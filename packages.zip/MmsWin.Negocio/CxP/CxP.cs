﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;
using MmsWin.Comun;

namespace MmsWin.Negocio.CxP
{
    public class CxP
    {
        internal static CxP CxPdet;

        public static CxP GetInstance()
        {
            if (CxPdet == null)
                CxPdet = new CxP();
            return CxPdet;
        }

        public DataTable ObtenCxP(string marca, string FchDe, string FchHas, string Folio,
                                            string comprador, string ParProveedor, string PartbNombre, string PartbEstilo,
                                            string ParDescripcion, string ParFechaRevision)
        {
            DataTable dtReprog1 = null;
            try
            {
                dtReprog1 = MmsWin.Datos.CxP.CxP.ObtenCxP(marca, FchDe, FchHas, Folio, comprador, ParProveedor, PartbNombre, PartbEstilo, ParDescripcion, ParFechaRevision);

                DataView dv = dtReprog1.DefaultView;
                dtReprog1 = dv.ToTable();

                return dtReprog1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EliminaCxP1(string ParProveedor, string ParEstilo, string ParFchRev, string ParFchRepro)
        {
            MmsWin.Datos.CxP.CxP.EliminaCxP(ParProveedor, ParEstilo, ParFchRev, ParFchRepro);
        }

        /// <summary>
        /// Obtener las reprogramaciones preautorizadas para que se liguen a un formato.
        /// Agrega la columna de "Seleccion" al datatable 
        /// </summary>
        /// <returns>DataTable con los datos</returns>
        /// <remarks>PROGRMADOR: OCG 01/12/2016</remarks>
        public static DataTable CargaCxPesSinFormato(string Estilo = "", int Cadena = 999, int Comprador = 999)
        {
            DataTable dt = new DataTable("Preautorizaciones");

            dt = Datos.CxP.CxP.CargaCxPesSinFormato(Estilo, Cadena, Comprador).Copy();

            ////Agregar columna para ser utilizada como indicador de selección por medio de CheckBox
            //dt.Columns.Add("Seleccion", typeof(bool));

            ////Posicionar columna como la primera
            //dt.Columns["Seleccion"].SetOrdinal(0);

            return dt;
        }

        /// <summary>
        /// Obtener el número de folio siguiente para el reporte
        /// </summary>
        /// <param name="Tabla">1 = MMSATOBJ.SAT177F14, 2 = MMSATOBJ.SAT177F41 </param>
        /// <returns>Folio</returns>
        /// <remarks>PROGRMADOR: OCG 19/12/2016</remarks>
        public static string ObtenerFolio(int Tabla = 1)
        {
            return Datos.CxP.CxP.ObtenerFolio(Tabla);
        }

        /// <summary>
        /// Carga los Folios disponibles en el sistema para consulta
        /// </summary>
        /// <param name="Folio">Folio que se busca</param>
        /// <returns>DataTable con los folios encontrados</returns>
        public static DataTable CargaListaFolios(string Folio = "", string Estatus = "P", int Marca = 999, int Comprador = 999)
        {
            return Datos.CxP.CxP.CargaListaFolios(Folio, Estatus, Marca, Comprador);
        }

        /// <summary>
        /// Asigna el estilo preautorizado a un folio de reporte
        /// </summary>
        /// <param name="Folio">Número de folio al que se ligará</param>
        /// <param name="Marca">Marca a la que pertenece el estilo</param>
        /// <param name="EstiloID">Número Estilo</param>
        /// <param name="ProveedorID">Número Proveedor</param>
        /// <param name="REPFRV">Fecha revisión</param>
        /// <param name="REPFRP">Fecha nueva programación</param>
        /// <returns>True: Actualización satisfactoria, False: Actualización fallida</returns>
        public static bool AsignaFolio(string Folio, string Marca, string EstiloID, string ProveedorID, int REPFRV, int REPFRP)
        {
            return Datos.CxP.CxP.AsignaFolio(Folio, Marca, EstiloID, ProveedorID, REPFRV, REPFRP);
        }

        /// <summary>
        /// Carga el detalle de los estilos preautorizados por folio
        /// </summary>
        /// <param name="Folio">Número de reporte</param>
        /// <returns>DataTable con los datos</returns>
        /// <remarks>PROGRMADOR: OCG 20/12/2016</remarks>
        public static DataTable CargaDetalleFolio(string Folio)
        {
            return Datos.CxP.CxP.CargaDetalleFolio(Folio);
        }

        /// <summary>
        /// Libera los estilos indicados para poder ser vinculados a otra solicitud
        /// </summary>
        /// <param name="EstiloID">Número Estilo</param>
        /// <param name="ProveedorID">Número Proveedor</param>
        /// <param name="REPFRV">Fecha revisión</param>
        /// <param name="REPFRP">Fecha nueva programación</param>
        /// <returns>True: Actualización satisfactoria, False: Actualización fallida</returns>
        public static bool LiberarEstilos(string EstiloID, string ProveedorID, DateTime REPFRV, DateTime REPFRP)
        {
            return Datos.CxP.CxP.LiberarEstilos(EstiloID, ProveedorID, Convert.ToInt32(REPFRV.ToString("yyMMdd")), Convert.ToInt32(REPFRP.ToString("yyMMdd")));
        }

        /// <summary>
        /// Autorizar los estilos indicados 
        /// </summary>
        /// <param name="EstiloID">Número Estilo</param>
        /// <param name="ProveedorID">Número Proveedor</param>
        /// <param name="REPFRV">Fecha revisión</param>
        /// <param name="REPFRP">Fecha nueva programación</param>
        /// <returns>True: Actualización satisfactoria, False: Actualización fallida</returns>
        public static bool AutorizarEstilos(string EstiloID, string ProveedorID, DateTime REPFRV, DateTime REPFRP)
        {
            return Datos.CxP.CxP.AutorizarEstilos(EstiloID, ProveedorID, Convert.ToInt32(REPFRV.ToString("yyMMdd")), Convert.ToInt32(REPFRP.ToString("yyMMdd")));

        }

        /// <summary>
        /// Obtiene el porcentaje mínimo para que el estilo pueda ser reprogramado para su calificación
        /// </summary>
        /// <param name="Cadena">Número de la marca o cadena</param>
        /// <param name="Fecha">Fecha en la que se hizo la revisión o calificación</param>
        /// <returns>Porcentaje mínimo que debe de tener en la calificación</returns>
        /// <remarks>PROGRMADOR: OCG 28/12/2016</remarks>
        public static string PorcentajeMinimoReprogramar(int Cadena, DateTime Fecha)
        {
            return Datos.CxP.CxP.PorcentajeMinimoReprogramar(Cadena, Fecha);
        }

        /// <summary>
        /// Busca el proveedor en la tabla de proveedores internacionales para determinar su origen
        /// </summary>
        /// <param name="NumeroProveedor">Número de proveedor</param>
        /// <returns>Número del proveedor si es que es encontrado</returns>
        /// /// <remarks>PROGRMADOR: OCG 28/12/2016</remarks>
        public static bool ProveedorNacional(int NumeroProveedor)
        {
            int dato = 0;

            dato = Datos.CxP.CxP.ProveedorNacional(NumeroProveedor);

            if (dato > 0)
                return true;
            else
                return false;
        }

        public static bool AsignaFolioOC(int Folio, int OrdenCompra, string Usuario)
        {
            return Datos.CxP.CxP.AsignaFolioOC(Folio, OrdenCompra, Usuario);
        }

        /// <summary>
        /// Carga los folios de las Solicitudes de Ampliación de Ordenes de Compra
        /// </summary>
        /// <param name="Folio">Folio a buscar</param>
        /// <param name="Estatus">Estatus por el que se desea filtrar</param>
        /// <returns>Datatable con los datos</returns>
        public static DataTable CargaListaFoliosOC(string Folio = "", string Estatus = "P", string Comprador = "")
        {
            return Datos.CxP.CxP.CargaListaFoliosOC(Folio, Estatus, Comprador);

        }

        public static DataTable CargaMotivosAOC()
        {
            return Datos.CxP.CxP.CargaMotivosAOC();
        }

        public static bool ActualizarFechaAmpliacion(DateTime Fecha, int MotivoID, int Folio, int OrdenCompra)
        {
            return Datos.CxP.CxP.ActualizarFechaAmpliacion(Fecha, MotivoID, Folio, OrdenCompra);
        }

        public static bool LiberarOrdeneCompra(int OrdenCompra)
        {
            return Datos.CxP.CxP.LiberarOrdeneCompra(OrdenCompra);
        }

        public static bool AutorizarOrdenesCompra(int OrdenCompra, string Usuario)
        {
            return Datos.CxP.CxP.AutorizarOrdenesCompra(OrdenCompra, Usuario);
        }

        public static DataTable CargaOCFillRate(string Param)
        {
            return Datos.CxP.CxP.CargaOCFillRate(Param);
        }

        public static DataTable CargaOCFillRate(int Param)
        {
            return Datos.CxP.CxP.CargaOCFillRate(Param);
        }

        public static bool AsignaFolioOCFillRate(int Folio, int OrdenCompra, string Usuario)
        {
            return Datos.CxP.CxP.AsignaFolioOCFillRate(Folio, OrdenCompra, Usuario);
        }

        public static DataTable CargaListaFoliosOCFillRate(string Folio = "", string Estatus = "P")
        {
            return Datos.CxP.CxP.CargaListaFoliosOCFillRate(Folio, Estatus);
        }

        public static bool AutorizarExcepcionFillRate(int OrdenCompra)
        {
            return Datos.CxP.CxP.AutorizarExcepcionFillRate(OrdenCompra);
        }

        public static decimal ObtenerPorcentajePenalizacion(decimal FillRate)
        {
            return Datos.CxP.CxP.ObtenerPorcentajePenalizacion(FillRate);
        }

        public static DataTable CargaMotivosExceFillRate()
        {
            return Datos.CxP.CxP.CargaMotivosExceFillRate();
        }

        public static bool ActualizarMontoFR(DateTime Fecha, int MotivoID, int Folio, int Monto)
        {
            return Datos.CxP.CxP.ActualizarMontoFR(Fecha, MotivoID, Folio, Monto);
        }

        public static string[] ObtFechasPeriodoFillRate(byte idConfiguracion)
        {
            return Datos.CxP.CxP.ObtFechasPeriodoFillRate(idConfiguracion);
        }

        public static decimal ObtFillRatePolitica_porProveedor(int idProveedor, byte idConfiguracion)
        {
            return Datos.CxP.CxP.ObtFillRatePolitica_porProveedor(idProveedor, idConfiguracion);
        }

        public static DataTable obtCatProveedoresFillRate()
        {
            return Datos.CxP.CxP.obtCatProveedoresFillRate();
        }

        public static bool LiberarOrdeneCompraFillRate(int OrdenCompra)
        {
            return Datos.CxP.CxP.LiberarOrdeneCompraFillRate(OrdenCompra);

        }

        /// <summary>
        /// Obtiene los meses en los que se puede extender una reprogramación, cuando se excede de las 4 semanas
        /// </summary>
        /// <param name="idMarca">Marca</param>
        /// <returns>Matriz con el rango de fechas</returns>
        /// <remarks>PROGRMADOR: OCG 09/02/2017</remarks>
        public static DateTime[] obtPeriodoSemanasExtendidas(byte idMarca)
        {
            return Datos.CxP.CxP.obtPeriodoSemanasExtendidas(idMarca);
        }

        /// <summary>
        /// Obtener total de reprogramaciones por Proveedor-FechaRecibo-Estilo de la tabla
        /// MMSTOBJ.SAT177F14
        /// </summary>
        /// <param name="idProveedor">Número Proveedor</param>
        /// <param name="fechaRecibo">Fecha de Recibo</param>
        /// <param name="idEstilo">Número de Estilo</param>
        /// <remarks>PROGRMADOR: OCG 09/02/2017</remarks>
        /// <returns>Total de reprogramaciones</returns>
        public static byte obtNoCxPes(int idProveedor, int fechaRecibo, string idEstilo, int OrdenCompra)
        {
            return Datos.CxP.CxP.obtNoCxPes(idProveedor, fechaRecibo, idEstilo, OrdenCompra);
        }

        //-----------------------------------------------------------------------------------------

        /// <summary>
        /// Catálogo de "Excepciones de Reprogramación"
        /// Se carga del catálogo maestro  MMNETLIB.SAT177F42, filtro 'EXC'
        /// </summary>
        /// <remarks>Desarrollador: Omar Cervantes G. | 13/02/2017</remarks>
        /// <returns>Lista tipada Entidades.Catalogo</returns>
        public static List<Entidades.Catalogo> obtCatalogoCxPes()
        {
            string Query = "SELECT CHAR(AOMOTIV) AS ID, AODESCR AS VALUE FROM MMNETLIB.SAT177F42 WHERE AOCUCVE = 'EXC'";

            List<Entidades.Catalogo> list = Datos.Global.
                CargaDataTable(Query).AsEnumerable().Select(m => new Entidades.Catalogo()
                {
                    ID = m.Field<string>("ID"),
                    Value = m.Field<string>("Value"),

                }).ToList();

            return list;
        }

        /// <summary>
        /// Catálogo de "Tipos de Proveedor"
        /// Se carga del catálogo maestro  MMNETLIB.SAT177F42, filtro 'TIP'
        /// </summary>
        /// <remarks>Desarrollador: Omar Cervantes G. | 14/02/2017</remarks>
        /// <returns>List tipado a Entidades.Catalogo</returns>
        public static List<Entidades.Catalogo> obtCatalogoTiposProveedor()
        {
            string Query = "SELECT CHAR(AOMOTIV) AS ID, AODESCR AS VALUE FROM MMNETLIB.SAT177F42 WHERE AOCUCVE = 'TIP'";

            List<Entidades.Catalogo> list = Datos.Global.
                CargaDataTable(Query).AsEnumerable().Select(m => new Entidades.Catalogo()
                {
                    ID = m.Field<string>("ID"),
                    Value = m.Field<string>("Value"),

                }).ToList();

            return list;
        }

        /// <summary>
        /// Catálogo de "Proveedores"
        /// </summary>
        /// <remarks>Desarrollador: Omar Cervantes G. | 14/02/2017</remarks>
        /// <returns>Lista tipada Entidades.Catalogo</returns>
        public static List<Entidades.Catalogo> obtCatalogoProveedores()
        {
            //Vista catálogo de Proveedores
            string Query = " SELECT ID, VALUE FROM MMNETLIB.SATNETA03";

            List<Entidades.Catalogo> list = Datos.Global.
                CargaDataTable(Query.ToString(),false).AsEnumerable().Select(m => new Entidades.Catalogo()
                {
                    ID = m.Field<string>("ID"),
                    Value = m.Field<string>("Value"),

                }).ToList();

            return list;
        }

        /// <summary>
        /// Obtener la lista de los proveedores identificados como 
        /// "Importaciones" o "Maquila"
        /// </summary>
        /// <remarks>Desarrollador: Omar Cervantes G. | 14/02/2017</remarks>
        /// <returns>Lista de Proveedores y su tipo</returns>
        public static List<Entidades.TipoProveedores> obtProveedoresTipo()
        {
            //Vista de Tipos de Proveedores
            string Query = "SELECT * FROM MMNETLIB.SATNETA02";

            List<Entidades.TipoProveedores> list = Datos.Global.
                CargaDataTable(Query, false).AsEnumerable().Select(m => new Entidades.TipoProveedores()
                {
                    ProveedorID = m.Field<int>("ProveedorID"),
                    Proveedor = m.Field<string>("Proveedor"),
                    TipoID = m.Field<string>("TipoID"),
                    Tipo = m.Field<string>("Tipo"),

                }).ToList();

            return list;
        }
      
    }

}
