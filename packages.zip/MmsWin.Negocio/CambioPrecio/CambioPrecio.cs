﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MmsWin.Datos.CambioPrecio;
using System.Data;

namespace MmsWin.Negocio.CambioPrecio
{
    public class CambioPrecio
    {
        #region " Instancias de la capa de datos "
        internal static CambioPrecio DetCambioPrecio;

        public static CambioPrecio GetInstance()
        {
            if (DetCambioPrecio == null)
                DetCambioPrecio = new CambioPrecio();
            return DetCambioPrecio;
        }
        #endregion

        #region " Variable Globales "
        DataTable dtCambioPrecio = null;
        #endregion

        public DataTable CambioPrecioSinFolio(string idComprador)
        {
            try
            {
                return MmsWin.Datos.CambioPrecio.CambioPrecio.CambioPrecioSinFolio(idComprador);
            }
            catch { }
            finally { }

            return dtCambioPrecio;
        }

        public static string ObtieneFolio()
        {
            try
            {
                return MmsWin.Datos.CambioPrecio.CambioPrecio.ObtieneFolio();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static int nuevoFolioCP(DataTable dtProveEstilo, string Usuario)
        {
            try
            {
                return MmsWin.Datos.CambioPrecio.CambioPrecio.nuevoFolioCP(dtProveEstilo, Usuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static int modificaFolioCP(string folioMod, string costoMod, string precioMod, string margenMod, string proveeMod, string estiloMod, string marcaDes, string tempo, string idComprador)
        {
            try
            {
                return MmsWin.Datos.CambioPrecio.CambioPrecio.modificaFolioCP(folioMod, costoMod, precioMod, margenMod, proveeMod, estiloMod, marcaDes, tempo, idComprador);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable CargaListaFolios(string idComprador, string Folio = "P")
        {
            try
            {
                return Datos.CambioPrecio.CambioPrecio.CargaListaFolios(idComprador,Folio);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable CargaDetalleFolio(string Folio)
        {
            try
            {
                return Datos.CambioPrecio.CambioPrecio.CargaDetalleFolio(Folio);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable cargaDetallePorFolio(string Folio, string proveedor, string estilo, string marca, string temp)
        {
            try
            {
                return Datos.CambioPrecio.CambioPrecio.cargaDetallePorFolio(Folio, proveedor, estilo, marca, temp);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool AutorizaFolio(string folio, string estatus, string usuario)
        {
            try
            {
                return Datos.CambioPrecio.CambioPrecio.AutorizaFolio(folio, estatus, usuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool EliminaNoAutorizados(string folio, string estilo, string proveedor, string marca, string temporada, string idcomprador)
        {
            try
            {
                return Datos.CambioPrecio.CambioPrecio.EliminaNoAutorizados(folio, estilo, proveedor, marca, temporada, idcomprador);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public decimal obtenMargenPrecio(string marca)
        {
            try
            {
                return MmsWin.Datos.CambioPrecio.CambioPrecio.obtenMargenPrecio(marca);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable obtenRedondeoPre(string marca)
        {
            try
            {
                return MmsWin.Datos.CambioPrecio.CambioPrecio.obtenRedondeoPre(marca);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void ObtenEstilosPrepedidos(string folio)
        {
            try
            {
                MmsWin.Datos.CambioPrecio.CambioPrecio.ObtenEstilosPrepedidos(folio);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}