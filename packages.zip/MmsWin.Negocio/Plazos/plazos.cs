﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Plazos
{
    public class plazos
    {
        internal static plazos plazosDet;

        public static plazos GetInstance()
        {
            if (plazosDet == null)
                plazosDet = new plazos();
            return plazosDet;
        }

        public DataTable detallePlazosDBR(string marca, string comprador)
        {
            try
            {
                return MmsWin.Datos.Plazos.plazos.detallePlazosDBR(marca, comprador);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
