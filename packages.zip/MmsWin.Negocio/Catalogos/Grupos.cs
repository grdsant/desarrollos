﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Catalogos
{
    public class Grupos
    {
        internal static Grupos GruposDet;

        public static Grupos GetInstance()
        {
            if (GruposDet == null)
                GruposDet = new Grupos();
            return GruposDet;
        }

        public string EliminaGrupos( DataTable dtGrupos)
        {
            string mensaje = string.Empty;
            mensaje = MmsWin.Datos.Catalogos.Grupos.EliminaGrupos(dtGrupos);
            return mensaje;
        }
    }
}
