﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Catalogos;

namespace MmsWin.Negocio.Catalogos
{
    public class TemporadaMms
    {

        internal static TemporadaMms TemporadasMmsDet;

        public static TemporadaMms GetInstance()
        {
            if (TemporadasMmsDet == null)
                TemporadasMmsDet = new TemporadaMms();
            return TemporadasMmsDet;
        }

        public Dictionary<string , string> ObtenTemporadaMms()
        {
            try
            {
                return MmsWin.Datos.Catalogos.TemporadasMms.ObtenTemporadasMms();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenTemporadasMmsSEA(string temporada, string descripcion)
        {
            DataTable dtTemporadas = null;
            try
            {
                dtTemporadas = MmsWin.Datos.Catalogos.TemporadasMms.ObtenTemporadasMmsSEA(temporada, descripcion);

                return dtTemporadas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
