﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Catalogos
{
    public class Marca
    {
        internal static Marca MarcaDet;

        public static Marca GetInstance()
        {
            if (MarcaDet == null)
                MarcaDet = new Marca();
            return MarcaDet;
        }

        public Dictionary<string, string> ObtenMarca()
        {
            try
            {
                return MmsWin.Datos.Catalogos.Marca.ObtenMarca();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
