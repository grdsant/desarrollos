﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Catalogos
{
    public class Excepciones
    {
        internal static Excepciones Excepcion;

        public static Excepciones GetInstance()
        {
            if (Excepcion == null)
                Excepcion = new Excepciones();
            return Excepcion;
        }

        public Dictionary<string, string> ObteneExcepciones()
        {
            try
            {
                return MmsWin.Datos.Catalogos.Excepciones.ObtenExcepciones();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
