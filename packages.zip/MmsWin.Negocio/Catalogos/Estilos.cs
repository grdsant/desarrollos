﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Catalogos
{
    public class Estilos
    {
        internal static Estilos EstilosDet;

        public static Estilos GetInstance()
        {
            if (EstilosDet == null)
                EstilosDet = new Estilos();
            return EstilosDet;
        }

        public DataTable ObtenEsilos(string proveedor,string nombre,string estilo,string descripcion, string dp, string sd, string cl, string sc, string dpd, string sdd, string cld, string scd, string usuario )
        {
            try
            {
                return MmsWin.Datos.Catalogos.EstilosMms.ObtenEstilosMms(proveedor, nombre, estilo, descripcion, dp, sd, cl, sc, dpd, sdd, cld, scd, usuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
