﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Catalogos
{
   public class Reprogramados
    {
       internal static Reprogramados ReprogramadosDet;

       public static Reprogramados GetInstance()
        {
            if (ReprogramadosDet == null)
                ReprogramadosDet = new Reprogramados();
            return ReprogramadosDet;
        }

       public Dictionary<string, string> ObtenReprogramados()
        {
            try
            {
                return MmsWin.Datos.Catalogos.Reprogramados.ObtenReprogramados();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

       public Dictionary<string, string> ObteneExcepciones()
       {
           try
           {
               return MmsWin.Datos.Catalogos.Reprogramados.ObtenReprogramados();
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

    }
}
