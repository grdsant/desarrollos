﻿using System.Data;
using MmsWin.Datos.Catalogos;

namespace MmsWin.Negocio.Catalogos
{
    public class Motivos
    {
        public static DataTable CargaMotivos()
        {
            DataTable dtMotivos = new DataTable();

            dtMotivos = Datos.Catalogos.Motivos.CargaMotivos().Copy();

            DataRow workRow = dtMotivos.NewRow();
            workRow["MOVOID"] = "0";
            workRow["DSCMOV"] = "<< SELECCIONAR >>";
            dtMotivos.Rows.InsertAt(workRow,0);

            return dtMotivos;
        }

        public static DataTable CargaMotivosDSB()
        {
            DataTable dtMotivos = new DataTable();

            dtMotivos = Datos.Catalogos.Motivos.CargaMotivosDSB().Copy();

            DataRow workRow = dtMotivos.NewRow();
            workRow["MOVOID"] = "0";
            workRow["DSCMOV"] = "<< SELECCIONAR >>";
            dtMotivos.Rows.InsertAt(workRow, 0);

            return dtMotivos;
        }
    }
}
