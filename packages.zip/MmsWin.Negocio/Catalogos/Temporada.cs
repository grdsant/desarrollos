﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Catalogos
{
    public class Temporada
    {
        internal static Temporada TemporadaDet;

        public static Temporada GetInstance()
        {
            if (TemporadaDet == null)
                TemporadaDet = new Temporada();
            return TemporadaDet;
        }

        public DataTable ObtenTemporada()
        {
            try
            {
               //return new DataTable();
                 return MmsWin.Datos.Catalogos.Temporada.ObtenTemporada();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
