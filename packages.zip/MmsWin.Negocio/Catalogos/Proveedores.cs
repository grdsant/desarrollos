﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Catalogos
{
    public class Proveedores
    {
        internal static Proveedores ProveedoresDet;

        public static Proveedores GetInstance()
        {
            if (ProveedoresDet == null)
                ProveedoresDet = new Proveedores();
            return ProveedoresDet;
        }

        public DataTable ObtenProveedores(string proveedor, string nombre, string usuario)
        {
            try
            {
                return MmsWin.Datos.Catalogos.Proveedores.ObtenProveedores(proveedor, nombre, usuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
