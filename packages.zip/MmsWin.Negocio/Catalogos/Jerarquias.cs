﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Catalogos
{
    public class Jerarquia
    {
        internal static Jerarquia JerarquiaDet;

        public static Jerarquia GetInstance()
        {
            if (JerarquiaDet == null)
                JerarquiaDet = new Jerarquia();
            return JerarquiaDet;
        }

        public DataTable ObtenJerarquias(string dp, string sd, string cl, string sc, string dpd, string sdd, string cld, string scd)
        {
            try
            {
                return MmsWin.Datos.Catalogos.JerarquiasMms.ObtenJerarquiasMms(dp, sd, cl, sc, dpd, sdd, cld, scd);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
