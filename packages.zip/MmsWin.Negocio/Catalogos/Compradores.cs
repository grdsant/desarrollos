﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Catalogos;

namespace MmsWin.Negocio.Catalogos
{
    public class Compradores
    {

        internal static Compradores CompradoresDet;

        public static Compradores GetInstance()
        {
            if (CompradoresDet == null)
                CompradoresDet = new Compradores();
            return CompradoresDet;
        }
        public Dictionary<string , string> ObtenCompradors()
        {
            try
            {
                return MmsWin.Datos.Catalogos.Compradores.ObtenCompradors();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
