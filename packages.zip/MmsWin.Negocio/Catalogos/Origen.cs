﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Catalogos
{
    public class Origen
    {
        internal static Origen OrigenDet;

        public static Origen GetInstance()
        {
            if (OrigenDet == null)
                OrigenDet = new Origen();
            return OrigenDet;
        }

        public Dictionary<string, string> ObtenOrigen()
        {
            try
            {
                return MmsWin.Datos.Catalogos.Origen.ObtenOrigen();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
