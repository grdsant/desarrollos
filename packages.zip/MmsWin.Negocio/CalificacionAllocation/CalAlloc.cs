﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.CalificacionAllocation
{
    public class CalAlloc
    {
        internal static CalAlloc CalAllocDet;
        public static CalAlloc GetInstance()
        {
            if (CalAllocDet == null)
                CalAllocDet = new CalAlloc();
            return CalAllocDet;
        }

        public DataTable ObtenCalAlloc1(string marca, string comprador, string FchDe, string FchHas, string ParTienda, string ParProveedor, string PartbNombre, string PartbEstilo, string ParDescripcion)
        {
            DataTable dtCalAlloc1 = null;
            try
            {
                dtCalAlloc1 = MmsWin.Datos.CalificacionAllocation.CalAlloc.ObtenCalAlloc(marca, comprador, FchDe, FchHas, ParTienda, ParProveedor, PartbNombre, PartbEstilo, ParDescripcion);

                DataView dv = dtCalAlloc1.DefaultView;
                dtCalAlloc1 = dv.ToTable();

                return dtCalAlloc1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void validacion(string Nota)
        {
            if (Nota == " ")
            {

            }
        }

        public void EliminaDocumentos(string ParFchBon, string ParFchRev, string ParTipoCal, string ParTemporada, string ParTienda, string ParProveedor, string ParEstilo, string ParNota)
        {
            MmsWin.Datos.CalificacionAllocation.CalAlloc.EliminaDocumento(ParFchBon, ParFchRev, ParTipoCal, ParTemporada, ParTienda, ParProveedor, ParEstilo, ParNota);
        }

        public void EjecutaCargaPDF(string ParFchBon, string ParFchCal, string ParNota, string ParTienda, string ParPrv, string ParSty, string ParDest, string ParTpo, string ParUser)
        {
            MmsWin.Datos.CalificacionAllocation.CalAlloc.EjecutaCargaPDF(ParFchBon, ParFchCal, ParNota, ParTienda,ParPrv, ParSty, ParDest, ParTpo, ParUser);
        }
    }
}
