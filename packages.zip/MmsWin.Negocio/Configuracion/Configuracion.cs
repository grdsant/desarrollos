﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;

namespace MmsWin.Negocio.Configuracion
{
    public class Configuracion
    {
        internal static Configuracion ConfiguracionDet;
        public static Configuracion GetInstance()
        {
            if (ConfiguracionDet == null)
                ConfiguracionDet = new Configuracion();
            return ConfiguracionDet;
        }

        public DataTable ObtenConfiguracion1()
        {
            DataTable dtConfiguracion1 = null;
            try
            {
                dtConfiguracion1 = MmsWin.Datos.Configuracion.Configuracion.ObtenConfiguracion();

                DataView dv = dtConfiguracion1.DefaultView;
                dtConfiguracion1 = dv.ToTable();

                return dtConfiguracion1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateConfiguracion(DataTable dtConfiguracion)
        {
            try
            {
                MmsWin.Datos.Configuracion.Configuracion.UpdateConfiguracion(dtConfiguracion);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EliminaConfiguracion(string marcaB)
        {
            MmsWin.Datos.Configuracion.Configuracion.EliminadtConfiguracion(marcaB);
        }

    }
}
