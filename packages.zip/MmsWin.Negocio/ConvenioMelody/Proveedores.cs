﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.ConvenioMelody
{
    public class Proveedores
    {
        internal static Proveedores ProveedoresDet;
        public static Proveedores GetInstance()
        {
            if (ProveedoresDet == null)
                ProveedoresDet = new Proveedores();
            return ProveedoresDet;
        }

        public string AgregarProveedores(DataTable dtProveedores, string usuario)
        {
            string mensaje = string.Empty;

            mensaje = MmsWin.Datos.ConvenioMelody.Proveedores.AgregarProveedores(dtProveedores, usuario);

            return mensaje;
        }
    }
}
