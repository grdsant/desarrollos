﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.ConvenioMelody
{
    public class Estilos
    {
        internal static Estilos EstilosDet;
        public static Estilos GetInstance()
        {
            if (EstilosDet == null)
                EstilosDet = new Estilos();
            return EstilosDet;
        }

        public string AgregarEstilos(DataTable dtEstilos, string usuario)
        {
            string mensaje = string.Empty;

            mensaje = MmsWin.Datos.ConvenioMelody.Estilos.AgregarEstilos(dtEstilos, usuario);

            return mensaje;
        }
    }
}
