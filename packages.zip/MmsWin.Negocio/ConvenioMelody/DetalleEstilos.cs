﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.ConvenioMelody
{
    public class DetalleEstilos
    {
        internal static DetalleEstilos DetalleEstilosDet;

        public static DetalleEstilos GetInstance()
        {
            if (DetalleEstilosDet == null)
                DetalleEstilosDet = new DetalleEstilos();
            return DetalleEstilosDet;
        }

        public DataTable ObtenDetalleEstilos(string marca, string grupo, string tipo, string proveedor, string nombre, string estilo, string descripcion, string dp, string sd, string cl, string sc, string dpd, string sdd, string cld, string scd, string usuario)
        {
            try
            {
                return MmsWin.Datos.Catalogos.DetalleEstilos.ObtenDetalleEstilos(marca, grupo, tipo, proveedor, nombre, estilo, descripcion, dp, sd, cl, sc, dpd, sdd, cld, scd, usuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
