﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.ConvenioMelody
{
    public class Jerarquias
    {
        internal static Jerarquias JerarquiasDet;
        public static Jerarquias GetInstance()
        {
            if (JerarquiasDet == null)
                JerarquiasDet = new Jerarquias();
            return JerarquiasDet;
        }

        public string AgregarJerarquias(DataTable dtJerarquias, string usuario)
        {
            string mensaje = string.Empty;

            mensaje = MmsWin.Datos.ConvenioMelody.Jerarquias.AgregarJerarquias(dtJerarquias, usuario);

            return mensaje;
        }
    }
}
