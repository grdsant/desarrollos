﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.ConvenioMelody
{
    public class CalificacionGrid
    {
        internal static CalificacionGrid ConvenioMelodyDet;

        public static CalificacionGrid GetInstance()
        {
            if (ConvenioMelodyDet == null)
                ConvenioMelodyDet = new CalificacionGrid();
            return ConvenioMelodyDet;
        }

        public string EjecutaEnvio(string marca, string fecha, string tipo, string temporada, string tabla, string proveedor, string estilo)
        {
            string mensaje = string.Empty;

            try
            {
                mensaje = MmsWin.Datos.ConvenioMelody.CalificacionGrid.EjecutaEnvio(marca, fecha, tipo, temporada, tabla, proveedor, estilo);
            }
            catch { }
            finally { }

            return mensaje;
        }
    }
}
