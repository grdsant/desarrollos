﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.ConvenioMelody
{
    public class Grupos
    {
        internal static Grupos GruposDet;
        public static Grupos GetInstance()
        {
            if (GruposDet == null)
                GruposDet = new Grupos();
            return GruposDet;
        }

        public string AgregarGrupos(DataTable dtTemporadas, string usuario)
        {
            string mensaje = string.Empty;

           mensaje = MmsWin.Datos.ConvenioMelody.Grupos.AgregarGrupos(dtTemporadas, usuario);

            return mensaje;
        }
    }
}
