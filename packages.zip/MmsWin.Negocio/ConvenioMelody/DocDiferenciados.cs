﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.ConvenioMelody
{
    public class DocDiferenciados
    {
        internal static DocDiferenciados DocDiferenciadosDet;
        public static DocDiferenciados GetInstance()
        {
            if (DocDiferenciadosDet == null)
                DocDiferenciadosDet = new DocDiferenciados();
            return DocDiferenciadosDet;
        }

        public DataTable ObtenDocDiferenciados1(string marca, string comprador, string FchDe, string FchHas, string ParTienda, string ParProveedor, string PartbNombre, string PartbEstilo, string ParDescripcion)
        {
            DataTable dtDocDiferenciados1 = null;
            try
            {
                dtDocDiferenciados1 = MmsWin.Datos.ConvenioMelody.DocDiferenciados.ObtenDocDiferenciados(marca, comprador, FchDe, FchHas, ParTienda, ParProveedor, PartbNombre, PartbEstilo, ParDescripcion);

                DataView dv = dtDocDiferenciados1.DefaultView;
                dtDocDiferenciados1 = dv.ToTable();

                return dtDocDiferenciados1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void validacion(string Nota)
        {
            if (Nota == " ")
            {

            }
        }

        public void EliminaDocumentos(string ParFchBon, string ParFchRev, string ParTipoCal, string ParTemporada, string ParTienda, string ParProveedor, string ParEstilo, string ParNota)
        {
            MmsWin.Datos.ConvenioMelody.DocDiferenciados.EliminaDocumento(ParFchBon, ParFchRev, ParTipoCal, ParTemporada, ParTienda, ParProveedor, ParEstilo, ParNota);
        }

        public void EjecutaCargaPDF(string ParFchBon, string ParFchCal, string ParNota, string ParTienda, string ParPrv, string ParSty, string ParDest, string ParTpo, string ParUser)
        {
            MmsWin.Datos.ConvenioMelody.DocDiferenciados.EjecutaCargaPDF(ParFchBon, ParFchCal, ParNota, ParTienda,ParPrv, ParSty, ParDest, ParTpo, ParUser);
        }
    }
}
