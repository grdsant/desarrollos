﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.ConvenioMelody;

namespace MmsWin.Negocio.ConvenioMelody
{
    public class CalendarioProgramacionGrid
    {
        internal static CalendarioProgramacionGrid ConvenioMelodyDet;

        public static CalendarioProgramacionGrid GetInstance()
        {
            if (ConvenioMelodyDet == null)
                ConvenioMelodyDet = new CalendarioProgramacionGrid();
            return ConvenioMelodyDet;
        }

        public DataTable ObtenCalendarioProgramacionGrid1(string marca, string anio, string temporadaCombo, string usuario)
        {
            DataTable dtConvenioMelody1 = null;

            try
            {
                dtConvenioMelody1 = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenCalendarioProgramacionGrid(marca, anio, temporadaCombo, usuario);
                DataView dv = dtConvenioMelody1.DefaultView;
                dtConvenioMelody1 = dv.ToTable();
            }
            catch { }
            finally { }

            return dtConvenioMelody1;
        }

        public DataTable ObtenCalificaion(string marca, string comprador,string FchDe, string FchHas, string tipo, string temporada, string parTipoCalificacion, string parFchCalificacion, string parProveedor, string parNombre, string parEstilo, string parDescripcion)
        {
            DataTable dtCalificaiones = null;

            try
            {
                dtCalificaiones = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenCalificaiones(marca, comprador, FchDe, FchHas, tipo, temporada, parTipoCalificacion, parFchCalificacion, parProveedor, parNombre, parEstilo, parDescripcion);
                DataView dv = dtCalificaiones.DefaultView;
                dtCalificaiones = dv.ToTable();
            }
            catch { }
            finally { }

            return dtCalificaiones;
        }

        public DataTable ObtenCalificaionTda(string marca, string comprador, string FchDe, string FchHas, string tipo, string temporada, string parTipoCalificacion, string parFchCalificacion, string parProveedor, string parNombre, string parEstilo, string parDescripcion)
        {
            DataTable dtCalificaiones = null;

            try
            {
                dtCalificaiones = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenCalificaionesTda(marca, comprador, FchDe, FchHas, tipo, temporada, parTipoCalificacion, parFchCalificacion, parProveedor, parNombre, parEstilo, parDescripcion);
                DataView dv = dtCalificaiones.DefaultView;
                dtCalificaiones = dv.ToTable();
            }
            catch { }
            finally { }

            return dtCalificaiones;
        }

        public DataTable ObtenValidacion(string ParUser)
        {
            DataTable dtCalificaiones = null;

            try
            {
                dtCalificaiones = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenValidacion(ParUser);
            }
            catch { }
            finally { }

            return dtCalificaiones;
        }

        public DataTable ObtenCalificaionTdaXcalificacion(string marca, string comprador, string FchDe, string FchHas, string temporada, string parTipoCalificacion, string parFchCalificacion, string parProveedor, string parNombre, string parEstilo, string parDescripcion, string parCalificacion, string parOrigen)
        {
            DataTable dtCalificaiones = null;

            try
            {
                dtCalificaiones = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenCalificaionesTdaXcalificacion(marca, comprador, FchDe, FchHas, temporada, parTipoCalificacion, parFchCalificacion, parProveedor, parNombre, parEstilo, parDescripcion, parCalificacion, parOrigen );
                DataView dv = dtCalificaiones.DefaultView;
                dtCalificaiones = dv.ToTable();
            }
            catch { }
            finally { }

            return dtCalificaiones;
        }

        public DataTable ObtenResumenTda(string marca, string comprador, string FchDe, string FchHas, string tipo, string temporada, string parTipoCalificacion, string parFchCalificacion, string parProveedor, string parNombre, string parEstilo, string parDescripcion)
        {
            DataTable dtCalificaiones = null;

            try
            {
                dtCalificaiones = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenResumensTda(marca, comprador, FchDe, FchHas, tipo, temporada, parTipoCalificacion, parFchCalificacion, parProveedor, parNombre, parEstilo, parDescripcion);
                DataView dv = dtCalificaiones.DefaultView;
                dtCalificaiones = dv.ToTable();
            }
            catch { }
            finally { }

            return dtCalificaiones;
        }

        public DataTable EjecutaConsultaTda(string marca, string comprador, string FchDe, string FchHas, string tipo, string temporada, string parTipoCalificacion, string parFchCalificacion, string parProveedor, string parNombre, string parEstilo, string parDescripcion, string usuario)
        {
            DataTable dtCalificaiones = null;

            try
            {
                dtCalificaiones = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.EjecutaConsultaTda( marca,  comprador,  FchDe,  FchHas,  tipo,  temporada,  parTipoCalificacion,  parFchCalificacion,  parProveedor,  parNombre,  parEstilo,  parDescripcion,  usuario);
                DataView dv = dtCalificaiones.DefaultView;
                dtCalificaiones = dv.ToTable();
            }
            catch { }
            finally { }

            return dtCalificaiones;
        }

        public DataTable ObtenResumenGlobal(string marca, string comprador, string FchDe, string FchHas, string tipo, string temporada, string parTipoCalificacion, string parFchCalificacion, string parProveedor, string parNombre, string parEstilo, string parDescripcion)
        {
            DataTable dtResumenGlobal = null;
            try
            {
                dtResumenGlobal = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenResumensGlobal(marca, comprador, FchDe, FchHas, tipo, temporada, parTipoCalificacion, parFchCalificacion, parProveedor, parNombre, parEstilo, parDescripcion);
                DataView dv = dtResumenGlobal.DefaultView;
                dtResumenGlobal = dv.ToTable();
            }
            catch { }
            finally { }
            return dtResumenGlobal;
        }

        public string EventoCalificacion1(string temporada, string tablaPorc, string tablaPorc2, string anio, string semana, string columna, string marca, string tipo, string estatus, string usuario, string rentOdespl)
        {
            string mensaje = string.Empty;

            try
            {
                mensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.EventoCalificacion(temporada, tablaPorc, tablaPorc2, anio, semana, columna, marca, tipo, estatus, usuario, rentOdespl);
            }
            catch { }
            finally { }

            return mensaje;
        }

        public string UpdateTemporadas(string temporada, string anio, string semana, string columna, string marca, string usuario, string campo)
        {
            string mensaje = string.Empty;

            try
            {
                mensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.UpdateTemporada(temporada, anio, semana, columna, marca, usuario, campo);
            }
            catch { }
            finally { }

            return mensaje;
        }

        public string EjecutaSimulaciones(string anio, string temporada, string marca, string renglon, string columna, string usuario, string calificacion, string rentOdesplaz)
        {
            string mensaje = string.Empty;

            try
            {
                mensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.EjecutaSimulacion(anio, temporada, marca, renglon, columna, usuario, calificacion, rentOdesplaz);
            }
            catch { }
            finally { }

            return mensaje;
        }

        public string ObtenFechaMmsNegocio(string anio, int semana, out string fechaMms)
        {
            string stMensaje = string.Empty;
            fechaMms = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenFechaMms(anio, semana, out fechaMms);
                return stMensaje;
            }
            catch { }
            finally { }
            return stMensaje;
        }

        public string UpdateCheckBoxCompras(string marca, string fecha, string tipo, string temporada, string tabla, string proveedor, string estilo,
                                                    string orden, string checkBox, string Observaciones, string usuario, string fechaUser, string horaUser)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.UpdatesCheckBoxCompras(marca, fecha, tipo, temporada, tabla, proveedor, estilo,
                                                                                                              orden, checkBox, Observaciones, usuario, fechaUser, horaUser);
                return stMensaje;
            }
            catch { }
            finally { }
            return stMensaje;
        }

        public string UpdateCheckBoxContraloria(string marca, string fecha, string tipo, string temporada, string tabla, string proveedor, string estilo,
                                                    string orden, string checkBox, string Observaciones, string usuario, string fechaUser, string horaUser)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.UpdatesCheckBoxContraloria(marca, fecha, tipo, temporada, tabla, proveedor, estilo,
                                                                                                              orden, checkBox, Observaciones, usuario, fechaUser, horaUser);
                return stMensaje;
            }
            catch { }
            finally { }
            return stMensaje;
        }

        public string UpdateCheckBoxComprasTda(string marca, string fecha, string tipo, string temporada, string tabla, string tienda, string proveedor, string estilo,
                                                    string orden, string checkBox, string Observaciones, string usuario, string fechaUser, string horaUser)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.UpdatesCheckBoxComprasTda(marca, fecha, tipo, temporada, tabla, tienda, proveedor, estilo,
                                                                                                              orden, checkBox, Observaciones, usuario, fechaUser, horaUser);
                return stMensaje;
            }
            catch { }
            finally { }
            return stMensaje;
        }

        public string UpdateCheckBoxContraloriaTda(string marca, string fecha, string tipo, string temporada, string tabla, string tienda, string proveedor, string estilo,
                                                    string orden, string checkBox, string Observaciones, string usuario, string fechaUser, string horaUser)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.UpdatesCheckBoxContraloriaTda(marca, fecha, tipo, temporada, tabla, tienda, proveedor, estilo,
                                                                                                              orden, checkBox, Observaciones, usuario, fechaUser, horaUser);
                return stMensaje;
            }
            catch { }
            finally { }
            return stMensaje;
        }

        public DataTable ObtenRebajasDiferenciadas(String marca, String comprador, String FchDe, String FchHas, string ParProveedor, string PartbNombre, string PartbEstilo, string ParDescripcion)
        {
            DataTable dtBonifica1 = null;
            try
            {
                dtBonifica1 = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenRebajaDiferenciada(marca, comprador, FchDe, FchHas, ParProveedor, PartbNombre, PartbEstilo, ParDescripcion);

                DataView dv = dtBonifica1.DefaultView;
                dtBonifica1 = dv.ToTable();
            }
            catch { }
            finally { }

            return dtBonifica1;
        }

        public void EliminaRebajasDiferenciadas(string ParFchBon, string ParFchRev, string ParTipoCal, string ParTemporada, string ParTienda, string ParProveedor, string ParEstilo)
        {
            MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.EliminaRebajaDiferenciada(ParFchBon, ParFchRev, ParTipoCal, ParTemporada, ParTienda, ParProveedor, ParEstilo);
        }

        public DataTable ObtenRutaPDFRebajasDiferenciadas(String ParFchBon, String ParFchRev, String ParTipoCal, String ParTemporada, String ParTienda, String ParProveedor, String ParEstilo, String ParNota)
        {
            DataTable dtRutaPDF = null;
            try
            {
                dtRutaPDF = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenRutaPDFRebajaDiferenciada(ParFchBon, ParFchRev, ParTipoCal, ParTemporada, ParTienda, ParProveedor, ParEstilo, ParNota);

                DataView dv = dtRutaPDF.DefaultView;
                dtRutaPDF = dv.ToTable();
            }
            catch { }
            finally { }

            return dtRutaPDF;
        }

        public void UpdateRebajasDiferenciadas(DataTable dtRebajaDiferenciada)
        {
            try
            {
                dtRebajaDiferenciada = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.UpdateRebajaDiferenciada(dtRebajaDiferenciada);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateCheckBoxRebajasDiferenciadas(DataTable dtCheckBox)
        {
            try
            {
                MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.UpdateCheckBoxRebajaDiferenciada(dtCheckBox);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenTablasPorc(string marca, string tabla)
        {
            DataTable dtTablasPorc = null;
            try
            {
                dtTablasPorc = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenTablasPorc( marca,  tabla);
                DataView dv = dtTablasPorc.DefaultView;
                dtTablasPorc = dv.ToTable();
            }
            catch { }
            finally { }

            return dtTablasPorc;
        }

        public string InsertTablasporc(string marca, string tabla, string secuencia, string delr, string alr, string porcentaje, string calificacion, string estatus, string userAlta, string fechaAlta, string horaAlta, string userCambio, string fechaCambio, string horaCambio)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.InsertTablasporc(marca, tabla, secuencia, delr, alr, porcentaje, calificacion, estatus, userAlta, fechaAlta, horaAlta, userCambio, fechaCambio, horaCambio);
            }

            catch { }
            finally { }
            return stMensaje;
        }

        public string UpdateTablasporc(string marca, string tabla, string secuencia, string delr, string alr, string porcentaje, string calificacion, string estatus, string userAlta, string fechaAlta, string horaAlta, string userCambio, string fechaCambio, string horaCambio)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.UpdateTablasporc(marca, tabla, secuencia, delr, alr, porcentaje, calificacion, estatus, userAlta, fechaAlta, horaAlta, userCambio, fechaCambio, horaCambio);
            }

            catch { }
            finally { }
            return stMensaje;
        }

        public string DeleteTablasporc(string marca, string tabla, string secuencia)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.DeleteTablasporc(marca, tabla, secuencia);
            }

            catch { }
            finally { }
            return stMensaje;
        }

        public string InsertRenglonNuevo(string marca, string anio)
        {
            string stMensaje = string.Empty;
            try
            {
                MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.InsertRenglonNuevo(marca, anio);
            }
            catch { }
            finally { }
            return stMensaje;
        }

        // Temporadas
        public DataTable ObtenTemporadaPropia(string marca, string temporada, string descripcion)
        {
            DataTable dtTablasPorc = null;
            try
            {
                dtTablasPorc = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenTemporadaPropia(marca, temporada, descripcion);
                DataView dv = dtTablasPorc.DefaultView;
                dtTablasPorc = dv.ToTable();
            }
            catch { }
            finally { }

            return dtTablasPorc;
        }

        public string InsertTemporadaPropia(string marca, string temporada, string descripcion, string estatus, string userAlta, string fechaAlta, string horaAlta, string userCambio, string fechaCambio, string horaCambio)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.InsertTemporadaPropia( marca,  temporada,  descripcion,  estatus,  userAlta,  fechaAlta,  horaAlta,  userCambio,  fechaCambio,  horaCambio);
            }

            catch { }
            finally { }
            return stMensaje;
        }

        public string UpdateTemporadaPropia(string marca, string temporada, string descripcion, string estatus, string userAlta, string fechaAlta, string horaAlta, string userCambio, string fechaCambio, string horaCambio)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.UpdateTemporadaPropia(marca, temporada, descripcion, estatus, userAlta, fechaAlta, horaAlta, userCambio, fechaCambio, horaCambio);
            }

            catch { }
            finally { }
            return stMensaje;
        }

        public string DeleteTemporadaPropia(string marca, string temporada, string descripcion)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.DeleteTemporadaPropia( marca,  temporada,  descripcion);
            }

            catch { }
            finally { }
            return stMensaje;
        }
        // Grupo de Temporadas
        public DataTable ObtenGrupoTemporadaPropia(string marca, string grupo,
                    string tipo,     
                    string desc,
                    string tmpMms,    
                    string desTmpMms, 
                    string dp,    
                    string sd,     
                    string cl,     
                    string sc,     
                    string dpd,    
                    string sdd,   
                    string cld,   
                    string scd,    
                    string prv,    
                    string prvDes, 
                    string sty,
                    string styDes 
            )
        {
            DataTable dtTablasPorc = null;
            try
            {
                dtTablasPorc = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenGrupoTemporadaPropia(marca, grupo, tipo, desc, tmpMms, desTmpMms, dp, sd, cl, sc, dpd, sdd, cld, scd, prv, prvDes, sty, styDes);
                DataView dv = dtTablasPorc.DefaultView;
                dtTablasPorc = dv.ToTable();
            }
            catch { }
            finally { }

            return dtTablasPorc;
        }

        public string InsertGrupoTemporadaPropia(
            string marca,     string temporadaPro, string renglon,  string secuecia,
            string tipoMms,   string descTpoMms,   string tmpMms,   string descTmpMms,   string Depto,       string subDepto, 
            string clase,     string subClase,     string desDepto, string desSubDepto,  string desClas,     string desSubClase,
            string Proveedor, string desProv,      string estilo,   string desEstio,     string estatus,
            string userAlta,  string fechaAlta,    string horaAlta, string userCambio,   string fechaCambio, string horaCambio)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.InsertGrupoTemporadaPropia(
                    marca,     temporadaPro, renglon,  secuecia,
                    tipoMms,   descTpoMms,   tmpMms,   descTmpMms,  Depto,       subDepto, 
                    clase,     subClase,     desDepto, desSubDepto, desClas,     desSubClase,
                    Proveedor, desProv,      estilo,   desEstio,    estatus,
                    userAlta,  fechaAlta,    horaAlta, userCambio,  fechaCambio, horaCambio);
            }

            catch { }
            finally { }
            return stMensaje;
        }

        public string UpdateGrupoTemporadaPropia(string marca, string temporada, string descripcion, string estatus, string userAlta, string fechaAlta, string horaAlta, string userCambio, string fechaCambio, string horaCambio)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.UpdateGrupoTemporadaPropia(marca, temporada, descripcion, estatus, userAlta, fechaAlta, horaAlta, userCambio, fechaCambio, horaCambio);
            }

            catch { }
            finally { }
            return stMensaje;
        }

        public string DeleteGrupoTemporadaPropia(string marca, string temporada, string descripcion)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.DeleteGrupoTemporadaPropia(marca, temporada, descripcion);
            }

            catch { }
            finally { }
            return stMensaje;
        }
        // Detalle Grupo de Temporadas
        public DataTable ObtenDetalleGrupoTemporadaPropia(string marca, string temporada, string descripcion)
        {
            DataTable dtTablasPorc = null;
            try
            {
                dtTablasPorc = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenDetalleGrupoTemporadaPropia(marca, temporada, descripcion);
                DataView dv = dtTablasPorc.DefaultView;
                dtTablasPorc = dv.ToTable();
            }
            catch { }
            finally { }

            return dtTablasPorc;
        }

        public string InsertDetalleGrupoTemporadaPropia(string marca, string temporada, string descripcion, string estatus, string userAlta, string fechaAlta, string horaAlta, string userCambio, string fechaCambio, string horaCambio)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.InsertDetalleGrupoTemporadaPropia(marca, temporada, descripcion, estatus, userAlta, fechaAlta, horaAlta, userCambio, fechaCambio, horaCambio);
            }

            catch { }
            finally { }
            return stMensaje;
        }

        public string UpdateDetalleGrupoTemporadaPropia(string marca, string temporada, string descripcion, string estatus, string userAlta, string fechaAlta, string horaAlta, string userCambio, string fechaCambio, string horaCambio)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.UpdateDetalleGrupoTemporadaPropia(marca, temporada, descripcion, estatus, userAlta, fechaAlta, horaAlta, userCambio, fechaCambio, horaCambio);
            }

            catch { }
            finally { }
            return stMensaje;
        }

        public string DeleteDetalleGrupoTemporadaPropia(string marca, string temporada, string descripcion)
        {
            string stMensaje = string.Empty;
            try
            {
                stMensaje = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.DeleteDetalleGrupoTemporadaPropia(marca, temporada, descripcion);
            }

            catch { }
            finally { }
            return stMensaje;
        }

        public DataTable ObtenAdministracion(string marca, string comprador, string fechaInicio, string fechaFinal, string temporada, string tipoCalificacion, string tipoConsulta, string niveltienda, string proveedor, string estilo, string depto, string subDepto, string clase, string subClase, string usuario)
        {
            DataTable dtCalificaiones = null;

            try
            {
                dtCalificaiones = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenAdministracion(marca, comprador, fechaInicio, fechaFinal, temporada, tipoCalificacion, tipoConsulta, niveltienda, proveedor, estilo, depto, subDepto, clase, subClase, usuario);
                DataView dv = dtCalificaiones.DefaultView;
                dtCalificaiones = dv.ToTable();
            }
            catch { }
            finally { }

            return dtCalificaiones;
        }

        public DataTable ObtenResumenAdministracion()
        {
            DataTable dtCalificaiones = null;

            try
            {
                dtCalificaiones = MmsWin.Datos.ConvenioMelody.CalendarioProgramacionGrid.ObtenResumenAdministracion();
                DataView dv = dtCalificaiones.DefaultView;
                dtCalificaiones = dv.ToTable();
            }
            catch { }
            finally { }

            return dtCalificaiones;
        }
    }
}
