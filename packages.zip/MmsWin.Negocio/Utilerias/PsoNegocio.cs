﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Utilerias;

namespace MmsWin.Negocio.Utilerias
{
   public class PsoNegocio
    {
        internal static PsoNegocio Paso;
        public static PsoNegocio GetInstance()
        {
            if (Paso == null)
                Paso = new PsoNegocio();
            return Paso;
        }

       // Metodos                                                                  
       //

        public DataTable ObtenDt1()
        {
            DataTable dtData1 = null;
            try
            {
                DataView dv = dtData1.DefaultView;
                dtData1 = dv.ToTable();

                return dtData1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
