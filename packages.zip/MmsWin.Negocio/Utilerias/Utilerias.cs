﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos;
using MmsWin.Datos.Utilerias;
using MmsWin.Comun;

namespace MmsWin.Negocio.Utilerias
{
    public class Utilerias
    {
        internal static Utilerias Utileria;

        public static Utilerias GetInstance()
        {
            if (Utileria == null)
                Utileria = new Utilerias();
            return Utileria;
        }

        public DataTable ObtenFechaInial1()
        {
            DataTable dtFechaInicial1 = null;
            try
            {
                dtFechaInicial1 = MmsWin.Datos.Utilerias.Utilerias.ObtenFechaInicial();

                DataView dv = dtFechaInicial1.DefaultView;
                dtFechaInicial1 = dv.ToTable();

                return dtFechaInicial1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenCalculos1(string ParFchBon, string ParFchRev, string ParProveedor, string ParEstilo, string ParNotCal, string ParUsuario)
        {
            DataTable dtCalculos1 = null;
            try
            {
                dtCalculos1 = MmsWin.Datos.Utilerias.Utilerias.ObtenCalculos(ParFchBon, ParFchRev, ParProveedor, ParEstilo, ParNotCal, ParUsuario);

                DataView dv = dtCalculos1.DefaultView;
                dtCalculos1 = dv.ToTable();

                return dtCalculos1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenCalculoNota(string ParFchBon, string ParFchRev, string ParProveedor, string ParEstilo, string ParNotCal, string ParUsuario, string ParSubTot, string TipMov, string TipCal, string ParPorc)
        {
            DataTable ObtenCalculoNota = null;
            try
            {
                ObtenCalculoNota = MmsWin.Datos.Utilerias.Utilerias.ObtenCalculoNota(ParFchBon, ParFchRev, ParProveedor, ParEstilo, ParNotCal, ParUsuario, ParSubTot, TipMov, TipCal, ParPorc);

                DataView dv = ObtenCalculoNota.DefaultView;
                ObtenCalculoNota = dv.ToTable();

                return ObtenCalculoNota;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenCalculoNotasDiferenciada(string ParFchBon, string ParFchRev, string ParTipo, string ParTemporada, string ParTienda, string ParProveedor, string ParEstilo, string ParNotCal, string ParUsuario, string ParSubTot, string TipMov, string TipCal, string ParPorc)
        {
            DataTable ObtenCalculoNota = null;
            try
            {
                ObtenCalculoNota = MmsWin.Datos.Utilerias.Utilerias.ObtenCalculoNotaDiferenciada(ParFchBon, ParFchRev, ParTipo, ParTemporada, ParTienda, ParProveedor, ParEstilo, ParNotCal, ParUsuario, ParSubTot, TipMov, TipCal, ParPorc);

                DataView dv = ObtenCalculoNota.DefaultView;
                ObtenCalculoNota = dv.ToTable();

                return ObtenCalculoNota;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertaRegistrosArebajar(DataTable dtDiferenciados, string ParUsuario, string porcentajeXaplicar, string PrecioFinalXaplicar)
        {
            string  Mensaje = string.Empty;
            try
            {
                MmsWin.Datos.Utilerias.Utilerias.InsertaRegistrosArebajar(dtDiferenciados, ParUsuario, porcentajeXaplicar, PrecioFinalXaplicar);

               //return Mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenDetalleXrebajar(string ParFchBon, string ParProveedor, string PartbEstilo, string ParUsuario)
        {
            DataTable dtDetalleXrebajar = null;
            try
            {
                dtDetalleXrebajar = MmsWin.Datos.Utilerias.Utilerias.ObtenDetalleXrebajar(ParFchBon, ParProveedor, PartbEstilo, ParUsuario);

                return dtDetalleXrebajar;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GuardaNota(string ParFchBon, string ParFchRev, string ParProveedor, string ParEstilo, string ParNotCal, string ParUsuario, string ParSubTot, string ParPorc, string varInd1, string varInd2, string TpoMov, string TpoCal, string RutaPdf)
        {
            DataTable GuardaNota = null;
            try
            {
                GuardaNota = MmsWin.Datos.Utilerias.Utilerias.GuardaNota(ParFchBon, ParFchRev, ParProveedor, ParEstilo, ParNotCal, ParUsuario, ParSubTot, ParPorc, varInd1, varInd2, TpoMov, TpoCal, RutaPdf);

                DataView dv = GuardaNota.DefaultView;
                GuardaNota = dv.ToTable();

                return GuardaNota;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GuardaNotaDiferenciada(string ParFchBon, string ParFchRev, string ParTipo, string ParTemporada, string ParTienda, string ParProveedor, string ParEstilo, string ParNotCal, string ParUsuario, string ParSubTot, string ParPorc, string varInd1, string varInd2, string TpoMov, string TpoCal, string RutaPdf)
        {
            DataTable GuardaNota = null;
            try
            {
                GuardaNota = MmsWin.Datos.Utilerias.Utilerias.GuardaNotaDiferenciada(ParFchBon, ParFchRev, ParTipo, ParTemporada, ParTienda, ParProveedor, ParEstilo, ParNotCal, ParUsuario, ParSubTot, ParPorc, varInd1, varInd2, TpoMov, TpoCal, RutaPdf);

                DataView dv = GuardaNota.DefaultView;
                GuardaNota = dv.ToTable();

                return GuardaNota;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable GuardaNotaAnt(string ParFchBon, string ParFchRev, string ParProveedor, string ParEstilo, string ParNotCal, string ParUsuario, string ParSubTot, string ParPorc, string varInd1, string varInd2, string TpoMov, string ParFechaRcb, string ParBodega, string ParOrden, string ParPzas, string TpoCal)
        {
            DataTable GuardaNota = null;
            try
            {
                GuardaNota = MmsWin.Datos.Utilerias.Utilerias.GuardaNotaAnt(ParFchBon, ParFchRev, ParProveedor, ParEstilo, ParNotCal, ParUsuario, ParSubTot, ParPorc, varInd1, varInd2, TpoMov, ParFechaRcb, ParBodega, ParOrden, ParPzas, TpoCal);

                DataView dv = GuardaNota.DefaultView;
                GuardaNota = dv.ToTable();

                return GuardaNota;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static Boolean fecha(string fecha)
        {
            try
            {
                DateTime.ParseExact(fecha, "dd/MM/yyyy", null);
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static string NombreDiaSem(string fchNom)
        {
            string NombreDiaSem;
            try
            {
                //  DateTime dateValue = new DateTime(2008, 6, 11);
                DateTime dateValue = new DateTime(Convert.ToInt16(fchNom.Substring(6, 4)), Convert.ToInt16(fchNom.Substring(3, 2)), Convert.ToInt16(fchNom.Substring(0, 2)));
                NombreDiaSem = (dateValue.ToString("dddd"));
                return NombreDiaSem;
            }
            catch
            {
                NombreDiaSem = "Fecha Incorrta";
                return NombreDiaSem;
            }
        }

        public DataTable ObtenEstilo(string ParPrv, string ParSty)
        {
            DataTable dtEstilo = null;
            try
            {
                dtEstilo = MmsWin.Datos.Utilerias.Utilerias.ObtenEstilo(ParPrv, ParSty);

                DataView dv = dtEstilo.DefaultView;
                dtEstilo = dv.ToTable();
                return dtEstilo;
            }

            catch { }
            finally { }

            return dtEstilo;
        }

        public DataTable ObtenPrcCst(string ParPrv, string ParSty)
        {
            DataTable dtPrcCst = null;
            try
            {
                dtPrcCst = MmsWin.Datos.Utilerias.Utilerias.ObtenPrcCst(ParPrv, ParSty);

                DataView dv = dtPrcCst.DefaultView;
                dtPrcCst = dv.ToTable();
                return dtPrcCst;
            }

            catch { }
            finally { }

            return dtPrcCst;
        }

        public DataTable ObtenRecibos(string ParPrv, string ParSty)
        {
            DataTable dtRecibos = null;
            try
            {
                dtRecibos = MmsWin.Datos.Utilerias.Utilerias.ObtenRecibos(ParPrv, ParSty);

                DataView dv = dtRecibos.DefaultView;
                dtRecibos = dv.ToTable();

                return dtRecibos;
            }

            catch { }
            finally { }

            return dtRecibos;
        }

        public static void EjecutaCorreos(string ParFchBon, string ParFchEfe, string ParUser)
        {
            try
            {
                MmsWin.Datos.Utilerias.Utilerias.EjecutaCorreos(ParFchBon, ParFchEfe, ParUser);
            }
            catch { }
            finally { }
        }

        public static void EjecutaCorreosDev(string ParFchBon, string ParFchEfe, string ParUser)
        {
            try
            {
                MmsWin.Datos.Utilerias.Utilerias.EjecutaCorreosDev(ParFchBon, ParFchEfe, ParUser);
            }
            catch { }
            finally { }
        }

        public static void EjecutaCorreosDiferenciados(string ParFchBon, string ParFchEfe, string ParUser)
        {
            try
            {
                // Identifica Estilos y Tiendas a enviar 
                MmsWin.Datos.Utilerias.Utilerias.EjecutaCorreosDiferenciados(ParFchBon, ParFchEfe, ParUser);
            }
            catch { }
            finally { }
        }

        public DataTable ObtenCorreos(string ParFchBon, string ParFchEfe, string ParMarca, string ParUser)
        {
            DataTable dtCorreos = null;
            try
            {
                dtCorreos = MmsWin.Datos.Utilerias.Utilerias.ObtenCorreos(ParFchBon, ParFchEfe, ParMarca, ParUser);

                DataView dv = dtCorreos.DefaultView;
                dtCorreos = dv.ToTable();

                return dtCorreos;
            }

            catch { }
            finally { }

            return dtCorreos;
        }

        public DataTable ObtenCorreosDev(string ParFchBon, string ParFchEfe, string ParMarca, string ParUser)
        {
            DataTable dtCorreos = null;
            try
            {
                dtCorreos = MmsWin.Datos.Utilerias.Utilerias.ObtenCorreosDev(ParFchBon, ParMarca, ParUser);

                DataView dv = dtCorreos.DefaultView;
                dtCorreos = dv.ToTable();

                return dtCorreos;
            }

            catch { }
            finally { }

            return dtCorreos;
        }

        public DataTable ObtenCorreosDiferenciados(string ParFchBon, string ParFchEfe, string ParMarca, string ParUser)
        {
            DataTable dtCorreos = null;
            try
            {
                dtCorreos = MmsWin.Datos.Utilerias.Utilerias.ObtenCorreosDiferenciados(ParFchBon, ParFchEfe, ParMarca, ParUser);

                DataView dv = dtCorreos.DefaultView;
                dtCorreos = dv.ToTable();

                return dtCorreos;
            }

            catch { }
            finally { }

            return dtCorreos;
        }

        public DataTable ObtenDestino(string ParMarcaDes)
        {
            DataTable dtDestino = null;
            try
            {
                dtDestino = MmsWin.Datos.Utilerias.Utilerias.ObtenDestino(ParMarcaDes);

                DataView dv = dtDestino.DefaultView;
                dtDestino = dv.ToTable();

                return dtDestino;
            }

            catch { }
            finally { }

            return dtDestino;
        }

        public DataTable ObtenDestinoDev(string ParMarcaDes)
        {
            DataTable dtDestino = null;
            try
            {
                dtDestino = MmsWin.Datos.Utilerias.Utilerias.ObtenDestino(ParMarcaDes);

                DataView dv = dtDestino.DefaultView;
                dtDestino = dv.ToTable();

                return dtDestino;
            }

            catch { }
            finally { }

            return dtDestino;
        }

        public DataTable ObtenDestinoDiferenciados(string ParMarcaDes)
        {
            DataTable dtDestino = null;
            try
            {
                dtDestino = MmsWin.Datos.Utilerias.Utilerias.ObtenDestinoDiferenciados(ParMarcaDes);
                // Limpia DataSet
                //dtDestino = null;

                //DataView dv = dtDestino.DefaultView;
                //dtDestino = dv.ToTable();

                return dtDestino;
            }

            catch { }
            finally { }

            return dtDestino;
        }

        public string ObtenMarcaConfiguracion1(string ParMarca)
        {
            string stFechaAbierta = null;
            try
            {
                stFechaAbierta = MmsWin.Datos.Utilerias.Utilerias.ObtenMarcaConfiguracion(ParMarca);
                return stFechaAbierta;
            }
            catch { }
            finally { }
            return stFechaAbierta;
        }

        public string ObtenVecesAreprogramarConfiguracion(string ParMarca)
        {
            string stVecesAreprogramar = null;
            try
            {
                stVecesAreprogramar = MmsWin.Datos.Utilerias.Utilerias.ObtenVecesAreprogramarConfiguracion(ParMarca);
                return stVecesAreprogramar;
            }
            catch { }
            finally { }
            return stVecesAreprogramar;
        }

        public string ObtenOnHandTransito1(string ParPrv, string ParSty, out string onHand, out string transito)
        {
            string stOnHandTransito = string.Empty;
            onHand = string.Empty;
            transito = string.Empty;
            try
            {
                stOnHandTransito = MmsWin.Datos.Utilerias.Utilerias.ObtenOnHandTransito(ParPrv, ParSty, out onHand, out transito);
                return stOnHandTransito;
            }
            catch { }
            finally { }
            return stOnHandTransito;
        }

        /// <summary>
        /// Recupera el parametro solicitado para aplicar las reglas del negocio
        /// </summary>
        /// <param name="Dato">Información requerida</param>
        /// <param name="Cadena">Marca de la que se requiere</param>
        /// <returns>Valor recuperado de MMSATOBJ.SAT177SMAR</returns>
        /// <remarks>Desarrollador: OCG | 15/12/2016</remarks>
        public static string ObtenerConfiguracion(Comun.Engine.Paremetrizacion Dato, Int32 Cadena)
        {
            return Datos.Utilerias.Utilerias.ObtenerConfiguracion(Dato, Cadena);
        }

        public bool GuardaNotaCredito(int marca, string noMarca, int noEvento, string ordenCompra, string temporada, string ParFchBon, string ParFchRev, string ParProveedor, string ParEstilo, string ParNotCal, string ParUsuario, string comprador)
        {

            try
            {
                return MmsWin.Datos.Utilerias.Utilerias.GuardaNotaCredito(marca, noMarca, noEvento, ordenCompra, temporada, ParFchBon, ParFchRev, ParProveedor, ParEstilo, ParNotCal, ParUsuario, comprador);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenInfoEstilos(int pProveedor, string pEstilo)
        {
            DataTable dtInfoEstilo = null;
            try
            {
                dtInfoEstilo = MmsWin.Datos.Utilerias.Utilerias.ObtenInfoEstilo(pProveedor, pEstilo);

                DataView dv = dtInfoEstilo.DefaultView;
                dtInfoEstilo = dv.ToTable();

                return dtInfoEstilo;
            }

            catch { }
            finally { }

            return dtInfoEstilo;
        }

        public DataTable ObtenFechasRebajas(int pProveedor, string pEstilo)
        {
            DataTable dtInfoFechasRebajas = null;
            try
            {
                dtInfoFechasRebajas = MmsWin.Datos.Utilerias.Utilerias.ObtenFechasRebajas(pProveedor, pEstilo);

                DataView dv = dtInfoFechasRebajas.DefaultView;
                dtInfoFechasRebajas = dv.ToTable();

                return dtInfoFechasRebajas;
            }

            catch { }
            finally { }

            return dtInfoFechasRebajas;
        }

        public DataTable ObtenPosDistro(int pMarca, int pProveedor, string pEstilo)
        {
            DataTable dtPosDistro = null;
            try
            {
                dtPosDistro = MmsWin.Datos.Utilerias.Utilerias.ObtenPosDistro(pMarca, pProveedor, pEstilo);

                return dtPosDistro;
            }

            catch { }
            finally { }

            return dtPosDistro;
        }
    }
}
