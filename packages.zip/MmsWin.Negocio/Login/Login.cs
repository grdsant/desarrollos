﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Login;

namespace MmsWin.Negocio.Login
{
    public class Login
    {
        internal static Login LoginDet;

        public static Login GetInstance()
        {
            if (LoginDet == null)
                LoginDet = new Login();
            return LoginDet;
        }

        public DataTable ObtenLogin1(string ParUsuario, string ParPassword)
        {
            DataTable dtLogin1 = null;
            try
            {
                dtLogin1 = MmsWin.Datos.Login.Login.ObtenLogin(ParUsuario, ParPassword);

                if (dtLogin1 != null)
                {
                    DataView dv = dtLogin1.DefaultView;
                    dtLogin1 = dv.ToTable();
                }
                return dtLogin1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Valida la versión activa del convenio registrada en la base de datos
        /// Desarrollador: Omar Cervantes
        /// </summary>
        /// <returns>Datatable con los datos</returns>
        public Boolean ValidaVersion()
        {
            DataTable dt = null;
            dt = MmsWin.Datos.Login.Login.ValidaVersion();

            foreach (DataRow row in dt.Rows)
            {
                if (row["ID"].ToString() == "1" && row["FECHAVERS"].ToString() == "170524" && row["NOVERSION"].ToString() == "5")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            return false;
        }

    }
}
