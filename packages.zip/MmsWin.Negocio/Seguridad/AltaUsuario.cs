﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Login;

namespace MmsWin.Negocio.Seguridad
{
    public class AltaUsuario
    {
        internal static AltaUsuario AltaUsuarioDet;

        public static AltaUsuario GetInstance()
        {
            if (AltaUsuarioDet == null)
                AltaUsuarioDet = new AltaUsuario();
            return AltaUsuarioDet;
        }

        public DataTable ObtenUsuario1(string Usuario)
        {
            DataTable dtUsuario1 = null;
            try
            {
                dtUsuario1 = MmsWin.Datos.Seguridad.AltaUsuario.ObtenUsuario(Usuario);

                if (dtUsuario1 != null)
                {
                    DataView dv = dtUsuario1.DefaultView;
                    dtUsuario1 = dv.ToTable();
                }
                return dtUsuario1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable WriteUsuario1(string Usuario, string Nombre, string Password, string nivel, string Marca, string Descripcion, string Comprador, string Correo, string Perfil, string Fecha, string Hora, string Estatus)
        {
            DataTable dtUsuario1 = null;
            try
            {
                dtUsuario1 = MmsWin.Datos.Seguridad.AltaUsuario.WriteUsuario(Usuario, Nombre, Password, nivel, Marca, Descripcion, Comprador, Correo, Perfil, Fecha, Hora, Estatus);

                if (dtUsuario1 != null)
                {
                    DataView dv = dtUsuario1.DefaultView;
                    dtUsuario1 = dv.ToTable();
                }
                return dtUsuario1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
