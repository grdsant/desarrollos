﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Login;

namespace MmsWin.Negocio.Seguridad
{
    public class AltaPerfil
    {
        internal static AltaPerfil AltaPerfilDet;

        public static AltaPerfil GetInstance()
        {
            if (AltaPerfilDet == null)
                AltaPerfilDet = new AltaPerfil();
            return AltaPerfilDet;
        }

        public DataTable ObtenPerfil1(string Perfil)
        {
            DataTable dtPerfil1 = null;
            try
            {
                dtPerfil1 = MmsWin.Datos.Seguridad.AltaUsuario.ObtenUsuario(Perfil);

                if (dtPerfil1 != null)
                {
                    DataView dv = dtPerfil1.DefaultView;
                    dtPerfil1 = dv.ToTable();
                }
                return dtPerfil1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable WritePerfil1(string Perfil, string Descripcion, string Fecha, string Hora, string Estatus)
        {
            DataTable dtPerfil1 = null;
            try
            {
                dtPerfil1 = MmsWin.Datos.Seguridad.AltaPerfil.WritePerfil(Perfil, Descripcion, Fecha, Hora, Estatus);

                if (dtPerfil1 != null)
                {
                    DataView dv = dtPerfil1.DefaultView;
                    dtPerfil1 = dv.ToTable();
                }
                return dtPerfil1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
