﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.Seguridad
{
    public class PerfilDetalle
    {
        internal static PerfilDetalle PerfilDetalleDet;
        public static PerfilDetalle GetInstance()
        {
            if (PerfilDetalleDet == null)
                PerfilDetalleDet = new PerfilDetalle();
            return PerfilDetalleDet;
        }

        public DataTable ObtenPerfilDetalle1(string perfil, string aplicacion, string modulo, string control)
        {
            DataTable dtPerfilDetalle1 = null;
            try
            {
                dtPerfilDetalle1 = MmsWin.Datos.Seguridad.PerfilDetalle.ObtenPerfilDetalle(perfil, aplicacion, modulo, control);

                DataView dv = dtPerfilDetalle1.DefaultView;
                dtPerfilDetalle1 = dv.ToTable();

                return dtPerfilDetalle1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void WritePerfilDetalle1(string Perfil, string Aplicacion, string Modulo, string Control, string Fecha, string Hora, string Estatus)
        {
            try
            {
                MmsWin.Datos.Seguridad.PerfilDetalle.WritePerfilDetalle(Perfil, Aplicacion, Modulo, Control, Fecha, Hora, Estatus);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdatePerfilDetalle(DataTable dtPerfilDetalle)
        {
            try
            {
                MmsWin.Datos.Seguridad.PerfilDetalle.UpdatePerfilesDetalle(dtPerfilDetalle);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EliminaPerfilDetalle(string Perfil, string Aplicacion, string Modulo, string Control)
        {
            MmsWin.Datos.Seguridad.PerfilDetalle.EliminaPerfilDetalle(Perfil, Aplicacion, Modulo, Control);
        }

    }
}
