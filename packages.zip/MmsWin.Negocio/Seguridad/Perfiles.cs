﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.Seguridad
{
    public class Perfiles
    {
        internal static Perfiles PerfilesDet;
        public static Perfiles GetInstance()
        {
            if (PerfilesDet == null)
                PerfilesDet = new Perfiles();
            return PerfilesDet;
        }

        public DataTable ObtenPerfiles1(string perfil, string descripcion)
        {
            DataTable dtPerfiles1 = null;
            try
            {
                dtPerfiles1 = MmsWin.Datos.Seguridad.Perfiles.ObtenPerfiles(perfil, descripcion);

                DataView dv = dtPerfiles1.DefaultView;
                dtPerfiles1 = dv.ToTable();

                return dtPerfiles1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdatePerfil(DataTable dtPerfil)
        {
            try
            {
                dtPerfil = MmsWin.Datos.Seguridad.Perfiles.UpdatePerfiles(dtPerfil);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EliminaPerfil(string PerfilB)
        {
            MmsWin.Datos.Seguridad.Perfiles.EliminaPerfil(PerfilB);
        }
    }
}
