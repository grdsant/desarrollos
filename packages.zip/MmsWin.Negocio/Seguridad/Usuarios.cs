﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.Seguridad
{
    public class Usuarios
    {
        internal static Usuarios UsuarioDet;
        public static Usuarios GetInstance()
        {
            if (UsuarioDet == null)
                UsuarioDet = new Usuarios();
            return UsuarioDet;
        }

        public DataTable ObtenUsuarios1(string usuario, string nombre, string password, string nivel, string marca, string descripcion, string comprador, string correo, string perfil)
        {
            DataTable dtUsuarios1 = null;
            try
            {
                dtUsuarios1 = MmsWin.Datos.Seguridad.Usuarios.ObtenUsuarios(usuario, nombre, password, nivel, marca, descripcion, comprador, correo, perfil);

                DataView dv = dtUsuarios1.DefaultView;
                dtUsuarios1 = dv.ToTable();

                return dtUsuarios1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateUsuario(DataTable dtUsuario)
        {
            try
            {
                dtUsuario = MmsWin.Datos.Seguridad.Usuarios.UpdateUsuarios(dtUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EliminaUsuario(string UsuarioB, string PerfilB)
        {
            MmsWin.Datos.Seguridad.Usuarios.EliminaUsuario(UsuarioB, PerfilB);
        }
    }
}
