﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.Seguridad
{
    public class Aplicaciones
    {
        internal static Aplicaciones AplicacionesDet;
        public static Aplicaciones GetInstance()
        {
            if (AplicacionesDet == null)
                AplicacionesDet = new Aplicaciones();
            return AplicacionesDet;
        }

        public DataTable ObtenAplicaciones1()
        {
            DataTable dtAplicaciones1 = null;
            try
            {
                dtAplicaciones1 = MmsWin.Datos.Seguridad.Aplicaciones.ObtenAplicaciones();

                DataView dv = dtAplicaciones1.DefaultView;
                dtAplicaciones1 = dv.ToTable();

                return dtAplicaciones1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
