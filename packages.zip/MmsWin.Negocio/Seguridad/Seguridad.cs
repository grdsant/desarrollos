﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.Seguridad
{
    public class Seguridad
    {
        internal static Seguridad SeguridadDet;
        public static Seguridad GetInstance()
        {
            if (SeguridadDet == null)
                SeguridadDet = new Seguridad();
            return SeguridadDet;
        }

        public DataTable ObtenSeguridad1(string Aplicacion, string Modulo, string Usuario, Boolean NuevaSeguridad = false)
        {
            DataTable dtSeguridad1 = null;
            try
            {
                dtSeguridad1 = MmsWin.Datos.Seguridad.Seguridad.ObtenSeguridad(Aplicacion, Modulo, Usuario, NuevaSeguridad);

                DataView dv = dtSeguridad1.DefaultView;
                dtSeguridad1 = dv.ToTable();

                return dtSeguridad1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
