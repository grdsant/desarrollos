﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.Seguridad
{
    public class Modulos
    {
        internal static Modulos ModulosDet;
        public static Modulos GetInstance()
        {
            if (ModulosDet == null)
                ModulosDet = new Modulos();
            return ModulosDet;
        }

        public DataTable ObtenModulos1()
        {
            DataTable dtModulos1 = null;
            try
            {
                dtModulos1 = MmsWin.Datos.Seguridad.Modulos.ObtenModulos();

                DataView dv = dtModulos1.DefaultView;
                dtModulos1 = dv.ToTable();

                return dtModulos1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
