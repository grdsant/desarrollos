﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.Seguridad
{
    public class Controles
    {
        internal static Controles ControlesDet;
        public static Controles GetInstance()
        {
            if (ControlesDet == null)
                ControlesDet = new Controles();
            return ControlesDet;
        }

        public DataTable ObtenControles1(string control, string descripcion, string aplicacion, string modulo, string tipo)
        {
            DataTable dtControles1 = null;
            try
            {
                dtControles1 = MmsWin.Datos.Seguridad.Controles.ObtenControles(control, descripcion, aplicacion, modulo, tipo);

                DataView dv = dtControles1.DefaultView;
                dtControles1 = dv.ToTable();

                return dtControles1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void GrabaControles(DataTable dtControles)
        {
          try
            {
           dtControles = MmsWin.Datos.Seguridad.Controles.GrabaControles(dtControles);
            }
                        catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
