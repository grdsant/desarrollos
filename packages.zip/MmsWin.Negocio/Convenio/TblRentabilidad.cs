﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;

namespace MmsWin.Negocio.Convenio
{
    public class TblRentabilidad
    {
        internal static TblRentabilidad TblRentabilidadDet;
        public static TblRentabilidad GetInstance()
        {
            if (TblRentabilidadDet == null)
                TblRentabilidadDet = new TblRentabilidad();
            return TblRentabilidadDet;
        }

        public DataTable ObtenTblRentabilidadDet1(string tblTabla, string tblMarca)
        {
            DataTable dtTblRentabilidadDet1 = null;
            try
            {
                dtTblRentabilidadDet1 = MmsWin.Datos.Convenio.TblRentabilidad.ObtenTblRentabilidad(tblTabla, tblMarca);

                DataView dv = dtTblRentabilidadDet1.DefaultView;
                dtTblRentabilidadDet1 = dv.ToTable();

                return dtTblRentabilidadDet1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateTblRentabilidad(DataTable dtTblRentabilidad)
        {
            try
            {
                dtTblRentabilidad = MmsWin.Datos.Convenio.TblRentabilidad.UpdateTblRentabilidad(dtTblRentabilidad);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EliminaTblRentabilidad(string tablaB, string marcaB, string SecuenciaB)
        {
            MmsWin.Datos.Convenio.TblRentabilidad.EliminaTblRentabilidad(tablaB, marcaB, SecuenciaB);
        }

    }
}
