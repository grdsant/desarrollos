﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Convenio;

namespace MmsWin.Negocio.Convenio
{
    public class Convenio
    {
        internal static Convenio ConvenioDet;

        public static Convenio GetInstance()
        {
            if (ConvenioDet == null)
                ConvenioDet = new Convenio();
            return ConvenioDet;
        }

        public DataTable ObtenConvenio1(string marca, string comprador, String FchDe, String FchHas, string ParProveedor, string PartbNombre, string PartbEstilo, string ParDescripcion, string temporada, string origen, string conRpg, string sinRpg, string ParUsuario, Boolean simulador, string conExcep)
        {
            DataTable dtConvenio1 = null;

            try
            {
                dtConvenio1 = MmsWin.Datos.Convenio.Convenio.ObtenConvenio(marca, comprador, FchDe, FchHas, ParProveedor, PartbNombre, PartbEstilo, ParDescripcion, temporada, origen, conRpg, sinRpg, ParUsuario, simulador, conExcep);
                DataView dv = dtConvenio1.DefaultView;
                dtConvenio1 = dv.ToTable();
            }
            catch { }
            finally { }

            return dtConvenio1;
        }

        public static DataTable ObtenFechasPrecalificacion()
        {

            return Datos.Convenio.Convenio.ObtenFechasPrecalificacion();
        }

        public void UpdateConvenio(DataTable dtConvenio)
        {
            try
            {
                MmsWin.Datos.Convenio.Convenio.UpdateConvenio(dtConvenio);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<String> ObtenCompradores()
        {
            List<String> lista = new List<String>();
            try
            {
                lista = MmsWin.Datos.Convenio.Convenio.ObtenCompradores();
                return lista;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateCheckBox(DataTable dtCheckBox, string ParUser, string fecha, string hora)
        {
            try
            {
                MmsWin.Datos.Convenio.Convenio.UpdateCheckBox(dtCheckBox, ParUser, fecha, hora);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateCheckBox2(DataTable dtCheckBox, string ParUser, string fecha, string hora)
        {
            try
            {
                MmsWin.Datos.Convenio.Convenio.UpdateCheckBox2(dtCheckBox, ParUser, fecha, hora);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EjecutaSimulador1(string ParFchIni, string ParFchFin, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Convenio.Convenio.EjecutaSimulador(ParFchIni, ParFchFin, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        
        public void EjecutaCalificaciones(string ParFchIni, string ParFchFin, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Convenio.Convenio.EjecutaCalificacion(ParFchIni, ParFchFin, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenRutaPDF(String ParFchCal, String ParPrv, String ParSty, String ParNota)
        {
            DataTable dtRutaPDF = null;
            try
            {
                dtRutaPDF = MmsWin.Datos.Convenio.Convenio.ObtenRutaPDF(ParFchCal, ParPrv, ParSty, ParNota);

                DataView dv = dtRutaPDF.DefaultView;
                dtRutaPDF = dv.ToTable();
            }
            catch { }
            finally { }

            return dtRutaPDF;
        }
        public DataTable ObtenTemporada(string marca, string comprador, string temporada, string origen)
        {
            DataTable dtConvenio1 = null;

            try
            {
                dtConvenio1 = MmsWin.Datos.Convenio.Convenio.ObtenTemporada(marca, comprador, temporada, origen);
                DataView dv = dtConvenio1.DefaultView;
                dtConvenio1 = dv.ToTable();
            }
            catch { }
            finally { }

            return dtConvenio1;
        }

        public int cantidadNoCalificacion(string estilo, string proveedor, string ordencom, string marca, string tempo)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.cantidadNoCalificacion(estilo, proveedor, ordencom, marca, tempo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool insertNuevoCambioCal(string estilo, string proveedor, string ordencom, string marca, string nvaCalificacion, string estatus, string NoEventos, string fecharevic, string Usuario, string temp, string tipoReporte, decimal costoNvo, decimal difNuevo, string motivo, string calDirecta)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.insertNuevoCambioCal(estilo, proveedor, ordencom, marca, nvaCalificacion, estatus, NoEventos, fecharevic, Usuario, temp, tipoReporte, costoNvo, difNuevo, motivo, calDirecta);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable cambioCalEstatusTranslado()
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.cambioCalEstatusTranslado();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string ObtieneFolio()
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.ObtieneFolio();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static int nuevoFolioCamCal(DataTable dtProveEstilo)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.nuevoFolioCamCal(dtProveEstilo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable CargaListaFolios(string Folio = "P")
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.CargaListaFolios(Folio);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable CargaDetalleFolio(string Folio)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.CargaDetalleFolio(Folio);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool AutorizaFolio(string folio, string estatus, DataTable autorizado)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.AutorizaFolio(folio, estatus, autorizado);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool EliminaNoAutorizados(string folio, string fechaRev, string estilo, string proveedor, string ordencompra, string marca, string temp)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.EliminaNoAutorizados(folio, fechaRev, estilo, proveedor, ordencompra, marca, temp);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool cambioCalAutorizados(string folio, string estilo, string proveedor, string ordencompra, string marca, decimal nuevaCalificacion)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.cambioCalAutorizados(folio, estilo, proveedor, ordencompra, marca, nuevaCalificacion);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public decimal obtenMaximoCalificacion(string marca)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.obtenMaximoCalificacion(marca);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public decimal obtenBoXDevo(string marca)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.obtenBoXDevo(marca);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string obtenPenalizacionBon(string marca)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.obtenPenalizacionBon(marca);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool insertNuevaDevolucionBon(string estilo, string proveedor, string ordencom, string marca, string penalizacion, string montoPena, string motivo, string estatus, string NoEventos, string fecharevic, string Usuario, string temp, string calDirecta)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.insertNuevaDevolucionBon(estilo, proveedor, ordencom, marca, penalizacion, montoPena, motivo, estatus, NoEventos, fecharevic, Usuario, temp, calDirecta);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool insertNuevaBonXDev(string estilo, string proveedor, string ordencom, string marca, string porcentageNvo, string costoNuevo, string motivo, string estatus, string NoEventos, string fecharevic, string Usuario, string temp, string calDirecta)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.insertNuevaBonXDev(estilo, proveedor, ordencom, marca, porcentageNvo, costoNuevo, motivo, estatus, NoEventos, fecharevic, Usuario, temp, calDirecta);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable cambioDelEstatusTranslado(string idComprador, string Marca)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.cambioDelEstatusTranslado(idComprador, Marca);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static int nuevoFolioCamDevBon(DataTable dtProveEstilo)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.nuevoFolioCamDevBon(dtProveEstilo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string ObtieneFolioDevBon()
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.ObtieneFolioDevBon();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable CargaListaFoliosDevBon(string idComprador, string Folio = "P")
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.CargaListaFoliosDevBon(idComprador, Folio);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable CargaDetalleFolioDevBon(string Folio)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.CargaDetalleFolioDevBon(Folio);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool EliminaNoAutorizadosDebBon(string folio, string fechaRev, string estilo, string proveedor, string ordencompra, string marca, string temp, string tipoOp)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.EliminaNoAutorizadosDebBon(folio, fechaRev, estilo, proveedor, ordencompra, marca, temp, tipoOp);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool AutorizaFolioDevBon(string folio, string estatus, DataTable autorizado, string usuario)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.AutorizaFolioDevBon(folio, estatus, autorizado, usuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int cantidadNoDevBoni(string estilo, string proveedor, string ordencom, string marca, string tempo)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.cantidadNoDevBoni(estilo, proveedor, ordencom, marca, tempo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int cantidadNoBoniDev(string estilo, string proveedor, string ordencom, string marca, string tempo)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.cantidadNoBoniDev(estilo, proveedor, ordencom, marca, tempo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int cantidadNoCredito(string estilo, string proveedor, string ordencom, string marca, string tempo)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.cantidadNoCredito(estilo, proveedor, ordencom, marca, tempo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable notaCrestoEstatusTraslado()
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.notaCrestoEstatusTraslado();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static string ObtieneFolioNotaCredito()
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.ObtieneFolioNotaCredito();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static int estatusTempNotasCredito(DataTable dtProveEstilo)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.estatusTempNotasCredito(dtProveEstilo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable cargaListaFoliosNotaCre(string Folio = "P")
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.cargaListaFoliosNotaCre(Folio);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable CargaDetalleFolioNotaCredito(string Folio)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.CargaDetalleFolioNotaCredito(Folio);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool EliminaNoAutorizadosNotaCredito(string folio, string fechaBon, string fechaRev, string estilo, string proveedor, string ordencompra, string marca, string temp, string comprador)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.EliminaNoAutorizadosNotaCredito(folio, fechaBon, fechaRev, estilo, proveedor, ordencompra, marca, temp, comprador);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool AutorizaFolioNotaCredito(string folio, string estatus, DataTable autorizado)
        {
            try
            {
                return MmsWin.Datos.Convenio.Convenio.AutorizaFolioNotaCredito(folio, estatus, autorizado);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #region " Proceso de bonificación parcial "

        /// <summary>
        /// Inserta o actualiza la información del estilo que requiere de una bonificación anticipada
        /// </summary>
        /// <param name="ent">Entidad Entidades.BonificacionParcial (Tabla) </param>
        /// <returns>True, en caso correcto o, False en lo contrario</returns>
        public static bool BonificacionParcial_iu(Entidades.BonificacionParcial ent)
        {
            return Datos.Convenio.Convenio.BonificacionParcial_iu(ent);
        }

        public static bool BonificacionParcial_u(int OrdenCompra, int folio, string Usuario)
        {
            return Datos.Convenio.Convenio.BonificacionParcial_u(OrdenCompra, folio, Usuario);
        }

        public static DataTable CargaListaFoliosBonAnt(string Folio = "", string Estatus = "P", string Comprador = "")
        {
            return Datos.Convenio.Convenio.CargaListaFoliosBonAnt(Folio, Estatus, Comprador);
        }

        public static bool BonificacionParcial_uf(int folio, string Usuario)
        {
            return Datos.Convenio.Convenio.BonificacionParcial_uf(folio, Usuario);
        }


        public static bool BonificacionParcial_desautorizar(int OrdenCompra, string Usuario)
        {
            return Datos.Convenio.Convenio.BonificacionParcial_desautorizar(OrdenCompra, Usuario);
        }


        public static DataTable CargaLSTBonPar(int OrdenCompra)
        {
            return Datos.Convenio.Convenio.CargaLSTBonPar(OrdenCompra);
        }

        public static bool BonificacionParcial_actualizaNotCre(int OrdenCompra, string Usuario)
        {
            return Datos.Convenio.Convenio.BonificacionParcial_actualizaNotCre(OrdenCompra, Usuario);
        }

        public static DataTable CargaBonificacionParcial(string Busca = "", int Origen = 1, byte Vista = 1, string Comprador = "")
        {

            return Datos.Convenio.Convenio.CargaBonificacionParcial(Busca, Origen, Vista, Comprador);
        }

        #endregion

        /// <summary>
        /// Identifica si el Convenio trabaja en modalidad de FULL PATEO
        /// </summary>
        /// <param name="marca"></param>
        /// <returns>True, si esta marcadao como A</returns>
        public static bool banderaFullPateo(int marca)
        {
            return Datos.Convenio.Convenio.banderaFullPateo(marca);
        }
    }
}
