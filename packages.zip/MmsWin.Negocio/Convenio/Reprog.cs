﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.Convenio
{
   public class Reprog
    {
       internal static Reprog ReprogDet;
       public static Reprog GetInstance()
        {
            if (ReprogDet == null)
                ReprogDet = new Reprog();
            return ReprogDet;
        }

       public DataTable ObtenReprog1(string ParProv, string ParSty, string ParOrden, string ParMarca, string ParComprador, string ParCompDesc)
        {
            DataTable dtReprog1 = null;
            try
            {
                dtReprog1 = MmsWin.Datos.Convenio.Reprog.ObtenReprog(ParProv, ParSty, ParOrden, ParMarca, ParComprador, ParCompDesc);

                DataView dv = dtReprog1.DefaultView;
                dtReprog1 = dv.ToTable();

                return dtReprog1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

       public DataTable ObtenReprog1F14(string ParProv, string ParSty, string ParFchRev)
       {
           DataTable dtReprog1 = null;
           try
           {
               dtReprog1 = MmsWin.Datos.Convenio.Reprog.ObtenReprogF14(ParProv, ParSty, ParFchRev);

               DataView dv = dtReprog1.DefaultView;
               dtReprog1 = dv.ToTable();

               return dtReprog1;
           }
           catch (Exception ex)
           {
               throw ex;
           }
       }

       public void WriteReprog1(string PrvRpr, string NomRpr, string StyRpr, string DesRpr, string FchRevRpr, string FchRprRpr, string CompDesc, string ObsRpr, string MarcaRpr, string CompradorRpr, string FechaRpr, string HoraRpr, string UsrRpr, string orden, string MotivoID = "", string Estatus = "")
        {
            try
            {
                MmsWin.Datos.Convenio.Reprog.WriteReprog(PrvRpr, NomRpr, StyRpr, DesRpr, FchRevRpr, FchRprRpr, CompDesc, ObsRpr, MarcaRpr, CompradorRpr, FechaRpr, HoraRpr, UsrRpr, orden, MotivoID, Estatus);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static bool LogReprogramacion(int NoProveedor, string NoStilo, int FechaRev, int OrdenCompra, string Usuario)
        {
            return Datos.Convenio.Reprog.LogReprogramacion(NoProveedor, NoStilo, FechaRev, OrdenCompra, Usuario);

        }
    }
}
