﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Convenio
{
    public class OrdenesCompra
    {
        /// <summary>
        /// Obtener las reprogramaciones preautorizadas para que se liguen a un formato.
        /// Agrega la columna de "Seleccion" al datatable 
        /// </summary>
        /// <returns>DataTable con los datos</returns>
        /// <remarks>PROGRMADOR: OCG 029/12/2016</remarks>
        public static DataTable CargaOrdenesCompra(string Busca = "", int Origen = 1, byte Vista = 1, string Comprador = "")
        {
            return Datos.Convenio.OrdenesCompra.CargaOrdenesCompra(Busca, Origen, Vista, Comprador);
        }


    }
}
