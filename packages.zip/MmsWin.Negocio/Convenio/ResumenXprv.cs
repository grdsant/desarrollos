﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;

namespace MmsWin.Negocio.Convenio
{
    public class ResumenXprv
    {
        internal static ResumenXprv ResumenXprvDet;
        public static ResumenXprv GetInstance()
        {
            if (ResumenXprvDet == null)
                ResumenXprvDet = new ResumenXprv();
            return ResumenXprvDet;
        }

        public DataTable ObtenResumenXprvDet1(string marca, string comprador, string fechaRev, string usuario)
        {
            DataTable dtResumenXprvDet1 = null;
            try
            {
                dtResumenXprvDet1 = MmsWin.Datos.Convenio.ResumenXprv.ObtenResumenXprv(marca, comprador, fechaRev, usuario);

                DataView dv = dtResumenXprvDet1.DefaultView;
                dtResumenXprvDet1 = dv.ToTable();

                return dtResumenXprvDet1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
