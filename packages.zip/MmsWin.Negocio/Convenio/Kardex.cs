﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;

namespace MmsWin.Negocio.Convenio
{
    public class Kardex
    {
        internal static Kardex KardexDet;
        public static Kardex GetInstance()
        {
            if (KardexDet == null)
                KardexDet = new Kardex();
            return KardexDet;
        }

        public DataTable ObtenKardex1(string proveedor, string estilo, string usuario)
        {
            DataTable dtKardex1 = null;
            try
            {
                dtKardex1 = MmsWin.Datos.Convenio.Kardex.ObtenKardex(proveedor, estilo, usuario);

                DataView dv = dtKardex1.DefaultView;
                dtKardex1 = dv.ToTable();

                return dtKardex1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenKardex1PorSemana(string proveedor, string estilo, string anio, string semana, string usuario)
        {
            DataTable dtKardex1 = null;
            try
            {
                dtKardex1 = MmsWin.Datos.Convenio.Kardex.ObtenKardexPorSemana(proveedor, estilo, anio, semana, usuario);

                DataView dv = dtKardex1.DefaultView;
                dtKardex1 = dv.ToTable();

                return dtKardex1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenKardex1PorDia(string proveedor, string estilo, string anio, string semana, string tipo, string usuario)
        {
            DataTable dtKardex1 = null;
            try
            {
                dtKardex1 = MmsWin.Datos.Convenio.Kardex.ObtenKardexPorDia( proveedor,  estilo,  anio,  semana,  tipo, usuario);

                DataView dv = dtKardex1.DefaultView;
                dtKardex1 = dv.ToTable();

                return dtKardex1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenKardex1PorSku(string proveedor, string estilo, string anio, string semana, string tipo, string fechaTipo, string usuario)
        {
            DataTable dtKardex1 = null;
            try
            {
                dtKardex1 = MmsWin.Datos.Convenio.Kardex.ObtenKardexPorSku( proveedor,  estilo,  anio,  semana, tipo,  fechaTipo , usuario);

                DataView dv = dtKardex1.DefaultView;
                dtKardex1 = dv.ToTable();

                return dtKardex1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void ActualizaKardex1(string proveedor, string estilo, string resp)
        {
            try
            {
                MmsWin.Datos.Convenio.Kardex.ActualizaKardex(proveedor, estilo, resp);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
