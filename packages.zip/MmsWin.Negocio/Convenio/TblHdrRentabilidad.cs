﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;

namespace MmsWin.Negocio.Convenio
{
    public class TblHdrRentabilidad
    {
        internal static TblHdrRentabilidad TblHdrRentabilidadDet;
        public static TblHdrRentabilidad GetInstance()
        {
            if (TblHdrRentabilidadDet == null)
                TblHdrRentabilidadDet = new TblHdrRentabilidad();
            return TblHdrRentabilidadDet;
        }

        public DataTable ObtenTblHdrRentabilidad1()
        {
            DataTable dtTblHdrRentabilidad1 = null;
            try
            {
                dtTblHdrRentabilidad1 = MmsWin.Datos.Convenio.TblHdrRentabilidad.ObtenTblHdrRentabilidad();

                DataView dv = dtTblHdrRentabilidad1.DefaultView;
                dtTblHdrRentabilidad1 = dv.ToTable();

                return dtTblHdrRentabilidad1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void WriteTblHdrRentabilidad1(string marca, string tabla, string descripcion, string fechaInicial, string fechaFinal, string usuario, string fechaReg, string horaReg, string estatus)
        {
            try
            {
                MmsWin.Datos.Convenio.TblHdrRentabilidad.WriteTblHdrRentabilidad(marca, tabla, descripcion, fechaInicial, fechaFinal, usuario, fechaReg, horaReg, estatus);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateTblHdrRentabilidad(DataTable dtTblHdrRentabilidad)
        {
            try
            {
               MmsWin.Datos.Convenio.TblHdrRentabilidad.UpdateTblHdrRentabilidad(dtTblHdrRentabilidad);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EliminaTblHdrRentabilidad(string marcaB, string tablaB)
        {
          MmsWin.Datos.Convenio.TblHdrRentabilidad.EliminaTblHdrRentabilidad(marcaB, tablaB);
        }
    }
}
