﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;

namespace MmsWin.Negocio.Convenio
{
    public class ResumenXcal
    {
        internal static ResumenXcal ResumenXcalDet;
        public static ResumenXcal GetInstance()
        {
            if (ResumenXcalDet == null)
                ResumenXcalDet = new ResumenXcal();
            return ResumenXcalDet;
        }

        public DataTable ObtenResumenXcalDet1(string marca, string comprador, string fechaRev, string usuario)
        {
            DataTable dtResumenXcal1 = null;
            try
            {
                dtResumenXcal1 = MmsWin.Datos.Convenio.ResumenXcal.ObtenResumenXcal(marca, comprador, fechaRev, usuario);

                DataView dv = dtResumenXcal1.DefaultView;
                dtResumenXcal1 = dv.ToTable();

                return dtResumenXcal1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
