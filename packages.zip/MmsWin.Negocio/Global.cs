﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio
{
    public class Global
    {

        public static bool SAT177SORD_insert(Entidades.SAT177SORD iClass)
        {
            return Datos.Global.SAT177SORD_insert(iClass);
        }

        public static bool SAT177SORD_delete(Entidades.SAT177SORD iClass)
        {
            return Datos.Global.SAT177SORD_delete(iClass);
        }

    }
}
