﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.Bonificaciones
{
    public class Doctos
    {
        internal static Doctos DoctosDet;
        public static Doctos GetInstance()
        {
            if (DoctosDet == null)
                DoctosDet = new Doctos();
            return DoctosDet;
        }

        public DataTable ObtenDoctos1(string marca, string comprador, string FchDe, string FchHas, string ParProveedor, string PartbNombre, string PartbEstilo, string ParDescripcion)
        {
            DataTable dtDoctos1 = null;
            try
            {
                dtDoctos1 = MmsWin.Datos.Bonificaciones.Doctos.ObtenDoctos( marca,  comprador,  FchDe,  FchHas,  ParProveedor,  PartbNombre,  PartbEstilo,  ParDescripcion);

                DataView dv = dtDoctos1.DefaultView;
                dtDoctos1 = dv.ToTable();

                return dtDoctos1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void validacion(string Nota)
        {
            if (Nota == " ")
            {

            }
        }

        public void EliminaDocumentos(string ParFchBon, string ParFchRev, string ParProveedor, string ParEstilo, string ParNota)
        {
            MmsWin.Datos.Bonificaciones.Doctos.EliminaDocumento(ParFchBon, ParFchRev, ParProveedor, ParEstilo, ParNota);
        }

        public void EjecutaCargaPDF(string ParFchBon, string ParFchCal, string ParNota, string ParPrv, string ParSty, string ParDest, string ParTpo, string ParUser)
        {
            MmsWin.Datos.Bonificaciones.Doctos.EjecutaCargaPDF(ParFchBon, ParFchCal, ParNota, ParPrv, ParSty, ParDest, ParTpo, ParUser);
        }
    }
}
