﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.Bonificaciones
{
    public class Calificaciones
    {
        internal static Calificaciones CalificacionesDet;
        public static Calificaciones GetInstance()
        {
            if (CalificacionesDet == null)
                CalificacionesDet = new Calificaciones();
            return CalificacionesDet;
        }

        public DataTable ObtenCalificaciones1(String marca, String comprador, String FchDe, String FchHas, String ParPendiente, string ParProveedor, string PartbNombre, string PartbEstilo, string ParDescripcion, String User )
        {
            DataTable dtCalificaciones1 = null;
            try
            {
                dtCalificaciones1 = MmsWin.Datos.Bonificaciones.Calificaciones.ObtenCalificaciones(marca, comprador, FchDe, FchHas, ParPendiente, ParProveedor, PartbNombre, PartbEstilo, ParDescripcion, User);

                DataView dv = dtCalificaciones1.DefaultView;
                dtCalificaciones1 = dv.ToTable();

                return dtCalificaciones1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
