﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using MmsWin.Datos.Bonificaciones;

namespace MmsWin.Negocio.Bonificaciones
{
    public class Bonificaciones
    {
        internal static Bonificaciones BonificaDet;
        public static Bonificaciones GetInstance()
        {
            if (BonificaDet == null)
                BonificaDet = new Bonificaciones();
            return BonificaDet;
        }

        public DataTable ObtenBonifica1(String marca, String comprador, String FchDe, String FchHas, string ParProveedor, string PartbNombre, string PartbEstilo, string ParDescripcion)
        {
            DataTable dtBonifica1 = null;
            try
            {
                dtBonifica1 = MmsWin.Datos.Bonificaciones.Bonificaciones.ObtenBonifica(marca, comprador, FchDe, FchHas, ParProveedor, PartbNombre, PartbEstilo, ParDescripcion);

                DataView dv = dtBonifica1.DefaultView;
                dtBonifica1 = dv.ToTable();
            }
            catch { }
            finally { }

            return dtBonifica1;
        }

        public void UpdateBonificaciones(DataTable dtBonificaciones)
        {
            try
            {
                dtBonificaciones = MmsWin.Datos.Bonificaciones.Bonificaciones.UpdateBonificaciones(dtBonificaciones);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateCheckBox(DataTable dtCheckBox)
        {
            try
            {
                MmsWin.Datos.Bonificaciones.Bonificaciones.UpdateCheckBox(dtCheckBox);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EliminaBonificaciones(string ParFchBon, string ParFchRev, string ParProveedor, string ParEstilo)
        {
            MmsWin.Datos.Bonificaciones.Bonificaciones.EliminaBonificaciones(ParFchBon, ParFchRev, ParProveedor, ParEstilo);
        }

        public DataTable ObtenRutaPDF(String ParFchBon, String ParFchCal, String ParPrv, String ParSty, String ParNota)
        {
            DataTable dtRutaPDF = null;
            try
            {
                dtRutaPDF = MmsWin.Datos.Bonificaciones.Bonificaciones.ObtenRutaPDF(ParFchBon, ParFchCal, ParPrv, ParSty, ParNota);

                DataView dv = dtRutaPDF.DefaultView;
                dtRutaPDF = dv.ToTable();
            }
            catch { }
            finally { }

            return dtRutaPDF;
        }

        public void EjecutaRecalculo(string ParFchBon)
        {
            try
            {
                MmsWin.Datos.Bonificaciones.Bonificaciones.EjecutaRecalculo(ParFchBon);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateFechaAmover(DataTable dtMoverFecha, string FchAmover)
        {
            try
            {
                dtMoverFecha = MmsWin.Datos.Bonificaciones.Bonificaciones.UpdateFechaAmover(dtMoverFecha, FchAmover);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
