﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Procesos
{
    public class Costos
    {
        internal static Costos Costo;

        public static Costos GetInstance()
        {
            if (Costo == null)
                Costo = new Costos();
            return Costo;
        }

        public void EjecutaCostos1(string ParFchBon, string ParFchEfe, string ParDescrip, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Procesos.Costos.EjecutaCostos(ParFchBon, ParFchEfe, ParDescrip, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
