﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Procesos
{
    public class BonificacionesP
    {
        internal static BonificacionesP BonificacionesPs;

        public static BonificacionesP GetInstance()
        {
            if (BonificacionesPs == null)
                BonificacionesPs = new BonificacionesP();
            return BonificacionesPs;
        }

        public void EjecutaBonificacionesP1(string ParFchInicio, string ParFchBon, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Procesos.BonificacionesP.EjecutaBonificaciones(ParFchInicio, ParFchBon, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
