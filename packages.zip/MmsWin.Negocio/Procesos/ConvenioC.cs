﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Procesos
{
    class ConvenioC
    {
        internal static ConvenioC Convenio;

        public static ConvenioC GetInstance()
        {
            if (Convenio == null)
                Convenio = new ConvenioC();
            return Convenio;
        }

        public void EjecutaEtiquetas1(string ParFCal, string ParfEfe, string ParDescrip, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Procesos.Etiquetas.EjecutaEtiquetas(ParFCal, ParfEfe, ParDescrip, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
