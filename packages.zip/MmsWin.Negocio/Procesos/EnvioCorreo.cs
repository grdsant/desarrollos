﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Procesos
{
    public class EnvioCorreo
    {
        internal static EnvioCorreo EnvioCorreos;

        public static EnvioCorreo GetInstance()
        {
            if (EnvioCorreos == null)
                EnvioCorreos = new EnvioCorreo();
            return EnvioCorreos;
        }

        public void EjecutaEnvioCorreo1(string ParFCal, string ParfEfe, string ParDescrip, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Procesos.EnvioCorreo.EjecutaEnvioCorreo(ParFCal, ParfEfe, ParDescrip, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
