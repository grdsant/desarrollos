﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MmsWin.Datos.Procesos;

namespace MmsWin.Negocio.Procesos
{
    public class PreciosMasivos
    {
        internal static PreciosMasivos Rebaja;

        public static PreciosMasivos GetInstance()
        {
            if (Rebaja == null)
                Rebaja = new PreciosMasivos();
            return Rebaja;
        }

        public void EjecutaRebajas1(string ParFchBon, string ParFchEfe, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Procesos.PreciosMasivos.EjecutaRebajas(ParFchBon, ParFchEfe, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
