﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MmsWin.Datos.Procesos;

namespace MmsWin.Negocio.Procesos
{
    public class Etiquetas
    {
        internal static Etiquetas Etiqueta;

        public static Etiquetas GetInstance()
        {
            if (Etiqueta == null)
                Etiqueta = new Etiquetas();
            return Etiqueta;
        }

        public void EjecutaEtiquetas1(string ParFCal, string ParfEfe, string ParDescrip, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Procesos.Etiquetas.EjecutaEtiquetas(ParFCal, ParfEfe, ParDescrip, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
