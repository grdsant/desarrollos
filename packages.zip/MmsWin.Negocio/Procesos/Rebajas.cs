﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MmsWin.Datos.Procesos;

namespace MmsWin.Negocio.Procesos
{
    public class Rebajas
    {
        internal static Rebajas Rebaja;

        public static Rebajas GetInstance()
        {
            if (Rebaja == null)
                Rebaja = new Rebajas();
            return Rebaja;
        }

        public void EjecutaRebajas1(string ParFchBon, string ParFchEfe, string ParDescrip, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Procesos.Rebajas.EjecutaRebajas(ParFchBon, ParFchEfe, ParDescrip, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
