﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Procesos
{
    public class CostosMasivos
    {
        internal static CostosMasivos Costo;

        public static CostosMasivos GetInstance()
        {
            if (Costo == null)
                Costo = new CostosMasivos();
            return Costo;
        }

        public void EjecutaCostos1(string ParFchBon, string ParFchEfe, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Procesos.CostosMasivos.EjecutaCostos(ParFchBon, ParFchEfe, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
