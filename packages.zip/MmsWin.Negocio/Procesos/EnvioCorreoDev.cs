﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Procesos
{
    public class EnvioCorreoDev
    {
        internal static EnvioCorreoDev EnvioCorreos;

        public static EnvioCorreoDev GetInstance()
        {
            if (EnvioCorreos == null)
                EnvioCorreos = new EnvioCorreoDev();
            return EnvioCorreos;
        }

        public void EjecutaEnvioCorreo1Dev(string ParFCal, string ParfEfe, string ParDescrip, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Procesos.EnvioCorreoDev.EjecutaEnvioCorreoDev(ParFCal, ParfEfe, ParDescrip, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
