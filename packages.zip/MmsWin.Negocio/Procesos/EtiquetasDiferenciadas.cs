﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MmsWin.Datos.Procesos;

namespace MmsWin.Negocio.Procesos
{
    public class EtiquetasDiferenciadas
    {
        internal static EtiquetasDiferenciadas Etiqueta;

        public static EtiquetasDiferenciadas GetInstance()
        {
            if (Etiqueta == null)
                Etiqueta = new EtiquetasDiferenciadas();
            return Etiqueta;
        }

        public void EjecutaEtiquetasDiferenciadas(string ParFCal, string ParfEfe, string ParDescrip, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Procesos.EtiquetaDiferenciada.EjecutaEtiquetaDiferenciada(ParFCal, ParfEfe, ParDescrip, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
