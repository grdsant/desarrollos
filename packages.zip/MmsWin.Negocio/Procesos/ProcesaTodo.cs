﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Procesos
{
    class ProcesaTodo
    {
        internal static ProcesaTodo ProcesaTodos;

        public static ProcesaTodo GetInstance()
        {
            if (ProcesaTodos == null)
                ProcesaTodos = new ProcesaTodo();
            return ProcesaTodos;
        }

        public void EjecutaProcesaTodo1(string ParFCal, string ParfEfe, string ParDescrip, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Procesos.ProcesaTodo.EjecutaProcesaTodo(ParFCal, ParfEfe, ParDescrip, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
