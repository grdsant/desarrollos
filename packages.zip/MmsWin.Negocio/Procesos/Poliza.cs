﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Procesos
{
    public class Poliza
    {
        internal static Poliza Polizas;

        public static Poliza GetInstance()
        {
            if (Polizas == null)
                Polizas = new Poliza();
            return Polizas;
        }

        public void EjecutaPoliza1(string ParFchCal, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Procesos.Poliza.EjecutaPoliza(ParFchCal, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
