﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Procesos
{
   public class Devoluciones
    {
       internal static Devoluciones Devolucion;

       public static Devoluciones GetInstance()
        {
            if (Devolucion == null)
                Devolucion = new Devoluciones();
            return Devolucion;
        }

       public void EjecutaDevolucion1(string ParFchCal, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Procesos.Devoluciones.EjecutaDevoluciones(ParFchCal, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
