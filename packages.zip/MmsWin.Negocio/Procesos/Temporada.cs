﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MmsWin.Entidades;
using System.Data;
namespace MmsWin.Negocio.Procesos
{
    public class Temporada
    {
        internal static Temporada temporada;

        public static Temporada GetInstance()
        {
            if (temporada == null)
                temporada = new Temporada();
            return temporada;
        }

        public void GuardaTemporada(MmsWin.Entidades.Temporada temp, string usuario)
        {
            try
            {
                MmsWin.Datos.Procesos.Temporada.GuardaTemporada(temp, usuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenTemporada(int marca, string comprador, string temporada, string origen,
             int id_prov = 0, string prov = "", string id_estilo = "", string estilo = "", int depto = 0, int subdepto = 0, int clase = 0, int subclase = 0)
        {
            try
            {
                return MmsWin.Datos.Procesos.Temporada.ObtenTemporada(marca, comprador, temporada, origen, id_prov, prov, id_estilo, estilo, depto, subdepto, clase, subclase);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenEstilos(string marca, int depto, int subdepto, int clase, int subclase, int proveedor, string estilo, string temporada, string origen)
        {
            try
            {
                return MmsWin.Datos.Procesos.Temporada.ObtenEstilos(marca, depto, subdepto, clase, subclase, proveedor, estilo, temporada, origen);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EliminaTemporada(int marca, int id_prov, string id_estilo)
        {
            try
            {
                MmsWin.Datos.Procesos.Temporada.EliminaTemporada(marca, id_prov, id_estilo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public DataTable ObtenHeaderTemporadas(short cadena)
        {
            try
            {
                return MmsWin.Datos.Procesos.Temporada.ObtenHeaderTemporadas(cadena);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void AgregaHeaderTemporadas(int anio, int marca, int id, string temp, string fec_black, string fec_black_fin, string fecha_cal, string fec_rec, string fec_rec_fin)
        {
            try
            {
                MmsWin.Datos.Procesos.Temporada.AgregaHeaderTemporadas(anio, marca, id, temp, fec_black, fec_black_fin, fecha_cal, fec_rec, fec_rec_fin);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenDetalleTemporadas(short cadena, int temp, int anio)
        {
            try
            {
                return MmsWin.Datos.Procesos.Temporada.ObtenDetalleTemporadas(cadena, temp,anio);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EliminaJerarquia_Black(int marca, int depto, int subdepto, int clase, int subclase, int temporada, int anio)
        {
            try
            {
                MmsWin.Datos.Procesos.Temporada.EliminaJerarquia_Black(marca, depto, subdepto, clase, subclase, temporada, anio);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public bool ValidaJerarquia(int marca, int depto, int subdepto, int clase, int subclase)
        {
            try
            {
                return MmsWin.Datos.Procesos.Temporada.ValidaJerarquia(marca, depto, subdepto, clase, subclase);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void InsertaJerarquia_Black(int marca, int depto, int subdepto, int clase, int subclase, int temporada, int anio)
        {
            try
            {
                MmsWin.Datos.Procesos.Temporada.InsertaJerarquia_Black(marca, depto, subdepto, clase, subclase, temporada, anio);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable CalificaTemporada(int marca, string temporada, string fecha_inicial, string fecha_final, int tabla)
        {
            try
            {
                return MmsWin.Datos.Procesos.Temporada.CalificaTemporada(marca, temporada, fecha_inicial,fecha_final,tabla);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
