﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace MmsWin.Negocio.Procesos
{
    public class Obtenfotos1
    {

        internal static Obtenfotos1 Obtenfoto;

        public static Obtenfotos1 GetInstance()
        {
            if (Obtenfoto == null)
                Obtenfoto = new Obtenfotos1();
            return Obtenfoto;
        }

        public DataTable ObtenFotos()
        {
            DataTable dtFotos = null;
            try
            {
                dtFotos = MmsWin.Datos.Procesos.Obtenfotos.ObtenFotos();

                DataView dv = dtFotos.DefaultView;
                dtFotos = dv.ToTable();
            }
            catch { }
            finally { }

            return dtFotos;
        }
    }
}
