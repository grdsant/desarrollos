﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MmsWin.Datos.Procesos;

namespace MmsWin.Negocio.Procesos
{
    public class RebajasDiferenciadas
    {
        internal static RebajasDiferenciadas Rebaja;

        public static RebajasDiferenciadas GetInstance()
        {
            if (Rebaja == null)
                Rebaja = new RebajasDiferenciadas();
            return Rebaja;
        }

        public void EjecutaRebajasDiferenciadas(string ParFchBon, string ParFchEfe, string ParDescrip, string ParUsuario)
        {
            try
            {
                MmsWin.Datos.Procesos.RebajaDiferenciada.EjecutaRebajaDiferenciada(ParFchBon, ParFchEfe, ParDescrip, ParUsuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
