﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace MmsWin.Negocio.Procesos
{
    public class Reglas
    {
        public static decimal PorcentajeMinimoCalificar { get { return Convert.ToDecimal(ConfigurationManager.AppSettings["PorcentajeMinimoCalificar"].ToString()); } }
        public static string TemporadasValidas { get { return ConfigurationManager.AppSettings["TemporadasValidas"].ToString(); } }

        /// <summary>
        /// Excepciones para la reprogramación
        /// </summary>
        public enum Excepciones : byte
        { 
            CumpleReglas = 0,
            TemporadaNoReprograma = 1,
            CalificacionNoAlcanzada = 2
        };


        /// <summary>
        /// 
        /// </summary>
        /// <param name="Calificacion"></param>
        /// <param name="Temporada"></param>
        /// <returns></returns>
        public static byte ValidarReglasReprogramacion(decimal Calificacion, string Temporada)
        {
            byte Validacion = 0;
            string[] Temporadas;

            Temporadas = TemporadasValidas.Split(',');

            foreach(string indice in Temporadas)
            {
                if (Temporada == indice)
                {
                    Validacion = (byte)Excepciones.CumpleReglas;
                }
            }

            if (Calificacion <= PorcentajeMinimoCalificar)
            {
                Validacion = (byte)Excepciones.CalificacionNoAlcanzada;
            }

            return Validacion;
        }


        public static string MensajeValidacion(Excepciones Excepcion )
        {
            string Mensaje = "";

            switch (Excepcion)
            {
                case Excepciones.CalificacionNoAlcanzada:
                    Mensaje = "REGLA REPROGRAMACIÓN: \nPara reprogramar, se debe contar con una calificación superior o igual al 40%";

                    break;

                case Excepciones.TemporadaNoReprograma:
                    Mensaje = "REGLA REPROGRAMACIÓN: \nNo definida para TODA TEMPORADA";

                    break;
            
            
            
            }
            
            return Mensaje;

        }

    }
}
