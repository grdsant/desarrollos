﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Seguridad
{
    public partial class AltaPerfil : Form
    {

        string Perfil;
        string Descripcion;
        string Fecha;
        string Hora;
        string Estatus;

        string PERPER;

        public AltaPerfil()
        {
            InitializeComponent();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btAceptar_Click(object sender, EventArgs e)
        {
            Valida();
        }

        private void tbPerfil_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (tbPerfil.Text != "")
                {
                    Valida();
                }
                else
                {
                    MessageBox.Show("No debe quedar en blanco el campo perfil...");
                }
            }
        }

        private void Valida()
        {
            if (tbPerfil.Text == "")
            {
                MessageBox.Show("No debe quedar en blanco el campo perfil...");
            }
            else
            {
                tbFecha.Text = DateTime.Now.ToString("dd/MM/yyyy");
                tbHora.Text = DateTime.Now.ToString("HH:mm:ss");
                tbEstatus.Text = "A";

                WritePerfil();
            }
        }

        private void WritePerfil()
        {

            Perfil = tbPerfil.Text;
            Descripcion = tbDescripcion.Text;
            Fecha = tbFecha.Text;
            Fecha = Fecha.Substring(8, 2) + Fecha.Substring(3, 2) + Fecha.Substring(0, 2);
            Hora = tbHora.Text;
            Hora = Hora.Substring(0, 2) + Hora.Substring(3, 2) + Hora.Substring(6, 2);
            Estatus = tbEstatus.Text;

            System.Data.DataTable tbLogin = null;
            tbLogin = MmsWin.Negocio.Seguridad.AltaPerfil.GetInstance().WritePerfil1(Perfil, Descripcion, Fecha, Hora, Estatus);

            if (tbLogin != null)
            {
                foreach (DataRow row in tbLogin.Rows)
                {
                    PERPER = row["PERPER"].ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpPERPER = PERPER;
                }
                if (tbLogin.Rows.Count > 0)
                {
                    MessageBox.Show("Se agrego el perfil correctamente...");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("No se completo la Alta Correctamente...");
                }
            }
            else
            {
                MessageBox.Show("No se completo la Alta Correctamente...");
            }

        }

        private void AltaPerfil_Load(object sender, EventArgs e)
        {

        }

    }
}
