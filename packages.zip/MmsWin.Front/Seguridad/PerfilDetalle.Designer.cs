﻿namespace MmsWin.Front.Seguridad
{
    partial class PerfilDetalle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvPerfilDetalle = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ActualizarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.borrarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.lblReg = new System.Windows.Forms.Label();
            this.tbControl = new System.Windows.Forms.TextBox();
            this.tbModulo = new System.Windows.Forms.TextBox();
            this.tbAplicacion = new System.Windows.Forms.TextBox();
            this.tbPerfil = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPerfilDetalle)).BeginInit();
            this.cmMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvPerfilDetalle
            // 
            this.dgvPerfilDetalle.AllowDrop = true;
            this.dgvPerfilDetalle.AllowUserToAddRows = false;
            this.dgvPerfilDetalle.AllowUserToOrderColumns = true;
            this.dgvPerfilDetalle.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPerfilDetalle.ContextMenuStrip = this.cmMenu;
            this.dgvPerfilDetalle.Location = new System.Drawing.Point(4, 30);
            this.dgvPerfilDetalle.Name = "dgvPerfilDetalle";
            this.dgvPerfilDetalle.Size = new System.Drawing.Size(1090, 323);
            this.dgvPerfilDetalle.TabIndex = 0;
            this.dgvPerfilDetalle.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvPerfilDetalle_CellMouseDown);
            this.dgvPerfilDetalle.DragDrop += new System.Windows.Forms.DragEventHandler(this.dgvPerfilDetalle_DragDrop);
            this.dgvPerfilDetalle.DragEnter += new System.Windows.Forms.DragEventHandler(this.dgvPerfilDetalle_DragEnter);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ActualizarTSMI,
            this.borrarTSMI});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(127, 48);
            // 
            // ActualizarTSMI
            // 
            this.ActualizarTSMI.Name = "ActualizarTSMI";
            this.ActualizarTSMI.Size = new System.Drawing.Size(126, 22);
            this.ActualizarTSMI.Text = "Actualizar";
            this.ActualizarTSMI.Click += new System.EventHandler(this.ActualizarTSMI_Click);
            // 
            // borrarTSMI
            // 
            this.borrarTSMI.Name = "borrarTSMI";
            this.borrarTSMI.Size = new System.Drawing.Size(126, 22);
            this.borrarTSMI.Text = "Borrar";
            this.borrarTSMI.Click += new System.EventHandler(this.borrarTSMI_Click);
            // 
            // lblReg
            // 
            this.lblReg.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblReg.AutoSize = true;
            this.lblReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReg.Location = new System.Drawing.Point(1040, -4);
            this.lblReg.Name = "lblReg";
            this.lblReg.Size = new System.Drawing.Size(35, 37);
            this.lblReg.TabIndex = 13;
            this.lblReg.Text = "0";
            this.lblReg.Visible = false;
            // 
            // tbControl
            // 
            this.tbControl.Location = new System.Drawing.Point(643, 7);
            this.tbControl.Name = "tbControl";
            this.tbControl.Size = new System.Drawing.Size(204, 20);
            this.tbControl.TabIndex = 21;
            this.tbControl.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbControl_KeyPress);
            // 
            // tbModulo
            // 
            this.tbModulo.Location = new System.Drawing.Point(447, 7);
            this.tbModulo.Name = "tbModulo";
            this.tbModulo.Size = new System.Drawing.Size(195, 20);
            this.tbModulo.TabIndex = 20;
            this.tbModulo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbModulo_KeyPress);
            // 
            // tbAplicacion
            // 
            this.tbAplicacion.Location = new System.Drawing.Point(247, 7);
            this.tbAplicacion.Name = "tbAplicacion";
            this.tbAplicacion.Size = new System.Drawing.Size(199, 20);
            this.tbAplicacion.TabIndex = 19;
            this.tbAplicacion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbAplicacion_KeyPress);
            // 
            // tbPerfil
            // 
            this.tbPerfil.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbPerfil.Location = new System.Drawing.Point(48, 7);
            this.tbPerfil.Name = "tbPerfil";
            this.tbPerfil.Size = new System.Drawing.Size(198, 20);
            this.tbPerfil.TabIndex = 18;
            this.tbPerfil.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbPerfil_KeyPress);
            // 
            // PerfilDetalle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1098, 365);
            this.ContextMenuStrip = this.cmMenu;
            this.Controls.Add(this.tbControl);
            this.Controls.Add(this.tbModulo);
            this.Controls.Add(this.tbAplicacion);
            this.Controls.Add(this.tbPerfil);
            this.Controls.Add(this.lblReg);
            this.Controls.Add(this.dgvPerfilDetalle);
            this.Name = "PerfilDetalle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Detalle de Perfiles";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PerfilDetalle_FormClosing);
            this.Load += new System.EventHandler(this.PerfilDetalle_Load);
            this.Resize += new System.EventHandler(this.PerfilDetalle_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPerfilDetalle)).EndInit();
            this.cmMenu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvPerfilDetalle;
        private System.Windows.Forms.Label lblReg;
        private System.Windows.Forms.TextBox tbControl;
        private System.Windows.Forms.TextBox tbModulo;
        private System.Windows.Forms.TextBox tbAplicacion;
        private System.Windows.Forms.TextBox tbPerfil;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem ActualizarTSMI;
        private System.Windows.Forms.ToolStripMenuItem borrarTSMI;
    }
}