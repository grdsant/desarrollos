﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Seguridad
{
    public partial class AltaUsuario : Form
    {
        string Usuario;
        string Nombre;
        string Password;
        string nivel;
        string Marca;
        string Descripcion;
        string Comprador;
        string Correo;
        string Perfil;
        string Fecha;
        string Hora;
        string Estatus;

        string USRUSR;
        string USRPER;

        string UPUPRF;
        string UPTEXT;

        public AltaUsuario()
        {
            InitializeComponent();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btAceptar_Click(object sender, EventArgs e)
        {
            if (tbUsuario.Text == "")
            {
                MessageBox.Show("No debe quedar en blanco el campo usuario...");
            }
            else
            {
                Validacion();
                if (tbNombre.Text != "")
                {
                    WriteUsuario();
                }
                else
                {
                    MessageBox.Show("El usuario no existe ó no hay conexion con el servidor ");
                }
            }
        }

        private void tbUsuario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (tbUsuario.Text != "")
                {
                    Validacion();
                }
                else
                {
                    MessageBox.Show("No debe quedar en blanco el campo usuario...");
                }
            }
        }

        private void Validacion()
        {
            string Usuario = tbUsuario.Text;
            string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
            string ParPassword = MmsWin.Front.Utilerias.VarTem.tmpPass;
            System.Data.DataTable tbLogin = null;
            tbLogin = MmsWin.Negocio.Seguridad.AltaUsuario.GetInstance().ObtenUsuario1(Usuario);

            if (tbLogin != null)
            {
                foreach (DataRow row in tbLogin.Rows)
                {
                    UPUPRF = row["UPUPRF"].ToString();
                    UPTEXT = row["UPTEXT"].ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpUPUPRF = UPUPRF;
                    MmsWin.Front.Utilerias.VarTem.tmpUPTEXT = UPTEXT;
                }
                if (tbLogin.Rows.Count > 0)
                {
                    tbNombre.Text = UPTEXT;

                    tbFecha.Text = DateTime.Now.ToString("dd/MM/yyyy");
                    tbHora.Text = DateTime.Now.ToString("HH:mm:ss");
                    tbEstatus.Text = "A";
                }
                else
                {
                    tbNombre.Text = "";
                    MessageBox.Show("El usuario no existe ó no hay conexion con el servidor ");
                }
            }
            else
            {
                tbNombre.Text = "";
                MessageBox.Show("El usuario no existe ó no hay conexion con el servidor ");
            }
        }

        private void WriteUsuario()
        {
            Usuario = tbUsuario.Text;
            Nombre = tbNombre.Text;
            Password = tbPassword.Text;
            nivel = tbNivel.Text;
            Marca = tbMarca.Text;
            Descripcion = tbDescripcion.Text;
            Comprador = tbComprador.Text;
            Correo = tbCorreo.Text;
            Perfil = tbPerfil.Text;
            Fecha = tbFecha.Text;
            Fecha = Fecha.Substring(8, 2) + Fecha.Substring(3, 2) + Fecha.Substring(0, 2);
            Hora = tbHora.Text;
            Hora = Hora.Substring(0, 2) + Hora.Substring(3, 2) + Hora.Substring(6, 2);
            Estatus = tbEstatus.Text;

            System.Data.DataTable tbLogin = null;
            tbLogin = MmsWin.Negocio.Seguridad.AltaUsuario.GetInstance().WriteUsuario1(Usuario, Nombre, Password, nivel, Marca, Descripcion, Comprador, Correo, Perfil, Fecha, Hora, Estatus);

            if (tbLogin != null)
            {
                foreach (DataRow row in tbLogin.Rows)
                {
                    USRUSR = row["USRUSR"].ToString();
                    USRPER = row["USRPER"].ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpUSRUSR = USRUSR;
                    MmsWin.Front.Utilerias.VarTem.tmpUSRPER = USRPER;
                }
                if (tbLogin.Rows.Count > 0)
                {
                  MessageBox.Show("Se agrego el usuario correctamente...");
                  this.Close();
                }
                else
                {
                    MessageBox.Show("No se completo la Alta Correctamente...");
                }
            }
            else
            {
                MessageBox.Show("No se completo la Alta Correctamente...");
            }

        }

    }
}
