﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Seguridad
{
    public partial class Perfiles : Form
    {

        string ParUser;
        string perfil;
        string descripcion;

        int dgvOffset;
        int dgvOffset2;

        public Perfiles()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvPerfiles.Width;
            dgvOffset2 = this.Height - dgvPerfiles.Height;
        }

        private void Perfiles_Load(object sender, EventArgs e)
        {
            BindPerfiles();

            // Seguridad...                                                                     
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("Seguridad", "Perfiles", ParUser);
        }
        // Seguridad                                                                                 
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                          
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvPerfiles.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvPerfiles.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenu.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenu.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        private void Perfiles_Resize(object sender, EventArgs e)
        {
            dgvPerfiles.Width = this.Width - dgvOffset;
            dgvPerfiles.Height = this.Height - dgvOffset2;
        }

        protected void BindPerfiles()
        {

            this.Cursor = Cursors.WaitCursor;

            dgvPerfiles.DataSource = null;
            System.Data.DataTable Perfiles = null;
            try
            {
                perfil = tbPerfil.Text;
                descripcion = tbDescripcion.Text;
                Perfiles = MmsWin.Negocio.Seguridad.Perfiles.GetInstance().ObtenPerfiles1(perfil, descripcion);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (Perfiles.Rows.Count > 0)
            {
                dgvPerfiles.DataSource = Perfiles;
                int nr = dgvPerfiles.RowCount;
                this.Text = (nr).ToString() + " " + "Perfiles";

                SetFontAndColors();
                rowStyle();
                SetDoubleBuffered(dgvPerfiles);
            }
            this.Cursor = Cursors.Default;
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        private void dgvPerfiles_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                try
                {
                    Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                                  "PerfilDetalle").SingleOrDefault<Form>();
                    {
                        if (existe != null)
                        {
                            MessageBox.Show("La ventana de Detalle ya esta abierta");
                        }
                        else
                        {
                            PerfilDetalle i = new PerfilDetalle();
                            i.Show();
                        }
                    }
                }
                catch { }
                finally { }
            }
        }

        private void SetFontAndColors()
        {
            this.dgvPerfiles.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvPerfiles.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvPerfiles.EnableHeadersVisualStyles = false;
            this.dgvPerfiles.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvPerfiles.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvPerfiles.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvPerfiles.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvPerfiles.RowsDefaultCellStyle.ForeColor = Color.Black;
           // this.dgvPerfiles.Columns[3].Frozen = true;

            dgvPerfiles.Columns[0].HeaderText = "Perfil";
            dgvPerfiles.Columns[1].HeaderText = "Descripcion";
            dgvPerfiles.Columns[2].HeaderText = "Fecha";
            dgvPerfiles.Columns[3].HeaderText = "Hora";
            dgvPerfiles.Columns[4].HeaderText = "Estatus";

            dgvPerfiles.Columns[0].Width = 200;
            dgvPerfiles.Columns[1].Width = 200;
            dgvPerfiles.Columns[2].Width = 90;
            dgvPerfiles.Columns[3].Width = 90;
            dgvPerfiles.Columns[4].Width = 50;

            dgvPerfiles.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvPerfiles.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvPerfiles.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvPerfiles.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvPerfiles.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvPerfiles.Columns[2].DefaultCellStyle.Format = "20##-##-##";
            dgvPerfiles.Columns[3].DefaultCellStyle.Format = "##:##:##";

            dgvPerfiles.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvPerfiles.Columns[1].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvPerfiles.Columns[2].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvPerfiles.Columns[3].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvPerfiles.Columns[4].HeaderCell.Style.BackColor = Color.LightGreen;
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvPerfiles.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvPerfiles.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }

        private void dgvPerfiles_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                string valorcelda = "";
                DataGridView.HitTestInfo info = dgvPerfiles.HitTest(e.X, e.Y);

                // buscar fila bajo el Mouse
                if (e.Button == MouseButtons.Left)
                {
                    if (dgvPerfiles.Rows[info.RowIndex].Cells[info.ColumnIndex].Value != null)
                    {
                        valorcelda = dgvPerfiles.Rows[info.RowIndex].Cells[info.ColumnIndex].Value.ToString();
                        dgvPerfiles.DoDragDrop(valorcelda, DragDropEffects.Copy);
                        MmsWin.Front.Utilerias.VarTem.tmpPerfil = dgvPerfiles.Rows[info.RowIndex].Cells[0].Value.ToString();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void dgvPerfiles_CellMouseMove(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.dgvPerfiles.DoDragDrop(this.dgvPerfiles.CurrentRow, DragDropEffects.All);
            }
        }

        private void dgvPerfiles_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
           if (e.Button == MouseButtons.Left)
            {
                var hti = dgvPerfiles.HitTest(e.X, e.Y);
                int Row = e.RowIndex;
                int Col = e.ColumnIndex;
            }

           if (e.Button == MouseButtons.Right)
           {
               var hti = dgvPerfiles.HitTest(e.X, e.Y);
               int Row = e.RowIndex;
               int Col = e.ColumnIndex;
               cmMenu.Visible = true;
           }
        }

        private void PerfilDetalle()
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "PerfilDetalle").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana de Detalle ya esta abierta");
                    }
                    else
                    {
                        PerfilDetalle i = new PerfilDetalle();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbNuevo_Click(object sender, EventArgs e)
        {
            AltaPerfil();  
        }

        private void AltaPerfil()
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "AltaPerfil").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana de Alta de Perfil ya esta abierta");
                    }
                    else
                    {
                        AltaPerfil i = new AltaPerfil();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void dgvPerfiles_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F6)
            {
                AltaPerfil();
            }
            if (e.KeyCode == Keys.F5)
            {
                BindPerfiles();
            }
        }

        private void nuevoTSMI_Click(object sender, EventArgs e)
        {
            AltaPerfil();
        }

        private void dgvPerfiles_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int Row = e.RowIndex;
            int Col = e.ColumnIndex;
            MmsWin.Front.Utilerias.VarTem.tmpPerfil = dgvPerfiles.Rows[Row].Cells[0].Value.ToString();
            PerfilDetalle();
        }

        private void tbPerfil_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindPerfiles();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindPerfiles();
            }
        }

        private void ActualizarTSMI_Click(object sender, EventArgs e)
        {
            ActualizaPerfil();
        }

        private void ActualizaPerfil()
        {
            System.Data.DataTable dtPerfil = new System.Data.DataTable("Usuario");
            dtPerfil.Columns.Add("Perfil", typeof(String));
            dtPerfil.Columns.Add("Descripcion", typeof(String));
            dtPerfil.Columns.Add("Fecha", typeof(String));
            dtPerfil.Columns.Add("Hora", typeof(String));
            dtPerfil.Columns.Add("Estatus", typeof(String));
            dtPerfil.Columns.Add("PerfilB", typeof(String));

            DataGridViewSelectedRowCollection Seleccionados = dgvPerfiles.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                DataRow workRow = dtPerfil.NewRow();
                workRow["Perfil"] = item.Cells[0].Value.ToString();
                workRow["Descripcion"] = item.Cells[1].Value.ToString();
                workRow["Fecha"] = item.Cells[2].Value.ToString();
                workRow["Hora"] = item.Cells[3].Value.ToString();
                workRow["Estatus"] = item.Cells[4].Value.ToString();
                workRow["PerfilB"] = item.Cells[5].Value.ToString();

                dtPerfil.Rows.Add(workRow);
            }
            MmsWin.Negocio.Seguridad.Perfiles.GetInstance().UpdatePerfil(dtPerfil);
            MessageBox.Show("Actualizacion completa...");
            BindPerfiles();
        }

        private void EliminarTSMI_Click(object sender, EventArgs e)
        {
            string perfil;
            string message = "Corfirmar la Eliminación del Registro";
            string caption = "Advertencia...";
            DataGridViewSelectedRowCollection Seleccionados = dgvPerfiles.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                perfil = item.Cells[0].Value.ToString();

                message = "Confirma la eliminacion del perfil:" + perfil;
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;
                result = MessageBox.Show(message, caption, buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    MmsWin.Negocio.Seguridad.Perfiles.GetInstance().EliminaPerfil(perfil);
                    MessageBox.Show("Perfil Eliminado...");
                }
            }

            BindPerfiles();
        }

        private void detalleTSMI_Click(object sender, EventArgs e)
        {
            PerfilDetalle();
        }

        private void Perfiles_FormClosing(object sender, FormClosingEventArgs e)
        {
            CargaSeguridad("Seguridad", "Perfiles", ParUser);
        }
        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            //
            string NomCol;
            Int32 NoCol = dgvPerfiles.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvPerfiles.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      
            //
            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void dgvPerfiles_SelectionChanged(object sender, EventArgs e)
        {
            dgvPerfiles.Select();
            MmsWin.Front.Utilerias.VarTem.tmpPerfil = this.dgvPerfiles.CurrentRow.Cells[0].Value.ToString();
        }
    }
}
