﻿namespace MmsWin.Front.Seguridad
{
    partial class Perfiles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Perfiles));
            this.dgvPerfiles = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.nuevoTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.detalleTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.ActualizarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.EliminarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbPerfil = new System.Windows.Forms.TextBox();
            this.pbNuevo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPerfiles)).BeginInit();
            this.cmMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNuevo)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvPerfiles
            // 
            this.dgvPerfiles.AllowDrop = true;
            this.dgvPerfiles.AllowUserToAddRows = false;
            this.dgvPerfiles.AllowUserToOrderColumns = true;
            this.dgvPerfiles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPerfiles.ContextMenuStrip = this.cmMenu;
            this.dgvPerfiles.Location = new System.Drawing.Point(6, 32);
            this.dgvPerfiles.Name = "dgvPerfiles";
            this.dgvPerfiles.Size = new System.Drawing.Size(674, 295);
            this.dgvPerfiles.TabIndex = 0;
            this.dgvPerfiles.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPerfiles_CellDoubleClick);
            this.dgvPerfiles.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvPerfiles_CellMouseDown);
            this.dgvPerfiles.CellMouseMove += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvPerfiles_CellMouseMove);
            this.dgvPerfiles.SelectionChanged += new System.EventHandler(this.dgvPerfiles_SelectionChanged);
            this.dgvPerfiles.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dgvPerfiles_KeyPress);
            this.dgvPerfiles.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvPerfiles_KeyUp);
            this.dgvPerfiles.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgvPerfiles_MouseDown);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevoTSMI,
            this.detalleTSMI,
            this.ActualizarTSMI,
            this.EliminarTSMI});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(127, 92);
            // 
            // nuevoTSMI
            // 
            this.nuevoTSMI.Name = "nuevoTSMI";
            this.nuevoTSMI.Size = new System.Drawing.Size(126, 22);
            this.nuevoTSMI.Text = "Nuevo";
            this.nuevoTSMI.Click += new System.EventHandler(this.nuevoTSMI_Click);
            // 
            // detalleTSMI
            // 
            this.detalleTSMI.Name = "detalleTSMI";
            this.detalleTSMI.Size = new System.Drawing.Size(126, 22);
            this.detalleTSMI.Text = "Detalle";
            this.detalleTSMI.Click += new System.EventHandler(this.detalleTSMI_Click);
            // 
            // ActualizarTSMI
            // 
            this.ActualizarTSMI.Name = "ActualizarTSMI";
            this.ActualizarTSMI.Size = new System.Drawing.Size(126, 22);
            this.ActualizarTSMI.Text = "Actualizar";
            this.ActualizarTSMI.Click += new System.EventHandler(this.ActualizarTSMI_Click);
            // 
            // EliminarTSMI
            // 
            this.EliminarTSMI.Name = "EliminarTSMI";
            this.EliminarTSMI.Size = new System.Drawing.Size(126, 22);
            this.EliminarTSMI.Text = "Eliminar";
            this.EliminarTSMI.Click += new System.EventHandler(this.EliminarTSMI_Click);
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.Location = new System.Drawing.Point(248, 11);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(200, 20);
            this.tbDescripcion.TabIndex = 21;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress);
            // 
            // tbPerfil
            // 
            this.tbPerfil.Location = new System.Drawing.Point(47, 11);
            this.tbPerfil.Name = "tbPerfil";
            this.tbPerfil.Size = new System.Drawing.Size(200, 20);
            this.tbPerfil.TabIndex = 20;
            this.tbPerfil.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbPerfil_KeyPress);
            // 
            // pbNuevo
            // 
            this.pbNuevo.Image = ((System.Drawing.Image)(resources.GetObject("pbNuevo.Image")));
            this.pbNuevo.Location = new System.Drawing.Point(9, 4);
            this.pbNuevo.Name = "pbNuevo";
            this.pbNuevo.Size = new System.Drawing.Size(26, 26);
            this.pbNuevo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbNuevo.TabIndex = 22;
            this.pbNuevo.TabStop = false;
            this.pbNuevo.Click += new System.EventHandler(this.pbNuevo_Click);
            // 
            // Perfiles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 335);
            this.Controls.Add(this.pbNuevo);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.tbPerfil);
            this.Controls.Add(this.dgvPerfiles);
            this.Name = "Perfiles";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Perfiles";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Perfiles_FormClosing);
            this.Load += new System.EventHandler(this.Perfiles_Load);
            this.Resize += new System.EventHandler(this.Perfiles_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPerfiles)).EndInit();
            this.cmMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbNuevo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvPerfiles;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbPerfil;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem ActualizarTSMI;
        private System.Windows.Forms.ToolStripMenuItem EliminarTSMI;
        private System.Windows.Forms.ToolStripMenuItem nuevoTSMI;
        private System.Windows.Forms.PictureBox pbNuevo;
        private System.Windows.Forms.ToolStripMenuItem detalleTSMI;
    }
}