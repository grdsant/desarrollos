﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Seguridad
{
    public partial class PerfilDetalle : Form
    {

        string ParUser;
        string perfil;
        string aplicacion;
        string modulo;
        string control;

        int dgvOffset;
        int dgvOffset2;

        public PerfilDetalle()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvPerfilDetalle.Width;
            dgvOffset2 = this.Height - dgvPerfilDetalle.Height;
        }

        private void PerfilDetalle_Resize(object sender, EventArgs e)
        {
            dgvPerfilDetalle.Width = this.Width - dgvOffset;
            dgvPerfilDetalle.Height = this.Height - dgvOffset2;
        }

        private void PerfilDetalle_Load(object sender, EventArgs e)
        {
            tbPerfil.Text = MmsWin.Front.Utilerias.VarTem.tmpPerfil;
            BindPerfilDetalle();

            // Seguridad...                                                                     
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("Seguridad", "PerfilDetalle", ParUser);
        }

        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }

        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvPerfilDetalle.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvPerfilDetalle.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenu.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenu.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        protected void BindPerfilDetalle()
        {

            this.Cursor = Cursors.WaitCursor;

            dgvPerfilDetalle.DataSource = null;
            System.Data.DataTable PerfilDetalle = null;
            try
            {
                perfil = tbPerfil.Text;
                aplicacion = tbAplicacion.Text;
                modulo = tbModulo.Text;
                control = tbControl.Text;
                PerfilDetalle = MmsWin.Negocio.Seguridad.PerfilDetalle.GetInstance().ObtenPerfilDetalle1(perfil, aplicacion, modulo, control);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (PerfilDetalle.Rows.Count > 0)
            {
                dgvPerfilDetalle.DataSource = PerfilDetalle;
                int nr = dgvPerfilDetalle.RowCount;
                this.Text = (nr).ToString() + " " + "Controles en Perfiles";

                SetFontAndColors();
                rowStyle();
            }
            this.Cursor = Cursors.Default;
        }

        private void SetFontAndColors()
        {
            this.dgvPerfilDetalle.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvPerfilDetalle.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvPerfilDetalle.EnableHeadersVisualStyles = false;
            this.dgvPerfilDetalle.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvPerfilDetalle.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvPerfilDetalle.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvPerfilDetalle.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvPerfilDetalle.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvPerfilDetalle.Columns[3].Frozen = true;

            dgvPerfilDetalle.Columns[0].HeaderText = "Perfil";
            dgvPerfilDetalle.Columns[1].HeaderText = "Aplicacion";
            dgvPerfilDetalle.Columns[2].HeaderText = "Modulo";
            dgvPerfilDetalle.Columns[3].HeaderText = "Control";
            dgvPerfilDetalle.Columns[4].HeaderText = "Disponible";
            dgvPerfilDetalle.Columns[5].HeaderText = "Visible";
            dgvPerfilDetalle.Columns[6].HeaderText = "Fecha";
            dgvPerfilDetalle.Columns[7].HeaderText = "Hora";
            dgvPerfilDetalle.Columns[8].HeaderText = "Estatus";

            dgvPerfilDetalle.Columns[0].Width = 200;
            dgvPerfilDetalle.Columns[1].Width = 200;
            dgvPerfilDetalle.Columns[2].Width = 200;
            dgvPerfilDetalle.Columns[3].Width = 210;
            dgvPerfilDetalle.Columns[4].Width = 70;
            dgvPerfilDetalle.Columns[5].Width = 70;
            dgvPerfilDetalle.Columns[6].Width = 80;
            dgvPerfilDetalle.Columns[7].Width = 80;
            dgvPerfilDetalle.Columns[8].Width = 50;

            dgvPerfilDetalle.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvPerfilDetalle.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvPerfilDetalle.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvPerfilDetalle.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvPerfilDetalle.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvPerfilDetalle.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvPerfilDetalle.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvPerfilDetalle.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvPerfilDetalle.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvPerfilDetalle.Columns[6].DefaultCellStyle.Format = "20##-##-##";
            dgvPerfilDetalle.Columns[7].DefaultCellStyle.Format = "##:##:##";

            dgvPerfilDetalle.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvPerfilDetalle.Columns[1].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvPerfilDetalle.Columns[2].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvPerfilDetalle.Columns[3].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvPerfilDetalle.Columns[4].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvPerfilDetalle.Columns[5].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvPerfilDetalle.Columns[6].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvPerfilDetalle.Columns[7].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvPerfilDetalle.Columns[8].HeaderCell.Style.BackColor = Color.LightSlateGray;
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvPerfilDetalle.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvPerfilDetalle.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }
        // Activa el Copy                                                                             
        //
        private void dgvPerfilDetalle_DragEnter(object sender, DragEventArgs e)
        { 
            e.Effect = DragDropEffects.Copy;
        }
        // Pega                                                                                       
        //
        private void dgvPerfilDetalle_DragDrop(object sender, DragEventArgs e)
        {
            string valornuevo = Convert.ToString(e.Data.GetData(DataFormats.StringFormat));
            control = valornuevo;
            string aplicacion = MmsWin.Front.Utilerias.VarTem.tmpAplicacion;
            string modulo = MmsWin.Front.Utilerias.VarTem.tmpModulo;
            string perfil = tbPerfil.Text;

            // calcular ubicacion del Mouse en coordenadas relativas al Gridview          
            Point gridDrop = dgvPerfilDetalle.PointToClient(new Point(e.X, e.Y));

            // buscar fila bajo el Mouse                                                  
            int rowDrop = dgvPerfilDetalle.HitTest(gridDrop.X, gridDrop.Y).RowIndex;
            int colDrop = dgvPerfilDetalle.HitTest(gridDrop.X, gridDrop.Y).ColumnIndex;

            if (tbPerfil.Text != "")
            {
               string fecha = DateTime.Now.ToString("dd/MM/yyyy");
               fecha = fecha.Substring(8, 2) + fecha.Substring(3, 2) + fecha.Substring(0, 2);
               string hora = DateTime.Now.ToString("HH:mm:ss");
               hora = hora.Substring(0, 2) + hora.Substring(3, 2) + hora.Substring(6, 2);
               string estatus = "A";

               MmsWin.Negocio.Seguridad.PerfilDetalle.GetInstance().WritePerfilDetalle1(perfil, aplicacion, modulo, control, fecha, hora, estatus);
               BindPerfilDetalle();
            }
            else
            {
                MessageBox.Show("No hay Perfil Seleccionado");
            }

       //     dgvPerfilDetalle.Rows[rowDrop].Cells[colDrop].Value = valornuevo;
       //     valornuevo = "";
        }

        private void dgvPerfilDetalle_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                var hti = dgvPerfilDetalle.HitTest(e.X, e.Y);
                int Row = e.RowIndex;
                int Col = e.ColumnIndex;
                cmMenu.Visible = true;
            }
        }

        private void tbPerfil_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindPerfilDetalle();
            }
        }

        private void tbAplicacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindPerfilDetalle();
            }
        }

        private void tbModulo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindPerfilDetalle();
            }
        }

        private void tbControl_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindPerfilDetalle();
            }
        }

        private void ActualizarTSMI_Click(object sender, EventArgs e)
        {
            ActualizaPerfilDetalle();
        }

        private void ActualizaPerfilDetalle()
        {
            System.Data.DataTable dtPerfilDetalle = new System.Data.DataTable("Usuario");
            dtPerfilDetalle.Columns.Add("Perfil", typeof(String));
            dtPerfilDetalle.Columns.Add("Aplicacion", typeof(String));
            dtPerfilDetalle.Columns.Add("Modulo", typeof(String));
            dtPerfilDetalle.Columns.Add("Control", typeof(String));
            dtPerfilDetalle.Columns.Add("Disponible", typeof(String));
            dtPerfilDetalle.Columns.Add("Visible", typeof(String));
            dtPerfilDetalle.Columns.Add("Fecha", typeof(String));
            dtPerfilDetalle.Columns.Add("Hora", typeof(String));
            dtPerfilDetalle.Columns.Add("Estatus", typeof(String));

            DataGridViewSelectedRowCollection Seleccionados = dgvPerfilDetalle.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                DataRow workRow = dtPerfilDetalle.NewRow();
                workRow["Perfil"] = item.Cells[0].Value.ToString();
                workRow["Aplicacion"] = item.Cells[1].Value.ToString();
                workRow["Modulo"] = item.Cells[2].Value.ToString();
                workRow["Control"] = item.Cells[3].Value.ToString();
                workRow["Disponible"] = item.Cells[4].Value.ToString();
                workRow["Visible"] = item.Cells[5].Value.ToString();
                workRow["Fecha"] = item.Cells[6].Value.ToString();
                workRow["Hora"] = item.Cells[7].Value.ToString();
                workRow["Estatus"] = item.Cells[8].Value.ToString();

                dtPerfilDetalle.Rows.Add(workRow);
            }
            MmsWin.Negocio.Seguridad.PerfilDetalle.GetInstance().UpdatePerfilDetalle(dtPerfilDetalle);
            MessageBox.Show("Actualizacion completa...");
            BindPerfilDetalle();
        }

        private void borrarTSMI_Click(object sender, EventArgs e)
        {
            string perfil;
            string aplicacion;
            string modulo;
            string control;

            string message = "Corfirmar la Eliminación del Registro";
            string caption = "Advertencia...";
            DataGridViewSelectedRowCollection Seleccionados = dgvPerfilDetalle.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                perfil = item.Cells[0].Value.ToString();
                aplicacion = item.Cells[1].Value.ToString();
                modulo = item.Cells[2].Value.ToString();
                control = item.Cells[3].Value.ToString();

                message = "Confirma la eliminacion del Control en el perfil:" + perfil;
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;
                result = MessageBox.Show(message, caption, buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    MmsWin.Negocio.Seguridad.PerfilDetalle.GetInstance().EliminaPerfilDetalle(perfil, aplicacion, modulo, control);
                }
            }

            BindPerfilDetalle();
        }

        private void PerfilDetalle_FormClosing(object sender, FormClosingEventArgs e)
        {
            CargaSeguridad("Seguridad", "PerfilDetalle", ParUser);
        }

        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            //
            string NomCol;
            Int32 NoCol = dgvPerfilDetalle.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvPerfilDetalle.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      
            //
            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

    }
}
