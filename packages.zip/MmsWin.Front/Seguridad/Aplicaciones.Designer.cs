﻿namespace MmsWin.Front.Seguridad
{
    partial class Aplicaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvAplicaciones = new System.Windows.Forms.DataGridView();
            this.lblReg = new System.Windows.Forms.Label();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ActualizarTodoTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.borrarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAplicaciones)).BeginInit();
            this.cmMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvAplicaciones
            // 
            this.dgvAplicaciones.AllowUserToOrderColumns = true;
            this.dgvAplicaciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAplicaciones.ContextMenuStrip = this.cmMenu;
            this.dgvAplicaciones.Location = new System.Drawing.Point(10, 39);
            this.dgvAplicaciones.Name = "dgvAplicaciones";
            this.dgvAplicaciones.Size = new System.Drawing.Size(599, 285);
            this.dgvAplicaciones.TabIndex = 0;
            this.dgvAplicaciones.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvAplicaciones_CellMouseDown);
            // 
            // lblReg
            // 
            this.lblReg.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblReg.AutoSize = true;
            this.lblReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReg.Location = new System.Drawing.Point(274, -1);
            this.lblReg.Name = "lblReg";
            this.lblReg.Size = new System.Drawing.Size(35, 37);
            this.lblReg.TabIndex = 12;
            this.lblReg.Text = "0";
            this.lblReg.Visible = false;
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ActualizarTodoTSMI,
            this.borrarToolStripMenuItem});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(158, 70);
            // 
            // ActualizarTodoTSMI
            // 
            this.ActualizarTodoTSMI.Name = "ActualizarTodoTSMI";
            this.ActualizarTodoTSMI.Size = new System.Drawing.Size(157, 22);
            this.ActualizarTodoTSMI.Text = "Actualizar Todo";
            // 
            // borrarToolStripMenuItem
            // 
            this.borrarToolStripMenuItem.Name = "borrarToolStripMenuItem";
            this.borrarToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.borrarToolStripMenuItem.Text = "Borrar";
            // 
            // Aplicaciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(618, 338);
            this.Controls.Add(this.lblReg);
            this.Controls.Add(this.dgvAplicaciones);
            this.Name = "Aplicaciones";
            this.Text = "Aplicaciones";
            this.Load += new System.EventHandler(this.Aplicaciones_Load);
            this.Resize += new System.EventHandler(this.Aplicaciones_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAplicaciones)).EndInit();
            this.cmMenu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvAplicaciones;
        private System.Windows.Forms.Label lblReg;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem ActualizarTodoTSMI;
        private System.Windows.Forms.ToolStripMenuItem borrarToolStripMenuItem;
    }
}