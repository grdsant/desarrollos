﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Seguridad
{
    public partial class Aplicaciones : Form
    {
        int dgvOffset;
        int dgvOffset2;

        public Aplicaciones()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvAplicaciones.Width;
            dgvOffset2 = this.Height - dgvAplicaciones.Height;
        }

        private void Aplicaciones_Resize(object sender, EventArgs e)
        {
            dgvAplicaciones.Width = this.Width - dgvOffset;
            dgvAplicaciones.Height = this.Height - dgvOffset2;
        }

        private void Aplicaciones_Load(object sender, EventArgs e)
        {
            BindAplicaciones();
        }

        protected void BindAplicaciones()
        {

            this.Cursor = Cursors.WaitCursor;

            dgvAplicaciones.DataSource = null;
            System.Data.DataTable Aplicaciones = null;
            try
            {
                Aplicaciones = MmsWin.Negocio.Seguridad.Aplicaciones.GetInstance().ObtenAplicaciones1();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (Aplicaciones.Rows.Count > 0)
            {
                dgvAplicaciones.DataSource = Aplicaciones;
                int nr = dgvAplicaciones.RowCount;
                lblReg.Text = (nr).ToString();
            }
            this.Cursor = Cursors.Default;
        }

        private void dgvAplicaciones_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                cmMenu.Visible = true;
            }
        }
    }
}
