﻿namespace MmsWin.Front.Seguridad
{
    partial class Controles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvControles = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ActualizarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.borrarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.tbControl = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbAplicacion = new System.Windows.Forms.TextBox();
            this.tbModulo = new System.Windows.Forms.TextBox();
            this.tbTipo = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvControles)).BeginInit();
            this.cmMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvControles
            // 
            this.dgvControles.AllowUserToAddRows = false;
            this.dgvControles.AllowUserToDeleteRows = false;
            this.dgvControles.AllowUserToOrderColumns = true;
            this.dgvControles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvControles.ContextMenuStrip = this.cmMenu;
            this.dgvControles.Location = new System.Drawing.Point(2, 30);
            this.dgvControles.Name = "dgvControles";
            this.dgvControles.Size = new System.Drawing.Size(1047, 351);
            this.dgvControles.TabIndex = 0;
            this.dgvControles.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvControles_CellMouseDown);
            this.dgvControles.CellMouseMove += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvControles_CellMouseMove);
            this.dgvControles.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dgvControles_MouseDown);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ActualizarTSMI,
            this.borrarTSMI});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(153, 70);
            // 
            // ActualizarTSMI
            // 
            this.ActualizarTSMI.Name = "ActualizarTSMI";
            this.ActualizarTSMI.Size = new System.Drawing.Size(152, 22);
            this.ActualizarTSMI.Text = "Actualizar";
            // 
            // borrarTSMI
            // 
            this.borrarTSMI.Name = "borrarTSMI";
            this.borrarTSMI.Size = new System.Drawing.Size(152, 22);
            this.borrarTSMI.Text = "Borrar";
            this.borrarTSMI.Click += new System.EventHandler(this.borrarTSMI_Click);
            // 
            // tbControl
            // 
            this.tbControl.Location = new System.Drawing.Point(44, 8);
            this.tbControl.Name = "tbControl";
            this.tbControl.Size = new System.Drawing.Size(209, 20);
            this.tbControl.TabIndex = 14;
            this.tbControl.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbControl_KeyPress);
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.Location = new System.Drawing.Point(253, 8);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(201, 20);
            this.tbDescripcion.TabIndex = 15;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress);
            // 
            // tbAplicacion
            // 
            this.tbAplicacion.Location = new System.Drawing.Point(454, 8);
            this.tbAplicacion.Name = "tbAplicacion";
            this.tbAplicacion.Size = new System.Drawing.Size(150, 20);
            this.tbAplicacion.TabIndex = 16;
            this.tbAplicacion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbAplicacion_KeyPress);
            // 
            // tbModulo
            // 
            this.tbModulo.Location = new System.Drawing.Point(604, 8);
            this.tbModulo.Name = "tbModulo";
            this.tbModulo.Size = new System.Drawing.Size(149, 20);
            this.tbModulo.TabIndex = 17;
            this.tbModulo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbModulo_KeyPress);
            // 
            // tbTipo
            // 
            this.tbTipo.Location = new System.Drawing.Point(753, 8);
            this.tbTipo.Name = "tbTipo";
            this.tbTipo.Size = new System.Drawing.Size(70, 20);
            this.tbTipo.TabIndex = 18;
            this.tbTipo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTipo_KeyPress);
            // 
            // Controles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1049, 387);
            this.Controls.Add(this.tbTipo);
            this.Controls.Add(this.tbModulo);
            this.Controls.Add(this.tbAplicacion);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.tbControl);
            this.Controls.Add(this.dgvControles);
            this.Name = "Controles";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Controles";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Controles_FormClosing);
            this.Load += new System.EventHandler(this.Controles_Load);
            this.Resize += new System.EventHandler(this.Controles_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvControles)).EndInit();
            this.cmMenu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvControles;
        private System.Windows.Forms.TextBox tbControl;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbAplicacion;
        private System.Windows.Forms.TextBox tbModulo;
        private System.Windows.Forms.TextBox tbTipo;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem ActualizarTSMI;
        private System.Windows.Forms.ToolStripMenuItem borrarTSMI;
    }
}