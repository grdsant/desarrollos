﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Seguridad
{
    public partial class Controles : Form
    {

        string ParUser;
        string control;
        string descripcion;
        string aplicacion;
        string modulo;
        string tipo;

        int dgvOffset;
        int dgvOffset2;

        public Controles()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvControles.Width;
            dgvOffset2 = this.Height - dgvControles.Height;
        }

        private void Controles_Resize(object sender, EventArgs e)
        {
            dgvControles.Width = this.Width - dgvOffset;
            dgvControles.Height = this.Height - dgvOffset2;
        }

        private void Controles_Load(object sender, EventArgs e)
        {
            BindControles();
            SetFontAndColors();
            rowStyle();
        }

        // Seguridad                                                                                        
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                                     
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvControles.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvControles.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenu.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenu.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        protected void BindControles()
        {

            this.Cursor = Cursors.WaitCursor;

            dgvControles.DataSource = null;
            System.Data.DataTable Controles = null;
            try
            {
                control = tbControl.Text;
                descripcion = tbDescripcion.Text;
                aplicacion = tbAplicacion.Text;
                modulo = tbModulo.Text;
                tipo = tbTipo.Text;
                Controles = MmsWin.Negocio.Seguridad.Controles.GetInstance().ObtenControles1(control, descripcion, aplicacion, modulo, tipo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (Controles.Rows.Count > 0)
            {
                dgvControles.DataSource = Controles;
                int nr = dgvControles.RowCount;
                this.Text = (nr).ToString() + " " + "Controles";
                
                SetFontAndColors();
                rowStyle();

                // Seguridad...                                                                     
                ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                Seguridad("Seguridad", "Controles", ParUser);

                SetDoubleBuffered(dgvControles);

            }
            this.Cursor = Cursors.Default;
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        private void SetFontAndColors()
        {
            this.dgvControles.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvControles.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvControles.EnableHeadersVisualStyles = false;
            this.dgvControles.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvControles.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvControles.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvControles.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvControles.RowsDefaultCellStyle.ForeColor = Color.Black;
         //  this.dgvControles.Columns[3].Frozen = true;

            dgvControles.Columns[0].HeaderText = "Control";
            dgvControles.Columns[1].HeaderText = "Descripción";
            dgvControles.Columns[2].HeaderText = "Aplicación";
            dgvControles.Columns[3].HeaderText = "Módulo";
            dgvControles.Columns[4].HeaderText = "Tipo";
            dgvControles.Columns[5].HeaderText = "Fecha";
            dgvControles.Columns[6].HeaderText = "Hora";
            dgvControles.Columns[7].HeaderText = "Estatus";

            dgvControles.Columns[0].Width = 210;
            dgvControles.Columns[1].Width = 200;
            dgvControles.Columns[2].Width = 150;
            dgvControles.Columns[3].Width = 150;
            dgvControles.Columns[4].Width = 70;
            dgvControles.Columns[5].Width = 80;
            dgvControles.Columns[6].Width = 80;
            dgvControles.Columns[7].Width = 50;

            dgvControles.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvControles.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvControles.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvControles.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvControles.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvControles.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvControles.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvControles.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvControles.Columns[5].DefaultCellStyle.Format = "20##-##-##";
            dgvControles.Columns[6].DefaultCellStyle.Format = "##:##:##";

            dgvControles.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvControles.Columns[1].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvControles.Columns[2].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvControles.Columns[3].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvControles.Columns[4].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvControles.Columns[5].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvControles.Columns[6].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvControles.Columns[7].HeaderCell.Style.BackColor = Color.LightSlateGray;
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvControles.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvControles.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }
        // Copy Fuente                                                                      
        //
        private void dgvControles_MouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                string valorcelda = "";
                MmsWin.Front.Utilerias.VarTem.tmpAplicacion = "";
                MmsWin.Front.Utilerias.VarTem.tmpModulo = "";

                DataGridView.HitTestInfo info = dgvControles.HitTest(e.X, e.Y);

                // buscar fila bajo el Mouse
                if (e.Button == MouseButtons.Left)
                {
                    try
                    {
                        if (dgvControles.Rows[info.RowIndex].Cells[info.ColumnIndex].Value != null)
                        {
                            //    valorcelda = dgvControles.Rows[info.RowIndex].Cells[info.ColumnIndex].Value.ToString();
                            valorcelda = dgvControles.Rows[info.RowIndex].Cells[0].Value.ToString();
                            MmsWin.Front.Utilerias.VarTem.tmpAplicacion  = dgvControles.Rows[info.RowIndex].Cells[2].Value.ToString();
                            MmsWin.Front.Utilerias.VarTem.tmpModulo  = dgvControles.Rows[info.RowIndex].Cells[3].Value.ToString();
 
                            dgvControles.DoDragDrop(valorcelda, DragDropEffects.Copy);
                        }
                    }
                    catch 
                    {
                        
                    }
                }
            }
            finally {}
        }
        // DoDragDrop                                                                       
        //
        private void dgvControles_CellMouseMove(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.dgvControles.DoDragDrop(this.dgvControles.CurrentRow, DragDropEffects.All);
            }
        }

        private void dgvControles_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                cmMenu.Visible = true;
            }
        }

        private void tbControl_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindControles();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindControles();
            }
        }

        private void tbAplicacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindControles();
            }
        }

        private void tbModulo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindControles();
            }
        }

        private void tbTipo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindControles();
            }
        }

        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            //
            string NomCol;
            Int32 NoCol = dgvControles.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvControles.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      
            //
            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void Controles_FormClosing(object sender, FormClosingEventArgs e)
        {
            CargaSeguridad("Seguridad", "Controles", ParUser);
        }

        private void borrarTSMI_Click(object sender, EventArgs e)
        {

        }
    }
}
