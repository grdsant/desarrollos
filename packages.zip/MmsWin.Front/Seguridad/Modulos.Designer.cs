﻿namespace MmsWin.Front.Seguridad
{
    partial class Modulos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvModulos = new System.Windows.Forms.DataGridView();
            this.lblReg = new System.Windows.Forms.Label();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ActualizarTodoTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.borrarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dgvModulos)).BeginInit();
            this.cmMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvModulos
            // 
            this.dgvModulos.AllowUserToAddRows = false;
            this.dgvModulos.AllowUserToDeleteRows = false;
            this.dgvModulos.AllowUserToOrderColumns = true;
            this.dgvModulos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvModulos.ContextMenuStrip = this.cmMenu;
            this.dgvModulos.Location = new System.Drawing.Point(12, 47);
            this.dgvModulos.Name = "dgvModulos";
            this.dgvModulos.ReadOnly = true;
            this.dgvModulos.Size = new System.Drawing.Size(741, 203);
            this.dgvModulos.TabIndex = 0;
            this.dgvModulos.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvModulos_CellMouseDown);
            // 
            // lblReg
            // 
            this.lblReg.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.lblReg.AutoSize = true;
            this.lblReg.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReg.Location = new System.Drawing.Point(715, 7);
            this.lblReg.Name = "lblReg";
            this.lblReg.Size = new System.Drawing.Size(35, 37);
            this.lblReg.TabIndex = 14;
            this.lblReg.Text = "0";
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ActualizarTodoTSMI,
            this.borrarTSMI});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(158, 48);
            // 
            // ActualizarTodoTSMI
            // 
            this.ActualizarTodoTSMI.Name = "ActualizarTodoTSMI";
            this.ActualizarTodoTSMI.Size = new System.Drawing.Size(157, 22);
            this.ActualizarTodoTSMI.Text = "Actualizar Todo";
            // 
            // borrarTSMI
            // 
            this.borrarTSMI.Name = "borrarTSMI";
            this.borrarTSMI.Size = new System.Drawing.Size(157, 22);
            this.borrarTSMI.Text = "Borrar";
            // 
            // Modulos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(762, 262);
            this.ContextMenuStrip = this.cmMenu;
            this.Controls.Add(this.dgvModulos);
            this.Controls.Add(this.lblReg);
            this.Name = "Modulos";
            this.Text = "Modulos";
            this.Load += new System.EventHandler(this.Modulos_Load);
            this.Resize += new System.EventHandler(this.Modulos_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvModulos)).EndInit();
            this.cmMenu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvModulos;
        private System.Windows.Forms.Label lblReg;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem ActualizarTodoTSMI;
        private System.Windows.Forms.ToolStripMenuItem borrarTSMI;
    }
}