﻿namespace MmsWin.Front.Seguridad
{
    partial class SegMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SegMain));
            this.pbUsuarios = new System.Windows.Forms.PictureBox();
            this.pbAplicaciones = new System.Windows.Forms.PictureBox();
            this.pbControles = new System.Windows.Forms.PictureBox();
            this.pbPerfiles = new System.Windows.Forms.PictureBox();
            this.pbModulos = new System.Windows.Forms.PictureBox();
            this.lblUsuarios = new System.Windows.Forms.Label();
            this.lblAplicaciones = new System.Windows.Forms.Label();
            this.lblControles = new System.Windows.Forms.Label();
            this.lblPerfiles = new System.Windows.Forms.Label();
            this.lblModulos = new System.Windows.Forms.Label();
            this.lblAplicacion = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbUsuarios)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAplicaciones)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbControles)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPerfiles)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbModulos)).BeginInit();
            this.SuspendLayout();
            // 
            // pbUsuarios
            // 
            this.pbUsuarios.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbUsuarios.Image = ((System.Drawing.Image)(resources.GetObject("pbUsuarios.Image")));
            this.pbUsuarios.Location = new System.Drawing.Point(12, 109);
            this.pbUsuarios.Name = "pbUsuarios";
            this.pbUsuarios.Size = new System.Drawing.Size(207, 124);
            this.pbUsuarios.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbUsuarios.TabIndex = 1;
            this.pbUsuarios.TabStop = false;
            this.pbUsuarios.Click += new System.EventHandler(this.pbUsuarios_Click);
            // 
            // pbAplicaciones
            // 
            this.pbAplicaciones.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbAplicaciones.Image = ((System.Drawing.Image)(resources.GetObject("pbAplicaciones.Image")));
            this.pbAplicaciones.Location = new System.Drawing.Point(469, 186);
            this.pbAplicaciones.Name = "pbAplicaciones";
            this.pbAplicaciones.Size = new System.Drawing.Size(207, 124);
            this.pbAplicaciones.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbAplicaciones.TabIndex = 2;
            this.pbAplicaciones.TabStop = false;
            this.pbAplicaciones.Click += new System.EventHandler(this.pbAplicaciones_Click);
            // 
            // pbControles
            // 
            this.pbControles.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbControles.Image = ((System.Drawing.Image)(resources.GetObject("pbControles.Image")));
            this.pbControles.Location = new System.Drawing.Point(241, 25);
            this.pbControles.Name = "pbControles";
            this.pbControles.Size = new System.Drawing.Size(207, 124);
            this.pbControles.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbControles.TabIndex = 3;
            this.pbControles.TabStop = false;
            this.pbControles.Click += new System.EventHandler(this.pbControles_Click);
            // 
            // pbPerfiles
            // 
            this.pbPerfiles.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbPerfiles.Image = ((System.Drawing.Image)(resources.GetObject("pbPerfiles.Image")));
            this.pbPerfiles.Location = new System.Drawing.Point(241, 186);
            this.pbPerfiles.Name = "pbPerfiles";
            this.pbPerfiles.Size = new System.Drawing.Size(207, 124);
            this.pbPerfiles.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPerfiles.TabIndex = 4;
            this.pbPerfiles.TabStop = false;
            this.pbPerfiles.Click += new System.EventHandler(this.pbPerfiles_Click);
            // 
            // pbModulos
            // 
            this.pbModulos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbModulos.Image = ((System.Drawing.Image)(resources.GetObject("pbModulos.Image")));
            this.pbModulos.Location = new System.Drawing.Point(470, 25);
            this.pbModulos.Name = "pbModulos";
            this.pbModulos.Size = new System.Drawing.Size(207, 124);
            this.pbModulos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbModulos.TabIndex = 5;
            this.pbModulos.TabStop = false;
            this.pbModulos.Click += new System.EventHandler(this.pbModulos_Click);
            // 
            // lblUsuarios
            // 
            this.lblUsuarios.AutoSize = true;
            this.lblUsuarios.BackColor = System.Drawing.Color.Transparent;
            this.lblUsuarios.ForeColor = System.Drawing.Color.White;
            this.lblUsuarios.Location = new System.Drawing.Point(93, 236);
            this.lblUsuarios.Name = "lblUsuarios";
            this.lblUsuarios.Size = new System.Drawing.Size(48, 13);
            this.lblUsuarios.TabIndex = 12;
            this.lblUsuarios.Text = "Usuarios";
            // 
            // lblAplicaciones
            // 
            this.lblAplicaciones.AutoSize = true;
            this.lblAplicaciones.BackColor = System.Drawing.Color.Transparent;
            this.lblAplicaciones.ForeColor = System.Drawing.Color.White;
            this.lblAplicaciones.Location = new System.Drawing.Point(-148, -14);
            this.lblAplicaciones.Name = "lblAplicaciones";
            this.lblAplicaciones.Size = new System.Drawing.Size(67, 13);
            this.lblAplicaciones.TabIndex = 13;
            this.lblAplicaciones.Text = "Aplicaciones";
            // 
            // lblControles
            // 
            this.lblControles.AutoSize = true;
            this.lblControles.BackColor = System.Drawing.Color.Transparent;
            this.lblControles.ForeColor = System.Drawing.Color.White;
            this.lblControles.Location = new System.Drawing.Point(314, 152);
            this.lblControles.Name = "lblControles";
            this.lblControles.Size = new System.Drawing.Size(51, 13);
            this.lblControles.TabIndex = 14;
            this.lblControles.Text = "Controles";
            // 
            // lblPerfiles
            // 
            this.lblPerfiles.AutoSize = true;
            this.lblPerfiles.BackColor = System.Drawing.Color.Transparent;
            this.lblPerfiles.ForeColor = System.Drawing.Color.White;
            this.lblPerfiles.Location = new System.Drawing.Point(326, 313);
            this.lblPerfiles.Name = "lblPerfiles";
            this.lblPerfiles.Size = new System.Drawing.Size(41, 13);
            this.lblPerfiles.TabIndex = 15;
            this.lblPerfiles.Text = "Perfiles";
            // 
            // lblModulos
            // 
            this.lblModulos.AutoSize = true;
            this.lblModulos.BackColor = System.Drawing.Color.Transparent;
            this.lblModulos.ForeColor = System.Drawing.Color.White;
            this.lblModulos.Location = new System.Drawing.Point(543, 152);
            this.lblModulos.Name = "lblModulos";
            this.lblModulos.Size = new System.Drawing.Size(47, 13);
            this.lblModulos.TabIndex = 20;
            this.lblModulos.Text = "Módulos";
            // 
            // lblAplicacion
            // 
            this.lblAplicacion.AutoSize = true;
            this.lblAplicacion.BackColor = System.Drawing.Color.Transparent;
            this.lblAplicacion.ForeColor = System.Drawing.Color.White;
            this.lblAplicacion.Location = new System.Drawing.Point(543, 313);
            this.lblAplicacion.Name = "lblAplicacion";
            this.lblAplicacion.Size = new System.Drawing.Size(67, 13);
            this.lblAplicacion.TabIndex = 21;
            this.lblAplicacion.Text = "Aplicaciones";
            // 
            // SegMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(695, 339);
            this.Controls.Add(this.lblAplicacion);
            this.Controls.Add(this.lblModulos);
            this.Controls.Add(this.lblPerfiles);
            this.Controls.Add(this.lblControles);
            this.Controls.Add(this.lblAplicaciones);
            this.Controls.Add(this.lblUsuarios);
            this.Controls.Add(this.pbModulos);
            this.Controls.Add(this.pbPerfiles);
            this.Controls.Add(this.pbControles);
            this.Controls.Add(this.pbAplicaciones);
            this.Controls.Add(this.pbUsuarios);
            this.MaximizeBox = false;
            this.Name = "SegMain";
            this.Opacity = 0.9D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Seguridad";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SegMain_FormClosing);
            this.Load += new System.EventHandler(this.SegMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbUsuarios)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbAplicaciones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbControles)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPerfiles)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbModulos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbUsuarios;
        private System.Windows.Forms.PictureBox pbAplicaciones;
        private System.Windows.Forms.PictureBox pbControles;
        private System.Windows.Forms.PictureBox pbPerfiles;
        private System.Windows.Forms.PictureBox pbModulos;
        private System.Windows.Forms.Label lblUsuarios;
        private System.Windows.Forms.Label lblAplicaciones;
        private System.Windows.Forms.Label lblControles;
        private System.Windows.Forms.Label lblPerfiles;
        private System.Windows.Forms.Label lblModulos;
        private System.Windows.Forms.Label lblAplicacion;
    }
}