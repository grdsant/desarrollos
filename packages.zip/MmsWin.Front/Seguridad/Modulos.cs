﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Seguridad
{
    public partial class Modulos : Form
    {
        int dgvOffset;
        int dgvOffset2;

        public Modulos()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvModulos.Width;
            dgvOffset2 = this.Height - dgvModulos.Height;
        }

        private void Modulos_Resize(object sender, EventArgs e)
        {
            dgvModulos.Width = this.Width - dgvOffset;
            dgvModulos.Height = this.Height - dgvOffset2;
        }

        private void Modulos_Load(object sender, EventArgs e)
        {
            BindModulos();
        }

        protected void BindModulos()
        {

            this.Cursor = Cursors.WaitCursor;

            dgvModulos.DataSource = null;
            System.Data.DataTable Modulos = null;
            try
            {
                Modulos = MmsWin.Negocio.Seguridad.Modulos.GetInstance().ObtenModulos1();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (Modulos.Rows.Count > 0)
            {
                dgvModulos.DataSource = Modulos;
                int nr = dgvModulos.RowCount;
                lblReg.Text = (nr).ToString();
            }
            this.Cursor = Cursors.Default;
        }

        private void dgvModulos_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
       //         var hti = dgvModulos.HitTest(e.X, e.Y);
       //         int Row = e.RowIndex;
       //         int Col = e.ColumnIndex;
       //         MmsWin.Front.Utilerias.Fotos.numPrv = this.dgvModulos.CurrentRow.Cells[0].Value.ToString();
       //         MmsWin.Front.Utilerias.Fotos.numSty = this.dgvModulos.CurrentRow.Cells[2].Value.ToString();
                cmMenu.Visible = true;
            }
        }
    }
}
