﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Seguridad
{
    public partial class Usuarios : Form
    {

        string ParUser;
        string usuario;
        string nombre;
        string password;
        string nivel;
        string marca;
        string descripcion;
        string comprador;
        string correo;
        string perfil;

        int dgvOffset;
        int dgvOffset2;

        public Usuarios()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvUsuarios.Width;
            dgvOffset2 = this.Height - dgvUsuarios.Height;
        }

        private void Usuarios_Resize(object sender, EventArgs e)
        {
            dgvUsuarios.Width = this.Width - dgvOffset;
            dgvUsuarios.Height = this.Height - dgvOffset2;
        }

        private void Usuarios_Load(object sender, EventArgs e)
        {
            BindUsuarios();
            SetFontAndColors();
            rowStyle();

            // Seguridad...                                                                     
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("Seguridad", "Usuarios", ParUser);
        }

        // Seguridad                                                                                        
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                                     
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvUsuarios.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvUsuarios.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenu.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenu.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        protected void BindUsuarios()
        {

            this.Cursor = Cursors.WaitCursor;

            dgvUsuarios.DataSource = null;
            System.Data.DataTable Usuarios = null;
            try
            {
                usuario = tbUsuario.Text;
                nombre = tbNombre.Text;
                password = tbPassword.Text;
                nivel = tbNivel.Text;
                marca = tbMarca.Text;
                descripcion = tbDescripcion.Text;
                comprador = tbComprador.Text;
                correo = tbCorreo.Text;
                perfil = tbPerfil.Text;
                Usuarios = MmsWin.Negocio.Seguridad.Usuarios.GetInstance().ObtenUsuarios1(usuario, nombre, password, nivel, marca, descripcion, comprador, correo, perfil);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (Usuarios.Rows.Count > 0)
            {
                dgvUsuarios.DataSource = Usuarios;
                int nr = dgvUsuarios.RowCount;
             //   lblReg.Text = (nr).ToString();
                this.Text = (nr).ToString() + " " + "Usuarios";
                SetFontAndColors();
                rowStyle();
                SetDoubleBuffered(dgvUsuarios);
            }
            this.Cursor = Cursors.Default;
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        private void SetFontAndColors()
        {
            this.dgvUsuarios.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvUsuarios.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvUsuarios.EnableHeadersVisualStyles = false;
            this.dgvUsuarios.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvUsuarios.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvUsuarios.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvUsuarios.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvUsuarios.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvUsuarios.Columns[3].Frozen = true;

            dgvUsuarios.Columns[0].HeaderText = "Usuario";
            dgvUsuarios.Columns[1].HeaderText = "Nombre";
            dgvUsuarios.Columns[2].HeaderText = "Password";
            dgvUsuarios.Columns[3].HeaderText = "Nivel";
            dgvUsuarios.Columns[4].HeaderText = "Marca";
            dgvUsuarios.Columns[5].HeaderText = "Descripcion";
            dgvUsuarios.Columns[6].HeaderText = "Comprador";
            dgvUsuarios.Columns[7].HeaderText = "Compradores";
            dgvUsuarios.Columns[8].HeaderText = "Perfil";
            dgvUsuarios.Columns[9].HeaderText = "Fecha";
            dgvUsuarios.Columns[10].HeaderText = "Hora";
            dgvUsuarios.Columns[11].HeaderText = "Estatus";

            dgvUsuarios.Columns[12].Visible = false;
            dgvUsuarios.Columns[13].Visible = false;

            dgvUsuarios.Columns[0].Width = 80;
            dgvUsuarios.Columns[1].Width = 200;
            dgvUsuarios.Columns[2].Width = 80;
            dgvUsuarios.Columns[3].Width = 100;
            dgvUsuarios.Columns[4].Width = 50;
            dgvUsuarios.Columns[5].Width = 100;
            dgvUsuarios.Columns[6].Width = 50;
            dgvUsuarios.Columns[7].Width = 200;
            dgvUsuarios.Columns[8].Width = 100;
            dgvUsuarios.Columns[9].Width = 90;
            dgvUsuarios.Columns[10].Width = 90;
            dgvUsuarios.Columns[11].Width = 50;

            dgvUsuarios.Columns[0].DefaultCellStyle.NullValue = true;
            dgvUsuarios.Columns[1].DefaultCellStyle.NullValue = true;
            dgvUsuarios.Columns[2].DefaultCellStyle.NullValue = true;
            dgvUsuarios.Columns[3].DefaultCellStyle.NullValue = true;
            dgvUsuarios.Columns[4].DefaultCellStyle.NullValue = true;
            dgvUsuarios.Columns[5].DefaultCellStyle.NullValue = true;
            dgvUsuarios.Columns[6].DefaultCellStyle.NullValue = true;
            dgvUsuarios.Columns[7].DefaultCellStyle.NullValue = true;
            dgvUsuarios.Columns[8].DefaultCellStyle.NullValue = true;
            dgvUsuarios.Columns[9].DefaultCellStyle.NullValue = true;
            dgvUsuarios.Columns[10].DefaultCellStyle.NullValue = true;
            dgvUsuarios.Columns[11].DefaultCellStyle.NullValue = true;

            dgvUsuarios.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvUsuarios.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvUsuarios.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvUsuarios.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvUsuarios.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvUsuarios.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvUsuarios.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvUsuarios.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvUsuarios.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvUsuarios.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvUsuarios.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvUsuarios.Columns[11].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;


            dgvUsuarios.Columns[5].DefaultCellStyle.Format = "20##-##-##";
            dgvUsuarios.Columns[6].DefaultCellStyle.Format = "##:##:##";

            dgvUsuarios.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvUsuarios.Columns[1].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvUsuarios.Columns[2].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvUsuarios.Columns[3].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvUsuarios.Columns[4].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvUsuarios.Columns[5].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvUsuarios.Columns[6].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvUsuarios.Columns[7].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvUsuarios.Columns[8].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvUsuarios.Columns[9].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvUsuarios.Columns[10].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvUsuarios.Columns[11].HeaderCell.Style.BackColor = Color.LightSlateGray;
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvUsuarios.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvUsuarios.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }

        private void dgvUsuarios_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }

        private void dgvUsuarios_DragDrop(object sender, DragEventArgs e)
        {
            try
            {
                string valornuevo = Convert.ToString(e.Data.GetData(DataFormats.StringFormat));

                // calcular ubicacion del Mouse en coordenadas relativas a la grilla          
                Point gridDrop = dgvUsuarios.PointToClient(new Point(e.X, e.Y));

                // buscar fila bajo el Mouse                                                  
                int rowDrop = dgvUsuarios.HitTest(gridDrop.X, gridDrop.Y).RowIndex;
                int colDrop = dgvUsuarios.HitTest(gridDrop.X, gridDrop.Y).ColumnIndex;
                dgvUsuarios.Rows[rowDrop].Cells[colDrop].Value = valornuevo;
                valornuevo = "";
            }
            catch { }
            finally { }
        }

        private void dgvUsuarios_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                var hti = dgvUsuarios.HitTest(e.X, e.Y);
                int Row = e.RowIndex;
                int Col = e.ColumnIndex;

                cmMenu.Visible = true;
            }
        }
        // Actualizar DataGRidView                                                                
        //
        private void ActualizarTSMI_Click(object sender, EventArgs e)
        {
            ActualizaUsuario();
        }

        private void ActualizaUsuario()
        {
            System.Data.DataTable dtUsuario = new System.Data.DataTable("Usuario");
            dtUsuario.Columns.Add("Usuario", typeof(String));
            dtUsuario.Columns.Add("Nombre", typeof(String));
            dtUsuario.Columns.Add("Password", typeof(String));
            dtUsuario.Columns.Add("Nivel", typeof(String));
            dtUsuario.Columns.Add("Marca", typeof(String));
            dtUsuario.Columns.Add("Descripcion", typeof(String));
            dtUsuario.Columns.Add("Comprador", typeof(String));
            dtUsuario.Columns.Add("Correo", typeof(String));
            dtUsuario.Columns.Add("Perfil", typeof(String));
            dtUsuario.Columns.Add("Fecha", typeof(String));
            dtUsuario.Columns.Add("Hora", typeof(String));
            dtUsuario.Columns.Add("Estatus", typeof(String));
            dtUsuario.Columns.Add("UsuarioB", typeof(String));
            dtUsuario.Columns.Add("PerfilB", typeof(String));

            DataGridViewSelectedRowCollection Seleccionados = dgvUsuarios.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                DataRow workRow = dtUsuario.NewRow();
                workRow["Usuario"] = item.Cells[0].Value.ToString();
                workRow["Nombre"] = item.Cells[1].Value.ToString();
                workRow["Password"] = item.Cells[2].Value.ToString();
                workRow["Nivel"] = item.Cells[3].Value.ToString();
                workRow["Marca"] = item.Cells[4].Value.ToString();
                workRow["Descripcion"] = item.Cells[5].Value.ToString();
                workRow["Comprador"] = item.Cells[6].Value.ToString();
                workRow["Correo"] = item.Cells[7].Value.ToString();
                workRow["Perfil"] = item.Cells[8].Value.ToString();
                workRow["Fecha"] = item.Cells[9].Value.ToString();
                workRow["Hora"] = item.Cells[10].Value.ToString();
                workRow["Estatus"] = item.Cells[11].Value.ToString();
                workRow["UsuarioB"] = item.Cells[12].Value.ToString();
                workRow["PerfilB"] = item.Cells[13].Value.ToString();

                dtUsuario.Rows.Add(workRow);
            }
            MmsWin.Negocio.Seguridad.Usuarios.GetInstance().UpdateUsuario(dtUsuario);
            BindUsuarios();
            MessageBox.Show("Actualizacion completa...");
            BindUsuarios();
        }
        // Borra usuarios                                                                              
        //
        private void dgvUsuarios_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            MessageBox.Show("Borrar");
        }

        private void dgvUsuarios_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
         //   MessageBox.Show("mensaje de error");

        }

        private void nuevoTSMI_Click(object sender, EventArgs e)
        {
            AltaUsuario();
            BindUsuarios();
        }

        private void pbNuevo_Click(object sender, EventArgs e)
        {
            AltaUsuario();
        }

        private void AltaUsuario()
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "AltaUsuario").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana de Alta de Usuario ya esta abierta");
                    }
                    else
                    {
                        AltaUsuario i = new AltaUsuario();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void dgvUsuarios_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F6)
            {
                AltaUsuario();
            }
            if (e.KeyCode == Keys.F5)
            {
                BindUsuarios();
            }
            
        }

        private void tbUsuario_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindUsuarios();
            }
        }

        private void tbNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindUsuarios();
            }
        }

        private void tbPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindUsuarios();
            }
        }

        private void tbNivel_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindUsuarios();
            }
        }

        private void tbMarca_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindUsuarios();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindUsuarios();
            }
        }

        private void tbComprador_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindUsuarios();
            }
        }

        private void tbCorreo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindUsuarios();
            }
        }

        private void tbPerfil_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindUsuarios();
            }
        }

        private void eliminarTSMI_Click(object sender, EventArgs e)
        {
            string usuario;
            string perfil;
            string message = "Corfirmar la Eliminación del Registro";
            string caption = "Advertencia...";
            DataGridViewSelectedRowCollection Seleccionados = dgvUsuarios.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                usuario = item.Cells[0].Value.ToString();
                perfil = item.Cells[8].Value.ToString();

                message = "Confirma la Eliminacion de usuario:" + usuario + " con el Perfil : " + perfil;
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;
                result = MessageBox.Show(message, caption, buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    MmsWin.Negocio.Seguridad.Usuarios.GetInstance().EliminaUsuario(usuario, perfil);
                    MessageBox.Show("Usuario Eliminado...");
                }
            }

            BindUsuarios();
        }

        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            //
            string NomCol;
            Int32 NoCol = dgvUsuarios.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvUsuarios.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      
            //
            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void Usuarios_FormClosing(object sender, FormClosingEventArgs e)
        {
            CargaSeguridad("Seguridad", "Usuarios", ParUser);
        }

    }
}
