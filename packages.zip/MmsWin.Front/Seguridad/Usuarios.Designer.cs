﻿namespace MmsWin.Front.Seguridad
{
    partial class Usuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Usuarios));
            this.dgvUsuarios = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.nuevoTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.ActualizarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.tbUsuario = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbPassword = new System.Windows.Forms.TextBox();
            this.tbNivel = new System.Windows.Forms.TextBox();
            this.tbMarca = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbComprador = new System.Windows.Forms.TextBox();
            this.tbCorreo = new System.Windows.Forms.TextBox();
            this.tbPerfil = new System.Windows.Forms.TextBox();
            this.pbNuevo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsuarios)).BeginInit();
            this.cmMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbNuevo)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvUsuarios
            // 
            this.dgvUsuarios.AllowDrop = true;
            this.dgvUsuarios.AllowUserToAddRows = false;
            this.dgvUsuarios.AllowUserToOrderColumns = true;
            this.dgvUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvUsuarios.ContextMenuStrip = this.cmMenu;
            this.dgvUsuarios.Location = new System.Drawing.Point(12, 27);
            this.dgvUsuarios.Name = "dgvUsuarios";
            this.dgvUsuarios.ShowCellErrors = false;
            this.dgvUsuarios.Size = new System.Drawing.Size(1160, 355);
            this.dgvUsuarios.TabIndex = 0;
            this.dgvUsuarios.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvUsuarios_CellMouseDown);
            this.dgvUsuarios.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvUsuarios_DataError);
            this.dgvUsuarios.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.dgvUsuarios_UserDeletingRow);
            this.dgvUsuarios.DragDrop += new System.Windows.Forms.DragEventHandler(this.dgvUsuarios_DragDrop);
            this.dgvUsuarios.DragEnter += new System.Windows.Forms.DragEventHandler(this.dgvUsuarios_DragEnter);
            this.dgvUsuarios.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvUsuarios_KeyUp);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevoTSMI,
            this.ActualizarTSMI,
            this.eliminarTSMI});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(127, 70);
            // 
            // nuevoTSMI
            // 
            this.nuevoTSMI.Name = "nuevoTSMI";
            this.nuevoTSMI.Size = new System.Drawing.Size(126, 22);
            this.nuevoTSMI.Text = "Nuevo";
            this.nuevoTSMI.Click += new System.EventHandler(this.nuevoTSMI_Click);
            // 
            // ActualizarTSMI
            // 
            this.ActualizarTSMI.Name = "ActualizarTSMI";
            this.ActualizarTSMI.Size = new System.Drawing.Size(126, 22);
            this.ActualizarTSMI.Text = "Actualizar";
            this.ActualizarTSMI.Click += new System.EventHandler(this.ActualizarTSMI_Click);
            // 
            // eliminarTSMI
            // 
            this.eliminarTSMI.Name = "eliminarTSMI";
            this.eliminarTSMI.Size = new System.Drawing.Size(126, 22);
            this.eliminarTSMI.Text = "Eliminar";
            this.eliminarTSMI.Click += new System.EventHandler(this.eliminarTSMI_Click);
            // 
            // tbUsuario
            // 
            this.tbUsuario.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbUsuario.Location = new System.Drawing.Point(53, 6);
            this.tbUsuario.Name = "tbUsuario";
            this.tbUsuario.Size = new System.Drawing.Size(81, 20);
            this.tbUsuario.TabIndex = 12;
            this.tbUsuario.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUsuario_KeyPress);
            // 
            // tbNombre
            // 
            this.tbNombre.Location = new System.Drawing.Point(135, 6);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(199, 20);
            this.tbNombre.TabIndex = 13;
            this.tbNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNombre_KeyPress);
            // 
            // tbPassword
            // 
            this.tbPassword.Location = new System.Drawing.Point(335, 6);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.Size = new System.Drawing.Size(78, 20);
            this.tbPassword.TabIndex = 14;
            this.tbPassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbPassword_KeyPress);
            // 
            // tbNivel
            // 
            this.tbNivel.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNivel.Location = new System.Drawing.Point(414, 6);
            this.tbNivel.Name = "tbNivel";
            this.tbNivel.Size = new System.Drawing.Size(100, 20);
            this.tbNivel.TabIndex = 15;
            this.tbNivel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNivel_KeyPress);
            // 
            // tbMarca
            // 
            this.tbMarca.Location = new System.Drawing.Point(515, 6);
            this.tbMarca.Name = "tbMarca";
            this.tbMarca.Size = new System.Drawing.Size(48, 20);
            this.tbMarca.TabIndex = 16;
            this.tbMarca.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbMarca_KeyPress);
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.Location = new System.Drawing.Point(564, 6);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(98, 20);
            this.tbDescripcion.TabIndex = 17;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress);
            // 
            // tbComprador
            // 
            this.tbComprador.Location = new System.Drawing.Point(663, 6);
            this.tbComprador.Name = "tbComprador";
            this.tbComprador.Size = new System.Drawing.Size(50, 20);
            this.tbComprador.TabIndex = 18;
            this.tbComprador.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbComprador_KeyPress);
            // 
            // tbCorreo
            // 
            this.tbCorreo.Location = new System.Drawing.Point(714, 6);
            this.tbCorreo.Name = "tbCorreo";
            this.tbCorreo.Size = new System.Drawing.Size(199, 20);
            this.tbCorreo.TabIndex = 19;
            this.tbCorreo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCorreo_KeyPress);
            // 
            // tbPerfil
            // 
            this.tbPerfil.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbPerfil.Location = new System.Drawing.Point(914, 6);
            this.tbPerfil.Name = "tbPerfil";
            this.tbPerfil.Size = new System.Drawing.Size(100, 20);
            this.tbPerfil.TabIndex = 20;
            this.tbPerfil.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbPerfil_KeyPress);
            // 
            // pbNuevo
            // 
            this.pbNuevo.Image = ((System.Drawing.Image)(resources.GetObject("pbNuevo.Image")));
            this.pbNuevo.Location = new System.Drawing.Point(13, 0);
            this.pbNuevo.Name = "pbNuevo";
            this.pbNuevo.Size = new System.Drawing.Size(25, 26);
            this.pbNuevo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbNuevo.TabIndex = 21;
            this.pbNuevo.TabStop = false;
            this.pbNuevo.Click += new System.EventHandler(this.pbNuevo_Click);
            // 
            // Usuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1181, 391);
            this.Controls.Add(this.pbNuevo);
            this.Controls.Add(this.tbPerfil);
            this.Controls.Add(this.tbCorreo);
            this.Controls.Add(this.tbComprador);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.tbMarca);
            this.Controls.Add(this.tbNivel);
            this.Controls.Add(this.tbPassword);
            this.Controls.Add(this.tbNombre);
            this.Controls.Add(this.tbUsuario);
            this.Controls.Add(this.dgvUsuarios);
            this.Name = "Usuarios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Usuarios";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Usuarios_FormClosing);
            this.Load += new System.EventHandler(this.Usuarios_Load);
            this.Resize += new System.EventHandler(this.Usuarios_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvUsuarios)).EndInit();
            this.cmMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbNuevo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvUsuarios;
        private System.Windows.Forms.TextBox tbUsuario;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.TextBox tbPassword;
        private System.Windows.Forms.TextBox tbNivel;
        private System.Windows.Forms.TextBox tbMarca;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbComprador;
        private System.Windows.Forms.TextBox tbCorreo;
        private System.Windows.Forms.TextBox tbPerfil;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem ActualizarTSMI;
        private System.Windows.Forms.ToolStripMenuItem nuevoTSMI;
        private System.Windows.Forms.ToolStripMenuItem eliminarTSMI;
        private System.Windows.Forms.PictureBox pbNuevo;
    }
}