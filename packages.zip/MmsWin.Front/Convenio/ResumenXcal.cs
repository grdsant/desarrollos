﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class ResumenXcal : Form
    {
        int dgvOffset;
        int dgvOffset2;

        public ResumenXcal()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }

        private void ResumenXcal_Load(object sender, EventArgs e)
        {
            BindData();
        }

        private void BindData()
        {
            this.Cursor = Cursors.WaitCursor;

            dgvGridView.DataSource = null;
            System.Data.DataTable ResumenXcal = null;
            try
            {
                string marca = MmsWin.Front.Utilerias.VarTem.tmpMarca;
                string comprador = MmsWin.Front.Utilerias.VarTem.tmpComprador;
                string fechaRev = MmsWin.Front.Utilerias.VarTem.tmpFchRev;
                string usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                ResumenXcal = MmsWin.Negocio.Convenio.ResumenXcal.GetInstance().ObtenResumenXcalDet1(marca, comprador, fechaRev, usuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (ResumenXcal.Rows.Count > 0)
            {
                dgvGridView.DataSource = ResumenXcal;
                int nr = dgvGridView.RowCount;
                this.Text = "Resumen por Calificaion / " + " " + (nr).ToString() + " Registro(s)";
                SetFontAndColors();
                rowStyle();
                SetDoubleBuffered(dgvGridView);
            }
            this.Cursor = Cursors.Default;
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvGridView.Columns[3].Frozen = true;

            dgvGridView.Columns[0].HeaderText = "Calificacion";
            dgvGridView.Columns[1].HeaderText = "Piezas Recibidas";
            dgvGridView.Columns[2].HeaderText = "Costo Total";
            dgvGridView.Columns[3].HeaderText = "Piezas Bonificacion";
            dgvGridView.Columns[4].HeaderText = "Costo Bonificar";

            dgvGridView.Columns[0].Width = 100;
            dgvGridView.Columns[1].Width = 100;
            dgvGridView.Columns[2].Width = 100;
            dgvGridView.Columns[3].Width = 100;
            dgvGridView.Columns[4].Width = 100;

            dgvGridView.Columns[0].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[1].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[2].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[3].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[4].DefaultCellStyle.NullValue = true;


            dgvGridView.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgvGridView.Columns[1].DefaultCellStyle.Format = "#,###,###";
            dgvGridView.Columns[2].DefaultCellStyle.Format = "#,###,###.##";
            dgvGridView.Columns[3].DefaultCellStyle.Format = "#,###,###";
            dgvGridView.Columns[4].DefaultCellStyle.Format = "#,###,###.##";

            dgvGridView.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[1].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[2].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[3].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[4].HeaderCell.Style.BackColor = Color.LightGreen;

            foreach (DataGridViewRow row in dgvGridView.Rows)
            {
                // Pagar
                if (Convert.ToString(row.Cells[0].Value) == " P a g a r") { row.Cells[0].Style.BackColor = Color.LightGreen; }
                // 15%
                if (Convert.ToString(row.Cells[0].Value) == " 15%") { row.Cells[0].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(row.Cells[0].Value) == " 20%") { row.Cells[0].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(row.Cells[0].Value) == " 25%") { row.Cells[0].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(row.Cells[0].Value) == " 30%") { row.Cells[0].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(row.Cells[0].Value) == " 35%") { row.Cells[0].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(row.Cells[0].Value) == " 40%") { row.Cells[0].Style.BackColor = Color.LightSalmon; }
                // Dev ó 40%
                if (Convert.ToString(row.Cells[0].Value) == " 40%") { row.Cells[0].Style.BackColor = Color.Red; row.Cells[0].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(row.Cells[0].Value) == " 50%") { row.Cells[0].Style.BackColor = Color.Red; row.Cells[0].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(row.Cells[0].Value) == " 50%") { row.Cells[0].Style.BackColor = Color.Red; row.Cells[0].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(row.Cells[0].Value) == "Devolucion") { row.Cells[0].Style.BackColor = Color.Red; row.Cells[0].Style.ForeColor = Color.White; }
            }

        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                string  TotalCal = rowp.Cells[0].Value.ToString();

                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }

                if (TotalCal == "Z_Califica")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.DarkGreen;
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.ForeColor = Color.White;
                    rowp.Cells[0].Style.ForeColor = Color.DarkGreen;

                    // Totales por columna
                    // Suma Piezas Recibidas                              
                    int totPzRcb = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[1].Value));
                    rowp.Cells[1].Value = totPzRcb;
                    // Suma Costo Total                                   
                    int totCST = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[2].Value));
                    rowp.Cells[2].Value = totCST;
                    // Suma Piezas a Bonificar                            
                    int totPzaBo = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[3].Value));
                    rowp.Cells[3].Value = totPzaBo;
                    // Suma Costo a Bonificar                             
                    int totCSTBo = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[4].Value));
                    rowp.Cells[4].Value = totCSTBo;
                }
            }
        }

        private void ResumenXcal_Resize(object sender, EventArgs e)
        {
            dgvGridView.Width = this.Width - dgvOffset;
            dgvGridView.Height = this.Height - dgvOffset2;
        }

        private void dgvGridView_Sorted(object sender, EventArgs e)
        {
            SetFontAndColors();
            rowStyle();
        }
    }
}
