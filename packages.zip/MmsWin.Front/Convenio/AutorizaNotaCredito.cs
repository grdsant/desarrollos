﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class AutorizaNotaCredito : Form
    {
        #region " Variables Globales"
        //Se les asigna su valor desde la pantalla de convenio
        //dependiendo de la selección de los combos de marca y comprador
        public Comun.Engine.Marca Marca { get; set; }
        public int Comprador { get; set; }

        //Se usan para el marcado y desmarcado de los checkbox en las grid
        bool CheckMarcados = false;
        bool CheckMarcadosDetalle = false;

        /// Número de folio de la solicitud
        string Folio = "";

        ///Matriz para separar el folio y el estatus del estilo 
        string[] item;

        DataTable dtFiltroFolio = null;
        private BindingSource bsFiltroPre;
        #endregion

        #region "metodo de la clase principal "
        public AutorizaNotaCredito()
        {
            InitializeComponent();
        }
        #endregion

        #region " Page Load "
        private void AutorizaNotaCredito_Load(object sender, EventArgs e)
        {
            try
            {
                cargaGrid();
                this.cboFiltrar.SelectedItem = "Pendiente";

                //Agregar columna "CheckBox" a los estilos que se seleccionaran para agregar al formato
                DataGridViewCheckBoxColumn CheckboxColumn = new DataGridViewCheckBoxColumn();
                CheckboxColumn.TrueValue = true;
                CheckboxColumn.FalseValue = false;
                CheckboxColumn.Width = 100;
                dgvEstilosPreautorizados.Columns.Insert(0, CheckboxColumn);

                DataGridViewCheckBoxColumn Checkbox_Column = new DataGridViewCheckBoxColumn();
                CheckboxColumn.TrueValue = true;
                CheckboxColumn.FalseValue = false;
                CheckboxColumn.Width = 100;
                dgvDetalleFolios.Columns.Insert(0, Checkbox_Column);

                dgvEstilosPreautorizados.EditMode = DataGridViewEditMode.EditOnKeystroke;
                dgvDetalleFolios.EditMode = DataGridViewEditMode.EditOnKeystroke;
                //-----------------------------------------------------------------------------------------

                this.lblFolio.Text = "Folio: N/G";
                estilosGridView();
                //Carga los Folis Existentes 
                CargaFolios();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region  " Metodo que llena el Grid's "
        protected void cargaGrid()
        {
            dgvEstilosPreautorizados.DataSource = null;
            System.Data.DataTable dtCambioCalificacion = null;

            try
            {
                dtCambioCalificacion = MmsWin.Negocio.Convenio.Convenio.GetInstance().notaCrestoEstatusTraslado();

                bsFiltroPre = new BindingSource(dtCambioCalificacion, null);
                dgvEstilosPreautorizados.DataSource = bsFiltroPre;
                dgvEstilosPreautorizados.Focus();
                dgvEstilosPreautorizados.Select();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region "  Semanejan todos los estilos de los Gridview  "
        public void estilosGridView()
        {
            #region [ Dar formato a la grid de Estilos Preautorizados ]

            // ocultos
            this.dgvEstilosPreautorizados.Columns["NTCBON"].Visible = false;
            this.dgvEstilosPreautorizados.Columns["NTCFRE"].Visible = false;
            this.dgvEstilosPreautorizados.Columns["IDCOMPRADOR"].Visible = false;
            this.dgvEstilosPreautorizados.Columns["IDMARCA"].Visible = false;
            //Fuente

            this.dgvEstilosPreautorizados.Columns[0].Frozen = true;

            this.dgvEstilosPreautorizados.Columns["FECHABON"].Frozen = true;
            this.dgvEstilosPreautorizados.Columns["FECHABON"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//  Fecha Bonifica 
            this.dgvEstilosPreautorizados.Columns["FECHABON"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.dgvEstilosPreautorizados.Columns["FECHAREV"].Frozen = true;
            this.dgvEstilosPreautorizados.Columns["FECHAREV"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//  Fecha Revision 
            this.dgvEstilosPreautorizados.Columns["FECHAREV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.dgvEstilosPreautorizados.Columns["IDPROV"].Frozen = true;
            this.dgvEstilosPreautorizados.Columns["IDPROV"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del Proveedor  
            this.dgvEstilosPreautorizados.Columns["IDPROV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.dgvEstilosPreautorizados.Columns["PROVEEDOR"].Frozen = true;
            this.dgvEstilosPreautorizados.Columns["PROVEEDOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del Proveedor
            this.dgvEstilosPreautorizados.Columns["PROVEEDOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            this.dgvEstilosPreautorizados.Columns["IDESTILO"].Frozen = true;
            this.dgvEstilosPreautorizados.Columns["IDESTILO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del Estilo
            this.dgvEstilosPreautorizados.Columns["IDESTILO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.dgvEstilosPreautorizados.Columns["ESTILO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del Estilo
            this.dgvEstilosPreautorizados.Columns["ESTILO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            this.dgvEstilosPreautorizados.Columns["COMPRADOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del Comprador
            this.dgvEstilosPreautorizados.Columns["COMPRADOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            this.dgvEstilosPreautorizados.Columns["ODCOMPRA"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # de orden de compra
            this.dgvEstilosPreautorizados.Columns["ODCOMPRA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.dgvEstilosPreautorizados.Columns["NOTACREDITO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);
            this.dgvEstilosPreautorizados.Columns["NOTACREDITO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft; // NotaCredito de Credito

            this.dgvEstilosPreautorizados.Columns["MARCA"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);
            this.dgvEstilosPreautorizados.Columns["MARCA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;// Marca

            this.dgvEstilosPreautorizados.Columns["TEMPORADA"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Temporada
            this.dgvEstilosPreautorizados.Columns["TEMPORADA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.dgvEstilosPreautorizados.Columns["CALIFICACION"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // calidficacion
            this.dgvEstilosPreautorizados.Columns["PIEZAS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Piezas
            this.dgvEstilosPreautorizados.Columns["ONHAND"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // on hand
            this.dgvEstilosPreautorizados.Columns["PORVENTAS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // % de Venta
            this.dgvEstilosPreautorizados.Columns["VENTA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;  // Venta

            this.dgvEstilosPreautorizados.Columns["PIEZAS"].DefaultCellStyle.Format = "###,###,###,###0";
            this.dgvEstilosPreautorizados.Columns["ONHAND"].DefaultCellStyle.Format = "###,###,###,###0";
            this.dgvEstilosPreautorizados.Columns["VENTA"].DefaultCellStyle.Format = "###,###,###,###0.00";

            //Título de los encabezados
            this.dgvEstilosPreautorizados.Columns["FECHABON"].HeaderText = "Fecha Bonificación";
            this.dgvEstilosPreautorizados.Columns["FECHAREV"].HeaderText = "Fecha Revisión";
            this.dgvEstilosPreautorizados.Columns["IDPROV"].HeaderText = "# Prov.";
            this.dgvEstilosPreautorizados.Columns["PROVEEDOR"].HeaderText = "Proveedor";
            this.dgvEstilosPreautorizados.Columns["IDESTILO"].HeaderText = "# Estilo";
            this.dgvEstilosPreautorizados.Columns["ESTILO"].HeaderText = "Estilo";
            this.dgvEstilosPreautorizados.Columns["COMPRADOR"].HeaderText = "Comprador";
            this.dgvEstilosPreautorizados.Columns["ODCOMPRA"].HeaderText = "Orden Compra";
            this.dgvEstilosPreautorizados.Columns["PIEZAS"].HeaderText = "Piezas";
            this.dgvEstilosPreautorizados.Columns["VENTA"].HeaderText = "Venta";
            this.dgvEstilosPreautorizados.Columns["ONHAND"].HeaderText = "On Hand";
            this.dgvEstilosPreautorizados.Columns["PORVENTAS"].HeaderText = "% Ventas";
            this.dgvEstilosPreautorizados.Columns["NOTACREDITO"].HeaderText = "Nota Crédito";
            this.dgvEstilosPreautorizados.Columns["CALIFICACION"].HeaderText = "Calificación";
            this.dgvEstilosPreautorizados.Columns["MARCA"].HeaderText = "Marca";
            this.dgvEstilosPreautorizados.Columns["TEMPORADA"].HeaderText = "Temporada";

            ////Ancho
            this.dgvEstilosPreautorizados.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosPreautorizados.Columns["FECHABON"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosPreautorizados.Columns["FECHAREV"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosPreautorizados.Columns["IDPROV"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvEstilosPreautorizados.Columns["PROVEEDOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosPreautorizados.Columns["IDESTILO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvEstilosPreautorizados.Columns["ESTILO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosPreautorizados.Columns["COMPRADOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosPreautorizados.Columns["ODCOMPRA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosPreautorizados.Columns["PIEZAS"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosPreautorizados.Columns["VENTA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvEstilosPreautorizados.Columns["ONHAND"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvEstilosPreautorizados.Columns["PORVENTAS"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvEstilosPreautorizados.Columns["NOTACREDITO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvEstilosPreautorizados.Columns["CALIFICACION"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvEstilosPreautorizados.Columns["MARCA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvEstilosPreautorizados.Columns["TEMPORADA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            #endregion

            #region [ Dar formato a la grid de estilos seleccionados ]

            this.dgvEstilosSeleccionados.Columns.Add("NTCBON", "NTCBON");
            this.dgvEstilosSeleccionados.Columns.Add("FECHABON", "FECHABON");
            this.dgvEstilosSeleccionados.Columns.Add("NTCFRE", "NTCFRE");
            this.dgvEstilosSeleccionados.Columns.Add("FECHAREV", "FECHAREV");
            this.dgvEstilosSeleccionados.Columns.Add("IDPROV", "IDPROV");
            this.dgvEstilosSeleccionados.Columns.Add("PROVEEDOR", "PROVEEDOR");
            this.dgvEstilosSeleccionados.Columns.Add("IDESTILO", "IDESTILO");
            this.dgvEstilosSeleccionados.Columns.Add("ODCOMPRA", "ODCOMPRA");
            this.dgvEstilosSeleccionados.Columns.Add("IDMARCA", "IDMARCA");
            this.dgvEstilosSeleccionados.Columns.Add("TEMPORADA", "TEMPORADA");
            this.dgvEstilosSeleccionados.Columns.Add("IDCOMPRADOR", "IDCOMPRADOR");
            this.dgvEstilosSeleccionados.Columns.Add("COMPRADOR", "COMPRADOR");
            this.dgvEstilosSeleccionados.Columns.Add("NOTACREDITO", "NOTACREDITO");

            this.dgvEstilosSeleccionados.Columns["NTCBON"].Visible = false;
            this.dgvEstilosSeleccionados.Columns["NTCFRE"].Visible = false;
            this.dgvEstilosSeleccionados.Columns["IDCOMPRADOR"].Visible = false;
            this.dgvEstilosSeleccionados.Columns["IDMARCA"].Visible = false;
            this.dgvEstilosSeleccionados.Columns["ODCOMPRA"].Visible = false;
            this.dgvEstilosSeleccionados.Columns["IDMARCA"].Visible = false;
            this.dgvEstilosSeleccionados.Columns["TEMPORADA"].Visible = false;

            //Fuente
            this.dgvEstilosSeleccionados.Columns["FECHABON"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Fecha de bonificacion 
            this.dgvEstilosSeleccionados.Columns["FECHAREV"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Fecha de revision 
            this.dgvEstilosSeleccionados.Columns["IDPROV"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del Proveedor 
            this.dgvEstilosSeleccionados.Columns["PROVEEDOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del Proveedor
            this.dgvEstilosSeleccionados.Columns["IDESTILO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del Estilo
            this.dgvEstilosSeleccionados.Columns["COMPRADOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// comprador
            this.dgvEstilosSeleccionados.Columns["NOTACREDITO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nota de Crédito

            //Ancho
            this.dgvEstilosSeleccionados.Columns["FECHABON"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosSeleccionados.Columns["FECHAREV"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosSeleccionados.Columns["IDPROV"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvEstilosSeleccionados.Columns["PROVEEDOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosSeleccionados.Columns["IDESTILO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvEstilosSeleccionados.Columns["COMPRADOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosSeleccionados.Columns["NOTACREDITO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            #endregion
        }
        #endregion

        #region " Carga los folios que ya estan y no autolizados "
        private void CargaFolios(string Folio = "")
        {
            int imagen = 0;

            string status = "";

            status = (this.cboFiltrar.ComboBox.SelectedItem == "Pendiente") ? "P" : "A";

            dtFiltroFolio = MmsWin.Negocio.Convenio.Convenio.cargaListaFoliosNotaCre(status);

            this.lsvFolios.Items.Clear();

            for (int i = 0; i < dtFiltroFolio.Rows.Count; i++)
            {

                DataRow dr = dtFiltroFolio.Rows[i];

                if (dr["ESTATUS"].ToString() == "Autorizado")
                {
                    imagen = 3;
                }
                else
                {
                    imagen = 0;
                }

                this.lsvFolios.Items.Add(dr["FOLIO"].ToString() + "," + dr["ESTATUS"].ToString(), dr["FOLIO"].ToString() + "\n" + dr["ESTATUS"].ToString(), imagen);
            }

            dtFiltroFolio.Dispose();
        }
        #endregion

        #region "  Evento que ejecuta todos los botones de la Pantalla "
        private void Buttons_Click(object sender, EventArgs e)
        {
            dgvEstilosPreautorizados.EndEdit();
            dgvEstilosPreautorizados.ClearSelection();
            this.dgvEstilosPreautorizados.Refresh();

            this.dgvDetalleFolios.EndEdit();
            this.dgvDetalleFolios.ClearSelection();
            this.dgvDetalleFolios.Refresh();

            string msg = "";

            try
            {
                if (sender == this.btnBuscarPre)
                {
                    filtraPreautorizados();
                }

                if (sender == this.btnBuscar)
                {
                    CargaFolios();
                }

                if (sender == this.btnAutorizar)
                {
                    AutorizarEstilos("A");
                }

                if (sender == this.btnLiberar)
                {
                    msg = "El Proveedor - Estilos y Orden de compra seleccionados, Se eliminara del folio.\n\n¿Desea continuar?";
                    if (MessageBox.Show(msg, "Nota de Crédito", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                    {
                        DesautorizarEstilos();
                    }
                }

                if (sender == this.btnMarcarTodas)
                {
                    //Marcar o desmarcar todos los estilos de la lista
                    foreach (DataGridViewRow row in this.dgvEstilosPreautorizados.Rows)
                    {
                        row.Cells[0].Value = !CheckMarcados;
                    }

                    CheckMarcados = !CheckMarcados;
                }

                if (sender == this.btnMarcarDetalle)
                {
                    //Marcar o desmarcar todos los estilos de la lista
                    foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
                    {
                        row.Cells[0].Value = !CheckMarcadosDetalle;
                    }

                    CheckMarcadosDetalle = !CheckMarcadosDetalle;
                }

                if (sender == this.btnAgregar)
                {
                    agregaAntesDeFolio();
                }

                if (sender == this.btnImprimir)
                {
                    if (item != null)
                    {
                        dgvDetalleFolios.ClearSelection();

                        foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
                        {
                            if (dgvDetalleFolios.Rows[row.Index].Cells["ESTATUS"].Value.ToString()[0] == 'A')
                            {
                                MessageBox.Show("Para imprimir el folio [ " + item[0] + " ] el estatus tiene que estar en pendiente.", "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                return;
                            }
                        }

                        if (Convert.ToInt32(item[0]) > 0)
                        {
                            rptNotaCredito f = new rptNotaCredito();
                            f.StartPosition = FormStartPosition.CenterParent;
                            f.Folio = Convert.ToInt32(item[0]);
                            f.ShowDialog(this);
                        }
                        else
                        {
                            MessageBox.Show("Debe seleccionar una solicitud para imprimirla", "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Debe seleccionar una solicitud para imprimirla", "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }

                if (sender == this.tsbEliminarTodos)
                {
                    if (this.dgvEstilosSeleccionados.SelectedRows.Count > 0)
                    {
                        eliminaPorRegistro();
                        this.dgvEstilosSeleccionados.ClearSelection();
                    }
                    else
                    {
                        MessageBox.Show("Debe seleccionar una solicitud para elimiarla", "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }

                if (sender == this.btnGuardar)
                {
                    if (this.dgvEstilosSeleccionados.Rows.Count > 0)
                    {
                        if (MessageBox.Show("Los Registros de Proveedor - Estilo y orden de compra seleccionados se asignaran a un nuevo folio\n\n¿Desea continuar?", "Nota de Crédito", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                        {
                            Folio = MmsWin.Negocio.Convenio.Convenio.ObtieneFolioNotaCredito();
                            this.lblFolio.Text = string.Format("Folio: {0}", Folio);

                            if (insertaFolio() > 0)
                            {
                                MessageBox.Show(string.Format("Se genero la solicitud con el número de folio: {0}", Folio), "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                Folio = "";
                                cargaGrid();

                                //desmarcar todos los estilos de la lista
                                if (dgvEstilosPreautorizados.Rows.Count > 0)
                                {
                                    foreach (DataGridViewRow row in this.dgvEstilosPreautorizados.Rows)
                                    {
                                        row.Cells[0].Value = false;
                                    }
                                    CheckMarcados = false;
                                }
                                CargaFolios();
                                estilosGridView();
                                EliminaRegistros();
                            }
                            else
                            {
                                MessageBox.Show("ERROR!\nNo se almacenaron los registros seleccionados, haga click en el botón de 'Generar' \n !Si el problema persiste comuniquese a 'Soporte' ", "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            }
                        }
                        else
                        {
                            MessageBox.Show("La operación fue cancelada, no se realizaron cambios.", "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("ATENCIÓN!\nNo se han seleccionado estilos para asignar un folio, marquelos y haga agreguelos", "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion

        #region " Metodo que afrega los estilos con compradores no repetidos que van a genrarles folio "
        private void agregaAntesDeFolio()
        {
            //Limpiar los registros autorizados
            int Proveedor = 0;

            foreach (DataGridViewRow row in this.dgvEstilosPreautorizados.Rows)
            {
                if (this.dgvEstilosSeleccionados.RowCount == 0)
                {
                    Proveedor = Convert.ToInt32(dgvEstilosPreautorizados.Rows[row.Index].Cells["IDPROV"].Value);
                }

                DataGridViewCheckBoxCell chk = dgvEstilosPreautorizados.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                if (Convert.ToBoolean(chk.Value) == true)
                {
                    if (this.dgvEstilosSeleccionados.Rows.Count > 0)
                    {
                        bool existe = false;
                        foreach (DataGridViewRow rowCP in dgvEstilosSeleccionados.Rows)
                        {
                            if (Convert.ToString(rowCP.Cells["IDCOMPRADOR"].Value).Trim() != dgvEstilosPreautorizados.Rows[row.Index].Cells["IDCOMPRADOR"].Value.ToString().Trim())
                            {
                                string comp1 = Convert.ToString(rowCP.Cells["COMPRADOR"].Value).Trim();
                                string comp2 = dgvEstilosPreautorizados.Rows[row.Index].Cells["COMPRADOR"].Value.ToString().Trim();
                                MessageBox.Show(string.Format("Solicitud de un solo comprador y tienes seleccionados al comprador {0} y el comprador {1}", comp1, comp2), "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                return;
                            }

                            if (Convert.ToString(rowCP.Cells["IDMARCA"].Value).Trim() != dgvEstilosPreautorizados.Rows[row.Index].Cells["IDMARCA"].Value.ToString().Trim())
                            {
                                string comp1 = Convert.ToString(rowCP.Cells["IDMARCA"].Value).Trim();
                                string comp2 = dgvEstilosPreautorizados.Rows[row.Index].Cells["IDMARCA"].Value.ToString().Trim();
                                MessageBox.Show(string.Format("Solicitud de una sola marca y tienes seleccionados la marca {0} y la marca {1}", comp1, comp2), "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                return;
                            }

                            if (
                                Convert.ToString(rowCP.Cells["NTCBON"].Value).Trim().Equals(dgvEstilosPreautorizados.Rows[row.Index].Cells["NTCBON"].Value.ToString().Trim()) &&
                                Convert.ToString(rowCP.Cells["NTCFRE"].Value).Trim().Equals(dgvEstilosPreautorizados.Rows[row.Index].Cells["NTCFRE"].Value.ToString().Trim()) &&
                                Convert.ToString(rowCP.Cells["IDPROV"].Value).Trim().Equals(dgvEstilosPreautorizados.Rows[row.Index].Cells["IDPROV"].Value.ToString().Trim()) &&
                                Convert.ToString(rowCP.Cells["IDESTILO"].Value).Trim().Equals(dgvEstilosPreautorizados.Rows[row.Index].Cells["IDESTILO"].Value.ToString().Trim()) &&
                                Convert.ToString(rowCP.Cells["ODCOMPRA"].Value).Trim().Equals(dgvEstilosPreautorizados.Rows[row.Index].Cells["ODCOMPRA"].Value.ToString().Trim()) &&
                                Convert.ToString(rowCP.Cells["IDMARCA"].Value).Trim().Equals(dgvEstilosPreautorizados.Rows[row.Index].Cells["IDMARCA"].Value.ToString().Trim()) &&
                                Convert.ToString(rowCP.Cells["TEMPORADA"].Value).Trim().Equals(dgvEstilosPreautorizados.Rows[row.Index].Cells["TEMPORADA"].Value.ToString().Trim()) &&
                                Convert.ToString(rowCP.Cells["IDCOMPRADOR"].Value).Trim().Equals(dgvEstilosPreautorizados.Rows[row.Index].Cells["IDCOMPRADOR"].Value.ToString().Trim()))
                            {
                                existe = true;
                            }
                        }
                        if (existe == true)
                        {

                        }
                        else
                        {
                            this.dgvEstilosSeleccionados.Rows.Add(
                                                            dgvEstilosPreautorizados.Rows[row.Index].Cells["NTCBON"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["FECHABON"].Value,
                                                            dgvEstilosPreautorizados.Rows[row.Index].Cells["NTCFRE"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["FECHAREV"].Value,
                                                            dgvEstilosPreautorizados.Rows[row.Index].Cells["IDPROV"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["PROVEEDOR"].Value,
                                                            dgvEstilosPreautorizados.Rows[row.Index].Cells["IDESTILO"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["ODCOMPRA"].Value,
                                                            dgvEstilosPreautorizados.Rows[row.Index].Cells["IDMARCA"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["TEMPORADA"].Value,
                                                            dgvEstilosPreautorizados.Rows[row.Index].Cells["IDCOMPRADOR"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["COMPRADOR"].Value,
                                                            dgvEstilosPreautorizados.Rows[row.Index].Cells["NOTACREDITO"].Value);
                            this.dgvEstilosSeleccionados.Sort(dgvEstilosSeleccionados.Columns["PROVEEDOR"], ListSortDirection.Ascending);
                            this.dgvEstilosSeleccionados.Columns["FECHABON"].Frozen = true;
                            this.dgvEstilosSeleccionados.Columns["FECHAREV"].Frozen = true;
                            this.dgvEstilosSeleccionados.Columns["IDPROV"].Frozen = true;
                        }
                    }
                    else
                    {
                        this.dgvEstilosSeleccionados.Rows.Add(
                                                            dgvEstilosPreautorizados.Rows[row.Index].Cells["NTCBON"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["FECHABON"].Value,
                                                            dgvEstilosPreautorizados.Rows[row.Index].Cells["NTCFRE"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["FECHAREV"].Value,
                                                            dgvEstilosPreautorizados.Rows[row.Index].Cells["IDPROV"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["PROVEEDOR"].Value,
                                                            dgvEstilosPreautorizados.Rows[row.Index].Cells["IDESTILO"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["ODCOMPRA"].Value,
                                                            dgvEstilosPreautorizados.Rows[row.Index].Cells["IDMARCA"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["TEMPORADA"].Value,
                                                            dgvEstilosPreautorizados.Rows[row.Index].Cells["IDCOMPRADOR"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["COMPRADOR"].Value,
                                                            dgvEstilosPreautorizados.Rows[row.Index].Cells["NOTACREDITO"].Value);
                        this.dgvEstilosSeleccionados.Sort(dgvEstilosSeleccionados.Columns["PROVEEDOR"], ListSortDirection.Ascending);
                        this.dgvEstilosSeleccionados.Columns["FECHABON"].Frozen = true;
                        this.dgvEstilosSeleccionados.Columns["FECHAREV"].Frozen = true;
                        this.dgvEstilosSeleccionados.Columns["IDPROV"].Frozen = true;
                    }
                }
            }

            this.dgvEstilosSeleccionados.ClearSelection();
        }
        #endregion

        #region " Metodo que se utiliza para dezautorizar los estilos "
        private void DesautorizarEstilos()
        {
            string folioEs = string.Empty;
            bool correcto = false;
            foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
            {
                DataGridViewCheckBoxCell chk = dgvDetalleFolios.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;
                if (Convert.ToBoolean(chk.Value) == true)
                {
                    folioEs = dgvDetalleFolios.Rows[row.Index].Cells["FOLIO"].Value.ToString();
                    correcto = Negocio.Convenio.Convenio.EliminaNoAutorizadosNotaCredito(
                              folioEs,
                              dgvDetalleFolios.Rows[row.Index].Cells["NTCBON"].Value.ToString(),
                              dgvDetalleFolios.Rows[row.Index].Cells["NTCFRE"].Value.ToString(),
                              dgvDetalleFolios.Rows[row.Index].Cells["IDESTILO"].Value.ToString(),
                              dgvDetalleFolios.Rows[row.Index].Cells["IDPROV"].Value.ToString(),
                              dgvDetalleFolios.Rows[row.Index].Cells["ODCOMPRA"].Value.ToString(),
                              dgvDetalleFolios.Rows[row.Index].Cells["IDMARCA"].Value.ToString(),
                              dgvDetalleFolios.Rows[row.Index].Cells["TEMPORADA"].Value.ToString(),
                              dgvDetalleFolios.Rows[row.Index].Cells["COMPRADOR"].Value.ToString()
                              );
                }
            }

            if (folioEs == string.Empty)
            {
                MessageBox.Show("Debe de seleccionar todas las casillas para dezautorizar la solicitud.", "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            if (correcto == true)
            {
                gridDetalleFolio(item[0]);
                CargaFolios();
                dgvDetalleFolios.ClearSelection();
                if (dgvDetalleFolios.Rows.Count == 0)
                {
                    item[0] = null;
                }
            }
            else
            {
                MessageBox.Show("Error al dezautorizar la solicitud, Intente nuevamente.\n Si el problema persiste comunicate a soporte", "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion

        #region " Metodo que autoriza los estilos "
        private void AutorizarEstilos(string estatus)
        {
            int check = 0, noCheck = 0, caccal = 0;
            Folio = item[0];

            foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
            {
                DataGridViewCheckBoxCell chk = dgvDetalleFolios.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                if (Convert.ToBoolean(chk.Value) == true)
                {
                    check++;
                }
                else
                {
                    noCheck++;
                }

                //if (dgvDetalleFolios.Rows[row.Index].Cells["NOTACREDITO"].Value.ToString() == string.Empty)
                //{
                //    caccal++;
                //}
            }

            //if (caccal > 0)
            //{
            //    MessageBox.Show("Para autorizar el folio [ " + Folio + " ] es necesario que se haya generado la nota de crédito.", "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    return;
            //}

            if (noCheck == 0)
            {

                DataTable dtProvedorEstilo = new DataTable();
                dtProvedorEstilo = dgvDetalleFolios.DataSource as DataTable;

                bool continua = Negocio.Convenio.Convenio.AutorizaFolioNotaCredito(
                         Folio,
                         estatus, dtProvedorEstilo);

                if (continua == true)
                {
                    gridDetalleFolio(item[0]);
                    CargaFolios();
                    this.btnMarcarDetalle.Enabled = false;
                    this.btnAutorizar.Enabled = false;
                    this.btnLiberar.Enabled = false;
                    dgvDetalleFolios.ClearSelection();

                    MessageBox.Show("SOLICITUD [ " + Folio + " ] AUTORIZADA correctamente.", "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Error con la información, reintente y si el problema persiste comunicarse a soporte.", "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Debe de seleccionar todas las casillas para autorizar la solicitud.", "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion

        #region " Liga los Proveedores y estilos seleccionados a un nuevo folio "
        private int insertaFolio()
        {
            DataTable dtProvedorEstilo = new DataTable("ProvedorEstilo");
            dtProvedorEstilo.Columns.Add("FOLIO", typeof(int));
            dtProvedorEstilo.Columns.Add("NTCBON", typeof(string));
            dtProvedorEstilo.Columns.Add("NTCFRE", typeof(string));
            dtProvedorEstilo.Columns.Add("IDPROV", typeof(int));
            dtProvedorEstilo.Columns.Add("IDESTILO", typeof(string));
            dtProvedorEstilo.Columns.Add("ODCOMPRA", typeof(int));
            dtProvedorEstilo.Columns.Add("IDMARCA", typeof(int));
            dtProvedorEstilo.Columns.Add("TEMPORADA", typeof(string));
            dtProvedorEstilo.Columns.Add("COMPRADOR", typeof(string));

            foreach (DataGridViewRow row in this.dgvEstilosSeleccionados.Rows)
            {
                dtProvedorEstilo.Rows.Add(
                        Folio, dgvEstilosSeleccionados.Rows[row.Index].Cells["NTCBON"].Value.ToString(),
                               dgvEstilosSeleccionados.Rows[row.Index].Cells["NTCFRE"].Value.ToString(),
                               dgvEstilosSeleccionados.Rows[row.Index].Cells["IDPROV"].Value,
                               dgvEstilosSeleccionados.Rows[row.Index].Cells["IDESTILO"].Value.ToString(),
                               dgvEstilosSeleccionados.Rows[row.Index].Cells["ODCOMPRA"].Value,
                               dgvEstilosSeleccionados.Rows[row.Index].Cells["IDMARCA"].Value,
                               dgvEstilosSeleccionados.Rows[row.Index].Cells["TEMPORADA"].Value.ToString(),
                               dgvEstilosSeleccionados.Rows[row.Index].Cells["COMPRADOR"].Value.ToString()
                        );
            }

            return MmsWin.Negocio.Convenio.Convenio.estatusTempNotasCredito(dtProvedorEstilo);
        }
        #endregion

        #region " Borrar los registros de la grid de estilos seleccionado "
        private void EliminaRegistros()
        {
            dgvEstilosSeleccionados.Rows.Clear();
        }

        protected void eliminaPorRegistro()
        {
            Int32 rowDelete = this.dgvEstilosSeleccionados.Rows.GetFirstRow(DataGridViewElementStates.Selected);

            if (rowDelete > -1)
            {
                this.dgvEstilosSeleccionados.Rows.RemoveAt(rowDelete);
            }
        }
        #endregion

        #region " Filtra los registros de la grid de estilos Preautorizados "
        private void filtraPreautorizados()
        {
            if (txtBuscarPre.Text == string.Empty)
                bsFiltroPre.RemoveFilter();
            else
                bsFiltroPre.Filter = string.Format("PROVEEDOR LIKE '*{0}*' OR ESTILO LIKE '*{0}*' OR IDESTILO LIKE '*{0}*' OR CONVERT(IDPROV, System.String) LIKE '*{0}*' OR COMPRADOR LIKE '*{0}*' OR CONVERT(ODCOMPRA, System.String)  LIKE '*{0}*'", txtBuscarPre.Text);
        }

        private void filtraFolios()
        {
            try
            {
                dgvDetalleFolios.DataSource = null;

                DataView Dv = dtFiltroFolio.DefaultView;
                Dv.RowFilter = string.Format("CONVERT(FOLIO, System.String) LIKE '*{0}*' OR ESTATUS LIKE '*{0}*'", txtBuscar.Text);

                int imagen = 0;

                this.lsvFolios.Items.Clear();

                foreach (DataRowView rowView in Dv)
                {
                    DataRow dr = rowView.Row;
                    if (dr["ESTATUS"].ToString() == "Autorizado")
                    {
                        imagen = 3;
                    }
                    else
                    {
                        imagen = 0;
                    }

                    this.lsvFolios.Items.Add(dr["FOLIO"].ToString() + "," + dr["ESTATUS"].ToString(), dr["FOLIO"].ToString() + "\n" + dr["ESTATUS"].ToString(), imagen);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Evento txtBuscar y txtBuscarPre para filtrar lo que contiene el List de los folios y el grid de preautorizados "
        private void txtBuscarPre_TextChanged(object sender, EventArgs e)
        {
            if (txtBuscarPre.Text == string.Empty)
                bsFiltroPre.RemoveFilter();
            else
                bsFiltroPre.Filter = string.Format("PROVEEDOR LIKE '*{0}*' OR ESTILO LIKE '*{0}*' OR CONVERT(IDESTILO, System.String) LIKE '*{0}*' OR CONVERT(IDPROV, System.String) LIKE '*{0}*' OR CONVERT(COMPRADOR, System.String) LIKE '*{0}*' OR CONVERT(ODCOMPRA, System.String)  LIKE '*{0}*'", txtBuscarPre.Text);
        }

        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            dgvDetalleFolios.ClearSelection();
            filtraFolios();
        }
        #endregion

        #region " evento que muestra el filtro de los folios por pendientes o autorizados "
        private void cboFiltrar_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.dgvDetalleFolios.DataSource = null;

            if (sender == this.cboFiltrar)
            {
                CargaFolios();
                if (this.cboFiltrar.SelectedItem == "Autorizado")
                {
                    this.btnImprimir.Enabled = false;
                }
                else
                { this.btnImprimir.Enabled = true; }
            }
        }
        #endregion

        #region  "  Evento de Tab manipula las pestañas para la visivilidad de los controles del Nota de Crédito "
        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            this.dgvDetalleFolios.DataSource = null;
        }
        #endregion

        #region " Evento que selecciona los folio  "
        private void lsvFolios_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lsvFolios_Click(object sender, EventArgs e)
        {
            //Recuperar el folio
            item = this.lsvFolios.SelectedItems[0].Name.Split(',');
            gridDetalleFolio(item[0]);
            dgvDetalleFolios.ClearSelection();
        }
        #endregion

        #region " llena el detalle del grid por folio seleccionado "
        public void gridDetalleFolio(string folio)
        {
            this.dgvDetalleFolios.DataSource = MmsWin.Negocio.Convenio.Convenio.CargaDetalleFolioNotaCredito(folio);

            #region " formato a la grid de Estilos Preautorizados "
            // Columnas no visibles
            this.dgvDetalleFolios.Columns["NTCBON"].Visible = false;
            this.dgvDetalleFolios.Columns["NTCFRE"].Visible = false;
            this.dgvDetalleFolios.Columns["IDCOMPRADOR"].Visible = false;
            this.dgvDetalleFolios.Columns["IDMARCA"].Visible = false;
            this.dgvDetalleFolios.Columns["IDESTUS"].Visible = false;

            //Fuente
            this.dgvDetalleFolios.Columns[0].Frozen = true;
            this.dgvDetalleFolios.Columns["FOLIO"].Frozen = true;
            this.dgvDetalleFolios.Columns["FOLIO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del FOLIO 
            this.dgvDetalleFolios.Columns["FOLIO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.dgvDetalleFolios.Columns["FECHABON"].Frozen = true;
            this.dgvDetalleFolios.Columns["FECHABON"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// fecha de Bonificacion 
            this.dgvDetalleFolios.Columns["FECHABON"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.dgvDetalleFolios.Columns["FECHAREV"].Frozen = true;
            this.dgvDetalleFolios.Columns["FECHAREV"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// fecha de revision 
            this.dgvDetalleFolios.Columns["FECHAREV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.dgvDetalleFolios.Columns["IDPROV"].Frozen = true;
            this.dgvDetalleFolios.Columns["IDPROV"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del Proveedor  
            this.dgvDetalleFolios.Columns["IDPROV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.dgvDetalleFolios.Columns["PROVEEDOR"].Frozen = true;
            this.dgvDetalleFolios.Columns["PROVEEDOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del Proveedor
            this.dgvDetalleFolios.Columns["PROVEEDOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            this.dgvDetalleFolios.Columns["IDESTILO"].Frozen = true;
            this.dgvDetalleFolios.Columns["IDESTILO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del Estilo
            this.dgvDetalleFolios.Columns["IDESTILO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.dgvDetalleFolios.Columns["ESTILO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del Estilo
            this.dgvDetalleFolios.Columns["ESTILO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            this.dgvDetalleFolios.Columns["COMPRADOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del comprador
            this.dgvDetalleFolios.Columns["COMPRADOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            this.dgvDetalleFolios.Columns["ODCOMPRA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;  // orden de compra

            this.dgvDetalleFolios.Columns["NOTACREDITO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nota de credito
            this.dgvDetalleFolios.Columns["NOTACREDITO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            this.dgvDetalleFolios.Columns["PIEZAS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;       // Piezas
            this.dgvDetalleFolios.Columns["VENTA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;        // Venta
            this.dgvDetalleFolios.Columns["ONHAND"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;       // On Hand
            this.dgvDetalleFolios.Columns["PORVENTAS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;    // % Venta
            this.dgvDetalleFolios.Columns["CALIFICACION"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Calificacion
            this.dgvDetalleFolios.Columns["SUBTOTAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;     // Sub Total
            this.dgvDetalleFolios.Columns["IVA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;         // Iva 
            this.dgvDetalleFolios.Columns["TOTAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;       // Total
            this.dgvDetalleFolios.Columns["PORBONIFICA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // % Bonificacion
            this.dgvDetalleFolios.Columns["CSTACT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;      // Costo Acual
            this.dgvDetalleFolios.Columns["PRCACT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;      // Precio Actual
            this.dgvDetalleFolios.Columns["MARACT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;      // Margen Actual
            this.dgvDetalleFolios.Columns["CSTNVO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;      // Costo Nuevo
            this.dgvDetalleFolios.Columns["PRCNVO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;      // Precio Nuevo
            this.dgvDetalleFolios.Columns["MARNVO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;      // Margen Nuevo
            this.dgvDetalleFolios.Columns["CSTFIN"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;      // Costo Fin
            this.dgvDetalleFolios.Columns["PRCFIN"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;      // Precio Fin
            this.dgvDetalleFolios.Columns["MARFIN"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;      // Margen Fin
            this.dgvDetalleFolios.Columns["DIFCOSTO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;      // Dif. Pezas
            this.dgvDetalleFolios.Columns["PZAONHAND"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;      // Pzas. On Hand
            this.dgvDetalleFolios.Columns["IMPONHAND"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;      // Imp. On Hand
            this.dgvDetalleFolios.Columns["DIFCSTFIN"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;      // Dif. Costo Fin
            this.dgvDetalleFolios.Columns["IMPDISCST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;      // Imp. Costos Fin 
            this.dgvDetalleFolios.Columns["IMPMARFIN"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;      // Imp. Margen Fin
            this.dgvDetalleFolios.Columns["MARCA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // marca
            this.dgvDetalleFolios.Columns["ESTATUS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // Estatus
            this.dgvDetalleFolios.Columns["TEMPORADA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // Temporada

            this.dgvDetalleFolios.Columns["PIEZAS"].DefaultCellStyle.Format = "###,###,###,###0";
            this.dgvDetalleFolios.Columns["VENTA"].DefaultCellStyle.Format = "###,###,###,###0";
            this.dgvDetalleFolios.Columns["ONHAND"].DefaultCellStyle.Format = "###,###,###,###0";
            this.dgvDetalleFolios.Columns["PORVENTAS"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["IVA"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["TOTAL"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["PORBONIFICA"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["DIFCOSTO"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["PZAONHAND"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["IMPONHAND"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["DIFCSTFIN"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["IMPDISCST"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["IMPMARFIN"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["CSTACT"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["PRCACT"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["MARACT"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["CSTNVO"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["PRCNVO"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["MARNVO"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["CSTFIN"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["PRCFIN"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["MARFIN"].DefaultCellStyle.Format = "###,###,###,###0.00";

            //Título de los encabezados
            this.dgvDetalleFolios.Columns["FOLIO"].HeaderText = "Folio";
            this.dgvDetalleFolios.Columns["FECHABON"].HeaderText = "Fecha Bonificación";
            this.dgvDetalleFolios.Columns["FECHAREV"].HeaderText = "Fecha Revisión";
            this.dgvDetalleFolios.Columns["IDPROV"].HeaderText = "# Prov.";
            this.dgvDetalleFolios.Columns["PROVEEDOR"].HeaderText = "Proveedor";
            this.dgvDetalleFolios.Columns["IDESTILO"].HeaderText = "# Estilo";
            this.dgvDetalleFolios.Columns["ESTILO"].HeaderText = "Estilo";
            this.dgvDetalleFolios.Columns["COMPRADOR"].HeaderText = "Comprador";
            this.dgvDetalleFolios.Columns["ODCOMPRA"].HeaderText = "Orden Compra";
            this.dgvDetalleFolios.Columns["NOTACREDITO"].HeaderText = "Nota Crédito";
            this.dgvDetalleFolios.Columns["PIEZAS"].HeaderText = "Piezas";
            this.dgvDetalleFolios.Columns["VENTA"].HeaderText = "Venta";
            this.dgvDetalleFolios.Columns["ONHAND"].HeaderText = "On Hand";
            this.dgvDetalleFolios.Columns["PORVENTAS"].HeaderText = "% Venta";
            this.dgvDetalleFolios.Columns["CALIFICACION"].HeaderText = "Calificación";
            this.dgvDetalleFolios.Columns["SUBTOTAL"].HeaderText = "Sub Total";
            this.dgvDetalleFolios.Columns["IVA"].HeaderText = "Iva ";
            this.dgvDetalleFolios.Columns["TOTAL"].HeaderText = "Total";
            this.dgvDetalleFolios.Columns["PORBONIFICA"].HeaderText = "% Bonificación";
            this.dgvDetalleFolios.Columns["CSTACT"].HeaderText = "Costo Acual";
            this.dgvDetalleFolios.Columns["PRCACT"].HeaderText = "Precio Actual";
            this.dgvDetalleFolios.Columns["MARACT"].HeaderText = "Margen Actual";
            this.dgvDetalleFolios.Columns["CSTNVO"].HeaderText = "Costo Nuevo";
            this.dgvDetalleFolios.Columns["PRCNVO"].HeaderText = "Precio Nuevo";
            this.dgvDetalleFolios.Columns["MARNVO"].HeaderText = "Margen Nuevo";
            this.dgvDetalleFolios.Columns["CSTFIN"].HeaderText = "Costo Fin";
            this.dgvDetalleFolios.Columns["PRCFIN"].HeaderText = "Precio Fin";
            this.dgvDetalleFolios.Columns["MARFIN"].HeaderText = "Margen Fin";
            this.dgvDetalleFolios.Columns["DIFCOSTO"].HeaderText = "Dif. Pezas";
            this.dgvDetalleFolios.Columns["PZAONHAND"].HeaderText = "Pzas. On Hand";
            this.dgvDetalleFolios.Columns["IMPONHAND"].HeaderText = "Imp. On Hand";
            this.dgvDetalleFolios.Columns["DIFCSTFIN"].HeaderText = "Dif. Costo Fin";
            this.dgvDetalleFolios.Columns["IMPDISCST"].HeaderText = "Imp. Costos Fin ";
            this.dgvDetalleFolios.Columns["IMPMARFIN"].HeaderText = "Imp. Margen Fin";
            this.dgvDetalleFolios.Columns["MARCA"].HeaderText = "Marca";
            this.dgvDetalleFolios.Columns["ESTATUS"].HeaderText = "Estatus";
            this.dgvDetalleFolios.Columns["TEMPORADA"].HeaderText = "Temporada";

            ////Ancho
            this.dgvDetalleFolios.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["FOLIO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["FECHABON"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["FECHAREV"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["IDPROV"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["PROVEEDOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["IDESTILO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["ESTILO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["COMPRADOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["ODCOMPRA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["PORBONIFICA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["PIEZAS"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["VENTA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["ONHAND"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["PORVENTAS"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["CALIFICACION"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["SUBTOTAL"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["IVA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["TOTAL"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["PORBONIFICA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["CSTACT"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["PRCACT"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["MARACT"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["CSTNVO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["PRCNVO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["MARNVO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["CSTFIN"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["PRCFIN"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["MARFIN"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["DIFCOSTO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["PZAONHAND"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["IMPONHAND"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["DIFCSTFIN"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["IMPDISCST"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["IMPMARFIN"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["MARCA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["ESTATUS"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["TEMPORADA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;

            // Solo lectura

            this.dgvDetalleFolios.Columns["FOLIO"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["FECHABON"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["FECHAREV"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["IDPROV"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["PROVEEDOR"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["IDESTILO"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["ESTILO"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["COMPRADOR"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["ODCOMPRA"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["PORBONIFICA"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["PIEZAS"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["VENTA"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["ONHAND"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["PORVENTAS"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["CALIFICACION"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["SUBTOTAL"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["IVA"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["TOTAL"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["PORBONIFICA"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["CSTACT"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["PRCACT"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["MARACT"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["CSTNVO"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["PRCNVO"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["MARNVO"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["CSTFIN"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["PRCFIN"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["MARFIN"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["DIFCOSTO"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["PZAONHAND"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["IMPONHAND"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["DIFCSTFIN"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["IMPDISCST"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["IMPMARFIN"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["MARCA"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["ESTATUS"].ReadOnly = true;
            this.dgvDetalleFolios.Columns["TEMPORADA"].ReadOnly = true;

            #endregion

            if (item[1] == "Autorizado" || item[1] == "Vencido")
            {
                this.btnMarcarDetalle.Enabled = false;
                this.btnAutorizar.Enabled = false;
                this.btnLiberar.Enabled = false;
            }
            else
            {
                this.btnMarcarDetalle.Enabled = true;
                this.btnAutorizar.Enabled = true;
                this.btnLiberar.Enabled = true;
            }
        }
        #endregion
    }
}
