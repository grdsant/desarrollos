﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class rptNotaCredito : Form
    {
        public int Folio { get; set; }
        public rptNotaCredito()
        {
            InitializeComponent();
        }

        private void rptNotaCredito_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dsSAT177VNTrpt.SAT177VNT' Puede moverla o quitarla según sea necesario.
            this.SAT177VNTTableAdapter.Fill(this.dsSAT177VNTrpt.SAT177VNT, Folio);

            this.rpvNotaCredito.RefreshReport();
        }
    }
}
