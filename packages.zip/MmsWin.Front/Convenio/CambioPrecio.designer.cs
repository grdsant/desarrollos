﻿namespace MmsWin.Front.Convenio
{
    partial class CambioPrecio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CambioPrecio));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.cbCompradores = new System.Windows.Forms.ComboBox();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.gpbEstilosDisponibles = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btRelleno = new System.Windows.Forms.Button();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbProveedor = new System.Windows.Forms.TextBox();
            this.dgvEstilosPreautorizados = new System.Windows.Forms.DataGridView();
            this.gpbEstilosSeleccionados = new System.Windows.Forms.GroupBox();
            this.tspOrdenesSeleccionadas = new System.Windows.Forms.ToolStrip();
            this.btnGenerarFormato = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.tsbEliminarSeleccion = new System.Windows.Forms.ToolStripButton();
            this.tslblFecha = new System.Windows.Forms.ToolStripLabel();
            this.dgvCPSeleccionadas = new System.Windows.Forms.DataGridView();
            this.tspGeneracionFormatos = new System.Windows.Forms.ToolStrip();
            this.lblFolio = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.lblBuscarOc = new System.Windows.Forms.ToolStripLabel();
            this.txtBuscarCP = new System.Windows.Forms.ToolStripTextBox();
            this.btnBuscarCP = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.btnMarcarTodas = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.btnAgregar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.lblTempo = new System.Windows.Forms.ToolStripLabel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.tspConsultaAutorizadas = new System.Windows.Forms.ToolStrip();
            this.lblBuscar = new System.Windows.Forms.ToolStripLabel();
            this.txtBuscar = new System.Windows.Forms.ToolStripTextBox();
            this.btnBuscarFolio = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.cboEstatus = new System.Windows.Forms.ToolStripComboBox();
            this.btnImprimir = new System.Windows.Forms.ToolStripButton();
            this.lsvFolios = new System.Windows.Forms.ListView();
            this.imlFolios = new System.Windows.Forms.ImageList(this.components);
            this.pnlActualizar = new System.Windows.Forms.Panel();
            this.lblComDesc = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblIdComp = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblTemporada = new System.Windows.Forms.Label();
            this.lblTEmp = new System.Windows.Forms.Label();
            this.lblMarcaDesc = new System.Windows.Forms.Label();
            this.lblMarca = new System.Windows.Forms.Label();
            this.dgvDetallePorFolio = new System.Windows.Forms.DataGridView();
            this.lblEstiloDesc = new System.Windows.Forms.Label();
            this.lblProvDesc = new System.Windows.Forms.Label();
            this.lblIdEstilo = new System.Windows.Forms.Label();
            this.lblIdProv = new System.Windows.Forms.Label();
            this.lblFolioDesc = new System.Windows.Forms.Label();
            this.lblFolioMod = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblProveedor = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblEstilo = new System.Windows.Forms.Label();
            this.gbxCambiaPrecio = new System.Windows.Forms.GroupBox();
            this.lblError = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblTPA = new System.Windows.Forms.Label();
            this.lblNMA = new System.Windows.Forms.Label();
            this.lblNPA = new System.Windows.Forms.Label();
            this.lblTotalMargen = new System.Windows.Forms.Label();
            this.lblMargen = new System.Windows.Forms.Label();
            this.txtPrecio = new System.Windows.Forms.TextBox();
            this.txtCosto = new System.Windows.Forms.TextBox();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.lblTMA = new System.Windows.Forms.Label();
            this.lblCosto = new System.Windows.Forms.Label();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.lblNCA = new System.Windows.Forms.Label();
            this.btnGuardarCambios = new System.Windows.Forms.Button();
            this.lblTCA = new System.Windows.Forms.Label();
            this.lblFechaMod = new System.Windows.Forms.Label();
            this.dgvDetalleFolios = new System.Windows.Forms.DataGridView();
            this.tspAutorizadas = new System.Windows.Forms.ToolStrip();
            this.btnMarcarDetalle = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.btnLiberar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.btnAutorizar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.gpbEstilosDisponibles.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstilosPreautorizados)).BeginInit();
            this.gpbEstilosSeleccionados.SuspendLayout();
            this.tspOrdenesSeleccionadas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCPSeleccionadas)).BeginInit();
            this.tspGeneracionFormatos.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.tspConsultaAutorizadas.SuspendLayout();
            this.pnlActualizar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetallePorFolio)).BeginInit();
            this.gbxCambiaPrecio.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalleFolios)).BeginInit();
            this.tspAutorizadas.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(2, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1140, 454);
            this.tabControl1.TabIndex = 2;
            this.tabControl1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Selecting);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.cbCompradores);
            this.tabPage1.Controls.Add(this.splitContainer1);
            this.tabPage1.Controls.Add(this.tspGeneracionFormatos);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1132, 428);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Generación formatos";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // cbCompradores
            // 
            this.cbCompradores.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbCompradores.FormattingEnabled = true;
            this.cbCompradores.Location = new System.Drawing.Point(581, 4);
            this.cbCompradores.Name = "cbCompradores";
            this.cbCompradores.Size = new System.Drawing.Size(128, 21);
            this.cbCompradores.TabIndex = 4;
            this.cbCompradores.Visible = false;
            this.cbCompradores.SelectedIndexChanged += new System.EventHandler(this.cbCompradores_SelectedIndexChanged);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 28);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.gpbEstilosDisponibles);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.gpbEstilosSeleccionados);
            this.splitContainer1.Size = new System.Drawing.Size(1126, 397);
            this.splitContainer1.SplitterDistance = 723;
            this.splitContainer1.TabIndex = 1;
            // 
            // gpbEstilosDisponibles
            // 
            this.gpbEstilosDisponibles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gpbEstilosDisponibles.Controls.Add(this.button1);
            this.gpbEstilosDisponibles.Controls.Add(this.btRelleno);
            this.gpbEstilosDisponibles.Controls.Add(this.tbDescripcion);
            this.gpbEstilosDisponibles.Controls.Add(this.tbEstilo);
            this.gpbEstilosDisponibles.Controls.Add(this.tbNombre);
            this.gpbEstilosDisponibles.Controls.Add(this.tbProveedor);
            this.gpbEstilosDisponibles.Controls.Add(this.dgvEstilosPreautorizados);
            this.gpbEstilosDisponibles.Location = new System.Drawing.Point(4, 3);
            this.gpbEstilosDisponibles.Name = "gpbEstilosDisponibles";
            this.gpbEstilosDisponibles.Size = new System.Drawing.Size(716, 391);
            this.gpbEstilosDisponibles.TabIndex = 1;
            this.gpbEstilosDisponibles.TabStop = false;
            this.gpbEstilosDisponibles.Text = "Proveedor - Estilos Disponibles";
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(547, 20);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(166, 22);
            this.button1.TabIndex = 55;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            // 
            // btRelleno
            // 
            this.btRelleno.Location = new System.Drawing.Point(-1, 20);
            this.btRelleno.Name = "btRelleno";
            this.btRelleno.Size = new System.Drawing.Size(63, 22);
            this.btRelleno.TabIndex = 54;
            this.btRelleno.UseVisualStyleBackColor = true;
            this.btRelleno.Visible = false;
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDescripcion.Location = new System.Drawing.Point(387, 21);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(160, 20);
            this.tbDescripcion.TabIndex = 53;
            this.tbDescripcion.Visible = false;
            this.tbDescripcion.TextChanged += new System.EventHandler(this.tbDescripcion_TextChanged);
            // 
            // tbEstilo
            // 
            this.tbEstilo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbEstilo.Location = new System.Drawing.Point(319, 21);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(68, 20);
            this.tbEstilo.TabIndex = 52;
            this.tbEstilo.Visible = false;
            this.tbEstilo.TextChanged += new System.EventHandler(this.tbEstilo_TextChanged);
            // 
            // tbNombre
            // 
            this.tbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNombre.Location = new System.Drawing.Point(130, 21);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(189, 20);
            this.tbNombre.TabIndex = 51;
            this.tbNombre.Visible = false;
            this.tbNombre.TextChanged += new System.EventHandler(this.tbNombre_TextChanged);
            // 
            // tbProveedor
            // 
            this.tbProveedor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbProveedor.Location = new System.Drawing.Point(62, 21);
            this.tbProveedor.Name = "tbProveedor";
            this.tbProveedor.Size = new System.Drawing.Size(68, 20);
            this.tbProveedor.TabIndex = 50;
            this.tbProveedor.Visible = false;
            this.tbProveedor.TextChanged += new System.EventHandler(this.tbProveedor_TextChanged);
            // 
            // dgvEstilosPreautorizados
            // 
            this.dgvEstilosPreautorizados.AllowUserToAddRows = false;
            this.dgvEstilosPreautorizados.AllowUserToDeleteRows = false;
            this.dgvEstilosPreautorizados.AllowUserToOrderColumns = true;
            this.dgvEstilosPreautorizados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEstilosPreautorizados.Location = new System.Drawing.Point(3, 44);
            this.dgvEstilosPreautorizados.Name = "dgvEstilosPreautorizados";
            this.dgvEstilosPreautorizados.Size = new System.Drawing.Size(710, 344);
            this.dgvEstilosPreautorizados.TabIndex = 1;
            // 
            // gpbEstilosSeleccionados
            // 
            this.gpbEstilosSeleccionados.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gpbEstilosSeleccionados.Controls.Add(this.tspOrdenesSeleccionadas);
            this.gpbEstilosSeleccionados.Controls.Add(this.dgvCPSeleccionadas);
            this.gpbEstilosSeleccionados.Location = new System.Drawing.Point(3, 3);
            this.gpbEstilosSeleccionados.Name = "gpbEstilosSeleccionados";
            this.gpbEstilosSeleccionados.Size = new System.Drawing.Size(391, 388);
            this.gpbEstilosSeleccionados.TabIndex = 1;
            this.gpbEstilosSeleccionados.TabStop = false;
            this.gpbEstilosSeleccionados.Text = "Proveedor - Estilos Seleccionados";
            // 
            // tspOrdenesSeleccionadas
            // 
            this.tspOrdenesSeleccionadas.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnGenerarFormato,
            this.toolStripSeparator9,
            this.tsbEliminarSeleccion,
            this.tslblFecha});
            this.tspOrdenesSeleccionadas.Location = new System.Drawing.Point(3, 16);
            this.tspOrdenesSeleccionadas.Name = "tspOrdenesSeleccionadas";
            this.tspOrdenesSeleccionadas.Size = new System.Drawing.Size(385, 25);
            this.tspOrdenesSeleccionadas.TabIndex = 2;
            this.tspOrdenesSeleccionadas.Text = "toolStrip4";
            // 
            // btnGenerarFormato
            // 
            this.btnGenerarFormato.Image = global::MmsWin.Front.Properties.Resources._077_AddFile_16x16_72;
            this.btnGenerarFormato.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnGenerarFormato.Name = "btnGenerarFormato";
            this.btnGenerarFormato.Size = new System.Drawing.Size(68, 22);
            this.btnGenerarFormato.Text = "Generar";
            this.btnGenerarFormato.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 25);
            // 
            // tsbEliminarSeleccion
            // 
            this.tsbEliminarSeleccion.Image = global::MmsWin.Front.Properties.Resources._109_AllAnnotations_Error_16x16_721;
            this.tsbEliminarSeleccion.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEliminarSeleccion.Name = "tsbEliminarSeleccion";
            this.tsbEliminarSeleccion.Size = new System.Drawing.Size(112, 22);
            this.tsbEliminarSeleccion.Text = "Quitar selección";
            this.tsbEliminarSeleccion.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // tslblFecha
            // 
            this.tslblFecha.ActiveLinkColor = System.Drawing.Color.Black;
            this.tslblFecha.Name = "tslblFecha";
            this.tslblFecha.Size = new System.Drawing.Size(0, 22);
            // 
            // dgvCPSeleccionadas
            // 
            this.dgvCPSeleccionadas.AllowUserToAddRows = false;
            this.dgvCPSeleccionadas.AllowUserToDeleteRows = false;
            this.dgvCPSeleccionadas.AllowUserToOrderColumns = true;
            this.dgvCPSeleccionadas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvCPSeleccionadas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCPSeleccionadas.Location = new System.Drawing.Point(3, 44);
            this.dgvCPSeleccionadas.MultiSelect = false;
            this.dgvCPSeleccionadas.Name = "dgvCPSeleccionadas";
            this.dgvCPSeleccionadas.ReadOnly = true;
            this.dgvCPSeleccionadas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCPSeleccionadas.Size = new System.Drawing.Size(385, 341);
            this.dgvCPSeleccionadas.TabIndex = 1;
            // 
            // tspGeneracionFormatos
            // 
            this.tspGeneracionFormatos.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblFolio,
            this.toolStripSeparator1,
            this.lblBuscarOc,
            this.txtBuscarCP,
            this.btnBuscarCP,
            this.toolStripSeparator5,
            this.btnMarcarTodas,
            this.toolStripSeparator6,
            this.btnAgregar,
            this.toolStripSeparator7,
            this.lblTempo});
            this.tspGeneracionFormatos.Location = new System.Drawing.Point(3, 3);
            this.tspGeneracionFormatos.Name = "tspGeneracionFormatos";
            this.tspGeneracionFormatos.Size = new System.Drawing.Size(1126, 25);
            this.tspGeneracionFormatos.TabIndex = 0;
            this.tspGeneracionFormatos.Text = "toolStrip1";
            // 
            // lblFolio
            // 
            this.lblFolio.AutoSize = false;
            this.lblFolio.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblFolio.ForeColor = System.Drawing.Color.Maroon;
            this.lblFolio.Name = "lblFolio";
            this.lblFolio.Size = new System.Drawing.Size(80, 22);
            this.lblFolio.Text = "Folio: 1698";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // lblBuscarOc
            // 
            this.lblBuscarOc.Name = "lblBuscarOc";
            this.lblBuscarOc.Size = new System.Drawing.Size(45, 22);
            this.lblBuscarOc.Text = "Buscar:";
            // 
            // txtBuscarCP
            // 
            this.txtBuscarCP.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBuscarCP.Name = "txtBuscarCP";
            this.txtBuscarCP.Size = new System.Drawing.Size(100, 25);
            this.txtBuscarCP.TextChanged += new System.EventHandler(this.txtBuscarCP_TextChanged);
            // 
            // btnBuscarCP
            // 
            this.btnBuscarCP.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnBuscarCP.Image = global::MmsWin.Front.Properties.Resources.Find_VS;
            this.btnBuscarCP.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnBuscarCP.Name = "btnBuscarCP";
            this.btnBuscarCP.Size = new System.Drawing.Size(23, 22);
            this.btnBuscarCP.Text = "toolStripButton2";
            this.btnBuscarCP.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // btnMarcarTodas
            // 
            this.btnMarcarTodas.AutoSize = false;
            this.btnMarcarTodas.Image = global::MmsWin.Front.Properties.Resources.CheckBoxHS;
            this.btnMarcarTodas.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnMarcarTodas.Name = "btnMarcarTodas";
            this.btnMarcarTodas.Size = new System.Drawing.Size(100, 22);
            this.btnMarcarTodas.Text = "Marcar todos";
            this.btnMarcarTodas.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // btnAgregar
            // 
            this.btnAgregar.Image = global::MmsWin.Front.Properties.Resources._112_RightArrowShort_Blue_16x16_72;
            this.btnAgregar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(124, 22);
            this.btnAgregar.Text = "Agregar a formato";
            this.btnAgregar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAgregar.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 25);
            // 
            // lblTempo
            // 
            this.lblTempo.Name = "lblTempo";
            this.lblTempo.Size = new System.Drawing.Size(71, 22);
            this.lblTempo.Text = "Comprador:";
            this.lblTempo.Visible = false;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.splitContainer3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1132, 428);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Autorizaciones";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // splitContainer3
            // 
            this.splitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer3.CausesValidation = false;
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.tspConsultaAutorizadas);
            this.splitContainer3.Panel1.Controls.Add(this.lsvFolios);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.pnlActualizar);
            this.splitContainer3.Panel2.Controls.Add(this.dgvDetalleFolios);
            this.splitContainer3.Panel2.Controls.Add(this.tspAutorizadas);
            this.splitContainer3.Size = new System.Drawing.Size(1132, 428);
            this.splitContainer3.SplitterDistance = 156;
            this.splitContainer3.TabIndex = 3;
            // 
            // tspConsultaAutorizadas
            // 
            this.tspConsultaAutorizadas.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblBuscar,
            this.txtBuscar,
            this.btnBuscarFolio,
            this.toolStripSeparator4,
            this.toolStripLabel2,
            this.cboEstatus,
            this.btnImprimir});
            this.tspConsultaAutorizadas.Location = new System.Drawing.Point(0, 0);
            this.tspConsultaAutorizadas.Name = "tspConsultaAutorizadas";
            this.tspConsultaAutorizadas.Size = new System.Drawing.Size(1128, 25);
            this.tspConsultaAutorizadas.TabIndex = 1;
            this.tspConsultaAutorizadas.Text = "toolStrip2";
            // 
            // lblBuscar
            // 
            this.lblBuscar.Name = "lblBuscar";
            this.lblBuscar.Size = new System.Drawing.Size(45, 22);
            this.lblBuscar.Text = "Buscar:";
            // 
            // txtBuscar
            // 
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.Size = new System.Drawing.Size(100, 25);
            this.txtBuscar.TextChanged += new System.EventHandler(this.txtBuscar_TextChanged);
            // 
            // btnBuscarFolio
            // 
            this.btnBuscarFolio.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnBuscarFolio.Image = global::MmsWin.Front.Properties.Resources.Find_VS;
            this.btnBuscarFolio.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnBuscarFolio.Name = "btnBuscarFolio";
            this.btnBuscarFolio.Size = new System.Drawing.Size(23, 22);
            this.btnBuscarFolio.Text = "Filtra Folio";
            this.btnBuscarFolio.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(90, 22);
            this.toolStripLabel2.Text = "Ver por estatus: ";
            // 
            // cboEstatus
            // 
            this.cboEstatus.BackColor = System.Drawing.Color.Gainsboro;
            this.cboEstatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEstatus.Items.AddRange(new object[] {
            "Pendientes",
            "Autorizadas"});
            this.cboEstatus.Name = "cboEstatus";
            this.cboEstatus.Size = new System.Drawing.Size(121, 25);
            this.cboEstatus.SelectedIndexChanged += new System.EventHandler(this.Event_cbo_SelectIndexChanged);
            // 
            // btnImprimir
            // 
            this.btnImprimir.Image = global::MmsWin.Front.Properties.Resources.PrintHS;
            this.btnImprimir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnImprimir.Name = "btnImprimir";
            this.btnImprimir.Size = new System.Drawing.Size(73, 22);
            this.btnImprimir.Text = "Imprimir";
            this.btnImprimir.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // lsvFolios
            // 
            this.lsvFolios.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lsvFolios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lsvFolios.LargeImageList = this.imlFolios;
            this.lsvFolios.Location = new System.Drawing.Point(3, 28);
            this.lsvFolios.Name = "lsvFolios";
            this.lsvFolios.Size = new System.Drawing.Size(1120, 121);
            this.lsvFolios.SmallImageList = this.imlFolios;
            this.lsvFolios.TabIndex = 0;
            this.lsvFolios.UseCompatibleStateImageBehavior = false;
            this.lsvFolios.SelectedIndexChanged += new System.EventHandler(this.lsvFolios_SelectedIndexChanged);
            this.lsvFolios.Click += new System.EventHandler(this.lsvFolios_Click);
            // 
            // imlFolios
            // 
            this.imlFolios.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imlFolios.ImageStream")));
            this.imlFolios.TransparentColor = System.Drawing.Color.Transparent;
            this.imlFolios.Images.SetKeyName(0, "folder_process.png");
            this.imlFolios.Images.SetKeyName(1, "Folder_32x32.png");
            this.imlFolios.Images.SetKeyName(2, "NewDocuments_32x32.png");
            this.imlFolios.Images.SetKeyName(3, "folder_autorizado.png");
            this.imlFolios.Images.SetKeyName(4, "IgnoreIssue_32x32.png");
            this.imlFolios.Images.SetKeyName(5, "112_Tick_Green_32x32_72.png");
            this.imlFolios.Images.SetKeyName(6, "folder_cancel.png");
            // 
            // pnlActualizar
            // 
            this.pnlActualizar.BackColor = System.Drawing.Color.Lavender;
            this.pnlActualizar.Controls.Add(this.lblComDesc);
            this.pnlActualizar.Controls.Add(this.label3);
            this.pnlActualizar.Controls.Add(this.lblIdComp);
            this.pnlActualizar.Controls.Add(this.label2);
            this.pnlActualizar.Controls.Add(this.lblTemporada);
            this.pnlActualizar.Controls.Add(this.lblTEmp);
            this.pnlActualizar.Controls.Add(this.lblMarcaDesc);
            this.pnlActualizar.Controls.Add(this.lblMarca);
            this.pnlActualizar.Controls.Add(this.dgvDetallePorFolio);
            this.pnlActualizar.Controls.Add(this.lblEstiloDesc);
            this.pnlActualizar.Controls.Add(this.lblProvDesc);
            this.pnlActualizar.Controls.Add(this.lblIdEstilo);
            this.pnlActualizar.Controls.Add(this.lblIdProv);
            this.pnlActualizar.Controls.Add(this.lblFolioDesc);
            this.pnlActualizar.Controls.Add(this.lblFolioMod);
            this.pnlActualizar.Controls.Add(this.lblNombre);
            this.pnlActualizar.Controls.Add(this.lblProveedor);
            this.pnlActualizar.Controls.Add(this.label1);
            this.pnlActualizar.Controls.Add(this.lblEstilo);
            this.pnlActualizar.Controls.Add(this.gbxCambiaPrecio);
            this.pnlActualizar.Controls.Add(this.lblFechaMod);
            this.pnlActualizar.Location = new System.Drawing.Point(1, 0);
            this.pnlActualizar.Name = "pnlActualizar";
            this.pnlActualizar.Size = new System.Drawing.Size(1126, 262);
            this.pnlActualizar.TabIndex = 6;
            this.pnlActualizar.Visible = false;
            // 
            // lblComDesc
            // 
            this.lblComDesc.AutoSize = true;
            this.lblComDesc.Location = new System.Drawing.Point(257, 84);
            this.lblComDesc.Name = "lblComDesc";
            this.lblComDesc.Size = new System.Drawing.Size(19, 13);
            this.lblComDesc.TabIndex = 70;
            this.lblComDesc.Text = "cp";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(210, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 13);
            this.label3.TabIndex = 69;
            this.label3.Text = "Nombre:";
            // 
            // lblIdComp
            // 
            this.lblIdComp.AutoSize = true;
            this.lblIdComp.ForeColor = System.Drawing.Color.Red;
            this.lblIdComp.Location = new System.Drawing.Point(89, 84);
            this.lblIdComp.Name = "lblIdComp";
            this.lblIdComp.Size = new System.Drawing.Size(35, 13);
            this.lblIdComp.TabIndex = 68;
            this.lblIdComp.Text = "idcom";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 67;
            this.label2.Text = "Comprador:";
            // 
            // lblTemporada
            // 
            this.lblTemporada.AutoSize = true;
            this.lblTemporada.Location = new System.Drawing.Point(257, 11);
            this.lblTemporada.Name = "lblTemporada";
            this.lblTemporada.Size = new System.Drawing.Size(18, 13);
            this.lblTemporada.TabIndex = 66;
            this.lblTemporada.Text = "tm";
            // 
            // lblTEmp
            // 
            this.lblTEmp.AutoSize = true;
            this.lblTEmp.Location = new System.Drawing.Point(194, 11);
            this.lblTEmp.Name = "lblTEmp";
            this.lblTEmp.Size = new System.Drawing.Size(64, 13);
            this.lblTEmp.TabIndex = 65;
            this.lblTEmp.Text = "Temporada:";
            // 
            // lblMarcaDesc
            // 
            this.lblMarcaDesc.AutoSize = true;
            this.lblMarcaDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMarcaDesc.Location = new System.Drawing.Point(707, 10);
            this.lblMarcaDesc.Name = "lblMarcaDesc";
            this.lblMarcaDesc.Size = new System.Drawing.Size(51, 16);
            this.lblMarcaDesc.TabIndex = 64;
            this.lblMarcaDesc.Text = "marca";
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = true;
            this.lblMarca.Location = new System.Drawing.Point(661, 12);
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.Size = new System.Drawing.Size(40, 13);
            this.lblMarca.TabIndex = 63;
            this.lblMarca.Text = "Marca:";
            // 
            // dgvDetallePorFolio
            // 
            this.dgvDetallePorFolio.AllowUserToAddRows = false;
            this.dgvDetallePorFolio.AllowUserToDeleteRows = false;
            this.dgvDetallePorFolio.AllowUserToOrderColumns = true;
            this.dgvDetallePorFolio.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDetallePorFolio.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetallePorFolio.Location = new System.Drawing.Point(62, 111);
            this.dgvDetallePorFolio.MultiSelect = false;
            this.dgvDetallePorFolio.Name = "dgvDetallePorFolio";
            this.dgvDetallePorFolio.ReadOnly = true;
            this.dgvDetallePorFolio.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvDetallePorFolio.Size = new System.Drawing.Size(392, 139);
            this.dgvDetallePorFolio.TabIndex = 62;
            // 
            // lblEstiloDesc
            // 
            this.lblEstiloDesc.AutoSize = true;
            this.lblEstiloDesc.Location = new System.Drawing.Point(256, 57);
            this.lblEstiloDesc.Name = "lblEstiloDesc";
            this.lblEstiloDesc.Size = new System.Drawing.Size(20, 13);
            this.lblEstiloDesc.TabIndex = 61;
            this.lblEstiloDesc.Text = "nE";
            // 
            // lblProvDesc
            // 
            this.lblProvDesc.AutoSize = true;
            this.lblProvDesc.Location = new System.Drawing.Point(257, 35);
            this.lblProvDesc.Name = "lblProvDesc";
            this.lblProvDesc.Size = new System.Drawing.Size(20, 13);
            this.lblProvDesc.TabIndex = 60;
            this.lblProvDesc.Text = "nP";
            // 
            // lblIdEstilo
            // 
            this.lblIdEstilo.AutoSize = true;
            this.lblIdEstilo.ForeColor = System.Drawing.Color.Red;
            this.lblIdEstilo.Location = new System.Drawing.Point(89, 57);
            this.lblIdEstilo.Name = "lblIdEstilo";
            this.lblIdEstilo.Size = new System.Drawing.Size(27, 13);
            this.lblIdEstilo.TabIndex = 54;
            this.lblIdEstilo.Text = "idEs";
            // 
            // lblIdProv
            // 
            this.lblIdProv.AutoSize = true;
            this.lblIdProv.ForeColor = System.Drawing.Color.Red;
            this.lblIdProv.Location = new System.Drawing.Point(91, 35);
            this.lblIdProv.Name = "lblIdProv";
            this.lblIdProv.Size = new System.Drawing.Size(22, 13);
            this.lblIdProv.TabIndex = 53;
            this.lblIdProv.Text = "idP";
            // 
            // lblFolioDesc
            // 
            this.lblFolioDesc.AutoSize = true;
            this.lblFolioDesc.ForeColor = System.Drawing.Color.Red;
            this.lblFolioDesc.Location = new System.Drawing.Point(92, 11);
            this.lblFolioDesc.Name = "lblFolioDesc";
            this.lblFolioDesc.Size = new System.Drawing.Size(10, 13);
            this.lblFolioDesc.TabIndex = 52;
            this.lblFolioDesc.Text = "f";
            // 
            // lblFolioMod
            // 
            this.lblFolioMod.AutoSize = true;
            this.lblFolioMod.Location = new System.Drawing.Point(59, 11);
            this.lblFolioMod.Name = "lblFolioMod";
            this.lblFolioMod.Size = new System.Drawing.Size(32, 13);
            this.lblFolioMod.TabIndex = 50;
            this.lblFolioMod.Text = "Folio:";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(211, 35);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(47, 13);
            this.lblNombre.TabIndex = 56;
            this.lblNombre.Text = "Nombre:";
            // 
            // lblProveedor
            // 
            this.lblProveedor.AutoSize = true;
            this.lblProveedor.Location = new System.Drawing.Point(33, 35);
            this.lblProveedor.Name = "lblProveedor";
            this.lblProveedor.Size = new System.Drawing.Size(59, 13);
            this.lblProveedor.TabIndex = 55;
            this.lblProveedor.Text = "Proveedor:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(191, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 58;
            this.label1.Text = "Descripción:";
            // 
            // lblEstilo
            // 
            this.lblEstilo.AutoSize = true;
            this.lblEstilo.Location = new System.Drawing.Point(55, 57);
            this.lblEstilo.Name = "lblEstilo";
            this.lblEstilo.Size = new System.Drawing.Size(35, 13);
            this.lblEstilo.TabIndex = 57;
            this.lblEstilo.Text = "Estilo:";
            // 
            // gbxCambiaPrecio
            // 
            this.gbxCambiaPrecio.Controls.Add(this.lblError);
            this.gbxCambiaPrecio.Controls.Add(this.label5);
            this.gbxCambiaPrecio.Controls.Add(this.label4);
            this.gbxCambiaPrecio.Controls.Add(this.lblTPA);
            this.gbxCambiaPrecio.Controls.Add(this.lblNMA);
            this.gbxCambiaPrecio.Controls.Add(this.lblNPA);
            this.gbxCambiaPrecio.Controls.Add(this.lblTotalMargen);
            this.gbxCambiaPrecio.Controls.Add(this.lblMargen);
            this.gbxCambiaPrecio.Controls.Add(this.txtPrecio);
            this.gbxCambiaPrecio.Controls.Add(this.txtCosto);
            this.gbxCambiaPrecio.Controls.Add(this.lblPrecio);
            this.gbxCambiaPrecio.Controls.Add(this.lblTMA);
            this.gbxCambiaPrecio.Controls.Add(this.lblCosto);
            this.gbxCambiaPrecio.Controls.Add(this.btnCancelar);
            this.gbxCambiaPrecio.Controls.Add(this.lblNCA);
            this.gbxCambiaPrecio.Controls.Add(this.btnGuardarCambios);
            this.gbxCambiaPrecio.Controls.Add(this.lblTCA);
            this.gbxCambiaPrecio.Location = new System.Drawing.Point(555, 42);
            this.gbxCambiaPrecio.Name = "gbxCambiaPrecio";
            this.gbxCambiaPrecio.Size = new System.Drawing.Size(492, 216);
            this.gbxCambiaPrecio.TabIndex = 59;
            this.gbxCambiaPrecio.TabStop = false;
            this.gbxCambiaPrecio.Text = "Cambia Precio";
            // 
            // lblError
            // 
            this.lblError.AutoSize = true;
            this.lblError.ForeColor = System.Drawing.Color.Red;
            this.lblError.Location = new System.Drawing.Point(9, 200);
            this.lblError.Name = "lblError";
            this.lblError.Size = new System.Drawing.Size(28, 13);
            this.lblError.TabIndex = 63;
            this.lblError.Text = "error";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(237, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 20);
            this.label5.TabIndex = 46;
            this.label5.Text = "Nuevo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(51, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 20);
            this.label4.TabIndex = 45;
            this.label4.Text = "Actual";
            // 
            // lblTPA
            // 
            this.lblTPA.AutoSize = true;
            this.lblTPA.Location = new System.Drawing.Point(80, 114);
            this.lblTPA.Name = "lblTPA";
            this.lblTPA.Size = new System.Drawing.Size(34, 13);
            this.lblTPA.TabIndex = 44;
            this.lblTPA.Text = "totalP";
            // 
            // lblNMA
            // 
            this.lblNMA.AutoSize = true;
            this.lblNMA.Location = new System.Drawing.Point(32, 166);
            this.lblNMA.Name = "lblNMA";
            this.lblNMA.Size = new System.Drawing.Size(46, 13);
            this.lblNMA.TabIndex = 11;
            this.lblNMA.Text = "Margen:";
            // 
            // lblNPA
            // 
            this.lblNPA.AutoSize = true;
            this.lblNPA.Location = new System.Drawing.Point(34, 114);
            this.lblNPA.Name = "lblNPA";
            this.lblNPA.Size = new System.Drawing.Size(40, 13);
            this.lblNPA.TabIndex = 10;
            this.lblNPA.Text = "Precio:";
            // 
            // lblTotalMargen
            // 
            this.lblTotalMargen.AutoSize = true;
            this.lblTotalMargen.Location = new System.Drawing.Point(229, 166);
            this.lblTotalMargen.Name = "lblTotalMargen";
            this.lblTotalMargen.Size = new System.Drawing.Size(36, 13);
            this.lblTotalMargen.TabIndex = 8;
            this.lblTotalMargen.Text = "totalM";
            // 
            // lblMargen
            // 
            this.lblMargen.AutoSize = true;
            this.lblMargen.Location = new System.Drawing.Point(179, 166);
            this.lblMargen.Name = "lblMargen";
            this.lblMargen.Size = new System.Drawing.Size(46, 13);
            this.lblMargen.TabIndex = 7;
            this.lblMargen.Text = "Margen:";
            // 
            // txtPrecio
            // 
            this.txtPrecio.Location = new System.Drawing.Point(225, 111);
            this.txtPrecio.MaxLength = 6;
            this.txtPrecio.Name = "txtPrecio";
            this.txtPrecio.Size = new System.Drawing.Size(100, 20);
            this.txtPrecio.TabIndex = 6;
            this.txtPrecio.TextChanged += new System.EventHandler(this.txtPrecio_TextChanged);
            this.txtPrecio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrecio_KeyPress);
            // 
            // txtCosto
            // 
            this.txtCosto.Location = new System.Drawing.Point(222, 62);
            this.txtCosto.MaxLength = 6;
            this.txtCosto.Name = "txtCosto";
            this.txtCosto.Size = new System.Drawing.Size(100, 20);
            this.txtCosto.TabIndex = 5;
            this.txtCosto.TextChanged += new System.EventHandler(this.txtCosto_TextChanged);
            this.txtCosto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCosto_KeyPress);
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.Location = new System.Drawing.Point(179, 114);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(40, 13);
            this.lblPrecio.TabIndex = 4;
            this.lblPrecio.Text = "Precio:";
            // 
            // lblTMA
            // 
            this.lblTMA.AutoSize = true;
            this.lblTMA.Location = new System.Drawing.Point(80, 166);
            this.lblTMA.Name = "lblTMA";
            this.lblTMA.Size = new System.Drawing.Size(36, 13);
            this.lblTMA.TabIndex = 43;
            this.lblTMA.Text = "totalM";
            // 
            // lblCosto
            // 
            this.lblCosto.AutoSize = true;
            this.lblCosto.Location = new System.Drawing.Point(179, 65);
            this.lblCosto.Name = "lblCosto";
            this.lblCosto.Size = new System.Drawing.Size(37, 13);
            this.lblCosto.TabIndex = 3;
            this.lblCosto.Text = "Costo:";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Image = global::MmsWin.Front.Properties.Resources._109_AllAnnotations_Error_16x16_72;
            this.btnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelar.Location = new System.Drawing.Point(346, 111);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 25);
            this.btnCancelar.TabIndex = 15;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // lblNCA
            // 
            this.lblNCA.AutoSize = true;
            this.lblNCA.Location = new System.Drawing.Point(37, 69);
            this.lblNCA.Name = "lblNCA";
            this.lblNCA.Size = new System.Drawing.Size(37, 13);
            this.lblNCA.TabIndex = 41;
            this.lblNCA.Text = "Costo:";
            // 
            // btnGuardarCambios
            // 
            this.btnGuardarCambios.Image = global::MmsWin.Front.Properties.Resources._109_AllAnnotations_Complete_16x16_72;
            this.btnGuardarCambios.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGuardarCambios.Location = new System.Drawing.Point(346, 69);
            this.btnGuardarCambios.Name = "btnGuardarCambios";
            this.btnGuardarCambios.Size = new System.Drawing.Size(75, 25);
            this.btnGuardarCambios.TabIndex = 14;
            this.btnGuardarCambios.Text = "Aceptar";
            this.btnGuardarCambios.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGuardarCambios.UseVisualStyleBackColor = true;
            this.btnGuardarCambios.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // lblTCA
            // 
            this.lblTCA.AutoSize = true;
            this.lblTCA.Location = new System.Drawing.Point(80, 69);
            this.lblTCA.Name = "lblTCA";
            this.lblTCA.Size = new System.Drawing.Size(34, 13);
            this.lblTCA.TabIndex = 36;
            this.lblTCA.Text = "totalC";
            // 
            // lblFechaMod
            // 
            this.lblFechaMod.AutoSize = true;
            this.lblFechaMod.Location = new System.Drawing.Point(910, 11);
            this.lblFechaMod.Name = "lblFechaMod";
            this.lblFechaMod.Size = new System.Drawing.Size(34, 13);
            this.lblFechaMod.TabIndex = 51;
            this.lblFechaMod.Text = "fecha";
            // 
            // dgvDetalleFolios
            // 
            this.dgvDetalleFolios.AllowUserToAddRows = false;
            this.dgvDetalleFolios.AllowUserToDeleteRows = false;
            this.dgvDetalleFolios.AllowUserToOrderColumns = true;
            this.dgvDetalleFolios.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDetalleFolios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetalleFolios.Location = new System.Drawing.Point(0, 27);
            this.dgvDetalleFolios.MultiSelect = false;
            this.dgvDetalleFolios.Name = "dgvDetalleFolios";
            this.dgvDetalleFolios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDetalleFolios.Size = new System.Drawing.Size(1128, 243);
            this.dgvDetalleFolios.TabIndex = 0;
            this.dgvDetalleFolios.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDetalleFolios_CellDoubleClick);
            // 
            // tspAutorizadas
            // 
            this.tspAutorizadas.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnMarcarDetalle,
            this.toolStripSeparator10,
            this.btnLiberar,
            this.toolStripSeparator8,
            this.btnAutorizar,
            this.toolStripSeparator3});
            this.tspAutorizadas.Location = new System.Drawing.Point(0, 0);
            this.tspAutorizadas.Name = "tspAutorizadas";
            this.tspAutorizadas.Size = new System.Drawing.Size(1128, 25);
            this.tspAutorizadas.TabIndex = 1;
            this.tspAutorizadas.Text = "Autorizar ";
            // 
            // btnMarcarDetalle
            // 
            this.btnMarcarDetalle.Image = global::MmsWin.Front.Properties.Resources.CheckBoxHS;
            this.btnMarcarDetalle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnMarcarDetalle.Name = "btnMarcarDetalle";
            this.btnMarcarDetalle.Size = new System.Drawing.Size(64, 22);
            this.btnMarcarDetalle.Text = "Marcar";
            this.btnMarcarDetalle.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 25);
            // 
            // btnLiberar
            // 
            this.btnLiberar.Image = global::MmsWin.Front.Properties.Resources.XSDSchema_AllIcon;
            this.btnLiberar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnLiberar.Name = "btnLiberar";
            this.btnLiberar.Size = new System.Drawing.Size(107, 22);
            this.btnLiberar.Text = "\"Des-autorizar\"";
            this.btnLiberar.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 25);
            // 
            // btnAutorizar
            // 
            this.btnAutorizar.Image = global::MmsWin.Front.Properties.Resources.PrimaryKeyHS;
            this.btnAutorizar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAutorizar.Name = "btnAutorizar";
            this.btnAutorizar.Size = new System.Drawing.Size(75, 22);
            this.btnAutorizar.Text = "Autorizar";
            this.btnAutorizar.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // CambioPrecio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1143, 460);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "CambioPrecio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cambio de Costo y Precio";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CambioPrecio_FormClosing);
            this.Load += new System.EventHandler(this.CambioPrecio_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.gpbEstilosDisponibles.ResumeLayout(false);
            this.gpbEstilosDisponibles.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstilosPreautorizados)).EndInit();
            this.gpbEstilosSeleccionados.ResumeLayout(false);
            this.gpbEstilosSeleccionados.PerformLayout();
            this.tspOrdenesSeleccionadas.ResumeLayout(false);
            this.tspOrdenesSeleccionadas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCPSeleccionadas)).EndInit();
            this.tspGeneracionFormatos.ResumeLayout(false);
            this.tspGeneracionFormatos.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.tspConsultaAutorizadas.ResumeLayout(false);
            this.tspConsultaAutorizadas.PerformLayout();
            this.pnlActualizar.ResumeLayout(false);
            this.pnlActualizar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetallePorFolio)).EndInit();
            this.gbxCambiaPrecio.ResumeLayout(false);
            this.gbxCambiaPrecio.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalleFolios)).EndInit();
            this.tspAutorizadas.ResumeLayout(false);
            this.tspAutorizadas.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox gpbEstilosDisponibles;
        private System.Windows.Forms.DataGridView dgvEstilosPreautorizados;
        private System.Windows.Forms.GroupBox gpbEstilosSeleccionados;
        private System.Windows.Forms.ToolStrip tspOrdenesSeleccionadas;
        private System.Windows.Forms.ToolStripButton btnGenerarFormato;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.DataGridView dgvCPSeleccionadas;
        private System.Windows.Forms.ToolStrip tspGeneracionFormatos;
        private System.Windows.Forms.ToolStripLabel lblFolio;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripLabel lblBuscarOc;
        private System.Windows.Forms.ToolStripTextBox txtBuscarCP;
        private System.Windows.Forms.ToolStripButton btnBuscarCP;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton btnMarcarTodas;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton btnAgregar;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.ToolStrip tspConsultaAutorizadas;
        private System.Windows.Forms.ToolStripLabel lblBuscar;
        private System.Windows.Forms.ToolStripTextBox txtBuscar;
        private System.Windows.Forms.ToolStripButton btnBuscarFolio;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton btnImprimir;
        private System.Windows.Forms.ListView lsvFolios;
        private System.Windows.Forms.ToolStrip tspAutorizadas;
        private System.Windows.Forms.ToolStripButton btnMarcarDetalle;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripButton btnLiberar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripButton btnAutorizar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.DataGridView dgvDetalleFolios;
        private System.Windows.Forms.ToolStripLabel tslblFecha;
        private System.Windows.Forms.ImageList imlFolios;
        private System.Windows.Forms.ToolStripButton tsbEliminarSeleccion;
        private System.Windows.Forms.Panel pnlActualizar;
        private System.Windows.Forms.DataGridView dgvDetallePorFolio;
        private System.Windows.Forms.Label lblEstiloDesc;
        private System.Windows.Forms.Label lblProvDesc;
        private System.Windows.Forms.Label lblIdEstilo;
        private System.Windows.Forms.Label lblIdProv;
        private System.Windows.Forms.Label lblFolioDesc;
        private System.Windows.Forms.Label lblFolioMod;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblProveedor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblEstilo;
        private System.Windows.Forms.GroupBox gbxCambiaPrecio;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblTPA;
        private System.Windows.Forms.Label lblNMA;
        private System.Windows.Forms.Label lblNPA;
        private System.Windows.Forms.Label lblTotalMargen;
        private System.Windows.Forms.Label lblMargen;
        private System.Windows.Forms.TextBox txtPrecio;
        private System.Windows.Forms.TextBox txtCosto;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Label lblTMA;
        private System.Windows.Forms.Label lblCosto;
        private System.Windows.Forms.Label lblNCA;
        private System.Windows.Forms.Label lblTCA;
        private System.Windows.Forms.Label lblFechaMod;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnGuardarCambios;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripComboBox cboEstatus;
        private System.Windows.Forms.Label lblError;
        private System.Windows.Forms.Label lblMarcaDesc;
        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.Label lblTemporada;
        private System.Windows.Forms.Label lblTEmp;
        private System.Windows.Forms.Label lblComDesc;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblIdComp;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripLabel lblTempo;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btRelleno;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.TextBox tbProveedor;
        private System.Windows.Forms.ComboBox cbCompradores;




    }
}