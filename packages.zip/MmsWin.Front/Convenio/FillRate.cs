﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MmsWin.Negocio;
using MmsWin.Negocio.Convenio;

namespace MmsWin.Front.Convenio
{
    public partial class FillRate : Form
    {
        //Se les asigna su valor desde la pantalla de convenio
        //dependiendo de la selección de los combos de marca y comprador
        public Comun.Engine.Marca Marca { get; set; }
        public int Comprador { get; set; }
        //-------------------------------------------------------

        //Se usan para el marcado y desmarcado de los checkbox en las grid
        bool CheckMarcados = false;
        bool CheckMarcadosDetalle = false;
        //---------------------------------------------------------

        /// <summary>
        /// Número de folio de la solicitud
        /// </summary>
        string Folio = "";

        /// <summary>
        ///Matriz para separar el folio y el estatus del estilo 
        /// </summary>
        string[] item;

        int Proveedor = 0;
        int xj = 0;

        //DataTable dtFiltroFolio = null;
        DataTable dtCambioPrecio = null;
        private BindingSource bsFiltroPre;

        DataTable dtProveedores = null;
        private BindingSource bsProveedores;


        DataTable dtFolios = null;
        private BindingSource bsFolios;

        string pMonto = "";
        string pPenalizacion = "";
        string pFillRate = "";


        string origen = "";

        public FillRate()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Evento Click de todos los botones de la pantalla
        /// </summary>
        /// <param name="sender">Sender (Default)</param>
        /// <param name="e">e (Default)</param>
        private void Buttons_Click(object sender, EventArgs e)
        {
            dgvEstilosPreautorizados.EndEdit();
            dgvEstilosPreautorizados.ClearSelection();
            this.dgvEstilosPreautorizados.Refresh();

            this.dgvDetalleFolios.EndEdit();
            this.dgvDetalleFolios.ClearSelection();
            this.dgvDetalleFolios.Refresh();

            string msg = "";

            string ordenCompraValidar = "";
            bool Existe = false;
            decimal Penalizacion = 0;

            try
            {
                if (sender == this.btnNuevoMonto)
                {
                    this.pnlActualizar.Visible = true;
                }

                if (sender == this.btnAutorizar)
                {
                    AutorizarEstilosSeleccionados();
                    AplicarEstiloGrids(this.dgvEstilosPreautorizados);
                    AplicarEstiloGrids(this.dgvDetalleFolios);
                }

                if (sender == this.btnLiberar)
                {
                    msg = "Las Ordenes de Compra marcadas [*], seran quitados de la solicitud y quedaran disponibles para ser asignados a otra.\n\n¿Desea continuar?";
                    if (MessageBox.Show(msg, "Convenio", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                    {
                        LiberarEstilosSeleccionados();
                        CargaOrdenesCompra();
                        CargaOrdenesCompra(2, item[0]);
                        //this.dgvDetalleFolios.DataSource = Negocio.Convenio.Reprogramacion.CargaListaFoliosOC(item[0]);
                        //this.dgvEstilosPreautorizados.DataSource = Negocio.Convenio.Reprogramacion.(Marca);
                        CargaFolios();
                        AplicarEstiloGrids(this.dgvEstilosPreautorizados);
                        AplicarEstiloGrids(this.dgvDetalleFolios);

                    }
                }

                if (sender == this.btnMarcarTodas)
                {
                    //Marcar o desmarcar todos los estilos de la lista
                    foreach (DataGridViewRow row in this.dgvEstilosPreautorizados.Rows)
                    {
                        DataGridViewCheckBoxCell chk = dgvEstilosPreautorizados.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                        chk.Value = false;
                        chk.ReadOnly = false;

                        if (Convert.ToInt32(this.dgvEstilosPreautorizados.Rows[row.Index].Cells["FillRateOC"].Value) < 90)
                        {
                            //row.Cells[0].Value = !CheckMarcados;
                            chk.Value = !CheckMarcados;
                            chk.ReadOnly = false;
                        }
                        else
                        {
                            chk.ReadOnly = true;
                        }
                    }

                    CheckMarcados = !CheckMarcados;
                }

                if (sender == this.btnMarcarDetalle)
                {
                    //Marcar o desmarcar todos los estilos de la lista
                    foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
                    {
                        row.Cells[0].Value = !CheckMarcadosDetalle;
                    }

                    CheckMarcadosDetalle = !CheckMarcadosDetalle;
                }

                if (sender == this.btnAgregar)
                {
                    EliminaRegistros();

                    foreach (DataGridViewRow row in this.dgvEstilosPreautorizados.Rows)
                    {
                        //Instanciar la columna checkbox de la grid de Ordenes de Compra
                        DataGridViewCheckBoxCell chk = dgvEstilosPreautorizados.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                        //Orden de Compra seleccionada??
                        if (Convert.ToBoolean(chk.Value) == true)
                        {
                            if (this.dgvOCSeleccionadas.RowCount == 0)
                            {
                                //Obtener el primer proveedor de la primer Orden de Compra, para validar que siempre sea el mismo
                                Proveedor = Convert.ToInt32(dgvEstilosPreautorizados.Rows[row.Index].Cells["POVNUM"].Value);
                            }

                            //Validar que el proveedor sea el mismo
                            if (Proveedor == Convert.ToInt32(dgvEstilosPreautorizados.Rows[row.Index].Cells["POVNUM"].Value))
                            {
                                //Recuperar OC de la selección
                                ordenCompraValidar = dgvEstilosPreautorizados.Rows[row.Index].Cells["PONUMB"].Value.ToString();

                                //Penalizacion = Convert.ToDecimal(dgvEstilosPreautorizados.Rows[row.Index].Cells["FillRateOC"].Value.ToString());

                                //if (Penalizacion == -1)
                                //{
                                //    MessageBox.Show("El proveedor no cumple con la calificación mínima de FillRate estipulada.\n\n Orden de Compra: " + dgvEstilosPreautorizados.Rows[row.Index].Cells["PONUMB"].Value, "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                //}
                                //else if (Penalizacion == 0)
                                //{
                                //    MessageBox.Show("No aplica penalización.\n\n Orden de Compra: " + dgvEstilosPreautorizados.Rows[row.Index].Cells["PONUMB"].Value, "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                //}
                                //else
                                //{
                                if (this.dgvOCSeleccionadas.RowCount > 0)
                                {

                                    //Validar que la Orden de Compra no se haya agregado previamente a la grid
                                    foreach (DataGridViewRow rowt in this.dgvOCSeleccionadas.Rows)
                                    {
                                        Existe = (ordenCompraValidar == dgvOCSeleccionadas.Rows[rowt.Index].Cells["OrdenCompra"].Value.ToString()) ? true : false;

                                        if (Existe == true)
                                        {
                                            //MessageBox.Show(string.Format("La Orden de Compra: {0} ya ha sido ingresada.", ordenCompraValidar), "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                            break;
                                        }
                                    }

                                    if (Existe == false)
                                    {
                                        this.dgvOCSeleccionadas.Rows.Add(dgvEstilosPreautorizados.Rows[row.Index].Cells["PONUMB"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["POVNUM"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["ASNAME"].Value);
                                    }
                                    else
                                    {
                                        Existe = false;
                                    }
                                }
                                else
                                {
                                    this.dgvOCSeleccionadas.Rows.Add(dgvEstilosPreautorizados.Rows[row.Index].Cells["PONUMB"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["POVNUM"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["ASNAME"].Value);
                                }
                                // }

                            }
                            else
                            {
                                MessageBox.Show(string.Format("Las Ordenes de Compra deben pertenecer del mismo proveedor.\n\nOrden de Compra no agregada: {0}", dgvEstilosPreautorizados.Rows[row.Index].Cells["PONUMB"].Value), "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            }
                        }
                    }
                }

                if (sender == this.btnImprimir)
                {
                    if (Convert.ToInt32(item[0]) > 0)
                    {
                          xj = 0;
                        foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
                        {
                            if (dgvDetalleFolios.Rows[row.Index].Cells["FFRNMT"].Value.ToString() == "0")
                            {
                                xj++;
                            }
                        }

                        if (xj > 0)
                        {
                            MessageBox.Show("Debe de capturar el  y el motivo para poder imprimir.", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                        else
                        {
                            rptFillRate f = new rptFillRate();
                            f.StartPosition = FormStartPosition.CenterParent;
                            f.Folio = Convert.ToInt32(item[0]);
                            f.FillRate = pFillRate;
                            f.Penalizacion = pPenalizacion;
                            f.Monto = pMonto;
                            f.ShowDialog(this);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Debe seleccionar una solicitud para imprimirla", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }

                }

                if (sender == this.tsbEliminarTodos)
                {
                    EliminaRegistros();
                }

                if (sender == this.btnGenerarFormato)
                {
                    if (this.dgvOCSeleccionadas.Rows.Count > 0)
                    {

                        if (MessageBox.Show("Las Órdenes de Compra seleccionadas se asignaran a un nuevo folio de Solicitud de excepción  de pago de Fill Rate\n\n¿Desea continuar?", "Convenio", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                        {
                            Folio = Negocio.Convenio.Reprogramacion.ObtenerFolio(3);
                            this.lblFolio.Text = string.Format("Folio: {0}", Folio);

                            LigarOCFolio();

                            MessageBox.Show(string.Format("Se genero la solicitud con el número de folio: {0}", Folio), "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            Folio = "";

                            //this.dgvEstilosPreautorizados.DataSource = Negocio.Convenio.Reprogramacion.CargaReprogramacionesSinFormato(Marca);

                            EliminaRegistros();
                            CargaOrdenesCompra();
                            CargaFolios();
                            AplicarEstiloGrids(this.dgvEstilosPreautorizados);


                        }
                        else
                        {
                            MessageBox.Show("La operación fue cancelada, no se realizaron cambios.", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                    else
                    {
                        MessageBox.Show("ATENCIÓN!\nNo se han seleccionado estilos para asignar un folio, marquelos y haga click en el botón de 'Actualizar estilos'", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }

                //if (sender == this.btnBuscarOc)
                //{
                //    CargaOrdenesCompra();
                //    AplicarEstiloGrids(this.dgvEstilosPreautorizados);
                //}

                if (sender == this.btnCancelar)
                {
                    this.pnlActualizar.Visible = false;
                }

                if (sender == this.btnAceptar)
                {
                    //if (this.dtpFechaAmpliacion.Value <= DateTime.Now)
                    //{
                    //MessageBox.Show("La fecha de ampliación de la Orden de Compra tiene que ser mayor a la fecha actual", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //}
                    //else
                    //{
                    Negocio.Convenio.Reprogramacion.ActualizarMontoFR(
                            DateTime.Now,
                            Convert.ToInt32(this.cboMotivo.SelectedValue),
                              Convert.ToInt32(item[0]),
                            Convert.ToInt32(this.txtNuevoMonto.Text));

                    MessageBox.Show("El monto y el motivo fueron actualizados", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.lblMonto2.Text = "Nuevo monto: " + string.Format(this.txtNuevoMonto.Text, "###,###,###,###");
                    this.pnlActualizar.Visible = false;

                    Cursor.Current = Cursors.WaitCursor;

                    CargaOrdenesCompra();
                    CargaOrdenesCompra(2, item[0]);
                    Cursor.Current = Cursors.Default;
                    //}
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void CargaProveedores()
        {
            this.dgvProveedores.DataSource = null;

            //Cargar la grid con las ordenes de compra dispobibles para el formato
            dtProveedores = Negocio.Convenio.Reprogramacion.obtCatProveedoresFillRate();//, Convert.ToInt32(q), Vista);
            bsProveedores = new BindingSource(dtProveedores, null);

            this.dgvProveedores.DataSource = bsProveedores;
            //Filtrar();

            dgvProveedores.Columns["ASNUM"].HeaderText = " # ";
            dgvProveedores.Columns["ASNUM"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            dgvProveedores.Columns["ASNUM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //dgvProveedores.Columns["ASNUM"].DefaultCellStyle.Format = "###,###,###,###";
            dgvProveedores.Columns["ASNUM"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            //dgvProveedores.Columns["ASNUM"].DefaultCellStyle.ForeColor = Color.Blue;

            dgvProveedores.Columns["NOMBRE"].HeaderText = "PROVEEDOR";
            dgvProveedores.Columns["NOMBRE"].Width = 180;// = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            dgvProveedores.Columns["NOMBRE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //dgvProveedores.Columns["ASNUM"].DefaultCellStyle.Format = "###,###,###,###";
            dgvProveedores.Columns["NOMBRE"].DefaultCellStyle.Font = new Font("Tahoma", 8);//Fecha inspección
            //dgvProveedores.Columns["ASNUM"].DefaultCellStyle.ForeColor = Color.Blue;

            dgvProveedores.Columns["FILLRATE"].HeaderText = "FLRT ";
            dgvProveedores.Columns["FILLRATE"].ToolTipText = "Fill Rate de los últimos 6 meses";
            dgvProveedores.Columns["FILLRATE"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            dgvProveedores.Columns["FILLRATE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvProveedores.Columns["FILLRATE"].DefaultCellStyle.Format = "###,###,###,###.##";
            dgvProveedores.Columns["FILLRATE"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            dgvProveedores.Columns["FILLRATE"].DefaultCellStyle.ForeColor = Color.Blue;

            dgvProveedores.Columns["NUORCO"].HeaderText = "#OC";
            dgvProveedores.Columns["NUORCO"].ToolTipText = "Total de Ordenes de Compra recibidas en el periodo en revisión";
            dgvProveedores.Columns["NUORCO"].Width = 35;// = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            dgvProveedores.Columns["NUORCO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //dgvProveedores.Columns["ASNUM"].DefaultCellStyle.Format = "###,###,###,###";
            dgvProveedores.Columns["NUORCO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            //dgvProveedores.Columns["ASNUM"].DefaultCellStyle.ForeColor = Color.Blue;

        }

        private void CargaOrdenesCompra(byte Vista = 1, string Folio = "0")
        {
            string filtro = "";
            string[] Periodo = new string[2];

            if (Vista == 1)
            {
                dgvEstilosPreautorizados.DataSource = null;

                //Cargar la grid con las ordenes de compra dispobibles para el formato
                dtCambioPrecio = Negocio.Convenio.Reprogramacion.CargaOCFillRate(this.txtBuscarOc.Text.Trim());//, Convert.ToInt32(q), Vista);
                bsFiltroPre = new BindingSource(dtCambioPrecio, null);
                Filtrar();
                this.dgvEstilosPreautorizados.DataSource = bsFiltroPre;
                this.lblTot1.Text = string.Format("Ordenes de Compra: {0}", this.dgvEstilosPreautorizados.RowCount.ToString());

                Periodo = Negocio.Convenio.Reprogramacion.ObtFechasPeriodoFillRate(6);
                this.lblPeriodo.Text = string.Format(" |  Periodo, del {0}  al {1}", Periodo[0], Periodo[1]);
            }
            else if (Vista == 2)
            {
                dgvDetalleFolios.DataSource = null;

                bsFiltroPre.RemoveFilter();
                dtFolios = dtCambioPrecio.Copy();
                bsFolios = new BindingSource(dtFolios, null);

                filtro = (this.cboEstatus.ComboBox.SelectedItem == "Pendientes") ? "P" : "A";

                this.dgvDetalleFolios.DataSource = bsFolios;//Negocio.Convenio.Reprogramacion.CargaOCFillRate(Convert.ToInt32(Folio));

                bsFolios.Filter = string.Format("FFRFOL = {0} AND FFREST = '{1}'  ", Folio, filtro);

                try
                {
                    AplicarEstiloGrids(this.dgvDetalleFolios);
                }
                catch
                {
                    throw;
                }
            }



        }

        private void AutorizarEstilosSeleccionados()
        {
            //int check = 0;
            //int noCheck = 0;
            int motivo = 0;

            Folio = item[0];

            foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
            {
                // DataGridViewCheckBoxCell chk = dgvDetalleFolios.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                //if (Convert.ToBoolean(chk.Value) == true)
                //{
                //    check++;
                //}
                //else
                //{
                //    noCheck++;
                //}

                if (dgvDetalleFolios.Rows[row.Index].Cells["Motivo"].Value.ToString() == "0")
                {
                    motivo++;
                }
            }

            //if (motivo > 0)
            //{
            //    MessageBox.Show("Debe de capturar la nueva fecha y el motivo para poder autorizar.", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //    return;
            //}

            //if (noCheck == 0)
            //{
            foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
            {
                //DataGridViewCheckBoxCell chk = dgvDetalleFolios.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                //if (Convert.ToBoolean(chk.Value) == true)
                //{
                Negocio.Convenio.Reprogramacion.AutorizarExcepcionFillRate(
                    Convert.ToInt32(dgvDetalleFolios.Rows[row.Index].Cells["PONUMB"].Value)
                    );
                //}
            }

            CargaOrdenesCompra();
            CargaOrdenesCompra(2, item[0]);
            //this.dgvDetalleFolios.DataSource = Negocio.Convenio.Reprogramacion.CargaDetalleFolio(Folio);
            //this.dgvEstilosPreautorizados.DataSource = Negocio.Convenio.Reprogramacion.CargaReprogramacionesSinFormato(Marca);
            
            CargaFolios();
            this.btnMarcarDetalle.Enabled = false;
            this.btnAutorizar.Enabled = false;
            this.btnLiberar.Enabled = false;
            MessageBox.Show("SOLICITUD [ " + Folio + " ] AUTORIZADA correctamente.", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Information);

            //}
            //else
            //{
            //    MessageBox.Show("Debe de seleccionar todas las casillas para autorizar la solicitud. Si desea excluir estilos, primero debe liberarlos.", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //}
        }

        /// <summary>
        /// Desvincula los estilos seleccionados del folio en revisión y quedan libres para asignarse a otra solicitud
        /// </summary>
        private void LiberarEstilosSeleccionados()
        {
            foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
            {
                DataGridViewCheckBoxCell chk = dgvDetalleFolios.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                if (Convert.ToBoolean(chk.Value) == true)
                {
                    Negocio.Convenio.Reprogramacion.LiberarOrdeneCompraFillRate(
                        Convert.ToInt32(dgvDetalleFolios.Rows[row.Index].Cells["PONUMB"].Value.ToString())
                   );

                }
            }

            CargaOrdenesCompra(2, item[0]);
        }

        /// <summary>
        /// Liga los estilos seleccionados al folio correspondiente
        /// </summary>
        private void LigarOCFolio()
        {
            foreach (DataGridViewRow row in this.dgvOCSeleccionadas.Rows)
            {
                //DataGridViewCheckBoxCell chk = dgvEstilosPreautorizados.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                //if (Convert.ToBoolean(chk.Value) == true)
                //{
                Negocio.Convenio.Reprogramacion.AsignaFolioOCFillRate(
                    Convert.ToInt32(Folio),
                    Convert.ToInt32(dgvOCSeleccionadas.Rows[row.Index].Cells["OrdenCompra"].Value.ToString()),
                    "PGMCGC");
                //}
            }
        }

        /// <summary>
        /// Borrar los registros de la grid de estilos seleccionados
        /// </summary>
        private void EliminaRegistros()
        {
            int r = (dgvOCSeleccionadas.Rows.Count - 1);

            for (int i = 0; i <= r; i++)
            {
                dgvOCSeleccionadas.Rows.RemoveAt(0);
            }
        }

        /// <summary>
        /// Inicialización de la pantalla
        /// </summary>
        /// <param name="sender">Sender (Default)</param>
        /// <param name="e">e (Default)</param>
        private void Preautorizaciones_Load(object sender, EventArgs e)
        {
            this.cboOrigen.ComboBox.SelectedItem = "Nacional";
            this.cboEstatus.ComboBox.SelectedItem = "Pendientes";
            this.lblFolio.Text = "Folio: N/G";
            this.pnlActualizar.Visible = false;

            this.cboMotivo.DataSource = Negocio.Convenio.Reprogramacion.CargaMotivosExceFillRate();
            this.cboMotivo.DisplayMember = "Descripcion";
            this.cboMotivo.ValueMember = "Id";

            CargaProveedores();

            CargaOrdenesCompra();

            //Agregar columna "CheckBox" a los estilos que se seleccionaran para agregar al formato
            DataGridViewCheckBoxColumn CheckboxColumn = new DataGridViewCheckBoxColumn();
            CheckboxColumn.TrueValue = true;
            CheckboxColumn.FalseValue = false;
            CheckboxColumn.Width = 100;
            dgvEstilosPreautorizados.Columns.Insert(0, CheckboxColumn);

            DataGridViewCheckBoxColumn Checkbox_Column = new DataGridViewCheckBoxColumn();
            CheckboxColumn.TrueValue = true;
            CheckboxColumn.FalseValue = false;
            CheckboxColumn.Width = 100;
            dgvDetalleFolios.Columns.Insert(0, Checkbox_Column);

            dgvEstilosPreautorizados.EditMode = DataGridViewEditMode.EditOnKeystroke;
            dgvDetalleFolios.EditMode = DataGridViewEditMode.EditOnKeystroke;

            //-----------------------------------------------------------------------------------------

            CargaFolios();
            
            this.dgvOCSeleccionadas.Columns.Add("OrdenCompra", "OrdenCompra");
            this.dgvOCSeleccionadas.Columns.Add("NoProveedor", "NoProveedor");
            this.dgvOCSeleccionadas.Columns.Add("Proveedor", "Proveedor");

            AplicarEstiloGrids(this.dgvEstilosPreautorizados);
        }

        private void AplicarEstiloGrids(DataGridView Grid)
        {

            ////Visibilidad

            //Grid.Columns[0].Visible = false; //Columna de los checkbox

            Grid.Columns["FFRFOL"].Visible = false;
            Grid.Columns["POSTAT"].Visible = false;
            Grid.Columns["FFRFID"].Visible = false;
            Grid.Columns["FFRNMT"].Visible = false;
            Grid.Columns["Motivo"].Visible = false;
            Grid.Columns["FFREST"].Visible = false;
            Grid.Columns["ORIGEN"].Visible = false;
            //Grid.Columns["Penalizacion"].Visible = false;
            Grid.Columns["Monto"].Visible = false;
            Grid.Columns["POVNUM"].Visible = false;
            Grid.Columns["ASNAME"].Visible = false;


            //Fuente
            //this.dgvEstilosPreautorizados.Columns[0].Frozen = true;
            Grid.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;

            Grid.Columns["PONUMB"].Frozen = true;
            Grid.Columns["PONUMB"].DefaultCellStyle.Font = new Font("Tahoma", 9, FontStyle.Bold);//Fecha inspección
            Grid.Columns["PONUMB"].DefaultCellStyle.ForeColor = Color.Maroon;
            Grid.Columns["PONUMB"].HeaderText = "NoOC";
            Grid.Columns["PONUMB"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;

            Grid.Columns["Estilo"].Frozen = true;
            Grid.Columns["Estilo"].HeaderText = "No.Est";
            Grid.Columns["Estilo"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
            Grid.Columns["Estilo"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Grid.Columns["SSTYLE"].HeaderText = "Estilo";
            Grid.Columns["SSTYLE"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;

            Grid.Columns["POVNUM"].HeaderText = "NoProv";
            Grid.Columns["POVNUM"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            Grid.Columns["POVNUM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Grid.Columns["ASNAME"].HeaderText = "Proveedor";
            Grid.Columns["ASNAME"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;

            Grid.Columns["TEMPORADA"].HeaderText = "TEM";
            Grid.Columns["TEMPORADA"].Width = 30;// = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            Grid.Columns["TEMPORADA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Grid.Columns["CANTIDAD"].HeaderText = "Pzs Solicitadas";
            Grid.Columns["CANTIDAD"].Width = 70;
            Grid.Columns["CANTIDAD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["CANTIDAD"].DefaultCellStyle.Format = "###,###,###,###";
            Grid.Columns["CANTIDAD"].DefaultCellStyle.Font = new Font("Tahoma", 9, FontStyle.Bold);//Fecha inspección

            //Grid.Columns["MONTO"].HeaderText = "Monto Penalización";
            //Grid.Columns["MONTO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            //Grid.Columns["MONTO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            //Grid.Columns["MONTO"].DefaultCellStyle.Format = "###,###,###,###";
            //Grid.Columns["MONTO"].DefaultCellStyle.Font = new Font("Tahoma", 10, FontStyle.Bold);//Fecha inspección

            Grid.Columns["RECIBIDAS"].HeaderText = "Pzs Recibidas";
            Grid.Columns["RECIBIDAS"].Width = 70;
            Grid.Columns["RECIBIDAS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["RECIBIDAS"].DefaultCellStyle.Format = "###,###,###,###";
            Grid.Columns["RECIBIDAS"].DefaultCellStyle.Font = new Font("Tahoma", 9, FontStyle.Bold);//Fecha inspección
            Grid.Columns["RECIBIDAS"].DefaultCellStyle.ForeColor = Color.Blue;

            Grid.Columns["FILLRATEOC"].HeaderText = "FLRT";
            Grid.Columns["FILLRATEOC"].ToolTipText = "Fill Rate de la Orden de Compra";
            Grid.Columns["FILLRATEOC"].Width = 35;

            Grid.Columns["FILLRATEOC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["FILLRATEOC"].DefaultCellStyle.Format = "###,###,###,###";

            //Grid.Columns["PENALIZACION"].HeaderText = "%Penalización";
            //Grid.Columns["PENALIZACION"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            //Grid.Columns["PENALIZACION"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //Grid.Columns["PENALIZACION"].DefaultCellStyle.Format = "###,###,###,###";
            //Grid.Columns["PENALIZACION"].DefaultCellStyle.Font = new Font("Tahoma", 10, FontStyle.Bold);//Fecha inspección
            //Grid.Columns["PENALIZACION"].DefaultCellStyle.ForeColor = Color.Maroon;



            Grid.Columns["COSTO"].HeaderText = "Cst";
            Grid.Columns["COSTO"].Width = 25;
            Grid.Columns["COSTO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            Grid.Columns["COSTO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["COSTO"].DefaultCellStyle.Format = "###,###,###,###";

            Grid.Columns["FFRNMT"].HeaderText = "NvoMonto";
            Grid.Columns["FFRNMT"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            Grid.Columns["FFRNMT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["FFRNMT"].DefaultCellStyle.Format = "###,###,###,###";

            Grid.Columns["FechaEntrada"].HeaderText = "Entrada";
            Grid.Columns["FechaEntrada"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            Grid.Columns["FechaEntrada"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Grid.Columns["FFRFOL"].HeaderText = "FOLIO";
            Grid.Columns["FFRFOL"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            Grid.Columns["FFRFOL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            #region [ Dar formato a la grid de estilos seleccionados ]

           


            //Fuente
            this.dgvOCSeleccionadas.Columns["OrdenCompra"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            this.dgvOCSeleccionadas.Columns["OrdenCompra"].DefaultCellStyle.ForeColor = Color.Maroon;
            this.dgvOCSeleccionadas.Columns["NoProveedor"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            this.dgvOCSeleccionadas.Columns["NoProveedor"].Visible = false;
            this.dgvOCSeleccionadas.Columns["Proveedor"].Visible = false;

            //Ancho
            this.dgvOCSeleccionadas.Columns["OrdenCompra"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvOCSeleccionadas.Columns["NoProveedor"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvOCSeleccionadas.Columns["Proveedor"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;

            #endregion

        }

        /// <summary>
        /// Llena el listview con los folios generados
        /// </summary>
        /// <param name="Folio">Folio que se desea buscar</param>
        private void CargaFolios(string Folio = "")
        {
            DataTable dt = new DataTable();
            int imagen = 0;

            string q = "";

            q = (this.cboEstatus.ComboBox.SelectedItem == "Pendientes") ? "P" : "A";

            dt = Negocio.Convenio.Reprogramacion.CargaListaFoliosOCFillRate(this.txtBuscar.Text.Trim(), q);

            this.lsvFolios.Items.Clear();

            for (int i = 0; i < dt.Rows.Count; i++)
            {

                DataRow dr = dt.Rows[i];

                if (dr["Estatus"].ToString() == "Autorizado")
                {
                    imagen = 3;
                }
                else
                {
                    imagen = 0;
                }

                this.lsvFolios.Items.Add(dr["Folio"].ToString() + "," + dr["Estatus"].ToString(), dr["Folio"].ToString() + "\n" + dr["Estatus"].ToString(), imagen);
            }

            dt.Dispose();
        }

        private void lsvFolios_DoubleClick(object sender, EventArgs e)
        {
            int Solicitadas = 0;
            int Recibidas = 0;
            decimal Monto = 0;
            int NvoMonto = 0;
            int Proveedor = 0;
            //decimal FillRate = 0;
            decimal FillRate6M = 0;
            decimal penalizacion = 0;

            //Recuperar el folio
            item = this.lsvFolios.SelectedItems[0].Name.Split(',');

            CargaOrdenesCompra(2, item[0]);

            dgvDetalleFolios.Columns["Motivo"].Visible = true;
            dgvDetalleFolios.Columns["FFRNMT"].Visible = true;

            dgvDetalleFolios.Columns["FFRFOL"].Visible = true;
            dgvDetalleFolios.Columns["POVNUM"].Visible = true;
            dgvDetalleFolios.Columns["ASNAME"].Visible = true;

            if (item[1] == "Autorizado" || item[1] == "Vencido")
            {
                this.btnMarcarDetalle.Enabled = false;
                this.btnAutorizar.Enabled = false;
                this.btnLiberar.Enabled = false;
            }
            else
            {
                this.btnMarcarDetalle.Enabled = true;
                this.btnAutorizar.Enabled = true;
                this.btnLiberar.Enabled = true;
            }


            foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
            {
                Solicitadas += Convert.ToInt32(dgvDetalleFolios.Rows[row.Index].Cells["CANTIDAD"].Value);
                Recibidas += Convert.ToInt32(dgvDetalleFolios.Rows[row.Index].Cells["RECIBIDAS"].Value);
                Monto += Convert.ToInt32(dgvDetalleFolios.Rows[row.Index].Cells["MONTO"].Value);
                NvoMonto = Convert.ToInt32(dgvDetalleFolios.Rows[row.Index].Cells["FFRNMT"].Value);
                Proveedor = Convert.ToInt32(dgvDetalleFolios.Rows[row.Index].Cells["POVNUM"].Value);
            }
            //FillRate = Negocio.Convenio.Reprogramacion.ObtFillRatePolitica_porProveedor(Proveedor, 6);
            FillRate6M = Negocio.Convenio.Reprogramacion.ObtFillRatePolitica_porProveedor(Proveedor, 5);
            penalizacion = Negocio.Convenio.Reprogramacion.ObtenerPorcentajePenalizacion(FillRate6M);

            Monto = (Monto * penalizacion) / 100;

            pFillRate = FillRate6M.ToString("###,###,###,###");
            pPenalizacion = penalizacion.ToString("###,###,###,###") + "%";
            pMonto = Monto.ToString("###,###,###,###");

            this.lblSolicitadas.Text = "Solicitadas: " + Solicitadas.ToString("###,###,###,###");
            this.lblRecibidas.Text = "Recibidas: " + Recibidas.ToString("###,###,###,###");
            this.lblImporte.Text = "Diferencia: " + (Solicitadas - Recibidas).ToString("###,###,###,###");


            //if (Solicitadas != 0)
            //    this.lblFillRate.Text = "FillRate periodo: " + FillRate.ToString();
            //else
            //    this.lblFillRate.Text = "FillRate periodo: ";
            this.lblFillRate.Text = "";

            this.lblFillRate6M.Text = "Fill Rate: " + FillRate6M.ToString();
            this.lblPenalizacion.Text = "Penalización: " + penalizacion + "%";

            if (penalizacion == 0)
            {
                this.lblMonto.Visible = false;
                this.lblMonto2.Visible = false;
                this.btnNuevoMonto.Enabled = false;
            }
            else
            {
                this.lblMonto.Visible = true;
                this.lblMonto2.Visible = true;
                this.btnNuevoMonto.Enabled = true;

                this.lblMonto.Text = "Monto: " + Monto.ToString("###,###,###,###");
                this.lblMonto2.Text = "Nvo. Monto: " + NvoMonto.ToString("###,###,###,###");
            }




        }

        //private void Event_cbo_SelectIndexChanged(object sender, EventArgs e)
        //{
        //    if (sender == this.cboOrigen)
        //    {
        //        CargaOrdenesCompra();
        //    }
        //    if (sender == this.cboEstatus)
        //    {
        //        CargaFolios();
        //        if (this.cboEstatus.SelectedItem == "Autorizadas")
        //        {
        //            this.btnImprimir.Enabled = false;
        //        }
        //        else
        //        { this.btnImprimir.Enabled = true; }
        //    }
        //}

        private void dgvDetalleFolios_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //this.pnlActualizar.Visible = true;
            //this.lblOrdenCompra.Text = this.dgvDetalleFolios.Rows[e.RowIndex].Cells["PONUMB"].Value.ToString();
        }

        private void txtBuscarOc_TextChanged(object sender, EventArgs e)
        {
            Filtrar();
        }


        private void Filtrar(string Proveedor = "")
        {
            bsFiltroPre.RemoveFilter();
            origen = (this.cboOrigen.ComboBox.SelectedItem == "Nacional") ? "1" : "2";

            if (Proveedor == string.Empty)
            {
                bsFiltroPre.Filter = string.Format("FFRFOL = 9999 ", origen);
            }
            else
            {
                bsFiltroPre.Filter = string.Format("FFREST = 'P' AND FFRFOL = 0 AND POVNUM = '{0}' ", Proveedor, origen);
            }
        }

        private void cboEstatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            CargaFolios();
        }

        private void dgvProveedores_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            decimal fr = 0;

            fr = Convert.ToDecimal(this.dgvProveedores.Rows[e.RowIndex].Cells["FILLRATE"].Value);

            Filtrar(this.dgvProveedores.Rows[e.RowIndex].Cells[0].Value.ToString());

            if (fr >= 90)
            {
                this.btnMarcarTodas.Enabled = false;
                this.btnAgregar.Enabled = false;
                this.lblMensaje.Visible = true;
            }
            else if (fr >= 70 && fr < 90)
            {
                this.btnMarcarTodas.Enabled = true;
                this.btnAgregar.Enabled = true;
                this.lblMensaje.Visible = false;
            }
            else
            {
                MessageBox.Show("El proveedor esta en Black List");
                this.btnMarcarTodas.Enabled = false;
                this.btnAgregar.Enabled = false;
            }
        }


    }
}
