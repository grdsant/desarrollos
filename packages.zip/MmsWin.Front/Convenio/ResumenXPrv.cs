﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class ResumenXPrv : Form
    {
        int dgvOffset;
        int dgvOffset2;

        public ResumenXPrv()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }

        private void ResumenXPrv_Load(object sender, EventArgs e)
        {
            BindData();
        }

        private void BindData()
        {
            this.Cursor = Cursors.WaitCursor;

            dgvGridView.DataSource = null;
            System.Data.DataTable ResumenXPrv = null;
            try
            {
                string marca = MmsWin.Front.Utilerias.VarTem.tmpMarca;
                string comprador = MmsWin.Front.Utilerias.VarTem.tmpComprador; 
                string fechaRev = MmsWin.Front.Utilerias.VarTem.tmpFchRev;
                string usuario = MmsWin.Front.Utilerias.VarTem.tmpUser; 
                ResumenXPrv = MmsWin.Negocio.Convenio.ResumenXprv.GetInstance().ObtenResumenXprvDet1(marca, comprador, fechaRev, usuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (ResumenXPrv.Rows.Count > 0)
            {
                dgvGridView.DataSource = ResumenXPrv;
                int nr = dgvGridView.RowCount;
                this.Text = "Resumen por proveedor / " + " " + (nr).ToString() + " Registro(s)";
                SetFontAndColors();
                rowStyle();
                SetDoubleBuffered(dgvGridView);
            }
            this.Cursor = Cursors.Default;
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvGridView.Columns[3].Frozen = true;

            dgvGridView.Columns[0].HeaderText = "Proveedor";
            dgvGridView.Columns[1].HeaderText = "Nombre";
            dgvGridView.Columns[2].HeaderText = "Comprador";
            dgvGridView.Columns[3].HeaderText = "Piezas Recibidas";
            dgvGridView.Columns[4].HeaderText = "On Hand";
            dgvGridView.Columns[5].HeaderText = "Resurtido";
            dgvGridView.Columns[6].HeaderText = "Semana 1";
            dgvGridView.Columns[7].HeaderText = "Semana 2";
            dgvGridView.Columns[8].HeaderText = "Semana 3";
            dgvGridView.Columns[9].HeaderText = "Semana 4";
            dgvGridView.Columns[10].HeaderText = "Semana 5";
            dgvGridView.Columns[11].HeaderText = "Semana 6";
            dgvGridView.Columns[12].HeaderText = "Semana 7";
            dgvGridView.Columns[13].HeaderText = "Semana 8";
            dgvGridView.Columns[14].HeaderText = "Fecha Revision";
            dgvGridView.Columns[15].HeaderText = "Costo Total";
            dgvGridView.Columns[16].HeaderText = "Piezas Bonificar";
            dgvGridView.Columns[17].HeaderText = "Costo Bonificar";
            dgvGridView.Columns[18].HeaderText = "Marca";

            dgvGridView.Columns[0].Width = 50;
            dgvGridView.Columns[1].Width = 200;
            dgvGridView.Columns[2].Width = 100;
            dgvGridView.Columns[3].Width = 70;
            dgvGridView.Columns[4].Width = 70;
            dgvGridView.Columns[5].Width = 60;
            dgvGridView.Columns[6].Width = 50;
            dgvGridView.Columns[7].Width = 50;
            dgvGridView.Columns[8].Width = 50;
            dgvGridView.Columns[9].Width = 50;
            dgvGridView.Columns[10].Width = 50;
            dgvGridView.Columns[11].Width = 50;
            dgvGridView.Columns[12].Width = 50;
            dgvGridView.Columns[13].Width = 50;
            dgvGridView.Columns[14].Width = 80;
            dgvGridView.Columns[15].Width = 80;
            dgvGridView.Columns[16].Width = 80;
            dgvGridView.Columns[17].Width = 80;
            dgvGridView.Columns[18].Width = 70;

            dgvGridView.Columns[0].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[1].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[2].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[3].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[4].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[5].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[6].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[7].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[8].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[9].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[10].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[11].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[12].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[13].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[14].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[15].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[16].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[17].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[18].DefaultCellStyle.NullValue = true;

            dgvGridView.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[11].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[12].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[13].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[14].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[15].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[16].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[17].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[18].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns[3].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[4].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[5].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[6].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[7].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[8].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[9].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[10].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[11].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[12].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[13].DefaultCellStyle.Format = "###,###";

            dgvGridView.Columns[14].DefaultCellStyle.Format = "20##-##-##";

            dgvGridView.Columns[15].DefaultCellStyle.Format = "###,###.##";
            dgvGridView.Columns[16].DefaultCellStyle.Format = "###,###.##";
            dgvGridView.Columns[17].DefaultCellStyle.Format = "###,###.##";

            dgvGridView.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[1].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[2].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[3].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[4].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[5].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns[6].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[7].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[8].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[9].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[10].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[11].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[12].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[13].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[14].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns[15].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[16].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[17].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[18].HeaderCell.Style.BackColor = Color.LightSalmon;
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                int TotalPrv = Convert.ToInt32(rowp.Cells[0].Value);

                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }

                if (TotalPrv == 999999)
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.DarkGreen;
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.ForeColor = Color.White;
                    rowp.Cells[0].Style.ForeColor = Color.DarkGreen;
                    rowp.Cells[1].Style.ForeColor = Color.DarkGreen;
                    rowp.Cells[14].Style.ForeColor = Color.DarkGreen;
                   
                    // Totales por columna
                    // Suma Piezas Recibidas                              
                    int totPzRcb = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[3].Value));
                    rowp.Cells[3].Value = totPzRcb;
                    // Suma On Hand                                       
                    int totOnH = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[4].Value));
                    rowp.Cells[4].Value = totOnH;
                    // Suma Resurtidos                                    
                    int totRst = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[5].Value));
                    rowp.Cells[5].Value = totRst;
                    // Suma Resurtidos                                    
                    int totSm1 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[6].Value));
                    rowp.Cells[6].Value = totSm1;
                    // Suma Resurtidos                                    
                    int totSm2 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[7].Value));
                    rowp.Cells[7].Value = totSm2;
                    // Suma Resurtidos                                    
                    int totSm3 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[8].Value));
                    rowp.Cells[8].Value = totSm3;
                    // Suma Resurtidos                                    
                    int totSm4 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[9].Value));
                    rowp.Cells[9].Value = totSm4;
                    // Suma Resurtidos                                    
                    int totSm5 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[10].Value));
                    rowp.Cells[10].Value = totSm5;
                    // Suma Resurtidos                                    
                    int totSm6 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[11].Value));
                    rowp.Cells[11].Value = totSm6;
                    // Suma Resurtidos                                    
                    int totSm7 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[12].Value));
                    rowp.Cells[12].Value = totSm7;
                    // Suma Resurtidos                                    
                    int totSm8 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[13].Value));
                    rowp.Cells[13].Value = totSm8;
                    // Suma Costo total                                    
                    int totCst = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[15].Value));
                    rowp.Cells[15].Value = totCst;
                    // Suma Piezas a Bonificar                             
                    int totPzBo = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[16].Value));
                    rowp.Cells[16].Value = totPzBo;
                    // Suma Costo a Boificar                                  
                    int totCstBo = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[17].Value));
                    rowp.Cells[17].Value = totCstBo;
                }



            }
        }

        private void ResumenXPrv_Resize(object sender, EventArgs e)
        {
            dgvGridView.Width = this.Width - dgvOffset;
            dgvGridView.Height = this.Height - dgvOffset2;
        }

        private void dgvGridView_Sorted(object sender, EventArgs e)
        {
            SetFontAndColors();
            rowStyle();
        }
    }
}
