﻿namespace MmsWin.Front.Convenio
{
    partial class Reprogramacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Reprogramacion));
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.fotoTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tbPrv = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbFchRevision = new System.Windows.Forms.TextBox();
            this.tbFchReprog = new System.Windows.Forms.TextBox();
            this.cbCompradores = new System.Windows.Forms.ComboBox();
            this.gbMarca = new System.Windows.Forms.GroupBox();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.gbComprador = new System.Windows.Forms.GroupBox();
            this.pbExcel = new System.Windows.Forms.PictureBox();
            this.btRelleno = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pgbProg = new System.Windows.Forms.ProgressBar();
            this.imprimirTlSMI = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.cmMenu.SuspendLayout();
            this.gbMarca.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbExcel)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.ContextMenuStrip = this.cmMenu;
            this.dgvGridView.Location = new System.Drawing.Point(2, 74);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.ReadOnly = true;
            this.dgvGridView.Size = new System.Drawing.Size(1352, 397);
            this.dgvGridView.TabIndex = 0;
            this.dgvGridView.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvGridView_CellMouseDown);
            this.dgvGridView.SelectionChanged += new System.EventHandler(this.dgvGridView_SelectionChanged);
            this.dgvGridView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvGridView_KeyUp);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fotoTSMI,
            this.eliminarToolStripMenuItem,
            this.imprimirTlSMI});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(153, 92);
            // 
            // fotoTSMI
            // 
            this.fotoTSMI.Name = "fotoTSMI";
            this.fotoTSMI.Size = new System.Drawing.Size(152, 22);
            this.fotoTSMI.Text = "Foto";
            this.fotoTSMI.Click += new System.EventHandler(this.fotoTSMI_Click);
            // 
            // eliminarToolStripMenuItem
            // 
            this.eliminarToolStripMenuItem.Name = "eliminarToolStripMenuItem";
            this.eliminarToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.eliminarToolStripMenuItem.Text = "Eliminar";
            this.eliminarToolStripMenuItem.Click += new System.EventHandler(this.eliminarToolStripMenuItem_Click);
            // 
            // tbPrv
            // 
            this.tbPrv.Location = new System.Drawing.Point(44, 53);
            this.tbPrv.Name = "tbPrv";
            this.tbPrv.Size = new System.Drawing.Size(46, 20);
            this.tbPrv.TabIndex = 1;
            this.tbPrv.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbPrv_KeyPress);
            // 
            // tbNombre
            // 
            this.tbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNombre.Location = new System.Drawing.Point(90, 53);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(198, 20);
            this.tbNombre.TabIndex = 2;
            this.tbNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNombre_KeyPress);
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDescripcion.Location = new System.Drawing.Point(356, 53);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(197, 20);
            this.tbDescripcion.TabIndex = 4;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress);
            // 
            // tbEstilo
            // 
            this.tbEstilo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbEstilo.Location = new System.Drawing.Point(288, 53);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(68, 20);
            this.tbEstilo.TabIndex = 3;
            this.tbEstilo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbEstilo_KeyPress);
            // 
            // tbFchRevision
            // 
            this.tbFchRevision.Location = new System.Drawing.Point(553, 53);
            this.tbFchRevision.Name = "tbFchRevision";
            this.tbFchRevision.Size = new System.Drawing.Size(83, 20);
            this.tbFchRevision.TabIndex = 5;
            this.tbFchRevision.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFchRevision.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbFchRevision_KeyPress);
            // 
            // tbFchReprog
            // 
            this.tbFchReprog.Location = new System.Drawing.Point(636, 53);
            this.tbFchReprog.Name = "tbFchReprog";
            this.tbFchReprog.Size = new System.Drawing.Size(77, 20);
            this.tbFchReprog.TabIndex = 6;
            this.tbFchReprog.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFchReprog.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbFchReprog_KeyPress);
            // 
            // cbCompradores
            // 
            this.cbCompradores.FormattingEnabled = true;
            this.cbCompradores.Location = new System.Drawing.Point(196, 20);
            this.cbCompradores.Name = "cbCompradores";
            this.cbCompradores.Size = new System.Drawing.Size(168, 21);
            this.cbCompradores.TabIndex = 21;
            this.cbCompradores.SelectedValueChanged += new System.EventHandler(this.cbCompradores_SelectedValueChanged);
            // 
            // gbMarca
            // 
            this.gbMarca.Controls.Add(this.cbMarca);
            this.gbMarca.Location = new System.Drawing.Point(61, 7);
            this.gbMarca.Name = "gbMarca";
            this.gbMarca.Size = new System.Drawing.Size(113, 40);
            this.gbMarca.TabIndex = 20;
            this.gbMarca.TabStop = false;
            this.gbMarca.Text = "Marca";
            // 
            // cbMarca
            // 
            this.cbMarca.Location = new System.Drawing.Point(24, 13);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(74, 21);
            this.cbMarca.TabIndex = 2;
            this.cbMarca.SelectedValueChanged += new System.EventHandler(this.cbMarca_SelectedValueChanged);
            // 
            // gbComprador
            // 
            this.gbComprador.Location = new System.Drawing.Point(178, 7);
            this.gbComprador.Name = "gbComprador";
            this.gbComprador.Size = new System.Drawing.Size(203, 40);
            this.gbComprador.TabIndex = 22;
            this.gbComprador.TabStop = false;
            this.gbComprador.Text = "Comprador";
            // 
            // pbExcel
            // 
            this.pbExcel.Image = ((System.Drawing.Image)(resources.GetObject("pbExcel.Image")));
            this.pbExcel.Location = new System.Drawing.Point(-9, 0);
            this.pbExcel.Name = "pbExcel";
            this.pbExcel.Size = new System.Drawing.Size(65, 47);
            this.pbExcel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbExcel.TabIndex = 18;
            this.pbExcel.TabStop = false;
            this.pbExcel.Visible = false;
            this.pbExcel.Click += new System.EventHandler(this.pbExcel_Click);
            // 
            // btRelleno
            // 
            this.btRelleno.Location = new System.Drawing.Point(-1, 52);
            this.btRelleno.Name = "btRelleno";
            this.btRelleno.Size = new System.Drawing.Size(47, 22);
            this.btRelleno.TabIndex = 23;
            this.btRelleno.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(712, 52);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(641, 22);
            this.button1.TabIndex = 35;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // pgbProg
            // 
            this.pgbProg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pgbProg.Location = new System.Drawing.Point(2, 473);
            this.pgbProg.Name = "pgbProg";
            this.pgbProg.Size = new System.Drawing.Size(1349, 10);
            this.pgbProg.TabIndex = 36;
            this.pgbProg.Visible = false;
            // 
            // imprimirTlSMI
            // 
            this.imprimirTlSMI.Name = "imprimirTlSMI";
            this.imprimirTlSMI.Size = new System.Drawing.Size(152, 22);
            this.imprimirTlSMI.Text = "Imprimir";
            this.imprimirTlSMI.Click += new System.EventHandler(this.imprimirTlSMI_Click);
            // 
            // Reprogramacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1354, 486);
            this.Controls.Add(this.pgbProg);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btRelleno);
            this.Controls.Add(this.cbCompradores);
            this.Controls.Add(this.gbMarca);
            this.Controls.Add(this.gbComprador);
            this.Controls.Add(this.pbExcel);
            this.Controls.Add(this.tbFchReprog);
            this.Controls.Add(this.tbFchRevision);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.tbEstilo);
            this.Controls.Add(this.tbNombre);
            this.Controls.Add(this.tbPrv);
            this.Controls.Add(this.dgvGridView);
            this.Name = "Reprogramacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reprogramacion";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Reprogramacion_FormClosing);
            this.Load += new System.EventHandler(this.Reprogramacion_Load);
            this.Resize += new System.EventHandler(this.Reprogramacion_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.cmMenu.ResumeLayout(false);
            this.gbMarca.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbExcel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.TextBox tbPrv;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbFchRevision;
        private System.Windows.Forms.TextBox tbFchReprog;
        private System.Windows.Forms.ComboBox cbCompradores;
        private System.Windows.Forms.GroupBox gbMarca;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.GroupBox gbComprador;
        private System.Windows.Forms.PictureBox pbExcel;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem fotoTSMI;
        private System.Windows.Forms.Button btRelleno;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ProgressBar pgbProg;
        private System.Windows.Forms.ToolStripMenuItem eliminarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem imprimirTlSMI;
    }
}