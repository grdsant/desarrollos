﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class TblRentabilidad : Form
    {

        string ParUser;
        int dgvOffset;
        int dgvOffset2;

        public TblRentabilidad()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }

        private void TblRentabilidad_Resize(object sender, EventArgs e)
        {
            dgvGridView.Width = this.Width - dgvOffset;
            dgvGridView.Height = this.Height - dgvOffset2;
        }

        private void TblRentabilidad_Load(object sender, EventArgs e)
        {
            tbTabla.Text = MmsWin.Front.Utilerias.VarTem.tmpTblTbl;
            tbMarca.Text = MmsWin.Front.Utilerias.VarTem.tmpTblMar;
            BindTblRentabilidad();

            // Seguridad...
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("Convenio", "TblRentabilidadDetalle", ParUser);
        }

        // Seguridad                                                                                       
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                                
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvGridView.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvGridView.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenu.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenu.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        protected void BindTblRentabilidad()
        {
            this.Cursor = Cursors.WaitCursor;

            dgvGridView.DataSource = null;
            System.Data.DataTable TblRentabilidad = null;
            try
            {
                string tbltabla = tbTabla.Text;
                string tblmarca = tbMarca.Text;
                TblRentabilidad = MmsWin.Negocio.Convenio.TblRentabilidad.GetInstance().ObtenTblRentabilidadDet1(tbltabla, tblmarca);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (TblRentabilidad.Rows.Count > 0)
            {
                dgvGridView.DataSource = TblRentabilidad;
                int nr = dgvGridView.RowCount;
                this.Text = "Tablas de Rentabilidad / " + " " + (nr).ToString() + " Registro(s)";
                SetFontAndColors();
                rowStyle();
                SetDoubleBuffered(dgvGridView);
                // Seguridad...
                ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                Seguridad("Convenio", "TblRentabilidadDetalle", ParUser);
            }
            this.Cursor = Cursors.Default;
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvGridView.Columns[3].Frozen = true;

            dgvGridView.Columns[0].HeaderText = "Tabla";
            dgvGridView.Columns[1].HeaderText = "Marca";
            dgvGridView.Columns[2].HeaderText = "Secuencia";
            dgvGridView.Columns[3].HeaderText = "Del";
            dgvGridView.Columns[4].HeaderText = "Al";
            dgvGridView.Columns[5].HeaderText = " % ";
            dgvGridView.Columns[6].HeaderText = "Del Real";
            dgvGridView.Columns[7].HeaderText = "Al Real";
            dgvGridView.Columns[8].HeaderText = "% Real";
            dgvGridView.Columns[9].HeaderText = "Usuario";
            dgvGridView.Columns[10].HeaderText = "Fecha";
            dgvGridView.Columns[11].HeaderText = "Hora";
            dgvGridView.Columns[12].HeaderText = "Estatus";

            dgvGridView.Columns[0].Width = 80;
            dgvGridView.Columns[1].Width = 80;
            dgvGridView.Columns[2].Width = 80;
            dgvGridView.Columns[3].Width = 80;
            dgvGridView.Columns[4].Width = 80;
            dgvGridView.Columns[5].Width = 80;
            dgvGridView.Columns[6].Width = 80;
            dgvGridView.Columns[7].Width = 80;
            dgvGridView.Columns[8].Width = 80;
            dgvGridView.Columns[9].Width = 80;
            dgvGridView.Columns[10].Width = 80;
            dgvGridView.Columns[11].Width = 80;
            dgvGridView.Columns[12].Width = 80;

            dgvGridView.Columns[0].DefaultCellStyle.Format = "###";
            dgvGridView.Columns[1].DefaultCellStyle.Format = "###";
            dgvGridView.Columns[2].DefaultCellStyle.Format = "###";

            dgvGridView.Columns[3].DefaultCellStyle.Format = "{0:n2}";
            dgvGridView.Columns[4].DefaultCellStyle.Format = "{0:n2}";

            dgvGridView.Columns[6].DefaultCellStyle.Format = "###.###";
            dgvGridView.Columns[7].DefaultCellStyle.Format = "###.###";
            dgvGridView.Columns[8].DefaultCellStyle.Format = "###.###";

            dgvGridView.Columns[10].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns[11].DefaultCellStyle.Format = "##:##:##";

            dgvGridView.Columns[0].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[1].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[2].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[3].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[4].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[5].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[6].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[7].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[8].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[9].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[10].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[11].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[12].DefaultCellStyle.NullValue = true;

            dgvGridView.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[11].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[12].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[1].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[2].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[3].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[4].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[5].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns[6].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[7].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[8].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[9].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns[10].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[11].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[12].HeaderCell.Style.BackColor = Color.LightGreen;


            foreach (DataGridViewRow row in dgvGridView.Rows)
            {
                // Pagar
                if (Convert.ToString(row.Cells[5].Value) == "P a g a r") { row.Cells[5].Style.BackColor = Color.LightGreen; }
                // 15%
                if (Convert.ToString(row.Cells[5].Value) == "15%") { row.Cells[5].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(row.Cells[5].Value) == "20%") { row.Cells[5].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(row.Cells[5].Value) == "25%") { row.Cells[5].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(row.Cells[5].Value) == "30%") { row.Cells[5].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(row.Cells[5].Value) == "35%") { row.Cells[5].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(row.Cells[5].Value) == "40%") { row.Cells[5].Style.BackColor = Color.LightSalmon; }
                // Dev ó 40%
                if (Convert.ToString(row.Cells[5].Value) == "40%") { row.Cells[5].Style.BackColor = Color.Red; row.Cells[5].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(row.Cells[5].Value) == "50%") { row.Cells[5].Style.BackColor = Color.Red; row.Cells[5].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(row.Cells[5].Value) == "Devolucion") { row.Cells[5].Style.BackColor = Color.Red; row.Cells[5].Style.ForeColor = Color.White; }
            }

        }

        private void rowStyle()
        {

            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                try
                {
                    Decimal val03 = Convert.ToDecimal(rowp.Cells[3].Value);
                    Decimal val04 = Convert.ToDecimal(rowp.Cells[4].Value);
                    val03 = val03 * 100;
                    val04 = val04 * 100;
                    rowp.Cells[3].Value = String.Format("{00:n2}", val03);
                    rowp.Cells[4].Value = String.Format("{0:n2}", val04);
                }
                catch { }

                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }

        // Ejecuta Carga de Seguridad                                                                  
        //
        private void TblRentabilidad_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("Convenio", "TblRentabilidadDetalle", ParUser);
            }
        }
        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            //
            string NomCol;
            Int32 NoCol = dgvGridView.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvGridView.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      
            //
            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void actualizarTSMI_Click(object sender, EventArgs e)
        {
            ActualizaTblRentabilidad();
        }

        private void ActualizaTblRentabilidad()
        {
            System.Data.DataTable dtTblRentabilidad = new System.Data.DataTable("TblRentabilidad");
            dtTblRentabilidad.Columns.Add("Tabla", typeof(String));
            dtTblRentabilidad.Columns.Add("Marca", typeof(String));
            dtTblRentabilidad.Columns.Add("Secuencia", typeof(String));
            dtTblRentabilidad.Columns.Add("Del", typeof(String));
            dtTblRentabilidad.Columns.Add("Al", typeof(String));
            dtTblRentabilidad.Columns.Add("Por", typeof(String));
            dtTblRentabilidad.Columns.Add("Delr", typeof(String));
            dtTblRentabilidad.Columns.Add("Alr", typeof(String));
            dtTblRentabilidad.Columns.Add("Porr", typeof(String));
            dtTblRentabilidad.Columns.Add("Usuario", typeof(String));
            dtTblRentabilidad.Columns.Add("Fecha", typeof(String));
            dtTblRentabilidad.Columns.Add("Hora", typeof(String));
            dtTblRentabilidad.Columns.Add("Estatus", typeof(String));

            DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                DataRow workRow = dtTblRentabilidad.NewRow();
                workRow["Tabla"] = item.Cells[0].Value.ToString();
                workRow["Marca"] = item.Cells[1].Value.ToString();
                workRow["Secuencia"] = item.Cells[2].Value.ToString();
                workRow["Del"] = item.Cells[3].Value.ToString();
                workRow["Al"] = item.Cells[4].Value.ToString();
                workRow["Por"] = item.Cells[5].Value.ToString();
                workRow["Delr"] = item.Cells[6].Value.ToString();
                workRow["Alr"] = item.Cells[7].Value.ToString();
                workRow["Porr"] = item.Cells[8].Value.ToString();
                workRow["Usuario"] = item.Cells[9].Value.ToString();
                workRow["Fecha"] = item.Cells[10].Value.ToString();
                workRow["Hora"] = item.Cells[11].Value.ToString();
                workRow["Estatus"] = item.Cells[12].Value.ToString();

                dtTblRentabilidad.Rows.Add(workRow);
            }
            MmsWin.Negocio.Convenio.TblRentabilidad.GetInstance().UpdateTblRentabilidad(dtTblRentabilidad);
            BindTblRentabilidad();
            MessageBox.Show("Actualizacion completa...");
            BindTblRentabilidad();
        }

        private void borrarTSMI_Click(object sender, EventArgs e)
        {
            string tabla;
            string marca;
            string secuencia;
            string message = "Corfirmar la Eliminación del Registro";
            string caption = "Advertencia...";
            DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                tabla = item.Cells[0].Value.ToString();
                marca = item.Cells[1].Value.ToString();
                secuencia = item.Cells[2].Value.ToString();

                message = "Confirma la Eliminacion del Registro:" + tabla + " con la marca : " + marca + " y la secuemcia : " + secuencia;
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;
                result = MessageBox.Show(message, caption, buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    MmsWin.Negocio.Convenio.TblRentabilidad.GetInstance().EliminaTblRentabilidad(tabla, marca, secuencia);
                    MessageBox.Show("Regitro Eliminado...");
                }
            }

            BindTblRentabilidad();
        }

        private void tbMarca_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindTblRentabilidad();
            }
        }

        private void tbTabla_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindTblRentabilidad();
            }
        }

        private void dgvGridView_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                var hti = dgvGridView.HitTest(e.X, e.Y);
                int Row = e.RowIndex;
                int Col = e.ColumnIndex;

                cmMenu.Visible = true;
            }
        }
    }
}
