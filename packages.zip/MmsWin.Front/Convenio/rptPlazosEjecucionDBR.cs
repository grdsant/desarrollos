﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class rptPlazosEjecucionDBR : Form
    {
        public string idComprador { get; set; }
        public string idMarca { get; set; }
        public rptPlazosEjecucionDBR()
        {
            InitializeComponent();
        }

        private void rptPlazosEjecucionDBR_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dsTablaAccion10.SAT177DBR' Puede moverla o quitarla según sea necesario.
            this.sAT177DBRTableAdapter.Fill(this.dsTablaAccion10.SAT177DBR, idComprador, idMarca);

            this.reportViewer1.RefreshReport();
        }
    }
}
