﻿namespace MmsWin.Front.Convenio
{
    partial class AutorizaDevolucion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AutorizaDevolucion));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.gpbEstilosDisponibles = new System.Windows.Forms.GroupBox();
            this.tspGeneracionFormatos = new System.Windows.Forms.ToolStrip();
            this.lblFolio = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.lblBuscarPre = new System.Windows.Forms.ToolStripLabel();
            this.txtBuscarPre = new System.Windows.Forms.ToolStripTextBox();
            this.btnBuscarPre = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.btnMarcarTodas = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.btnAgregar = new System.Windows.Forms.ToolStripButton();
            this.dgvEstilosPreautorizados = new System.Windows.Forms.DataGridView();
            this.gpbEstilosSeleccionados = new System.Windows.Forms.GroupBox();
            this.dgvEstilosSeleccionados = new System.Windows.Forms.DataGridView();
            this.tspOrdenesSeleccionadas = new System.Windows.Forms.ToolStrip();
            this.btnGuardar = new System.Windows.Forms.ToolStripButton();
            this.tsbEliminarTodos = new System.Windows.Forms.ToolStripButton();
            this.ofdAdjuntar = new System.Windows.Forms.OpenFileDialog();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.tspConsultaAutorizadas = new System.Windows.Forms.ToolStrip();
            this.lblBuscar = new System.Windows.Forms.ToolStripLabel();
            this.txtBuscar = new System.Windows.Forms.ToolStripTextBox();
            this.btnBuscar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.lblFiltrarPor = new System.Windows.Forms.ToolStripLabel();
            this.cboFiltrar = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.btnImprimir = new System.Windows.Forms.ToolStripButton();
            this.lsvFolios = new System.Windows.Forms.ListView();
            this.imlFolios = new System.Windows.Forms.ImageList(this.components);
            this.tspAutorizadas = new System.Windows.Forms.ToolStrip();
            this.btnMarcarDetalle = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.btnLiberar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.btnAutorizar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.dgvDetalleFolios = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.gpbEstilosDisponibles.SuspendLayout();
            this.tspGeneracionFormatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstilosPreautorizados)).BeginInit();
            this.gpbEstilosSeleccionados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstilosSeleccionados)).BeginInit();
            this.tspOrdenesSeleccionadas.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.tspConsultaAutorizadas.SuspendLayout();
            this.tspAutorizadas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalleFolios)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.gpbEstilosDisponibles);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.gpbEstilosSeleccionados);
            this.splitContainer1.Size = new System.Drawing.Size(1062, 402);
            this.splitContainer1.SplitterDistance = 645;
            this.splitContainer1.TabIndex = 1;
            // 
            // gpbEstilosDisponibles
            // 
            this.gpbEstilosDisponibles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gpbEstilosDisponibles.Controls.Add(this.tspGeneracionFormatos);
            this.gpbEstilosDisponibles.Controls.Add(this.dgvEstilosPreautorizados);
            this.gpbEstilosDisponibles.Location = new System.Drawing.Point(4, 3);
            this.gpbEstilosDisponibles.Name = "gpbEstilosDisponibles";
            this.gpbEstilosDisponibles.Size = new System.Drawing.Size(638, 371);
            this.gpbEstilosDisponibles.TabIndex = 1;
            this.gpbEstilosDisponibles.TabStop = false;
            this.gpbEstilosDisponibles.Text = "Estilos disponibles";
            // 
            // tspGeneracionFormatos
            // 
            this.tspGeneracionFormatos.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblFolio,
            this.toolStripSeparator2,
            this.lblBuscarPre,
            this.txtBuscarPre,
            this.btnBuscarPre,
            this.toolStripSeparator1,
            this.btnMarcarTodas,
            this.toolStripSeparator7,
            this.btnAgregar});
            this.tspGeneracionFormatos.Location = new System.Drawing.Point(3, 16);
            this.tspGeneracionFormatos.Name = "tspGeneracionFormatos";
            this.tspGeneracionFormatos.Size = new System.Drawing.Size(632, 25);
            this.tspGeneracionFormatos.TabIndex = 2;
            // 
            // lblFolio
            // 
            this.lblFolio.AutoSize = false;
            this.lblFolio.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblFolio.ForeColor = System.Drawing.Color.Maroon;
            this.lblFolio.Name = "lblFolio";
            this.lblFolio.Size = new System.Drawing.Size(80, 22);
            this.lblFolio.Text = "Folio: 1698";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // lblBuscarPre
            // 
            this.lblBuscarPre.Name = "lblBuscarPre";
            this.lblBuscarPre.Size = new System.Drawing.Size(45, 22);
            this.lblBuscarPre.Text = "Buscar:";
            // 
            // txtBuscarPre
            // 
            this.txtBuscarPre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBuscarPre.Name = "txtBuscarPre";
            this.txtBuscarPre.Size = new System.Drawing.Size(100, 25);
            this.txtBuscarPre.TextChanged += new System.EventHandler(this.txtBuscarPre_TextChanged);
            // 
            // btnBuscarPre
            // 
            this.btnBuscarPre.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnBuscarPre.Image = global::MmsWin.Front.Properties.Resources.Find_VS;
            this.btnBuscarPre.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnBuscarPre.Name = "btnBuscarPre";
            this.btnBuscarPre.Size = new System.Drawing.Size(23, 22);
            this.btnBuscarPre.Text = "toolStripButton1";
            this.btnBuscarPre.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // btnMarcarTodas
            // 
            this.btnMarcarTodas.AutoSize = false;
            this.btnMarcarTodas.Image = global::MmsWin.Front.Properties.Resources.CheckBoxHS;
            this.btnMarcarTodas.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnMarcarTodas.Name = "btnMarcarTodas";
            this.btnMarcarTodas.Size = new System.Drawing.Size(100, 22);
            this.btnMarcarTodas.Text = "Marcar todos";
            this.btnMarcarTodas.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 25);
            // 
            // btnAgregar
            // 
            this.btnAgregar.Image = global::MmsWin.Front.Properties.Resources._112_RightArrowShort_Blue_16x16_72;
            this.btnAgregar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(124, 22);
            this.btnAgregar.Text = "Agregar a formato";
            this.btnAgregar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAgregar.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // dgvEstilosPreautorizados
            // 
            this.dgvEstilosPreautorizados.AllowUserToAddRows = false;
            this.dgvEstilosPreautorizados.AllowUserToDeleteRows = false;
            this.dgvEstilosPreautorizados.AllowUserToOrderColumns = true;
            this.dgvEstilosPreautorizados.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvEstilosPreautorizados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEstilosPreautorizados.Location = new System.Drawing.Point(3, 44);
            this.dgvEstilosPreautorizados.Name = "dgvEstilosPreautorizados";
            this.dgvEstilosPreautorizados.Size = new System.Drawing.Size(632, 324);
            this.dgvEstilosPreautorizados.TabIndex = 1;
            // 
            // gpbEstilosSeleccionados
            // 
            this.gpbEstilosSeleccionados.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gpbEstilosSeleccionados.Controls.Add(this.dgvEstilosSeleccionados);
            this.gpbEstilosSeleccionados.Controls.Add(this.tspOrdenesSeleccionadas);
            this.gpbEstilosSeleccionados.Location = new System.Drawing.Point(3, 3);
            this.gpbEstilosSeleccionados.Name = "gpbEstilosSeleccionados";
            this.gpbEstilosSeleccionados.Size = new System.Drawing.Size(405, 368);
            this.gpbEstilosSeleccionados.TabIndex = 1;
            this.gpbEstilosSeleccionados.TabStop = false;
            this.gpbEstilosSeleccionados.Text = "Estilos seleccionados para formato";
            // 
            // dgvEstilosSeleccionados
            // 
            this.dgvEstilosSeleccionados.AllowUserToAddRows = false;
            this.dgvEstilosSeleccionados.AllowUserToDeleteRows = false;
            this.dgvEstilosSeleccionados.AllowUserToOrderColumns = true;
            this.dgvEstilosSeleccionados.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvEstilosSeleccionados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEstilosSeleccionados.Location = new System.Drawing.Point(0, 44);
            this.dgvEstilosSeleccionados.MultiSelect = false;
            this.dgvEstilosSeleccionados.Name = "dgvEstilosSeleccionados";
            this.dgvEstilosSeleccionados.ReadOnly = true;
            this.dgvEstilosSeleccionados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEstilosSeleccionados.Size = new System.Drawing.Size(402, 324);
            this.dgvEstilosSeleccionados.TabIndex = 3;
            // 
            // tspOrdenesSeleccionadas
            // 
            this.tspOrdenesSeleccionadas.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnGuardar,
            this.tsbEliminarTodos});
            this.tspOrdenesSeleccionadas.Location = new System.Drawing.Point(3, 16);
            this.tspOrdenesSeleccionadas.Name = "tspOrdenesSeleccionadas";
            this.tspOrdenesSeleccionadas.Size = new System.Drawing.Size(399, 25);
            this.tspOrdenesSeleccionadas.TabIndex = 2;
            this.tspOrdenesSeleccionadas.Text = "toolStrip4";
            // 
            // btnGuardar
            // 
            this.btnGuardar.Image = global::MmsWin.Front.Properties.Resources._077_AddFile_16x16_72;
            this.btnGuardar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(68, 22);
            this.btnGuardar.Text = "Generar";
            this.btnGuardar.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // tsbEliminarTodos
            // 
            this.tsbEliminarTodos.Image = global::MmsWin.Front.Properties.Resources._109_AllAnnotations_Error_16x16_72;
            this.tsbEliminarTodos.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEliminarTodos.Name = "tsbEliminarTodos";
            this.tsbEliminarTodos.Size = new System.Drawing.Size(112, 22);
            this.tsbEliminarTodos.Text = "Quitar selección";
            this.tsbEliminarTodos.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // ofdAdjuntar
            // 
            this.ofdAdjuntar.FileName = "*.*";
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1076, 434);
            this.tabControl1.TabIndex = 3;
            this.tabControl1.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControl1_Selecting);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.splitContainer1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1068, 408);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Generación formatos";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.splitContainer3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1068, 408);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Autorizaciones";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // splitContainer3
            // 
            this.splitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer3.CausesValidation = false;
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.tspConsultaAutorizadas);
            this.splitContainer3.Panel1.Controls.Add(this.lsvFolios);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.tspAutorizadas);
            this.splitContainer3.Panel2.Controls.Add(this.dgvDetalleFolios);
            this.splitContainer3.Size = new System.Drawing.Size(1068, 408);
            this.splitContainer3.SplitterDistance = 149;
            this.splitContainer3.TabIndex = 3;
            // 
            // tspConsultaAutorizadas
            // 
            this.tspConsultaAutorizadas.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblBuscar,
            this.txtBuscar,
            this.btnBuscar,
            this.toolStripSeparator4,
            this.lblFiltrarPor,
            this.cboFiltrar,
            this.toolStripSeparator5,
            this.btnImprimir});
            this.tspConsultaAutorizadas.Location = new System.Drawing.Point(0, 0);
            this.tspConsultaAutorizadas.Name = "tspConsultaAutorizadas";
            this.tspConsultaAutorizadas.Size = new System.Drawing.Size(1064, 25);
            this.tspConsultaAutorizadas.TabIndex = 1;
            this.tspConsultaAutorizadas.Text = "toolStrip2";
            this.tspConsultaAutorizadas.TextChanged += new System.EventHandler(this.txtBuscar_TextChanged);
            // 
            // lblBuscar
            // 
            this.lblBuscar.Name = "lblBuscar";
            this.lblBuscar.Size = new System.Drawing.Size(45, 22);
            this.lblBuscar.Text = "Buscar:";
            // 
            // txtBuscar
            // 
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.Size = new System.Drawing.Size(100, 25);
            this.txtBuscar.TextChanged += new System.EventHandler(this.txtBuscar_TextChanged);
            // 
            // btnBuscar
            // 
            this.btnBuscar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnBuscar.Image = global::MmsWin.Front.Properties.Resources.Find_VS;
            this.btnBuscar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(23, 22);
            this.btnBuscar.Text = "toolStripButton1";
            this.btnBuscar.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // lblFiltrarPor
            // 
            this.lblFiltrarPor.Name = "lblFiltrarPor";
            this.lblFiltrarPor.Size = new System.Drawing.Size(64, 22);
            this.lblFiltrarPor.Text = "Filtrar por: ";
            // 
            // cboFiltrar
            // 
            this.cboFiltrar.BackColor = System.Drawing.Color.Gainsboro;
            this.cboFiltrar.Items.AddRange(new object[] {
            "Pendiente",
            "Autorizado"});
            this.cboFiltrar.Name = "cboFiltrar";
            this.cboFiltrar.Size = new System.Drawing.Size(121, 25);
            this.cboFiltrar.SelectedIndexChanged += new System.EventHandler(this.cboFiltrar_SelectedIndexChanged);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // btnImprimir
            // 
            this.btnImprimir.Image = global::MmsWin.Front.Properties.Resources.PrintHS;
            this.btnImprimir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnImprimir.Name = "btnImprimir";
            this.btnImprimir.Size = new System.Drawing.Size(73, 22);
            this.btnImprimir.Text = "Imprimir";
            this.btnImprimir.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // lsvFolios
            // 
            this.lsvFolios.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lsvFolios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lsvFolios.LargeImageList = this.imlFolios;
            this.lsvFolios.Location = new System.Drawing.Point(3, 28);
            this.lsvFolios.Name = "lsvFolios";
            this.lsvFolios.Size = new System.Drawing.Size(1058, 114);
            this.lsvFolios.SmallImageList = this.imlFolios;
            this.lsvFolios.TabIndex = 0;
            this.lsvFolios.UseCompatibleStateImageBehavior = false;
            this.lsvFolios.SelectedIndexChanged += new System.EventHandler(this.lsvFolios_SelectedIndexChanged);
            this.lsvFolios.Click += new System.EventHandler(this.lsvFolios_Click);
            // 
            // imlFolios
            // 
            this.imlFolios.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imlFolios.ImageStream")));
            this.imlFolios.TransparentColor = System.Drawing.Color.Transparent;
            this.imlFolios.Images.SetKeyName(0, "folder_process.png");
            this.imlFolios.Images.SetKeyName(1, "Folder_32x32.png");
            this.imlFolios.Images.SetKeyName(2, "NewDocuments_32x32.png");
            this.imlFolios.Images.SetKeyName(3, "folder_autorizado.png");
            this.imlFolios.Images.SetKeyName(4, "IgnoreIssue_32x32.png");
            this.imlFolios.Images.SetKeyName(5, "112_Tick_Green_32x32_72.png");
            this.imlFolios.Images.SetKeyName(6, "folder_cancel.png");
            // 
            // tspAutorizadas
            // 
            this.tspAutorizadas.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnMarcarDetalle,
            this.toolStripSeparator10,
            this.btnLiberar,
            this.toolStripSeparator8,
            this.btnAutorizar,
            this.toolStripSeparator3});
            this.tspAutorizadas.Location = new System.Drawing.Point(0, 0);
            this.tspAutorizadas.Name = "tspAutorizadas";
            this.tspAutorizadas.Size = new System.Drawing.Size(1064, 25);
            this.tspAutorizadas.TabIndex = 1;
            this.tspAutorizadas.Text = "Autorizar ";
            // 
            // btnMarcarDetalle
            // 
            this.btnMarcarDetalle.Image = global::MmsWin.Front.Properties.Resources.CheckBoxHS;
            this.btnMarcarDetalle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnMarcarDetalle.Name = "btnMarcarDetalle";
            this.btnMarcarDetalle.Size = new System.Drawing.Size(64, 22);
            this.btnMarcarDetalle.Text = "Marcar";
            this.btnMarcarDetalle.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 25);
            // 
            // btnLiberar
            // 
            this.btnLiberar.Image = global::MmsWin.Front.Properties.Resources.XSDSchema_AllIcon;
            this.btnLiberar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnLiberar.Name = "btnLiberar";
            this.btnLiberar.Size = new System.Drawing.Size(107, 22);
            this.btnLiberar.Text = "\"Des-autorizar\"";
            this.btnLiberar.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 25);
            // 
            // btnAutorizar
            // 
            this.btnAutorizar.Image = global::MmsWin.Front.Properties.Resources.PrimaryKeyHS;
            this.btnAutorizar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAutorizar.Name = "btnAutorizar";
            this.btnAutorizar.Size = new System.Drawing.Size(75, 22);
            this.btnAutorizar.Text = "Autorizar";
            this.btnAutorizar.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // dgvDetalleFolios
            // 
            this.dgvDetalleFolios.AllowUserToAddRows = false;
            this.dgvDetalleFolios.AllowUserToDeleteRows = false;
            this.dgvDetalleFolios.AllowUserToOrderColumns = true;
            this.dgvDetalleFolios.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDetalleFolios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetalleFolios.Location = new System.Drawing.Point(0, 27);
            this.dgvDetalleFolios.Name = "dgvDetalleFolios";
            this.dgvDetalleFolios.Size = new System.Drawing.Size(1064, 226);
            this.dgvDetalleFolios.TabIndex = 0;
            // 
            // AutorizaDevolucion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1077, 440);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AutorizaDevolucion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Autoriza Devolución";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AutorizaDevolucion_FormClosing);
            this.Load += new System.EventHandler(this.AutorizaDevolucion_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.gpbEstilosDisponibles.ResumeLayout(false);
            this.gpbEstilosDisponibles.PerformLayout();
            this.tspGeneracionFormatos.ResumeLayout(false);
            this.tspGeneracionFormatos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstilosPreautorizados)).EndInit();
            this.gpbEstilosSeleccionados.ResumeLayout(false);
            this.gpbEstilosSeleccionados.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstilosSeleccionados)).EndInit();
            this.tspOrdenesSeleccionadas.ResumeLayout(false);
            this.tspOrdenesSeleccionadas.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.tspConsultaAutorizadas.ResumeLayout(false);
            this.tspConsultaAutorizadas.PerformLayout();
            this.tspAutorizadas.ResumeLayout(false);
            this.tspAutorizadas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalleFolios)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox gpbEstilosDisponibles;
        private System.Windows.Forms.ToolStrip tspGeneracionFormatos;
        private System.Windows.Forms.ToolStripLabel lblFolio;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripLabel lblBuscarPre;
        private System.Windows.Forms.ToolStripTextBox txtBuscarPre;
        private System.Windows.Forms.ToolStripButton btnBuscarPre;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripButton btnMarcarTodas;
        private System.Windows.Forms.ToolStripButton btnAgregar;
        private System.Windows.Forms.DataGridView dgvEstilosPreautorizados;
        private System.Windows.Forms.GroupBox gpbEstilosSeleccionados;
        private System.Windows.Forms.DataGridView dgvEstilosSeleccionados;
        private System.Windows.Forms.ToolStrip tspOrdenesSeleccionadas;
        private System.Windows.Forms.ToolStripButton btnGuardar;
        private System.Windows.Forms.ToolStripButton tsbEliminarTodos;
        private System.Windows.Forms.OpenFileDialog ofdAdjuntar;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.ToolStrip tspConsultaAutorizadas;
        private System.Windows.Forms.ToolStripLabel lblBuscar;
        private System.Windows.Forms.ToolStripTextBox txtBuscar;
        private System.Windows.Forms.ToolStripButton btnBuscar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripLabel lblFiltrarPor;
        private System.Windows.Forms.ToolStripComboBox cboFiltrar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton btnImprimir;
        private System.Windows.Forms.ListView lsvFolios;
        private System.Windows.Forms.ImageList imlFolios;
        private System.Windows.Forms.ToolStrip tspAutorizadas;
        private System.Windows.Forms.ToolStripButton btnMarcarDetalle;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripButton btnLiberar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripButton btnAutorizar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.DataGridView dgvDetalleFolios;
    }
}