﻿namespace MmsWin.Front.Convenio
{
    partial class rptPlazosEjecucionDBR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.sAT177DBRBindingSource = new System.Windows.Forms.BindingSource(this.components);
            //this.dsTablaAccion10 = new MmsWin.Front.Data_Set.dsTablaAccion10();
            //this.sAT177DBRTableAdapter = new MmsWin.Front.Data_Set.dsTablaAccion10TableAdapters.SAT177DBRTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.sAT177DBRBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsTablaAccion10)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "cdsTablaAccion10";
            reportDataSource1.Value = this.sAT177DBRBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "MmsWin.Front.Convenio.rptPlazosEjecucionDBR.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(896, 458);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.PageWidth;
            // 
            // sAT177DBRBindingSource
            // 
            this.sAT177DBRBindingSource.DataMember = "SAT177DBR";
            this.sAT177DBRBindingSource.DataSource = this.dsTablaAccion10;
            // 
            // dsTablaAccion10
            // 
            this.dsTablaAccion10.DataSetName = "dsTablaAccion10";
            this.dsTablaAccion10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sAT177DBRTableAdapter
            // 
            this.sAT177DBRTableAdapter.ClearBeforeFill = true;
            // 
            // rptPlazosEjecucionDBR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(896, 458);
            this.Controls.Add(this.reportViewer1);
            this.Name = "rptPlazosEjecucionDBR";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reporte de Plazos";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.rptPlazosEjecucionDBR_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sAT177DBRBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsTablaAccion10)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource sAT177DBRBindingSource;
        private MmsWin.Front.Resources.Data_Set.dsTablaAccion10 dsTablaAccion10;
        private MmsWin.Front.Resources.Data_Set.dsTablaAccion10TableAdapters.SAT177DBRTableAdapter sAT177DBRTableAdapter;
    }
}