﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MmsWin.Negocio;
using MmsWin.Negocio.Convenio;

namespace MmsWin.Front.Convenio
{
    public partial class BonificacionAnticipada : Form
    {
        //Se les asigna su valor desde la pantalla de convenio
        //dependiendo de la selección de los combos de marca y comprador
        public Comun.Engine.Marca Marca { get; set; }
        public int Comprador { get; set; }
        //-------------------------------------------------------

        //Se usan para el marcado y desmarcado de los checkbox en las grid
        bool CheckMarcados = false;
        bool CheckMarcadosDetalle = false;
        //---------------------------------------------------------

        /// <summary>
        /// Número de folio de la solicitud
        /// </summary>
        string Folio = "";

        /// <summary>
        ///Matriz para separar el folio y el estatus del estilo 
        /// </summary>
        string[] item;

        int Proveedor = 0;
        string comprador = "";
        int xj = 0;

        bool[] segAutorizar = new bool[4];



        public BonificacionAnticipada()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Evento Click de todos los botones de la pantalla
        /// </summary>
        /// <param name="sender">Sender (Default)</param>
        /// <param name="e">e (Default)</param>
        private void Buttons_Click(object sender, EventArgs e)
        {
            dgvEstilosPreautorizados.EndEdit();
            dgvEstilosPreautorizados.ClearSelection();
            this.dgvEstilosPreautorizados.Refresh();

            this.dgvDetalleFolios.EndEdit();
            this.dgvDetalleFolios.ClearSelection();
            this.dgvDetalleFolios.Refresh();

            string msg = "";

            string ordenCompraValidar = "";
            bool Existe = false;

            try
            {
                if (sender == this.btnAutorizar)
                {
                    AutorizarEstilosSeleccionados();
                }

                if (sender == this.btnLiberar)
                {
                    msg = "Las Ordenes de Compra marcadas [*], seran quitados de la solicitud y quedaran disponibles para ser asignados a otra.\n\n¿Desea continuar?";
                    if (MessageBox.Show(msg, "Convenio", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                    {
                        LiberarEstilosSeleccionados();
                        CargaOrdenesCompra();
                        CargaOrdenesCompra(2, item[0]);
                        //this.dgvDetalleFolios.DataSource = Negocio.Convenio.Reprogramacion.CargaListaFoliosOC(item[0]);
                        //this.dgvEstilosPreautorizados.DataSource = Negocio.Convenio.Reprogramacion.(Marca);
                        CargaFolios();
                    }
                }

                if (sender == this.btnMarcarTodas)
                {
                    //Marcar o desmarcar todos los estilos de la lista
                    foreach (DataGridViewRow row in this.dgvEstilosPreautorizados.Rows)
                    {
                        row.Cells[0].Value = !CheckMarcados;
                    }

                    CheckMarcados = !CheckMarcados;
                }

                if (sender == this.btnMarcarDetalle)
                {
                    //Marcar o desmarcar todos los estilos de la lista
                    foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
                    {
                        row.Cells[0].Value = !CheckMarcadosDetalle;
                    }

                    CheckMarcadosDetalle = !CheckMarcadosDetalle;
                }

                if (sender == this.btnAgregar)
                {
                    foreach (DataGridViewRow row in this.dgvEstilosPreautorizados.Rows)
                    {
                        //Instanciar la columna checkbox de la grid de Ordenes de Compra
                        DataGridViewCheckBoxCell chk = dgvEstilosPreautorizados.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                        //Orden de Compra seleccionada??
                        if (Convert.ToBoolean(chk.Value) == true)
                        {
                            if (this.dgvOCSeleccionadas.RowCount == 0)
                            {
                                //Obtener el primer COMPRADOR de la primer Orden de Compra, para validar que siempre sea el mismo
                                comprador = dgvEstilosPreautorizados.Rows[row.Index].Cells["BYRNUM"].Value.ToString();
                            }

                            //Validar que el comprador sea el mismo para todas las ordenes seleccionadas
                            if (comprador == dgvEstilosPreautorizados.Rows[row.Index].Cells["BYRNUM"].Value.ToString())
                            {
                                //Recuperar OC de la selección
                                ordenCompraValidar = dgvEstilosPreautorizados.Rows[row.Index].Cells["PONUMB"].Value.ToString();

                                if (this.dgvOCSeleccionadas.RowCount > 0)
                                {
                                    //Validar que la Orden de Compra no se haya agregado previamente a la grid
                                    foreach (DataGridViewRow rowt in this.dgvOCSeleccionadas.Rows)
                                    {
                                        Existe = (ordenCompraValidar == dgvOCSeleccionadas.Rows[rowt.Index].Cells["OrdenCompra"].Value.ToString()) ? true : false;

                                        if (Existe == true)
                                        {
                                            //MessageBox.Show(string.Format("La Orden de Compra: {0} ya ha sido ingresada.", ordenCompraValidar), "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                            break;
                                        }
                                    }

                                    if (Existe == false)
                                    {
                                        this.dgvOCSeleccionadas.Rows.Add(dgvEstilosPreautorizados.Rows[row.Index].Cells["PONUMB"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["POVNUM"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["ASNAME"].Value);
                                    }
                                    else
                                    {
                                        Existe = false;
                                    }
                                }
                                else
                                {
                                    this.dgvOCSeleccionadas.Rows.Add(dgvEstilosPreautorizados.Rows[row.Index].Cells["PONUMB"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["POVNUM"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["ASNAME"].Value);
                                }
                            }
                            else
                            {
                                MessageBox.Show(string.Format("Las Ordenes de Compra deben ser del mismo Comprador.\n\nOrden de Compra no agregada: {0}", dgvEstilosPreautorizados.Rows[row.Index].Cells["PONUMB"].Value), "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            }
                        }
                    }
                }

                if (sender == this.btnImprimir)
                {
                    if (Convert.ToInt32(item[0]) > 0)
                    {

                        rptBonificacionParcial f = new rptBonificacionParcial();
                        f.StartPosition = FormStartPosition.CenterParent;
                        f.Folio = Convert.ToInt32(item[0]);
                        f.ShowDialog(this);

                    }
                    else
                    {
                        MessageBox.Show("Debe seleccionar una solicitud para imprimirla", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }

                }

                if (sender == this.tsbEliminarTodos)
                {
                    EliminaRegistros();
                }

                if (sender == this.btnGenerarFormato)
                {
                    if (this.dgvOCSeleccionadas.Rows.Count > 0)
                    {

                        if (MessageBox.Show("Las Ordenes de Compra seleccionadas se asignaran a un nuevo folio de 'Bonificación parcial'\n\n¿Desea continuar?", "Convenio", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                        {
                            Folio = Negocio.Convenio.Reprogramacion.ObtenerFolio(4);
                            this.lblFolio.Text = string.Format("Folio: {0}", Folio);

                            LigarOCFolio();

                            MessageBox.Show(string.Format("Se genero la solicitud con el número de folio: {0}", Folio), "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            Folio = "";
                            CargaFolios();
                            //this.dgvEstilosPreautorizados.DataSource = Negocio.Convenio.Reprogramacion.CargaReprogramacionesSinFormato(Marca);

                            EliminaRegistros();
                            CargaOrdenesCompra();
                            AplicarEstiloGrids(this.dgvEstilosPreautorizados);
                        }
                        else
                        {
                            MessageBox.Show("La operación fue cancelada, no se realizaron cambios.", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                    else
                    {
                        MessageBox.Show("ATENCIÓN!\nNo se han seleccionado estilos para asignar un folio, marquelos y haga click en el botón de 'Actualizar estilos'", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }

                if (sender == this.btnBuscarOc)
                {
                    CargaOrdenesCompra();
                    AplicarEstiloGrids(this.dgvEstilosPreautorizados);
                }

                if (sender == this.btnCancelar)
                {
                    this.pnlActualizar.Visible = false;
                }

                if (sender == this.btnAceptar)
                {
                    if (this.dtpFechaAmpliacion.Value <= DateTime.Now)
                    {
                        MessageBox.Show("La fecha de ampliación de la Orden de Compra tiene que ser mayor a la fecha actual", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {

                        Negocio.Convenio.Reprogramacion.ActualizarFechaAmpliacion(
                            this.dtpFechaAmpliacion.Value,
                            Convert.ToInt32(this.cboMotivo.SelectedValue),
                              Convert.ToInt32(item[0]),
                            Convert.ToInt32(this.lblOrdenCompra.Text));

                        MessageBox.Show("Fecha de ampliación actualizada", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        CargaOrdenesCompra(2, item[0]);
                        this.pnlActualizar.Visible = false;



                    }


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CargaOrdenesCompra(byte Vista = 1, string Folio = "0")
        {

            string q = "";

            q = (this.cboOrigen.ComboBox.SelectedItem == "Nacional") ? "1" : "2";

            if (Vista == 1)
            {
                //Cargar la grid con las ordenes de compra dispobibles para el formato
                this.dgvEstilosPreautorizados.DataSource = Negocio.Convenio.Convenio.CargaBonificacionParcial(this.txtBuscarOc.Text.Trim(), Convert.ToInt32(q), Vista, MmsWin.Front.Utilerias.VarTem.tmpComprador);
                this.lblTot.Text = string.Format("Total: {0}", this.dgvEstilosPreautorizados.RowCount.ToString());
            }
            else if (Vista == 2)
            {

                this.dgvDetalleFolios.DataSource = Negocio.Convenio.Convenio.CargaBonificacionParcial(Folio, Convert.ToInt32(q), Vista);
                try
                {
                    AplicarEstiloGrids(this.dgvDetalleFolios);
                }
                catch
                {

                    throw;
                }


                //this.dgvDetalleFolios.Columns["DESCRMOTIVO"].Visible = true;
                //this.dgvDetalleFolios.Columns["Extra4"].Visible = true;

            }


        }

        private void AutorizarEstilosSeleccionados()
        {
            int check = 0;
            int noCheck = 0;

            Folio = item[0];

            foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
            {
                DataGridViewCheckBoxCell chk = dgvDetalleFolios.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                if (Convert.ToBoolean(chk.Value) == true)
                {
                    check++;
                }
                else
                {
                    noCheck++;
                }
            }

            if (noCheck == 0)
            {
                foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
                {
                    DataGridViewCheckBoxCell chk = dgvDetalleFolios.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                    if (Convert.ToBoolean(chk.Value) == true)
                    {
                        Negocio.Convenio.Convenio.BonificacionParcial_uf(
                            Convert.ToInt32(Folio),
                            MmsWin.Front.Utilerias.VarTem.tmpUser
                            );
                    }
                }

                CargaOrdenesCompra();
                CargaOrdenesCompra(2, item[0]);
               
                //this.dgvDetalleFolios.DataSource = Negocio.Convenio.Reprogramacion.CargaDetalleFolio(Folio);
                //this.dgvEstilosPreautorizados.DataSource = Negocio.Convenio.Reprogramacion.CargaReprogramacionesSinFormato(Marca);
                
                EliminaRegistros();
                CargaFolios();
               
                this.btnMarcarDetalle.Enabled = false;
                this.btnAutorizar.Enabled = false;
                this.btnLiberar.Enabled = false;
                
                MessageBox.Show("SOLICITUD [ " + Folio + " ] AUTORIZADA correctamente.", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("Debe de seleccionar todas las casillas para autorizar la solicitud. Si desea excluir estilos, primero debe liberarlos.", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /// <summary>
        /// Desvincula los estilos seleccionados del folio en revisión y quedan libres para asignarse a otra solicitud
        /// </summary>
        private void LiberarEstilosSeleccionados()
        {
            foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
            {
                DataGridViewCheckBoxCell chk = dgvDetalleFolios.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                if (Convert.ToBoolean(chk.Value) == true)
                {
                    Negocio.Convenio.Convenio.BonificacionParcial_desautorizar(
                        Convert.ToInt32(dgvDetalleFolios.Rows[row.Index].Cells["PONUMB"].Value.ToString()),
                         MmsWin.Front.Utilerias.VarTem.tmpUser
                   );

                }
            }

            CargaOrdenesCompra(2, item[0]);
        }

        /// <summary>
        /// Liga los estilos seleccionados al folio correspondiente
        /// </summary>
        private void LigarOCFolio()
        {
            foreach (DataGridViewRow row in this.dgvOCSeleccionadas.Rows)
            {
                //DataGridViewCheckBoxCell chk = dgvEstilosPreautorizados.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                //if (Convert.ToBoolean(chk.Value) == true)
                //{
                Negocio.Convenio.Convenio.BonificacionParcial_u(
                    Convert.ToInt32(dgvOCSeleccionadas.Rows[row.Index].Cells["ORDENCOMPRA"].Value.ToString()),
                    Convert.ToInt32(Folio),
                    MmsWin.Front.Utilerias.VarTem.tmpUser);
                //}
            }
        }

        /// <summary>
        /// Borrar los registros de la grid de estilos seleccionados
        /// </summary>
        private void EliminaRegistros()
        {
            int r = (dgvOCSeleccionadas.Rows.Count - 1);

            for (int i = 0; i <= r; i++)
            {
                dgvOCSeleccionadas.Rows.RemoveAt(0);
            }
        }

        /// <summary>
        /// Inicialización de la pantalla
        /// </summary>
        /// <param name="sender">Sender (Default)</param>
        /// <param name="e">e (Default)</param>
        private void Preautorizaciones_Load(object sender, EventArgs e)
        {


            this.cboOrigen.ComboBox.SelectedItem = "Nacional";
            this.cboEstatus.ComboBox.SelectedItem = "Pendientes";
            this.lblFolio.Text = "Folio: N/G";
            this.pnlActualizar.Visible = false;

            this.cboMotivo.DataSource = Negocio.Convenio.Reprogramacion.CargaMotivosAOC();
            this.cboMotivo.DisplayMember = "Descripcion";
            this.cboMotivo.ValueMember = "Id";

            CargaOrdenesCompra();

            //Agregar columna "CheckBox" a los estilos que se seleccionaran para agregar al formato

            DataGridViewCheckBoxColumn CheckboxColumn = new DataGridViewCheckBoxColumn();
            CheckboxColumn.TrueValue = true;
            CheckboxColumn.FalseValue = false;
            CheckboxColumn.Width = 100;
            dgvEstilosPreautorizados.Columns.Insert(0, CheckboxColumn);

            DataGridViewCheckBoxColumn Checkbox_Column = new DataGridViewCheckBoxColumn();
            CheckboxColumn.TrueValue = true;
            CheckboxColumn.FalseValue = false;
            CheckboxColumn.Width = 100;
            dgvDetalleFolios.Columns.Insert(0, Checkbox_Column);

            dgvEstilosPreautorizados.EditMode = DataGridViewEditMode.EditOnKeystroke;
            dgvDetalleFolios.EditMode = DataGridViewEditMode.EditOnKeystroke;

            //-----------------------------------------------------------------------------------------

            CargaFolios();
            AplicarEstiloGrids(this.dgvEstilosPreautorizados);
            //Seguridad("AmpliacionOC", "AmpliacionOC", MmsWin.Front.Utilerias.VarTem.tmpUser);
        }


        private void AplicarEstiloGrids(DataGridView Grid)
        {

            ////Visibilidad
            Grid.Columns["FOLIOS"].Visible = false;
            Grid.Columns["AUSTAT"].Visible = false;
            Grid.Columns["BODEGA"].Visible = false;
            Grid.Columns["Origen"].Visible = false;


            //Fuente y alineación
            this.dgvEstilosPreautorizados.Columns[0].Frozen = true;
            Grid.Columns[0].Width = 20;

            Grid.Columns["PONUMB"].HeaderText = "ORDCOM";
            Grid.Columns["PONUMB"].Frozen = true;
            Grid.Columns["PONUMB"].DefaultCellStyle.Font = new Font("Tahoma", 10, FontStyle.Bold);//Fecha inspección
            Grid.Columns["PONUMB"].DefaultCellStyle.ForeColor = Color.Maroon;
            Grid.Columns["PONUMB"].Width = 80;

            Grid.Columns["POVNUM"].HeaderText = "PRV";
            Grid.Columns["POVNUM"].Width = 40;
            Grid.Columns["POVNUM"].Frozen = true;
            Grid.Columns["POVNUM"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            Grid.Columns["POVNUM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Grid.Columns["ASNAME"].HeaderText = "PROVEEDOR";
            Grid.Columns["ASNAME"].Frozen = true;
            //Grid.Columns["ASNAME"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            Grid.Columns["ASNAME"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            Grid.Columns["ASNAME"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            Grid.Columns["SSTYLQ"].HeaderText = "EST";
            Grid.Columns["SSTYLQ"].Frozen = true;
            Grid.Columns["SSTYLQ"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            Grid.Columns["SSTYLQ"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            Grid.Columns["SSTYLQ"].Width = 50;

            Grid.Columns["SSTYLE"].HeaderText = "ESTILO";
            //Grid.Columns["SSTYLE"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            Grid.Columns["SSTYLE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            Grid.Columns["SSTYLE"].Width = 50;

            Grid.Columns["FECREV"].HeaderText = "FECREV";
            Grid.Columns["FECREV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Grid.Columns["FECREV"].Width = 80;

            Grid.Columns["BYRNUM"].HeaderText = "CM";
            Grid.Columns["BYRNUM"].Width = 30;
            Grid.Columns["BYRNUM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            Grid.Columns["BYRNAM"].HeaderText = "COMPRADOR";
            Grid.Columns["BYRNAM"].Width = 100;
            Grid.Columns["BYRNAM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            Grid.Columns["NUMARC"].HeaderText = "MR";
            Grid.Columns["NUMARC"].Width = 30;
            Grid.Columns["NUMARC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;


            Grid.Columns["CALORI"].ToolTipText = "CALIFICACIÓN ORIGINAL";
            Grid.Columns["CALORI"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            Grid.Columns["CALORI"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Grid.Columns["CALORI"].Width = 65;

            Grid.Columns["CALIFI"].ToolTipText = "CALIFICACIÓN FINAL";
            Grid.Columns["CALIFI"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            Grid.Columns["CALIFI"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Grid.Columns["CALIFI"].Width = 65;

            Grid.Columns["PIEREC"].ToolTipText = "PIEZAS RECIBIDAS";
            Grid.Columns["PIEREC"].Width = 50;
            Grid.Columns["PIEREC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["PIEREC"].DefaultCellStyle.Format = "###,###,###,###";

            Grid.Columns["ONHAND"].Width = 60;
            Grid.Columns["ONHAND"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["ONHAND"].DefaultCellStyle.Format = "###,###,###,###";

            Grid.Columns["ONORDR"].Width = 60;
            Grid.Columns["ONORDR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["ONORDR"].DefaultCellStyle.Format = "###,###,###,###";

            Grid.Columns["CSTTOT"].ToolTipText = "COSTO TOTAL";
            Grid.Columns["CSTTOT"].Width = 60;
            Grid.Columns["CSTTOT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["CSTTOT"].DefaultCellStyle.Format = "###,###,###,###";

            Grid.Columns["CSTACT"].ToolTipText = "COSTO ACTUAL";
            Grid.Columns["CSTACT"].Width = 60;
            Grid.Columns["CSTACT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["CSTACT"].DefaultCellStyle.Format = "###,###,###,###";

            Grid.Columns["PREACT"].ToolTipText = "PRECIO ACTUAL";
            Grid.Columns["PREACT"].Width = 60;
            Grid.Columns["PREACT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["PREACT"].DefaultCellStyle.Format = "###,###,###,###";

            Grid.Columns["CODTEM"].HeaderText = "TT";
            Grid.Columns["CODTEM"].ToolTipText = "TEMPORADA";
            Grid.Columns["CODTEM"].Width = 40;
            Grid.Columns["CODTEM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;


            Grid.Columns["SFEREG"].HeaderText = "REGISTRO";
            Grid.Columns["SFEREG"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Grid.Columns["SFEREG"].Width = 80;


            Grid.Columns["SUSREG"].HeaderText = "USUARIO";
            Grid.Columns["SUSREG"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            Grid.Columns["SUSREG"].Width = 80;


            Grid.Columns["ONHACT"].HeaderText = "ONHAND-ACT";
            Grid.Columns["ONHACT"].ToolTipText = "ONHAND ACTUAL";
            Grid.Columns["ONHACT"].Width = 80;
            Grid.Columns["ONHACT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["ONHACT"].DefaultCellStyle.Format = "###,###,###,###";

            Grid.Columns["TRANSIT"].HeaderText = "TRANSITO";
            //Grid.Columns["TRANSIT"].ToolTipText = "ONHAND ACTUAL";
            Grid.Columns["TRANSIT"].Width = 60;
            Grid.Columns["TRANSIT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["TRANSIT"].DefaultCellStyle.Format = "###,###,###,###";

            Grid.Columns["COSTO"].HeaderText = "COSTO_ACT";
            Grid.Columns["COSTO"].ToolTipText = "COSTO ACTUAL";
            Grid.Columns["COSTO"].Width = 80;
            Grid.Columns["COSTO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["COSTO"].DefaultCellStyle.Format = "###,###,###,###.00";

            //Grid.Columns["BONORIGINAL"].HeaderText = "COSTO_ACT";
            Grid.Columns["BONORIGINAL"].ToolTipText = "MONTO BONIFICACIÓN ORIGINAL";
            Grid.Columns["BONORIGINAL"].Width = 80;
            Grid.Columns["BONORIGINAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["BONORIGINAL"].DefaultCellStyle.Format = "###,###,###,###.00";

            //Grid.Columns["BONACTUAL"].HeaderText = "COSTO_ACT";
            Grid.Columns["BONACTUAL"].ToolTipText = "MONTO BONIFICACIÓN ACTUAL";
            Grid.Columns["BONACTUAL"].Width = 80;
            Grid.Columns["BONACTUAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            Grid.Columns["BONACTUAL"].DefaultCellStyle.Format = "###,###,###,###.00";







            Grid.Columns["SSTYLE"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;







            //Título de los encabezados
            //Grid.Columns["PONUMB"].HeaderText = "NoOC";
            //Grid.Columns["POVNUM"].HeaderText = "NoPROV";
            //Grid.Columns["ASNAME"].HeaderText = "PROVEEDOR";
            //Grid.Columns["POBUYR"].HeaderText = "NoCOMP";
            //Grid.Columns["BYRNAM"].HeaderText = "COMPRADOR";
            //Grid.Columns["FECHAENTRADA"].HeaderText = "REGISTRO";
            //Grid.Columns["FECHAVENCIMIENTO"].HeaderText = "VENCIMIENTO";
            //Grid.Columns["ESTILOS"].HeaderText = "NoEST";
            //Grid.Columns["NoEntregadas"].HeaderText = "OCNoEntregadas";
            //Grid.Columns["Extra4"].HeaderText = "NvaFecha";


            #region [ Dar formato a la grid de estilos seleccionados ]

            this.dgvOCSeleccionadas.Columns.Add("OrdenCompra", "OrdenCompra");
            this.dgvOCSeleccionadas.Columns.Add("NoProveedor", "NoProveedor");
            this.dgvOCSeleccionadas.Columns.Add("Proveedor", "Proveedor");


            //Fuente
            this.dgvOCSeleccionadas.Columns["OrdenCompra"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            this.dgvOCSeleccionadas.Columns["NoProveedor"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            //Ancho
            this.dgvOCSeleccionadas.Columns["OrdenCompra"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvOCSeleccionadas.Columns["NoProveedor"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvOCSeleccionadas.Columns["Proveedor"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;

            #endregion

        }



        /// <summary>
        /// Llena el listview con los folios generados
        /// </summary>
        /// <param name="Folio">Folio que se desea buscar</param>
        private void CargaFolios(string Folio = "")
        {
            DataTable dt = new DataTable();
            int imagen = 0;

            string q = "";

            q = (this.cboEstatus.ComboBox.SelectedItem == "Pendientes") ? "P" : "A";

            dt = Negocio.Convenio.Convenio.CargaListaFoliosBonAnt(this.txtBuscar.Text.Trim(), q, MmsWin.Front.Utilerias.VarTem.tmpComprador);

            this.lsvFolios.Items.Clear();

            for (int i = 0; i < dt.Rows.Count; i++)
            {

                DataRow dr = dt.Rows[i];

                if (dr["Estatus"].ToString() == "Autorizado")
                {
                    imagen = 3;
                }
                else
                {
                    imagen = 0;
                }

                this.lsvFolios.Items.Add(dr["Folio"].ToString() + "," + dr["Estatus"].ToString(), dr["Folio"].ToString() + "\n" + dr["Estatus"].ToString(), imagen);
            }

            dt.Dispose();
        }

        private void lsvFolios_DoubleClick(object sender, EventArgs e)
        {
            //Recuperar el folio
            item = this.lsvFolios.SelectedItems[0].Name.Split(',');

            //this.dgvDetalleFolios.DataSource = Negocio.Convenio.Reprogramacion.CargaDetalleFolio(item[0]);
            CargaOrdenesCompra(2, item[0]);

            if (item[1] == "Autorizado" || item[1] == "Vencido")
            {
                this.btnMarcarDetalle.Enabled = false;
                this.btnAutorizar.Enabled = false;
                this.btnLiberar.Enabled = false;
            }

            //Comentado para que este disponible la opción para todos
            //else
            //{
            //    if (segAutorizar[0] == true)
            //    {
            //        this.btnAutorizar.Enabled = true;
            //    }

            //    if (segAutorizar[2] == true)
            //    {
            //        this.btnLiberar.Enabled = true;
            //    }

            //    this.btnMarcarDetalle.Enabled = true;
            //}

            this.dgvDetalleFolios.Columns["BONORIGINAL"].Visible = false;
            this.dgvDetalleFolios.Columns["CALIFI"].Visible = false;
            this.dgvDetalleFolios.Columns["BYRNUM"].Visible = false;
            this.dgvDetalleFolios.Columns["SUSREG"].Visible = false;
            this.dgvDetalleFolios.Columns["NUMARC"].Visible = false;

        }

        private void Event_TextBox_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyValue.ToString() == "13")
            {


                CargaOrdenesCompra();
                AplicarEstiloGrids(this.dgvEstilosPreautorizados);
            }

        }

        private void Event_cbo_SelectIndexChanged(object sender, EventArgs e)
        {
            if (sender == this.cboOrigen)
            {
                CargaOrdenesCompra();
            }
            if (sender == this.cboEstatus)
            {
                CargaFolios();
                if (this.cboEstatus.SelectedItem == "Autorizadas")
                {
                    this.btnImprimir.Enabled = false;
                }
                else
                { this.btnImprimir.Enabled = true; }
            }
        }

        private void dgvDetalleFolios_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            this.pnlActualizar.Visible = true;
            this.lblOrdenCompra.Text = this.dgvDetalleFolios.Rows[e.RowIndex].Cells["PONUMB"].Value.ToString();
        }

        #region [ Seguridad ]

        /// <summary>
        /// Registra los controles en la tabla de seguridad
        /// </summary>
        /// <param name="sender">Obeject Sender</param>
        /// <param name="e">Form Closing event</param>
        /// <remarks>
        ///     Desarrollador: Gustavo de los Santos | 08/12/2016
        ///     Actualizo: Omar Cervantes  | 01/03/2017
        ///     Paso seguridad: 1
        /// </remarks>
        private void AmpliacionOC_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MmsWin.Front.Utilerias.VarTem.tmpUSRVIL == "ADMINISTRADOR")
            {
                CargaSeguridad("AmpliacionOC", "AmpliacionOC", MmsWin.Front.Utilerias.VarTem.tmpUser);
            }
        }

        /// <summary>
        /// Inserta los controles del formulario a la tabla MMSATOBJ.SAT177SCLS
        /// </summary>
        /// <param name="Aplicacion">Nombre de la aplicación</param>
        /// <param name="Modulo">Nombre del módulo</param>
        /// <param name="Usuario">Usuario que inicio sesión</param>
        /// <remarks>
        ///     Desarrollador: Gustavo de los Santos | 08/12/2016
        ///     Actualizo: Omar Cervantes  | 28/02/2017
        ///     Paso seguridad: 2
        /// </remarks>
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");

            //Definición de la estructura del DataTable
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (ToolStripItem item in tspGeneracionFormatos.Items)
            {
                DataRow toolStripControls = dtControles.NewRow();

                //Valores generales para cada renglon  
                toolStripControls["Aplicacion"] = Aplicacion;
                toolStripControls["Modulo"] = Modulo;
                toolStripControls["Usuario"] = Usuario;

                //Si el control es del tipo "ToolStripButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripComboBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripComboBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripComboBox";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripSplitButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripSplitButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripSplitButton";

                    dtControles.Rows.Add(toolStripControls);
                }



                //Si el control es del tipo "ToolStripLabel"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripTextBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripTextBox";

                    dtControles.Rows.Add(toolStripControls);
                }
            }

            foreach (ToolStripItem item in this.tspOrdenesSeleccionadas.Items)
            {
                DataRow toolStripControls = dtControles.NewRow();

                //Valores generales para cada renglon  
                toolStripControls["Aplicacion"] = Aplicacion;
                toolStripControls["Modulo"] = Modulo;
                toolStripControls["Usuario"] = Usuario;

                //Si el control es del tipo "ToolStripButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripComboBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripComboBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripComboBox";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripSplitButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripSplitButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripSplitButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripLabel"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripTextBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripTextBox";

                    dtControles.Rows.Add(toolStripControls);
                }
            }

            foreach (ToolStripItem item in this.tspConsultaAutorizadas.Items)
            {
                DataRow toolStripControls = dtControles.NewRow();

                //Valores generales para cada renglon  
                toolStripControls["Aplicacion"] = Aplicacion;
                toolStripControls["Modulo"] = Modulo;
                toolStripControls["Usuario"] = Usuario;

                //Si el control es del tipo "ToolStripButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripComboBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripComboBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripComboBox";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripSplitButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripSplitButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripSplitButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripTextBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripTextBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripTextBox";

                    dtControles.Rows.Add(toolStripControls);
                }
            }

            foreach (ToolStripItem item in this.tspAutorizadas.Items)
            {
                DataRow toolStripControls = dtControles.NewRow();

                //Valores generales para cada renglon  
                toolStripControls["Aplicacion"] = Aplicacion;
                toolStripControls["Modulo"] = Modulo;
                toolStripControls["Usuario"] = Usuario;

                //Si el control es del tipo "ToolStripButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripComboBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripComboBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripComboBox";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripSplitButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripSplitButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripSplitButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripTextBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripTextBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripTextBox";

                    dtControles.Rows.Add(toolStripControls);
                }

            }

            //Guardar los controles recuperados de la pantalla.
            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        /// <summary>
        /// Recupera los niveles del perfil del usuario y aplica los permisos
        /// a los controles del formulario
        /// </summary>
        /// <param name="Aplicacion">Nombre de aplicación o pantalla</param>
        /// <param name="Modulo">Nombre del módulo</param>
        /// <param name="Usuario">ID del usuario</param>
        /// <remarks>
        ///     Desarrollador: Gustavo de los Santos | 08/12/2016
        ///     Actualizo: Omar Cervantes  | 28/02/2017
        ///     Paso seguridad: 3
        /// </remarks>
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            // Buscar el control dentro del DataTable
            DataRow[] foundRows;

            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);

            string busca = string.Empty;

            //Aplicar seguridad de los controles que no se encuentran dentro de un control 
            //contenedor
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }

            foreach (ToolStripItem item in this.tspAutorizadas.Items)
            {
                foundRows = tbSeguridad.Select("SEGCLS Like '" + item.Name + "%'");

                if (foundRows.Count() > 0)
                {
                    if (item.Name == (foundRows[0]["SEGCLS"].ToString()))
                    {
                        item.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        item.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }

            }

            foreach (ToolStripItem item in this.tspConsultaAutorizadas.Items)
            {
                foundRows = tbSeguridad.Select("SEGCLS Like '" + item.Name + "%'");

                if (foundRows.Count() > 0)
                {
                    if (item.Name == (foundRows[0]["SEGCLS"].ToString()))
                    {
                        item.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        item.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }

            }

            foreach (ToolStripItem item in this.tspGeneracionFormatos.Items)
            {
                foundRows = tbSeguridad.Select("SEGCLS Like '" + item.Name + "%'");

                if (foundRows.Count() > 0)
                {
                    if (item.Name == (foundRows[0]["SEGCLS"].ToString()))
                    {
                        item.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        item.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }

            }

            foreach (ToolStripItem item in this.tspOrdenesSeleccionadas.Items)
            {
                foundRows = tbSeguridad.Select("SEGCLS Like '" + item.Name + "%'");

                if (foundRows.Count() > 0)
                {
                    if (item.Name == (foundRows[0]["SEGCLS"].ToString()))
                    {
                        item.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        item.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }

            }

            foreach (Control X in this.Controls)
            {

                busca = X.Name;


                foundRows = tbSeguridad.Select("SEGCLS Like '" + busca + "%'");

                if (foundRows.Count() > 0)
                {
                    if (X.GetType() != typeof(ToolStrip))
                    {
                        X.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        X.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }
            }

            //Recupera de la seguridad, el valor de las propiedades "Enabled" y "Visible" para 
            //botón btnAutorizar
            segAutorizar[0] = this.btnAutorizar.Enabled;
            segAutorizar[1] = this.btnAutorizar.Visible;

            //botón btnLiberar
            segAutorizar[2] = this.btnLiberar.Enabled;
            segAutorizar[3] = this.btnLiberar.Visible;
        }






        /// <summary>
        /// Aplicar seguridad de los controles que no se encuentran dentro de un control 
        /// contenedor
        /// </summary>
        /// <param name="Controles">Nombre del control</param>
        /// <param name="ValHab">Valor para aplicar a "Enabled"</param>
        /// <param name="ValVis">Valor para aplicar a  "Visibkle"</param>
        /// <param name="tipo">Tipo de objeto</param>
        /// <remarks>
        ///     Desarrollador: Gustavo de los Santos | 08/12/2016
        ///     Actualizo: Omar Cervantes  | 01/03/2017
        ///     Paso seguridad: 4
        /// </remarks>
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                this.Controls[Controles].Enabled = Convert.ToBoolean(ValHab);
                this.Controls[Controles].Visible = Convert.ToBoolean(ValVis);
            }
        }

        #endregion
    }


}
