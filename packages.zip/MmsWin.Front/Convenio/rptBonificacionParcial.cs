﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class rptBonificacionParcial : Form
    {
        public int Folio { get; set; }

        public rptBonificacionParcial()
        {
            InitializeComponent();
        }

        private void rptBonificacionParcial_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dsSAT177AOC.VWBONPARCI' Puede moverla o quitarla según sea necesario.
            this.vWBONPARCITableAdapter.Fill(this.dsSAT177AOC.VWBONPARCI,Folio);

            this.reportViewer1.RefreshReport();
        }
    }
}
