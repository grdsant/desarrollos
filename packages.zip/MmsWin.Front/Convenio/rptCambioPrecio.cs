﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class rptCambioPrecio : Form
    {
        public int Folio { get; set; }
        public rptCambioPrecio()
        {
            InitializeComponent();
        }

        private void rptCambioPrecio_Load(object sender, EventArgs e)
        {
            try
            {
                // TODO: esta línea de código carga datos en la tabla 'dsSAT177rpt.SAT177RPCRV' Puede moverla o quitarla según sea necesario.
                // = (this.dsSAT177rpt.SAT177RPCRV, Folio);
                this.sAT177RPCCPTableAdapter.Fill(this.dsSAT177MMNETLIB.SAT177RPCCP, Folio);
                this.reportViewer1.RefreshReport();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
    }
}
