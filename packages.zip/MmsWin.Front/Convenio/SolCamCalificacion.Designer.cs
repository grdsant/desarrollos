﻿namespace MmsWin.Front.Convenio
{
    partial class SolCamCalificacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.lblMensage = new System.Windows.Forms.Label();
            this.lblPorNueva = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cboMotivo = new System.Windows.Forms.ComboBox();
            this.lblMotivo = new System.Windows.Forms.Label();
            this.cbPagar = new System.Windows.Forms.CheckBox();
            this.lblPagado = new System.Windows.Forms.Label();
            this.lblDifBonDesc = new System.Windows.Forms.Label();
            this.lblDifBon = new System.Windows.Forms.Label();
            this.lblCostoBonNueDesc = new System.Windows.Forms.Label();
            this.lblCostoBonNue = new System.Windows.Forms.Label();
            this.lblCostoBonActDesc = new System.Windows.Forms.Label();
            this.lblCostoBonAct = new System.Windows.Forms.Label();
            this.lblCostoTotDesc = new System.Windows.Forms.Label();
            this.lblCostoActDesc = new System.Windows.Forms.Label();
            this.lblCostoTot = new System.Windows.Forms.Label();
            this.lblCostoAct = new System.Windows.Forms.Label();
            this.lblOnHandDesc = new System.Windows.Forms.Label();
            this.lblOnHand = new System.Windows.Forms.Label();
            this.lblcaltificacion = new System.Windows.Forms.Label();
            this.tbCalNueva = new System.Windows.Forms.TextBox();
            this.btAceptar = new System.Windows.Forms.Button();
            this.btCancelar = new System.Windows.Forms.Button();
            this.lblComprador = new System.Windows.Forms.Label();
            this.lblNumReprog = new System.Windows.Forms.Label();
            this.lblEstilo = new System.Windows.Forms.Label();
            this.lblProveedor = new System.Windows.Forms.Label();
            this.lblDescProveedor = new System.Windows.Forms.Label();
            this.lblNombreProv = new System.Windows.Forms.Label();
            this.lblidEstilo = new System.Windows.Forms.Label();
            this.lblDescEstilo = new System.Windows.Forms.Label();
            this.lblCompradorDesc = new System.Windows.Forms.Label();
            this.lblNumProg = new System.Windows.Forms.Label();
            this.lblMarca = new System.Windows.Forms.Label();
            this.lblDescMarca = new System.Windows.Forms.Label();
            this.lblOC = new System.Windows.Forms.Label();
            this.lblOCDesc = new System.Windows.Forms.Label();
            this.lblTem = new System.Windows.Forms.Label();
            this.lblTemporada = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 110);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 13);
            this.label5.TabIndex = 42;
            this.label5.Text = "% bonificación :";
            // 
            // lblMensage
            // 
            this.lblMensage.AutoSize = true;
            this.lblMensage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMensage.ForeColor = System.Drawing.Color.DarkRed;
            this.lblMensage.Location = new System.Drawing.Point(29, 177);
            this.lblMensage.Name = "lblMensage";
            this.lblMensage.Size = new System.Drawing.Size(33, 15);
            this.lblMensage.TabIndex = 37;
            this.lblMensage.Text = "error";
            // 
            // lblPorNueva
            // 
            this.lblPorNueva.AutoSize = true;
            this.lblPorNueva.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPorNueva.Location = new System.Drawing.Point(7, 134);
            this.lblPorNueva.Name = "lblPorNueva";
            this.lblPorNueva.Size = new System.Drawing.Size(111, 13);
            this.lblPorNueva.TabIndex = 35;
            this.lblPorNueva.Text = "% bonificación nuevo:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PowderBlue;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cbPagar);
            this.panel1.Controls.Add(this.lblPagado);
            this.panel1.Controls.Add(this.lblDifBonDesc);
            this.panel1.Controls.Add(this.lblDifBon);
            this.panel1.Controls.Add(this.lblCostoBonNueDesc);
            this.panel1.Controls.Add(this.lblCostoBonNue);
            this.panel1.Controls.Add(this.lblCostoBonActDesc);
            this.panel1.Controls.Add(this.lblCostoBonAct);
            this.panel1.Controls.Add(this.lblCostoTotDesc);
            this.panel1.Controls.Add(this.lblCostoActDesc);
            this.panel1.Controls.Add(this.lblCostoTot);
            this.panel1.Controls.Add(this.lblCostoAct);
            this.panel1.Controls.Add(this.lblOnHandDesc);
            this.panel1.Controls.Add(this.lblOnHand);
            this.panel1.Controls.Add(this.lblcaltificacion);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.lblMensage);
            this.panel1.Controls.Add(this.tbCalNueva);
            this.panel1.Controls.Add(this.lblPorNueva);
            this.panel1.Location = new System.Drawing.Point(12, 133);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(445, 211);
            this.panel1.TabIndex = 45;
            // 
            // cboMotivo
            // 
            this.cboMotivo.FormattingEnabled = true;
            this.cboMotivo.Location = new System.Drawing.Point(12, 355);
            this.cboMotivo.Name = "cboMotivo";
            this.cboMotivo.Size = new System.Drawing.Size(278, 21);
            this.cboMotivo.TabIndex = 85;
            // 
            // lblMotivo
            // 
            this.lblMotivo.AutoSize = true;
            this.lblMotivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMotivo.Location = new System.Drawing.Point(14, 358);
            this.lblMotivo.Name = "lblMotivo";
            this.lblMotivo.Size = new System.Drawing.Size(42, 13);
            this.lblMotivo.TabIndex = 84;
            this.lblMotivo.Text = "Motivo:";
            // 
            // cbPagar
            // 
            this.cbPagar.AutoSize = true;
            this.cbPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPagar.Location = new System.Drawing.Point(123, 157);
            this.cbPagar.Name = "cbPagar";
            this.cbPagar.Size = new System.Drawing.Size(139, 17);
            this.cbPagar.TabIndex = 83;
            this.cbPagar.Text = "Casilla marcada = Pagar";
            this.cbPagar.UseVisualStyleBackColor = true;
            this.cbPagar.CheckedChanged += new System.EventHandler(this.cbPagar_CheckedChanged);
            // 
            // lblPagado
            // 
            this.lblPagado.AutoSize = true;
            this.lblPagado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPagado.Location = new System.Drawing.Point(6, 157);
            this.lblPagado.Name = "lblPagado";
            this.lblPagado.Size = new System.Drawing.Size(84, 13);
            this.lblPagado.TabIndex = 82;
            this.lblPagado.Text = "Directo a Pagar:";
            // 
            // lblDifBonDesc
            // 
            this.lblDifBonDesc.AutoSize = true;
            this.lblDifBonDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDifBonDesc.Location = new System.Drawing.Point(323, 38);
            this.lblDifBonDesc.Name = "lblDifBonDesc";
            this.lblDifBonDesc.Size = new System.Drawing.Size(14, 13);
            this.lblDifBonDesc.TabIndex = 56;
            this.lblDifBonDesc.Text = "1";
            // 
            // lblDifBon
            // 
            this.lblDifBon.AutoSize = true;
            this.lblDifBon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDifBon.Location = new System.Drawing.Point(183, 38);
            this.lblDifBon.Name = "lblDifBon";
            this.lblDifBon.Size = new System.Drawing.Size(118, 13);
            this.lblDifBon.TabIndex = 55;
            this.lblDifBon.Text = "Diferencia bonificación:";
            // 
            // lblCostoBonNueDesc
            // 
            this.lblCostoBonNueDesc.AutoSize = true;
            this.lblCostoBonNueDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoBonNueDesc.Location = new System.Drawing.Point(323, 62);
            this.lblCostoBonNueDesc.Name = "lblCostoBonNueDesc";
            this.lblCostoBonNueDesc.Size = new System.Drawing.Size(13, 13);
            this.lblCostoBonNueDesc.TabIndex = 54;
            this.lblCostoBonNueDesc.Text = "1";
            // 
            // lblCostoBonNue
            // 
            this.lblCostoBonNue.AutoSize = true;
            this.lblCostoBonNue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoBonNue.Location = new System.Drawing.Point(183, 62);
            this.lblCostoBonNue.Name = "lblCostoBonNue";
            this.lblCostoBonNue.Size = new System.Drawing.Size(130, 13);
            this.lblCostoBonNue.TabIndex = 53;
            this.lblCostoBonNue.Text = "Costo bonificación nuevo:";
            // 
            // lblCostoBonActDesc
            // 
            this.lblCostoBonActDesc.AutoSize = true;
            this.lblCostoBonActDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoBonActDesc.Location = new System.Drawing.Point(110, 86);
            this.lblCostoBonActDesc.Name = "lblCostoBonActDesc";
            this.lblCostoBonActDesc.Size = new System.Drawing.Size(13, 13);
            this.lblCostoBonActDesc.TabIndex = 52;
            this.lblCostoBonActDesc.Text = "1";
            // 
            // lblCostoBonAct
            // 
            this.lblCostoBonAct.AutoSize = true;
            this.lblCostoBonAct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoBonAct.Location = new System.Drawing.Point(6, 86);
            this.lblCostoBonAct.Name = "lblCostoBonAct";
            this.lblCostoBonAct.Size = new System.Drawing.Size(98, 13);
            this.lblCostoBonAct.TabIndex = 51;
            this.lblCostoBonAct.Text = "Costo Bonificación:";
            // 
            // lblCostoTotDesc
            // 
            this.lblCostoTotDesc.AutoSize = true;
            this.lblCostoTotDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoTotDesc.Location = new System.Drawing.Point(110, 62);
            this.lblCostoTotDesc.Name = "lblCostoTotDesc";
            this.lblCostoTotDesc.Size = new System.Drawing.Size(13, 13);
            this.lblCostoTotDesc.TabIndex = 50;
            this.lblCostoTotDesc.Text = "1";
            // 
            // lblCostoActDesc
            // 
            this.lblCostoActDesc.AutoSize = true;
            this.lblCostoActDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoActDesc.Location = new System.Drawing.Point(110, 38);
            this.lblCostoActDesc.Name = "lblCostoActDesc";
            this.lblCostoActDesc.Size = new System.Drawing.Size(13, 13);
            this.lblCostoActDesc.TabIndex = 49;
            this.lblCostoActDesc.Text = "1";
            // 
            // lblCostoTot
            // 
            this.lblCostoTot.AutoSize = true;
            this.lblCostoTot.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoTot.Location = new System.Drawing.Point(6, 62);
            this.lblCostoTot.Name = "lblCostoTot";
            this.lblCostoTot.Size = new System.Drawing.Size(60, 13);
            this.lblCostoTot.TabIndex = 48;
            this.lblCostoTot.Text = "Costo total:";
            // 
            // lblCostoAct
            // 
            this.lblCostoAct.AutoSize = true;
            this.lblCostoAct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoAct.Location = new System.Drawing.Point(6, 38);
            this.lblCostoAct.Name = "lblCostoAct";
            this.lblCostoAct.Size = new System.Drawing.Size(69, 13);
            this.lblCostoAct.TabIndex = 47;
            this.lblCostoAct.Text = "Costo actual:";
            // 
            // lblOnHandDesc
            // 
            this.lblOnHandDesc.AutoSize = true;
            this.lblOnHandDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOnHandDesc.Location = new System.Drawing.Point(110, 14);
            this.lblOnHandDesc.Name = "lblOnHandDesc";
            this.lblOnHandDesc.Size = new System.Drawing.Size(13, 13);
            this.lblOnHandDesc.TabIndex = 46;
            this.lblOnHandDesc.Text = "1";
            // 
            // lblOnHand
            // 
            this.lblOnHand.AutoSize = true;
            this.lblOnHand.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOnHand.Location = new System.Drawing.Point(6, 14);
            this.lblOnHand.Name = "lblOnHand";
            this.lblOnHand.Size = new System.Drawing.Size(53, 13);
            this.lblOnHand.TabIndex = 45;
            this.lblOnHand.Text = "On Hand:";
            // 
            // lblcaltificacion
            // 
            this.lblcaltificacion.AutoSize = true;
            this.lblcaltificacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcaltificacion.Location = new System.Drawing.Point(110, 110);
            this.lblcaltificacion.Name = "lblcaltificacion";
            this.lblcaltificacion.Size = new System.Drawing.Size(31, 13);
            this.lblcaltificacion.TabIndex = 44;
            this.lblcaltificacion.Text = "9999";
            // 
            // tbCalNueva
            // 
            this.tbCalNueva.Location = new System.Drawing.Point(123, 131);
            this.tbCalNueva.MaxLength = 5;
            this.tbCalNueva.Name = "tbCalNueva";
            this.tbCalNueva.Size = new System.Drawing.Size(81, 20);
            this.tbCalNueva.TabIndex = 36;
            this.tbCalNueva.TextChanged += new System.EventHandler(this.tbCalNueva_TextChanged);
            this.tbCalNueva.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCalNueva_KeyPress);
            // 
            // btAceptar
            // 
            this.btAceptar.Location = new System.Drawing.Point(301, 355);
            this.btAceptar.Name = "btAceptar";
            this.btAceptar.Size = new System.Drawing.Size(75, 23);
            this.btAceptar.TabIndex = 39;
            this.btAceptar.Text = "Aceptar";
            this.btAceptar.UseVisualStyleBackColor = true;
            this.btAceptar.Click += new System.EventHandler(this.btAceptar_Click);
            // 
            // btCancelar
            // 
            this.btCancelar.Location = new System.Drawing.Point(382, 355);
            this.btCancelar.Name = "btCancelar";
            this.btCancelar.Size = new System.Drawing.Size(75, 23);
            this.btCancelar.TabIndex = 38;
            this.btCancelar.Text = "Cancelar";
            this.btCancelar.UseVisualStyleBackColor = true;
            this.btCancelar.Click += new System.EventHandler(this.btCancelar_Click);
            // 
            // lblComprador
            // 
            this.lblComprador.AutoSize = true;
            this.lblComprador.Location = new System.Drawing.Point(16, 33);
            this.lblComprador.Name = "lblComprador";
            this.lblComprador.Size = new System.Drawing.Size(61, 13);
            this.lblComprador.TabIndex = 43;
            this.lblComprador.Text = "Comprador:";
            // 
            // lblNumReprog
            // 
            this.lblNumReprog.AutoSize = true;
            this.lblNumReprog.Location = new System.Drawing.Point(362, 9);
            this.lblNumReprog.Name = "lblNumReprog";
            this.lblNumReprog.Size = new System.Drawing.Size(49, 13);
            this.lblNumReprog.TabIndex = 36;
            this.lblNumReprog.Text = "Eventos:";
            // 
            // lblEstilo
            // 
            this.lblEstilo.AutoSize = true;
            this.lblEstilo.Location = new System.Drawing.Point(16, 81);
            this.lblEstilo.Name = "lblEstilo";
            this.lblEstilo.Size = new System.Drawing.Size(35, 13);
            this.lblEstilo.TabIndex = 32;
            this.lblEstilo.Text = "Estilo:";
            // 
            // lblProveedor
            // 
            this.lblProveedor.AutoSize = true;
            this.lblProveedor.Location = new System.Drawing.Point(16, 57);
            this.lblProveedor.Name = "lblProveedor";
            this.lblProveedor.Size = new System.Drawing.Size(59, 13);
            this.lblProveedor.TabIndex = 29;
            this.lblProveedor.Text = "Proveedor:";
            // 
            // lblDescProveedor
            // 
            this.lblDescProveedor.AutoSize = true;
            this.lblDescProveedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescProveedor.Location = new System.Drawing.Point(81, 59);
            this.lblDescProveedor.Name = "lblDescProveedor";
            this.lblDescProveedor.Size = new System.Drawing.Size(17, 13);
            this.lblDescProveedor.TabIndex = 46;
            this.lblDescProveedor.Text = "id";
            // 
            // lblNombreProv
            // 
            this.lblNombreProv.AutoSize = true;
            this.lblNombreProv.Location = new System.Drawing.Point(133, 57);
            this.lblNombreProv.Name = "lblNombreProv";
            this.lblNombreProv.Size = new System.Drawing.Size(70, 13);
            this.lblNombreProv.TabIndex = 47;
            this.lblNombreProv.Text = "nombreProve";
            // 
            // lblidEstilo
            // 
            this.lblidEstilo.AutoSize = true;
            this.lblidEstilo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblidEstilo.Location = new System.Drawing.Point(81, 83);
            this.lblidEstilo.Name = "lblidEstilo";
            this.lblidEstilo.Size = new System.Drawing.Size(17, 13);
            this.lblidEstilo.TabIndex = 48;
            this.lblidEstilo.Text = "id";
            // 
            // lblDescEstilo
            // 
            this.lblDescEstilo.AutoSize = true;
            this.lblDescEstilo.Location = new System.Drawing.Point(133, 83);
            this.lblDescEstilo.Name = "lblDescEstilo";
            this.lblDescEstilo.Size = new System.Drawing.Size(55, 13);
            this.lblDescEstilo.TabIndex = 49;
            this.lblDescEstilo.Text = "descEstilo";
            // 
            // lblCompradorDesc
            // 
            this.lblCompradorDesc.AutoSize = true;
            this.lblCompradorDesc.Location = new System.Drawing.Point(81, 33);
            this.lblCompradorDesc.Name = "lblCompradorDesc";
            this.lblCompradorDesc.Size = new System.Drawing.Size(27, 13);
            this.lblCompradorDesc.TabIndex = 50;
            this.lblCompradorDesc.Text = "com";
            // 
            // lblNumProg
            // 
            this.lblNumProg.AutoSize = true;
            this.lblNumProg.Location = new System.Drawing.Point(417, 9);
            this.lblNumProg.Name = "lblNumProg";
            this.lblNumProg.Size = new System.Drawing.Size(27, 13);
            this.lblNumProg.TabIndex = 51;
            this.lblNumProg.Text = "num";
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = true;
            this.lblMarca.Location = new System.Drawing.Point(16, 9);
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.Size = new System.Drawing.Size(40, 13);
            this.lblMarca.TabIndex = 52;
            this.lblMarca.Text = "Marca:";
            // 
            // lblDescMarca
            // 
            this.lblDescMarca.AutoSize = true;
            this.lblDescMarca.Location = new System.Drawing.Point(81, 9);
            this.lblDescMarca.Name = "lblDescMarca";
            this.lblDescMarca.Size = new System.Drawing.Size(21, 13);
            this.lblDescMarca.TabIndex = 53;
            this.lblDescMarca.Text = "ma";
            // 
            // lblOC
            // 
            this.lblOC.AutoSize = true;
            this.lblOC.Location = new System.Drawing.Point(180, 9);
            this.lblOC.Name = "lblOC";
            this.lblOC.Size = new System.Drawing.Size(78, 13);
            this.lblOC.TabIndex = 54;
            this.lblOC.Text = "Orden Compra:";
            // 
            // lblOCDesc
            // 
            this.lblOCDesc.AutoSize = true;
            this.lblOCDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOCDesc.Location = new System.Drawing.Point(259, 9);
            this.lblOCDesc.Name = "lblOCDesc";
            this.lblOCDesc.Size = new System.Drawing.Size(25, 13);
            this.lblOCDesc.TabIndex = 55;
            this.lblOCDesc.Text = "orc";
            // 
            // lblTem
            // 
            this.lblTem.AutoSize = true;
            this.lblTem.Location = new System.Drawing.Point(16, 105);
            this.lblTem.Name = "lblTem";
            this.lblTem.Size = new System.Drawing.Size(64, 13);
            this.lblTem.TabIndex = 56;
            this.lblTem.Text = "Temporada:";
            // 
            // lblTemporada
            // 
            this.lblTemporada.AutoSize = true;
            this.lblTemporada.Location = new System.Drawing.Point(79, 105);
            this.lblTemporada.Name = "lblTemporada";
            this.lblTemporada.Size = new System.Drawing.Size(24, 13);
            this.lblTemporada.TabIndex = 57;
            this.lblTemporada.Text = "tem";
            // 
            // SolCamCalificacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 385);
            this.Controls.Add(this.lblMotivo);
            this.Controls.Add(this.cboMotivo);
            this.Controls.Add(this.lblTemporada);
            this.Controls.Add(this.lblTem);
            this.Controls.Add(this.lblOCDesc);
            this.Controls.Add(this.lblOC);
            this.Controls.Add(this.lblDescMarca);
            this.Controls.Add(this.lblMarca);
            this.Controls.Add(this.lblNumProg);
            this.Controls.Add(this.lblCompradorDesc);
            this.Controls.Add(this.lblDescEstilo);
            this.Controls.Add(this.lblidEstilo);
            this.Controls.Add(this.lblNombreProv);
            this.Controls.Add(this.lblDescProveedor);
            this.Controls.Add(this.btAceptar);
            this.Controls.Add(this.btCancelar);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblComprador);
            this.Controls.Add(this.lblNumReprog);
            this.Controls.Add(this.lblEstilo);
            this.Controls.Add(this.lblProveedor);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SolCamCalificacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cambio de Calificación";
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            this.Load += new System.EventHandler(this.SolCamCalificacion_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblMensage;
        private System.Windows.Forms.Label lblPorNueva;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tbCalNueva;
        private System.Windows.Forms.Label lblComprador;
        private System.Windows.Forms.Button btAceptar;
        private System.Windows.Forms.Button btCancelar;
        private System.Windows.Forms.Label lblNumReprog;
        private System.Windows.Forms.Label lblEstilo;
        private System.Windows.Forms.Label lblProveedor;
        private System.Windows.Forms.Label lblDescProveedor;
        private System.Windows.Forms.Label lblNombreProv;
        private System.Windows.Forms.Label lblidEstilo;
        private System.Windows.Forms.Label lblDescEstilo;
        private System.Windows.Forms.Label lblcaltificacion;
        private System.Windows.Forms.Label lblCompradorDesc;
        private System.Windows.Forms.Label lblNumProg;
        private System.Windows.Forms.Label lblOnHandDesc;
        private System.Windows.Forms.Label lblOnHand;
        private System.Windows.Forms.Label lblCostoBonNueDesc;
        private System.Windows.Forms.Label lblCostoBonNue;
        private System.Windows.Forms.Label lblCostoBonActDesc;
        private System.Windows.Forms.Label lblCostoBonAct;
        private System.Windows.Forms.Label lblCostoTotDesc;
        private System.Windows.Forms.Label lblCostoActDesc;
        private System.Windows.Forms.Label lblCostoTot;
        private System.Windows.Forms.Label lblCostoAct;
        private System.Windows.Forms.Label lblDifBonDesc;
        private System.Windows.Forms.Label lblDifBon;
        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.Label lblDescMarca;
        private System.Windows.Forms.Label lblOC;
        private System.Windows.Forms.Label lblOCDesc;
        private System.Windows.Forms.Label lblTem;
        private System.Windows.Forms.Label lblTemporada;
        private System.Windows.Forms.CheckBox cbPagar;
        private System.Windows.Forms.Label lblPagado;
        private System.Windows.Forms.ComboBox cboMotivo;
        private System.Windows.Forms.Label lblMotivo;
    }
}