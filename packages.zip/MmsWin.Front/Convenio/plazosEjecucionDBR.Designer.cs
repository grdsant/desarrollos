﻿namespace MmsWin.Front.Convenio
{
    partial class plazosEjecucionDBR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tsToolStrip = new System.Windows.Forms.ToolStrip();
            this.pbExcel = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.gbMarca = new System.Windows.Forms.GroupBox();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.gbCompradores = new System.Windows.Forms.GroupBox();
            this.cbCompradores = new System.Windows.Forms.ComboBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbProveedor = new System.Windows.Forms.TextBox();
            this.btRelleno = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.gvPlazos = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tsToolStrip.SuspendLayout();
            this.gbMarca.SuspendLayout();
            this.gbCompradores.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvPlazos)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.button1);
            this.splitContainer1.Panel1.Controls.Add(this.btRelleno);
            this.splitContainer1.Panel1.Controls.Add(this.tbDescripcion);
            this.splitContainer1.Panel1.Controls.Add(this.tbEstilo);
            this.splitContainer1.Panel1.Controls.Add(this.tbNombre);
            this.splitContainer1.Panel1.Controls.Add(this.tbProveedor);
            this.splitContainer1.Panel1.Controls.Add(this.gbMarca);
            this.splitContainer1.Panel1.Controls.Add(this.gbCompradores);
            this.splitContainer1.Panel1.Controls.Add(this.tsToolStrip);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.gvPlazos);
            this.splitContainer1.Size = new System.Drawing.Size(876, 516);
            this.splitContainer1.SplitterDistance = 113;
            this.splitContainer1.TabIndex = 0;
            // 
            // tsToolStrip
            // 
            this.tsToolStrip.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.tsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pbExcel,
            this.toolStripSeparator1});
            this.tsToolStrip.Location = new System.Drawing.Point(0, 0);
            this.tsToolStrip.Name = "tsToolStrip";
            this.tsToolStrip.Size = new System.Drawing.Size(876, 39);
            this.tsToolStrip.TabIndex = 40;
            this.tsToolStrip.Text = "toolStrip1";
            // 
            // pbExcel
            // 
            this.pbExcel.AutoSize = false;
            this.pbExcel.Image = global::MmsWin.Front.Properties.Resources.excel_32x32;
            this.pbExcel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pbExcel.Name = "pbExcel";
            this.pbExcel.Size = new System.Drawing.Size(100, 36);
            this.pbExcel.Text = "Exportar";
            this.pbExcel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.pbExcel.ToolTipText = "Exportar los datos a Excel";
            this.pbExcel.Click += new System.EventHandler(this.pbExcel_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // gbMarca
            // 
            this.gbMarca.Controls.Add(this.cbMarca);
            this.gbMarca.Location = new System.Drawing.Point(3, 41);
            this.gbMarca.Name = "gbMarca";
            this.gbMarca.Size = new System.Drawing.Size(104, 47);
            this.gbMarca.TabIndex = 41;
            this.gbMarca.TabStop = false;
            this.gbMarca.Text = "Marca";
            // 
            // cbMarca
            // 
            this.cbMarca.FormattingEnabled = true;
            this.cbMarca.Location = new System.Drawing.Point(5, 19);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(93, 21);
            this.cbMarca.TabIndex = 11;
            this.cbMarca.SelectedValueChanged += new System.EventHandler(this.cbMarca_SelectedValueChanged);
            // 
            // gbCompradores
            // 
            this.gbCompradores.Controls.Add(this.cbCompradores);
            this.gbCompradores.Location = new System.Drawing.Point(113, 41);
            this.gbCompradores.Name = "gbCompradores";
            this.gbCompradores.Size = new System.Drawing.Size(140, 47);
            this.gbCompradores.TabIndex = 42;
            this.gbCompradores.TabStop = false;
            this.gbCompradores.Text = "Comprador";
            // 
            // cbCompradores
            // 
            this.cbCompradores.FormattingEnabled = true;
            this.cbCompradores.Location = new System.Drawing.Point(5, 19);
            this.cbCompradores.Name = "cbCompradores";
            this.cbCompradores.Size = new System.Drawing.Size(128, 21);
            this.cbCompradores.TabIndex = 4;
            this.cbCompradores.SelectedValueChanged += new System.EventHandler(this.cbCompradores_SelectedValueChanged);
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDescripcion.Location = new System.Drawing.Point(402, 92);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(210, 20);
            this.tbDescripcion.TabIndex = 47;
            this.tbDescripcion.TextChanged += new System.EventHandler(this.tbDescripcion_TextChanged);
            // 
            // tbEstilo
            // 
            this.tbEstilo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbEstilo.Location = new System.Drawing.Point(334, 92);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(68, 20);
            this.tbEstilo.TabIndex = 46;
            this.tbEstilo.TextChanged += new System.EventHandler(this.tbEstilo_TextChanged);
            // 
            // tbNombre
            // 
            this.tbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNombre.Location = new System.Drawing.Point(110, 92);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(224, 20);
            this.tbNombre.TabIndex = 45;
            this.tbNombre.TextChanged += new System.EventHandler(this.tbNombre_TextChanged);
            // 
            // tbProveedor
            // 
            this.tbProveedor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbProveedor.Location = new System.Drawing.Point(42, 92);
            this.tbProveedor.Name = "tbProveedor";
            this.tbProveedor.Size = new System.Drawing.Size(68, 20);
            this.tbProveedor.TabIndex = 44;
            this.tbProveedor.TextChanged += new System.EventHandler(this.tbProveedor_TextChanged);
            // 
            // btRelleno
            // 
            this.btRelleno.Location = new System.Drawing.Point(0, 91);
            this.btRelleno.Name = "btRelleno";
            this.btRelleno.Size = new System.Drawing.Size(42, 22);
            this.btRelleno.TabIndex = 48;
            this.btRelleno.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(612, 91);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(264, 22);
            this.button1.TabIndex = 49;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // gvPlazos
            // 
            this.gvPlazos.AllowUserToAddRows = false;
            this.gvPlazos.AllowUserToDeleteRows = false;
            this.gvPlazos.AllowUserToOrderColumns = true;
            this.gvPlazos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvPlazos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gvPlazos.Location = new System.Drawing.Point(0, 0);
            this.gvPlazos.Name = "gvPlazos";
            this.gvPlazos.ReadOnly = true;
            this.gvPlazos.Size = new System.Drawing.Size(876, 399);
            this.gvPlazos.TabIndex = 1;
            // 
            // plazosEjecucionDBR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(876, 516);
            this.Controls.Add(this.splitContainer1);
            this.Name = "plazosEjecucionDBR";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Plazos de ejecución de devoluciones, bonificaciones y rebajas.";
            this.Load += new System.EventHandler(this.plazosEjecucionDBR_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tsToolStrip.ResumeLayout(false);
            this.tsToolStrip.PerformLayout();
            this.gbMarca.ResumeLayout(false);
            this.gbCompradores.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gvPlazos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ToolStrip tsToolStrip;
        private System.Windows.Forms.ToolStripButton pbExcel;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.GroupBox gbMarca;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.GroupBox gbCompradores;
        private System.Windows.Forms.ComboBox cbCompradores;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.TextBox tbProveedor;
        private System.Windows.Forms.Button btRelleno;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView gvPlazos;


    }
}