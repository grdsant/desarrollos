﻿namespace MmsWin.Front.Convenio
{
    partial class FillRate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FillRate));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.gpbEstilosDisponibles = new System.Windows.Forms.GroupBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.lblTot1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblPeriodo = new System.Windows.Forms.ToolStripStatusLabel();
            this.tspGeneracionFormatos = new System.Windows.Forms.ToolStrip();
            this.lblFolio = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.lblBuscarOc = new System.Windows.Forms.ToolStripLabel();
            this.txtBuscarOc = new System.Windows.Forms.ToolStripTextBox();
            this.btnBuscarOc = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.cboOrigen = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.btnMarcarTodas = new System.Windows.Forms.ToolStripButton();
            this.btnAgregar = new System.Windows.Forms.ToolStripButton();
            this.dgvEstilosPreautorizados = new System.Windows.Forms.DataGridView();
            this.gpbEstilosSeleccionados = new System.Windows.Forms.GroupBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbEliminarTodos = new System.Windows.Forms.ToolStripButton();
            this.btnGenerarFormato = new System.Windows.Forms.ToolStripButton();
            this.dgvOCSeleccionadas = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.tspConsultaAutorizadas = new System.Windows.Forms.ToolStrip();
            this.lblBuscar = new System.Windows.Forms.ToolStripLabel();
            this.txtBuscar = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.cboEstatus = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.btnImprimir = new System.Windows.Forms.ToolStripButton();
            this.lsvFolios = new System.Windows.Forms.ListView();
            this.imlFolios = new System.Windows.Forms.ImageList(this.components);
            this.pnlActualizar = new System.Windows.Forms.Panel();
            this.txtNuevoMonto = new System.Windows.Forms.TextBox();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.lblMotivo = new System.Windows.Forms.Label();
            this.cboMotivo = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblOrdenCompra = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tspAutorizadas = new System.Windows.Forms.ToolStrip();
            this.btnMarcarDetalle = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.btnLiberar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.btnAutorizar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.lblFillRate6M = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.lblSolicitadas = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.lblRecibidas = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.lblImporte = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.lblFillRate = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.lblPenalizacion = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.lblMonto = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.lblMonto2 = new System.Windows.Forms.ToolStripLabel();
            this.btnNuevoMonto = new System.Windows.Forms.ToolStripButton();
            this.dgvDetalleFolios = new System.Windows.Forms.DataGridView();
            this.ofdAdjuntar = new System.Windows.Forms.OpenFileDialog();
            this.dgvProveedores = new System.Windows.Forms.DataGridView();
            this.lblMensaje = new System.Windows.Forms.ToolStripLabel();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.gpbEstilosDisponibles.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.tspGeneracionFormatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstilosPreautorizados)).BeginInit();
            this.gpbEstilosSeleccionados.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOCSeleccionadas)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            this.tspConsultaAutorizadas.SuspendLayout();
            this.pnlActualizar.SuspendLayout();
            this.tspAutorizadas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalleFolios)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProveedores)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1201, 440);
            this.tabControl1.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.splitContainer1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1193, 414);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Generación formatos";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.gpbEstilosDisponibles);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.gpbEstilosSeleccionados);
            this.splitContainer1.Size = new System.Drawing.Size(1187, 408);
            this.splitContainer1.SplitterDistance = 1039;
            this.splitContainer1.TabIndex = 1;
            // 
            // gpbEstilosDisponibles
            // 
            this.gpbEstilosDisponibles.Controls.Add(this.dgvProveedores);
            this.gpbEstilosDisponibles.Controls.Add(this.statusStrip1);
            this.gpbEstilosDisponibles.Controls.Add(this.tspGeneracionFormatos);
            this.gpbEstilosDisponibles.Controls.Add(this.dgvEstilosPreautorizados);
            this.gpbEstilosDisponibles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gpbEstilosDisponibles.Location = new System.Drawing.Point(0, 0);
            this.gpbEstilosDisponibles.Name = "gpbEstilosDisponibles";
            this.gpbEstilosDisponibles.Size = new System.Drawing.Size(1039, 408);
            this.gpbEstilosDisponibles.TabIndex = 1;
            this.gpbEstilosDisponibles.TabStop = false;
            this.gpbEstilosDisponibles.Text = "Ordenes de Compra para pago Fill Rate";
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblTot1,
            this.lblPeriodo});
            this.statusStrip1.Location = new System.Drawing.Point(3, 383);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1033, 22);
            this.statusStrip1.TabIndex = 3;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // lblTot1
            // 
            this.lblTot1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblTot1.Name = "lblTot1";
            this.lblTot1.Size = new System.Drawing.Size(118, 17);
            this.lblTot1.Text = "toolStripStatusLabel1";
            // 
            // lblPeriodo
            // 
            this.lblPeriodo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblPeriodo.ForeColor = System.Drawing.Color.Black;
            this.lblPeriodo.Name = "lblPeriodo";
            this.lblPeriodo.Size = new System.Drawing.Size(118, 17);
            this.lblPeriodo.Text = "toolStripStatusLabel2";
            // 
            // tspGeneracionFormatos
            // 
            this.tspGeneracionFormatos.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblFolio,
            this.toolStripSeparator1,
            this.lblBuscarOc,
            this.txtBuscarOc,
            this.btnBuscarOc,
            this.toolStripSeparator2,
            this.toolStripLabel1,
            this.cboOrigen,
            this.toolStripSeparator5,
            this.btnMarcarTodas,
            this.btnAgregar,
            this.lblMensaje});
            this.tspGeneracionFormatos.Location = new System.Drawing.Point(3, 16);
            this.tspGeneracionFormatos.Name = "tspGeneracionFormatos";
            this.tspGeneracionFormatos.Size = new System.Drawing.Size(1033, 25);
            this.tspGeneracionFormatos.TabIndex = 2;
            this.tspGeneracionFormatos.Text = "toolStrip1";
            // 
            // lblFolio
            // 
            this.lblFolio.AutoSize = false;
            this.lblFolio.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblFolio.ForeColor = System.Drawing.Color.Maroon;
            this.lblFolio.Name = "lblFolio";
            this.lblFolio.Size = new System.Drawing.Size(80, 22);
            this.lblFolio.Text = "Folio: 1698";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // lblBuscarOc
            // 
            this.lblBuscarOc.Name = "lblBuscarOc";
            this.lblBuscarOc.Size = new System.Drawing.Size(45, 22);
            this.lblBuscarOc.Text = "Buscar:";
            // 
            // txtBuscarOc
            // 
            this.txtBuscarOc.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtBuscarOc.Name = "txtBuscarOc";
            this.txtBuscarOc.Size = new System.Drawing.Size(100, 25);
            this.txtBuscarOc.TextChanged += new System.EventHandler(this.txtBuscarOc_TextChanged);
            // 
            // btnBuscarOc
            // 
            this.btnBuscarOc.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnBuscarOc.Image = global::MmsWin.Front.Properties.Resources.Find_VS;
            this.btnBuscarOc.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnBuscarOc.Name = "btnBuscarOc";
            this.btnBuscarOc.Size = new System.Drawing.Size(23, 22);
            this.btnBuscarOc.Text = "toolStripButton2";
            this.btnBuscarOc.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(46, 22);
            this.toolStripLabel1.Text = "Origen:";
            // 
            // cboOrigen
            // 
            this.cboOrigen.AutoSize = false;
            this.cboOrigen.BackColor = System.Drawing.Color.Gainsboro;
            this.cboOrigen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboOrigen.ForeColor = System.Drawing.Color.DarkRed;
            this.cboOrigen.Items.AddRange(new object[] {
            "Nacional",
            "Importación"});
            this.cboOrigen.Name = "cboOrigen";
            this.cboOrigen.Size = new System.Drawing.Size(100, 23);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // btnMarcarTodas
            // 
            this.btnMarcarTodas.AutoSize = false;
            this.btnMarcarTodas.Image = global::MmsWin.Front.Properties.Resources.CheckBoxHS;
            this.btnMarcarTodas.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnMarcarTodas.Name = "btnMarcarTodas";
            this.btnMarcarTodas.Size = new System.Drawing.Size(100, 22);
            this.btnMarcarTodas.Text = "Marcar todas";
            this.btnMarcarTodas.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // btnAgregar
            // 
            this.btnAgregar.Image = global::MmsWin.Front.Properties.Resources._112_RightArrowShort_Blue_16x16_72;
            this.btnAgregar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(69, 22);
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAgregar.ToolTipText = "Agregar a formato";
            this.btnAgregar.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // dgvEstilosPreautorizados
            // 
            this.dgvEstilosPreautorizados.AllowUserToAddRows = false;
            this.dgvEstilosPreautorizados.AllowUserToDeleteRows = false;
            this.dgvEstilosPreautorizados.AllowUserToOrderColumns = true;
            this.dgvEstilosPreautorizados.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvEstilosPreautorizados.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvEstilosPreautorizados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEstilosPreautorizados.GridColor = System.Drawing.Color.Gainsboro;
            this.dgvEstilosPreautorizados.Location = new System.Drawing.Point(361, 47);
            this.dgvEstilosPreautorizados.MultiSelect = false;
            this.dgvEstilosPreautorizados.Name = "dgvEstilosPreautorizados";
            this.dgvEstilosPreautorizados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEstilosPreautorizados.Size = new System.Drawing.Size(672, 333);
            this.dgvEstilosPreautorizados.TabIndex = 1;
            // 
            // gpbEstilosSeleccionados
            // 
            this.gpbEstilosSeleccionados.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gpbEstilosSeleccionados.Controls.Add(this.toolStrip1);
            this.gpbEstilosSeleccionados.Controls.Add(this.dgvOCSeleccionadas);
            this.gpbEstilosSeleccionados.Location = new System.Drawing.Point(3, 3);
            this.gpbEstilosSeleccionados.Name = "gpbEstilosSeleccionados";
            this.gpbEstilosSeleccionados.Size = new System.Drawing.Size(160, 399);
            this.gpbEstilosSeleccionados.TabIndex = 1;
            this.gpbEstilosSeleccionados.TabStop = false;
            this.gpbEstilosSeleccionados.Text = "Ordenes de Compra seleccionadas";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbEliminarTodos,
            this.btnGenerarFormato});
            this.toolStrip1.Location = new System.Drawing.Point(3, 16);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(154, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbEliminarTodos
            // 
            this.tsbEliminarTodos.Image = global::MmsWin.Front.Properties.Resources._109_AllAnnotations_Error_16x16_72;
            this.tsbEliminarTodos.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbEliminarTodos.Name = "tsbEliminarTodos";
            this.tsbEliminarTodos.Size = new System.Drawing.Size(23, 22);
            this.tsbEliminarTodos.ToolTipText = "Eliminar";
            this.tsbEliminarTodos.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // btnGenerarFormato
            // 
            this.btnGenerarFormato.Image = global::MmsWin.Front.Properties.Resources._077_AddFile_16x16_72;
            this.btnGenerarFormato.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnGenerarFormato.Name = "btnGenerarFormato";
            this.btnGenerarFormato.Size = new System.Drawing.Size(23, 22);
            this.btnGenerarFormato.ToolTipText = "Generar Formato";
            this.btnGenerarFormato.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // dgvOCSeleccionadas
            // 
            this.dgvOCSeleccionadas.AllowUserToAddRows = false;
            this.dgvOCSeleccionadas.AllowUserToOrderColumns = true;
            this.dgvOCSeleccionadas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvOCSeleccionadas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOCSeleccionadas.Location = new System.Drawing.Point(3, 44);
            this.dgvOCSeleccionadas.Name = "dgvOCSeleccionadas";
            this.dgvOCSeleccionadas.ReadOnly = true;
            this.dgvOCSeleccionadas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvOCSeleccionadas.Size = new System.Drawing.Size(154, 352);
            this.dgvOCSeleccionadas.TabIndex = 1;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.splitContainer3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1193, 414);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Autorizaciones";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // splitContainer3
            // 
            this.splitContainer3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer3.CausesValidation = false;
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.tspConsultaAutorizadas);
            this.splitContainer3.Panel1.Controls.Add(this.lsvFolios);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.pnlActualizar);
            this.splitContainer3.Panel2.Controls.Add(this.tspAutorizadas);
            this.splitContainer3.Panel2.Controls.Add(this.dgvDetalleFolios);
            this.splitContainer3.Size = new System.Drawing.Size(1193, 414);
            this.splitContainer3.SplitterDistance = 151;
            this.splitContainer3.TabIndex = 3;
            // 
            // tspConsultaAutorizadas
            // 
            this.tspConsultaAutorizadas.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lblBuscar,
            this.txtBuscar,
            this.toolStripButton1,
            this.toolStripSeparator4,
            this.toolStripLabel2,
            this.cboEstatus,
            this.toolStripSeparator6,
            this.btnImprimir});
            this.tspConsultaAutorizadas.Location = new System.Drawing.Point(0, 0);
            this.tspConsultaAutorizadas.Name = "tspConsultaAutorizadas";
            this.tspConsultaAutorizadas.Size = new System.Drawing.Size(1189, 25);
            this.tspConsultaAutorizadas.TabIndex = 1;
            this.tspConsultaAutorizadas.Text = "toolStrip2";
            // 
            // lblBuscar
            // 
            this.lblBuscar.Name = "lblBuscar";
            this.lblBuscar.Size = new System.Drawing.Size(45, 22);
            this.lblBuscar.Text = "Buscar:";
            // 
            // txtBuscar
            // 
            this.txtBuscar.Name = "txtBuscar";
            this.txtBuscar.Size = new System.Drawing.Size(100, 25);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::MmsWin.Front.Properties.Resources.Find_VS;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton1.Text = "toolStripButton1";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(90, 22);
            this.toolStripLabel2.Text = "Ver por estatus: ";
            // 
            // cboEstatus
            // 
            this.cboEstatus.BackColor = System.Drawing.Color.Gainsboro;
            this.cboEstatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboEstatus.Items.AddRange(new object[] {
            "Pendientes",
            "Autorizadas"});
            this.cboEstatus.Name = "cboEstatus";
            this.cboEstatus.Size = new System.Drawing.Size(121, 25);
            this.cboEstatus.SelectedIndexChanged += new System.EventHandler(this.cboEstatus_SelectedIndexChanged);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // btnImprimir
            // 
            this.btnImprimir.Image = global::MmsWin.Front.Properties.Resources.PrintHS;
            this.btnImprimir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnImprimir.Name = "btnImprimir";
            this.btnImprimir.Size = new System.Drawing.Size(73, 22);
            this.btnImprimir.Text = "Imprimir";
            this.btnImprimir.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // lsvFolios
            // 
            this.lsvFolios.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lsvFolios.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lsvFolios.LargeImageList = this.imlFolios;
            this.lsvFolios.Location = new System.Drawing.Point(3, 28);
            this.lsvFolios.Name = "lsvFolios";
            this.lsvFolios.Size = new System.Drawing.Size(1183, 116);
            this.lsvFolios.SmallImageList = this.imlFolios;
            this.lsvFolios.TabIndex = 0;
            this.lsvFolios.UseCompatibleStateImageBehavior = false;
            this.lsvFolios.Click += new System.EventHandler(this.lsvFolios_DoubleClick);
            // 
            // imlFolios
            // 
            this.imlFolios.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imlFolios.ImageStream")));
            this.imlFolios.TransparentColor = System.Drawing.Color.Transparent;
            this.imlFolios.Images.SetKeyName(0, "folder_process.png");
            this.imlFolios.Images.SetKeyName(1, "Folder_32x32.png");
            this.imlFolios.Images.SetKeyName(2, "NewDocuments_32x32.png");
            this.imlFolios.Images.SetKeyName(3, "folder_autorizado.png");
            this.imlFolios.Images.SetKeyName(4, "IgnoreIssue_32x32.png");
            this.imlFolios.Images.SetKeyName(5, "112_Tick_Green_32x32_72.png");
            this.imlFolios.Images.SetKeyName(6, "folder_cancel.png");
            // 
            // pnlActualizar
            // 
            this.pnlActualizar.BackColor = System.Drawing.Color.Lavender;
            this.pnlActualizar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnlActualizar.Controls.Add(this.txtNuevoMonto);
            this.pnlActualizar.Controls.Add(this.btnCancelar);
            this.pnlActualizar.Controls.Add(this.btnAceptar);
            this.pnlActualizar.Controls.Add(this.lblMotivo);
            this.pnlActualizar.Controls.Add(this.cboMotivo);
            this.pnlActualizar.Controls.Add(this.label3);
            this.pnlActualizar.Controls.Add(this.lblOrdenCompra);
            this.pnlActualizar.Controls.Add(this.label1);
            this.pnlActualizar.Location = new System.Drawing.Point(477, 28);
            this.pnlActualizar.Name = "pnlActualizar";
            this.pnlActualizar.Size = new System.Drawing.Size(271, 93);
            this.pnlActualizar.TabIndex = 3;
            this.pnlActualizar.Visible = false;
            // 
            // txtNuevoMonto
            // 
            this.txtNuevoMonto.Location = new System.Drawing.Point(58, 7);
            this.txtNuevoMonto.Name = "txtNuevoMonto";
            this.txtNuevoMonto.Size = new System.Drawing.Size(200, 20);
            this.txtNuevoMonto.TabIndex = 16;
            // 
            // btnCancelar
            // 
            this.btnCancelar.Image = global::MmsWin.Front.Properties.Resources._109_AllAnnotations_Error_16x16_72;
            this.btnCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancelar.Location = new System.Drawing.Point(183, 60);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 25);
            this.btnCancelar.TabIndex = 15;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // btnAceptar
            // 
            this.btnAceptar.Image = global::MmsWin.Front.Properties.Resources._109_AllAnnotations_Complete_16x16_72;
            this.btnAceptar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAceptar.Location = new System.Drawing.Point(102, 60);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(75, 25);
            this.btnAceptar.TabIndex = 14;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // lblMotivo
            // 
            this.lblMotivo.AutoSize = true;
            this.lblMotivo.Location = new System.Drawing.Point(7, 41);
            this.lblMotivo.Name = "lblMotivo";
            this.lblMotivo.Size = new System.Drawing.Size(42, 13);
            this.lblMotivo.TabIndex = 13;
            this.lblMotivo.Text = "Motivo:";
            // 
            // cboMotivo
            // 
            this.cboMotivo.FormattingEnabled = true;
            this.cboMotivo.Location = new System.Drawing.Point(58, 33);
            this.cboMotivo.Name = "cboMotivo";
            this.cboMotivo.Size = new System.Drawing.Size(200, 21);
            this.cboMotivo.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(40, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Monto:";
            // 
            // lblOrdenCompra
            // 
            this.lblOrdenCompra.AutoSize = true;
            this.lblOrdenCompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrdenCompra.ForeColor = System.Drawing.Color.Maroon;
            this.lblOrdenCompra.Location = new System.Drawing.Point(33, 60);
            this.lblOrdenCompra.Name = "lblOrdenCompra";
            this.lblOrdenCompra.Size = new System.Drawing.Size(63, 15);
            this.lblOrdenCompra.TabIndex = 9;
            this.lblOrdenCompra.Text = "1234567";
            this.lblOrdenCompra.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Orden de compra:";
            this.label1.Visible = false;
            // 
            // tspAutorizadas
            // 
            this.tspAutorizadas.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnMarcarDetalle,
            this.toolStripSeparator10,
            this.btnLiberar,
            this.toolStripSeparator8,
            this.btnAutorizar,
            this.toolStripSeparator3,
            this.lblFillRate6M,
            this.toolStripSeparator15,
            this.lblSolicitadas,
            this.toolStripSeparator7,
            this.lblRecibidas,
            this.toolStripSeparator9,
            this.lblImporte,
            this.toolStripSeparator11,
            this.lblFillRate,
            this.toolStripSeparator12,
            this.lblPenalizacion,
            this.toolStripSeparator13,
            this.lblMonto,
            this.toolStripSeparator14,
            this.lblMonto2,
            this.btnNuevoMonto});
            this.tspAutorizadas.Location = new System.Drawing.Point(0, 0);
            this.tspAutorizadas.Name = "tspAutorizadas";
            this.tspAutorizadas.Size = new System.Drawing.Size(1189, 25);
            this.tspAutorizadas.TabIndex = 1;
            this.tspAutorizadas.Text = "Autorizar ";
            // 
            // btnMarcarDetalle
            // 
            this.btnMarcarDetalle.Image = global::MmsWin.Front.Properties.Resources.CheckBoxHS;
            this.btnMarcarDetalle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnMarcarDetalle.Name = "btnMarcarDetalle";
            this.btnMarcarDetalle.Size = new System.Drawing.Size(64, 22);
            this.btnMarcarDetalle.Text = "Marcar";
            this.btnMarcarDetalle.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 25);
            this.toolStripSeparator10.Visible = false;
            // 
            // btnLiberar
            // 
            this.btnLiberar.Image = global::MmsWin.Front.Properties.Resources.XSDSchema_AllIcon;
            this.btnLiberar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnLiberar.Name = "btnLiberar";
            this.btnLiberar.Size = new System.Drawing.Size(107, 22);
            this.btnLiberar.Text = "\"Des-autorizar\"";
            this.btnLiberar.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 25);
            this.toolStripSeparator8.Visible = false;
            // 
            // btnAutorizar
            // 
            this.btnAutorizar.Image = global::MmsWin.Front.Properties.Resources.PrimaryKeyHS;
            this.btnAutorizar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAutorizar.Name = "btnAutorizar";
            this.btnAutorizar.Size = new System.Drawing.Size(75, 22);
            this.btnAutorizar.Text = "Autorizar";
            this.btnAutorizar.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // lblFillRate6M
            // 
            this.lblFillRate6M.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblFillRate6M.ForeColor = System.Drawing.Color.Maroon;
            this.lblFillRate6M.Name = "lblFillRate6M";
            this.lblFillRate6M.Size = new System.Drawing.Size(66, 22);
            this.lblFillRate6M.Text = "FillRate6m";
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(6, 25);
            this.toolStripSeparator15.Visible = false;
            // 
            // lblSolicitadas
            // 
            this.lblSolicitadas.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblSolicitadas.Name = "lblSolicitadas";
            this.lblSolicitadas.Size = new System.Drawing.Size(65, 22);
            this.lblSolicitadas.Text = "Solicitadas";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 25);
            this.toolStripSeparator7.Visible = false;
            // 
            // lblRecibidas
            // 
            this.lblRecibidas.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblRecibidas.ForeColor = System.Drawing.Color.MediumBlue;
            this.lblRecibidas.Name = "lblRecibidas";
            this.lblRecibidas.Size = new System.Drawing.Size(59, 22);
            this.lblRecibidas.Text = "Recibidas";
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 25);
            // 
            // lblImporte
            // 
            this.lblImporte.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblImporte.ForeColor = System.Drawing.Color.Maroon;
            this.lblImporte.Name = "lblImporte";
            this.lblImporte.Size = new System.Drawing.Size(53, 22);
            this.lblImporte.Text = "Importe";
            this.lblImporte.Visible = false;
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(6, 25);
            this.toolStripSeparator11.Visible = false;
            // 
            // lblFillRate
            // 
            this.lblFillRate.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblFillRate.Name = "lblFillRate";
            this.lblFillRate.Size = new System.Drawing.Size(48, 22);
            this.lblFillRate.Text = "FillRate";
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(6, 25);
            this.toolStripSeparator12.Visible = false;
            // 
            // lblPenalizacion
            // 
            this.lblPenalizacion.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblPenalizacion.ForeColor = System.Drawing.Color.DarkRed;
            this.lblPenalizacion.Name = "lblPenalizacion";
            this.lblPenalizacion.Size = new System.Drawing.Size(75, 22);
            this.lblPenalizacion.Text = "Penalizacion";
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(6, 25);
            // 
            // lblMonto
            // 
            this.lblMonto.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblMonto.ForeColor = System.Drawing.Color.Red;
            this.lblMonto.Name = "lblMonto";
            this.lblMonto.Size = new System.Drawing.Size(44, 22);
            this.lblMonto.Text = "Monto";
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(6, 25);
            // 
            // lblMonto2
            // 
            this.lblMonto2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblMonto2.ForeColor = System.Drawing.Color.Green;
            this.lblMonto2.Name = "lblMonto2";
            this.lblMonto2.Size = new System.Drawing.Size(84, 22);
            this.lblMonto2.Text = "Nuevo Monto";
            // 
            // btnNuevoMonto
            // 
            this.btnNuevoMonto.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.btnNuevoMonto.Image = global::MmsWin.Front.Properties.Resources.CalculatorHS;
            this.btnNuevoMonto.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnNuevoMonto.Name = "btnNuevoMonto";
            this.btnNuevoMonto.Size = new System.Drawing.Size(23, 22);
            this.btnNuevoMonto.Text = "toolStripButton2";
            this.btnNuevoMonto.Click += new System.EventHandler(this.Buttons_Click);
            // 
            // dgvDetalleFolios
            // 
            this.dgvDetalleFolios.AllowUserToAddRows = false;
            this.dgvDetalleFolios.AllowUserToDeleteRows = false;
            this.dgvDetalleFolios.AllowUserToOrderColumns = true;
            this.dgvDetalleFolios.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDetalleFolios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDetalleFolios.Location = new System.Drawing.Point(0, 27);
            this.dgvDetalleFolios.MultiSelect = false;
            this.dgvDetalleFolios.Name = "dgvDetalleFolios";
            this.dgvDetalleFolios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDetalleFolios.Size = new System.Drawing.Size(1189, 230);
            this.dgvDetalleFolios.TabIndex = 0;
            this.dgvDetalleFolios.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDetalleFolios_CellDoubleClick);
            // 
            // ofdAdjuntar
            // 
            this.ofdAdjuntar.FileName = "*.*";
            // 
            // dgvProveedores
            // 
            this.dgvProveedores.AllowUserToAddRows = false;
            this.dgvProveedores.AllowUserToDeleteRows = false;
            this.dgvProveedores.AllowUserToOrderColumns = true;
            this.dgvProveedores.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dgvProveedores.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvProveedores.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.dgvProveedores.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProveedores.Location = new System.Drawing.Point(3, 47);
            this.dgvProveedores.MultiSelect = false;
            this.dgvProveedores.Name = "dgvProveedores";
            this.dgvProveedores.ReadOnly = true;
            this.dgvProveedores.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProveedores.Size = new System.Drawing.Size(352, 333);
            this.dgvProveedores.TabIndex = 4;
            this.dgvProveedores.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvProveedores_CellDoubleClick);
            // 
            // lblMensaje
            // 
            this.lblMensaje.ForeColor = System.Drawing.Color.MidnightBlue;
            this.lblMensaje.Name = "lblMensaje";
            this.lblMensaje.Size = new System.Drawing.Size(126, 22);
            this.lblMensaje.Text = "No aplica penalización";
            // 
            // FillRate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1201, 440);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FillRate";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Excepción cobro Fill Rate";
            this.Load += new System.EventHandler(this.Preautorizaciones_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.gpbEstilosDisponibles.ResumeLayout(false);
            this.gpbEstilosDisponibles.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.tspGeneracionFormatos.ResumeLayout(false);
            this.tspGeneracionFormatos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEstilosPreautorizados)).EndInit();
            this.gpbEstilosSeleccionados.ResumeLayout(false);
            this.gpbEstilosSeleccionados.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOCSeleccionadas)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.tspConsultaAutorizadas.ResumeLayout(false);
            this.tspConsultaAutorizadas.PerformLayout();
            this.pnlActualizar.ResumeLayout(false);
            this.pnlActualizar.PerformLayout();
            this.tspAutorizadas.ResumeLayout(false);
            this.tspAutorizadas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDetalleFolios)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProveedores)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ImageList imlFolios;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.ListView lsvFolios;
        private System.Windows.Forms.ToolStrip tspAutorizadas;
        private System.Windows.Forms.ToolStripButton btnMarcarDetalle;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripButton btnLiberar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripButton btnAutorizar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.DataGridView dgvDetalleFolios;
        private System.Windows.Forms.ToolStrip tspConsultaAutorizadas;
        private System.Windows.Forms.ToolStripLabel lblBuscar;
        private System.Windows.Forms.ToolStripTextBox txtBuscar;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton btnImprimir;
        private System.Windows.Forms.GroupBox gpbEstilosDisponibles;
        private System.Windows.Forms.DataGridView dgvEstilosPreautorizados;
        private System.Windows.Forms.GroupBox gpbEstilosSeleccionados;
        private System.Windows.Forms.DataGridView dgvOCSeleccionadas;
        private System.Windows.Forms.OpenFileDialog ofdAdjuntar;
        private System.Windows.Forms.ToolStrip tspGeneracionFormatos;
        private System.Windows.Forms.ToolStripLabel lblFolio;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripLabel lblBuscarOc;
        private System.Windows.Forms.ToolStripTextBox txtBuscarOc;
        private System.Windows.Forms.ToolStripButton btnBuscarOc;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton btnMarcarTodas;
        private System.Windows.Forms.ToolStripButton btnAgregar;
        private System.Windows.Forms.ToolStripComboBox cboOrigen;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripComboBox cboEstatus;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.Panel pnlActualizar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnAceptar;
        private System.Windows.Forms.Label lblMotivo;
        private System.Windows.Forms.ComboBox cboMotivo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblOrdenCompra;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNuevoMonto;
        private System.Windows.Forms.ToolStripLabel lblSolicitadas;
        private System.Windows.Forms.ToolStripLabel lblRecibidas;
        private System.Windows.Forms.ToolStripLabel lblImporte;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripLabel lblFillRate;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripLabel lblPenalizacion;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripLabel lblMonto;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.ToolStripLabel lblMonto2;
        private System.Windows.Forms.ToolStripButton btnNuevoMonto;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel lblTot1;
        private System.Windows.Forms.ToolStripStatusLabel lblPeriodo;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbEliminarTodos;
        private System.Windows.Forms.ToolStripButton btnGenerarFormato;
        private System.Windows.Forms.ToolStripLabel lblFillRate6M;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.DataGridView dgvProveedores;
        private System.Windows.Forms.ToolStripLabel lblMensaje;
    }
}