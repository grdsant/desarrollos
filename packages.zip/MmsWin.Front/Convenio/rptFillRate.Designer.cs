﻿namespace MmsWin.Front.Convenio
{
    partial class rptFillRate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.sAT177REFRBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsSAT177REFR = new MmsWin.Front.dsSAT177REFR();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.sAT177REFRTableAdapter = new MmsWin.Front.dsSAT177REFRTableAdapters.SAT177REFRTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.sAT177REFRBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSAT177REFR)).BeginInit();
            this.SuspendLayout();
            // 
            // sAT177REFRBindingSource
            // 
            this.sAT177REFRBindingSource.DataMember = "SAT177REFR";
            this.sAT177REFRBindingSource.DataSource = this.dsSAT177REFR;
            // 
            // dsSAT177REFR
            // 
            this.dsSAT177REFR.DataSetName = "dsSAT177REFR";
            this.dsSAT177REFR.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "cdSAT177REFR_2";
            reportDataSource1.Value = this.sAT177REFRBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "MmsWin.Front.Convenio.rptFillRate2.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ShowContextMenu = false;
            this.reportViewer1.ShowCredentialPrompts = false;
            this.reportViewer1.ShowExportButton = false;
            this.reportViewer1.ShowRefreshButton = false;
            this.reportViewer1.ShowStopButton = false;
            this.reportViewer1.Size = new System.Drawing.Size(871, 397);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.PageWidth;
            // 
            // sAT177REFRTableAdapter
            // 
            this.sAT177REFRTableAdapter.ClearBeforeFill = true;
            // 
            // rptFillRate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(871, 397);
            this.Controls.Add(this.reportViewer1);
            this.Name = "rptFillRate";
            this.Text = "rptFillRate";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.rptFillRate_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sAT177REFRBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSAT177REFR)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private dsSAT177REFR dsSAT177REFR;
        private System.Windows.Forms.BindingSource sAT177REFRBindingSource;
        private dsSAT177REFRTableAdapters.SAT177REFRTableAdapter sAT177REFRTableAdapter;


    }
}