﻿namespace MmsWin.Front.Convenio
{
    partial class AltaHdrRentabilidad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEstatus = new System.Windows.Forms.Label();
            this.lblUsuario = new System.Windows.Forms.Label();
            this.lblFechaFinal = new System.Windows.Forms.Label();
            this.lblFechaInicio = new System.Windows.Forms.Label();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.lblTabla = new System.Windows.Forms.Label();
            this.lblMarca = new System.Windows.Forms.Label();
            this.tbMarca = new System.Windows.Forms.TextBox();
            this.tbTabla = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbFechaInicial = new System.Windows.Forms.TextBox();
            this.tbFechaFinal = new System.Windows.Forms.TextBox();
            this.tbUsuario = new System.Windows.Forms.TextBox();
            this.tbEstatus = new System.Windows.Forms.TextBox();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btCancelar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.mcCal01 = new System.Windows.Forms.MonthCalendar();
            this.mcCal02 = new System.Windows.Forms.MonthCalendar();
            this.SuspendLayout();
            // 
            // lblEstatus
            // 
            this.lblEstatus.AutoSize = true;
            this.lblEstatus.Location = new System.Drawing.Point(35, 274);
            this.lblEstatus.Name = "lblEstatus";
            this.lblEstatus.Size = new System.Drawing.Size(42, 13);
            this.lblEstatus.TabIndex = 27;
            this.lblEstatus.Text = "Estatus";
            // 
            // lblUsuario
            // 
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.Location = new System.Drawing.Point(34, 238);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(43, 13);
            this.lblUsuario.TabIndex = 26;
            this.lblUsuario.Text = "Usuario";
            // 
            // lblFechaFinal
            // 
            this.lblFechaFinal.AutoSize = true;
            this.lblFechaFinal.Location = new System.Drawing.Point(34, 195);
            this.lblFechaFinal.Name = "lblFechaFinal";
            this.lblFechaFinal.Size = new System.Drawing.Size(62, 13);
            this.lblFechaFinal.TabIndex = 25;
            this.lblFechaFinal.Text = "Fecha Final";
            // 
            // lblFechaInicio
            // 
            this.lblFechaInicio.AutoSize = true;
            this.lblFechaInicio.Location = new System.Drawing.Point(35, 156);
            this.lblFechaInicio.Name = "lblFechaInicio";
            this.lblFechaInicio.Size = new System.Drawing.Size(67, 13);
            this.lblFechaInicio.TabIndex = 24;
            this.lblFechaInicio.Text = "Fecha Inicial";
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.AutoSize = true;
            this.lblDescripcion.Location = new System.Drawing.Point(34, 118);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(63, 13);
            this.lblDescripcion.TabIndex = 23;
            this.lblDescripcion.Text = "Descripcion";
            // 
            // lblTabla
            // 
            this.lblTabla.AutoSize = true;
            this.lblTabla.Location = new System.Drawing.Point(34, 75);
            this.lblTabla.Name = "lblTabla";
            this.lblTabla.Size = new System.Drawing.Size(34, 13);
            this.lblTabla.TabIndex = 22;
            this.lblTabla.Text = "Tabla";
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = true;
            this.lblMarca.Location = new System.Drawing.Point(34, 37);
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.Size = new System.Drawing.Size(37, 13);
            this.lblMarca.TabIndex = 21;
            this.lblMarca.Text = "Marca";
            // 
            // tbMarca
            // 
            this.tbMarca.Location = new System.Drawing.Point(131, 34);
            this.tbMarca.Name = "tbMarca";
            this.tbMarca.Size = new System.Drawing.Size(100, 20);
            this.tbMarca.TabIndex = 30;
            // 
            // tbTabla
            // 
            this.tbTabla.Location = new System.Drawing.Point(131, 72);
            this.tbTabla.Name = "tbTabla";
            this.tbTabla.Size = new System.Drawing.Size(100, 20);
            this.tbTabla.TabIndex = 31;
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.Location = new System.Drawing.Point(131, 111);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(206, 20);
            this.tbDescripcion.TabIndex = 32;
            // 
            // tbFechaInicial
            // 
            this.tbFechaInicial.Location = new System.Drawing.Point(131, 153);
            this.tbFechaInicial.Name = "tbFechaInicial";
            this.tbFechaInicial.Size = new System.Drawing.Size(100, 20);
            this.tbFechaInicial.TabIndex = 33;
            this.tbFechaInicial.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFechaInicial.Click += new System.EventHandler(this.tbFechaInicial_Click);
            // 
            // tbFechaFinal
            // 
            this.tbFechaFinal.Location = new System.Drawing.Point(131, 192);
            this.tbFechaFinal.Name = "tbFechaFinal";
            this.tbFechaFinal.Size = new System.Drawing.Size(100, 20);
            this.tbFechaFinal.TabIndex = 34;
            this.tbFechaFinal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFechaFinal.Click += new System.EventHandler(this.tbFechaFinal_Click);
            // 
            // tbUsuario
            // 
            this.tbUsuario.Enabled = false;
            this.tbUsuario.Location = new System.Drawing.Point(131, 231);
            this.tbUsuario.Name = "tbUsuario";
            this.tbUsuario.Size = new System.Drawing.Size(100, 20);
            this.tbUsuario.TabIndex = 35;
            this.tbUsuario.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbEstatus
            // 
            this.tbEstatus.Enabled = false;
            this.tbEstatus.Location = new System.Drawing.Point(131, 267);
            this.tbEstatus.Name = "tbEstatus";
            this.tbEstatus.Size = new System.Drawing.Size(100, 20);
            this.tbEstatus.TabIndex = 38;
            this.tbEstatus.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(219, 313);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 40;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btCancelar
            // 
            this.btCancelar.Location = new System.Drawing.Point(37, 313);
            this.btCancelar.Name = "btCancelar";
            this.btCancelar.Size = new System.Drawing.Size(75, 23);
            this.btCancelar.TabIndex = 39;
            this.btCancelar.Text = "Cancelar";
            this.btCancelar.UseVisualStyleBackColor = true;
            this.btCancelar.Click += new System.EventHandler(this.btCancelar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(237, 156);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 41;
            this.label2.Text = "DD/MM/AAAA";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(237, 199);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 13);
            this.label1.TabIndex = 42;
            this.label1.Text = "DD/MM/AAAA";
            // 
            // mcCal01
            // 
            this.mcCal01.BackColor = System.Drawing.Color.Gray;
            this.mcCal01.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.mcCal01.Location = new System.Drawing.Point(52, 174);
            this.mcCal01.Name = "mcCal01";
            this.mcCal01.TabIndex = 43;
            this.mcCal01.Visible = false;
            this.mcCal01.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcCal01_DateSelected);
            // 
            // mcCal02
            // 
            this.mcCal02.BackColor = System.Drawing.Color.Gray;
            this.mcCal02.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.mcCal02.Location = new System.Drawing.Point(52, 7);
            this.mcCal02.Name = "mcCal02";
            this.mcCal02.TabIndex = 44;
            this.mcCal02.Visible = false;
            this.mcCal02.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcCal02_DateSelected);
            // 
            // AltaHdrRentabilidad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 352);
            this.Controls.Add(this.mcCal02);
            this.Controls.Add(this.mcCal01);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.btCancelar);
            this.Controls.Add(this.tbEstatus);
            this.Controls.Add(this.tbUsuario);
            this.Controls.Add(this.tbFechaFinal);
            this.Controls.Add(this.tbFechaInicial);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.tbTabla);
            this.Controls.Add(this.tbMarca);
            this.Controls.Add(this.lblEstatus);
            this.Controls.Add(this.lblUsuario);
            this.Controls.Add(this.lblFechaFinal);
            this.Controls.Add(this.lblFechaInicio);
            this.Controls.Add(this.lblDescripcion);
            this.Controls.Add(this.lblTabla);
            this.Controls.Add(this.lblMarca);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AltaHdrRentabilidad";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AltaHdrRentabilidad";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AltaHdrRentabilidad_FormClosing);
            this.Load += new System.EventHandler(this.AltaHdrRentabilidad_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEstatus;
        private System.Windows.Forms.Label lblUsuario;
        private System.Windows.Forms.Label lblFechaFinal;
        private System.Windows.Forms.Label lblFechaInicio;
        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.Label lblTabla;
        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.TextBox tbMarca;
        private System.Windows.Forms.TextBox tbTabla;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbFechaInicial;
        private System.Windows.Forms.TextBox tbFechaFinal;
        private System.Windows.Forms.TextBox tbUsuario;
        private System.Windows.Forms.TextBox tbEstatus;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btCancelar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MonthCalendar mcCal01;
        private System.Windows.Forms.MonthCalendar mcCal02;
    }
}