﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class Kardex : Form
    {
        int dgvOffset;
        int dgvOffset2;

        public Kardex()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }

        private void Kardex_Load(object sender, EventArgs e)
        {
            ToolTip Tooltip1 = new ToolTip();
            Tooltip1.SetToolTip(this.btActualizarKardex, "Actualizar desde MMS"); 

            BindData();
        }

        private void BindData()
        {
            this.Cursor = Cursors.WaitCursor;

            dgvGridView.DataSource = null;
            System.Data.DataTable Kardex = null;
            try
            {
                string proveedor = MmsWin.Front.Utilerias.VarTem.tmpPrv;
                string estilo = MmsWin.Front.Utilerias.VarTem.tmpSty;
                string usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                Kardex = MmsWin.Negocio.Convenio.Kardex.GetInstance().ObtenKardex1(proveedor, estilo, usuario);
                string transito = string.Empty;
                string onHand = string.Empty;
                string OnHnadtransito = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenOnHandTransito1(proveedor, estilo, out onHand, out transito);
                if (OnHnadtransito == "")
                {
                    MessageBox.Show("No hay On Hand para este estilo");
                }
                btOnHandDat.Text = string.Format("{0:n0}", double.Parse(onHand));
                btTransitoDat.Text = string.Format("{0:n0}", double.Parse(transito));
                btInventarioTotDat.Text = string.Format("{0:n0}", double.Parse(OnHnadtransito));
            }
            catch  {  }

            //catch (Exception ex)
            //{
            //    throw ex;
            //}
            if (Kardex.Rows.Count > 0)
            {
                string proveedor = MmsWin.Front.Utilerias.VarTem.tmpPrv;
                string estilo = MmsWin.Front.Utilerias.VarTem.tmpSty;
                dgvGridView.DataSource = Kardex;
                int nr = dgvGridView.RowCount;
                this.Text = "Kardex / " + " " + (nr).ToString() + " Registro(s)" + "  / " + "Proveedor: " + proveedor + "   Estilo: "  + estilo ;
                SetFontAndColors();
                rowStyleColores();
                rowStyleSuma();
                SetDoubleBuffered(dgvGridView);
            }
            this.Cursor = Cursors.Default;
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvGridView.Columns[3].Frozen = true;

            dgvGridView.Columns[0].HeaderText = "Año";
            dgvGridView.Columns[1].HeaderText = "Semana";
            dgvGridView.Columns[2].HeaderText = "Proveedor";
            dgvGridView.Columns[3].HeaderText = "Estilo";
            dgvGridView.Columns[4].HeaderText = "Ventas 11";
            dgvGridView.Columns[5].HeaderText = "Devoluciones 12";
            dgvGridView.Columns[6].HeaderText = "Tipo 13";
            dgvGridView.Columns[7].HeaderText = "Tipo 14";
            dgvGridView.Columns[8].HeaderText = "Ventas 15";
            dgvGridView.Columns[9].HeaderText = "Devoluciones 16";
            dgvGridView.Columns[10].HeaderText = "Tipo 17";
            dgvGridView.Columns[11].HeaderText = "Tipo 18";
            dgvGridView.Columns[12].HeaderText = "Tipo 19";
            dgvGridView.Columns[13].HeaderText = "Tipo 20";
            dgvGridView.Columns[14].HeaderText = "Tipo 21";
            dgvGridView.Columns[15].HeaderText = "Return";
            dgvGridView.Columns[16].HeaderText = "Fecha Recibo";
            dgvGridView.Columns[17].HeaderText = "Piezas Recibidas.31";
            dgvGridView.Columns[18].HeaderText = "Recibo Transf.41";
            dgvGridView.Columns[19].HeaderText = "Transferencia 42";
            dgvGridView.Columns[20].HeaderText = "Tipo 47";
            dgvGridView.Columns[21].HeaderText = "Tipo 48";
            dgvGridView.Columns[22].HeaderText = "Tipo 49";
            dgvGridView.Columns[23].HeaderText = "Dev. Cedis.50";
            dgvGridView.Columns[24].HeaderText = "Dev. Prov.51";
            dgvGridView.Columns[25].HeaderText = "Trans.fWhs 53";
            dgvGridView.Columns[26].HeaderText = "Ajuste Directo.61";
            dgvGridView.Columns[27].HeaderText = "Tipo62";
            dgvGridView.Columns[28].HeaderText = "Ajuste Fisico.71";
            dgvGridView.Columns[29].HeaderText = "On Order";
            dgvGridView.Columns[30].HeaderText = "Tipo 73";
            dgvGridView.Columns[31].HeaderText = "Transito";
            dgvGridView.Columns[32].HeaderText = "Tipo 75";
            dgvGridView.Columns[33].HeaderText = "Tipo 76";
            dgvGridView.Columns[34].HeaderText = "Tipo 77";
            dgvGridView.Columns[35].HeaderText = "Tipo 78";
            dgvGridView.Columns[36].HeaderText = "Tipo 79";
            dgvGridView.Columns[37].HeaderText = "Tipo 80";
            dgvGridView.Columns[38].HeaderText = "Ajuste 83";
            dgvGridView.Columns[39].HeaderText = "Tipo 87";
            dgvGridView.Columns[40].HeaderText = "Tipo 88";
            dgvGridView.Columns[41].HeaderText = "Tipo 89";
            dgvGridView.Columns[42].HeaderText = "Tipo 90";
            dgvGridView.Columns[43].HeaderText = "On Hand";
            dgvGridView.Columns[44].HeaderText = "INV Total";
            dgvGridView.Columns[45].HeaderText = "Temporada";
            dgvGridView.Columns[46].HeaderText = "Costo ";
            dgvGridView.Columns[47].HeaderText = "Precio";
            dgvGridView.Columns[48].HeaderText = "Bodega";
            dgvGridView.Columns[49].HeaderText = "Fecha";

            dgvGridView.Columns[0].Width = 50;
            dgvGridView.Columns[1].Width = 50;
            dgvGridView.Columns[2].Width = 50;
            dgvGridView.Columns[3].Width = 70;
            dgvGridView.Columns[4].Width = 70;
            dgvGridView.Columns[5].Width = 70;
            dgvGridView.Columns[6].Width = 70;
            dgvGridView.Columns[7].Width = 70;
            dgvGridView.Columns[8].Width = 70;
            dgvGridView.Columns[9].Width = 70;
            dgvGridView.Columns[10].Width = 70;
            dgvGridView.Columns[11].Width = 70;
            dgvGridView.Columns[12].Width = 70;
            dgvGridView.Columns[13].Width = 70;
            dgvGridView.Columns[14].Width = 70;
            dgvGridView.Columns[15].Width = 70;
            dgvGridView.Columns[16].Width = 80;
            dgvGridView.Columns[17].Width = 70;
            dgvGridView.Columns[18].Width = 70;
            dgvGridView.Columns[19].Width = 70;
            dgvGridView.Columns[20].Width = 70;
            dgvGridView.Columns[21].Width = 70;
            dgvGridView.Columns[22].Width = 70;
            dgvGridView.Columns[23].Width = 70;
            dgvGridView.Columns[24].Width = 70;
            dgvGridView.Columns[25].Width = 70;
            dgvGridView.Columns[26].Width = 70;
            dgvGridView.Columns[27].Width = 70;
            dgvGridView.Columns[28].Width = 70;
            dgvGridView.Columns[29].Width = 70;
            dgvGridView.Columns[30].Width = 70;
            dgvGridView.Columns[31].Width = 70;
            dgvGridView.Columns[32].Width = 70;
            dgvGridView.Columns[33].Width = 70;
            dgvGridView.Columns[34].Width = 70;
            dgvGridView.Columns[35].Width = 70;
            dgvGridView.Columns[36].Width = 70;
            dgvGridView.Columns[37].Width = 70;
            dgvGridView.Columns[38].Width = 70;
            dgvGridView.Columns[39].Width = 70;
            dgvGridView.Columns[40].Width = 70;
            dgvGridView.Columns[41].Width = 70;
            dgvGridView.Columns[42].Width = 70;
            dgvGridView.Columns[43].Width = 70;
            dgvGridView.Columns[44].Width = 70;
            dgvGridView.Columns[45].Width = 70;
            dgvGridView.Columns[46].Width = 70;
            dgvGridView.Columns[47].Width = 70;
            dgvGridView.Columns[48].Width = 70;
            dgvGridView.Columns[49].Width = 80;

            dgvGridView.Columns[0].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[1].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[2].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[3].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[4].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[5].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[6].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[7].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[8].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[9].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[10].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[11].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[12].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[13].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[14].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[15].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[16].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[17].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[18].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[19].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[20].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[21].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[22].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[23].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[24].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[25].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[26].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[27].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[28].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[29].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[30].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[31].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[32].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[33].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[34].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[35].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[36].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[37].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[38].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[39].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[40].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[41].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[42].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[43].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[44].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[45].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[46].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[47].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[48].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[49].DefaultCellStyle.NullValue = true;


            dgvGridView.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[11].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[12].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[13].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[14].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[15].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[16].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[17].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[18].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[19].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[20].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[21].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[22].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[23].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[24].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[25].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[26].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[27].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[28].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[29].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[30].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[31].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[32].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[33].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[34].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[35].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[36].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[37].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[38].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[39].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[40].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[41].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[42].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[43].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[44].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[45].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[46].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[47].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[48].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[49].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns[4].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[5].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[6].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[7].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[8].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[9].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[10].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[11].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[12].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[13].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[14].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[15].DefaultCellStyle.Format = "###,###";

            dgvGridView.Columns[17].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[18].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[19].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[20].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[21].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[22].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[23].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[24].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[25].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[26].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[27].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[28].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[29].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[30].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[31].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[32].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[33].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[34].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[35].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[36].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[37].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[38].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[39].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[40].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[41].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[42].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[43].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[44].DefaultCellStyle.Format = "###,###";

            dgvGridView.Columns[46].DefaultCellStyle.Format = "###,###.##";
            dgvGridView.Columns[47].DefaultCellStyle.Format = "###,###.##";
            dgvGridView.Columns[48].DefaultCellStyle.Format = "######";

            dgvGridView.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[1].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[2].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[3].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[4].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[5].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[6].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[7].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[8].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[9].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[10].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[11].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[12].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[13].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[14].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[15].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[16].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[17].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[18].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[19].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[20].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[21].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[22].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[23].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[24].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[25].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[26].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[27].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[28].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[29].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[30].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[31].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[32].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[33].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns[34].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns[35].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns[36].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns[37].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns[38].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns[39].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns[40].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns[41].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[42].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[43].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[44].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns[45].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[46].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[47].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[48].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[49].HeaderCell.Style.BackColor = Color.LightGreen;
        }

        private void rowStyleColores()
        {
            int col0 = 0, col1 = 0, col2 = 0, col3 = 0, col4 = 0, col5 = 0, col6 = 0, col7 = 0, col8 = 0, col9 = 0, col10 = 0, col11 = 0, col12 = 0, col13 = 0, col14 = 0, col15 = 0, col16 = 0, col17 = 0, col18 = 0, col19 = 0, col20 = 0, col21 = 0;
            int col22 = 0, col23 = 0, col24 = 0, col25 = 0, col26 = 0, col27 = 0, col28 = 0, col29 = 0, col30 = 0, col31 = 0, col32 = 0, col33 = 0, col34 = 0, col35 = 0, col36 = 0, col37 = 0, col38 = 0, col39 = 0, col40 = 0, col41 = 0, col42 = 0;
            int col43 = 0, col44 = 0, col45 = 0, col46 = 0, col47 = 0, col48 = 0, col49 = 0;

            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                // Suma las Ventas y devoluciones                   
                int Total = Convert.ToInt32(rowp.Cells[0].Value);                                                
                Int32 Vtas11 = Convert.ToInt32(rowp.Cells[4].Value);
                Int32 Dev12 = Convert.ToInt32(rowp.Cells[5].Value);
                Int32 Vtas15 = Convert.ToInt32(rowp.Cells[8].Value);
                Int32 Dev16 = Convert.ToInt32(rowp.Cells[9].Value);
                rowp.Cells[4].Value = (Vtas11 + Vtas15) - (Dev12 + Dev16);
                rowp.Cells[5].Value = Dev12 + Dev16;

                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
                if (Total == 99)
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.DarkGreen;
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.ForeColor = Color.White;
                    rowp.Cells[0].Style.ForeColor = Color.DarkGreen;
                    rowp.Cells[1].Style.ForeColor = Color.DarkGreen;
                }

                // Validacion de columnas                                                                                          
                string Col0 = dgvGridView.Rows[Regs - 1].Cells[0].Value.ToString(); if (Col0 != "0") { col0 = 1; }
              //  string Col1 = dgvGridView.Rows[Regs - 1].Cells[1].Value.ToString(); if (Col1 != "0") { col1 = 1; }
                string Col2 = dgvGridView.Rows[Regs - 1].Cells[2].Value.ToString(); if (Col2 != "0") { col2 = 1; }
                string Col3 = dgvGridView.Rows[Regs - 1].Cells[3].Value.ToString(); if (Col3 != "0.000") { col3 = 1; }
                string Col4 = dgvGridView.Rows[Regs - 1].Cells[4].Value.ToString(); if (Col4 != "0.000") { col4 = 1; }
                string Col5 = dgvGridView.Rows[Regs - 1].Cells[5].Value.ToString(); if (Col5 != "0.000") { col5 = 1; }
                string Col6 = dgvGridView.Rows[Regs - 1].Cells[6].Value.ToString(); if (Col6 != "0.000") { col6 = 1; }
                string Col7 = dgvGridView.Rows[Regs - 1].Cells[7].Value.ToString(); if (Col7 != "0.000") { col7 = 1; }
                string Col8 = dgvGridView.Rows[Regs - 1].Cells[8].Value.ToString(); if (Col8 != "0.000") { col8 = 1; }
                string Col9 = dgvGridView.Rows[Regs - 1].Cells[9].Value.ToString(); if (Col9 != "0.000") { col9 = 1; }
                string Col10 = dgvGridView.Rows[Regs - 1].Cells[10].Value.ToString(); if (Col10 != "0.000") { col10 = 1; }
                string Col11 = dgvGridView.Rows[Regs - 1].Cells[11].Value.ToString(); if (Col11 != "0.000") { col11 = 1; }
                string Col12 = dgvGridView.Rows[Regs - 1].Cells[12].Value.ToString(); if (Col12 != "0.000") { col12 = 1; }
                string Col13 = dgvGridView.Rows[Regs - 1].Cells[13].Value.ToString(); if (Col13 != "0.000") { col13 = 1; }
                string Col14 = dgvGridView.Rows[Regs - 1].Cells[14].Value.ToString(); if (Col14 != "0.000") { col14 = 1; }
                string Col15 = dgvGridView.Rows[Regs - 1].Cells[15].Value.ToString(); if (Col15 != "0.000") { col15 = 1; }
                string Col16 = dgvGridView.Rows[Regs - 1].Cells[16].Value.ToString(); if (Col16 == "0") { rowp.Cells[16].Value = " "; }
                // Formato de Fecha                                                                                                      
                if (Col16 != "0" && Col16 != "")
                {
                    try
                    {
                        col16 = 1;

                        // Resalta la Fecha de Recibo                                                                                            
                        Col16 = dgvGridView.Rows[Regs - 1].Cells[16].Value.ToString(); if (Col16 == "0") { rowp.Cells[16].Value = " "; }
                        if (Col16 != "0") { rowp.Cells[16].Style.BackColor = Color.Red; rowp.Cells[16].Style.ForeColor = Color.White; }
                        if (Col16 != "0") { rowp.Cells[17].Style.ForeColor = Color.Green; }

                        // Identifica los Negativos en color Rojo                                                                                
                        string Col17 = dgvGridView.Rows[Regs - 1].Cells[17].Value.ToString(); if (Col17 != "0.000") { col17 = 1; }
                        Int32 PzRcb = Convert.ToInt32(rowp.Cells[17].Value);
                        if (PzRcb < 0) { rowp.Cells[17].Style.ForeColor = Color.Red; }
                    }
                    catch { }
                }

                string Col18 = dgvGridView.Rows[Regs - 1].Cells[18].Value.ToString(); if (Col18 != "0.000") { col18 = 1; }
                string Col19 = dgvGridView.Rows[Regs - 1].Cells[19].Value.ToString(); if (Col19 != "0.000") { col19 = 1; }
                string Col20 = dgvGridView.Rows[Regs - 1].Cells[20].Value.ToString(); if (Col20 != "0.000") { col20 = 1; }
                string Col21 = dgvGridView.Rows[Regs - 1].Cells[21].Value.ToString(); if (Col21 != "0.000") { col21 = 1; }
                string Col22 = dgvGridView.Rows[Regs - 1].Cells[22].Value.ToString(); if (Col22 != "0.000") { col22 = 1; }
                string Col23 = dgvGridView.Rows[Regs - 1].Cells[23].Value.ToString(); if (Col23 != "0.000") { col23 = 1; }
                string Col24 = dgvGridView.Rows[Regs - 1].Cells[24].Value.ToString(); if (Col24 != "0.000") { col24 = 1; }
                string Col25 = dgvGridView.Rows[Regs - 1].Cells[25].Value.ToString(); if (Col25 != "0.000") { col25 = 1; }
                // Identifica los Negativos en color Rojo                                                                                
                string Col26 = dgvGridView.Rows[Regs - 1].Cells[26].Value.ToString(); if (Col26 != "0.000") { col26 = 1; }
                Int32  Ajuste = Convert.ToInt32(rowp.Cells[26].Value);
                if (Ajuste < 0) { rowp.Cells[26].Style.ForeColor = Color.Red; }
                // Identifica los Negativos en color Rojo                                                                                
                string Col27 = dgvGridView.Rows[Regs - 1].Cells[27].Value.ToString(); if (Col27 != "0.000") { col27 = 1; }
                string Col28 = dgvGridView.Rows[Regs - 1].Cells[28].Value.ToString(); if (Col28 != "0.000") { col28 = 1; }
                Int32 AjuInv = Convert.ToInt32(rowp.Cells[28].Value);
                if (AjuInv < 0) { rowp.Cells[28].Style.ForeColor = Color.Red; }

                string Col29 = dgvGridView.Rows[Regs - 1].Cells[29].Value.ToString(); if (Col29 != "0.000") { col29 = 1; }
                string Col30 = dgvGridView.Rows[Regs - 1].Cells[30].Value.ToString(); if (Col30 != "0.000") { col30 = 1; }
                string Col31 = dgvGridView.Rows[Regs - 1].Cells[31].Value.ToString(); if (Col31 != "0.000") { col31 = 1; }
                string Col32 = dgvGridView.Rows[Regs - 1].Cells[32].Value.ToString(); if (Col32 != "0.000") { col32 = 1; }
                string Col33 = dgvGridView.Rows[Regs - 1].Cells[33].Value.ToString(); if (Col33 != "0.000") { col33 = 1; }
                string Col34 = dgvGridView.Rows[Regs - 1].Cells[34].Value.ToString(); if (Col34 != "0.000") { col34 = 1; }
                string Col35 = dgvGridView.Rows[Regs - 1].Cells[35].Value.ToString(); if (Col35 != "0.000") { col35 = 1; }
                string Col36 = dgvGridView.Rows[Regs - 1].Cells[36].Value.ToString(); if (Col36 != "0.000") { col36 = 1; }
                string Col37 = dgvGridView.Rows[Regs - 1].Cells[37].Value.ToString(); if (Col37 != "0.000") { col37 = 1; }
                string Col38 = dgvGridView.Rows[Regs - 1].Cells[38].Value.ToString(); if (Col38 != "0.000") { col38 = 1; }
                string Col39 = dgvGridView.Rows[Regs - 1].Cells[39].Value.ToString(); if (Col39 != "0.000") { col39 = 1; }
                string Col40 = dgvGridView.Rows[Regs - 1].Cells[40].Value.ToString(); if (Col40 != "0.000") { col40 = 1; }
                string Col41 = dgvGridView.Rows[Regs - 1].Cells[41].Value.ToString(); if (Col41 != "0.000") { col41 = 1; }
                string Col42 = dgvGridView.Rows[Regs - 1].Cells[42].Value.ToString(); if (Col42 != "0.000") { col42 = 1; }
                string Col43 = dgvGridView.Rows[Regs - 1].Cells[43].Value.ToString(); if (Col43 != "0.000") { col43 = 1; }
                string Col44 = dgvGridView.Rows[Regs - 1].Cells[44].Value.ToString(); if (Col44 != "0.000") { col44 = 1; }
                string Col45 = dgvGridView.Rows[Regs - 1].Cells[45].Value.ToString(); if (Col45 != "0.000") { col45 = 1; }
                string Col46 = dgvGridView.Rows[Regs - 1].Cells[46].Value.ToString(); if (Col46 != "0.000") { col46 = 1; }
                string Col47 = dgvGridView.Rows[Regs - 1].Cells[47].Value.ToString(); if (Col47 != "0.000") { col47 = 1; }
                string Col48 = dgvGridView.Rows[Regs - 1].Cells[48].Value.ToString(); if (Col48 != "0.000") { col48 = 1; }
                string Col49 = dgvGridView.Rows[Regs - 1].Cells[49].Value.ToString(); if (Col49 != "0.000") { col49 = 1; }
            }
            // Oculta columnas que no tienen datos                      
            if (col0 == 0) { dgvGridView.Columns[0].Visible = false; }
            if (col2 == 0) { dgvGridView.Columns[1].Visible = false; }
            dgvGridView.Columns[2].Visible = false;
            dgvGridView.Columns[3].Visible = false;
            if (col4 == 0) { dgvGridView.Columns[4].Visible = false; }
            if (col5 == 0) { dgvGridView.Columns[5].Visible = false; }
            dgvGridView.Columns[6].Visible = false;
            dgvGridView.Columns[7].Visible = false;
            dgvGridView.Columns[8].Visible = false; 
            dgvGridView.Columns[9].Visible = false; 
            dgvGridView.Columns[10].Visible = false;
            dgvGridView.Columns[11].Visible = false;
            dgvGridView.Columns[12].Visible = false;
            dgvGridView.Columns[13].Visible = false;
            dgvGridView.Columns[14].Visible = false;
            dgvGridView.Columns[15].Visible = false;
            if (col16 == 0) { dgvGridView.Columns[16].Visible = false; }
            if (col17 == 0) { dgvGridView.Columns[17].Visible = false; }
            if (col18 == 0) { dgvGridView.Columns[18].Visible = false; }
            if (col19 == 0) { dgvGridView.Columns[19].Visible = false; }
            dgvGridView.Columns[20].Visible = false;
            dgvGridView.Columns[21].Visible = false;
            dgvGridView.Columns[22].Visible = false;
            if (col23 == 0) { dgvGridView.Columns[23].Visible = false; }
            if (col24 == 0) { dgvGridView.Columns[24].Visible = false; }
            if (col25 == 0) { dgvGridView.Columns[25].Visible = false; }
            if (col26 == 0) { dgvGridView.Columns[26].Visible = false; }
            if (col27 == 0) { dgvGridView.Columns[27].Visible = false; }
            if (col28 == 0) { dgvGridView.Columns[28].Visible = false; }
            if (col29 == 0) { dgvGridView.Columns[29].Visible = false; }
            dgvGridView.Columns[30].Visible = false;
            dgvGridView.Columns[31].Visible = false;  
            dgvGridView.Columns[32].Visible = false;
            if (col33 == 0) { dgvGridView.Columns[33].Visible = false; }
            dgvGridView.Columns[34].Visible = false; 
            dgvGridView.Columns[35].Visible = false; 
            dgvGridView.Columns[36].Visible = false; 
            dgvGridView.Columns[37].Visible = false;
            if (col38 == 0) { dgvGridView.Columns[38].Visible = false; }
            dgvGridView.Columns[39].Visible = false;
            dgvGridView.Columns[40].Visible = false;
            dgvGridView.Columns[41].Visible = false;
            dgvGridView.Columns[42].Visible = false; 
            if (col43 == 0) { dgvGridView.Columns[43].Visible = false; }
            dgvGridView.Columns[44].Visible = false;
            if (col45 == 0) { dgvGridView.Columns[45].Visible = false; }
            if (col46 == 0) { dgvGridView.Columns[46].Visible = false; }
            if (col47 == 0) { dgvGridView.Columns[47].Visible = false; }
            if (col48 == 0) { dgvGridView.Columns[48].Visible = false; }
            dgvGridView.Columns[49].Visible = false;    
        }

        private void rowStyleSuma()
        {
            int col0 = 0, col1 = 0, col2 = 0, col3 = 0, col4 = 0, col5 = 0, col6 = 0, col7 = 0, col8 = 0, col9 = 0, col10 = 0, col11 = 0, col12 = 0, col13 = 0, col14 = 0, col15 = 0, col16 = 0, col17 = 0, col18 = 0, col19 = 0, col20 = 0, col21 = 0;
            int col22 = 0, col23 = 0, col24 = 0, col25 = 0, col26 = 0, col27 = 0, col28 = 0, col29 = 0, col30 = 0, col31 = 0, col32 = 0, col33 = 0, col34 = 0, col35 = 0, col36 = 0, col37 = 0, col38 = 0, col39 = 0, col40 = 0, col41 = 0, col42 = 0;
            int col43 = 0, col44 = 0, col45 = 0, col46 = 0, col47 = 0, col48 = 0, col49 = 0;

            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                // Suma las Ventas y devoluciones                   
                int Total = Convert.ToInt32(rowp.Cells[0].Value);
                Int32 Vtas11 = Convert.ToInt32(rowp.Cells[4].Value);
                Int32 Dev12 = Convert.ToInt32(rowp.Cells[5].Value);
                Int32 Vtas15 = Convert.ToInt32(rowp.Cells[8].Value);
                Int32 Dev16 = Convert.ToInt32(rowp.Cells[9].Value);
                rowp.Cells[4].Value = (Vtas11 + Vtas15) - (Dev12 + Dev16);
                rowp.Cells[5].Value = Dev12 + Dev16;

                int kia = rowp.Index;
                Regs += 1;

                if (Total == 99)
                {
                    // Totales por columna
                    // Suma Ventas                                        
                    int tot11 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[4].Value));
                    rowp.Cells[4].Value = tot11;
                    // Suma Devoluciones                                  
                    int tot12 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[5].Value));
                    rowp.Cells[5].Value = tot12;
                    // Suma Recibos                                       
                    int tot31 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[17].Value));
                    rowp.Cells[17].Value = tot31;
                    // Suma Recibos Transferencias                       
                    int tot41 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[18].Value));
                    rowp.Cells[18].Value = tot41;
                    // Suma Recibos Transferencias                       
                    int tot42 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[19].Value));
                    rowp.Cells[19].Value = tot42;
                    // Suma Devolucion al CEDIS                          
                    int tot50 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[23].Value));
                    rowp.Cells[23].Value = tot50;
                    // Suma Devolucion al Proveedor                      
                    int tot51 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[24].Value));
                    rowp.Cells[24].Value = tot51;
                    // Suma Transferencia al almacen                     
                    int tot53 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[25].Value));
                    rowp.Cells[25].Value = tot53;
                    // Suma Ajuste Directo                               
                    int tot61 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[26].Value));
                    rowp.Cells[26].Value = tot61;
                    // Suma Ajuste de inventario                         
                    int tot71 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[28].Value));
                    rowp.Cells[28].Value = tot71;
                    // Suma Transito                                     
                    int tot74 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[31].Value));
                    rowp.Cells[31].Value = tot74;
                }

                // Validacion de columnas                                                                                          
                string Col0 = dgvGridView.Rows[Regs - 1].Cells[0].Value.ToString(); if (Col0 != "0") { col0 = 1; }
                //  string Col1 = dgvGridView.Rows[Regs - 1].Cells[1].Value.ToString(); if (Col1 != "0") { col1 = 1; }
                string Col2 = dgvGridView.Rows[Regs - 1].Cells[2].Value.ToString(); if (Col2 != "0") { col2 = 1; }
                string Col3 = dgvGridView.Rows[Regs - 1].Cells[3].Value.ToString(); if (Col3 != "0.000") { col3 = 1; }
                string Col4 = dgvGridView.Rows[Regs - 1].Cells[4].Value.ToString(); if (Col4 != "0.000") { col4 = 1; }
                string Col5 = dgvGridView.Rows[Regs - 1].Cells[5].Value.ToString(); if (Col5 != "0.000") { col5 = 1; }
                string Col6 = dgvGridView.Rows[Regs - 1].Cells[6].Value.ToString(); if (Col6 != "0.000") { col6 = 1; }
                string Col7 = dgvGridView.Rows[Regs - 1].Cells[7].Value.ToString(); if (Col7 != "0.000") { col7 = 1; }
                string Col8 = dgvGridView.Rows[Regs - 1].Cells[8].Value.ToString(); if (Col8 != "0.000") { col8 = 1; }
                string Col9 = dgvGridView.Rows[Regs - 1].Cells[9].Value.ToString(); if (Col9 != "0.000") { col9 = 1; }
                string Col10 = dgvGridView.Rows[Regs - 1].Cells[10].Value.ToString(); if (Col10 != "0.000") { col10 = 1; }
                string Col11 = dgvGridView.Rows[Regs - 1].Cells[11].Value.ToString(); if (Col11 != "0.000") { col11 = 1; }
                string Col12 = dgvGridView.Rows[Regs - 1].Cells[12].Value.ToString(); if (Col12 != "0.000") { col12 = 1; }
                string Col13 = dgvGridView.Rows[Regs - 1].Cells[13].Value.ToString(); if (Col13 != "0.000") { col13 = 1; }
                string Col14 = dgvGridView.Rows[Regs - 1].Cells[14].Value.ToString(); if (Col14 != "0.000") { col14 = 1; }
                string Col15 = dgvGridView.Rows[Regs - 1].Cells[15].Value.ToString(); if (Col15 != "0.000") { col15 = 1; }
                string Col16 = dgvGridView.Rows[Regs - 1].Cells[16].Value.ToString(); if (Col16 == "0") { rowp.Cells[16].Value = " "; }
                // Formato de Fecha                                                                                                      
                if (Col16 != "0" && Col16 != "")
                {
                    try
                    {
                        col16 = 1;
                        string RcbFch = rowp.Cells[16].Value.ToString();
                        rowp.Cells[16].Value = RcbFch.Substring(4, 2) + "/" + RcbFch.Substring(2, 2) + "/20" + RcbFch.Substring(0, 2);

                        // Resalta la Fecha de Recibo                                                                                            
                        Col16 = dgvGridView.Rows[Regs - 1].Cells[16].Value.ToString(); if (Col16 == "0") { rowp.Cells[16].Value = " "; }
                        if (Col16 != "0") { rowp.Cells[16].Style.BackColor = Color.Red; rowp.Cells[16].Style.ForeColor = Color.White; }
                        if (Col16 != "0") { rowp.Cells[17].Style.ForeColor = Color.Green; }

                        // Identifica los Negativos en color Rojo                                                                                
                        string Col17 = dgvGridView.Rows[Regs - 1].Cells[17].Value.ToString(); if (Col17 != "0.000") { col17 = 1; }
                        Int32 PzRcb = Convert.ToInt32(rowp.Cells[17].Value);
                        if (PzRcb < 0) { rowp.Cells[17].Style.ForeColor = Color.Red; }
                    }
                    catch { }
                }

                string Col18 = dgvGridView.Rows[Regs - 1].Cells[18].Value.ToString(); if (Col18 != "0.000") { col18 = 1; }
                string Col19 = dgvGridView.Rows[Regs - 1].Cells[19].Value.ToString(); if (Col19 != "0.000") { col19 = 1; }
                string Col20 = dgvGridView.Rows[Regs - 1].Cells[20].Value.ToString(); if (Col20 != "0.000") { col20 = 1; }
                string Col21 = dgvGridView.Rows[Regs - 1].Cells[21].Value.ToString(); if (Col21 != "0.000") { col21 = 1; }
                string Col22 = dgvGridView.Rows[Regs - 1].Cells[22].Value.ToString(); if (Col22 != "0.000") { col22 = 1; }
                string Col23 = dgvGridView.Rows[Regs - 1].Cells[23].Value.ToString(); if (Col23 != "0.000") { col23 = 1; }
                string Col24 = dgvGridView.Rows[Regs - 1].Cells[24].Value.ToString(); if (Col24 != "0.000") { col24 = 1; }
                string Col25 = dgvGridView.Rows[Regs - 1].Cells[25].Value.ToString(); if (Col25 != "0.000") { col25 = 1; }

                string Col29 = dgvGridView.Rows[Regs - 1].Cells[29].Value.ToString(); if (Col29 != "0.000") { col29 = 1; }
                string Col30 = dgvGridView.Rows[Regs - 1].Cells[30].Value.ToString(); if (Col30 != "0.000") { col30 = 1; }
                string Col31 = dgvGridView.Rows[Regs - 1].Cells[31].Value.ToString(); if (Col31 != "0.000") { col31 = 1; }
                string Col32 = dgvGridView.Rows[Regs - 1].Cells[32].Value.ToString(); if (Col32 != "0.000") { col32 = 1; }
                string Col33 = dgvGridView.Rows[Regs - 1].Cells[33].Value.ToString(); if (Col33 != "0.000") { col33 = 1; }
                string Col34 = dgvGridView.Rows[Regs - 1].Cells[34].Value.ToString(); if (Col34 != "0.000") { col34 = 1; }
                string Col35 = dgvGridView.Rows[Regs - 1].Cells[35].Value.ToString(); if (Col35 != "0.000") { col35 = 1; }
                string Col36 = dgvGridView.Rows[Regs - 1].Cells[36].Value.ToString(); if (Col36 != "0.000") { col36 = 1; }
                string Col37 = dgvGridView.Rows[Regs - 1].Cells[37].Value.ToString(); if (Col37 != "0.000") { col37 = 1; }
                string Col38 = dgvGridView.Rows[Regs - 1].Cells[38].Value.ToString(); if (Col38 != "0.000") { col38 = 1; }
                string Col39 = dgvGridView.Rows[Regs - 1].Cells[39].Value.ToString(); if (Col39 != "0.000") { col39 = 1; }
                string Col40 = dgvGridView.Rows[Regs - 1].Cells[40].Value.ToString(); if (Col40 != "0.000") { col40 = 1; }
                string Col41 = dgvGridView.Rows[Regs - 1].Cells[41].Value.ToString(); if (Col41 != "0.000") { col41 = 1; }
                string Col42 = dgvGridView.Rows[Regs - 1].Cells[42].Value.ToString(); if (Col42 != "0.000") { col42 = 1; }
                string Col43 = dgvGridView.Rows[Regs - 1].Cells[43].Value.ToString(); if (Col43 != "0.000") { col43 = 1; }
                string Col44 = dgvGridView.Rows[Regs - 1].Cells[44].Value.ToString(); if (Col44 != "0.000") { col44 = 1; }
                string Col45 = dgvGridView.Rows[Regs - 1].Cells[45].Value.ToString(); if (Col45 != "0.000") { col45 = 1; }
                string Col46 = dgvGridView.Rows[Regs - 1].Cells[46].Value.ToString(); if (Col46 != "0.000") { col46 = 1; }
                string Col47 = dgvGridView.Rows[Regs - 1].Cells[47].Value.ToString(); if (Col47 != "0.000") { col47 = 1; }
                string Col48 = dgvGridView.Rows[Regs - 1].Cells[48].Value.ToString(); if (Col48 != "0.000") { col48 = 1; }
                string Col49 = dgvGridView.Rows[Regs - 1].Cells[49].Value.ToString(); if (Col49 != "0.000") { col49 = 1; }
            }
            // Oculta columnas que no tienen datos                      
            if (col0 == 0) { dgvGridView.Columns[0].Visible = false; }
            if (col2 == 0) { dgvGridView.Columns[1].Visible = false; }
            dgvGridView.Columns[2].Visible = false;
            dgvGridView.Columns[3].Visible = false;
            if (col4 == 0) { dgvGridView.Columns[4].Visible = false; }
            if (col5 == 0) { dgvGridView.Columns[5].Visible = false; }
            dgvGridView.Columns[6].Visible = false;
            dgvGridView.Columns[7].Visible = false;
            dgvGridView.Columns[8].Visible = false;
            dgvGridView.Columns[9].Visible = false;
            dgvGridView.Columns[10].Visible = false;
            dgvGridView.Columns[11].Visible = false;
            dgvGridView.Columns[12].Visible = false;
            dgvGridView.Columns[13].Visible = false;
            dgvGridView.Columns[14].Visible = false;
            dgvGridView.Columns[15].Visible = false;
            if (col16 == 0) { dgvGridView.Columns[16].Visible = false; }
            if (col17 == 0) { dgvGridView.Columns[17].Visible = false; }
            if (col18 == 0) { dgvGridView.Columns[18].Visible = false; }
            if (col19 == 0) { dgvGridView.Columns[19].Visible = false; }
            dgvGridView.Columns[20].Visible = false;
            dgvGridView.Columns[21].Visible = false;
            dgvGridView.Columns[22].Visible = false;
            if (col23 == 0) { dgvGridView.Columns[23].Visible = false; }
            if (col24 == 0) { dgvGridView.Columns[24].Visible = false; }
            if (col25 == 0) { dgvGridView.Columns[25].Visible = false; }
            if (col26 == 0) { dgvGridView.Columns[26].Visible = false; }
            if (col27 == 0) { dgvGridView.Columns[27].Visible = false; }
            if (col28 == 0) { dgvGridView.Columns[28].Visible = false; }
            if (col29 == 0) { dgvGridView.Columns[29].Visible = false; }
            dgvGridView.Columns[30].Visible = false;
            dgvGridView.Columns[31].Visible = false;
            dgvGridView.Columns[32].Visible = false;
            if (col33 == 0) { dgvGridView.Columns[33].Visible = false; }
            dgvGridView.Columns[34].Visible = false;
            dgvGridView.Columns[35].Visible = false;
            dgvGridView.Columns[36].Visible = false;
            dgvGridView.Columns[37].Visible = false;
            if (col38 == 0) { dgvGridView.Columns[38].Visible = false; }
            dgvGridView.Columns[39].Visible = false;
            dgvGridView.Columns[40].Visible = false;
            dgvGridView.Columns[41].Visible = false;
            dgvGridView.Columns[42].Visible = false;
            if (col43 == 0) { dgvGridView.Columns[43].Visible = false; }
            dgvGridView.Columns[44].Visible = false;
            if (col45 == 0) { dgvGridView.Columns[45].Visible = false; }
            if (col46 == 0) { dgvGridView.Columns[46].Visible = false; }
            if (col47 == 0) { dgvGridView.Columns[47].Visible = false; }
            if (col48 == 0) { dgvGridView.Columns[48].Visible = false; }
            dgvGridView.Columns[49].Visible = false;
        }

        private void Kardex_Resize(object sender, EventArgs e)
        {
            dgvGridView.Width = this.Width - dgvOffset;
            dgvGridView.Height = this.Height - dgvOffset2;
        }

        private void btActualizarKardex_Click(object sender, EventArgs e)
        {
            string proveedor, estilo, resp;
            proveedor = MmsWin.Front.Utilerias.VarTem.tmpPrv;
            estilo = MmsWin.Front.Utilerias.VarTem.tmpSty;
            
            string message = "¿La actualizacion sera total? ";
            string caption = "Aviso";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
               {
                resp = "SI";
               }
            else
            {
                resp = "NO";
            }
            this.Cursor = Cursors.WaitCursor;
            MmsWin.Negocio.Convenio.Kardex.GetInstance().ActualizaKardex1(proveedor, estilo, resp);
            this.Cursor = Cursors.Default;
            BindData();
        }

        private void dgvGridView_Sorted(object sender, EventArgs e)
        {
            SetFontAndColors();
            rowStyleColores();
        }

        private void dgvGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            MmsWin.Front.Utilerias.VarTem.tmpAnio = this.dgvGridView.CurrentRow.Cells[0].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpSemana = this.dgvGridView.CurrentRow.Cells[1].Value.ToString();

            dgvGridView.Select();
            dgvGridView.Focus();
            MTDOKardexPorSemana();
        }

        private void MTDOKardexPorSemana()
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Kardex por Semana").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del Kardex por semana ya esta abierta");
                    }
                    else
                    {
                        KardexPorSemana i = new KardexPorSemana();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

    }
}
