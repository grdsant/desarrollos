﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MmsWin.Negocio;
using MmsWin.Negocio.Catalogos;
using MmsWin.Negocio.Utilerias;
using MmsWin.Comun;

namespace MmsWin.Front.Convenio
{
    public partial class Reprog : Form
    {
        #region Variables
        // variables de la Ventana
        public static string xMarca            { get; set; }
        public static string xTemporada        { get; set; }
        public static string xTipoCalificacion { get; set; }
        public static string xFchCalificacion  { get; set; }
        public static string xFchInicial       { get; set; }

        public static string xProveedor     { get; set; }
        public static string xNombre        { get; set; }
        public static string xEstilo        { get; set; }
        public static string xDescripcion   { get; set; }
        public static string xOrdenCompra   { get; set; }
        public static string xCalificacion  { get; set; }
        public static string xFechaRevision { get; set; }

        public static string xFechaReprog   { get; set; }
        public static string xMotivo        { get; set; }
        public static string xObservaciones { get; set; }
        public static string xComprador     { get; set; }
        public static string xNombreComprador { get; set; }
        public static string xNoRepro       { get; set; }

        public static string xTablaAcc      { get; set; }
        #endregion

        public Reprog()
        {
            InitializeComponent();
        }

        private void Reprog_Load(object sender, EventArgs e)
        {

            this.cboMotivo.DataSource = Motivos.CargaMotivos();
            cboMotivo.DisplayMember = "DSCMOV";
            cboMotivo.ValueMember = "MOVOID";

            int contF14 = 0;        // Conteo de reprogramaciones actuales

            this.tbNumReprog.Text = contF14.ToString();

            tbProveedor.Text     = xProveedor;
            tbNombre.Text        = xNombre;
            tbEstilo.Text        = xEstilo;
            tbDescripcion.Text   = xDescripcion;
            txtOrdenCompra.Text  = xOrdenCompra;
         
            txtCalificacion.Text = xCalificacion;         
            tbFchRev.Text        = xFechaRevision;
            tbFchRev.Text = (tbFchRev.Text.Substring(4, 2) + "/" + tbFchRev.Text.Substring(2, 2) + "/20" + tbFchRev.Text.Substring(0, 2));
        }

        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }

        // Aplica Seguridad                                                                         
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }

        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btAceptar_Click(object sender, EventArgs e)
        {

            //eReprogramaciones.Estatus = "A"; //Valor predeterminado
            /*
            * DESARROLLADOR: OCG | 14/12/2016
            * ---------------------------------------------------------------------------------------
            * Validar la selección del motivo
            */
            if (this.cboMotivo.SelectedValue.ToString() == "0")
            {
                MessageBox.Show("ATENCIÓN!\n\nDebe seleccionar un motivo para guardar la reprogramación.", "CONVENIO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            /*
            * DESARROLLADOR: OCG | 14/12/2016
            * ---------------------------------------------------------------------------------------
            * Validar las reglas de la fecha
            */

            //DateTime FechaReprogramacion;
            //DateTime FechaOriginal;

            //DateTimeFormatInfo dfi = DateTimeFormatInfo.CurrentInfo;
            //Calendar cal = dfi.Calendar;

            //int diferenciaSemanas = 0;
            //int semanasPermitidas = 0;
            //DateTime[] fechasExtendidas = new DateTime[2];///Periodo de ampliación a usar si extiende de las semanas permitidas

            //if (DateTime.TryParse(this.tbFchReprog.Text, out FechaReprogramacion) && DateTime.TryParse(this.tbFchRev.Text, out FechaOriginal))
            //{
                //if (FechaReprogramacion < FechaOriginal)
                //{
                //    MessageBox.Show("La fecha de reprogramación no puede ser menor a la fecha original.", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    return;
                //}

                //if (FechaReprogramacion < DateTime.Now)
                //{
                //    MessageBox.Show("La fecha de reprogramación no puede ser menor a la fecha actual.", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //    return;
                //}

                ////Obtener las semanas de diferencia entre las fechas
                //if (FechaReprogramacion.Year == FechaOriginal.Year)
                //{
                //    //Diferencias en el mismo año
                //    diferenciaSemanas = cal.GetWeekOfYear(FechaReprogramacion, dfi.CalendarWeekRule, dfi.FirstDayOfWeek) - cal.GetWeekOfYear(FechaOriginal, dfi.CalendarWeekRule, dfi.FirstDayOfWeek);
                //}
                //else if (FechaReprogramacion.Year > FechaOriginal.Year)
                //{
                //    //Diferencias con el siguiente año inmediato
                //    diferenciaSemanas = (52 - cal.GetWeekOfYear(FechaOriginal, dfi.CalendarWeekRule, dfi.FirstDayOfWeek)) + cal.GetWeekOfYear(FechaReprogramacion, dfi.CalendarWeekRule, dfi.FirstDayOfWeek);
                //}
                //else if (FechaReprogramacion.Year < FechaOriginal.Year)
                //{
                //    MessageBox.Show("La fecha de reprogramación no puede ser menor a la fecha actual.",
                //        "Convenio",
                //        MessageBoxButtons.OK,
                //        MessageBoxIcon.Warning);
                //}

                //fechasExtendidas = Negocio.Convenio.Reprogramacion.obtPeriodoSemanasExtendidas(30);

                ////Si se excede de las 4 semanas permitidas
                //if (diferenciaSemanas > semanasPermitidas)
                //{


                //}
            //}
            //else
            //{
            //    MessageBox.Show("ATENCIÓN!\n\nEl formato de alguna de las fechas no es correcto.", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //    return;
            //}


            string fchReprog;
            Boolean indFch;
            string NomDiaSem;
            fchReprog = tbFchReprog.Text;
            indFch = MmsWin.Negocio.Utilerias.Utilerias.fecha(fchReprog);
            if (indFch == true)
            {
                // Obtiene el nombre de dia de la semana y debe ser Lunes                 
                NomDiaSem = MmsWin.Negocio.Utilerias.Utilerias.NombreDiaSem(fchReprog);
                if (NomDiaSem == "lunes")
                {
                    string FchIniString = MmsWin.Front.Utilerias.VarTem.tmpFchInicial;
                    Int32 FchIniInt = Convert.ToInt32(FchIniString);
                    string FchRprgString = tbFchReprog.Text;
                    Int32 FchRprInt = Convert.ToInt32(FchRprgString.Substring(8, 2) + FchRprgString.Substring(3, 2) + FchRprgString.Substring(0, 2));
                    if (FchIniInt < FchRprInt)
                    {
                        this.Cursor = Cursors.WaitCursor;

                        string PrvRpr = tbProveedor.Text;
                        string NomRpr = tbNombre.Text;
                        string StyRpr = tbEstilo.Text;
                        string DesRpr = tbDescripcion.Text;
                        string FchRevRpr = tbFchRev.Text;
                        //FchRevRpr = FchRevRpr.Substring(8, 2) + FchRevRpr.Substring(3, 2) + FchRevRpr.Substring(0, 2);
                        string FchRprRpr = tbFchReprog.Text;
                        FchRprRpr = FchRprRpr.Substring(8, 2) + FchRprRpr.Substring(3, 2) + FchRprRpr.Substring(0, 2);
                        string CompDesc = tbCompDesc.Text;
                        string ObsRpr = tbObservacion.Text;

                        string MarcaRpr = MmsWin.Front.Utilerias.VarTem.tmpMarca;
                        string CompradorRpr = MmsWin.Front.Utilerias.VarTem.tmpComprador;

                        string FechaRpr = DateTime.Now.ToString("dd/MM/yyyy");
                        FechaRpr = FechaRpr.Substring(8, 2) + FechaRpr.Substring(3, 2) + FechaRpr.Substring(0, 2);
                        string HoraRpr = DateTime.Now.ToString("HH:mm:ss");
                        HoraRpr = HoraRpr.Substring(0, 2) + HoraRpr.Substring(3, 2) + HoraRpr.Substring(6, 2);

                        string UsrRpr = MmsWin.Front.Utilerias.VarTem.tmpUser;

                        //Guardar la reprogramación
                        string orden = txtOrdenCompra.Text;
                        tbObservacion.Text = tbObservacion.Text;

                        string idMotivo = this.cboMotivo.SelectedValue.ToString();
                        xFechaReprog = tbFchReprog.Text.Substring(8, 2) + tbFchReprog.Text.Substring(3, 2) + tbFchReprog.Text.Substring(0, 2);
                        MmsWin.Negocio.Convenio.Reprog.GetInstance().WriteReprog1(xProveedor, xNombre, xEstilo, xDescripcion, xFechaRevision, xFechaReprog, xNombreComprador, tbObservacion.Text, xMarca, xComprador, FechaRpr, HoraRpr, UsrRpr, xOrdenCompra, idMotivo, " ");

                        Int32 NoProveedor = 0;
                        int Fecha400 = 0;

                        Int32.TryParse(PrvRpr, out NoProveedor);
                        Int32.TryParse(FchRevRpr, out Fecha400);

                        MessageBox.Show("Reprogramacion exitosa.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        this.Close();

                        this.Cursor = Cursors.Default;
                    }
                    else
                    {
                        MessageBox.Show("ATENCIÓN!\n\nLa fecha debe ser posterior a la última revisión.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("ATENCIÓN!\n\nSolo se permite los dias Lunes.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            // La fecha es Erronea                                                        
            if (indFch == false)
            {
                MessageBox.Show("ATENCIÓN!\n\nLa fecha es incorrecta.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void tbFchReprog_Click(object sender, EventArgs e)
        {
            mcCal01.Visible = true;
        }

        private void mcCal01_Leave(object sender, EventArgs e)
        {
            mcCal01.Visible = false;
        }

        private void Reprog_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Escape)
            {
                mcCal01.Visible = false;
            }
        }

        private void mcCal01_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Escape)
            {
                mcCal01.Visible = false;
            }
        }

        private void mcCal01_DateSelected(object sender, DateRangeEventArgs e)
        {
            string NomDiaSem = "";
            //string fchReprog;
            tbFchReprog.Text = mcCal01.SelectionEnd.ToShortDateString();
            DateTime fechaSel = Convert.ToDateTime(tbFchReprog.Text);
            mcCal01.Visible = false;
            
            // Obtiene el nombre de dia de la semana y debe ser Lunes                 
            //fchReprog = tbFchReprog.Text;

            NomDiaSem = MmsWin.Negocio.Utilerias.Utilerias.NombreDiaSem(mcCal01.SelectionEnd.ToShortDateString());

            if (NomDiaSem != "lunes")
            {
                MessageBox.Show("ATENCIÓN!\n\nSolo se permiten los dias lunes.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                tbFchReprog.Text = "";
            }
            else
            {
                string StyMarca = MmsWin.Front.Utilerias.VarTem.tmpMarca;

                foreach (DataRow row in MmsWin.Front.Utilerias.VarTem.BkConfiguracion.Rows)
                {
                    string marcaN = row["MARMID"].ToString();
                    if (marcaN == StyMarca)
                    {
                        try
                        {
                            Double NoSem = Convert.ToDouble(row["MARSAR"].ToString());
                         //   DateTime fecha = Convert.ToDateTime(tbFchRev.Text); // , new CultureInfo("es-ES"));
                            // fecha = fecha.AddDays(NoSem * 7);
                            DateTime fecha;
                            fecha = fechaSel.AddDays(NoSem * 7);
                            string fechaText = fecha.ToString("yyyyMMdd");
                            Int32 FchHasta = Convert.ToInt32(fechaText);
                            string fchSelText = fechaSel.ToString("yyyyMMdd");
                            Int32 fchContra = Convert.ToInt32(fchSelText);

                            //string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;

                            if (fchContra > FchHasta)
                            {
                                MessageBox.Show("ATENCIÓN!\n\nLa fecha es mayor a las " + NoSem + " semanas configuradas.\n", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                //tbFchReprog.Text = "";
                            }
                        }
                        catch {
                            MessageBox.Show("Error de Fecha", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
        }

        private void tbProveedor_TextChanged(object sender, EventArgs e)
        {

        }

        private void Reprog_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                //CargaSeguridad("Convenio", "Reprog", eReprogramaciones.Usuario);
            }
        }

        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }     

    }
}
