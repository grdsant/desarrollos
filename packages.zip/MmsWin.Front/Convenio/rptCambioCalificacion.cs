﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class rptCambioCalificacion : Form
    {
        public int Folio { get; set; }
        public rptCambioCalificacion()
        {
            InitializeComponent();
        }

        private void rptCambioCalificacion_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dsSAT177MMNETLIB.SAT177SCCRV1' Puede moverla o quitarla según sea necesario.
            this.sAT177SCCRV1TableAdapter.Fill(this.dsSAT177MMNETLIB.SAT177SCCRV1, Folio);

            this.reportViewer1.RefreshReport();
        }
    }
}
