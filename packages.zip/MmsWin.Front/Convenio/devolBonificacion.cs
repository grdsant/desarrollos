﻿using MmsWin.Negocio.Catalogos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front
{
    public partial class devolBonificacion : Form
    {
        #region " Variables Globales "

        //public string penalizacionMov { get; set; }

        //private static string fecharevicion = string.Empty;
        //private static string marca = string.Empty;
        private static string penalizacion = string.Empty;

        public Entidades.Reprogramaciones eReprogramaciones = new Entidades.Reprogramaciones();

        #endregion

        #region Metodo de  la clase "
        public devolBonificacion()
        {
            InitializeComponent();
        }
        #endregion

        #region "Page Load "
        private void devolBonificacion_Load(object sender, EventArgs e)
        {
            this.lblNumProg.Text = "0"; //Valor asignado por defecto

            this.cboMotivo.DataSource = Motivos.CargaMotivosDSB();
            cboMotivo.DisplayMember = "DSCMOV";
            cboMotivo.ValueMember = "MOVOID";

            this.cboMotivo.SelectedValue = "0";

            //fecharevicion = MmsWin.Front.Utilerias.VarTem.tmpFchRev;
            this.lblDescProveedor.Text = eReprogramaciones.ProveedorID;
            this.lblNombreProv.Text = eReprogramaciones.Proveedor;
            this.lblidEstilo.Text = eReprogramaciones.EstiloID;

            this.lblDescEstilo.Text = eReprogramaciones.Estilo;
            this.lblCompradorDesc.Text = eReprogramaciones.Comprador;
            this.lblOnHandDesc.Text = string.Format("{0:###,###,###,###0}", Convert.ToDecimal(eReprogramaciones.OnHand));
            this.lblCostoActDesc.Text = string.Format("{0:###,###,###,###0.00}", Convert.ToDecimal(eReprogramaciones.CostoActual));
            this.lblCostoTotDesc.Text = string.Format("{0:###,###,###,###0}", Convert.ToDecimal(eReprogramaciones.CostoTotal));
          
            this.lblNumProg.Text = eReprogramaciones.NoEventos;

            this.lblDescMarca.Text = eReprogramaciones.MarcaID == "10" ? "MELODY" : eReprogramaciones.MarcaID == "30" ? "MILANO" : "KALTEX";
            
            this.lblTemporada.Text = eReprogramaciones.Temporada;
            this.lblOCDesc.Text = eReprogramaciones.OrdenCompra;

            penalizacion = MmsWin.Negocio.Convenio.Convenio.GetInstance().obtenPenalizacionBon(eReprogramaciones.MarcaID);

            this.lblPenalizacion.Text = penalizacion + " % ";

            this.lblPorDesc.Text = string.Format("{0:###,###,###,###0.00}", Convert.ToDecimal(eReprogramaciones.CostoTotal) * (Convert.ToDecimal(penalizacion) / 100));
        }
        #endregion

        #region "Guarda el tipo de motivo de penalizacion que se muestra "
        private void btAceptar_Click(object sender, EventArgs e)
        {
            if (this.cboMotivo.SelectedValue.ToString() == "0")
            {
                MessageBox.Show("Debe seleccionar un motivo para guardar la Devolución por Bonificación", "Devolución por Bonificación", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            //if (cbPagar.Checked == true)
            //{
                
            //}

            //string idEstilo = this.lblidEstilo.Text.Trim().ToUpper();
            //string idProv = this.lblDescProveedor.Text.Trim().ToUpper();
            //string ordenCompra = this.lblOCDesc.Text.Trim().ToUpper();
            //string penaliza = penalizacion;
            if (this.lblNumProg.Text.Trim() == "")
            {
                this.lblNumProg.Text = "0";
            }
            string noEvento = Convert.ToString(int.Parse(this.lblNumProg.Text) + 1);
            //string estatus = "T";
            //string usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
            //string temp = this.lblTemporada.Text;
            //string motivo = this.cboMotivo.SelectedValue.ToString();
            //string montoPena = this.lblPorDesc.Text.Split('%')[0];
            //string calDirecta = cbPagar.Checked == true ? "P a g a r" : ""; 

            bool ejecuta = MmsWin.Negocio.Convenio.Convenio.GetInstance().insertNuevaDevolucionBon(
                                eReprogramaciones.EstiloID, 
                                eReprogramaciones.ProveedorID, 
                                eReprogramaciones.OrdenCompra, 
                                eReprogramaciones.MarcaID,
                                penalizacion,
                                (this.lblPorDesc.Text.Split('%')[0]),
                                this.cboMotivo.SelectedValue.ToString(), 
                                "T" ,
                                noEvento, 
                                eReprogramaciones.intFechaRevision, 
                                eReprogramaciones.Usuario, 
                                eReprogramaciones.Temporada, 
                                (cbPagar.Checked == true ? "P a g a r" : ""));

            if (ejecuta == true)
            {
                MessageBox.Show("La devolución por bonificación se guardo correctamente.\n !Recuerda generar tu formato para firma.¡", "Devolución por Bonificación", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.Close();
            }
            else
            {
                MessageBox.Show("La devolución por bonificación no fue generada, por favor reintentar, \n si el problema perciste comucate a soporte.", "Devolución por Bonificación", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        #endregion

        #region " Cierra el formulario de la devolución"
        private void btCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

      
    }
}
