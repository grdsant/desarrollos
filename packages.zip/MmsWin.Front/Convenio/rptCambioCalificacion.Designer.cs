﻿namespace MmsWin.Front.Convenio
{
    partial class rptCambioCalificacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.sAT177SCCRV1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsSAT177MMNETLIB = new MmsWin.Front.dsSAT177MMNETLIB();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.sAT177SCCRV1TableAdapter = new MmsWin.Front.dsSAT177MMNETLIBTableAdapters.SAT177SCCRV1TableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.sAT177SCCRV1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSAT177MMNETLIB)).BeginInit();
            this.SuspendLayout();
            // 
            // sAT177SCCRV1BindingSource
            // 
            this.sAT177SCCRV1BindingSource.DataMember = "SAT177SCCRV1";
            this.sAT177SCCRV1BindingSource.DataSource = this.dsSAT177MMNETLIB;
            // 
            // dsSAT177MMNETLIB
            // 
            this.dsSAT177MMNETLIB.DataSetName = "dsSAT177MMNETLIB";
            this.dsSAT177MMNETLIB.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "SAT177SCCRV1";
            reportDataSource1.Value = this.sAT177SCCRV1BindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "MmsWin.Front.Convenio.rptCambioCalificacion.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ShowExportButton = false;
            this.reportViewer1.Size = new System.Drawing.Size(865, 459);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.FullPage;
            // 
            // sAT177SCCRV1TableAdapter
            // 
            this.sAT177SCCRV1TableAdapter.ClearBeforeFill = true;
            // 
            // rptCambioCalificacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(865, 459);
            this.Controls.Add(this.reportViewer1);
            this.Name = "rptCambioCalificacion";
            this.Text = "rptCambioCalificacion";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.rptCambioCalificacion_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sAT177SCCRV1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSAT177MMNETLIB)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private dsSAT177MMNETLIB dsSAT177MMNETLIB;
        private System.Windows.Forms.BindingSource sAT177SCCRV1BindingSource;
        private dsSAT177MMNETLIBTableAdapters.SAT177SCCRV1TableAdapter sAT177SCCRV1TableAdapter;
    }
}