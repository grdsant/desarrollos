﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class KardexPorDia : Form
    {
        int dgvOffset;
        int dgvOffset2;

        public KardexPorDia()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }

        private void Kardex_Load(object sender, EventArgs e)
        {
            BindData();
        }

        private void BindData()
        {
            this.Cursor = Cursors.WaitCursor;

            dgvGridView.DataSource = null;
            System.Data.DataTable Kardex = null;
            try
            {
                string proveedor = MmsWin.Front.Utilerias.VarTem.tmpPrv;
                string estilo  = MmsWin.Front.Utilerias.VarTem.tmpSty;
                string usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                string anio    = MmsWin.Front.Utilerias.VarTem.tmpAnio;
                string semana  = MmsWin.Front.Utilerias.VarTem.tmpSemana;
                string tipo    = MmsWin.Front.Utilerias.VarTem.tmpTipo;

                Kardex = MmsWin.Negocio.Convenio.Kardex.GetInstance().ObtenKardex1PorDia(proveedor, estilo, anio, semana, tipo, usuario);
                string transito = string.Empty;
                string onHand   = string.Empty;
                string OnHnadtransito = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenOnHandTransito1(proveedor, estilo, out onHand, out transito);
                btOnHandDat.Text = string.Format("{0:n0}", double.Parse(onHand));
                btTransitoDat.Text = string.Format("{0:n0}", double.Parse(transito));
                btInventarioTotDat.Text = string.Format("{0:n0}", double.Parse(OnHnadtransito));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (Kardex.Rows.Count > 0)
            {
                string proveedor = MmsWin.Front.Utilerias.VarTem.tmpPrv;
                string estilo = MmsWin.Front.Utilerias.VarTem.tmpSty;
                dgvGridView.DataSource = Kardex;
                int nr = dgvGridView.RowCount;
                this.Text = "Kardex por Día/ " + " " + (nr).ToString() + " Registro(s)" + "  / " + "Proveedor: " + proveedor + "   Estilo: "  + estilo ;
                SetFontAndColors();
                rowStyle();
                SetDoubleBuffered(dgvGridView);
            }
            this.Cursor = Cursors.Default;
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvGridView.Columns[3].Frozen = true;

            dgvGridView.Columns[0].HeaderText = "Año";
            dgvGridView.Columns[1].HeaderText = "Semana";
            dgvGridView.Columns[2].HeaderText = "Fecha";
            dgvGridView.Columns[3].HeaderText = "Tipo";
            dgvGridView.Columns[4].HeaderText = "Piezas";

            dgvGridView.Columns[0].Width = 50;
            dgvGridView.Columns[1].Width = 50;
            dgvGridView.Columns[2].Width = 80;
            dgvGridView.Columns[3].Width = 50;
            dgvGridView.Columns[4].Width = 80;

            dgvGridView.Columns[0].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[1].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[2].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[3].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[4].DefaultCellStyle.NullValue = true;

            dgvGridView.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgvGridView.Columns[0].DefaultCellStyle.Format = "##";
            dgvGridView.Columns[1].DefaultCellStyle.Format = "##";
            dgvGridView.Columns[2].DefaultCellStyle.Format = "20##-##-##";

            dgvGridView.Columns[4].DefaultCellStyle.Format = "#,###,###";

            dgvGridView.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[1].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[2].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[3].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[4].HeaderCell.Style.BackColor = Color.LightSalmon;
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }

            }
        }

        private void Kardex_Resize(object sender, EventArgs e)
        {
            dgvGridView.Width = this.Width - dgvOffset;
            dgvGridView.Height = this.Height - dgvOffset2;
        }

        private void btActualizarKardex_Click(object sender, EventArgs e)
        {
            string proveedor, estilo, resp;
            proveedor = MmsWin.Front.Utilerias.VarTem.tmpPrv;
            estilo = MmsWin.Front.Utilerias.VarTem.tmpSty;
            
            string message = "¿La actualizacion sera total? ";
            string caption = "Aviso";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
               {
                resp = "SI";
               }
            else
            {
                resp = "NO";
            }
            this.Cursor = Cursors.WaitCursor;
            MmsWin.Negocio.Convenio.Kardex.GetInstance().ActualizaKardex1(proveedor, estilo, resp);
            this.Cursor = Cursors.Default;
            BindData();
        }

        private void dgvGridView_Sorted(object sender, EventArgs e)
        {
            SetFontAndColors();
            rowStyle();
        }

        private void dgvGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            MmsWin.Front.Utilerias.VarTem.tmpAnio = this.dgvGridView.CurrentRow.Cells[0].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpSemana = this.dgvGridView.CurrentRow.Cells[1].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpTipo = this.dgvGridView.CurrentRow.Cells[3].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpFechaTipo = this.dgvGridView.CurrentRow.Cells[2].Value.ToString();

            dgvGridView.Select();
            dgvGridView.Focus();
            MTDOKardexPorSku();
        }

        private void MTDOKardexPorSku()
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Kardex por Sku y Tienda").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del Kardex por Sku y Tienda ya esta abierta");
                    }
                    else
                    {
                        KardexPorSku i = new KardexPorSku();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }
    }
}
