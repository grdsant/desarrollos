﻿namespace MmsWin.Front.Convenio
{
    partial class Convenio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Convenio));
            this.dgvConvenio = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripMenuItem();
            this.devoluciónVsBonificaciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.camCalificacionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bonificaADecoluciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reprogramacionTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripMenuItem();
            this.devolucionTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.FotoTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.notaDeCréditoTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.actualizarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultaNCPDFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cbCompradores = new System.Windows.Forms.ComboBox();
            this.pgbProg = new System.Windows.Forms.ProgressBar();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.gbMarca = new System.Windows.Forms.GroupBox();
            this.gbCompradores = new System.Windows.Forms.GroupBox();
            this.gbRangoFecha = new System.Windows.Forms.GroupBox();
            this.lblHasta = new System.Windows.Forms.Label();
            this.lblDesde = new System.Windows.Forms.Label();
            this.tbHasta = new System.Windows.Forms.TextBox();
            this.tbDesde = new System.Windows.Forms.TextBox();
            this.gbTemporada = new System.Windows.Forms.GroupBox();
            this.ddlTemporada = new System.Windows.Forms.ComboBox();
            this.gbOrigen = new System.Windows.Forms.GroupBox();
            this.cbOrigen = new System.Windows.Forms.ComboBox();
            this.gbReprogramados = new System.Windows.Forms.GroupBox();
            this.cbReprogramacion = new System.Windows.Forms.ComboBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbProveedor = new System.Windows.Forms.TextBox();
            this.Relleno = new System.Windows.Forms.TextBox();
            this.tbRelleno02 = new System.Windows.Forms.TextBox();
            this.tsToolStrip = new System.Windows.Forms.ToolStrip();
            this.pbExcel = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.pbBuscar = new System.Windows.Forms.ToolStripButton();
            this.tss1 = new System.Windows.Forms.ToolStripSeparator();
            this.btCheckBox = new System.Windows.Forms.ToolStripButton();
            this.tss2 = new System.Windows.Forms.ToolStripSeparator();
            this.btCheckBox2 = new System.Windows.Forms.ToolStripButton();
            this.tss3 = new System.Windows.Forms.ToolStripSeparator();
            this.btnReportes = new System.Windows.Forms.ToolStripSplitButton();
            this.notasDeCredito = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.btnPreautorizadas1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.miRptBonificacionAnticipada = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.tablaDeAcción10ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tss4 = new System.Windows.Forms.ToolStripSeparator();
            this.btSimulador = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.lblFechas = new System.Windows.Forms.ToolStripLabel();
            this.cboFechas = new System.Windows.Forms.ToolStripComboBox();
            this.gvTemporada = new System.Windows.Forms.DataGridView();
            this.mcC1 = new System.Windows.Forms.MonthCalendar();
            this.mcC2 = new System.Windows.Forms.MonthCalendar();
            this.gpbExcepciones2 = new System.Windows.Forms.GroupBox();
            this.cboExcepciones2 = new System.Windows.Forms.ComboBox();
            this.cmSimulador = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.oPCIONESSIMULADORToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.miBonificacionAnticipada = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dgvConvenio)).BeginInit();
            this.cmMenu.SuspendLayout();
            this.gbMarca.SuspendLayout();
            this.gbCompradores.SuspendLayout();
            this.gbRangoFecha.SuspendLayout();
            this.gbTemporada.SuspendLayout();
            this.gbOrigen.SuspendLayout();
            this.gbReprogramados.SuspendLayout();
            this.tsToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvTemporada)).BeginInit();
            this.gpbExcepciones2.SuspendLayout();
            this.cmSimulador.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvConvenio
            // 
            this.dgvConvenio.AllowUserToAddRows = false;
            this.dgvConvenio.AllowUserToDeleteRows = false;
            this.dgvConvenio.AllowUserToOrderColumns = true;
            this.dgvConvenio.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvConvenio.ContextMenuStrip = this.cmMenu;
            this.dgvConvenio.Location = new System.Drawing.Point(1, 118);
            this.dgvConvenio.Name = "dgvConvenio";
            this.dgvConvenio.Size = new System.Drawing.Size(1014, 398);
            this.dgvConvenio.TabIndex = 0;
            this.dgvConvenio.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvConvenio_CellClick);
            this.dgvConvenio.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvConvenio_CellDoubleClick_1);
            this.dgvConvenio.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvConvenio_CellMouseDown);
            this.dgvConvenio.CellParsing += new System.Windows.Forms.DataGridViewCellParsingEventHandler(this.dgvConvenio_CellParsing);
            this.dgvConvenio.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvConvenio_DataError);
            this.dgvConvenio.SelectionChanged += new System.EventHandler(this.dgvConvenio_SelectionChanged);
            this.dgvConvenio.Sorted += new System.EventHandler(this.dgvConvenio_Sorted);
            this.dgvConvenio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dgvConvenio_KeyPress);
            this.dgvConvenio.KeyUp += new System.Windows.Forms.KeyEventHandler(this.clbTemporada_KeyUp);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator5,
            this.devoluciónVsBonificaciónToolStripMenuItem,
            this.camCalificacionToolStripMenuItem,
            this.bonificaADecoluciónToolStripMenuItem,
            this.reprogramacionTSMI,
            this.toolStripSeparator4,
            this.devolucionTSMI,
            this.FotoTSMI,
            this.notaDeCréditoTSMI,
            this.toolStripSeparator3,
            this.actualizarToolStripMenuItem,
            this.consultaNCPDFToolStripMenuItem});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(225, 252);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.BackColor = System.Drawing.Color.LightGray;
            this.toolStripSeparator5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.toolStripSeparator5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(224, 22);
            this.toolStripSeparator5.Text = "           EXCEPCIONES";
            // 
            // devoluciónVsBonificaciónToolStripMenuItem
            // 
            this.devoluciónVsBonificaciónToolStripMenuItem.Name = "devoluciónVsBonificaciónToolStripMenuItem";
            this.devoluciónVsBonificaciónToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.devoluciónVsBonificaciónToolStripMenuItem.Text = "Bonificación por devolución";
            this.devoluciónVsBonificaciónToolStripMenuItem.Click += new System.EventHandler(this.devoluciónVsBonificaciónToolStripMenuItem_Click);
            // 
            // camCalificacionToolStripMenuItem
            // 
            this.camCalificacionToolStripMenuItem.Name = "camCalificacionToolStripMenuItem";
            this.camCalificacionToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.camCalificacionToolStripMenuItem.Text = "Cambio calificación";
            this.camCalificacionToolStripMenuItem.Click += new System.EventHandler(this.camCalificacionToolStripMenuItem_Click);
            // 
            // bonificaADecoluciónToolStripMenuItem
            // 
            this.bonificaADecoluciónToolStripMenuItem.Name = "bonificaADecoluciónToolStripMenuItem";
            this.bonificaADecoluciónToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.bonificaADecoluciónToolStripMenuItem.Text = "Devolución por bonificación";
            this.bonificaADecoluciónToolStripMenuItem.Click += new System.EventHandler(this.bonificaADecoluciónToolStripMenuItem_Click);
            // 
            // reprogramacionTSMI
            // 
            this.reprogramacionTSMI.Name = "reprogramacionTSMI";
            this.reprogramacionTSMI.Size = new System.Drawing.Size(224, 22);
            this.reprogramacionTSMI.Text = "Reprogramación";
            this.reprogramacionTSMI.Click += new System.EventHandler(this.reprogramacionTSMI_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.BackColor = System.Drawing.Color.LightGray;
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(224, 22);
            this.toolStripSeparator4.Text = "                 OTROS";
            // 
            // devolucionTSMI
            // 
            this.devolucionTSMI.Name = "devolucionTSMI";
            this.devolucionTSMI.Size = new System.Drawing.Size(224, 22);
            this.devolucionTSMI.Text = "Devolución";
            this.devolucionTSMI.Visible = false;
            this.devolucionTSMI.Click += new System.EventHandler(this.devolucionTSMI_Click);
            // 
            // FotoTSMI
            // 
            this.FotoTSMI.Name = "FotoTSMI";
            this.FotoTSMI.Size = new System.Drawing.Size(224, 22);
            this.FotoTSMI.Text = "Foto";
            this.FotoTSMI.Click += new System.EventHandler(this.fotoToolStripMenuItem_Click);
            // 
            // notaDeCréditoTSMI
            // 
            this.notaDeCréditoTSMI.Name = "notaDeCréditoTSMI";
            this.notaDeCréditoTSMI.Size = new System.Drawing.Size(224, 22);
            this.notaDeCréditoTSMI.Text = "Nota de crédito";
            this.notaDeCréditoTSMI.Click += new System.EventHandler(this.notaDeCréditoTSMI_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(221, 6);
            // 
            // actualizarToolStripMenuItem
            // 
            this.actualizarToolStripMenuItem.Name = "actualizarToolStripMenuItem";
            this.actualizarToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.actualizarToolStripMenuItem.Text = "Actualizar";
            this.actualizarToolStripMenuItem.Click += new System.EventHandler(this.actualizarToolStripMenuItem_Click);
            // 
            // consultaNCPDFToolStripMenuItem
            // 
            this.consultaNCPDFToolStripMenuItem.Name = "consultaNCPDFToolStripMenuItem";
            this.consultaNCPDFToolStripMenuItem.Size = new System.Drawing.Size(224, 22);
            this.consultaNCPDFToolStripMenuItem.Text = "Consulta NC PDF";
            this.consultaNCPDFToolStripMenuItem.Click += new System.EventHandler(this.consultaNCPDFToolStripMenuItem_Click);
            // 
            // cbCompradores
            // 
            this.cbCompradores.FormattingEnabled = true;
            this.cbCompradores.Location = new System.Drawing.Point(5, 19);
            this.cbCompradores.Name = "cbCompradores";
            this.cbCompradores.Size = new System.Drawing.Size(128, 21);
            this.cbCompradores.TabIndex = 4;
            this.cbCompradores.SelectedIndexChanged += new System.EventHandler(this.cbCompradores_SelectedIndexChanged);
            this.cbCompradores.SelectedValueChanged += new System.EventHandler(this.cbCompradores_SelectedValueChanged);
            // 
            // pgbProg
            // 
            this.pgbProg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pgbProg.Location = new System.Drawing.Point(1, 553);
            this.pgbProg.Name = "pgbProg";
            this.pgbProg.Size = new System.Drawing.Size(1111, 10);
            this.pgbProg.TabIndex = 10;
            this.pgbProg.Visible = false;
            // 
            // cbMarca
            // 
            this.cbMarca.FormattingEnabled = true;
            this.cbMarca.Location = new System.Drawing.Point(5, 19);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(52, 21);
            this.cbMarca.TabIndex = 11;
            this.cbMarca.SelectedValueChanged += new System.EventHandler(this.cbMarca_SelectedValueChanged);
            // 
            // gbMarca
            // 
            this.gbMarca.Controls.Add(this.cbMarca);
            this.gbMarca.Location = new System.Drawing.Point(6, 45);
            this.gbMarca.Name = "gbMarca";
            this.gbMarca.Size = new System.Drawing.Size(63, 47);
            this.gbMarca.TabIndex = 12;
            this.gbMarca.TabStop = false;
            this.gbMarca.Text = "Marca";
            // 
            // gbCompradores
            // 
            this.gbCompradores.Controls.Add(this.cbCompradores);
            this.gbCompradores.Location = new System.Drawing.Point(70, 45);
            this.gbCompradores.Name = "gbCompradores";
            this.gbCompradores.Size = new System.Drawing.Size(140, 47);
            this.gbCompradores.TabIndex = 13;
            this.gbCompradores.TabStop = false;
            this.gbCompradores.Text = "Comprador";
            // 
            // gbRangoFecha
            // 
            this.gbRangoFecha.Controls.Add(this.lblHasta);
            this.gbRangoFecha.Controls.Add(this.lblDesde);
            this.gbRangoFecha.Controls.Add(this.tbHasta);
            this.gbRangoFecha.Controls.Add(this.tbDesde);
            this.gbRangoFecha.Location = new System.Drawing.Point(212, 45);
            this.gbRangoFecha.Name = "gbRangoFecha";
            this.gbRangoFecha.Size = new System.Drawing.Size(247, 47);
            this.gbRangoFecha.TabIndex = 14;
            this.gbRangoFecha.TabStop = false;
            this.gbRangoFecha.Text = "Rango";
            // 
            // lblHasta
            // 
            this.lblHasta.AutoSize = true;
            this.lblHasta.Location = new System.Drawing.Point(130, 22);
            this.lblHasta.Name = "lblHasta";
            this.lblHasta.Size = new System.Drawing.Size(35, 13);
            this.lblHasta.TabIndex = 38;
            this.lblHasta.Text = "Hasta";
            // 
            // lblDesde
            // 
            this.lblDesde.AutoSize = true;
            this.lblDesde.Location = new System.Drawing.Point(9, 22);
            this.lblDesde.Name = "lblDesde";
            this.lblDesde.Size = new System.Drawing.Size(38, 13);
            this.lblDesde.TabIndex = 37;
            this.lblDesde.Text = "Desde";
            // 
            // tbHasta
            // 
            this.tbHasta.Location = new System.Drawing.Point(167, 19);
            this.tbHasta.Name = "tbHasta";
            this.tbHasta.ReadOnly = true;
            this.tbHasta.Size = new System.Drawing.Size(74, 20);
            this.tbHasta.TabIndex = 36;
            this.tbHasta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbHasta.Click += new System.EventHandler(this.tbHasta_Click);
            // 
            // tbDesde
            // 
            this.tbDesde.Location = new System.Drawing.Point(50, 19);
            this.tbDesde.Name = "tbDesde";
            this.tbDesde.ReadOnly = true;
            this.tbDesde.Size = new System.Drawing.Size(76, 20);
            this.tbDesde.TabIndex = 35;
            this.tbDesde.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbDesde.Click += new System.EventHandler(this.tbDesde_Click);
            // 
            // gbTemporada
            // 
            this.gbTemporada.BackColor = System.Drawing.Color.Transparent;
            this.gbTemporada.Controls.Add(this.ddlTemporada);
            this.gbTemporada.Location = new System.Drawing.Point(465, 45);
            this.gbTemporada.Name = "gbTemporada";
            this.gbTemporada.Size = new System.Drawing.Size(131, 47);
            this.gbTemporada.TabIndex = 14;
            this.gbTemporada.TabStop = false;
            this.gbTemporada.Text = "Temporada";
            this.gbTemporada.Visible = false;
            // 
            // ddlTemporada
            // 
            this.ddlTemporada.BackColor = System.Drawing.Color.GhostWhite;
            this.ddlTemporada.FormattingEnabled = true;
            this.ddlTemporada.Location = new System.Drawing.Point(6, 19);
            this.ddlTemporada.Name = "ddlTemporada";
            this.ddlTemporada.Size = new System.Drawing.Size(119, 21);
            this.ddlTemporada.TabIndex = 24;
            this.ddlTemporada.SelectedValueChanged += new System.EventHandler(this.comboBox1_SelectedValueChanged);
            // 
            // gbOrigen
            // 
            this.gbOrigen.BackColor = System.Drawing.Color.Transparent;
            this.gbOrigen.Controls.Add(this.cbOrigen);
            this.gbOrigen.Location = new System.Drawing.Point(602, 44);
            this.gbOrigen.Name = "gbOrigen";
            this.gbOrigen.Size = new System.Drawing.Size(70, 47);
            this.gbOrigen.TabIndex = 23;
            this.gbOrigen.TabStop = false;
            this.gbOrigen.Text = "Origen";
            this.gbOrigen.Visible = false;
            // 
            // cbOrigen
            // 
            this.cbOrigen.BackColor = System.Drawing.Color.GhostWhite;
            this.cbOrigen.FormattingEnabled = true;
            this.cbOrigen.Location = new System.Drawing.Point(3, 18);
            this.cbOrigen.Name = "cbOrigen";
            this.cbOrigen.Size = new System.Drawing.Size(63, 21);
            this.cbOrigen.TabIndex = 23;
            // 
            // gbReprogramados
            // 
            this.gbReprogramados.Controls.Add(this.cbReprogramacion);
            this.gbReprogramados.Location = new System.Drawing.Point(678, 44);
            this.gbReprogramados.Name = "gbReprogramados";
            this.gbReprogramados.Size = new System.Drawing.Size(133, 45);
            this.gbReprogramados.TabIndex = 27;
            this.gbReprogramados.TabStop = false;
            this.gbReprogramados.Text = "Reprogramados";
            this.gbReprogramados.Visible = false;
            // 
            // cbReprogramacion
            // 
            this.cbReprogramacion.BackColor = System.Drawing.Color.GhostWhite;
            this.cbReprogramacion.FormattingEnabled = true;
            this.cbReprogramacion.Location = new System.Drawing.Point(6, 17);
            this.cbReprogramacion.Name = "cbReprogramacion";
            this.cbReprogramacion.Size = new System.Drawing.Size(117, 21);
            this.cbReprogramacion.TabIndex = 27;
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDescripcion.Location = new System.Drawing.Point(353, 97);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(201, 20);
            this.tbDescripcion.TabIndex = 4;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress);
            // 
            // tbEstilo
            // 
            this.tbEstilo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbEstilo.Location = new System.Drawing.Point(288, 97);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(65, 20);
            this.tbEstilo.TabIndex = 3;
            this.tbEstilo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbEstilo_KeyPress);
            // 
            // tbNombre
            // 
            this.tbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNombre.Location = new System.Drawing.Point(89, 97);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(199, 20);
            this.tbNombre.TabIndex = 2;
            this.tbNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNombre_KeyPress);
            // 
            // tbProveedor
            // 
            this.tbProveedor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbProveedor.Location = new System.Drawing.Point(43, 97);
            this.tbProveedor.Name = "tbProveedor";
            this.tbProveedor.Size = new System.Drawing.Size(46, 20);
            this.tbProveedor.TabIndex = 1;
            this.tbProveedor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbProveedor_KeyPress);
            // 
            // Relleno
            // 
            this.Relleno.Enabled = false;
            this.Relleno.Location = new System.Drawing.Point(1, 97);
            this.Relleno.Name = "Relleno";
            this.Relleno.Size = new System.Drawing.Size(42, 20);
            this.Relleno.TabIndex = 32;
            // 
            // tbRelleno02
            // 
            this.tbRelleno02.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbRelleno02.Enabled = false;
            this.tbRelleno02.Location = new System.Drawing.Point(554, 97);
            this.tbRelleno02.Name = "tbRelleno02";
            this.tbRelleno02.Size = new System.Drawing.Size(465, 20);
            this.tbRelleno02.TabIndex = 33;
            // 
            // tsToolStrip
            // 
            this.tsToolStrip.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.tsToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pbExcel,
            this.toolStripSeparator1,
            this.pbBuscar,
            this.tss1,
            this.btCheckBox,
            this.tss2,
            this.btCheckBox2,
            this.tss3,
            this.btnReportes,
            this.tss4,
            this.btSimulador,
            this.toolStripSeparator2,
            this.lblFechas,
            this.cboFechas});
            this.tsToolStrip.Location = new System.Drawing.Point(0, 0);
            this.tsToolStrip.Name = "tsToolStrip";
            this.tsToolStrip.Size = new System.Drawing.Size(1020, 39);
            this.tsToolStrip.TabIndex = 39;
            this.tsToolStrip.Text = "toolStrip1";
            // 
            // pbExcel
            // 
            this.pbExcel.AutoSize = false;
            this.pbExcel.Image = global::MmsWin.Front.Properties.Resources.excel_32x32;
            this.pbExcel.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pbExcel.Name = "pbExcel";
            this.pbExcel.Size = new System.Drawing.Size(100, 36);
            this.pbExcel.Text = "Exportar";
            this.pbExcel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.pbExcel.ToolTipText = "Exportar los datos a Excel";
            this.pbExcel.Click += new System.EventHandler(this.pbExcel_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // pbBuscar
            // 
            this.pbBuscar.AutoSize = false;
            this.pbBuscar.Image = global::MmsWin.Front.Properties.Resources.calendar_32x32;
            this.pbBuscar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pbBuscar.Name = "pbBuscar";
            this.pbBuscar.Size = new System.Drawing.Size(170, 36);
            this.pbBuscar.Text = "Reprogramaciones";
            this.pbBuscar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.pbBuscar.ToolTipText = "Histórico de Reprogramaciones";
            this.pbBuscar.Click += new System.EventHandler(this.pbBuscar_Click);
            // 
            // tss1
            // 
            this.tss1.Name = "tss1";
            this.tss1.Size = new System.Drawing.Size(6, 39);
            // 
            // btCheckBox
            // 
            this.btCheckBox.AutoSize = false;
            this.btCheckBox.Image = global::MmsWin.Front.Properties.Resources.refresh_32x32;
            this.btCheckBox.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btCheckBox.Name = "btCheckBox";
            this.btCheckBox.Size = new System.Drawing.Size(160, 36);
            this.btCheckBox.Text = "Actualiza obs. chk";
            this.btCheckBox.ToolTipText = "Aztualiza obs. chk";
            this.btCheckBox.Click += new System.EventHandler(this.btCheckBox_Click);
            // 
            // tss2
            // 
            this.tss2.Name = "tss2";
            this.tss2.Size = new System.Drawing.Size(6, 39);
            // 
            // btCheckBox2
            // 
            this.btCheckBox2.AutoSize = false;
            this.btCheckBox2.Image = global::MmsWin.Front.Properties.Resources.check_32x32;
            this.btCheckBox2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btCheckBox2.Name = "btCheckBox2";
            this.btCheckBox2.Size = new System.Drawing.Size(130, 36);
            this.btCheckBox2.Text = "Actualiza chk";
            this.btCheckBox2.ToolTipText = "Actualiza CheckBox";
            this.btCheckBox2.Click += new System.EventHandler(this.btCheckBox2_Click);
            // 
            // tss3
            // 
            this.tss3.Name = "tss3";
            this.tss3.Size = new System.Drawing.Size(6, 39);
            // 
            // btnReportes
            // 
            this.btnReportes.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.notasDeCredito,
            this.toolStripSeparator7,
            this.btnPreautorizadas1,
            this.toolStripMenuItem3,
            this.miRptBonificacionAnticipada,
            this.toolStripSeparator6,
            this.tablaDeAcción10ToolStripMenuItem});
            this.btnReportes.Image = global::MmsWin.Front.Properties.Resources.contract_32x32;
            this.btnReportes.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnReportes.Name = "btnReportes";
            this.btnReportes.Size = new System.Drawing.Size(101, 36);
            this.btnReportes.Text = "Reportes";
            this.btnReportes.ToolTipText = "Reportes de Reprogramaciones";
            // 
            // notasDeCredito
            // 
            this.notasDeCredito.Name = "notasDeCredito";
            this.notasDeCredito.Size = new System.Drawing.Size(289, 22);
            this.notasDeCredito.Text = "Notas de crédito";
            this.notasDeCredito.ToolTipText = "Proceso de Notas de Crédito";
            this.notasDeCredito.Click += new System.EventHandler(this.notasDeCredito_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(286, 6);
            // 
            // btnPreautorizadas1
            // 
            this.btnPreautorizadas1.Name = "btnPreautorizadas1";
            this.btnPreautorizadas1.Size = new System.Drawing.Size(289, 22);
            this.btnPreautorizadas1.Text = "Excepciones reprogramación";
            this.btnPreautorizadas1.ToolTipText = "Excepciones reprogramación";
            this.btnPreautorizadas1.Click += new System.EventHandler(this.btnPreautorizadas_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(289, 22);
            this.toolStripMenuItem3.Text = "Excepciones cambio de calificación";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.btnCamBoni_Click);
            // 
            // miRptBonificacionAnticipada
            // 
            this.miRptBonificacionAnticipada.Name = "miRptBonificacionAnticipada";
            this.miRptBonificacionAnticipada.Size = new System.Drawing.Size(289, 22);
            this.miRptBonificacionAnticipada.Text = "Bonificación parcial con rev. a los 45 días";
            this.miRptBonificacionAnticipada.Click += new System.EventHandler(this.miRptBonificacionAnticipada_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(286, 6);
            // 
            // tablaDeAcción10ToolStripMenuItem
            // 
            this.tablaDeAcción10ToolStripMenuItem.Name = "tablaDeAcción10ToolStripMenuItem";
            this.tablaDeAcción10ToolStripMenuItem.Size = new System.Drawing.Size(289, 22);
            this.tablaDeAcción10ToolStripMenuItem.Text = "Reporte tabla de acción 10";
            this.tablaDeAcción10ToolStripMenuItem.Click += new System.EventHandler(this.btnPlazosDias_Click);
            // 
            // tss4
            // 
            this.tss4.Name = "tss4";
            this.tss4.Size = new System.Drawing.Size(6, 39);
            // 
            // btSimulador
            // 
            this.btSimulador.Image = global::MmsWin.Front.Properties.Resources.pause_button_32x32;
            this.btSimulador.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btSimulador.Name = "btSimulador";
            this.btSimulador.Size = new System.Drawing.Size(136, 36);
            this.btSimulador.Text = "Pre-calificaciones";
            this.btSimulador.ToolTipText = "Simulador";
            this.btSimulador.Click += new System.EventHandler(this.btSimulador_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // lblFechas
            // 
            this.lblFechas.Name = "lblFechas";
            this.lblFechas.Size = new System.Drawing.Size(46, 36);
            this.lblFechas.Text = "Fechas:";
            // 
            // cboFechas
            // 
            this.cboFechas.AutoSize = false;
            this.cboFechas.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboFechas.DropDownWidth = 200;
            this.cboFechas.Name = "cboFechas";
            this.cboFechas.Size = new System.Drawing.Size(121, 23);
            this.cboFechas.SelectedIndexChanged += new System.EventHandler(this.cboFechas_SelectedIndexChanged);
            // 
            // gvTemporada
            // 
            this.gvTemporada.AllowUserToAddRows = false;
            this.gvTemporada.AllowUserToDeleteRows = false;
            this.gvTemporada.AllowUserToOrderColumns = true;
            this.gvTemporada.BackgroundColor = System.Drawing.SystemColors.Control;
            this.gvTemporada.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvTemporada.ContextMenuStrip = this.cmMenu;
            this.gvTemporada.Location = new System.Drawing.Point(0, 118);
            this.gvTemporada.Name = "gvTemporada";
            this.gvTemporada.Size = new System.Drawing.Size(1016, 394);
            this.gvTemporada.TabIndex = 41;
            this.gvTemporada.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvTemporada_CellClick);
            this.gvTemporada.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvConvenio_CellDoubleClick_1);
            this.gvTemporada.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.gvTemporada_CellMouseDown);
            // 
            // mcC1
            // 
            this.mcC1.BackColor = System.Drawing.Color.Gray;
            this.mcC1.ForeColor = System.Drawing.Color.Black;
            this.mcC1.Location = new System.Drawing.Point(90, 118);
            this.mcC1.Name = "mcC1";
            this.mcC1.TabIndex = 42;
            this.mcC1.Visible = false;
            this.mcC1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcC1_DateSelected_1);
            this.mcC1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcC1_KeyUp_1);
            this.mcC1.Leave += new System.EventHandler(this.mcC1_Leave_1);
            // 
            // mcC2
            // 
            this.mcC2.BackColor = System.Drawing.Color.Gray;
            this.mcC2.ForeColor = System.Drawing.Color.Black;
            this.mcC2.Location = new System.Drawing.Point(379, 118);
            this.mcC2.Name = "mcC2";
            this.mcC2.TabIndex = 43;
            this.mcC2.Visible = false;
            this.mcC2.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcC2_DateSelected_1);
            this.mcC2.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcC2_KeyUp_1);
            this.mcC2.Leave += new System.EventHandler(this.mcC2_Leave_1);
            // 
            // gpbExcepciones2
            // 
            this.gpbExcepciones2.Controls.Add(this.cboExcepciones2);
            this.gpbExcepciones2.Location = new System.Drawing.Point(817, 44);
            this.gpbExcepciones2.Name = "gpbExcepciones2";
            this.gpbExcepciones2.Size = new System.Drawing.Size(153, 45);
            this.gpbExcepciones2.TabIndex = 44;
            this.gpbExcepciones2.TabStop = false;
            this.gpbExcepciones2.Text = "Excepciones";
            // 
            // cboExcepciones2
            // 
            this.cboExcepciones2.BackColor = System.Drawing.Color.GhostWhite;
            this.cboExcepciones2.FormattingEnabled = true;
            this.cboExcepciones2.Location = new System.Drawing.Point(6, 17);
            this.cboExcepciones2.Name = "cboExcepciones2";
            this.cboExcepciones2.Size = new System.Drawing.Size(141, 21);
            this.cboExcepciones2.TabIndex = 27;
            this.cboExcepciones2.SelectedIndexChanged += new System.EventHandler(this.cboExcepciones2_SelectedIndexChanged);
            // 
            // cmSimulador
            // 
            this.cmSimulador.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.oPCIONESSIMULADORToolStripMenuItem,
            this.miBonificacionAnticipada});
            this.cmSimulador.Name = "cmSimulador";
            this.cmSimulador.Size = new System.Drawing.Size(312, 48);
            // 
            // oPCIONESSIMULADORToolStripMenuItem
            // 
            this.oPCIONESSIMULADORToolStripMenuItem.BackColor = System.Drawing.Color.Silver;
            this.oPCIONESSIMULADORToolStripMenuItem.Name = "oPCIONESSIMULADORToolStripMenuItem";
            this.oPCIONESSIMULADORToolStripMenuItem.Size = new System.Drawing.Size(311, 22);
            this.oPCIONESSIMULADORToolStripMenuItem.Text = "OPCIONES SIMULADOR";
            // 
            // miBonificacionAnticipada
            // 
            this.miBonificacionAnticipada.Name = "miBonificacionAnticipada";
            this.miBonificacionAnticipada.Size = new System.Drawing.Size(311, 22);
            this.miBonificacionAnticipada.Text = "Bonificación parcial con revisión a los 45 días";
            this.miBonificacionAnticipada.Click += new System.EventHandler(this.cmSimulado_Click_Event);
            // 
            // Convenio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1020, 516);
            this.Controls.Add(this.gpbExcepciones2);
            this.Controls.Add(this.tsToolStrip);
            this.Controls.Add(this.mcC2);
            this.Controls.Add(this.mcC1);
            this.Controls.Add(this.gvTemporada);
            this.Controls.Add(this.tbRelleno02);
            this.Controls.Add(this.pgbProg);
            this.Controls.Add(this.Relleno);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.tbEstilo);
            this.Controls.Add(this.tbNombre);
            this.Controls.Add(this.tbProveedor);
            this.Controls.Add(this.gbReprogramados);
            this.Controls.Add(this.gbOrigen);
            this.Controls.Add(this.gbMarca);
            this.Controls.Add(this.gbCompradores);
            this.Controls.Add(this.gbRangoFecha);
            this.Controls.Add(this.dgvConvenio);
            this.Controls.Add(this.gbTemporada);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Convenio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Convenio";
            this.Load += new System.EventHandler(this.Convenio_Load);
            this.Resize += new System.EventHandler(this.Convenio_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvConvenio)).EndInit();
            this.cmMenu.ResumeLayout(false);
            this.gbMarca.ResumeLayout(false);
            this.gbCompradores.ResumeLayout(false);
            this.gbRangoFecha.ResumeLayout(false);
            this.gbRangoFecha.PerformLayout();
            this.gbTemporada.ResumeLayout(false);
            this.gbOrigen.ResumeLayout(false);
            this.gbReprogramados.ResumeLayout(false);
            this.tsToolStrip.ResumeLayout(false);
            this.tsToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvTemporada)).EndInit();
            this.gpbExcepciones2.ResumeLayout(false);
            this.cmSimulador.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvConvenio;
        private System.Windows.Forms.ComboBox cbCompradores;
        private System.Windows.Forms.ProgressBar pgbProg;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem FotoTSMI;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.GroupBox gbMarca;
        private System.Windows.Forms.GroupBox gbCompradores;
        private System.Windows.Forms.GroupBox gbRangoFecha;
        private System.Windows.Forms.ToolStripMenuItem reprogramacionTSMI;
        private System.Windows.Forms.ToolStripMenuItem notaDeCréditoTSMI;
        private System.Windows.Forms.ToolStripMenuItem devolucionTSMI;
        private System.Windows.Forms.GroupBox gbTemporada;
        private System.Windows.Forms.GroupBox gbOrigen;
        private System.Windows.Forms.GroupBox gbReprogramados;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.TextBox tbProveedor;
        private System.Windows.Forms.TextBox Relleno;
        private System.Windows.Forms.TextBox tbRelleno02;
        private System.Windows.Forms.ToolStripMenuItem consultaNCPDFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem actualizarToolStripMenuItem;
        private System.Windows.Forms.ToolStrip tsToolStrip;
        private System.Windows.Forms.ToolStripButton pbExcel;
        private System.Windows.Forms.ToolStripButton pbBuscar;
        private System.Windows.Forms.ToolStripButton btCheckBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator tss1;
        private System.Windows.Forms.ToolStripSeparator tss2;
        private System.Windows.Forms.ToolStripButton btCheckBox2;
        private System.Windows.Forms.ToolStripSeparator tss3;
        private System.Windows.Forms.Label lblHasta;
        private System.Windows.Forms.Label lblDesde;
        private System.Windows.Forms.TextBox tbHasta;
        private System.Windows.Forms.TextBox tbDesde;
        private System.Windows.Forms.ComboBox cbOrigen;
        private System.Windows.Forms.ComboBox cbReprogramacion;
        private System.Windows.Forms.ToolStripSeparator tss4;
        private System.Windows.Forms.ToolStripButton btSimulador;
        private System.Windows.Forms.DataGridView gvTemporada;
        private System.Windows.Forms.ComboBox ddlTemporada;
        private System.Windows.Forms.MonthCalendar mcC1;
        private System.Windows.Forms.MonthCalendar mcC2;
        private System.Windows.Forms.ToolStripMenuItem camCalificacionToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem bonificaADecoluciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem devoluciónVsBonificaciónToolStripMenuItem;
        private System.Windows.Forms.GroupBox gpbExcepciones2;
        private System.Windows.Forms.ComboBox cboExcepciones2;
        private System.Windows.Forms.ToolStripMenuItem toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem toolStripSeparator4;
        private System.Windows.Forms.ToolStripSplitButton btnReportes;
        private System.Windows.Forms.ToolStripMenuItem notasDeCredito;
        private System.Windows.Forms.ToolStripMenuItem btnPreautorizadas1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem tablaDeAcción10ToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip cmSimulador;
        private System.Windows.Forms.ToolStripMenuItem oPCIONESSIMULADORToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem miBonificacionAnticipada;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem miRptBonificacionAnticipada;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripLabel lblFechas;
        private System.Windows.Forms.ToolStripComboBox cboFechas;
    }
}