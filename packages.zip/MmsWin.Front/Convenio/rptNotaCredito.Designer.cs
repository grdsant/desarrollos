﻿namespace MmsWin.Front.Convenio
{
    partial class rptNotaCredito
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.rpvNotaCredito = new Microsoft.Reporting.WinForms.ReportViewer();
            this.dsSAT177VNTrpt = new MmsWin.Front.Convenio.dsSAT177VNTrpt();
            this.SAT177VNTBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SAT177VNTTableAdapter = new MmsWin.Front.Convenio.dsSAT177VNTrptTableAdapters.SAT177VNTTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dsSAT177VNTrpt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SAT177VNTBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // rpvNotaCredito
            // 
            this.rpvNotaCredito.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "dtNotaCredito";
            reportDataSource1.Value = this.SAT177VNTBindingSource;
            this.rpvNotaCredito.LocalReport.DataSources.Add(reportDataSource1);
            this.rpvNotaCredito.LocalReport.ReportEmbeddedResource = "MmsWin.Front.Convenio.rptnotaCredito.rdlc";
            this.rpvNotaCredito.Location = new System.Drawing.Point(0, 0);
            this.rpvNotaCredito.Name = "rpvNotaCredito";
            this.rpvNotaCredito.ShowExportButton = false;
            this.rpvNotaCredito.Size = new System.Drawing.Size(871, 397);
            this.rpvNotaCredito.TabIndex = 0;
            this.rpvNotaCredito.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.PageWidth;
            // 
            // dsSAT177VNTrpt
            // 
            this.dsSAT177VNTrpt.DataSetName = "dsSAT177VNTrpt";
            this.dsSAT177VNTrpt.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // SAT177VNTBindingSource
            // 
            this.SAT177VNTBindingSource.DataMember = "SAT177VNT";
            this.SAT177VNTBindingSource.DataSource = this.dsSAT177VNTrpt;
            // 
            // SAT177VNTTableAdapter
            // 
            this.SAT177VNTTableAdapter.ClearBeforeFill = true;
            // 
            // rptNotaCredito
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(871, 397);
            this.Controls.Add(this.rpvNotaCredito);
            this.Name = "rptNotaCredito";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reporte Nota Crédito";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.rptNotaCredito_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dsSAT177VNTrpt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SAT177VNTBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer rpvNotaCredito;
        private System.Windows.Forms.BindingSource SAT177VNTBindingSource;
        private dsSAT177VNTrpt dsSAT177VNTrpt;
        private dsSAT177VNTrptTableAdapters.SAT177VNTTableAdapter SAT177VNTTableAdapter;
    }
}