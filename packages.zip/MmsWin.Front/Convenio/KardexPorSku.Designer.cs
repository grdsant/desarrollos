﻿namespace MmsWin.Front.Convenio
{
    partial class KardexPorSku
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.btOnHand = new System.Windows.Forms.Button();
            this.btOnHandDat = new System.Windows.Forms.Button();
            this.btTransitoDat = new System.Windows.Forms.Button();
            this.btTransito = new System.Windows.Forms.Button();
            this.btInventarioTotDat = new System.Windows.Forms.Button();
            this.btTotalInv = new System.Windows.Forms.Button();
            this.gbMms = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.Location = new System.Drawing.Point(2, 51);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.ReadOnly = true;
            this.dgvGridView.Size = new System.Drawing.Size(996, 548);
            this.dgvGridView.TabIndex = 0;
            this.dgvGridView.Sorted += new System.EventHandler(this.dgvGridView_Sorted);
            // 
            // btOnHand
            // 
            this.btOnHand.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btOnHand.ForeColor = System.Drawing.SystemColors.Control;
            this.btOnHand.Location = new System.Drawing.Point(271, 10);
            this.btOnHand.Name = "btOnHand";
            this.btOnHand.Size = new System.Drawing.Size(61, 28);
            this.btOnHand.TabIndex = 2;
            this.btOnHand.Text = "On Hand:";
            this.btOnHand.UseVisualStyleBackColor = false;
            // 
            // btOnHandDat
            // 
            this.btOnHandDat.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btOnHandDat.ForeColor = System.Drawing.SystemColors.Control;
            this.btOnHandDat.Location = new System.Drawing.Point(329, 10);
            this.btOnHandDat.Name = "btOnHandDat";
            this.btOnHandDat.Size = new System.Drawing.Size(89, 28);
            this.btOnHandDat.TabIndex = 3;
            this.btOnHandDat.UseVisualStyleBackColor = false;
            // 
            // btTransitoDat
            // 
            this.btTransitoDat.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btTransitoDat.ForeColor = System.Drawing.SystemColors.Control;
            this.btTransitoDat.Location = new System.Drawing.Point(481, 10);
            this.btTransitoDat.Name = "btTransitoDat";
            this.btTransitoDat.Size = new System.Drawing.Size(89, 28);
            this.btTransitoDat.TabIndex = 5;
            this.btTransitoDat.UseVisualStyleBackColor = false;
            // 
            // btTransito
            // 
            this.btTransito.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btTransito.ForeColor = System.Drawing.SystemColors.Control;
            this.btTransito.Location = new System.Drawing.Point(423, 10);
            this.btTransito.Name = "btTransito";
            this.btTransito.Size = new System.Drawing.Size(61, 28);
            this.btTransito.TabIndex = 4;
            this.btTransito.Text = "Transito:";
            this.btTransito.UseVisualStyleBackColor = false;
            // 
            // btInventarioTotDat
            // 
            this.btInventarioTotDat.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btInventarioTotDat.ForeColor = System.Drawing.SystemColors.Control;
            this.btInventarioTotDat.Location = new System.Drawing.Point(664, 10);
            this.btInventarioTotDat.Name = "btInventarioTotDat";
            this.btInventarioTotDat.Size = new System.Drawing.Size(98, 28);
            this.btInventarioTotDat.TabIndex = 7;
            this.btInventarioTotDat.UseVisualStyleBackColor = false;
            // 
            // btTotalInv
            // 
            this.btTotalInv.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btTotalInv.ForeColor = System.Drawing.SystemColors.Control;
            this.btTotalInv.Location = new System.Drawing.Point(574, 10);
            this.btTotalInv.Name = "btTotalInv";
            this.btTotalInv.Size = new System.Drawing.Size(93, 28);
            this.btTotalInv.TabIndex = 6;
            this.btTotalInv.Text = "Inventario Total:";
            this.btTotalInv.UseVisualStyleBackColor = false;
            // 
            // gbMms
            // 
            this.gbMms.ForeColor = System.Drawing.SystemColors.Control;
            this.gbMms.Location = new System.Drawing.Point(253, -3);
            this.gbMms.Name = "gbMms";
            this.gbMms.Size = new System.Drawing.Size(525, 48);
            this.gbMms.TabIndex = 8;
            this.gbMms.TabStop = false;
            this.gbMms.Text = "Mms";
            // 
            // KardexPorSku
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1000, 601);
            this.Controls.Add(this.btInventarioTotDat);
            this.Controls.Add(this.btTotalInv);
            this.Controls.Add(this.btTransitoDat);
            this.Controls.Add(this.btTransito);
            this.Controls.Add(this.btOnHandDat);
            this.Controls.Add(this.btOnHand);
            this.Controls.Add(this.dgvGridView);
            this.Controls.Add(this.gbMms);
            this.Name = "KardexPorSku";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kardex";
            this.Load += new System.EventHandler(this.Kardex_Load);
            this.Resize += new System.EventHandler(this.Kardex_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.Button btOnHand;
        private System.Windows.Forms.Button btOnHandDat;
        private System.Windows.Forms.Button btTransitoDat;
        private System.Windows.Forms.Button btTransito;
        private System.Windows.Forms.Button btInventarioTotDat;
        private System.Windows.Forms.Button btTotalInv;
        private System.Windows.Forms.GroupBox gbMms;
    }
}