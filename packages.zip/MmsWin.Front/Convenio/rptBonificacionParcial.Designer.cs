﻿namespace MmsWin.Front.Convenio
{
    partial class rptBonificacionParcial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(rptBonificacionParcial));
            this.vWBONPARCIBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsSAT177AOC = new MmsWin.Front.dsSAT177AOC();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.vWBONPARCITableAdapter = new MmsWin.Front.dsSAT177AOCTableAdapters.VWBONPARCITableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.vWBONPARCIBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSAT177AOC)).BeginInit();
            this.SuspendLayout();
            // 
            // vWBONPARCIBindingSource
            // 
            this.vWBONPARCIBindingSource.DataMember = "VWBONPARCI";
            this.vWBONPARCIBindingSource.DataSource = this.dsSAT177AOC;
            // 
            // dsSAT177AOC
            // 
            this.dsSAT177AOC.DataSetName = "dsSAT177AOC";
            this.dsSAT177AOC.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "cdBonificacionParcial";
            reportDataSource1.Value = this.vWBONPARCIBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "MmsWin.Front.Convenio.rptBonificacionParcial.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ShowExportButton = false;
            this.reportViewer1.ShowProgress = false;
            this.reportViewer1.Size = new System.Drawing.Size(763, 336);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.FullPage;
            // 
            // vWBONPARCITableAdapter
            // 
            this.vWBONPARCITableAdapter.ClearBeforeFill = true;
            // 
            // rptBonificacionParcial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(763, 336);
            this.Controls.Add(this.reportViewer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "rptBonificacionParcial";
            this.Text = "Reporte \"Bonificacion Parcial\"";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.rptBonificacionParcial_Load);
            ((System.ComponentModel.ISupportInitialize)(this.vWBONPARCIBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSAT177AOC)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource vWBONPARCIBindingSource;
        private dsSAT177AOC dsSAT177AOC;
        private dsSAT177AOCTableAdapters.VWBONPARCITableAdapter vWBONPARCITableAdapter;
    }
}