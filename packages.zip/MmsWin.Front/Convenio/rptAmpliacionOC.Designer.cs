﻿namespace MmsWin.Front.Convenio
{
    partial class rptAmpliacionOC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(rptAmpliacionOC));
            this.sAT177AOCBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsSAT177AOC = new MmsWin.Front.dsSAT177AOC();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.sAT177AOCTableAdapter = new MmsWin.Front.dsSAT177AOCTableAdapters.SAT177AOCTableAdapter();
            this.sAT176AOC = new MmsWin.Front.SAT176AOC();
            this.sAT176AOCBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sAT176AOCTableAdapter = new MmsWin.Front.SAT176AOCTableAdapters.SAT176AOCTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.sAT177AOCBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSAT177AOC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAT176AOC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAT176AOCBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // sAT177AOCBindingSource
            // 
            this.sAT177AOCBindingSource.DataSource = this.sAT176AOC;
            this.sAT177AOCBindingSource.Position = 0;
            // 
            // dsSAT177AOC
            // 
            this.dsSAT177AOC.DataSetName = "dsSAT177AOC";
            this.dsSAT177AOC.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "cdSAT176AOC";
            reportDataSource1.Value = this.sAT176AOCBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "MmsWin.Front.Convenio.rptAmpOrdenCompra.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ShowExportButton = false;
            this.reportViewer1.Size = new System.Drawing.Size(896, 458);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.PageWidth;
            // 
            // sAT177AOCTableAdapter
            // 
            this.sAT177AOCTableAdapter.ClearBeforeFill = true;
            // 
            // sAT176AOC
            // 
            this.sAT176AOC.DataSetName = "SAT176AOC";
            this.sAT176AOC.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sAT176AOCBindingSource
            // 
            this.sAT176AOCBindingSource.DataMember = "SAT176AOC";
            this.sAT176AOCBindingSource.DataSource = this.sAT177AOCBindingSource;
            // 
            // sAT176AOCTableAdapter
            // 
            this.sAT176AOCTableAdapter.ClearBeforeFill = true;
            // 
            // rptAmpliacionOC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(896, 458);
            this.Controls.Add(this.reportViewer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "rptAmpliacionOC";
            this.Text = "Reporte Ampliación de Ordenes de Compra";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.rptAmpliacionOC_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sAT177AOCBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSAT177AOC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAT176AOC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAT176AOCBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private dsSAT177AOC dsSAT177AOC;
        private System.Windows.Forms.BindingSource sAT177AOCBindingSource;
        private dsSAT177AOCTableAdapters.SAT177AOCTableAdapter sAT177AOCTableAdapter;
        private SAT176AOC sAT176AOC;
        private System.Windows.Forms.BindingSource sAT176AOCBindingSource;
        private SAT176AOCTableAdapters.SAT176AOCTableAdapter sAT176AOCTableAdapter;

    }
}