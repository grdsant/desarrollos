﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;

using System.Reflection;

using System.Diagnostics;
using MmsWin.Iseries.Reprogramaciones;


//using System.Diagnostics; 

namespace MmsWin.Front.Convenio
{
    public partial class Reprogramacion : Form
    {

        int nr;
        bool ind;
        bool Carga;
        string ParUser;
        string marca;
        string comprador;
        int dgvOffset;
        int dgvOffset2;

        public Reprogramacion()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }

        private void Reprogramacion_Load(object sender, EventArgs e)
        {
            Carga = false;

            MmsWin.Front.Utilerias.VarTem.tmpPrv = "";
            MmsWin.Front.Utilerias.VarTem.tmpSty = "";
            MmsWin.Front.Utilerias.VarTem.tmpFchRev = "";
            MmsWin.Front.Utilerias.VarTem.tmpMarca = "";
            MmsWin.Front.Utilerias.VarTem.tmpComprador = "";

            marca = "999";
            comprador = "999";

            // Carga de Marcatry
            try 
            {
                BindMarca();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            // Carga de Compradores
            try
            {
                BindCompradores();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            // Seguridad...
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("Convenio", "Reprogramacion", ParUser);

            comprador = MmsWin.Front.Utilerias.VarTem.tmpUSRCOM;
            cbCompradores.SelectedValue = comprador;
            marca = MmsWin.Front.Utilerias.VarTem.tmpUSRMAR;
            cbMarca.SelectedValue = marca;

            // Carga de Datos
            try
            {
                Carga = true;
                BindReprog();
                // Recupera Marca y Comprador                                                        
                MmsWin.Front.Utilerias.VarTem.tmpMarca = cbMarca.SelectedValue.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpComprador = cbCompradores.SelectedValue.ToString(); 
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void Reprogramacion_Resize(object sender, EventArgs e)
        {
            dgvGridView.Width = this.Width - dgvOffset;
            dgvGridView.Height = this.Height - dgvOffset2;
        }

        protected void BindMarca()
        {
            try
            {
                cbMarca.DataSource = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();
                cbMarca.DisplayMember = "Value";
                cbMarca.ValueMember = "Key";
                marca = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void BindCompradores()
        {
            try
            {
                cbCompradores.DataSource = MmsWin.Negocio.Catalogos.Compradores.GetInstance().ObtenCompradors().ToList();
                cbCompradores.DisplayMember = "Value";
                cbCompradores.ValueMember = "Key";
                comprador = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        // Seguridad                                                                                
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                         
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvGridView.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvGridView.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenu.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenu.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        protected void BindReprog()
        {
            if (Carga == true)
            {
                nr = 0;
                this.Cursor = Cursors.WaitCursor;
                dgvGridView.DataSource = null;
                System.Data.DataTable Reprog = null;
                try
                {
                    string ParPrv           = tbPrv.Text;
                    string ParNombre        = tbNombre.Text;
                    string ParEstilo        = tbEstilo.Text;
                    string ParDescripcion   = tbDescripcion.Text;
                    string ParFechaRevision = tbFchRevision.Text;
                    string ParFechaReprog   = tbFchReprog.Text;

                    Reprog = MmsWin.Negocio.Convenio.Reprogramacion.GetInstance().ObtenReprog1(marca, comprador, ParPrv, ParNombre, ParEstilo, ParDescripcion, ParFechaRevision, ParFechaReprog);
                }

                catch { }
                finally { }

                if (Reprog != null)
                {
                    if (Reprog.Rows.Count > 0)
                    {
                        dgvGridView.DataSource = Reprog;
                        SetFontAndColors();
                        rowStyle();

                        nr = dgvGridView.RowCount;
                        this.Text = "Reprogramación / " + " " + (nr).ToString() + " Registro(s)";
                        SetDoubleBuffered(dgvGridView);
                        // Seguridad...
                        ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        Seguridad("Convenio", "Reprogramacion", ParUser);
                    }
                }
                this.Cursor = Cursors.Default;
            }
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvGridView.Columns[3].Frozen = true;

            dgvGridView.Columns[0].HeaderText = "Proveedor";
            dgvGridView.Columns[1].HeaderText = "Nombre";
            dgvGridView.Columns[2].HeaderText = "Estilo";
            dgvGridView.Columns[3].HeaderText = "Descripcion";
            dgvGridView.Columns[4].HeaderText = "Fecha Revision";
            dgvGridView.Columns[5].HeaderText = "Fecha Reprog.";
            dgvGridView.Columns[6].HeaderText = "Comprador";
            dgvGridView.Columns[7].HeaderText = "Observaciones";
            dgvGridView.Columns[8].HeaderText = "Marca";
            dgvGridView.Columns[9].HeaderText = "Comprador";
            dgvGridView.Columns[10].HeaderText = "Fecha";
            dgvGridView.Columns[11].HeaderText = "Hora";
            dgvGridView.Columns[12].HeaderText = "Usuario";

            dgvGridView.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[11].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[12].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns[0].Width = 45;
            dgvGridView.Columns[1].Width = 200;
            dgvGridView.Columns[2].Width = 65;
            dgvGridView.Columns[3].Width = 200;
            dgvGridView.Columns[4].Width = 80;
            dgvGridView.Columns[5].Width = 80;
            dgvGridView.Columns[6].Width = 150;
            dgvGridView.Columns[7].Width = 200;
            dgvGridView.Columns[8].Width = 60;
            dgvGridView.Columns[9].Width = 60;
            dgvGridView.Columns[10].Width = 80;
            dgvGridView.Columns[11].Width = 70;
            dgvGridView.Columns[12].Width = 60;

            dgvGridView.Columns[4].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns[5].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns[10].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns[11].DefaultCellStyle.Format = "##:##:##";

            dgvGridView.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[1].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[2].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[3].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[4].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[5].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            dgvGridView.Columns[6].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[7].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            dgvGridView.Columns[8].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            dgvGridView.Columns[9].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[10].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[11].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[12].HeaderCell.Style.BackColor = Color.LightCoral;

            dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            dgvGridView.EnableHeadersVisualStyles = false;
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }

        private void Reprogramacion_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("Convenio", "Reprogramacion", ParUser);
            }
        }
        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            //
            string NomCol;
            Int32 NoCol = dgvGridView.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvGridView.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      
            //
            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void dgvGridView_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F6)
            {
                try
                {
                    Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                                  "Nota").SingleOrDefault<Form>();
                    {
                        if (existe != null)
                        {
                            MessageBox.Show("La Ventana ya esta abierta...");
                        }
                        else
                        {
                            ValidaReprog();
                            if (ind == true)
                            {
                                Reprog i = new Reprog();
                                i.Show();
                            }
                            else
                            {
                                MessageBox.Show("Se debe seleccionar Marca y Comprador ...");
                            }
                        }
                    }
                }
                catch { }
                finally { }
            }

            if (e.KeyCode == Keys.F5)
            {
                BindReprog();
            }


        }

        private void ValidaReprog()
        {
            string IndMarca = MmsWin.Front.Utilerias.VarTem.tmpMarca;
            string IndComprador = MmsWin.Front.Utilerias.VarTem.tmpComprador;

            if (IndMarca == "999" | IndComprador == "999" | IndMarca == "" | IndComprador == "")
            {
                ind = false;
            }
            else
            {
                ind = true;
            }
        }

        private void dgvGridView_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                var hti = dgvGridView.HitTest(e.X, e.Y);
                int Row = e.RowIndex;
                int Col = e.ColumnIndex;
            }
           }

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            marca = " ";
            ComboBox cmbMarca = (ComboBox)sender;
            marca = cmbMarca.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpMarca = cbMarca.SelectedValue.ToString();

            BindReprog();
        }

        private void cbCompradores_SelectedValueChanged(object sender, EventArgs e)
        {
            comprador = " ";
            ComboBox cmbComprador = (ComboBox)sender;
            comprador = cmbComprador.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpComprador = cmbComprador.SelectedValue.ToString();

            BindReprog();
        }

        private void dgvGridView_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                dgvGridView.Select();
                MmsWin.Front.Utilerias.VarTem.tmpPrv = this.dgvGridView.CurrentRow.Cells[0].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpNom = this.dgvGridView.CurrentRow.Cells[1].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpSty = this.dgvGridView.CurrentRow.Cells[2].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpDes = this.dgvGridView.CurrentRow.Cells[3].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpFolio  = this.dgvGridView.CurrentRow.Cells[15].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.tmpFchRev = this.dgvGridView.CurrentRow.Cells[4].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpFchReprog = this.dgvGridView.CurrentRow.Cells[5].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpCompDesc = this.dgvGridView.CurrentRow.Cells[6].Value.ToString();

                MmsWin.Front.Utilerias.Fotos.numPrv = this.dgvGridView.CurrentRow.Cells[0].Value.ToString();
                MmsWin.Front.Utilerias.Fotos.numSty = this.dgvGridView.CurrentRow.Cells[2].Value.ToString();

            }
            catch { }
        }

        private void fotoTSMI_Click(object sender, EventArgs e)
        {
            MuestraFoto();
        }

        private void MuestraFoto()
        {
            try
            {
                MmsWin.Front.Utilerias.Fotos i = new MmsWin.Front.Utilerias.Fotos();
                i.Show();
            }
            catch { }
            finally { }
        }

        private void pbExcel_Click(object sender, EventArgs e)
        {
            System.Data.DataTable dtDowns = (System.Data.DataTable)(dgvGridView.DataSource);
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            int nc = dgvGridView.Columns.Count;


            for (int ii = 1; ii <= nc; ii++)
            {
                xlWorkSheet.Cells[1, ii] = dgvGridView.Columns[ii - 1].HeaderText;
            }

            System.Data.DataTable dtCalificaciones = (System.Data.DataTable)(dgvGridView.DataSource);
            int nr = dgvGridView.RowCount;

            int r = 0;
            int rt = 3;
            foreach (DataRow row in dtCalificaciones.Rows)
            {
                var gsArray = new[]       {
                                                    row["REPPRV"],
                                                    row["REPPDS"],
                                                    row["REPSTY"],
                                                    row["REPSDS"],
                                                    row["REPFRV"],
                                                    row["REPFRP"],
                                                    row["REPCDS"],
                                                    row["REPOBS"],
                                                    row["REPMAR"],
                                                    row["REPCOM"],
                                                    row["REPFCHA"],
                                                    row["REPHORA"],
                                                    row["REPUSR"]
                                                   };

                Range rng = xlWorkSheet.get_Range("A" + rt, "M" + rt);
                rng.Value = gsArray;

                this.Text = "Reprogramaciones / " + " " + (r += 1).ToString() + " Registro(s) de " + nr;

                rt++;
            }

            xlWorkSheet.Columns[1].ColumnWidth = 5;
            xlWorkSheet.Columns[2].ColumnWidth = 45;
            xlWorkSheet.Columns[3].ColumnWidth = 10;
            xlWorkSheet.Columns[4].ColumnWidth = 45;
            xlWorkSheet.Columns[5].ColumnWidth = 15;
            xlWorkSheet.Columns[6].ColumnWidth = 15;
            xlWorkSheet.Columns[7].ColumnWidth = 35;
            xlWorkSheet.Columns[8].ColumnWidth = 45;
            xlWorkSheet.Columns[9].ColumnWidth = 10;
            xlWorkSheet.Columns[10].ColumnWidth = 2;
            xlWorkSheet.Columns[11].ColumnWidth = 11;
            xlWorkSheet.Columns[12].ColumnWidth = 11;
            xlWorkSheet.Columns[13].ColumnWidth = 11;

            var Rang1 = xlWorkSheet.get_Range("A1", "A1");
            Rang1.Interior.Color = Color.LightGreen;

            xlWorkSheet.Cells[1, 2].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 3].Cells.Interior.Color = Color.LightSkyBlue;

            xlWorkSheet.Cells[1, 4].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 5].Cells.Interior.Color = Color.LightSalmon;

            var Rang2 = xlWorkSheet.get_Range("F1", "F1");
            Rang2.Interior.Color = Color.LightGreen;

            var Rang3 = xlWorkSheet.get_Range("G1", "G1");
            Rang3.Interior.Color = Color.LightSkyBlue;

            var Rang4 = xlWorkSheet.get_Range("H1", "H1");
            Rang4.Interior.Color = Color.LightSalmon;

            var Rang5 = xlWorkSheet.get_Range("I1", "I1");
            Rang5.Interior.Color = Color.LightSkyBlue;

            var Rang6 = xlWorkSheet.get_Range("J1", "J1");
            Rang6.Interior.Color = Color.LightGreen;

            var Rang7 = xlWorkSheet.get_Range("K1", "K1");
            Rang7.Interior.Color = Color.LightSalmon;

            var Rang9 = xlWorkSheet.get_Range("L1", "L1");
            Rang9.Interior.Color = Color.LightGray;

            var Rang8 = xlWorkSheet.get_Range("M1", "M1");
            Rang8.WrapText = true;
            Rang8.Font.Bold = true;
            Rang8.Font.Color = Color.Black;
            Rang8.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang8.Font.Underline = true;
            Rang8.HorizontalAlignment = HorizontalAlignment.Center;
            Rang8.Interior.Color = Color.LightGray;

            String Rango = "A2" + ":" + "M" + rt;
            Excel.Range SourceRange = (Excel.Range)xlWorkSheet.get_Range("A2", "M" + rt); // or whatever range you want here
            FormatAsTable(SourceRange, "Table1", "TableStyleMedium2");

            xlWorkSheet.Rows[2].Hidden = true;

            xlWorkSheet.Columns["A"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["C"].HorizontalAlignment = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["E"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["F"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["I"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["J"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["K"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["L"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["M"].HorizontalAlignment = XlHAlign.xlHAlignCenter;


            xlWorkSheet.Columns["E"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["F"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["K"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["L"].NumberFormat = "00-00-00";

            var range = xlWorkSheet.get_Range("A3", "A3");
            range.Select();

            string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
            xlApp.ActiveWindow.Zoom = 80;
            xlWorkBook.SaveAs("C:\\Reportes\\Reprogramaciones" + Hoy + ".xlsx", Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            string comando = @"C:\\Reportes\\Reprogramaciones" + Hoy + ".xlsx";
            ExecuteCommand(comando);
        }

        static void ExecuteCommand(string _Command)
        {
            //Indicamos que deseamos inicializar el proceso cmd.exe junto a un comando de arranque. 
            //(/C, le indicamos al proceso cmd que deseamos que cuando termine la tarea asignada se cierre el proceso).
            //Para mas informacion consulte la ayuda de la consola con cmd.exe /? 
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;
            //Inicializa el proceso
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            string result = proc.StandardOutput.ReadToEnd();
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        public void FormatAsTable(Excel.Range SourceRange, string TableName, string TableStyleName)
        {
            SourceRange.Worksheet.ListObjects.Add(XlListObjectSourceType.xlSrcRange,
            SourceRange, System.Type.Missing, XlYesNoGuess.xlYes, System.Type.Missing).Name =
                TableName;
            SourceRange.Select();
            SourceRange.Worksheet.ListObjects[TableName].TableStyle = TableStyleName;
            SourceRange.Worksheet.ListObjects[TableName].ShowAutoFilter = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowHeaders = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowTotals = false;
        }

        private void tbPrv_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindReprog();
                tbPrv.Focus();
            }
        }

        private void tbNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindReprog();
                tbNombre.Focus();
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindReprog();
                tbEstilo.Focus();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindReprog();
                tbDescripcion.Focus();
            }

        }

        private void tbFchRevision_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindReprog();
                tbFchRevision.Focus();
            }
        }

        private void tbFchReprog_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindReprog();
                tbFchReprog.Focus();
            }
        }

        private void eliminarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string message = "Corfirmar la Eliminacion del Registro";
            string caption = "Advertencia...";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                string ParProveedor = MmsWin.Front.Utilerias.VarTem.tmpPrv;
                string ParEstilo = MmsWin.Front.Utilerias.VarTem.tmpSty;
                string ParFchRev = MmsWin.Front.Utilerias.VarTem.tmpFchRev;
                string ParFchRepro = MmsWin.Front.Utilerias.VarTem.tmpFchReprog;
                MmsWin.Negocio.Convenio.Reprogramacion.GetInstance().EliminaReprogramacion1(ParProveedor, ParEstilo, ParFchRev, ParFchRepro);
                BindReprog();
                tbFchReprog.Focus();
            }
        }

        private void imprimirTlSMI_Click(object sender, EventArgs e)
        {
            ImprimirReprogramacion();
        }

        private void ImprimirReprogramacion()
        {
            string folio = MmsWin.Front.Utilerias.VarTem.tmpFolio;
            string usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
            MmsWin.Negocio.Convenio.Reprogramacion.GetInstance().ObtenImprimir( folio, usuario);

            Reprograma i = new Reprograma();

            i.ShowDialog(this);
        }
    }
}
