﻿namespace MmsWin.Front.Convenio
{
    partial class rptCambioPrecio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.sAT177RPCCPBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsSAT177MMNETLIB = new MmsWin.Front.dsSAT177MMNETLIB();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.sAT177RPCCPTableAdapter = new MmsWin.Front.dsSAT177MMNETLIBTableAdapters.SAT177RPCCPTableAdapter();
            this.sAT177RPCCPBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.sAT177RPCCPBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSAT177MMNETLIB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAT177RPCCPBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // sAT177RPCCPBindingSource
            // 
            this.sAT177RPCCPBindingSource.DataMember = "SAT177RPCCP";
            this.sAT177RPCCPBindingSource.DataSource = this.dsSAT177MMNETLIB;
            // 
            // dsSAT177MMNETLIB
            // 
            this.dsSAT177MMNETLIB.DataSetName = "dsSAT177MMNETLIB";
            this.dsSAT177MMNETLIB.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "SAT177RPCCP";
            reportDataSource1.Value = this.sAT177RPCCPBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "MmsWin.Front.Convenio.rptCambioPrecio.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.ShowExportButton = false;
            this.reportViewer1.ShowStopButton = false;
            this.reportViewer1.Size = new System.Drawing.Size(869, 459);
            this.reportViewer1.TabIndex = 0;
            this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.PageWidth;
            // 
            // sAT177RPCCPTableAdapter
            // 
            this.sAT177RPCCPTableAdapter.ClearBeforeFill = true;
            // 
            // sAT177RPCCPBindingSource1
            // 
            this.sAT177RPCCPBindingSource1.DataMember = "SAT177RPCCP";
            this.sAT177RPCCPBindingSource1.DataSource = this.dsSAT177MMNETLIB;
            // 
            // rptCambioPrecio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(869, 459);
            this.Controls.Add(this.reportViewer1);
            this.Name = "rptCambioPrecio";
            this.Text = "Reporte Cambio de Precio";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.rptCambioPrecio_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sAT177RPCCPBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsSAT177MMNETLIB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAT177RPCCPBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource sAT177RPCCPBindingSource;
        private dsSAT177MMNETLIB dsSAT177MMNETLIB;
        private dsSAT177MMNETLIBTableAdapters.SAT177RPCCPTableAdapter sAT177RPCCPTableAdapter;
        private System.Windows.Forms.BindingSource sAT177RPCCPBindingSource1;
    }
}