﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using MmsWin.Front.Utilerias;
using System.Reflection;
using MmsWin.Front.Bonificaciones;
using MmsWin.Negocio.Procesos;
using System.Diagnostics;
using System.Globalization;

namespace MmsWin.Front.Convenio
{
    public partial class Convenio : Form
    {
        #region [ Variables ]

        int nr;
        bool ind;
        bool Carga;
        string ParUser;
        string marca;
        //string cadena;
        string comprador;
        string listaComprador;
        string temporada;
        string origen;
        String FchDe;
        String FchHas;
        long FchDeN;
        long FchHasN;
        string reprogramacion;
        string excepciones;
        string conRpg;
        string conExcep;
        string sinRpg;
        string FechaCal;
        string FechaFmt;
        public static string parProveedor   { get; set; }
        public static string parEstilo      { get; set; }
        public static string ParProveedor   { get; set; }
        public static string PartbNombre    { get; set; }
        public static string PartbEstilo    { get; set; }
        public static string ParDescripcion { get; set; }

        public static int    selecionGrid = 0;

        long fechaHis;
        int dgvOffset;
        int dgvOffset2;
        int pgbOffset;
        int vez1;

        #endregion

        #region [ Variables OCG ]

        decimal CalificacionRentabilidad = 0;

        bool bnaSimulador = false; //Indica ejecución del simulador para la bonificación anticipada

        Entidades.BonificacionParcial bonificacionParcial = new Entidades.BonificacionParcial();
        Entidades.Reprogramaciones eReprogramaciones = new Entidades.Reprogramaciones();

        #endregion

        public Convenio()
        {
            InitializeComponent();

            dgvOffset  = this.Width  - dgvConvenio.Width;
            dgvOffset2 = this.Height - dgvConvenio.Height;
            pgbOffset  = this.Width  - pgbProg.Width;
        }

        public struct Margins
        {
            public int derecha;
            public int izquierda;
            public int superior;
            public int inferior;
        }

        private void Convenio_Load(object sender, EventArgs e)
        {
            ToolTip Tooltip1 = new ToolTip();
            ToolTip tooltip = new ToolTip();
            tooltip.SetToolTip(this.tbProveedor, "Proveedor");
            tooltip.SetToolTip(this.tbEstilo, "Estilo");
            tooltip.SetToolTip(this.tbNombre, "Nombre");
            tooltip.SetToolTip(this.tbDescripcion, "Descripción");

            selecionGrid = 0;
            Carga = false;
            marca = "999";
            comprador = "999";
            fechaHis = 0;
            tbDesde.Text = "0000000000";

            FchDe = "10/10/2000";
            FchHas = "10/10/2000";
            tbDesde.Text = FchDe;
            tbHasta.Text = FchHas;

            //Ocultar los controles de fechas que se usan para la bonificación anticipada
            //se hacen visibles y se ocultan desde el botón de pre-calificaciones
            this.lblFechas.Visible = false;
            this.cboFechas.Visible = false;

            try
            {
                System.Data.DataTable tbFechaInicial = null;
                tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();

                foreach (DataRow row in tbFechaInicial.Rows)
                {
                    tbDesde.Text = row["DSPFCH"].ToString();
                    FechaCal = tbDesde.Text;
                    FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                    tbDesde.Text = FechaFmt.ToString();
                    tbHasta.Text = FechaFmt.ToString();

                    FechaCal = tbDesde.Text;
                    FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                    FchDeN = long.Parse(FechaFmt.ToString());
                    FchDe = FechaFmt.ToString();

                    FechaCal = tbHasta.Text;
                    FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                    FchHasN = long.Parse(FechaFmt.ToString());
                    FchHas = FechaFmt.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            System.Data.DataTable dtTemporadas = new System.Data.DataTable("Temporada");
            dtTemporadas.Columns.Add("Des", typeof(String));
            dtTemporadas.Columns.Add("Id", typeof(String));

            dtTemporadas = MmsWin.Negocio.Catalogos.Temporada.GetInstance().ObtenTemporada();

            ddlTemporada.DataSource = dtTemporadas;
            ddlTemporada.DisplayMember = "Des";
            ddlTemporada.ValueMember = "Id";

            // Carga de Marca
            try
            {
                BindMarca();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // Carga de Compradores
            try
            {
                BindCompradores();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // Carga de Temporadas
            try
            {
                BindTemporada();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            // Carga de Origen
            try
            {
                BindOrigen();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            // Carga de Reprogramados
            try
            {
                BindReprogramados();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            // Carga de Excepciones
            try
            {
                BindExcepciones();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            comprador = MmsWin.Front.Utilerias.VarTem.tmpUSRCOM;
            listaComprador = MmsWin.Front.Utilerias.VarTem.tmpDESC;
            cbCompradores.SelectedValue = comprador;
            marca = MmsWin.Front.Utilerias.VarTem.tmpUSRMAR;
            cbMarca.SelectedValue = marca;
            temporada = "999";

            origen = "999";
            cbOrigen.SelectedValue = origen;

            // Carga de Datos
            try
            {
                gvTemporada.Visible = false;
                // Recupera Fecha inicial                                                                                               
                tbDesde.Text = MmsWin.Front.Utilerias.VarTem.tmpFchInicial;
                FechaCal = tbDesde.Text;
                FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);

                tbDesde.Text = FechaFmt.ToString();
                FechaCal = tbDesde.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                fechaHis = long.Parse(FechaFmt.ToString());
                MmsWin.Front.Utilerias.VarTem.tmpFchConv = FechaFmt;

                Carga = true;

                BindData();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            //Borrame luego
            btSimulador.Enabled = true; btSimulador.Visible = true;

            this.dgvConvenio.ContextMenuStrip = cmMenu;

            Seguridad("Convenio", "Convenio", ParUser);
        }

        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario, true);

            string busca = string.Empty;

            //Aplicar seguridad de el menu contextual principal y sus opciones
            DataRow[] foundRows;
            foreach (ToolStripItem item in cmMenu.Items)
            {
                foundRows = tbSeguridad.Select("SEGCLS Like '" + item.Name + "%'");

                if (foundRows.Count() > 0)
                {
                    if (item.Name == (foundRows[0]["SEGCLS"].ToString()))
                    {
                        item.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        item.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }
            }

            //Aplicar seguridad a las opciones del menú contextual del simulador
            foreach (ToolStripItem item in cmSimulador.Items)
            {
                foundRows = tbSeguridad.Select("SEGCLS Like '" + item.Name + "%'");

                if (foundRows.Count() > 0)
                {
                    if (item.Name == (foundRows[0]["SEGCLS"].ToString()))
                    {
                        item.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        item.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }
            }

            foundRows = tbSeguridad.Select("SEGCLS Like 'cbMarca%'");
            if (foundRows.Count() > 0)
            {
                this.cbMarca.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
            }


            foundRows = tbSeguridad.Select("SEGCLS Like 'cbCompradores%'");
            if (foundRows.Count() > 0)
            {
                this.cbCompradores.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
            }

            //Se recorren todos los controles del formulario y se buscan dentro del datatable para validar
            // si existe y si se debe aplicar seguridad
            foreach (Control X in this.Controls)
            {
                busca = X.Name;

                // Buscar el control dentro del DataTable
                foundRows = tbSeguridad.Select("SEGCLS Like '" + busca + "%'");

                //Si el control existe
                if (foundRows.Count() > 0)
                {
                    //Si el control es una barra de controles
                    if (X.GetType() == typeof(ToolStrip))
                    {
                        foreach (ToolStripItem item in tsToolStrip.Items)
                        {
                            foundRows = tbSeguridad.Select("SEGCLS Like '" + item.Name + "%'");

                            if (foundRows.Count() > 0)
                            {
                                if (item.Name == (foundRows[0]["SEGCLS"].ToString()))
                                {
                                    item.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                                    item.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                                }
                            }

                        }
                    }

                }
            }
        }

        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvConvenio.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvConvenio.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
        }

        /// <summary>
        /// Carga los estilos calificados del periodo seleccionado
        /// </summary>
        /// <param name="excepcion">Indica si se deben de cargar solo excepciones</param>
        protected void BindData(string excepcion = "")
        {
            if (Carga == true)
            {
                nr = 0;
                this.Text = "Convenio / " + " " + (nr).ToString() + " Registro(s)";
                this.Cursor = Cursors.WaitCursor;
                EliminacheckBox();

                dgvConvenio.DataSource = null;

                System.Data.DataTable Convenio = null;
                try
                {
                    String ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUsrConv;
                    Boolean simulador = MmsWin.Front.Utilerias.VarTem.simulador;
                    long fechaHis = long.Parse(MmsWin.Front.Utilerias.VarTem.tmpFchConv.ToString());
                    conRpg = reprogramacion;
                    conExcep = excepciones;

                    ParProveedor = tbProveedor.Text;
                    PartbNombre = tbNombre.Text;
                    PartbEstilo = tbEstilo.Text;
                    ParDescripcion = tbDescripcion.Text;
                    if (listaComprador != "")
                    {
                        comprador = listaComprador;
                    }
                    
                    Convenio = MmsWin.Negocio.Convenio.Convenio.GetInstance().ObtenConvenio1(marca, comprador, FchDe, FchHas, ParProveedor, PartbNombre, PartbEstilo, ParDescripcion, temporada, origen, conRpg, sinRpg, ParUsuario, simulador, this.cboExcepciones2.SelectedValue.ToString());

                    comprador = MmsWin.Front.Utilerias.VarTem.tmpUSRCOM;
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                if (Convenio != null)
                {
                    if (Convenio.Rows.Count > 0)
                    {
                        SetDoubleBuffered(dgvConvenio);
                        dgvConvenio.DataSource = null;

                        dgvConvenio.DataSource = Convenio;

                        nr = dgvConvenio.RowCount;
                        this.Text = "Convenio / " + " " + (nr).ToString() + " Registro(s)";
                        CreaCheckBox();
                        SetFontAndColors();
                        rowStyle();

                        // Seguridad...
                        ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        Seguridad("Convenio", "Convenio", ParUser);
                        gvTemporada.Visible = false;

                        dgvConvenio.Focus();
                        dgvConvenio.Select();
                    }
                }
                this.Cursor = Cursors.Default;
            }
        }

        protected void BindDataTemp()
        {
            try
            {
                EliminacheckBoxTemp();
                gvTemporada.DataSource = null;
                SetDoubleBuffered(gvTemporada);
                System.Data.DataTable tbl = MmsWin.Negocio.Convenio.Convenio.GetInstance().ObtenTemporada(marca, comprador, ddlTemporada.SelectedValue.ToString(), cbOrigen.SelectedValue.ToString());

                gvTemporada.DataSource = tbl;

                gvTemporada.Focus();
                gvTemporada.Select();

                if (tbl != null)
                {
                    CreaCheckBoxTemporada();
                    SetFontAndColorsTemporada();
                    rowStyleTemporada();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void SetDoubleBuffered(Control control)
        {
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        protected void BindMarca()
        {
            try
            {
                cbMarca.DataSource = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();
                cbMarca.DisplayMember = "Value";
                cbMarca.ValueMember = "Key";
                marca = "30";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void BindCompradores()
        {
            try
            {
                cbCompradores.DataSource = MmsWin.Negocio.Catalogos.Compradores.GetInstance().ObtenCompradors().ToList();
                cbCompradores.DisplayMember = "Value";
                cbCompradores.ValueMember = "Key";
                comprador = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void BindTemporada()
        {
            try
            {
                System.Data.DataTable dtTemporadas = new System.Data.DataTable("Temporada");
                dtTemporadas.Columns.Add("Des", typeof(String));
                dtTemporadas.Columns.Add("Id", typeof(String));

                dtTemporadas = MmsWin.Negocio.Catalogos.Temporada.GetInstance().ObtenTemporada();
                DataSet ds = new DataSet();
                ds.Tables.Add(dtTemporadas);
                BindingSource bs = new BindingSource();
                rowStyleTemporada();
                temporada = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void BindOrigen()
        {
            try
            {
                cbOrigen.DataSource = MmsWin.Negocio.Catalogos.Origen.GetInstance().ObtenOrigen().ToList();
                cbOrigen.DisplayMember = "Value";
                cbOrigen.ValueMember = "Key";
                origen = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void BindReprogramados()
        {
            try
            {
                cbReprogramacion.DataSource = MmsWin.Negocio.Catalogos.Reprogramados.GetInstance().ObtenReprogramados().ToList();
                cbReprogramacion.DisplayMember = "Value";
                cbReprogramacion.ValueMember = "Key";
                reprogramacion = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void BindExcepciones()
        {
            try
            {
                this.cboExcepciones2.DataSource = new BindingSource(Negocio.Convenio.Reprogramacion.obtCatalogoReprogramaciones(), null);
                this.cboExcepciones2.DisplayMember = "Value";
                this.cboExcepciones2.ValueMember = "ID";

                this.cboExcepciones2.SelectedValue = "999";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Name, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void Convenio_Resize(object sender, EventArgs e)
        {
            dgvConvenio.Width = this.Width - dgvOffset;
            dgvConvenio.Height = this.Height - dgvOffset2;
            pgbProg.Width = this.Width - pgbOffset;

            nr = dgvConvenio.RowCount;

            if (nr > 0)
            {
                SetFontAndColors();
                rowStyle();
            }

            gvTemporada.Width = this.Width - dgvOffset;
            gvTemporada.Height = this.Height - dgvOffset2;

            nr = gvTemporada.RowCount;

            if (nr > 0)
            {
                SetFontAndColorsTemporada();
            }
        }

        private void SetFontAndColors()
        {
            int i = 0;
            try
            {
                this.dgvConvenio.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                //   this.dgvConvenio.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
                this.dgvConvenio.EnableHeadersVisualStyles = false;
                this.dgvConvenio.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
                this.dgvConvenio.DefaultCellStyle.SelectionForeColor = Color.Black;
                this.dgvConvenio.DefaultCellStyle.SelectionBackColor = Color.LightGray;
                this.dgvConvenio.CellBorderStyle = DataGridViewCellBorderStyle.Single;
                this.dgvConvenio.RowsDefaultCellStyle.ForeColor = Color.Black;
                this.dgvConvenio.Columns[2].Frozen = true;

                dgvConvenio.Columns["DSPPRV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPNOM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgvConvenio.Columns["DSPSTY"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgvConvenio.Columns["DSPDES"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgvConvenio.Columns["DSPDCP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgvConvenio.Columns["DSPORD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPFRB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPPRB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPMRG"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSP4P3"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPRTB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPRT2"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPRT3"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPRT4"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPCAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPCOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPCLF"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPONH"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPONO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPRSTD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPPDI"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPSM1"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPSM2"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPSM3"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPSM4"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPSM5"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPSM6"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPSM7"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPSM8"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPPOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPFRV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPCST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPPZA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPCSB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgvConvenio.Columns["DSPCBF"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPMAR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPBDG"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPCSTA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DSPPREA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvConvenio.Columns["DRECB0"].Visible = false;
                dgvConvenio.Columns["DRECB1"].Visible = false;
                dgvConvenio.Columns["DRECB2"].Visible = false;
                dgvConvenio.Columns["DRECB3"].Visible = false;
                dgvConvenio.Columns["DRECB4"].Visible = false;
                dgvConvenio.Columns["DRECB5"].Visible = false;
                dgvConvenio.Columns["DRECB6"].Visible = false;
                dgvConvenio.Columns["DRECB7"].Visible = false;
                dgvConvenio.Columns["DRECB8"].Visible = false;

                dgvConvenio.Columns["REPSTY"].Visible = false;

                dgvConvenio.Columns["DSPASN"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPORI"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPRPG"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                dgvConvenio.Columns["DSPNCS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPREP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPNRP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPFPX"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPOBS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgvConvenio.Columns["BONCK1"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPUCP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPFCP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPHCP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["BONCK2"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPUCT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPFCT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPHCT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvConvenio.Columns["DSPOBC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

                dgvConvenio.Columns["DSPPRV"].Width = 45;
                dgvConvenio.Columns["DSPNOM"].Width = 200;
                dgvConvenio.Columns["DSPSTY"].Width = 65;
                dgvConvenio.Columns["DSPDES"].Width = 200;
                dgvConvenio.Columns["DSPDCP"].Width = 130;
                dgvConvenio.Columns["DSPORD"].Width = 70;
                dgvConvenio.Columns["DSPFRB"].Width = 90;
                dgvConvenio.Columns["DSPPRB"].Width = 60;
                dgvConvenio.Columns["DSPMRG"].Width = 60;
                dgvConvenio.Columns["DSP4P3"].Width = 60;
                dgvConvenio.Columns["DSPRTB"].Width = 75;
                dgvConvenio.Columns["DSPRT2"].Width = 80;
                dgvConvenio.Columns["DSPRT3"].Width = 80;
                dgvConvenio.Columns["DSPRT4"].Width = 80;
                dgvConvenio.Columns["DSPCAL"].Width = 80;
                dgvConvenio.Columns["DSPCOR"].Width = 80;
                dgvConvenio.Columns["DSPCLF"].Width = 80;
                dgvConvenio.Columns["DSPONH"].Width = 60;
                dgvConvenio.Columns["DSPONO"].Width = 60;
                dgvConvenio.Columns["DSPRSTD"].Width = 50;
                dgvConvenio.Columns["DSPPDI"].Width = 50;
                dgvConvenio.Columns["DSPSM1"].Width = 50;
                dgvConvenio.Columns["DSPSM2"].Width = 50;
                dgvConvenio.Columns["DSPSM3"].Width = 50;
                dgvConvenio.Columns["DSPSM4"].Width = 50;
                dgvConvenio.Columns["DSPSM5"].Width = 50;
                dgvConvenio.Columns["DSPSM6"].Width = 50;
                dgvConvenio.Columns["DSPSM7"].Width = 50;
                dgvConvenio.Columns["DSPSM8"].Width = 50;
                dgvConvenio.Columns["DSPPOR"].Width = 50;
                dgvConvenio.Columns["DSPFRV"].Width = 80;
                dgvConvenio.Columns["DSPCST"].Width = 75;
                dgvConvenio.Columns["DSPPZA"].Width = 70;
                dgvConvenio.Columns["DSPCSB"].Width = 75;

                dgvConvenio.Columns["DSPCBF"].Width = 75;
                dgvConvenio.Columns["DSPMAR"].Width = 70;
                dgvConvenio.Columns["DSPBDG"].Width = 50;
                dgvConvenio.Columns["DSPCSTA"].Width = 70;
                dgvConvenio.Columns["DSPPREA"].Width = 70;

                dgvConvenio.Columns["DSPASN"].Width = 50;
                dgvConvenio.Columns["DSPORI"].Width = 50;
                dgvConvenio.Columns["DSPRPG"].Width = 50;

                dgvConvenio.Columns["DSPNMR"].Width = 40;
                dgvConvenio.Columns["DSPNCS"].Width = 50;

                dgvConvenio.Columns["DSPNRP"].Width = 50;
                dgvConvenio.Columns["DSPFPX"].Width = 80;
                dgvConvenio.Columns["DSPOBS"].Width = 300;
                dgvConvenio.Columns["BONCK1"].Width = 50;
                dgvConvenio.Columns["DSPUCP"].Width = 70;
                dgvConvenio.Columns["DSPFCP"].Width = 80;
                dgvConvenio.Columns["DSPHCP"].Width = 70;
                dgvConvenio.Columns["BONCK2"].Width = 70;

                dgvConvenio.Columns["DSPFCT"].Width = 80;
                dgvConvenio.Columns["DSPHCT"].Width = 70;
                dgvConvenio.Columns["DSPOBC"].Width = 300;

                dgvConvenio.Columns["DSPPRV"].HeaderText = "Proveedor";
                dgvConvenio.Columns["DSPNOM"].HeaderText = "Nombre";
                dgvConvenio.Columns["DSPSTY"].HeaderText = "Estilo";
                dgvConvenio.Columns["DSPDES"].HeaderText = "Descripción";
                dgvConvenio.Columns["DSPDCP"].HeaderText = "Comprador";
                dgvConvenio.Columns["DSPORD"].HeaderText = "Orden Compra";
                dgvConvenio.Columns["DSPFRB"].HeaderText = "Fecha Recibo";
                dgvConvenio.Columns["DSPPRB"].HeaderText = "Piezas Recibidas";
                dgvConvenio.Columns["DSPMRG"].HeaderText = "Margen";
                dgvConvenio.Columns["DSP4P3"].HeaderText = "Margen * 4.3";
                dgvConvenio.Columns["DSPRTB"].HeaderText = "Rentabilidad Calificación";
                dgvConvenio.Columns["DSPRT2"].HeaderText = "Rentabilidad 2_Sem_Atras";
                dgvConvenio.Columns["DSPRT3"].HeaderText = "Rentabilidad 3_Sem_Atras";
                dgvConvenio.Columns["DSPRT4"].HeaderText = "Rentabilidad 4_Sem_Atras";
                dgvConvenio.Columns["DSPCAL"].HeaderText = "Calificación";
                dgvConvenio.Columns["DSPCOR"].HeaderText = "Calificación Original";
                dgvConvenio.Columns["DSPCLF"].HeaderText = "Calificación Final";
                dgvConvenio.Columns["DSPONH"].HeaderText = "On Hand";
                dgvConvenio.Columns["DSPONO"].HeaderText = "On Order";
                dgvConvenio.Columns["DSPRSTD"].HeaderText = "Resurtido";
                dgvConvenio.Columns["DSPPDI"].HeaderText = "Pos Distro";               
                dgvConvenio.Columns["DSPSM1"].HeaderText = "Semana Vta_1";
                dgvConvenio.Columns["DSPSM2"].HeaderText = "Semana Vta_2";
                dgvConvenio.Columns["DSPSM3"].HeaderText = "Semana Vta_3";
                dgvConvenio.Columns["DSPSM4"].HeaderText = "Semana Vta_4";
                dgvConvenio.Columns["DSPSM5"].HeaderText = "Semana Vta_5";
                dgvConvenio.Columns["DSPSM6"].HeaderText = "Semana Vta_6";
                dgvConvenio.Columns["DSPSM7"].HeaderText = "Semana Vta_7";
                dgvConvenio.Columns["DSPSM8"].HeaderText = "Semana Vta_8";
                dgvConvenio.Columns["DSPPOR"].HeaderText = " % Vendido";
                dgvConvenio.Columns["DSPFRV"].HeaderText = "Fecha Revisión";
                dgvConvenio.Columns["DSPCST"].HeaderText = "Costo Total";
                dgvConvenio.Columns["DSPPZA"].HeaderText = "Piezas a Bonificar";
                dgvConvenio.Columns["DSPCSB"].HeaderText = "Costo a Bonificar";

                dgvConvenio.Columns["DSPCBF"].HeaderText = "Costo a Bonificar Final";
                dgvConvenio.Columns["DSPMAR"].HeaderText = "Marca";
                dgvConvenio.Columns["DSPBDG"].HeaderText = "Bodega";
                dgvConvenio.Columns["DSPCSTA"].HeaderText = "Costo Actual";
                dgvConvenio.Columns["DSPPREA"].HeaderText = "Precio Actual";
                dgvConvenio.Columns["DRECB0"].HeaderText = "Recibo 0";
                dgvConvenio.Columns["DRECB1"].HeaderText = "Recibo 1";
                dgvConvenio.Columns["DRECB2"].HeaderText = "Recibo 2";
                dgvConvenio.Columns["DRECB3"].HeaderText = "Recibo 3";
                dgvConvenio.Columns["DRECB4"].HeaderText = "Recibo 4";
                dgvConvenio.Columns["DRECB5"].HeaderText = "Recibo 5";
                dgvConvenio.Columns["DRECB6"].HeaderText = "Recibo 6";
                dgvConvenio.Columns["DRECB7"].HeaderText = "Recibo 7";
                dgvConvenio.Columns["DRECB8"].HeaderText = "Recibo 8";
                dgvConvenio.Columns["DSPASN"].HeaderText = "Temporada";
                dgvConvenio.Columns["DSPORI"].HeaderText = "Origen";
                dgvConvenio.Columns["DSPRPG"].HeaderText = "Reprog";

                dgvConvenio.Columns["DSPNCS"].HeaderText = "PDF";
                dgvConvenio.Columns["DSPREP"].HeaderText = "Reprogramación Próxima";

                dgvConvenio.Columns["DSPNRP"].HeaderText = "Reprogra- maciones";
                dgvConvenio.Columns["DSPFPX"].HeaderText = "Fecha Reprog. Próxima";
                dgvConvenio.Columns["DSPOBS"].HeaderText = "Observaciones Compras";

                dgvConvenio.Columns["BONCK1"].HeaderText = "Sts Compras";
                dgvConvenio.Columns["DSPUCP"].HeaderText = "Usuario";
                dgvConvenio.Columns["DSPFCP"].HeaderText = "Fecha";
                dgvConvenio.Columns["DSPHCP"].HeaderText = "Hora";

                dgvConvenio.Columns["BONCK2"].HeaderText = "Sts C x P";
                dgvConvenio.Columns["DSPUCT"].HeaderText = "Usuario";
                dgvConvenio.Columns["DSPFCT"].HeaderText = "Fecha";
                dgvConvenio.Columns["DSPHCT"].HeaderText = "Hora";
                dgvConvenio.Columns["DSPOBC"].HeaderText = "Observaciones C x P";

                dgvConvenio.Columns["DSPNRP"].DefaultCellStyle.NullValue = null;

                dgvConvenio.Columns["DSPPRV"].DefaultCellStyle.Format = "######";
                dgvConvenio.Columns["DSPFRB"].DefaultCellStyle.Format = "20##-##-##";
                dgvConvenio.Columns["DSPPRB"].DefaultCellStyle.Format = "#,###";
                dgvConvenio.Columns["DSPMRG"].DefaultCellStyle.Format = "#,###";
                dgvConvenio.Columns["DSP4P3"].DefaultCellStyle.Format = "#,###";
                dgvConvenio.Columns["DSPRTB"].DefaultCellStyle.Format = "##.##";
                dgvConvenio.Columns["DSPRT2"].DefaultCellStyle.Format = "##.##";
                dgvConvenio.Columns["DSPRT3"].DefaultCellStyle.Format = "##.##";
                dgvConvenio.Columns["DSPRT4"].DefaultCellStyle.Format = "##.##";

                dgvConvenio.Columns["DSPONH"].DefaultCellStyle.Format = "#,###";
                dgvConvenio.Columns["DSPONO"].DefaultCellStyle.Format = "#,###";
                dgvConvenio.Columns["DSPRSTD"].DefaultCellStyle.Format = "#,###";
                dgvConvenio.Columns["DSPPDI"].DefaultCellStyle.Format = "###,###";
                
                dgvConvenio.Columns["DSPSM1"].DefaultCellStyle.Format = "#,###";
                dgvConvenio.Columns["DSPSM2"].DefaultCellStyle.Format = "#,###";
                dgvConvenio.Columns["DSPSM3"].DefaultCellStyle.Format = "#,###";
                dgvConvenio.Columns["DSPSM4"].DefaultCellStyle.Format = "#,###";
                dgvConvenio.Columns["DSPSM5"].DefaultCellStyle.Format = "#,###";
                dgvConvenio.Columns["DSPSM6"].DefaultCellStyle.Format = "#,###";
                dgvConvenio.Columns["DSPSM7"].DefaultCellStyle.Format = "#,###";
                dgvConvenio.Columns["DSPSM8"].DefaultCellStyle.Format = "#,###";
                dgvConvenio.Columns["DSPPOR"].DefaultCellStyle.Format = "#0.00";
                dgvConvenio.Columns["DSPFRV"].DefaultCellStyle.Format = "20##-##-##";
                dgvConvenio.Columns["DSPCST"].DefaultCellStyle.Format = "#,###,###";
                dgvConvenio.Columns["DSPPZA"].DefaultCellStyle.Format = "#,###";
                dgvConvenio.Columns["DSPCSB"].DefaultCellStyle.Format = "#,###,###.#0";

                dgvConvenio.Columns["DSPCBF"].DefaultCellStyle.Format = "#,###,###.#0";
                dgvConvenio.Columns["DSPMAR"].DefaultCellStyle.Format = "##.00";
                dgvConvenio.Columns["DSPBDG"].DefaultCellStyle.Format = "###";
                dgvConvenio.Columns["DSPCSTA"].DefaultCellStyle.Format = "##0.00";
                dgvConvenio.Columns["DSPPREA"].DefaultCellStyle.Format = "##0.00";

                dgvConvenio.Columns["DSPFPX"].DefaultCellStyle.Format = "20##-##-##";
                dgvConvenio.Columns["DSPFCP"].DefaultCellStyle.Format = "20##-##-##";
                dgvConvenio.Columns["DSPHCP"].DefaultCellStyle.Format = "##:##:##";
                dgvConvenio.Columns["DSPFCT"].DefaultCellStyle.Format = "20##-##-##";
                dgvConvenio.Columns["DSPHCT"].DefaultCellStyle.Format = "##:##:##";

                dgvConvenio.Columns["DSPPRV"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvConvenio.Columns["DSPNOM"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvConvenio.Columns["DSPSTY"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvConvenio.Columns["DSPDES"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvConvenio.Columns["DSPDCP"].HeaderCell.Style.BackColor = Color.LightGreen;
                dgvConvenio.Columns["DSPORD"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvConvenio.Columns["DSPFRB"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvConvenio.Columns["DSPPRB"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvConvenio.Columns["DSPMRG"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvConvenio.Columns["DSP4P3"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvConvenio.Columns["DSPRTB"].HeaderCell.Style.BackColor = Color.LightCoral;
                dgvConvenio.Columns["DSPRT2"].HeaderCell.Style.BackColor = Color.LightCoral;
                dgvConvenio.Columns["DSPRT3"].HeaderCell.Style.BackColor = Color.LightCoral;
                dgvConvenio.Columns["DSPRT4"].HeaderCell.Style.BackColor = Color.LightCoral;
                dgvConvenio.Columns["DSPCAL"].HeaderCell.Style.BackColor = Color.LightGreen;
                dgvConvenio.Columns["DSPCAL"].HeaderCell.Style.ForeColor = Color.Black;
                dgvConvenio.Columns["DSPCOR"].HeaderCell.Style.BackColor = Color.LightGreen;
                dgvConvenio.Columns["DSPCOR"].HeaderCell.Style.ForeColor = Color.Black;
                dgvConvenio.Columns["DSPCLF"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvConvenio.Columns["DSPCLF"].HeaderCell.Style.ForeColor = Color.Black;
                dgvConvenio.Columns["DSPONH"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvConvenio.Columns["DSPONH"].HeaderCell.Style.ForeColor = Color.Black;
                dgvConvenio.Columns["DSPONO"].HeaderCell.Style.BackColor = Color.LightPink;
                dgvConvenio.Columns["DSPONO"].HeaderCell.Style.ForeColor = Color.Black;
                dgvConvenio.Columns["DSPRSTD"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvConvenio.Columns["DSPPDI"].HeaderCell.Style.BackColor = Color.LightGreen;
                dgvConvenio.Columns["DSPPDI"].HeaderCell.Style.ForeColor = Color.Black;                
                dgvConvenio.Columns["DSPSM1"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
                dgvConvenio.Columns["DSPSM2"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
                dgvConvenio.Columns["DSPSM3"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
                dgvConvenio.Columns["DSPSM4"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
                dgvConvenio.Columns["DSPSM5"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
                dgvConvenio.Columns["DSPSM6"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
                dgvConvenio.Columns["DSPSM7"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
                dgvConvenio.Columns["DSPSM8"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
                dgvConvenio.Columns["DSPPOR"].HeaderCell.Style.BackColor = Color.LightGreen;
                dgvConvenio.Columns["DSPPOR"].HeaderCell.Style.ForeColor = Color.Black;
                dgvConvenio.Columns["DSPFRV"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvConvenio.Columns["DSPCST"].HeaderCell.Style.BackColor = Color.LightCoral;
                dgvConvenio.Columns["DSPPZA"].HeaderCell.Style.BackColor = Color.LightCoral;
                dgvConvenio.Columns["DSPPZA"].HeaderCell.Style.ForeColor = Color.Black;

                dgvConvenio.Columns["DSPCSB"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvConvenio.Columns["DSPCSB"].HeaderCell.Style.ForeColor = Color.Black;
                dgvConvenio.Columns["DSPCBF"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvConvenio.Columns["DSPCBF"].HeaderCell.Style.ForeColor = Color.Black;

                dgvConvenio.Columns["DSPMAR"].HeaderCell.Style.BackColor = Color.LightGreen;
                dgvConvenio.Columns["DSPBDG"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvConvenio.Columns["DSPCSTA"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
                dgvConvenio.Columns["DSPPREA"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
                dgvConvenio.Columns["DSPASN"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvConvenio.Columns["DSPORI"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvConvenio.Columns["DSPRPG"].HeaderCell.Style.BackColor = Color.LightSalmon;

                dgvConvenio.Columns["DSPRPG"].Visible = false;
                dgvConvenio.Columns["DSPNMR"].Visible = false;
                dgvConvenio.Columns["DSPREP"].Visible = false;

                dgvConvenio.Columns["BONCK1"].Visible = false;
                dgvConvenio.Columns["BONCK2"].Visible = false;
                dgvConvenio.Columns["DSPCLF"].Visible = false;
                dgvConvenio.Columns["DSPOMI"].Visible = false;
                //dgvConvenio.Columns[69].Visible = false;
                //dgvConvenio.Columns["OMITIR"].Visible = false;

                dgvConvenio.Columns["DSPNCS"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvConvenio.Columns["DSPNRP"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvConvenio.Columns["DSPFPX"].HeaderCell.Style.BackColor = Color.LightSlateGray;

                dgvConvenio.Columns["DSPOBS"].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
                dgvConvenio.Columns["DSPOBS"].HeaderCell.Style.ForeColor = Color.White;
                dgvConvenio.Columns["BONCK1"].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
                dgvConvenio.Columns["BONCK1"].HeaderCell.Style.ForeColor = Color.White;
                dgvConvenio.Columns["DSPUCP"].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
                dgvConvenio.Columns["DSPUCP"].HeaderCell.Style.ForeColor = Color.White;
                dgvConvenio.Columns["DSPFCP"].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
                dgvConvenio.Columns["DSPFCP"].HeaderCell.Style.ForeColor = Color.White;
                dgvConvenio.Columns["DSPHCP"].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
                dgvConvenio.Columns["DSPHCP"].HeaderCell.Style.ForeColor = Color.White;

                dgvConvenio.Columns["BONCK2"].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
                dgvConvenio.Columns["BONCK2"].HeaderCell.Style.ForeColor = Color.White;
                dgvConvenio.Columns["DSPUCT"].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
                dgvConvenio.Columns["DSPUCT"].HeaderCell.Style.ForeColor = Color.White;
                dgvConvenio.Columns["DSPFCT"].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
                dgvConvenio.Columns["DSPFCT"].HeaderCell.Style.ForeColor = Color.White;
                dgvConvenio.Columns["DSPHCT"].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
                dgvConvenio.Columns["DSPHCT"].HeaderCell.Style.ForeColor = Color.White;
                dgvConvenio.Columns["DSPOBC"].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
                dgvConvenio.Columns["DSPOBC"].HeaderCell.Style.ForeColor = Color.White;

                dgvConvenio.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                dgvConvenio.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
                dgvConvenio.EnableHeadersVisualStyles = false;

                foreach (DataGridViewRow row in dgvConvenio.Rows)
                {
                    i++;
                    // Semana 8
                    if (Convert.ToInt32(row.Cells["DRECB8"].Value) > 0) { row.Cells["DSPSM8"].Style.BackColor = Color.LightGreen; }
                    // Semana 7
                    if (Convert.ToInt32(row.Cells["DRECB7"].Value) > 0) { row.Cells["DSPSM7"].Style.BackColor = Color.LightGreen; }
                    // Semana 6
                    if (Convert.ToInt32(row.Cells["DRECB6"].Value) > 0) { row.Cells["DSPSM6"].Style.BackColor = Color.LightGreen; }
                    // Semana 5
                    if (Convert.ToInt32(row.Cells["DRECB5"].Value) > 0) { row.Cells["DSPSM5"].Style.BackColor = Color.LightGreen; }
                    // Semana 4
                    if (Convert.ToInt32(row.Cells["DRECB4"].Value) > 0) { row.Cells["DSPSM4"].Style.BackColor = Color.LightGreen; }
                    // Semana 3
                    if (Convert.ToInt32(row.Cells["DRECB3"].Value) > 0) { row.Cells["DSPSM3"].Style.BackColor = Color.LightGreen; }
                    // Semana 2
                    if (Convert.ToInt32(row.Cells["DRECB2"].Value) > 0) { row.Cells["DSPSM2"].Style.BackColor = Color.LightGreen; }
                    // Semana 1
                    if (Convert.ToInt32(row.Cells["DRECB1"].Value) > 0) { row.Cells["DSPSM1"].Style.BackColor = Color.LightGreen; }

                    // Pagar
                    if (Convert.ToString(row.Cells["DSPCLF"].Value) == " P a g a r") { row.Cells["DSPCLF"].Style.BackColor = Color.LightGreen; }

                    if (Convert.ToString(row.Cells["DSPCLF"].Value) != "" && Char.IsNumber(Convert.ToString(row.Cells["DSPCLF"].Value).Substring(0).Trim()[0]) == true &&
                       (Convert.ToDecimal(Convert.ToString(row.Cells["DSPCLF"].Value).Split('%')[0]) >= 16 || Convert.ToDecimal(Convert.ToString(row.Cells["DSPCLF"].Value).Split('%')[0]) < 20))
                    { row.Cells["DSPCLF"].Style.BackColor = Color.Yellow; }
                    // 20%
                    if (Convert.ToString(row.Cells["DSPCLF"].Value) != "" && Char.IsNumber(Convert.ToString(row.Cells["DSPCLF"].Value).Substring(0).Trim()[0]) == true &&
                       (Convert.ToDecimal(Convert.ToString(row.Cells["DSPCLF"].Value).Split('%')[0]) >= 20 || Convert.ToDecimal(Convert.ToString(row.Cells["DSPCLF"].Value).Split('%')[0]) < 25))
                    { row.Cells["DSPCLF"].Style.BackColor = Color.Yellow; }
                    // 25%
                    if (Convert.ToString(row.Cells["DSPCLF"].Value) != "" && Char.IsNumber(Convert.ToString(row.Cells["DSPCLF"].Value).Substring(0).Trim()[0]) == true &&
                       (Convert.ToDecimal(Convert.ToString(row.Cells["DSPCLF"].Value).Split('%')[0]) >= 25 || Convert.ToDecimal(Convert.ToString(row.Cells["DSPCLF"].Value).Split('%')[0]) < 30))
                    { row.Cells["DSPCLF"].Style.BackColor = Color.Yellow; }
                    // 30%
                    if (Convert.ToString(row.Cells["DSPCLF"].Value) != "" && Char.IsNumber(Convert.ToString(row.Cells["DSPCLF"].Value).Substring(0).Trim()[0]) == true &&
                       (Convert.ToDecimal(Convert.ToString(row.Cells["DSPCLF"].Value).Split('%')[0]) >= 30 || Convert.ToDecimal(Convert.ToString(row.Cells["DSPCLF"].Value).Split('%')[0]) < 40))
                    { row.Cells["DSPCLF"].Style.BackColor = Color.LightSalmon; }
                    if (Convert.ToString(row.Cells["DSPCLF"].Value) != "" && Char.IsNumber(Convert.ToString(row.Cells["DSPCLF"].Value).Substring(0).Trim()[0]) == true &&
                       (Convert.ToDecimal(Convert.ToString(row.Cells["DSPCLF"].Value).Split('%')[0]) == 40))
                    { row.Cells["DSPCLF"].Style.BackColor = Color.LightSalmon; }
                    // Dev ó 40%
                    if (Convert.ToString(row.Cells["DSPCLF"].Value) == " 40%") { row.Cells["DSPCLF"].Style.BackColor = Color.Red; row.Cells["DSPCLF"].Style.ForeColor = Color.White; }
                    //Dev o 50%
                    if (Convert.ToString(row.Cells["DSPCLF"].Value) == " 50%") { row.Cells["DSPCLF"].Style.BackColor = Color.Red; row.Cells["DSPCLF"].Style.ForeColor = Color.White; }
                    //Dev o 50%
                    if (Convert.ToString(row.Cells["DSPCLF"].Value) == " 50%") { row.Cells["DSPCLF"].Style.BackColor = Color.Red; row.Cells["DSPCLF"].Style.ForeColor = Color.White; }
                    // Devolucion
                    if (Convert.ToString(row.Cells["DSPCLF"].Value) == "Devolucion") { row.Cells["DSPCLF"].Style.BackColor = Color.Red; row.Cells["DSPCLF"].Style.ForeColor = Color.White; }

                    // Pagar
                    if (Convert.ToString(row.Cells["DSPCOR"].Value) == " P a g a r") { row.Cells["DSPCOR"].Style.BackColor = Color.LightGreen; }

                    if (Convert.ToString(row.Cells["DSPCOR"].Value) != "" && Char.IsNumber(Convert.ToString(row.Cells["DSPCOR"].Value).Substring(0).Trim()[0]) == true &&
                    (Convert.ToDecimal(Convert.ToString(row.Cells["DSPCOR"].Value).Split('%')[0]) >= 15 || Convert.ToDecimal(Convert.ToString(row.Cells["DSPCOR"].Value).Split('%')[0]) < 20))
                    { row.Cells["DSPCOR"].Style.BackColor = Color.Yellow; }
                    // 20%
                    if (Convert.ToString(row.Cells["DSPCOR"].Value) != "" && Char.IsNumber(Convert.ToString(row.Cells["DSPCOR"].Value).Substring(0).Trim()[0]) == true &&
                       (Convert.ToDecimal(Convert.ToString(row.Cells["DSPCOR"].Value).Split('%')[0]) >= 20 || Convert.ToDecimal(Convert.ToString(row.Cells["DSPCOR"].Value).Split('%')[0]) < 25))
                    { row.Cells["DSPCOR"].Style.BackColor = Color.Yellow; }
                    // 25%
                    if (Convert.ToString(row.Cells["DSPCOR"].Value) != "" && Char.IsNumber(Convert.ToString(row.Cells["DSPCOR"].Value).Substring(0).Trim()[0]) == true &&
                       (Convert.ToDecimal(Convert.ToString(row.Cells["DSPCOR"].Value).Split('%')[0]) >= 25 || Convert.ToDecimal(Convert.ToString(row.Cells["DSPCOR"].Value).Split('%')[0]) < 30))
                    { row.Cells["DSPCOR"].Style.BackColor = Color.Yellow; }
                    // 30%
                    if (Convert.ToString(row.Cells["DSPCOR"].Value) != "" && Char.IsNumber(Convert.ToString(row.Cells["DSPCOR"].Value).Substring(0).Trim()[0]) == true &&
                       (Convert.ToDecimal(Convert.ToString(row.Cells["DSPCOR"].Value).Split('%')[0]) >= 30 || Convert.ToDecimal(Convert.ToString(row.Cells["DSPCOR"].Value).Split('%')[0]) < 40))
                    { row.Cells["DSPCOR"].Style.BackColor = Color.LightSalmon; }
                    if (Convert.ToString(row.Cells["DSPCOR"].Value) != "" && Char.IsNumber(Convert.ToString(row.Cells["DSPCOR"].Value).Substring(0).Trim()[0]) == true &&
                       (Convert.ToDecimal(Convert.ToString(row.Cells["DSPCOR"].Value).Split('%')[0]) == 40))
                    { row.Cells["DSPCOR"].Style.BackColor = Color.LightSalmon; }
                    // Dev ó 40%
                    if (Convert.ToString(row.Cells["DSPCOR"].Value) == " 40%") { row.Cells["DSPCOR"].Style.BackColor = Color.Red; row.Cells["DSPCOR"].Style.ForeColor = Color.White; }
                    //Dev o 50%
                    if (Convert.ToString(row.Cells["DSPCOR"].Value) == " 50%") { row.Cells["DSPCOR"].Style.BackColor = Color.Red; row.Cells["DSPCOR"].Style.ForeColor = Color.White; }
                    //Dev o 50%
                    if (Convert.ToString(row.Cells["DSPCOR"].Value) == " 50%") { row.Cells["DSPCOR"].Style.BackColor = Color.Red; row.Cells["DSPCOR"].Style.ForeColor = Color.White; }
                    // Devolucion
                    if (Convert.ToString(row.Cells["DSPCOR"].Value) == "Devolucion") { row.Cells["DSPCOR"].Style.BackColor = Color.Red; row.Cells["DSPCOR"].Style.ForeColor = Color.White; }

                    // Pagar
                    if (Convert.ToString(row.Cells["DSPCAL"].Value) == " P a g a r") { row.Cells["DSPCAL"].Style.BackColor = Color.LightGreen; }

                    if (Convert.ToString(row.Cells["DSPCAL"].Value) != "" && Char.IsNumber(Convert.ToString(row.Cells["DSPCAL"].Value).Substring(0).Trim()[0]) == true &&
                     (Convert.ToDecimal(Convert.ToString(row.Cells["DSPCAL"].Value).Split('%')[0]) >= 15 || Convert.ToDecimal(Convert.ToString(row.Cells["DSPCAL"].Value).Split('%')[0]) < 20))
                    { row.Cells["DSPCAL"].Style.BackColor = Color.Yellow; }
                    // 20%
                    if (Convert.ToString(row.Cells["DSPCAL"].Value) != "" && Char.IsNumber(Convert.ToString(row.Cells["DSPCAL"].Value).Substring(0).Trim()[0]) == true &&
                       (Convert.ToDecimal(Convert.ToString(row.Cells["DSPCAL"].Value).Split('%')[0]) >= 20 || Convert.ToDecimal(Convert.ToString(row.Cells["DSPCAL"].Value).Split('%')[0]) < 25))
                    { row.Cells["DSPCAL"].Style.BackColor = Color.Yellow; }
                    // 25%
                    if (Convert.ToString(row.Cells["DSPCAL"].Value) != "" && Char.IsNumber(Convert.ToString(row.Cells["DSPCAL"].Value).Substring(0).Trim()[0]) == true &&
                       (Convert.ToDecimal(Convert.ToString(row.Cells["DSPCAL"].Value).Split('%')[0]) >= 25 || Convert.ToDecimal(Convert.ToString(row.Cells["DSPCAL"].Value).Split('%')[0]) < 30))
                    { row.Cells["DSPCAL"].Style.BackColor = Color.Yellow; }
                    // 30%
                    if (Convert.ToString(row.Cells["DSPCAL"].Value) != "" && Char.IsNumber(Convert.ToString(row.Cells["DSPCAL"].Value).Substring(0).Trim()[0]) == true &&
                       (Convert.ToDecimal(Convert.ToString(row.Cells["DSPCAL"].Value).Split('%')[0]) >= 30 || Convert.ToDecimal(Convert.ToString(row.Cells["DSPCAL"].Value).Split('%')[0]) < 40))
                    { row.Cells["DSPCAL"].Style.BackColor = Color.LightSalmon; }
                    if (Convert.ToString(row.Cells["DSPCAL"].Value) != "" && Char.IsNumber(Convert.ToString(row.Cells["DSPCAL"].Value).Substring(0).Trim()[0]) == true &&
                       (Convert.ToDecimal(Convert.ToString(row.Cells["DSPCAL"].Value).Split('%')[0]) == 40))
                    { row.Cells["DSPCAL"].Style.BackColor = Color.LightSalmon; }
                    // Dev ó 40%
                    if (Convert.ToString(row.Cells["DSPCAL"].Value) == " 40%") { row.Cells["DSPCAL"].Style.BackColor = Color.Red; row.Cells["DSPCAL"].Style.ForeColor = Color.White; }
                    //Dev o 50%
                    if (Convert.ToString(row.Cells["DSPCAL"].Value) == " 50%") { row.Cells["DSPCAL"].Style.BackColor = Color.Red; row.Cells["DSPCAL"].Style.ForeColor = Color.White; }
                    //Dev o 50%
                    if (Convert.ToString(row.Cells["DSPCAL"].Value) == " 50%") { row.Cells["DSPCAL"].Style.BackColor = Color.Red; row.Cells["DSPCAL"].Style.ForeColor = Color.White; }
                    // Devolucion
                    if (Convert.ToString(row.Cells["DSPCAL"].Value) == "Devolucion") { row.Cells["DSPCAL"].Style.BackColor = Color.Red; row.Cells["DSPCAL"].Style.ForeColor = Color.White; }

                    row.Cells[10].Style.ForeColor = Color.DarkBlue;

                    dgvConvenio.Columns["DSPFRV"].DisplayIndex      = 8;  // 8
                    dgvConvenio.Columns["DSPPDI"].DisplayIndex      = 21; //
                    dgvConvenio.Columns["COMPRAS"].DisplayIndex     = 57; // 56
                    dgvConvenio.Columns["CONTRALORIA"].DisplayIndex = 63; // 62 
                    dgvConvenio.Columns["OMITIR"].DisplayIndex      = 68; // 67 
                    dgvConvenio.Columns["DSPOBC"].DisplayIndex      = 62; // 61
                }
            }
            catch (Exception ex)
            {
                i = i;
                throw new Exception("");
            }
        }

        private void SetFontAndColorsTemporada()
        {
            this.gvTemporada.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.gvTemporada.EnableHeadersVisualStyles = false;
            this.gvTemporada.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.gvTemporada.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.gvTemporada.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.gvTemporada.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.gvTemporada.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.gvTemporada.Columns[2].Frozen = true;

            gvTemporada.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvTemporada.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvTemporada.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvTemporada.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvTemporada.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvTemporada.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvTemporada.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvTemporada.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvTemporada.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvTemporada.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvTemporada.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvTemporada.Columns[11].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvTemporada.Columns[12].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;//Descripcion Subclase
            gvTemporada.Columns[13].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[14].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[15].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[16].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[17].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[18].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[19].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[20].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[21].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[22].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[23].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[24].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[25].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[26].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[27].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;//onhand plus
            gvTemporada.Columns[28].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvTemporada.Columns[29].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[30].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[31].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[32].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[33].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[34].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[35].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[36].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[37].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[38].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[39].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[40].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[41].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[42].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[43].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvTemporada.Columns[44].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[45].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[46].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[47].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[48].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvTemporada.Columns[49].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[50].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[51].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvTemporada.Columns[52].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            gvTemporada.Columns[0].Width = 45;
            gvTemporada.Columns[1].Width = 200;
            gvTemporada.Columns[2].Width = 65;
            gvTemporada.Columns[3].Width = 200;
            gvTemporada.Columns[4].Width = 80;//comprador
            gvTemporada.Columns[5].Width = 45;
            gvTemporada.Columns[6].Width = 200;
            gvTemporada.Columns[7].Width = 45;
            gvTemporada.Columns[8].Width = 200;
            gvTemporada.Columns[9].Width = 45;
            gvTemporada.Columns[10].Width = 200;
            gvTemporada.Columns[11].Width = 45;//subclase
            gvTemporada.Columns[12].Width = 200;
            gvTemporada.Columns[13].Width = 80;
            gvTemporada.Columns[14].Width = 80;
            gvTemporada.Columns[15].Width = 80;
            gvTemporada.Columns[16].Width = 80;
            gvTemporada.Columns[17].Width = 60;
            gvTemporada.Columns[18].Width = 60;
            gvTemporada.Columns[19].Width = 80;
            gvTemporada.Columns[20].Width = 80;
            gvTemporada.Columns[21].Width = 80;
            gvTemporada.Columns[22].Width = 80;
            gvTemporada.Columns[23].Width = 80;
            gvTemporada.Columns[24].Width = 80;
            gvTemporada.Columns[25].Width = 80;
            gvTemporada.Columns[26].Width = 80;
            gvTemporada.Columns[27].Width = 80;
            gvTemporada.Columns[28].Width = 120;
            gvTemporada.Columns[29].Width = 80;
            gvTemporada.Columns[30].Width = 80;
            gvTemporada.Columns[31].Width = 80;
            gvTemporada.Columns[32].Width = 80;

            gvTemporada.Columns[33].Width = 80;
            gvTemporada.Columns[34].Width = 80;
            gvTemporada.Columns[35].Width = 80;
            gvTemporada.Columns[36].Width = 80;
            gvTemporada.Columns[37].Width = 80;
            gvTemporada.Columns[38].Width = 80;
            gvTemporada.Columns[39].Width = 80;
            gvTemporada.Columns[40].Width = 80;
            gvTemporada.Columns[41].Width = 80;
            gvTemporada.Columns[42].Width = 80;
            //gvTemporada.Columns[37].Width = 70;
            gvTemporada.Columns[43].Width = 300;
            gvTemporada.Columns[44].Width = 60;
            gvTemporada.Columns[45].Width = 80;
            gvTemporada.Columns[46].Width = 70;
            gvTemporada.Columns[47].Width = 80;
            gvTemporada.Columns[48].Width = 300;
            gvTemporada.Columns[49].Width = 60;
            gvTemporada.Columns[50].Width = 80;
            gvTemporada.Columns[51].Width = 70;
            gvTemporada.Columns[52].Width = 80;


            gvTemporada.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[1].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[2].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[3].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[4].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[5].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[6].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[7].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[8].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[9].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[10].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[11].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[12].HeaderCell.Style.BackColor = Color.LightSalmon;//subclase

            gvTemporada.Columns[13].HeaderCell.Style.BackColor = Color.LightCoral;//costos anterior
            gvTemporada.Columns[14].HeaderCell.Style.BackColor = Color.LightCoral;
            gvTemporada.Columns[15].HeaderCell.Style.BackColor = Color.LightCoral;//costos actual

            gvTemporada.Columns[16].HeaderCell.Style.BackColor = Color.LightGreen;
            gvTemporada.Columns[17].HeaderCell.Style.BackColor = Color.LightGreen;
            gvTemporada.Columns[18].HeaderCell.Style.BackColor = Color.LightGreen;//ventas piezas

            gvTemporada.Columns[19].HeaderCell.Style.BackColor = Color.LightPink;
            gvTemporada.Columns[20].HeaderCell.Style.BackColor = Color.LightPink;//inventario
            gvTemporada.Columns[21].HeaderCell.Style.BackColor = Color.LightPink;

            gvTemporada.Columns[22].HeaderCell.Style.BackColor = Color.LightSkyBlue;//
            gvTemporada.Columns[23].HeaderCell.Style.BackColor = Color.LightSkyBlue;//bonificacion
            gvTemporada.Columns[24].HeaderCell.Style.BackColor = Color.LightSkyBlue;//efectiva

            gvTemporada.Columns[25].HeaderCell.Style.BackColor = Color.LightSeaGreen;//calificacion
            gvTemporada.Columns[26].HeaderCell.Style.BackColor = Color.LightSeaGreen;

            gvTemporada.Columns[27].HeaderCell.Style.BackColor = Color.LightCoral;//onhandplus
            gvTemporada.Columns[28].HeaderCell.Style.BackColor = Color.LightCoral;
            gvTemporada.Columns[29].HeaderCell.Style.BackColor = Color.LightCoral;
            gvTemporada.Columns[30].HeaderCell.Style.BackColor = Color.LightCoral;
            gvTemporada.Columns[31].HeaderCell.Style.BackColor = Color.LightCoral;
            gvTemporada.Columns[32].HeaderCell.Style.BackColor = Color.LightCoral;
            gvTemporada.Columns[33].HeaderCell.Style.BackColor = Color.LightCoral;
            gvTemporada.Columns[34].HeaderCell.Style.BackColor = Color.LightCoral;

            gvTemporada.Columns[35].HeaderCell.Style.BackColor = Color.LightSalmon;//calificacion
            gvTemporada.Columns[32].HeaderCell.Style.BackColor = Color.LightSalmon;

            gvTemporada.Columns[33].HeaderCell.Style.BackColor = Color.LightSalmon;

            gvTemporada.Columns[34].HeaderCell.Style.BackColor = Color.LightGreen;
            gvTemporada.Columns[35].HeaderCell.Style.BackColor = Color.LightGreen;
            gvTemporada.Columns[36].HeaderCell.Style.BackColor = Color.LightGreen;
            gvTemporada.Columns[37].HeaderCell.Style.BackColor = Color.LightGreen;
            gvTemporada.Columns[38].HeaderCell.Style.BackColor = Color.LightGreen;
            gvTemporada.Columns[39].HeaderCell.Style.BackColor = Color.LightGreen;
            gvTemporada.Columns[40].HeaderCell.Style.BackColor = Color.LightGreen;
            gvTemporada.Columns[41].HeaderCell.Style.BackColor = Color.LightGreen;
            gvTemporada.Columns[42].HeaderCell.Style.BackColor = Color.LightGreen;

            gvTemporada.Columns[43].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            gvTemporada.Columns[43].HeaderCell.Style.ForeColor = Color.White;
            gvTemporada.Columns[44].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            gvTemporada.Columns[44].HeaderCell.Style.ForeColor = Color.White;
            gvTemporada.Columns[45].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            gvTemporada.Columns[45].HeaderCell.Style.ForeColor = Color.White;
            gvTemporada.Columns[46].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            gvTemporada.Columns[46].HeaderCell.Style.ForeColor = Color.White;
            gvTemporada.Columns[47].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            gvTemporada.Columns[47].HeaderCell.Style.ForeColor = Color.White;

            gvTemporada.Columns[48].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[48].HeaderCell.Style.ForeColor = Color.White;
            gvTemporada.Columns[49].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[49].HeaderCell.Style.ForeColor = Color.White;
            gvTemporada.Columns[50].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[50].HeaderCell.Style.ForeColor = Color.White;
            gvTemporada.Columns[51].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[51].HeaderCell.Style.ForeColor = Color.White;
            gvTemporada.Columns[52].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvTemporada.Columns[52].HeaderCell.Style.ForeColor = Color.White;

            gvTemporada.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gvTemporada.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            gvTemporada.EnableHeadersVisualStyles = false;

            foreach (DataGridViewRow row in gvTemporada.Rows)
            {
                // Pagar
                if (Convert.ToString(row.Cells[27].Value) == " P a g a r") { row.Cells[27].Style.BackColor = Color.LightGreen; }
                // 15%
                if (Convert.ToString(row.Cells[27].Value) == " 15%") { row.Cells[27].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(row.Cells[27].Value) == " 20%") { row.Cells[27].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(row.Cells[27].Value) == " 25%") { row.Cells[27].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(row.Cells[27].Value) == " 30%") { row.Cells[27].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(row.Cells[27].Value) == " 35%") { row.Cells[27].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(row.Cells[27].Value) == " 40%") { row.Cells[27].Style.BackColor = Color.LightSalmon; }
                // Dev ó 40%
                if (Convert.ToString(row.Cells[27].Value) == " 40%") { row.Cells[27].Style.BackColor = Color.Red; row.Cells[27].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(row.Cells[27].Value) == " 50%") { row.Cells[27].Style.BackColor = Color.Red; row.Cells[27].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(row.Cells[27].Value) == " 50%") { row.Cells[27].Style.BackColor = Color.Red; row.Cells[27].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(row.Cells[27].Value) == "Devolucion") { row.Cells[27].Style.BackColor = Color.Red; row.Cells[16].Style.ForeColor = Color.White; }

                try
                {
                    gvTemporada.Columns["COMPRAS"].DisplayIndex = 44;
                    gvTemporada.Columns[44].Visible = false;
                    gvTemporada.Columns["CONTRALORIA"].DisplayIndex = 50;
                    gvTemporada.Columns[51].Visible = false;
                    gvTemporada.Columns["OMITIR"].DisplayIndex = 54;
                    gvTemporada.Columns[66].Visible = false;

                    gvTemporada.Columns[53].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                    gvTemporada.Columns[54].HeaderCell.Style.BackColor = Color.LightSalmon;
                }
                catch (Exception er) { }
            }
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvConvenio.Rows)
            {
                dgvConvenio.Select();

                DataGridViewCheckBoxCell chk1 = (DataGridViewCheckBoxCell)rowp.Cells["COMPRAS"];
                dgvConvenio.BeginEdit(true);
                if (Convert.ToString(rowp.Cells["BONCK1"].Value) == "1") { chk1.Value = 1; }

                DataGridViewCheckBoxCell chk2 = (DataGridViewCheckBoxCell)rowp.Cells["CONTRALORIA"];
                dgvConvenio.BeginEdit(true);
                if (Convert.ToString(rowp.Cells["BONCK2"].Value) == "1") { chk2.Value = 1; }

                DataGridViewCheckBoxCell chk3 = (DataGridViewCheckBoxCell)rowp.Cells["OMITIR"];
                dgvConvenio.BeginEdit(true);
                if (Convert.ToString(rowp.Cells["DSPOMI"].Value) == "1") { chk3.Value = 1; }

                string algo = rowp.Cells["DSPPZA"].Value.ToString();

                if (algo == "0.0000")
                {
                    rowp.Cells["DSPCST"].Value = 0;
                }

                int kia = rowp.Index;
                Regs += 1;

                if (vez == "Si")
                {
                    dgvConvenio.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }

        private void rowStyleTemporada()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in gvTemporada.Rows)
            {
                gvTemporada.Select();
                DataGridViewCheckBoxCell chk1 = (DataGridViewCheckBoxCell)rowp.Cells[53];
                gvTemporada.BeginEdit(true);
                if (Convert.ToString(rowp.Cells[53].Value) == "1") { chk1.Value = 1; }

                DataGridViewCheckBoxCell chk2 = (DataGridViewCheckBoxCell)rowp.Cells[54];
                gvTemporada.BeginEdit(true);
                if (Convert.ToString(rowp.Cells[54].Value) == "1") { chk2.Value = 1; }
            }
        }

        private void cmbMarca_SelectedIndexChanged(object sender, EventArgs e)
        {
            //  marca = " ";
            ComboBox cmb = (ComboBox)sender;
            marca = cmb.SelectedItem.ToString();

            FechaCal = tbDesde.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            fechaHis = long.Parse(FechaFmt.ToString());

            if (dgvConvenio.Visible)
                BindData();
            else if (gvTemporada.Visible)
                BindDataTemp();

        }

        private void pbExcel_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            System.Data.DataTable dtDowns = (System.Data.DataTable)(dgvConvenio.DataSource);
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            int nc = dgvConvenio.Columns.Count;

            for (int ii = 1; ii <= nc; ii++)
            {

                xlWorkSheet.Cells[1, ii] = dgvConvenio.Columns[ii - 1].HeaderText;

            }

            System.Data.DataTable dtConvenio = (System.Data.DataTable)(dgvConvenio.DataSource);
            int nr = dgvConvenio.RowCount;
            this.pgbProg.Visible = true;

            pgbProg.Maximum = nr;
            pgbProg.Value = 0;
            int r = 0; // Renglon 6
            int rt = 3; // Renglon 6
            foreach (DataRow row in dtDowns.Rows)
            {
                var gsArray = new[]       {         row["DSPPRV"],  // 01
                                                    row["DSPNOM"],  // 02
                                                    row["DSPSTY"],  // 03 
                                                    row["DSPDES"],  // 04
                                                    row["DSPDCP"],  // 05  
                                                    row["DSPORD"],  // 06
                                                    row["DSPFRB"],  // 07
                                                    row["DSPPRB"],  // 08
                                                    row["DSPMRG"],  // 09
                                                    row["DSP4P3"],  // 10
                                                    row["DSPRTB"],  // 11
                                                    row["DSPRT2"],  // 12
                                                    row["DSPRT3"],  // 13
                                                    row["DSPRT4"],  // 14
                                                    row["DSPCAL"],  // 15
                                                    row["DSPCOR"],  // 16
                                                    row["DSPCLF"],  // 17 Se quita a solicitud de Paco
                                                    row["DSPONH"],  // 18
                                                    row["DSPONO"],  // 19
                                                    row["DSPRSTD"], // 20
                                                    row["DSPPDI"],  // 21                                                                 
                                                    row["DSPSM1"],  // 22
                                                    row["DSPSM2"],  // 23
                                                    row["DSPSM3"],  // 24
                                                    row["DSPSM4"],  // 25
                                                    row["DSPSM5"],  // 26
                                                    row["DSPSM6"],  // 27
                                                    row["DSPSM7"],  // 28 
                                                    row["DSPSM8"],  // 29
                                                    row["DSPPOR"],  // 30
                                                    row["DSPFRV"],  // 31 
                                                    row["DSPCST"],  // 32 
                                                    row["DSPPZA"],  // 33
                                                    row["DSPCSB"],  // 34 
                                                    row["DSPCBF"],  // 35 
                                                    row["DSPMAR"],  // 36
                                                    row["DSPBDG"],  // 37
                                                    row["DSPCSTA"], // 38
                                                    row["DSPPREA"], // 39
                                                    row["DRECB0"],  // 40
                                                    row["DRECB1"],  // 41 
                                                    row["DRECB2"],  // 42 
                                                    row["DRECB3"],  // 43 
                                                    row["DRECB4"],  // 44
                                                    row["DRECB5"],  // 45 
                                                    row["DRECB6"],  // 46
                                                    row["DRECB7"],  // 47
                                                    row["DRECB8"],  // 48
                                                    row["DSPASN"],  // 49
                                                    row["DSPORI"],  // 50
                                                    row["DSPRPG"],  // 51
                                                    row["DSPNMR"],  // 52 
                                                    row["DSPNCS"],  // 53
                                                    row["DSPREP"],  // 54 
                                                    row["DSPNRP"],  // 55
                                                    row["DSPFPX"],  // 56
                                                    row["DSPOBS"],  // 57
                                                    row["BONCK1"],  // 58
                                                    row["DSPUCP"],  // 59
                                                    row["DSPFCP"],  // 60
                                                    row["DSPHCP"],  // 61
                                                    row["BONCK2"],  // 62
                                                    row["DSPUCT"],  // 63
                                                    row["DSPFCT"],  // 64 
                                                    row["DSPHCT"],  // 65 
                                                    row["DSPOBC"]   // 66   
                };

                Range rng = xlWorkSheet.get_Range("A" + rt, "BN" + rt);
                rng.Value = gsArray;

                pgbProg.Value += 1;

                this.Text = "Convenio / " + " " + (r += 1).ToString() + " Registro(s)";

                // Pagar
                if (row["DSPCAL"].ToString() == " P a g a r") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.LightGreen; }
                // 15%
                if (row["DSPCAL"].ToString() == " 15%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Yellow; }
                // 20%
                if (row["DSPCAL"].ToString() == " 20%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Yellow; }
                // 25%
                if (row["DSPCAL"].ToString() == " 25%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Yellow; }
                // 30%
                if (row["DSPCAL"].ToString() == " 30%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.LightSalmon; }
                // 35%
                if (row["DSPCAL"].ToString() == " 35%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.LightSalmon; }
                // 40%
                if (row["DSPCAL"].ToString() == " 40%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.LightSalmon; }
                // Dev ó 40%
                if (row["DSPCAL"].ToString() == " 40%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 15].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["DSPCAL"].ToString() == " 50%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 15].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["DSPCAL"].ToString() == " 50%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 15].Cells.Font.Color = Color.White; }
                // Devolucion
                if (row["DSPCAL"].ToString() == "Devolucion") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 15].Cells.Font.Color = Color.White; }

                // Pagar
                if (row["DSPCOR"].ToString() == " P a g a r") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.LightGreen; }
                // 15%
                if (row["DSPCOR"].ToString() == " 15%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.Yellow; }
                // 20%
                if (row["DSPCOR"].ToString() == " 20%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.Yellow; }
                // 25%
                if (row["DSPCOR"].ToString() == " 25%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.Yellow; }
                // 30%
                if (row["DSPCOR"].ToString() == " 30%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.LightSalmon; }
                // 35%
                if (row["DSPCOR"].ToString() == " 35%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.LightSalmon; }
                // 40%
                if (row["DSPCOR"].ToString() == " 40%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.LightSalmon; }
                // Dev ó 40%
                if (row["DSPCOR"].ToString() == " 40%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 16].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["DSPCOR"].ToString() == " 50%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 16].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["DSPCOR"].ToString() == " 50%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 16].Cells.Font.Color = Color.White; }
                // Devolucion
                if (row["DSPCOR"].ToString() == "Devolucion") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 16].Cells.Font.Color = Color.White; }


                // Pagar
                if (row["DSPCLF"].ToString() == " P a g a r") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.LightGreen; }
                // 15%
                if (row["DSPCLF"].ToString() == " 15%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.Yellow; }
                // 20%
                if (row["DSPCLF"].ToString() == " 20%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.Yellow; }
                // 25%
                if (row["DSPCLF"].ToString() == " 25%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.Yellow; }
                // 30%
                if (row["DSPCLF"].ToString() == " 30%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.LightSalmon; }
                // 35%
                if (row["DSPCLF"].ToString() == " 35%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.LightSalmon; }
                // 40%
                if (row["DSPCLF"].ToString() == " 40%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.LightSalmon; }
                // Dev ó 40%
                if (row["DSPCLF"].ToString() == " 40%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 17].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["DSPCLF"].ToString() == " 50%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 17].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["DSPCLF"].ToString() == " 50%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 17].Cells.Font.Color = Color.White; }
                // Devolucion
                if (row["DSPCLF"].ToString() == "Devolucion") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 17].Cells.Font.Color = Color.White; }
                rt++;
            }
            xlWorkSheet.Columns[1].ColumnWidth = 3;
            xlWorkSheet.Columns[2].ColumnWidth = 30;
            xlWorkSheet.Columns[3].ColumnWidth = 15;
            xlWorkSheet.Columns[4].ColumnWidth = 30;
            xlWorkSheet.Columns[5].ColumnWidth = 20;
            xlWorkSheet.Columns[6].ColumnWidth = 10;
            xlWorkSheet.Columns[7].ColumnWidth = 6;
            xlWorkSheet.Columns[8].ColumnWidth = 6;
            xlWorkSheet.Columns[9].ColumnWidth = 10;
            xlWorkSheet.Columns[10].ColumnWidth = 10;
            xlWorkSheet.Columns[11].ColumnWidth = 5;
            xlWorkSheet.Columns[12].ColumnWidth = 5;
            xlWorkSheet.Columns[13].ColumnWidth = 5;
            xlWorkSheet.Columns[14].ColumnWidth = 5;
            xlWorkSheet.Columns[15].ColumnWidth = 5;
            xlWorkSheet.Columns[16].ColumnWidth = 5;
            xlWorkSheet.Columns[17].ColumnWidth = 5;
            xlWorkSheet.Columns[18].ColumnWidth = 10;
            xlWorkSheet.Columns[19].ColumnWidth = 4;
            xlWorkSheet.Columns[20].ColumnWidth = 4;
            xlWorkSheet.Columns[21].ColumnWidth = 4;
            xlWorkSheet.Columns[22].ColumnWidth = 4;
            xlWorkSheet.Columns[23].ColumnWidth = 4;
            xlWorkSheet.Columns[24].ColumnWidth = 4;
            xlWorkSheet.Columns[25].ColumnWidth = 4;
            xlWorkSheet.Columns[26].ColumnWidth = 4;
            xlWorkSheet.Columns[27].ColumnWidth = 4;
            xlWorkSheet.Columns[28].ColumnWidth = 4;
            xlWorkSheet.Columns[29].ColumnWidth = 4;
            xlWorkSheet.Columns[30].ColumnWidth = 4;
            xlWorkSheet.Columns[31].ColumnWidth = 10;
            xlWorkSheet.Columns[32].ColumnWidth = 10;
            xlWorkSheet.Columns[33].ColumnWidth = 10;
            xlWorkSheet.Columns[34].ColumnWidth = 10;
            xlWorkSheet.Columns[35].ColumnWidth = 10;
            xlWorkSheet.Columns[36].ColumnWidth = 10;
            xlWorkSheet.Columns[37].ColumnWidth = 10;
            xlWorkSheet.Columns[38].ColumnWidth = 10;
            xlWorkSheet.Columns[39].ColumnWidth = 10;
            xlWorkSheet.Columns[40].ColumnWidth = 10;
            xlWorkSheet.Columns[41].ColumnWidth = 10;
            xlWorkSheet.Columns[42].ColumnWidth = 10;
            xlWorkSheet.Columns[43].ColumnWidth = 10;
            xlWorkSheet.Columns[44].ColumnWidth = 10;
            xlWorkSheet.Columns[45].ColumnWidth = 10;
            xlWorkSheet.Columns[46].ColumnWidth = 10;
            xlWorkSheet.Columns[47].ColumnWidth = 10;
            xlWorkSheet.Columns[48].ColumnWidth = 10;
            xlWorkSheet.Columns[49].ColumnWidth = 10;
            xlWorkSheet.Columns[50].ColumnWidth = 10;
            xlWorkSheet.Columns[51].ColumnWidth = 10;
            xlWorkSheet.Columns[52].ColumnWidth = 10;
            xlWorkSheet.Columns[53].ColumnWidth = 10;
            xlWorkSheet.Columns[54].ColumnWidth = 10;
            xlWorkSheet.Columns[55].ColumnWidth = 10;
            xlWorkSheet.Columns[56].ColumnWidth = 10;
            xlWorkSheet.Columns[57].ColumnWidth = 50;
            xlWorkSheet.Columns[58].ColumnWidth = 10;
            xlWorkSheet.Columns[59].ColumnWidth = 10;
            xlWorkSheet.Columns[60].ColumnWidth = 10;
            xlWorkSheet.Columns[61].ColumnWidth = 10;
            xlWorkSheet.Columns[62].ColumnWidth = 10;
            xlWorkSheet.Columns[63].ColumnWidth = 10;
            xlWorkSheet.Columns[64].ColumnWidth = 10;
            xlWorkSheet.Columns[65].ColumnWidth = 10;
            xlWorkSheet.Columns[66].ColumnWidth = 100;

            var Rang1 = xlWorkSheet.get_Range("A1", "D1");
            Rang1.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 5].Cells.Interior.Color = Color.LightGreen;
            var Rang3 = xlWorkSheet.get_Range("F1", "H1");
            Rang3.Interior.Color = Color.LightSeaGreen;

            xlWorkSheet.Cells[1, 9].Cells.Interior.Color = Color.LightSlateGray;
            xlWorkSheet.Cells[1, 10].Cells.Interior.Color = Color.LightSlateGray;

            var Rang4 = xlWorkSheet.get_Range("K1", "N1");
            Rang4.Interior.Color = Color.LightCoral;

            xlWorkSheet.Cells[1, 15].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 16].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 17].Cells.Interior.Color = Color.LightSalmon;

            xlWorkSheet.Cells[1, 18].Cells.Interior.Color = Color.LightSlateGray;
            xlWorkSheet.Cells[1, 19].Cells.Interior.Color = Color.LightSlateGray;
            xlWorkSheet.Cells[1, 20].Cells.Interior.Color = Color.LightSlateGray;

            var Rang21 = xlWorkSheet.get_Range("U1", "U1");
            Rang21.Interior.Color = Color.LightSeaGreen;

            var Rang5 = xlWorkSheet.get_Range("V1", "AC1");
            Rang5.Interior.Color = Color.LightSkyBlue;

            var Rang6 = xlWorkSheet.get_Range("AD1", "AD1");
            Rang6.Interior.Color = Color.LightGreen;

            xlWorkSheet.Cells[1, 31].Cells.Interior.Color = Color.LightSeaGreen;
            xlWorkSheet.Cells[1, 32].Cells.Interior.Color = Color.LightCoral;
            xlWorkSheet.Cells[1, 33].Cells.Interior.Color = Color.LightCoral;
            xlWorkSheet.Cells[1, 34].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 35].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 36].Cells.Interior.Color = Color.LightSeaGreen;
            xlWorkSheet.Cells[1, 37].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 38].Cells.Interior.Color = Color.LightSalmon;

            var Rang7 = xlWorkSheet.get_Range("AL1", "AM1");
            Rang7.Interior.Color = Color.LightSlateGray;

            var Rang8 = xlWorkSheet.get_Range("AN1", "AV1");
            Rang8.Interior.Color = Color.LightCoral;

            xlWorkSheet.Cells[1, 49].Cells.Interior.Color = Color.DarkOliveGreen;
            xlWorkSheet.Cells[1, 50].Cells.Interior.Color = Color.DarkOliveGreen;
            xlWorkSheet.Cells[1, 51].Cells.Interior.Color = Color.DarkOliveGreen;
            xlWorkSheet.Cells[1, 52].Cells.Interior.Color = Color.DarkOliveGreen;
            xlWorkSheet.Cells[1, 53].Cells.Interior.Color = Color.DarkOliveGreen;

            var Rang9 = xlWorkSheet.get_Range("BC1", "BD1");
            Rang9.Interior.Color = Color.LightSlateGray;

            var Rang10 = xlWorkSheet.get_Range("BE1", "BI1");
            Rang10.Interior.Color = Color.LimeGreen;

            var Rang11 = xlWorkSheet.get_Range("BJ1", "BN1");
            Rang11.Interior.Color = Color.DarkBlue;

            var Rang2 = xlWorkSheet.get_Range("A1", "BN1");
            Rang2.WrapText = true;
            Rang2.Font.Bold = true;
            Rang2.Font.Color = Color.White;
            Rang2.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang2.Font.Underline = true;
            Rang2.HorizontalAlignment = HorizontalAlignment.Center;

            String Rango = "A2" + ":" + "BN" + rt;
            Excel.Range SourceRange = (Excel.Range)xlWorkSheet.get_Range("A2", "BN" + rt); // or whatever range you want here
            FormatAsTable(SourceRange, "Table1", "TableStyleMedium2");

            xlWorkSheet.Rows[2].Hidden = true;

            xlWorkSheet.Columns["C"].HorizontalAlignment = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["F"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["G"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["O:Q"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["P"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["U:AE"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AJ:AK"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AN:BD"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["BF:BM"].HorizontalAlignment = XlHAlign.xlHAlignCenter;

            xlWorkSheet.Columns["G"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["H"].NumberFormat = "#,###";
            xlWorkSheet.Columns["I:N"].NumberFormat = "#,###.00";
            xlWorkSheet.Columns["R:AC"].NumberFormat = "#,###";
            xlWorkSheet.Columns["AD"].NumberFormat = "#,###.00";
            xlWorkSheet.Columns["AF"].NumberFormat = "#,###.00";
            xlWorkSheet.Columns["AE"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["AF"].NumberFormat = "#,###.00";
            xlWorkSheet.Columns["AG"].NumberFormat = "#,###";
            xlWorkSheet.Columns["AH"].NumberFormat = "#,###.00";
            xlWorkSheet.Columns["AJ"].NumberFormat = "#,###.00";
            xlWorkSheet.Columns["AK:AK"].NumberFormat = "#,###";
            xlWorkSheet.Columns["AL:AM"].NumberFormat = "#,###.00";
            xlWorkSheet.Columns["AN:AV"].NumberFormat = "#,###";
            xlWorkSheet.Columns["BD"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["BH"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["BI"].NumberFormat = "##-##-##";
            xlWorkSheet.Columns["BL"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["BM"].NumberFormat = "##-##-##";


            var range = xlWorkSheet.get_Range("A3", "A3");
            range.Select();



            //xlApp.Range["Q"].Select();

            xlApp.Range["Q:Q"].EntireColumn.Delete();
            //xlApp.Range["AD:AD"].EntireColumn.Delete();
            xlApp.Range["AH:AH"].EntireColumn.Delete();
            xlApp.Range["AZ:AZ"].EntireColumn.Delete();
            xlApp.Range["BL:BP"].EntireColumn.Delete();


            string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
            xlApp.ActiveWindow.Zoom = 80;
            xlWorkBook.SaveAs("C:\\Reportes\\Convenio" + Hoy + ".xlsx", Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            string comando = @"C:\\Reportes\\Convenio" + Hoy + ".xlsx";
            ExecuteCommand(comando);

            this.pgbProg.Visible = false;
            this.Cursor = Cursors.Default;
        }

        static void ExecuteCommand(string _Command)
        {
            //Indicamos que deseamos inicializar el proceso cmd.exe junto a un comando de arranque. 
            //(/C, le indicamos al proceso cmd que deseamos que cuando termine la tarea asignada se cierre el proceso).
            //Para mas informacion consulte la ayuda de la consola con cmd.exe /? 
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;
            //Inicializa el proceso
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            string result = proc.StandardOutput.ReadToEnd();
        }

        public void FormatAsTable(Excel.Range SourceRange, string TableName, string TableStyleName)
        {
            SourceRange.Worksheet.ListObjects.Add(XlListObjectSourceType.xlSrcRange,
            SourceRange, System.Type.Missing, XlYesNoGuess.xlYes, System.Type.Missing).Name =
                TableName;
            SourceRange.Select();
            SourceRange.Worksheet.ListObjects[TableName].TableStyle = TableStyleName;
            SourceRange.Worksheet.ListObjects[TableName].ShowAutoFilter = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowHeaders = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowTotals = false;
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        private void dgvConvenio_Sorted(object sender, EventArgs e)
        {
            nr = dgvConvenio.RowCount;

            if (nr > 0)
            {
                SetFontAndColors();
                rowStyle();
            }
        }

        private void dgvConvenio_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (bnaSimulador == false)
            {
                this.dgvConvenio.ContextMenuStrip = cmMenu;

                if (e.Button == MouseButtons.Right)
                {
                    var hti = dgvConvenio.HitTest(e.X, e.Y);
                    int Row = e.RowIndex;
                    int Col = e.ColumnIndex;

                    MmsWin.Front.Utilerias.Fotos.numMarca = this.dgvConvenio.CurrentRow.Cells["DSPNMR"].Value.ToString();
                    MmsWin.Front.Utilerias.Fotos.numPrv   = this.dgvConvenio.CurrentRow.Cells["DSPPRV"].Value.ToString();
                    MmsWin.Front.Utilerias.Fotos.numSty   = this.dgvConvenio.CurrentRow.Cells["DSPSTY"].Value.ToString();

                    MmsWin.Front.Utilerias.VarTem.tmpPrv   = this.dgvConvenio.CurrentRow.Cells["DSPPRV"].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpNom   = this.dgvConvenio.CurrentRow.Cells["DSPNOM"].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpSty   = this.dgvConvenio.CurrentRow.Cells["DSPSTY"].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpDes   = this.dgvConvenio.CurrentRow.Cells["DSPDES"].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpOrden = this.dgvConvenio.CurrentRow.Cells["DSPORD"].Value.ToString();

                    MmsWin.Front.Utilerias.VarTem.tmpFchRev  = this.dgvConvenio.CurrentRow.Cells["DSPFRV"].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpCalConv = this.dgvConvenio.CurrentRow.Cells["DSPCAL"].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpRentab  = this.dgvConvenio.CurrentRow.Cells["DSPRTB"].Value.ToString();

                    MmsWin.Front.Utilerias.VarTem.NotaProveedor   = this.dgvConvenio.CurrentRow.Cells["DSPPRV"].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.NotaNombre      = this.dgvConvenio.CurrentRow.Cells["DSPNOM"].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.NotaEstilo      = this.dgvConvenio.CurrentRow.Cells["DSPSTY"].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.NotaDescripcion = this.dgvConvenio.CurrentRow.Cells["DSPDES"].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.ConvMarcaNo     = this.dgvConvenio.CurrentRow.Cells["DSPNMR"].Value.ToString();
                    string varMarca = MmsWin.Front.Utilerias.VarTem.ConvMarcaNo;

                    MmsWin.Front.Utilerias.VarTem.tmpCalificacionAnt = this.dgvConvenio.CurrentRow.Cells["DSPCAL"].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpCalificacionFin = this.dgvConvenio.CurrentRow.Cells["DSPCLF"].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpOnHand          = this.dgvConvenio.CurrentRow.Cells["DSPONH"].Value.ToString();

                    MmsWin.Front.Utilerias.VarTem.tmpCtoActu  = this.dgvConvenio.CurrentRow.Cells["DSPCSTA"].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpCtoTotal = this.dgvConvenio.CurrentRow.Cells["DSPCST"].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpCtoBoni  = this.dgvConvenio.CurrentRow.Cells["DSPCSB"].Value.ToString();

                    MmsWin.Front.Utilerias.VarTem.tmpMarcaGrid = this.dgvConvenio.CurrentRow.Cells["DSPNMR"].Value.ToString();

                    if (varMarca != "")
                    { }
                    else { varMarca = marca; }
                    string varFchBon = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenMarcaConfiguracion1(varMarca);
                    varFchBon = varFchBon.Substring(4, 2) + "/" + varFchBon.Substring(2, 2) + "/" + "20" + varFchBon.Substring(0, 2);
                    MmsWin.Front.Utilerias.VarTem.NotaFchBonifica = varFchBon;

                    // Guarda Fecha Revision /Calificacion
                    string ParFchRevision = this.dgvConvenio.CurrentRow.Cells["DSPFRV"].Value.ToString();
                    FechaCal = ParFchRevision;
                    FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                    MmsWin.Front.Utilerias.VarTem.NotaFchRevision = FechaFmt;

                    //cmMenu.Visible = true;
                }

                if (e.Button == MouseButtons.Left)
                {
                    var hti = dgvConvenio.HitTest(e.X, e.Y);
                    int Row = e.RowIndex;
                    int Col = e.ColumnIndex;

                    string validaContraloria = this.dgvConvenio.CurrentRow.Cells["BONCK2"].Value.ToString();
                    string bandera;
                    if (validaContraloria == "1")
                    {
                        bandera = "1";
                        this.dgvConvenio.CurrentRow.Cells["REPSTY"].ReadOnly = true;
                        this.dgvConvenio.CurrentRow.Cells["DSPOBS"].ReadOnly = true;
                    }
                    else
                    {
                        bandera = "0";
                        this.dgvConvenio.CurrentRow.Cells["COMPRAS"].ReadOnly = false;
                        this.dgvConvenio.CurrentRow.Cells["DSPOBS"].ReadOnly = false;
                    }
                    string Controles = "DSPOBS";
                    string ValHab = bandera;
                    string ValVis = "1";
                    string tipo = "Columna";
                    AplicaSeguridad(Controles, ValHab, ValVis, tipo);
                    Controles = "COMPRAS";
                    ValHab = bandera;
                    ValVis = "1";
                    tipo = "Columna";
                    AplicaSeguridad(Controles, ValHab, ValVis, tipo);
                }
            }
            else
            {
                #region " Bonificación parcial con revisión a los 45 días "

                if (e.Button == MouseButtons.Right)
                {
                    this.dgvConvenio.ContextMenuStrip = cmSimulador;

                    if (comprador == "999")
                    {
                        MessageBox.Show("Debe seleccionar un comprador y marca", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

                #endregion

            }
        }

        private void fotoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MuestraFoto();
        }

        private void MuestraFoto()
        {
            try
            {
                Fotos i = new Fotos();
                i.Show();
            }
            catch { }
            finally { }
        }

        public int controles(string findControl)
        {
            int strNumber;
            int strIndex = 0;

            string[] segArray = { "cmbMarca", "cbCompradores", "tbCal01" };
            for (strNumber = 0; strNumber < segArray.Length; strNumber++)
            {
                //Emplo de manipulacion de Controles               // 
                string controles = "cmbMarca";
                bool valorFoT = true;
                this.Controls[controles].Visible = valorFoT;

                findControl = segArray[strNumber].ToString();
                this.Controls[findControl].Enabled = true;

            }
            return strIndex;
        }

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            marca = " ";
            ComboBox cmbMarca = (ComboBox)sender;
            marca = cmbMarca.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpMarca = cbMarca.SelectedValue.ToString();

            if (dgvConvenio.Visible)
                BindData();
            else if (gvTemporada.Visible)
                BindDataTemp();

        }

        private void cbCompradores_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                comprador = " ";
                nr = 0;
                ComboBox cmbComprador = (ComboBox)sender;
                comprador = cmbComprador.SelectedValue.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpComprador = cmbComprador.SelectedValue.ToString();

                BindData();
            }
            catch { }
        }

        /// <summary>
        /// Inserta los controles del formulario a la tabla MMSATOBJ.SAT177SCLS
        /// </summary>
        /// <param name="Aplicacion">Nombre de la aplicación</param>
        /// <param name="Modulo">Nombre del módulo</param>
        /// <param name="Usuario">Usuario que inicio sesión</param>
        /// <remarks>
        ///     Desarrollador: Gustavo de los Santos | 08/12/2016
        ///     Actualizo: Omar Cervantes  | 28/02/2017
        /// </remarks>
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            #region [ Insertar los controles del formulario ]

            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");

            //Definición del DataTable
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();

                //Valores generales para cada renglon  
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Usuario"] = Usuario;

                if (X.GetType() != typeof(ToolStrip))
                {
                    workRow["Control"] = X.Name;
                    workRow["Tipo"] = "Control";

                    dtControles.Rows.Add(workRow);
                }
                else
                {
                    DataRow toolStrip = dtControles.NewRow();

                    //Valores generales para cada renglon  
                    toolStrip["Aplicacion"] = Aplicacion;
                    toolStrip["Modulo"] = Modulo;
                    toolStrip["Usuario"] = Usuario;

                    toolStrip["Control"] = X.Name;
                    toolStrip["Tipo"] = "ToolStrip";//X.GetType().ToString();

                    dtControles.Rows.Add(toolStrip);

                    foreach (ToolStripItem item in tsToolStrip.Items)
                    {
                        DataRow toolStripControls = dtControles.NewRow();

                        //Valores generales para cada renglon  
                        toolStripControls["Aplicacion"] = Aplicacion;
                        toolStripControls["Modulo"] = Modulo;
                        toolStripControls["Usuario"] = Usuario;

                        //Si el control es del tipo "ToolStripButton"
                        if (item.GetType() == typeof(System.Windows.Forms.ToolStripButton))
                        {
                            toolStripControls["Control"] = item.Name;
                            toolStripControls["Tipo"] = "ToolStripButton";

                            dtControles.Rows.Add(toolStripControls);
                        }

                        //Si el control es del tipo "ToolStripComboBox"
                        if (item.GetType() == typeof(System.Windows.Forms.ToolStripComboBox))
                        {
                            toolStripControls["Control"] = item.Name;
                            toolStripControls["Tipo"] = "ToolStripComboBox";

                            dtControles.Rows.Add(toolStripControls);
                        }

                        //Si el control es del tipo "ToolStripSplitButton"
                        if (item.GetType() == typeof(System.Windows.Forms.ToolStripSplitButton))
                        {
                            toolStripControls["Control"] = item.Name;
                            toolStripControls["Tipo"] = "ToolStripSplitButton";

                            dtControles.Rows.Add(toolStripControls);
                        }
                    }
                }
            }

            #endregion

            #region [ Insertar columnas ]

            // Columnas                                                                  
            string NomCol;
            Int32 NoCol = dgvConvenio.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvConvenio.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;

                dtControles.Rows.Add(workRow);
            }

            #endregion

            #region [ Insertar los menus ]

            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;

            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;

                dtControles.Rows.Add(workRow);
            }

            #endregion

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void pbBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Reprogramacion").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana Reprogramacion ya esta abierta...");
                    }
                    else
                    {
                        Reprogramacion i = new Reprogramacion();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void dgvConvenio_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F6)
            {
                try
                {
                    Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                                  "Nota").SingleOrDefault<Form>();
                    {
                        if (existe != null)
                        {
                            MessageBox.Show("La Ventana ya esta abierta...");
                        }
                        else
                        {
                            ValidaReprog();
                            if (ind == true)
                            {
                                Reprog i = new Reprog();

                                //Cambiar mañana
                                //i.CalificacionRentabilidad = 0;

                                i.Show();
                            }
                            else
                            {
                                MessageBox.Show("Se debe seleccionar Marca y Comprador ...");
                            }
                        }
                    }
                }
                catch { }
                finally { }
            }
        }

        private void ValidaReprog()
        {
            MmsWin.Front.Utilerias.VarTem.tmpMarca = cbMarca.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpComprador = cbCompradores.SelectedValue.ToString();

            string IndMarca = MmsWin.Front.Utilerias.VarTem.tmpMarca;
            string IndComprador = MmsWin.Front.Utilerias.VarTem.tmpComprador;

            if (IndMarca == "999" | IndComprador == "999" | IndMarca == "" | IndComprador == "")
            {
                ind = false;
            }
            else
            {
                ind = true;
            }
        }

        private void dgvConvenio_SelectionChanged(object sender, EventArgs e)
        {
            CultureInfo provider = CultureInfo.InvariantCulture;

            try
            {
                dgvConvenio.Select();
                dgvConvenio.Focus();

                               #region [ Variables para los formatos ]
                //Asignación de valores a las propiedades
                //Desarrollador OCG 
                eReprogramaciones.Temporada = this.dgvConvenio.CurrentRow.Cells["DSPASN"].Value.ToString();
                eReprogramaciones.TipoCalificacion = "";
                eReprogramaciones.strCalificacion = this.dgvConvenio.CurrentRow.Cells["DSPCAL"].Value.ToString();
                eReprogramaciones.intFechaReprogramacion = "0";

                decimal.TryParse(this.dgvConvenio.CurrentRow.Cells["DSPCAL"].Value.ToString().Replace("%", ""), out CalificacionRentabilidad);
                eReprogramaciones.decCalificacion = CalificacionRentabilidad;

                eReprogramaciones.CalificacionRentabilidad = Convert.ToDecimal(this.dgvConvenio.CurrentRow.Cells["DSPRTB"].Value.ToString());


                //Convertir fecha AS400 6 digitos a Datetime
                DateTime dt; //Fecha revisión en formato de fecha corta
                DateTime.TryParseExact(this.dgvConvenio.CurrentRow.Cells["DSPFRV"].Value.ToString(),
                                        "yyMMdd",
                                        CultureInfo.InvariantCulture,
                                        DateTimeStyles.None, out dt);

                eReprogramaciones.FechaRevision    = dt.ToShortDateString();
                eReprogramaciones.intFechaRevision = this.dgvConvenio.CurrentRow.Cells["DSPFRV"].Value.ToString();

                eReprogramaciones.MarcaID     = this.dgvConvenio.CurrentRow.Cells["DSPNMR"].Value.ToString();
                eReprogramaciones.OrdenCompra = this.dgvConvenio.CurrentRow.Cells["DSPORD"].Value.ToString();

                eReprogramaciones.ProveedorID = this.dgvConvenio.CurrentRow.Cells["DSPPRV"].Value.ToString();
                eReprogramaciones.Proveedor   = this.dgvConvenio.CurrentRow.Cells["DSPNOM"].Value.ToString();

                eReprogramaciones.EstiloID = this.dgvConvenio.CurrentRow.Cells["DSPSTY"].Value.ToString();
                eReprogramaciones.Estilo   = this.dgvConvenio.CurrentRow.Cells["DSPDES"].Value.ToString();

                //eReprogramaciones.CompradorID = this.dgvConvenio.CurrentRow.Cells["DSPDCP"].Value.ToString();
                //eReprogramaciones.Comprador = this.dgvConvenio.CurrentRow.Cells[4].Value.ToString();

                eReprogramaciones.CompradorID = this.cbCompradores.SelectedValue.ToString();
                eReprogramaciones.Comprador   = this.dgvConvenio.CurrentRow.Cells["DSPDCP"].Value.ToString();

                eReprogramaciones.OnHand      = this.dgvConvenio.CurrentRow.Cells["DSPONH"].Value.ToString();
                eReprogramaciones.CostoTotal  = this.dgvConvenio.CurrentRow.Cells["DSPCST"].Value.ToString();
                eReprogramaciones.CostoActual = this.dgvConvenio.CurrentRow.Cells["DSPCSTA"].Value.ToString();

                eReprogramaciones.MontoBonificacion = Convert.ToDecimal(this.dgvConvenio.CurrentRow.Cells["DSPCSB"].Value.ToString());
                eReprogramaciones.PiezasBonificar = Convert.ToDecimal(this.dgvConvenio.CurrentRow.Cells["DSPPZA"].Value.ToString());

                eReprogramaciones.Usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                //----------------------------------------------------------------------
                #endregion


                #region [ Variables nativas ]

                MmsWin.Front.Utilerias.Fotos.numMarca = this.dgvConvenio.CurrentRow.Cells["DSPNMR"].Value.ToString();
                MmsWin.Front.Utilerias.Fotos.numPrv   = this.dgvConvenio.CurrentRow.Cells["DSPPRV"].Value.ToString();
                MmsWin.Front.Utilerias.Fotos.numSty   = this.dgvConvenio.CurrentRow.Cells["DSPSTY"].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.tmpPrv = this.dgvConvenio.CurrentRow.Cells["DSPPRV"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpNom = this.dgvConvenio.CurrentRow.Cells["DSPNOM"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpSty = this.dgvConvenio.CurrentRow.Cells["DSPSTY"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpDes = this.dgvConvenio.CurrentRow.Cells["DSPDES"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpCompDesc = this.dgvConvenio.CurrentRow.Cells["DSPDCP"].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.tmpFchRev = this.dgvConvenio.CurrentRow.Cells["DSPFRV"].Value.ToString();

                string validaContraloria = this.dgvConvenio.CurrentRow.Cells["BONCK2"].Value.ToString();
                if (validaContraloria == "1")
                {
                    this.dgvConvenio.CurrentRow.Cells["DSPCAL"].ReadOnly = true;
                    this.dgvConvenio.CurrentRow.Cells["DSPCOR"].ReadOnly = true;
                    this.dgvConvenio.CurrentRow.Cells["DSPCLF"].ReadOnly = true;
                    this.dgvConvenio.CurrentRow.Cells["DSPCBF"].ReadOnly = true;
                    this.dgvConvenio.CurrentRow.Cells["DSPOBS"].ReadOnly = true;
                    this.dgvConvenio.CurrentRow.Cells["BONCK1"].ReadOnly = true;
                }
                else
                {
                    this.dgvConvenio.CurrentRow.Cells["DSPCAL"].ReadOnly = false;
                    this.dgvConvenio.CurrentRow.Cells["DSPCOR"].ReadOnly = false;
                    this.dgvConvenio.CurrentRow.Cells["DSPCLF"].ReadOnly = false;
                    this.dgvConvenio.CurrentRow.Cells["DSPCBF"].ReadOnly = false;
                    this.dgvConvenio.CurrentRow.Cells["DSPOBS"].ReadOnly = false;
                    this.dgvConvenio.CurrentRow.Cells["BONCK1"].ReadOnly = false;
                }

                #endregion
            }
            catch { }
        }

        private void ResumenPorProveedor()
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "ResumenXPrv").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("El Resumen por proveedor ya esta abierta");
                    }
                    else
                    {
                        ResumenXPrv i = new ResumenXPrv();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void ResumenPorCalificacion()
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "ResumenXcal").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("El Resumen por calificacion ya esta abierta");
                    }
                    else
                    {
                        ResumenXcal i = new ResumenXcal();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void Kardex()
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Kardex").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del Kardex ya esta abierta");
                    }
                    else
                    {
                        Kardex i = new Kardex();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void dgvConvenio_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {

                SendKeys.Send("{UP}");

                SendKeys.Flush();

                MmsWin.Front.Utilerias.Fotos.numMarca = this.dgvConvenio.CurrentRow.Cells["DSPNMR"].Value.ToString();
                MmsWin.Front.Utilerias.Fotos.numPrv   = this.dgvConvenio.CurrentRow.Cells["DSPPRV"].Value.ToString();
                MmsWin.Front.Utilerias.Fotos.numSty   = this.dgvConvenio.CurrentRow.Cells["DSPSTY"].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.tmpPrv = this.dgvConvenio.CurrentRow.Cells["DSPPRV"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpNom = this.dgvConvenio.CurrentRow.Cells["DSPNOM"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpSty = this.dgvConvenio.CurrentRow.Cells["DSPSTY"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpDes = this.dgvConvenio.CurrentRow.Cells["DSPDES"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpCompDesc = this.dgvConvenio.CurrentRow.Cells["DSPDCP"].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.tmpFchRev = this.dgvConvenio.CurrentRow.Cells["DSPFRV"].Value.ToString();

                Kardex();
            }
        }

        private void btResumenXProveedor_Click(object sender, EventArgs e)
        {
            ResumenPorProveedor();
        }

        private void btResumenXCalificacion_Click(object sender, EventArgs e)
        {
            ResumenPorCalificacion();
        }

        private void btSimulador_Click(object sender, EventArgs e)
        {
            if (btSimulador.BackColor == Color.DarkOrange)
            {
                btSimulador.BackColor = Color.White;
                this.tsToolStrip.BackColor = Color.White;

                btSimulador.ForeColor = Color.Black;
                MmsWin.Front.Utilerias.VarTem.tmpUsrConv = "CALIFICA";
                MmsWin.Front.Utilerias.VarTem.simulador = false;

                bnaSimulador = false;

                this.dgvConvenio.ContextMenuStrip = cmMenu;

                //Ocultar los controles de fechas que se usan para la bonificación anticipada
                //se hacen visibles y se ocultan desde el botón de pre-calificaciones
                this.lblFechas.Visible = false;
                this.cboFechas.Visible = false;

                this.tbDesde.Enabled = true;
                this.tbHasta.Enabled = true;

                BindData();

                Seguridad("Convenio", "Convenio", ParUser);

            }
            else
            {

                MmsWin.Front.Utilerias.VarTem.tmpUsrConv = MmsWin.Front.Utilerias.VarTem.tmpUser;
                MmsWin.Front.Utilerias.VarTem.simulador = true;

                FechaCal = tbDesde.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                string ParFchIni = FechaFmt;
                string ParFchFin = FechaFmt;
                string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;

                string message = "Se va a cambiar la vista al modo de Pre-Calificación.  \n\nEn este modo solo existirá información de pre-calificación de las siguientes 5 semanas. \n\nPara regresar la ventana al modo Calificación, solo haga click de nuevo en el mismo botón. \n\n¿Desea continuar?";
                string caption = "Aviso";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;
                result = MessageBox.Show(message, caption, buttons, MessageBoxIcon.Question);

                if (result == System.Windows.Forms.DialogResult.Yes)
                {

                    bnaSimulador = true;

                    btSimulador.BackColor = Color.DarkOrange;
                    btSimulador.ForeColor = Color.White;

                    this.tsToolStrip.BackColor = Color.DarkOrange;

                    this.lblFechas.Visible = true;
                    this.cboFechas.Visible = true;

                    this.tbDesde.Enabled = false;
                    this.tbHasta.Enabled = false;

                    //Apagar todos los botones para evitar errores
                    for (int i = 0; i < 9; i++)
                    {
                        this.tsToolStrip.Items[i].Enabled = false;
                    }

                    this.dgvConvenio.ContextMenuStrip = cmSimulador;

                    // Esta sección se comenta por que la ejecución de la precalificación se realizara de forma
                    // manual los días lunes y se calificará a 5 semanas
                    //MmsWin.Negocio.Convenio.Convenio.GetInstance().EjecutaSimulador1(ParFchIni, ParFchFin, ParUsuario);



                    cboFechas.ComboBox.DataSource = Negocio.Convenio.Convenio.ObtenFechasPrecalificacion();
                    cboFechas.ComboBox.DisplayMember = "DSPFCH";
                    cboFechas.ComboBox.ValueMember = "DSPFCH";

                    cboFechas.ComboBox.SelectedIndex = 0;

                    tipoDeConsulta();
                    BindData();

                    this.Cursor = Cursors.Default;
                }
            }
        }

       //private void reprogramacionTSMI_Click(object sender, EventArgs e)
       // {

       //     decimal CalificacionMinima = 0;


       //     try
       //     {
       //         Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
       //                       "Reprog").SingleOrDefault<Form>();
       //         {
       //             if (existe != null)
       //             {
       //                 MessageBox.Show("La ventana de \"Reprogramacion\" ya esta abierta...");
       //             }
       //             else
       //             {
       //                 ValidaReprog();

       //                 if (ind == false)
       //                 {
       //                     MessageBox.Show("Debe de seleccionar a un comprador.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
       //                     return;
       //                 }

       //                 //Validar que la marca sea "Melody"
       //                 if (eReprogramaciones.MarcaID == "10")
       //                 {
       //                     MessageBox.Show("Las reprogramaciones en esta pantalla solo aplican para 'Milano y Home & Fashion'." +
       //                         "\n\nLas reprogramaciones para Melody se deben realizar desde el icono de " +
       //                         "\nMELODY.", "REGLA REPROGRAMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
       //                     return;
       //                 }


       //                 //Validar que el estilo seleccionado sea de Toda Temporada
       //                 if (eReprogramaciones.Temporada != "TT")
       //                 {
       //                     MessageBox.Show("Los estilos de temporada no pueden ser reprogramados.", "REGLA REPROGRAMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
       //                     return;
       //                 }

       //                 /*
       //                  * COMENTADO POR CAMBIO DE POLITICA, NO BORRAR
       //                 //Validar que el estilo no sea de importación
       //                 if (Negocio.Convenio.Reprogramacion.ProveedorNacional(NumeroProveedor))
       //                 {
       //                     MessageBox.Show("Estilos de importación no pueden ser reprogramados.", "REGLA REPROGRAMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
       //                     return;
       //                 }
       //                 */
       //                 if (eReprogramaciones.strCalificacion.Trim().Replace(" ", "").ToUpper() == "POSTERGAR")
       //                 {
       //                     MessageBox.Show("No se pueden generar reprogramaciones cuando se tiene el estatus de 'Postergar'.", "REGLA REPROGRAMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
       //                     return;
       //                 }

       //                 //Si la calificación es > a 0 y no es una cadena vacia
       //                 if (CalificacionRentabilidad > 0 && eReprogramaciones.strCalificacion != "")
       //                 {
       //                     //Si la fecha de revisión es menor al año actual, se le aumenta un año
       //                     // para encontrar su coincidencia en la vista de MMSATOBJ.SAT177TART
       //                     if ((Convert.ToDateTime(eReprogramaciones.FechaRevision).Year < DateTime.Now.Year))
       //                     {
       //                         eReprogramaciones.FechaRevision = Convert.ToString(Convert.ToDateTime(eReprogramaciones.FechaRevision).AddYears(1));
       //                     }

       //                     CalificacionMinima = Convert.ToDecimal(
       //                                             Negocio.Convenio.Reprogramacion.PorcentajeMinimoReprogramar(
       //                                                     Convert.ToInt32(eReprogramaciones.MarcaID),
       //                                                     Convert.ToDateTime(eReprogramaciones.FechaRevision))
       //                                           );

       //                     if (CalificacionRentabilidad >= CalificacionMinima)
       //                     {
       //                         //ResultadoValidacion = Reglas.ValidarReglasReprogramacion(CalificacionRentabilidad, Temporada);

       //                         //if (ResultadoValidacion > 0)
       //                         //{
       //                         //    MessageBox.Show(Reglas.MensajeValidacion((Reglas.Excepciones)ResultadoValidacion), "REGLA REPROGRAMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
       //                         //    return;
       //                         //}

       //                         if (ind == true)
       //                         {
       //                             Reprog i = new Reprog();

       //                             i.eReprogramaciones = eReprogramaciones;

       //                             i.TopLevel = true;
       //                             i.WindowState = FormWindowState.Normal;

       //                             i.ShowDialog(this);

       //                             i.Activate();
       //                         }
       //                         else
       //                         {
       //                             MessageBox.Show("Se debe seleccionar Marca y Comprador ...");
       //                         }
       //                     }
       //                     else
       //                     {
       //                         MessageBox.Show(string.Format("La calificación mínima para reprogramar es: {0} y su calificación es: {1}", CalificacionMinima, CalificacionRentabilidad), "REGLA REPROGRAMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
       //                     }

       //                 }
       //                 else
       //                 {
       //                     MessageBox.Show(string.Format("No se puede reprogramar cuando la calificación es: {0} ", eReprogramaciones.strCalificacion), "REGLA REPROGRAMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

       //                 }
       //             }
       //         }
       //     }
       //     catch (Exception ex)
       //     {
       //         throw ex;
       //     }
       //     finally { }


       // }
        
        private void reprogramacionTSMI_Click(object sender, EventArgs e)
        {
            decimal CalificacionMinima = 0;

            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Reprog").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana de \"Reprogramacion\" ya esta abierta...");
                    }
                    else
                    {
                        ValidaReprog();

                        if (ind == false)
                        {
                            MessageBox.Show("Debe de seleccionar a un comprador.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }

                        //Validar que la marca sea "Melody"
                        if (eReprogramaciones.MarcaID == "10")
                        {
                            MessageBox.Show("Las reprogramaciones en esta pantalla solo aplican para 'Milano y Home & Fashion'." +
                                "\n\nLas reprogramaciones para Melody se deben realizar desde el icono de " +
                                "\nMELODY.", "REGLA REPROGRAMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return;
                        }

                        if (eReprogramaciones.strCalificacion.Trim().Replace(" ", "").ToUpper() == "POSTERGAR" && Negocio.Convenio.Convenio.banderaFullPateo(Convert.ToInt32(eReprogramaciones.MarcaID)) == false)
                        {
                            MessageBox.Show("No se pueden generar reprogramaciones cuando se tiene el estatus de 'Postergar'.", "REGLA REPROGRAMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return;
                        }

                        if (Negocio.Convenio.Convenio.banderaFullPateo(Convert.ToInt32(eReprogramaciones.MarcaID)) == false)
                        {
                            //Si la calificación es > a 0 y no es una cadena vacia
                            if (CalificacionRentabilidad > 0 && eReprogramaciones.strCalificacion != "")
                            {
                                if ((Convert.ToDateTime(eReprogramaciones.FechaRevision).Year < DateTime.Now.Year))
                                {
                                    eReprogramaciones.FechaRevision = Convert.ToString(Convert.ToDateTime(eReprogramaciones.FechaRevision).AddYears(1));
                                }

                                CalificacionMinima = Convert.ToDecimal(
                                                        Negocio.Convenio.Reprogramacion.PorcentajeMinimoReprogramar(
                                                                Convert.ToInt32(eReprogramaciones.MarcaID),
                                                                Convert.ToDateTime(eReprogramaciones.FechaRevision))
                                                      );

                                if (CalificacionRentabilidad >= CalificacionMinima)
                                {

                                    if (ind == true)
                                    {
                                        Reprog i = new Reprog();

                                        //i.eReprogramaciones = eReprogramaciones;

                                        i.TopLevel = true;
                                        i.WindowState = FormWindowState.Normal;

                                        i.ShowDialog(this);

                                        i.Activate();
                                    }
                                    else
                                    {
                                        MessageBox.Show("Se debe seleccionar Marca y Comprador ...");
                                    }
                                }
                                else
                                {
                                    MessageBox.Show(string.Format("La calificación mínima para reprogramar es: {0} y su calificación es: {1}", CalificacionMinima, CalificacionRentabilidad), "REGLA REPROGRAMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                }

                            }
                            else
                            {
                                MessageBox.Show(string.Format("No se puede reprogramar cuando la calificación es: {0} ", eReprogramaciones.strCalificacion), "REGLA REPROGRAMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                            }
                        }
                        else
                        {

                            if (ind == true)
                            {
                                Reprog i = new Reprog();

                                //i.eReprogramaciones = eReprogramaciones;

                                i.TopLevel = true;
                                i.WindowState = FormWindowState.Normal;

                                i.ShowDialog(this);

                                i.Activate();
                            }
                            else
                            {
                                MessageBox.Show("Se debe seleccionar Marca y Comprador ...");
                            }

                        }

                    }


                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { }


        }
	  	  
        #region "Proceso de Notas de credito  "
        private void notaDeCréditoTSMI_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Nota").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La Ventana ya esta abierta...");
                    }
                    else
                    {
                        string FechaBon = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
                        if (FechaBon != null)
                        {
                            string calificaion = MmsWin.Front.Utilerias.VarTem.tmpCalConv;
                            string convMarcaNo = MmsWin.Front.Utilerias.VarTem.ConvMarcaNo;

                            string FechaBinificacion = FechaBon.Substring(8, 2) + FechaBon.Substring(3, 2) + FechaBon.Substring(0, 2);
                            string FechaAbierta = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenMarcaConfiguracion1(convMarcaNo);
                            if (FechaBinificacion == FechaAbierta)
                            {
                                if (eReprogramaciones.strCalificacion.Trim() == "Postergar")
                                {
                                    MessageBox.Show("No se pueden generar la nota de crédito cuando se tiene el estatus de 'Postergar'.", "Nota de Crédito", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                    return;
                                }
                                MessageBox.Show("La nota de crédito se va a concentrar en la fecha :" + FechaBon);
                                Nota i = new Nota();

                                i.Show();
                            }
                            else
                            {
                                MessageBox.Show("La fecha " + FechaBon + " No esta abierta para captura de Notas de Credito");
                            }
                        }
                        else
                        {
                            MessageBox.Show("La ventana de Calificacion no esta abierta...");
                        }
                    }
                }
            }
            catch { }
            finally { }
        }

        private void notasDeCredito_Click(object sender, EventArgs e)
        {
            Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "AutorizaNotaCredito").SingleOrDefault<Form>();
            {
                if (existe != null)
                {
                    MessageBox.Show("La ventana Autoriza Nota Crédito ya esta abierta...");
                }
                else
                {
                    AutorizaNotaCredito i = new AutorizaNotaCredito();
                    i.Marca = (Comun.Engine.Marca)Convert.ToInt32(this.cbMarca.SelectedValue);
                    i.Comprador = Convert.ToInt32(this.cbCompradores.SelectedValue);
                    i.ShowDialog(this);
                }
            }
        }
        #endregion

        private void devolucionTSMI_Click(object sender, EventArgs e)
        {
            string Calificacion = MmsWin.Front.Utilerias.VarTem.tmpCalConv;
            if (Calificacion == "Devolucion" || Calificacion == "50%" || Calificacion == "50%" || Calificacion == "40%" || Calificacion == "Dev ó 40%")
            {
                string message = "Esta seguro de devolver este estilo?";
                string caption = "Confirmación";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;
                result = MessageBox.Show(message, caption, buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    GuardarNotaDevolucion();
                }
                else
                {
                    MessageBox.Show("Proceso cancelado por el usuario");
                }
            }
            else
            {
                MessageBox.Show("No aplica para esta calificacion");
            }
        }

        private void GuardarNotaDevolucion()
        {
            string TpoMov = "DEV";
            string TpoCal = "NOR";
            string FechaBon = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
            if (FechaBon != null)
            {
                MessageBox.Show("La devolucion se va a concentrar en la fecha :" + FechaBon);

                string FchDvl = DateTime.Now.ToString("dd/MM/yyyy");
                FchDvl = FchDvl.Substring(8, 2) + FchDvl.Substring(3, 2) + FchDvl.Substring(0, 2);
                string HorDvl = DateTime.Now.ToString("HH:mm:ss");
                HorDvl = HorDvl.Substring(0, 2) + HorDvl.Substring(3, 2) + HorDvl.Substring(6, 2);
                string FchHorDvl = FchDvl + HorDvl;

                // Recalculo . . . . .
                System.Data.DataTable dtGuardaNota = null;

                string ParFchBon = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
                ParFchBon = ParFchBon.Substring(8, 2) + ParFchBon.Substring(3, 2) + ParFchBon.Substring(0, 2);
                string ParFchRev = this.dgvConvenio.CurrentRow.Cells["DSPFRV"].Value.ToString();
                string ParProveedor = this.dgvConvenio.CurrentRow.Cells["DSPPRV"].Value.ToString();
                string PartbEstilo = this.dgvConvenio.CurrentRow.Cells["DSPSTY"].Value.ToString();
                string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                string ParNotCal = FchHorDvl;
                string ParSubtot = "0";
                string ParPorc = "0";
                string varInd1 = "0";
                string varInd2 = "0";

                ParSubtot = ParSubtot.Replace(".", "");
                ParSubtot = ParSubtot.Replace(",", "");
                ParPorc = ParPorc.Replace(".", "");
                String RutaPdf = MmsWin.Front.Utilerias.VarTem.tmpRutaPdf;
                dtGuardaNota = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().GuardaNota(ParFchBon, ParFchRev, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, ParPorc, varInd1, varInd2, TpoMov, TpoCal, RutaPdf);

                if (dtGuardaNota.Rows.Count > 0)
                {
                    foreach (DataRow row in dtGuardaNota.Rows)
                    {
                        varInd1 = row["NOTIN1"].ToString();
                        varInd2 = row["NOTIN2"].ToString();

                        if (varInd1 == "1" && varInd2 == "0")
                        {
                            MessageBox.Show("Se generó el registro exitosamente");
                            //     this.Close();

                        }
                        else
                        {
                            if (varInd2 == "1")
                            {
                                string message = "Ya existe La Nota de Crédito, Haz Click en (Si) para remplazar ";
                                string caption = "Aviso";
                                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                                DialogResult result;
                                result = MessageBox.Show(message, caption, buttons);
                                if (result == System.Windows.Forms.DialogResult.Yes)
                                {
                                    varInd1 = "2";
                                    varInd2 = "2";
                                    RutaPdf = MmsWin.Front.Utilerias.VarTem.tmpRutaPdf;
                                    MmsWin.Negocio.Utilerias.Utilerias.GetInstance().GuardaNota(ParFchBon, ParFchRev, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, ParPorc, varInd1, varInd2, TpoMov, TpoCal, RutaPdf);
                                    MessageBox.Show("Se actualizo la Nota de Crédito exitosamente");
                                    //     this.Close();
                                }
                            }
                        }
                    }
                }
            } // Valida si esta abierta la calificacion
            else
            {
                MessageBox.Show("La ventana de Calificacion no esta abierta...");
            }
        }

        private void cbOrigen_SelectedValueChanged(object sender, EventArgs e)
        {
            origen = " ";
            ComboBox cmbOrigen = (ComboBox)sender;
            origen = cmbOrigen.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpOrigen = cbOrigen.SelectedValue.ToString();

            BindData();
        }

        private void cbTemporada_Click(object sender, EventArgs e)
        {
            //clbTemporada.Visible = true;
            //clbTemporada.Focus();
        }

        private void clbTemporada_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                //clbTemporada.Visible = false;
                dgvConvenio.Focus();
                dgvConvenio.Select();
            }
            if (e.KeyCode == Keys.F5)
            {
                BindData();
                dgvConvenio.Focus();
                dgvConvenio.Select();
            }
        }

        private void tbTemporada_Click(object sender, EventArgs e)
        {
            //clbTemporada.Visible = true;
            //clbTemporada.Focus();
        }

        private void cbReprogramacion_SelectedValueChanged(object sender, EventArgs e)
        {
            reprogramacion = " ";
            ComboBox cmbReprogramacion = (ComboBox)sender;
            reprogramacion = cmbReprogramacion.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpReprogramacion = cbReprogramacion.SelectedValue.ToString();

            BindData();
        }

        private void tbDesde_Click(object sender, EventArgs e)
        {
            mcC1.Visible = true;
            mcC1.Focus();
        }

        private void tbHasta_Click(object sender, EventArgs e)
        {
            mcC2.Visible = true;
            mcC2.Focus();
        }

        private void mcC1_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbDesde.Text = mcC1.SelectionEnd.ToShortDateString();
            FechaCal = tbDesde.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchDeN = long.Parse(FechaFmt.ToString());
            FchDe = FechaFmt.ToString();

            mcC1.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbDesde.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    tipoDeConsulta();
                    BindData(); ;
                }
            }
        }

        private void tipoDeConsulta()
        {
            string FechaInicial = MmsWin.Front.Utilerias.VarTem.tmpFchInicial;
            Boolean simulador = MmsWin.Front.Utilerias.VarTem.simulador;

            if (FchDe == FechaInicial && simulador == false && FchDe == FchHas)
            {
                MmsWin.Front.Utilerias.VarTem.tmpUsrConv = "CALIFICA";
            }
            else
            {
                MmsWin.Front.Utilerias.VarTem.tmpUsrConv = MmsWin.Front.Utilerias.VarTem.tmpUser;
            }
        }

        private void mcC2_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbHasta.Text = mcC2.SelectionEnd.ToShortDateString();
            FechaCal = tbHasta.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchHasN = long.Parse(FechaFmt.ToString());
            FchHas = FechaFmt.ToString();

            mcC2.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbHasta.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    tipoDeConsulta();
                    BindData();
                }
            }
        }

        private void mcC1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcC1.Visible = false;
            }
        }

        private void mcC1_Leave(object sender, EventArgs e)
        {
            mcC1.Visible = false;
        }

        private void mcC2_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcC2.Visible = false;
            }
        }

        private void mcC2_Leave(object sender, EventArgs e)
        {
            mcC2.Visible = false;
        }

        private void tbProveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbDesde.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindData();
                tbProveedor.Focus();
            }
        }

        private void tbNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbDesde.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindData();
                tbNombre.Focus();
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbDesde.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindData();
                tbEstilo.Focus();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbDesde.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindData();
                tbDescripcion.Focus();
            }
        }

        private void EliminacheckBox()
        {
            try
            {
                dgvConvenio.Columns.Remove("COMPRAS");
                dgvConvenio.Columns.Remove("CONTRALORIA");
                dgvConvenio.Columns.Remove("OMITIR");
            }
            catch { }
        }

        private void EliminacheckBoxTemp()
        {
            try
            {
                gvTemporada.Columns.Remove("COMPRAS");
                gvTemporada.Columns.Remove("CONTRALORIA");
                //gvTemporada.Columns.Remove("OMITIR");
            }
            catch { }
        }

        private void CreaCheckBox()
        {
            DataGridViewCheckBoxColumn Compras = new DataGridViewCheckBoxColumn();

            dgvConvenio.Columns.Add(Compras);
            dgvConvenio.Columns[68].Name = "COMPRAS";
            dgvConvenio.Columns[68].HeaderText = "Revisado Comprador";
            dgvConvenio.Columns[68].Width = 70;
            dgvConvenio.Columns[68].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
            dgvConvenio.Columns[68].HeaderCell.Style.ForeColor = Color.White;


            DataGridViewCheckBoxColumn Contraloria = new DataGridViewCheckBoxColumn();

            dgvConvenio.Columns.Add(Contraloria);
            dgvConvenio.Columns[69].Name = "CONTRALORIA";
            dgvConvenio.Columns[69].HeaderText = "Revisado C x P";
            dgvConvenio.Columns[69].Width = 68;
            dgvConvenio.Columns[69].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
            dgvConvenio.Columns[69].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn Omitir = new DataGridViewCheckBoxColumn();

            dgvConvenio.Columns.Add(Omitir);
            dgvConvenio.Columns[70].Name = "OMITIR";
            dgvConvenio.Columns[70].HeaderText = "Omitir";
            dgvConvenio.Columns[70].Width = 68;
            dgvConvenio.Columns[70].HeaderCell.Style.BackColor = Color.FromArgb(255, 0, 0);
            dgvConvenio.Columns[70].HeaderCell.Style.ForeColor = Color.White;
        }

        private void CreaCheckBoxTemporada()
        {
            DataGridViewCheckBoxColumn Compras = new DataGridViewCheckBoxColumn();

            gvTemporada.Columns.Add(Compras);
            gvTemporada.Columns[54].Name = "COMPRAS";
            gvTemporada.Columns[54].HeaderText = "Revisado Comprador";
            gvTemporada.Columns[54].Width = 70;
            gvTemporada.Columns[54].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
            gvTemporada.Columns[54].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn Contraloria = new DataGridViewCheckBoxColumn();
            gvTemporada.Columns.Add(Contraloria);
            gvTemporada.Columns[55].Name = "CONTRALORIA";
            gvTemporada.Columns[55].HeaderText = "Revisado C x P";
            gvTemporada.Columns[55].Width = 68;
            gvTemporada.Columns[55].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
            gvTemporada.Columns[55].HeaderCell.Style.ForeColor = Color.White;
        }

        private void btCheckBox_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            System.Data.DataTable dtCheckBox = new System.Data.DataTable("Bonificaciones");
            dtCheckBox.Columns.Add("FechaRev", typeof(String));
            dtCheckBox.Columns.Add("Proveedor", typeof(String));
            dtCheckBox.Columns.Add("Estilo", typeof(String));

            dtCheckBox.Columns.Add("DSPOBS", typeof(String));
            dtCheckBox.Columns.Add("Compras", typeof(String));
            dtCheckBox.Columns.Add("Com1", typeof(String));

            int RegChkBox = 0;

            foreach (DataGridViewRow item in dgvConvenio.Rows)
            {
                {
                    if (item.Cells["COMPRAS"].Value != null) //&& (Convert.ToString(item.Cells["BONCK1"].Value) == "0"))
                    {
                        DataRow workRow = dtCheckBox.NewRow();
                        workRow["FechaRev"] = item.Cells["DSPFRV"].Value.ToString();
                        workRow["Proveedor"] = item.Cells["DSPPRV"].Value.ToString();
                        workRow["Estilo"] = item.Cells["DSPSTY"].Value.ToString();
                        workRow["DSPOBS"] = item.Cells["DSPOBS"].Value.ToString();

                        try
                        {
                            workRow["Com1"] = "0";
                            try
                            {
                                if ((Boolean)item.Cells["COMPRAS"].Value == true)
                                { workRow["Compras"] = "1"; workRow["Com1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                else
                                { workRow["Compras"] = "0"; workRow["Com1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                            }
                            catch { }
                        }
                        catch { }
                    }
                }
            }

            if (RegChkBox > 0)
            {
                DateTime hoy = DateTime.Now;

                string fecha = hoy.Date.ToString("yyMMdd");
                string hora = DateTime.Now.ToString("HHmmss");
                ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;

                MmsWin.Negocio.Convenio.Convenio.GetInstance().UpdateCheckBox(dtCheckBox, ParUser, fecha, hora);
                BindData();

                dgvConvenio.Focus();
                dgvConvenio.Select();
                SendKeys.Send("{END}");
                SendKeys.Flush();
                MessageBox.Show("Actualizacion completa...");
            }
            this.Cursor = Cursors.Default;
        }

        private void btCheckBox2_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            System.Data.DataTable dtCheckBox = new System.Data.DataTable("Bonificaciones");
            dtCheckBox.Columns.Add("FechaRev",  typeof(String));
            dtCheckBox.Columns.Add("Proveedor", typeof(String));
            dtCheckBox.Columns.Add("Estilo",    typeof(String));

            dtCheckBox.Columns.Add("Contraloria", typeof(String));
            dtCheckBox.Columns.Add("Cont1",       typeof(String));
            dtCheckBox.Columns.Add("DSPOBC",      typeof(String));
            dtCheckBox.Columns.Add("Omitir",      typeof(String));
            dtCheckBox.Columns.Add("Cont2",       typeof(String));

            int RegChkBox = 0;
            if (dgvConvenio.Visible)
            {
                foreach (DataGridViewRow item in dgvConvenio.Rows)
                {
                    {
                        if ((item.Cells["CONTRALORIA"].Value != null) || (item.Cells["OMITIR"].Value != null))
                        {
                            DataRow workRow = dtCheckBox.NewRow();
                            workRow["FechaRev"] = item.Cells["DSPFRV"].Value.ToString();
                            workRow["Proveedor"] = item.Cells["DSPPRV"].Value.ToString();
                            workRow["Estilo"] = item.Cells["DSPSTY"].Value.ToString();
                            workRow["DSPOBC"] = item.Cells["DSPOBC"].Value.ToString();

                            try
                            {
                                workRow["Cont1"] = "0";
                                workRow["Cont2"] = "0";
                                try
                                {
                                    if ((Boolean)item.Cells["CONTRALORIA"].Value == true)
                                    { workRow["Contraloria"] = "1"; workRow["Cont1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                    else
                                    { workRow["Contraloria"] = "0"; workRow["Cont1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                }
                                catch { }
                                try
                                {
                                    if ((Boolean)item.Cells["OMITIR"].Value == true)
                                    { workRow["Omitir"] = "1"; workRow["Cont2"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                    else
                                    { workRow["Omitir"] = "0"; workRow["Cont2"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                }
                                catch { }
                            }
                            catch { }
                        }
                    }
                }
            }
            else if (gvTemporada.Visible)
            {
                foreach (DataGridViewRow item in gvTemporada.Rows)
                {

                    if ((item.Cells[53].Value != null))
                    {
                        DataRow workRow      = dtCheckBox.NewRow();
                        workRow["FechaRev"]  = item.Cells["DSPFRV"].Value.ToString();
                        workRow["Proveedor"] = item.Cells["DSPPRV"].Value.ToString();
                        workRow["Estilo"]    = item.Cells["DSPSTY"].Value.ToString();
                        workRow["DSPOBC"]    = item.Cells["DSPRPG"].Value.ToString();

                        try
                        {
                            workRow["Cont1"] = "0";
                            try
                            {
                                if ((Boolean)item.Cells["DSPFPX"].Value == true)
                                { workRow["Contraloria"] = "1"; workRow["Cont1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                else
                                { workRow["Contraloria"] = "0"; workRow["Cont1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                            }
                            catch { }
                        }
                        catch { }
                    }

                }
            }

            if (RegChkBox > 0)
            {
                DateTime hoy = DateTime.Now;

                string fecha = hoy.Date.ToString("yyMMdd");
                string hora = DateTime.Now.ToString("HHmmss");
                ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;

                MmsWin.Negocio.Convenio.Convenio.GetInstance().UpdateCheckBox2(dtCheckBox, ParUser, fecha, hora);
                BindData();
                dgvConvenio.Focus();
                SendKeys.Send("{END}");
                SendKeys.Flush();
                MessageBox.Show("Actualizacion completa...");
            }
            this.Cursor = Cursors.Default;
        }

        private void consultaNCPDFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //   MuestraPDF();
            try
            {
                string ParFchCal = MmsWin.Front.Utilerias.VarTem.tmpFchRev;
                string ParPrv = MmsWin.Front.Utilerias.VarTem.tmpPrv;
                string ParSty = MmsWin.Front.Utilerias.VarTem.tmpSty;
                string ParNota = MmsWin.Front.Utilerias.VarTem.tmpNota;

                System.Data.DataTable dtRutaPDF = null;
                dtRutaPDF = MmsWin.Negocio.Convenio.Convenio.GetInstance().ObtenRutaPDF(ParFchCal, ParPrv, ParSty, ParNota);
                foreach (DataRow row in dtRutaPDF.Rows)
                {
                    string ruta = row["NOTRUT"].ToString();

                    string notaPDF = ruta;
                    Process.Start(notaPDF);
                }
            }
            catch { MessageBox.Show("No hay PDF Cargado"); }
        }

        private void dgvConvenio_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selecionGrid = 1;
            MmsWin.Front.Utilerias.Fotos.numMarca = this.dgvConvenio.CurrentRow.Cells["DSPNMR"].Value.ToString();
            MmsWin.Front.Utilerias.Fotos.numPrv = this.dgvConvenio.CurrentRow.Cells["DSPPRV"].Value.ToString();
            MmsWin.Front.Utilerias.Fotos.numSty = this.dgvConvenio.CurrentRow.Cells["DSPSTY"].Value.ToString();

            MmsWin.Front.Utilerias.VarTem.tmpPrv = this.dgvConvenio.CurrentRow.Cells["DSPPRV"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpNom = this.dgvConvenio.CurrentRow.Cells["DSPNOM"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpSty = this.dgvConvenio.CurrentRow.Cells["DSPSTY"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpDes = this.dgvConvenio.CurrentRow.Cells["DSPDES"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpOrden = this.dgvConvenio.CurrentRow.Cells["DSPORD"].Value.ToString();

            MmsWin.Front.Utilerias.VarTem.tmpCalificacionAnt = this.dgvConvenio.CurrentRow.Cells["DSPCAL"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpCalificacionFin = this.dgvConvenio.CurrentRow.Cells["DSPCLF"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpOnHand = this.dgvConvenio.CurrentRow.Cells["DSPONH"].Value.ToString();

            MmsWin.Front.Utilerias.VarTem.tmpCtoActu = this.dgvConvenio.CurrentRow.Cells["DSPCSTA"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpCtoTotal = this.dgvConvenio.CurrentRow.Cells["DSPCST"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpCtoBoni = this.dgvConvenio.CurrentRow.Cells["DSPCSB"].Value.ToString();

            MmsWin.Front.Utilerias.VarTem.tmpMarcaGrid = this.dgvConvenio.CurrentRow.Cells["DSPNMR"].Value.ToString();

            string validaContraloria = this.dgvConvenio.CurrentRow.Cells["BONCK2"].Value.ToString();
            if (validaContraloria == "1")
            {
                this.dgvConvenio.CurrentRow.Cells["COMPRAS"].ReadOnly = true;
                this.dgvConvenio.CurrentRow.Cells["DSPOBS"].ReadOnly = true;
            }
            else
            {
                this.dgvConvenio.CurrentRow.Cells["COMPRAS"].ReadOnly = false;
                this.dgvConvenio.CurrentRow.Cells["DSPOBS"].ReadOnly = false;
            }


            #region " Asignación de datos para la Bonificación parcial "

            bonificacionParcial.POVNUM = Convert.ToInt32(this.dgvConvenio.CurrentRow.Cells["DSPPRV"].Value.ToString());
            bonificacionParcial.SSTYLQ = this.dgvConvenio.CurrentRow.Cells["DSPSTY"].Value.ToString();
            bonificacionParcial.PONUMB = Convert.ToInt32(this.dgvConvenio.CurrentRow.Cells["DSPORD"].Value.ToString());
            bonificacionParcial.NUMARC = Convert.ToInt32(this.dgvConvenio.CurrentRow.Cells["DSPNMR"].Value.ToString());
            bonificacionParcial.BYRNUM = comprador;
            bonificacionParcial.FECREC = Convert.ToInt32(this.dgvConvenio.CurrentRow.Cells["DSPFRB"].Value.ToString());
            bonificacionParcial.PIEREC = Convert.ToInt32(this.dgvConvenio.CurrentRow.Cells["DSPPRB"].Value.ToString());
            bonificacionParcial.FECREV = Convert.ToInt32(this.dgvConvenio.CurrentRow.Cells["DSPFRV"].Value.ToString());
            bonificacionParcial.CALIFI = this.dgvConvenio.CurrentRow.Cells["DSPCLF"].Value.ToString();
            bonificacionParcial.CALORI = this.dgvConvenio.CurrentRow.Cells["DSPCAL"].Value.ToString();
            bonificacionParcial.ONHAND = Convert.ToInt32(this.dgvConvenio.CurrentRow.Cells["DSPONH"].Value.ToString());
            bonificacionParcial.ONORDR = Convert.ToInt32(this.dgvConvenio.CurrentRow.Cells["DSPONO"].Value.ToString());
            bonificacionParcial.CSTTOT = Convert.ToDecimal(this.dgvConvenio.CurrentRow.Cells["DSPCST"].Value.ToString());
            bonificacionParcial.BODEGA = Convert.ToInt32(this.dgvConvenio.CurrentRow.Cells["DSPBDG"].Value.ToString());
            bonificacionParcial.CSTACT = Convert.ToDecimal(this.dgvConvenio.CurrentRow.Cells["DSPCSTA"].Value.ToString());
            bonificacionParcial.PREACT = Convert.ToDecimal(this.dgvConvenio.CurrentRow.Cells["DSPPREA"].Value.ToString());
            bonificacionParcial.CODTEM = this.dgvConvenio.CurrentRow.Cells["DSPASN"].Value.ToString();
            bonificacionParcial.AUSTAT = "P";
            bonificacionParcial.SUSREG = MmsWin.Front.Utilerias.VarTem.tmpUser;

            #endregion
        }

        private void gvTemporada_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selecionGrid = 1;
            MmsWin.Front.Utilerias.Fotos.numMarca = this.gvTemporada.CurrentRow.Cells["DSPNMR"].Value.ToString();
            MmsWin.Front.Utilerias.Fotos.numPrv = this.gvTemporada.CurrentRow.Cells["DSPPRV"].Value.ToString();
            MmsWin.Front.Utilerias.Fotos.numSty = this.gvTemporada.CurrentRow.Cells["DSPSTY"].Value.ToString();

            MmsWin.Front.Utilerias.VarTem.tmpPrv = this.gvTemporada.CurrentRow.Cells["DSPPRV"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpNom = this.gvTemporada.CurrentRow.Cells["DSPNOM"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpSty = this.gvTemporada.CurrentRow.Cells["DSPSTY"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpDes = this.gvTemporada.CurrentRow.Cells["DSPDES"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpOrden = this.gvTemporada.CurrentRow.Cells["DSPORD"].Value.ToString();

            MmsWin.Front.Utilerias.VarTem.tmpFchRev = this.gvTemporada.CurrentRow.Cells["FECHA_RECIBO"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpCalificacionAnt = this.gvTemporada.CurrentRow.Cells["CALIFICACION"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpCalificacionFin = "";// this.gvTemporada.CurrentRow.Cells["DSPCLF"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpOnHand = this.gvTemporada.CurrentRow.Cells["ONHAND_PLUS"].Value.ToString();

            MmsWin.Front.Utilerias.VarTem.tmpCtoActu = this.gvTemporada.CurrentRow.Cells["COSTO_ACT"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpCtoTotal = Convert.ToString(Convert.ToInt32(this.gvTemporada.CurrentRow.Cells["ONHAND_PLUS"].Value.ToString()) * Convert.ToInt32(this.gvTemporada.CurrentRow.Cells["COSTO_ACT"].Value.ToString()));
            MmsWin.Front.Utilerias.VarTem.tmpCtoBoni = this.gvTemporada.CurrentRow.Cells["BONIFICACION"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpOrden = "0";
            MmsWin.Front.Utilerias.VarTem.tmpMarcaGrid = this.gvTemporada.CurrentRow.Cells["MARCA"].Value.ToString();

        }

        private void dgvConvenio_CellDoubleClick_1(object sender, DataGridViewCellEventArgs e)
        {
            dgvConvenio.Select();
            dgvConvenio.Focus();
            Kardex();
        }

        private void dgvConvenio_CellParsing(object sender, DataGridViewCellParsingEventArgs e)
        {
            int Row = e.RowIndex;
            int Col = e.ColumnIndex;
            double pzasMenosPorc = 0;
            double porcentaje = 0;
            double CostoFinal = 0;
            this.dgvConvenio.Rows[Row].Cells[Col].Style.BackColor = Color.Orange;

            string validaContraloria = this.dgvConvenio.CurrentRow.Cells["BONCK2"].Value.ToString();

            if (validaContraloria == "1" && this.dgvConvenio.Columns[e.ColumnIndex].Name != "CONTRALORIA")
            {
                MessageBox.Show("Este Registro no se puede actualizar o modificar");
            }
            else
            {

            }

            if (this.dgvConvenio.Columns[e.ColumnIndex].Name == "DSPCLF")
            {
                try
                {
                    if (e != null)
                    {
                        if (e.Value != null)
                        {
                            porcentaje = Convert.ToDouble(e.Value);

                            pzasMenosPorc = porcentaje * (Convert.ToDouble(dgvConvenio.Rows[Row].Cells["DSPONH"].Value));
                            CostoFinal = pzasMenosPorc * (Convert.ToDouble(dgvConvenio.Rows[Row].Cells["DSPCSTA"].Value));
                            dgvConvenio.Rows[Row].Cells["DSPCBF"].Value = Convert.ToString(CostoFinal);
                            this.dgvConvenio.Rows[Row].Cells["DSPCBF"].Style.BackColor = Color.Orange;
                        }
                    }
                }
                catch
                { }
            }

        }

        private void cbCompradores_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void actualizarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ActualizarConvenio();
        }

        private void ActualizarConvenio()
        {
            System.Data.DataTable dtConvenio = new System.Data.DataTable("Convenio");
            dtConvenio.Columns.Add("FechaRev", typeof(String));
            dtConvenio.Columns.Add("Proveedor", typeof(String));
            dtConvenio.Columns.Add("Estilo", typeof(String));

            dtConvenio.Columns.Add("CalificaFinal", typeof(String));
            dtConvenio.Columns.Add("CostoFinal", typeof(String));

            DataGridViewSelectedRowCollection Seleccionados = dgvConvenio.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                DataRow workRow = dtConvenio.NewRow();
                workRow["FechaRev"] = item.Cells["DSPFRV"].Value.ToString();
                workRow["Proveedor"] = item.Cells["DSPPRV"].Value.ToString();
                workRow["Estilo"] = item.Cells["DSPSTY"].Value.ToString();

                workRow["CalificaFinal"] = item.Cells["DSPCLF"].Value.ToString();
                workRow["CostoFinal"] = item.Cells["DSPCBF"].Value.ToString();

                dtConvenio.Rows.Add(workRow);
            }
            MmsWin.Negocio.Convenio.Convenio.GetInstance().UpdateConvenio(dtConvenio);
            BindData();
            MessageBox.Show("Actualizacion completa...");
            BindData();
        }

        private void dgvConvenio_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            try
            { }
            catch { }
        }

        private void cbExcepciones_SelectedValueChanged(object sender, EventArgs e)
        {
            excepciones = " ";
            ComboBox cmbExcepcion = (ComboBox)sender;
            excepciones = cmbExcepcion.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpExcepcion = cbReprogramacion.SelectedValue.ToString();

            BindData();
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            if (ddlTemporada.SelectedValue.ToString().ToUpper() == "INV")
            {
                dgvConvenio.Visible = false;
                gvTemporada.Visible = true;

                BindDataTemp();
            }
            else
            {
                dgvConvenio.Visible = true;
                gvTemporada.Visible = false;
            }
        }

        private void gvTemporada_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                var hti = gvTemporada.HitTest(e.X, e.Y);
                int Row = e.RowIndex;
                int Col = e.ColumnIndex;

                MmsWin.Front.Utilerias.Fotos.numMarca = this.gvTemporada.CurrentRow.Cells["DSPNMR"].Value.ToString();
                MmsWin.Front.Utilerias.Fotos.numPrv   = this.gvTemporada.CurrentRow.Cells["DSPPRV"].Value.ToString();
                MmsWin.Front.Utilerias.Fotos.numSty   = this.gvTemporada.CurrentRow.Cells["DSPSTY"].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.tmpPrv   = this.gvTemporada.CurrentRow.Cells["DSPPRV"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpNom   = this.gvTemporada.CurrentRow.Cells["DSPNOM"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpSty   = this.gvTemporada.CurrentRow.Cells["DSPSTY"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpDes   = this.gvTemporada.CurrentRow.Cells["DSPDES"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpOrden = this.gvTemporada.CurrentRow.Cells["DSPORD"].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.tmpFchRev  = this.gvTemporada.CurrentRow.Cells["DSPFRV"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpCalConv = this.gvTemporada.CurrentRow.Cells["DSPCAL"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpRentab  = this.gvTemporada.CurrentRow.Cells["DSPRTB"].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.NotaProveedor   = this.gvTemporada.CurrentRow.Cells["DSPPRV"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.NotaNombre      = this.gvTemporada.CurrentRow.Cells["DSPNOM"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.NotaEstilo      = this.gvTemporada.CurrentRow.Cells["DSPSTY"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.NotaDescripcion = this.gvTemporada.CurrentRow.Cells["DSPDES"].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.tmpFchRev          = this.gvTemporada.CurrentRow.Cells["FECHA_RECIBO"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpCalificacionAnt = this.gvTemporada.CurrentRow.Cells["CALIFICACION"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpCalificacionFin = "";// this.gvTemporada.CurrentRow.Cells["DSPCLF"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpOnHand          = this.gvTemporada.CurrentRow.Cells["ONHAND_PLUS"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpOrden    = "0";
                MmsWin.Front.Utilerias.VarTem.tmpCtoActu  = this.gvTemporada.CurrentRow.Cells["COSTO_ACT"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpCtoTotal = Convert.ToString(Convert.ToInt32(this.gvTemporada.CurrentRow.Cells["ONHAND_PLUS"].Value.ToString()) * Convert.ToInt32(this.gvTemporada.CurrentRow.Cells["COSTO_ACT"].Value.ToString()));
                MmsWin.Front.Utilerias.VarTem.tmpCtoBoni  = this.gvTemporada.CurrentRow.Cells["BONIFICACION"].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.tmpMarcaGrid = this.gvTemporada.CurrentRow.Cells["MARCA"].Value.ToString();

                cmMenu.Visible = true;
            }
        }

		private void btnPreautorizadas_Click(object sender, EventArgs e)
        {


            //if (cbMarca.SelectedValue.ToString() == "999")
            //{
            //     MessageBox.Show("Seleccione una marca y comprador","Convenio");
            //     return;
            //}

            //if (this.cbCompradores.SelectedValue.ToString() == "999")
            //{
            //    MessageBox.Show("Seleccione un comprador","Convenio");
            //     return;
            //}


            Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "Preautorizaciones").SingleOrDefault<Form>();
            {
                if (existe != null)
                {
                    MessageBox.Show("La ventana Reprogramacion ya esta abierta...");
                }
                else
                {
                    Preautorizaciones i = new Preautorizaciones();
                    i.Marca = (Comun.Engine.Marca)Convert.ToInt32(this.cbMarca.SelectedValue);
                    i.Comprador = Convert.ToInt32(this.cbCompradores.SelectedValue);
                    i.ShowDialog(this);
                }
            }
        }
		
        #region "  Proceso de cambio de Calificacion   "
        private void btnCamCalificacion_Click(object sender, EventArgs e)
        {
            Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "AutorizaCalificacion").SingleOrDefault<Form>();
            {
                if (existe != null)
                {
                    MessageBox.Show("La ventana Autoriza Calificación ya esta abierta...");
                }
                else
                {
                    AutorizaCalificacion i = new AutorizaCalificacion();
                    i.FormClosed += new System.Windows.Forms.FormClosedEventHandler(form2_FormClosed);
                    i.Marca = (Comun.Engine.Marca)Convert.ToInt32(this.cbMarca.SelectedValue);
                    i.Comprador = Convert.ToInt32(this.cbCompradores.SelectedValue);
                    i.ShowDialog(this);
                }
            }
        }

        private void form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            selecionGrid = 0;
            BindData();
            if (dgvConvenio.Rows.Count > 0)
                SetFontAndColors();

            dgvConvenio.ClearSelection();
        }

         private void camCalificacionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ValidaReprog();

                if (ind == false)
                {
                        MessageBox.Show("Debe de seleccionar a un comprador.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (selecionGrid == 0)
                {
                    MessageBox.Show("Selecciona un registro.", "Cambio de Calificación", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                //Validar que la marca sea "Melody"
                if (eReprogramaciones.MarcaID == "10")
                {
                    MessageBox.Show("Los Cambios de Calificación en esta pantalla, solo aplican para 'Milano y Home & Fashion'." +
                        "\n\nLos Cambios de Calificación para Melody se deben realizar desde el icono de " +
                        "\nMELODY.", "REGLA REPROGRAMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (eReprogramaciones.strCalificacion.Trim().Replace(" ", "").ToUpper() == "POSTERGAR")
                {
                    MessageBox.Show("No se pueden generar el cambio de calificación cuando se tiene el estatus de 'Postergar'.", "Cambio de Calificación", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                string tempo = ddlTemporada.SelectedValue.ToString();

                selecionGrid = 0;
                int valorCali = 0;

                if (tempo != "999")
                    valorCali = 1;

                string IndProveedor = MmsWin.Front.Utilerias.Fotos.numPrv;
                string IndStylo = MmsWin.Front.Utilerias.Fotos.numSty;
                string IndOrdenCompra = MmsWin.Front.Utilerias.VarTem.tmpOrden;
                string IndMarca = MmsWin.Front.Utilerias.VarTem.tmpMarcaGrid;

                string calificacionFinal = MmsWin.Front.Utilerias.VarTem.tmpCalificacionFin;
                string calificacionPrevia = MmsWin.Front.Utilerias.VarTem.tmpCalificacionAnt;

                bool esnumPrevia = Char.IsNumber(calificacionPrevia.Substring(valorCali).Trim()[valorCali]);

                MmsWin.Front.Utilerias.VarTem.tmpTemporada = tempo;

                int noEventos = MmsWin.Negocio.Convenio.Convenio.GetInstance().cantidadNoCalificacion(IndStylo, IndProveedor, IndOrdenCompra, IndMarca, tempo);
                MmsWin.Front.Utilerias.VarTem.tmpNoEventos = noEventos.ToString();

                if (esnumPrevia == true)
                {
                    if (calificacionPrevia.ToUpper().Trim().Replace(" ", "").Contains("DEVOLUCI"))
                    {
                        MessageBox.Show("Los estilos con devolución no se pueden modificar.", "Cambio de Calificación", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                    else
                    {
                        if (Convert.ToInt32(calificacionPrevia.Trim().Split('%')[valorCali]) > 0)
                        {
                            if (noEventos == 0)
                            {
                                SolCamCalificacion i = new SolCamCalificacion();
                                i.eReprogramaciones = eReprogramaciones;
                                i.TopLevel = true;
                                i.WindowState = FormWindowState.Normal;

                                i.ShowDialog(this);

                                i.Activate();
                            }
                            else
                            {
                                MessageBox.Show("El estilo está en proceso o ya fue calificado, no se pueden modificar.", "Cambio de Calificación", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                return;
                            }
                        }
                        else
                        {
                            MessageBox.Show("El estilo debe ser mayor al 0% de calificación, no se pueden modificar.", "Cambio de Calificación", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return;
                        }
                    }
                }
                else
                {
                    if (calificacionPrevia.Substring(0, 3).ToUpper().Trim() == "DEV")
                    {
                        MessageBox.Show("Los estilos con devolución no se pueden modificar.", "Cambio de Calificación", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                    else if (calificacionPrevia.ToUpper().Replace(" ", "").Trim() == "PAGAR")
                    {
                        MessageBox.Show("Los estilos pagados no se pueden modificar.", "Cambio de Calificación", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region "  Proceso de ejercer devolucion en sustitucion de una bonificacion   "
		
		   private void btnCamBoni_Click(object sender, EventArgs e)
        {
            Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "AutorizaDevolucion").SingleOrDefault<Form>();
            {
                if (existe != null)
                {
                    MessageBox.Show("La ventana Autoriza la Devolución ya esta abierta...");
                }
                else
                {
                    AutorizaDevolucion i = new AutorizaDevolucion();
                    i.Marca = eReprogramaciones.MarcaID;
                    i.Comprador = Convert.ToInt32(eReprogramaciones.CompradorID);
                    i.ShowDialog(this);
                }
            }
        }
		
        private void bonificaADecoluciónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {

                ValidaReprog();

                if (ind == false)
                {
                    MessageBox.Show("Debe de seleccionar a un comprador.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (selecionGrid == 0)
                {
                    MessageBox.Show("Selecciona un registro.", "Cambio a Devolución", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                //Validar que la marca sea "Melody"
                if (eReprogramaciones.MarcaID == "10")
                {
                    MessageBox.Show("La Bonificación por Devolución en esta pantalla, solo aplican para 'Milano y Home & Fashion'." +
                        "\n\nLa Bonificación por Devolución para Melody se deben realizar desde el icono de " +
                        "\nMELODY.", "REGLA REPROGRAMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (eReprogramaciones.strCalificacion.Trim().Replace(" ", "").ToUpper() == "POSTERGAR")
                {
                    MessageBox.Show("No se pueden generar el cambio de devolución cuando se tiene el estatus de 'Postergar'.", "Cambio a Devolución", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                string calificacionPrevia = MmsWin.Front.Utilerias.VarTem.tmpCalificacionAnt;

                if (calificacionPrevia.Replace(" ", "").ToUpper().Contains("DEVOLUCI"))
                {
                    MessageBox.Show("!ANTENCIÓN¡ \n\nLa calificación debe ser bonificación, para aplicar una devolución.", "Cambio a Devolución", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                if (calificacionPrevia.ToUpper().Replace(" ", "").Trim().Contains("PAGAR"))
                {
                    MessageBox.Show("!ANTENCIÓN¡ \n\nLa calificación es pagar, no se pueden realizar cambios.", "Cambio a Devolución", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                selecionGrid = 0;

                string tempo = ddlTemporada.SelectedValue.ToString();
                string IndProveedor = MmsWin.Front.Utilerias.Fotos.numPrv;
                string IndStylo = MmsWin.Front.Utilerias.Fotos.numSty;
                string IndOrdenCompra = MmsWin.Front.Utilerias.VarTem.tmpOrden;
                string IndMarca = MmsWin.Front.Utilerias.VarTem.tmpMarcaGrid;
                string calificacionFinal = MmsWin.Front.Utilerias.VarTem.tmpCalificacionFin;

                MmsWin.Front.Utilerias.VarTem.tmpTemporada = tempo;

                int noEventos = MmsWin.Negocio.Convenio.Convenio.GetInstance().cantidadNoBoniDev(IndStylo, IndProveedor, IndOrdenCompra, IndMarca, tempo);
                MmsWin.Front.Utilerias.VarTem.tmpNoEventos = noEventos.ToString();

                if (noEventos == 0)
                {
                    devolBonificacion i = new devolBonificacion();

                    i.eReprogramaciones = eReprogramaciones;
                    i.TopLevel = true;
                    i.WindowState = FormWindowState.Normal;

                    i.ShowDialog(this);

                    i.Activate();
                }
                else
                {
                    MessageBox.Show("El estilo está en proceso o ya se autorizó la devolución, no se pueden modificar.", "Cambio a Devolución", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Proceso de devolucion "
        
		   private void devoluciónVsBonificaciónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                ValidaReprog();

                if (ind == false)
                {
                    MessageBox.Show("Debe de seleccionar a un comprador.", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (selecionGrid == 0)
                {
                    MessageBox.Show("Selecciona un registro.", "Cambio a Bonificación", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                //Validar que la marca sea "Melody"
                if (eReprogramaciones.MarcaID == "10")
                {
                    MessageBox.Show("Las Devoluciones por Bonificación en esta pantalla, solo aplican para 'Milano y Home & Fashion'." +
                        "\n\nLas Devoluciones por Bonificación para Melody se deben realizar desde el icono de " +
                        "\nMELODY.", "REGLA REPROGRAMACIÓN", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                if (eReprogramaciones.strCalificacion.Trim().Replace(" ", "").ToUpper() == "POSTERGAR")
                {
                    MessageBox.Show("No se pueden generar el cambio de bonificación cuando se tiene el estatus de 'Postergar'.", "Cambio a Bonificación", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                string calificacionPrevia = MmsWin.Front.Utilerias.VarTem.tmpCalificacionAnt;

                if (calificacionPrevia.ToUpper().Trim().Replace(" ", "").Contains("DEVOLUCI"))
                {
                    selecionGrid = 0;

                    //string tempo = ddlTemporada.SelectedValue.ToString();
                    //string IndProveedor = MmsWin.Front.Utilerias.Fotos.numPrv;
                    //string IndStylo = MmsWin.Front.Utilerias.Fotos.numSty;
                    //string IndOrdenCompra = MmsWin.Front.Utilerias.VarTem.tmpOrden;
                    //string IndMarca = MmsWin.Front.Utilerias.VarTem.tmpMarcaGrid;
                    //string calificacionFinal = MmsWin.Front.Utilerias.VarTem.tmpCalificacionFin;

                    //MmsWin.Front.Utilerias.VarTem.tmpTemporada = tempo;

                    int noEventos = MmsWin.Negocio.Convenio.Convenio.GetInstance().cantidadNoDevBoni(
                        eReprogramaciones.EstiloID,
                        eReprogramaciones.ProveedorID,
                        eReprogramaciones.OrdenCompra,
                        eReprogramaciones.MarcaID,
                        eReprogramaciones.Temporada);

                    eReprogramaciones.NoEventos = noEventos.ToString();
                    //MmsWin.Front.Utilerias.VarTem.tmpNoEventos = noEventos.ToString();

                    if (noEventos == 0)
                    {
                        boniDevolucion i = new boniDevolucion();
                        i.eReprogramaciones = eReprogramaciones;
                        i.TopLevel = true;
                        i.WindowState = FormWindowState.Normal;

                        i.ShowDialog(this);

                        i.Activate();
                    }
                    else
                    {
                        MessageBox.Show("El estilo está en proceso o ya se autorizó la bonificación, !no se pueden modificar¡.", "Cambio a Bonificación", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("!ANTENCIÓN¡\n\nLa calificación debe ser devolución, para aplicar una bonificación.", "Cambio a Bonificación", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
		
        #endregion

        #region "Evento que envia a la pantalla que contiene Plazos de ejecución de devoluciones, bonificaciones y rebajas. "
        private void btnPlazosDias_Click(object sender, EventArgs e)
        {
            Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "plazosEjecucionDBR").SingleOrDefault<Form>();
            {
                if (existe != null)
                {
                    MessageBox.Show("La ventana Plazos de ejecución de devoluciones, bonificaciones y rebajas. ya esta abierta...");
                }
                else
                {
                    plazosEjecucionDBR i = new plazosEjecucionDBR();
                    i.ShowDialog(this);
                }
            }
        }
        #endregion

        private void mcC1_DateSelected_1(object sender, DateRangeEventArgs e)
        {
            tbDesde.Text = mcC1.SelectionEnd.ToShortDateString();
            FechaCal = tbDesde.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchDeN = long.Parse(FechaFmt.ToString());
            FchDe = FechaFmt.ToString();

            mcC1.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbDesde.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    tipoDeConsulta();
                    BindData();
                }
            }
        }

        private void mcC1_KeyUp_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcC1.Visible = false;
            }
        }

        private void mcC1_Leave_1(object sender, EventArgs e)
        {
            mcC1.Visible = false;
        }

        private void mcC2_DateSelected_1(object sender, DateRangeEventArgs e)
        {
            tbHasta.Text = mcC2.SelectionEnd.ToShortDateString();
            FechaCal = tbHasta.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchHasN = long.Parse(FechaFmt.ToString());
            FchHas = FechaFmt.ToString();

            mcC2.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbHasta.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    tipoDeConsulta();
                    BindData();
                }
            }
        }

        private void mcC2_KeyUp_1(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcC2.Visible = false;
            }
        }

        private void mcC2_Leave_1(object sender, EventArgs e)
        {
            mcC2.Visible = false;
        }

        private void cboExcepciones2_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindData();
        }

        private void cmSimulado_Click_Event(object sender, EventArgs e)
        {
            string msg = "";


            if (bonificacionParcial.CALORI.Replace(" ", "") == "Pagar" || bonificacionParcial.CALORI.Replace(" ", "") == "Devolucion" || bonificacionParcial.CALORI.Replace(" ", "") == "Postergar")
            {
                MessageBox.Show("Para generar una Bonificación Parcial, la calificación debe ser diferente de 'Pagar, Devolución y Postergar'.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            msg = "Se aplicará una bonificación anticipada a la orden de compra: " + bonificacionParcial.PONUMB + "\n\n¿Desea continuar?";

            if (MessageBox.Show(msg, "Convenio", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {
                Negocio.Convenio.Convenio.BonificacionParcial_iu(bonificacionParcial);
            }


        }

        private void miRptBonificacionAnticipada_Click(object sender, EventArgs e)
        {
            Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "BonificacionAnticipada").SingleOrDefault<Form>();
            {
                if (existe != null)
                {
                    MessageBox.Show("La ventana ya se encuentra abierta.");
                }
                else
                {
                    BonificacionAnticipada i = new BonificacionAnticipada();
                    i.Marca = (Comun.Engine.Marca)Convert.ToInt32(this.cbMarca.SelectedValue);
                    i.Comprador = Convert.ToInt32(this.cbCompradores.SelectedValue);
                    i.ShowDialog(this);
                }
            }
        }

        public string vbrl { get; set; }

        private void cboFechas_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (this.cboFechas.SelectedIndex > -1 && this.cboFechas.ComboBox.SelectedValue.ToString() != "System.Data.DataRowView")
                {
                    this.tbHasta.Text = this.cboFechas.ComboBox.SelectedValue.ToString();
                    this.tbDesde.Text = this.cboFechas.ComboBox.SelectedValue.ToString();
                    mcC1.SetDate(Convert.ToDateTime(this.cboFechas.ComboBox.SelectedValue.ToString()));
                    mcC2.SetDate(Convert.ToDateTime(this.cboFechas.ComboBox.SelectedValue.ToString()));

                    #region [ Código de los calendarios para que funcione "TipoDeConsulta" ]
                    tbDesde.Text = mcC1.SelectionEnd.ToShortDateString();
                    FechaCal = tbDesde.Text;
                    FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                    FchDeN = long.Parse(FechaFmt.ToString());
                    FchDe = FechaFmt.ToString();

                    tbHasta.Text = mcC2.SelectionEnd.ToShortDateString();
                    FechaCal = tbHasta.Text;
                    FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                    FchHasN = long.Parse(FechaFmt.ToString());
                    FchHas = FechaFmt.ToString();
                    #endregion

                    tipoDeConsulta();
                    BindData();
                }
            }
            catch (Exception)
            {

                //  throw;
            }



        }

    }
}
