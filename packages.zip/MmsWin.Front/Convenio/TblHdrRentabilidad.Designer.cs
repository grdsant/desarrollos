﻿namespace MmsWin.Front.Convenio
{
    partial class TblHdrRent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TblHdrRent));
            this.pbNuevo = new System.Windows.Forms.PictureBox();
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.nuevoTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.detalleTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.ActualizarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.EliminarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pbNuevo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.cmMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbNuevo
            // 
            this.pbNuevo.Image = ((System.Drawing.Image)(resources.GetObject("pbNuevo.Image")));
            this.pbNuevo.Location = new System.Drawing.Point(6, 3);
            this.pbNuevo.Name = "pbNuevo";
            this.pbNuevo.Size = new System.Drawing.Size(26, 27);
            this.pbNuevo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbNuevo.TabIndex = 26;
            this.pbNuevo.TabStop = false;
            this.pbNuevo.Click += new System.EventHandler(this.pbNuevo_Click);
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowDrop = true;
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.ContextMenuStrip = this.cmMenu;
            this.dgvGridView.Location = new System.Drawing.Point(3, 32);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.Size = new System.Drawing.Size(933, 285);
            this.dgvGridView.TabIndex = 23;
            this.dgvGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellDoubleClick);
            this.dgvGridView.SelectionChanged += new System.EventHandler(this.dgvGridView_SelectionChanged);
            this.dgvGridView.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dgvGridView_KeyPress);
            this.dgvGridView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvGridView_KeyUp);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nuevoTSMI,
            this.detalleTSMI,
            this.ActualizarTSMI,
            this.EliminarTSMI});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(127, 92);
            // 
            // nuevoTSMI
            // 
            this.nuevoTSMI.Name = "nuevoTSMI";
            this.nuevoTSMI.Size = new System.Drawing.Size(126, 22);
            this.nuevoTSMI.Text = "Nuevo";
            this.nuevoTSMI.Click += new System.EventHandler(this.nuevoTSMI_Click);
            // 
            // detalleTSMI
            // 
            this.detalleTSMI.Name = "detalleTSMI";
            this.detalleTSMI.Size = new System.Drawing.Size(126, 22);
            this.detalleTSMI.Text = "Detalle";
            this.detalleTSMI.Click += new System.EventHandler(this.detalleTSMI_Click);
            // 
            // ActualizarTSMI
            // 
            this.ActualizarTSMI.Name = "ActualizarTSMI";
            this.ActualizarTSMI.Size = new System.Drawing.Size(126, 22);
            this.ActualizarTSMI.Text = "Actualizar";
            this.ActualizarTSMI.Click += new System.EventHandler(this.ActualizarTSMI_Click);
            // 
            // EliminarTSMI
            // 
            this.EliminarTSMI.Name = "EliminarTSMI";
            this.EliminarTSMI.Size = new System.Drawing.Size(126, 22);
            this.EliminarTSMI.Text = "Eliminar";
            this.EliminarTSMI.Click += new System.EventHandler(this.EliminarTSMI_Click);
            // 
            // TblHdrRent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(939, 322);
            this.ContextMenuStrip = this.cmMenu;
            this.Controls.Add(this.pbNuevo);
            this.Controls.Add(this.dgvGridView);
            this.Name = "TblHdrRent";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Header Tablas de Rentabilidad";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TblHdrRent_FormClosing);
            this.Load += new System.EventHandler(this.TblHdrRent_Load);
            this.Resize += new System.EventHandler(this.TblHdrRent_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.pbNuevo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.cmMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pbNuevo;
        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem nuevoTSMI;
        private System.Windows.Forms.ToolStripMenuItem detalleTSMI;
        private System.Windows.Forms.ToolStripMenuItem ActualizarTSMI;
        private System.Windows.Forms.ToolStripMenuItem EliminarTSMI;
    }
}