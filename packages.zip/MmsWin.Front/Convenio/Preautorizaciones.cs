﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MmsWin.Negocio;
using MmsWin.Negocio.Convenio;

namespace MmsWin.Front.Convenio
{
    public partial class Preautorizaciones : Form
    {
        //Se les asigna su valor desde la pantalla de convenio
        //dependiendo de la selección de los combos de marca y comprador
        public Comun.Engine.Marca Marca { get; set; }
        public int Comprador { get; set; }
        //-------------------------------------------------------

        //Se usan para el marcado y desmarcado de los checkbox en las grid
        bool CheckMarcados = false;
        bool CheckMarcadosDetalle = false;
        //---------------------------------------------------------

        /// <summary>
        /// Número de folio de la solicitud
        /// </summary>
        string Folio = "";

        /// <summary>
        ///Matriz para separar el folio y el estatus del estilo 
        /// </summary>
        string[] item;
        bool[] segAutorizar = new bool[4];


        public Preautorizaciones()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Evento Click de todos los botones de la pantalla
        /// </summary>
        /// <param name="sender">Sender (Default)</param>
        /// <param name="e">e (Default)</param>
        private void Buttons_Click(object sender, EventArgs e)
        {
            dgvEstilosPreautorizados.EndEdit();
            dgvEstilosPreautorizados.ClearSelection();
            this.dgvEstilosPreautorizados.Refresh();

            this.dgvDetalleFolios.EndEdit();
            this.dgvDetalleFolios.ClearSelection();
            this.dgvDetalleFolios.Refresh();

            string msg = "";

            try
            {
                if (sender == this.btnBuscarPre)
                {
                    this.dgvEstilosPreautorizados.DataSource = Negocio.Convenio.Reprogramacion.CargaReprogramacionesSinFormato(this.txtBuscarPre.Text, (int)Marca, Comprador);
                }

                if (sender == this.btnBuscar)
                {
                    CargaFolios();
                }

                if (sender == this.btnAutorizar)
                {
                    AutorizarEstilosSeleccionados();
                }

                if (sender == this.btnLiberar)
                {
                    msg = "Los estilos marcados [*], seran quitados de la solicitud y quedaran disponibles para ser asignados a otra solicitud.\n\n¿Desea continuar?";
                    if (MessageBox.Show(msg, "Convenio", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                    {
                        LiberarEstilosSeleccionados();
                        this.dgvDetalleFolios.DataSource = Negocio.Convenio.Reprogramacion.CargaDetalleFolio(item[0]);
                        this.dgvEstilosPreautorizados.DataSource = Negocio.Convenio.Reprogramacion.CargaReprogramacionesSinFormato(this.txtBuscarPre.Text, (int)Marca, Comprador);
                        CargaFolios();
                    }
                }

                if (sender == this.btnMarcarTodas)
                {
                    //Marcar o desmarcar todos los estilos de la lista
                    foreach (DataGridViewRow row in this.dgvEstilosPreautorizados.Rows)
                    {
                        row.Cells[0].Value = !CheckMarcados;
                    }

                    CheckMarcados = !CheckMarcados;
                }

                if (sender == this.btnMarcarDetalle)
                {
                    //Marcar o desmarcar todos los estilos de la lista
                    foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
                    {
                        row.Cells[0].Value = !CheckMarcadosDetalle;
                    }

                    CheckMarcadosDetalle = !CheckMarcadosDetalle;
                }

                if (sender == this.btnAgregar)
                {
                    //Limpiar los registros autorizados
                    EliminaRegistros();

                    foreach (DataGridViewRow row in this.dgvEstilosPreautorizados.Rows)
                    {
                        DataGridViewCheckBoxCell chk = dgvEstilosPreautorizados.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                        if (Convert.ToBoolean(chk.Value) == true)
                        {
                            this.dgvEstilosSeleccionados.Rows.Add(dgvEstilosPreautorizados.Rows[row.Index].Cells["EstiloID"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["Descripcion"].Value);
                        }
                    }
                }

                if (sender == this.btnImprimir)
                {
                    if (Convert.ToInt32(item[0]) > 0)
                    {
                        rptReprogramaciones f = new rptReprogramaciones();
                        f.StartPosition = FormStartPosition.CenterParent;
                        f.Folio = Convert.ToInt32(item[0]);
                        f.ShowDialog(this);
                    }
                    else
                    {
                        MessageBox.Show("Debe seleccionar una solicitud para imprimirla", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }

                }

                if (sender == this.tsbEliminarTodos)
                {
                    EliminaRegistros();
                }

                if (sender == this.btnGuardar)
                {
                    if (this.dgvEstilosSeleccionados.Rows.Count > 0)
                    {
                        if (MessageBox.Show("Los estilos seleccionados se asignaran a un nuevo folio de solicitud de reprogramacaión\n\n¿Desea continuar?", "Convenio", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                        {
                            Folio = Negocio.Convenio.Reprogramacion.ObtenerFolio();
                            this.lblFolio.Text = string.Format("Folio: {0}", Folio);

                            LigarEstilosFolio();

                            MessageBox.Show(string.Format("Se genero el número de folio: {0}", Folio), "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            Folio = "";
                            CargaFolios();
                            this.dgvEstilosPreautorizados.DataSource = Negocio.Convenio.Reprogramacion.CargaReprogramacionesSinFormato(this.txtBuscarPre.Text, (int)Marca, Comprador);

                            EliminaRegistros();
                        }
                        else
                        {
                            MessageBox.Show("La operación fue cancelada, no se realizaron cambios.", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                    else
                    {
                        MessageBox.Show("ATENCIÓN!\nNo se han seleccionado estilos para asignar un folio, marquelos y haga click en el botón de 'Actualizar estilos'", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void AutorizarEstilosSeleccionados()
        {
            int check = 0;
            int noCheck = 0;

            Folio = item[0];

            foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
            {
                DataGridViewCheckBoxCell chk = dgvDetalleFolios.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                if (Convert.ToBoolean(chk.Value) == true)
                {
                    check++;
                }
                else
                {
                    noCheck++;
                }
            }


            if (noCheck == 0)
            {
                foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
                {
                    DataGridViewCheckBoxCell chk = dgvDetalleFolios.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                    if (Convert.ToBoolean(chk.Value) == true)
                    {
                        Negocio.Convenio.Reprogramacion.AutorizarEstilos(
                            dgvDetalleFolios.Rows[row.Index].Cells["EstiloID"].Value.ToString(),
                            dgvDetalleFolios.Rows[row.Index].Cells["ProveedorID"].Value.ToString(),
                            Convert.ToDateTime(dgvDetalleFolios.Rows[row.Index].Cells["FechaVenc"].Value),
                            Convert.ToDateTime(dgvDetalleFolios.Rows[row.Index].Cells["FechaReprog"].Value));
                    }
                }

                this.dgvDetalleFolios.DataSource = Negocio.Convenio.Reprogramacion.CargaDetalleFolio(Folio);
                this.dgvEstilosPreautorizados.DataSource = Negocio.Convenio.Reprogramacion.CargaReprogramacionesSinFormato(this.txtBuscarPre.Text, (int)Marca, Comprador);
                EliminaRegistros();
                CargaFolios();
                this.btnMarcarDetalle.Enabled = false;
                this.btnAutorizar.Enabled = false;
                this.btnLiberar.Enabled = false;
                MessageBox.Show("SOLICITUD [ " + Folio + " ] AUTORIZADA correctamente.", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
            else
            {
                MessageBox.Show("Debe de seleccionar todas las casillas para autorizar la solicitud. Si desea excluir estilos, primero debe liberarlos.", "Convenio", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        /// <summary>
        /// Desvincula los estilos seleccionados del folio en revisión y quedan libres para asignarse a otra solicitud
        /// </summary>
        private void LiberarEstilosSeleccionados()
        {
            foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
            {
                DataGridViewCheckBoxCell chk = dgvDetalleFolios.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                if (Convert.ToBoolean(chk.Value) == true)
                {
                    Negocio.Convenio.Reprogramacion.LiberarEstilos(
                        dgvDetalleFolios.Rows[row.Index].Cells["EstiloID"].Value.ToString(),
                        dgvDetalleFolios.Rows[row.Index].Cells["ProveedorID"].Value.ToString(),
                        Convert.ToDateTime(dgvDetalleFolios.Rows[row.Index].Cells["FechaVenc"].Value),
                        Convert.ToDateTime(dgvDetalleFolios.Rows[row.Index].Cells["FechaReprog"].Value));
                }
            }
        }

        /// <summary>
        /// Liga los estilos seleccionados al folio correspondiente
        /// </summary>
        private void LigarEstilosFolio()
        {
            string fecha1 = "";
            string fecha2 = "";
            foreach (DataGridViewRow row in this.dgvEstilosPreautorizados.Rows)
            {
                DataGridViewCheckBoxCell chk = dgvEstilosPreautorizados.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                if (Convert.ToBoolean(chk.Value) == true)
                {
                    fecha1 = dgvEstilosPreautorizados.Rows[row.Index].Cells["FechaVenc"].Value.ToString();
                    fecha1 = fecha1.Substring(8, 2) + fecha1.Substring(3, 2) + fecha1.Substring(0, 2);

                    fecha2 = dgvEstilosPreautorizados.Rows[row.Index].Cells["FechaReprog"].Value.ToString();
                    fecha2 = fecha2.Substring(8, 2) + fecha2.Substring(3, 2) + fecha2.Substring(0, 2);

                    Negocio.Convenio.Reprogramacion.AsignaFolio(
                        Folio,
                        dgvEstilosPreautorizados.Rows[row.Index].Cells["Marca"].Value.ToString(),
                        dgvEstilosPreautorizados.Rows[row.Index].Cells["EstiloID"].Value.ToString(),
                        dgvEstilosPreautorizados.Rows[row.Index].Cells["ProveedorID"].Value.ToString(),
                        Convert.ToInt32(fecha1),
                        Convert.ToInt32(fecha2));
                }
            }
        }

        /// <summary>
        /// Borrar los registros de la grid de estilos seleccionados
        /// </summary>
        private void EliminaRegistros()
        {
            int r = (dgvEstilosSeleccionados.Rows.Count - 1);

            for (int i = 0; i <= r; i++)
            {
                dgvEstilosSeleccionados.Rows.RemoveAt(0);
            }
        }

        /// <summary>
        /// Inicialización de la pantalla
        /// </summary>
        /// <param name="sender">Sender (Default)</param>
        /// <param name="e">e (Default)</param>
        private void Preautorizaciones_Load(object sender, EventArgs e)
        {

            //if (MmsWin.Front.Utilerias.VarTem.tmpUser != "COMRRG" && MmsWin.Front.Utilerias.VarTem.tmpUser != "CPRJGC" && MmsWin.Front.Utilerias.VarTem.tmpUser != "PGMCGC")
            //{
            //    this.btnAutorizar.Enabled = false;
            //}

            //Cargar la grid con los estilos dispobibles para el formato
            this.dgvEstilosPreautorizados.DataSource = Negocio.Convenio.Reprogramacion.CargaReprogramacionesSinFormato(this.txtBuscarPre.Text, (int)Marca, Comprador);

            this.cboFiltrar.SelectedItem = "Pendiente";

            //Agregar columna "CheckBox" a los estilos que se seleccionaran para agregar al formato
            DataGridViewCheckBoxColumn CheckboxColumn = new DataGridViewCheckBoxColumn();
            CheckboxColumn.TrueValue = true;
            CheckboxColumn.FalseValue = false;
            CheckboxColumn.Width = 100;
            dgvEstilosPreautorizados.Columns.Insert(0, CheckboxColumn);

            DataGridViewCheckBoxColumn Checkbox_Column = new DataGridViewCheckBoxColumn();
            CheckboxColumn.TrueValue = true;
            CheckboxColumn.FalseValue = false;
            CheckboxColumn.Width = 100;
            dgvDetalleFolios.Columns.Insert(0, Checkbox_Column);

            dgvEstilosPreautorizados.EditMode = DataGridViewEditMode.EditOnKeystroke;
            dgvDetalleFolios.EditMode = DataGridViewEditMode.EditOnKeystroke;
            //-----------------------------------------------------------------------------------------

            #region [ Dar formato a la grid de Estilos Preautorizados ]

            this.lblFolio.Text = "Folio: N/G";

            //Visibilidad
            this.dgvEstilosPreautorizados.Columns["MotivoID"].Visible = false;
            this.dgvEstilosPreautorizados.Columns["CompradorID"].Visible = false;
            this.dgvEstilosPreautorizados.Columns["Marca"].Visible = false;
            this.dgvEstilosPreautorizados.Columns["Estatus"].Visible = false;
            this.dgvEstilosPreautorizados.Columns["Usuario"].Visible = false;

            this.dgvEstilosPreautorizados.Columns["FechaVenc"].Visible = false;
            this.dgvEstilosPreautorizados.Columns["FechaReprog"].Visible = false;

            //Fuente
            this.dgvEstilosPreautorizados.Columns[0].Frozen = true;
            this.dgvEstilosPreautorizados.Columns["EstiloID"].Frozen = true;
            this.dgvEstilosPreautorizados.Columns["Descripcion"].Frozen = true;
            this.dgvEstilosPreautorizados.Columns["EstiloID"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            this.dgvEstilosPreautorizados.Columns["Descripcion"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            this.dgvEstilosPreautorizados.Columns["Proveedor"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            this.dgvEstilosPreautorizados.Columns["ProveedorId"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            //Ancho
            this.dgvEstilosPreautorizados.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosPreautorizados.Columns["Motivo"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosPreautorizados.Columns["EstiloID"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosPreautorizados.Columns["Descripcion"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosPreautorizados.Columns["Proveedor"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosPreautorizados.Columns["ProveedorId"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;

            #endregion

            #region [ Dar formato a la grid de estilos seleccionados ]

            this.dgvEstilosSeleccionados.Columns.Add("EstiloID", "EstiloID");
            this.dgvEstilosSeleccionados.Columns.Add("Descripcion", "Descripción");
            //Fuente
            this.dgvEstilosSeleccionados.Columns["EstiloID"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            this.dgvEstilosSeleccionados.Columns["Descripcion"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            //Ancho
            this.dgvEstilosSeleccionados.Columns["EstiloID"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvEstilosSeleccionados.Columns["Descripcion"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;

            #endregion

            CargaFolios();

            //Aplicar la seguridad
            Seguridad("Pateos", "Pateos", MmsWin.Front.Utilerias.VarTem.tmpUser);
        }

        /// <summary>
        /// Llena el listview con los folios generados
        /// </summary>
        /// <param name="Folio">Folio que se desea buscar</param>
        private void CargaFolios()
        {
            DataTable dt = new DataTable();
            int imagen = 0;

            dt = Negocio.Convenio.Reprogramacion.CargaListaFolios(
                        this.txtBuscar.Text.Trim(),
                        this.cboFiltrar.SelectedItem.ToString().Substring(0, 1),
                        (int)Marca,
                        Comprador);

            this.lsvFolios.Items.Clear();

            for (int i = 0; i < dt.Rows.Count; i++)
            {

                DataRow dr = dt.Rows[i];

                if (dr["Estatus"].ToString() == "Autorizado")
                {
                    imagen = 3;

                }
                else
                {
                    imagen = 0;

                }

                this.lsvFolios.Items.Add(dr["Folio"].ToString() + "," + dr["Estatus"].ToString(), dr["Folio"].ToString() + "\n" + dr["Estatus"].ToString(), imagen);
            }

            dt.Dispose();
        }

        private void lsvFolios_DoubleClick(object sender, EventArgs e)
        {
            //Recuperar el folio
            item = this.lsvFolios.SelectedItems[0].Name.Split(',');

            this.dgvDetalleFolios.DataSource = Negocio.Convenio.Reprogramacion.CargaDetalleFolio(item[0]);

            #region [ Dar formato a la grid de Estilos Preautorizados ]

            //Visibilidad
            this.dgvDetalleFolios.Columns["MotivoID"].Visible = false;
            this.dgvDetalleFolios.Columns["CompradorID"].Visible = false;
            this.dgvDetalleFolios.Columns["Marca"].Visible = false;
            this.dgvDetalleFolios.Columns["Estatus"].Visible = false;
            this.dgvDetalleFolios.Columns["Usuario"].Visible = false;
            //Fuente
            this.dgvDetalleFolios.Columns[0].Frozen = true;
            this.dgvDetalleFolios.Columns["EstiloID"].Frozen = true;
            this.dgvDetalleFolios.Columns["Descripcion"].Frozen = true;
            this.dgvDetalleFolios.Columns["EstiloID"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            this.dgvDetalleFolios.Columns["Descripcion"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            this.dgvDetalleFolios.Columns["Proveedor"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            this.dgvDetalleFolios.Columns["ProveedorId"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Fecha inspección
            //Ancho
            this.dgvDetalleFolios.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["Motivo"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["EstiloID"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["Descripcion"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["Proveedor"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["ProveedorId"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;

            #endregion


            if (item[1] == "Autorizado" || item[1] == "Vencido")
            {
                this.btnMarcarDetalle.Enabled = false;
                this.btnAutorizar.Enabled = false;
                this.btnLiberar.Enabled = false;
                this.btnImprimir.Enabled = false;
            }
            else
            {
                if (segAutorizar[0] == true)
                {
                    this.btnAutorizar.Enabled = true;
                }

                if (segAutorizar[2] == true)
                {
                    this.btnLiberar.Enabled = true;
                }

                this.btnMarcarDetalle.Enabled = true;
                this.btnImprimir.Enabled = true;

            }

            //if (item[1] == "Autorizado" || item[1] == "Vencido")
            //{
            //    this.btnMarcarDetalle.Enabled = false;
            //    this.btnAutorizar.Enabled = false;
            //    this.btnLiberar.Enabled = false;
            //    this.btnImprimir.Enabled = false;
            //}
            //else
            //{
            //    this.btnMarcarDetalle.Enabled = true;
            //    this.btnAutorizar.Enabled = true;
            //    this.btnLiberar.Enabled = true;
            //    this.btnImprimir.Enabled = true;
            //}

            //if (MmsWin.Front.Utilerias.VarTem.tmpUser != "COMRRG" && MmsWin.Front.Utilerias.VarTem.tmpUser != "CPRJGC" && MmsWin.Front.Utilerias.VarTem.tmpUser != "PGMCGC")
            //{
            //    this.btnAutorizar.Enabled = false;
            //}
        }



        private void cboFiltrar_SelectedIndexChanged(object sender, EventArgs e)
        {
            CargaFolios();
        }

        private void TxtTeclas_Event(object sender, KeyEventArgs e)
        {

            if (e.KeyValue.ToString() == "13")
            {
                if (sender == this.txtBuscar)
                {
                    CargaFolios();
                }

                if (sender == this.txtBuscarPre)
                {
                    //Cargar la grid con los estilos dispobibles para el formato
                    this.dgvEstilosPreautorizados.DataSource = Negocio.Convenio.Reprogramacion.CargaReprogramacionesSinFormato(this.txtBuscarPre.Text, (int)Marca, Comprador);
                }
            }
        }

        #region  Seguridad
        
        private void Preautorizaciones_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MmsWin.Front.Utilerias.VarTem.tmpUSRVIL == "ADMINISTRADOR")
            {
                CargaSeguridad("Pateos", "Pateos", MmsWin.Front.Utilerias.VarTem.tmpUser);
            }
        }

        /// <summary>
        /// Inserta los controles del formulario a la tabla MMSATOBJ.SAT177SCLS
        /// </summary>
        /// <param name="Aplicacion">Nombre de la aplicación</param>
        /// <param name="Modulo">Nombre del módulo</param>
        /// <param name="Usuario">Usuario que inicio sesión</param>
        /// <remarks>
        ///     Desarrollador: Gustavo de los Santos | 08/12/2016
        ///     Actualizo: Omar Cervantes  | 28/02/2017
        ///     Paso seguridad: 2
        /// </remarks>
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");

            //Definición de la estructura del DataTable
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (ToolStripItem item in tspGeneracionFormatos.Items)
            {
                DataRow toolStripControls = dtControles.NewRow();

                //Valores generales para cada renglon  
                toolStripControls["Aplicacion"] = Aplicacion;
                toolStripControls["Modulo"] = Modulo;
                toolStripControls["Usuario"] = Usuario;

                //Si el control es del tipo "ToolStripButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripComboBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripComboBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripComboBox";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripSplitButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripSplitButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripSplitButton";

                    dtControles.Rows.Add(toolStripControls);
                }



                //Si el control es del tipo "ToolStripLabel"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripTextBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripTextBox";

                    dtControles.Rows.Add(toolStripControls);
                }
            }

            foreach (ToolStripItem item in this.tspOrdenesSeleccionadas.Items)
            {
                DataRow toolStripControls = dtControles.NewRow();

                //Valores generales para cada renglon  
                toolStripControls["Aplicacion"] = Aplicacion;
                toolStripControls["Modulo"] = Modulo;
                toolStripControls["Usuario"] = Usuario;

                //Si el control es del tipo "ToolStripButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripComboBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripComboBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripComboBox";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripSplitButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripSplitButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripSplitButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripLabel"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripTextBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripTextBox";

                    dtControles.Rows.Add(toolStripControls);
                }
            }

            foreach (ToolStripItem item in this.tspConsultaAutorizadas.Items)
            {
                DataRow toolStripControls = dtControles.NewRow();

                //Valores generales para cada renglon  
                toolStripControls["Aplicacion"] = Aplicacion;
                toolStripControls["Modulo"] = Modulo;
                toolStripControls["Usuario"] = Usuario;

                //Si el control es del tipo "ToolStripButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripComboBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripComboBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripComboBox";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripSplitButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripSplitButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripSplitButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripTextBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripTextBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripTextBox";

                    dtControles.Rows.Add(toolStripControls);
                }
            }

            foreach (ToolStripItem item in this.tspAutorizadas.Items)
            {
                DataRow toolStripControls = dtControles.NewRow();

                //Valores generales para cada renglon  
                toolStripControls["Aplicacion"] = Aplicacion;
                toolStripControls["Modulo"] = Modulo;
                toolStripControls["Usuario"] = Usuario;

                //Si el control es del tipo "ToolStripButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripComboBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripComboBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripComboBox";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripSplitButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripSplitButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripSplitButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripTextBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripTextBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripTextBox";

                    dtControles.Rows.Add(toolStripControls);
                }

            }

            //Guardar los controles recuperados de la pantalla.
            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }


        /// <summary>
        /// Recupera los niveles del perfil del usuario y aplica los permisos
        /// a los controles del formulario
        /// </summary>
        /// <param name="Aplicacion">Nombre de aplicación o pantalla</param>
        /// <param name="Modulo">Nombre del módulo</param>
        /// <param name="Usuario">ID del usuario</param>
        /// <remarks>
        ///     Desarrollador: Gustavo de los Santos | 08/12/2016
        ///     Actualizo: Omar Cervantes  | 28/02/2017
        ///     Paso seguridad: 3
        /// </remarks>
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            // Buscar el control dentro del DataTable
            DataRow[] foundRows;

            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);

            string busca = string.Empty;

            //Aplicar seguridad de los controles que no se encuentran dentro de un control 
            //contenedor
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }

            foreach (ToolStripItem item in this.tspAutorizadas.Items)
            {
                foundRows = tbSeguridad.Select("SEGCLS Like '" + item.Name + "%'");

                if (foundRows.Count() > 0)
                {
                    if (item.Name == (foundRows[0]["SEGCLS"].ToString()))
                    {
                        item.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        item.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }

            }

            foreach (ToolStripItem item in this.tspConsultaAutorizadas.Items)
            {
                foundRows = tbSeguridad.Select("SEGCLS Like '" + item.Name + "%'");

                if (foundRows.Count() > 0)
                {
                    if (item.Name == (foundRows[0]["SEGCLS"].ToString()))
                    {
                        item.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        item.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }

            }

            foreach (ToolStripItem item in this.tspGeneracionFormatos.Items)
            {
                foundRows = tbSeguridad.Select("SEGCLS Like '" + item.Name + "%'");

                if (foundRows.Count() > 0)
                {
                    if (item.Name == (foundRows[0]["SEGCLS"].ToString()))
                    {
                        item.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        item.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }

            }

            foreach (ToolStripItem item in this.tspOrdenesSeleccionadas.Items)
            {
                foundRows = tbSeguridad.Select("SEGCLS Like '" + item.Name + "%'");

                if (foundRows.Count() > 0)
                {
                    if (item.Name == (foundRows[0]["SEGCLS"].ToString()))
                    {
                        item.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        item.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }

            }

            foreach (Control X in this.Controls)
            {

                busca = X.Name;


                foundRows = tbSeguridad.Select("SEGCLS Like '" + busca + "%'");

                if (foundRows.Count() > 0)
                {
                    if (X.GetType() != typeof(ToolStrip))
                    {
                        X.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        X.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }
            }

            //Recupera de la seguridad, el valor de las propiedades "Enabled" y "Visible"
            segAutorizar[0] = this.btnAutorizar.Enabled;
            segAutorizar[1] = this.btnAutorizar.Visible;

            segAutorizar[2] = this.btnLiberar.Enabled;
            segAutorizar[3] = this.btnLiberar.Visible;
        }

        /// <summary>
        /// Aplicar seguridad de los controles que no se encuentran dentro de un control 
        /// contenedor
        /// </summary>
        /// <param name="Controles">Nombre del control</param>
        /// <param name="ValHab">Valor para aplicar a "Enabled"</param>
        /// <param name="ValVis">Valor para aplicar a  "Visibkle"</param>
        /// <param name="tipo">Tipo de objeto</param>
        /// <remarks>
        ///     Desarrollador: Gustavo de los Santos | 08/12/2016
        ///     Actualizo: Omar Cervantes  | 01/03/2017
        ///     Paso seguridad: 4
        /// </remarks>
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                this.Controls[Controles].Enabled = Convert.ToBoolean(ValHab);
                this.Controls[Controles].Visible = Convert.ToBoolean(ValVis);
            }
        }


        #endregion

    }
}
