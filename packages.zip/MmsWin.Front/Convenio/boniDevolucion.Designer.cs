﻿namespace MmsWin.Front.Convenio
{
    partial class boniDevolucion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(boniDevolucion));
            this.lblCostoTotDesc = new System.Windows.Forms.Label();
            this.lblCostoActDesc = new System.Windows.Forms.Label();
            this.lblCostoTot = new System.Windows.Forms.Label();
            this.lblCostoAct = new System.Windows.Forms.Label();
            this.lblOnHandDesc = new System.Windows.Forms.Label();
            this.lblOnHand = new System.Windows.Forms.Label();
            this.btAceptar = new System.Windows.Forms.Button();
            this.btCancelar = new System.Windows.Forms.Button();
            this.cboMotivo = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbPagar = new System.Windows.Forms.CheckBox();
            this.lblPagado = new System.Windows.Forms.Label();
            this.lblCostoBonNueDesc = new System.Windows.Forms.Label();
            this.lblCostoBonNue = new System.Windows.Forms.Label();
            this.lblMensage = new System.Windows.Forms.Label();
            this.tbCalNueva = new System.Windows.Forms.TextBox();
            this.lblPorNueva = new System.Windows.Forms.Label();
            this.lblMotivo = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblComprador = new System.Windows.Forms.Label();
            this.lblNumReprog = new System.Windows.Forms.Label();
            this.lblEstilo = new System.Windows.Forms.Label();
            this.lblCompradorDesc = new System.Windows.Forms.Label();
            this.lblDescEstilo = new System.Windows.Forms.Label();
            this.lblidEstilo = new System.Windows.Forms.Label();
            this.lblDescProveedor = new System.Windows.Forms.Label();
            this.lblMarca = new System.Windows.Forms.Label();
            this.lblNumProg = new System.Windows.Forms.Label();
            this.lblOCDesc = new System.Windows.Forms.Label();
            this.lblOC = new System.Windows.Forms.Label();
            this.lblDescMarca = new System.Windows.Forms.Label();
            this.lblNombreProv = new System.Windows.Forms.Label();
            this.lblTemporada = new System.Windows.Forms.Label();
            this.lblTem = new System.Windows.Forms.Label();
            this.lblProveedor = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCostoTotDesc
            // 
            this.lblCostoTotDesc.AutoSize = true;
            this.lblCostoTotDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoTotDesc.Location = new System.Drawing.Point(88, 56);
            this.lblCostoTotDesc.Name = "lblCostoTotDesc";
            this.lblCostoTotDesc.Size = new System.Drawing.Size(14, 13);
            this.lblCostoTotDesc.TabIndex = 50;
            this.lblCostoTotDesc.Text = "1";
            // 
            // lblCostoActDesc
            // 
            this.lblCostoActDesc.AutoSize = true;
            this.lblCostoActDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoActDesc.Location = new System.Drawing.Point(88, 35);
            this.lblCostoActDesc.Name = "lblCostoActDesc";
            this.lblCostoActDesc.Size = new System.Drawing.Size(14, 13);
            this.lblCostoActDesc.TabIndex = 49;
            this.lblCostoActDesc.Text = "1";
            // 
            // lblCostoTot
            // 
            this.lblCostoTot.AutoSize = true;
            this.lblCostoTot.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoTot.Location = new System.Drawing.Point(12, 56);
            this.lblCostoTot.Name = "lblCostoTot";
            this.lblCostoTot.Size = new System.Drawing.Size(64, 13);
            this.lblCostoTot.TabIndex = 48;
            this.lblCostoTot.Text = "Costo Total:";
            // 
            // lblCostoAct
            // 
            this.lblCostoAct.AutoSize = true;
            this.lblCostoAct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoAct.Location = new System.Drawing.Point(12, 35);
            this.lblCostoAct.Name = "lblCostoAct";
            this.lblCostoAct.Size = new System.Drawing.Size(70, 13);
            this.lblCostoAct.TabIndex = 47;
            this.lblCostoAct.Text = "Costo Actual:";
            // 
            // lblOnHandDesc
            // 
            this.lblOnHandDesc.AutoSize = true;
            this.lblOnHandDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOnHandDesc.Location = new System.Drawing.Point(88, 14);
            this.lblOnHandDesc.Name = "lblOnHandDesc";
            this.lblOnHandDesc.Size = new System.Drawing.Size(14, 13);
            this.lblOnHandDesc.TabIndex = 46;
            this.lblOnHandDesc.Text = "1";
            // 
            // lblOnHand
            // 
            this.lblOnHand.AutoSize = true;
            this.lblOnHand.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOnHand.Location = new System.Drawing.Point(12, 14);
            this.lblOnHand.Name = "lblOnHand";
            this.lblOnHand.Size = new System.Drawing.Size(53, 13);
            this.lblOnHand.TabIndex = 45;
            this.lblOnHand.Text = "On Hand:";
            // 
            // btAceptar
            // 
            this.btAceptar.Location = new System.Drawing.Point(250, 172);
            this.btAceptar.Name = "btAceptar";
            this.btAceptar.Size = new System.Drawing.Size(75, 23);
            this.btAceptar.TabIndex = 80;
            this.btAceptar.Text = "Aceptar";
            this.btAceptar.UseVisualStyleBackColor = true;
            this.btAceptar.Click += new System.EventHandler(this.btAceptar_Click);
            // 
            // btCancelar
            // 
            this.btCancelar.Location = new System.Drawing.Point(336, 172);
            this.btCancelar.Name = "btCancelar";
            this.btCancelar.Size = new System.Drawing.Size(75, 23);
            this.btCancelar.TabIndex = 79;
            this.btCancelar.Text = "Cancelar";
            this.btCancelar.UseVisualStyleBackColor = true;
            this.btCancelar.Click += new System.EventHandler(this.btCancelar_Click);
            // 
            // cboMotivo
            // 
            this.cboMotivo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMotivo.FormattingEnabled = true;
            this.cboMotivo.Location = new System.Drawing.Point(100, 123);
            this.cboMotivo.Name = "cboMotivo";
            this.cboMotivo.Size = new System.Drawing.Size(311, 21);
            this.cboMotivo.TabIndex = 78;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PowderBlue;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cbPagar);
            this.panel1.Controls.Add(this.lblPagado);
            this.panel1.Controls.Add(this.lblCostoBonNueDesc);
            this.panel1.Controls.Add(this.lblCostoBonNue);
            this.panel1.Controls.Add(this.lblMensage);
            this.panel1.Controls.Add(this.tbCalNueva);
            this.panel1.Controls.Add(this.lblPorNueva);
            this.panel1.Controls.Add(this.btAceptar);
            this.panel1.Controls.Add(this.btCancelar);
            this.panel1.Controls.Add(this.cboMotivo);
            this.panel1.Controls.Add(this.lblMotivo);
            this.panel1.Controls.Add(this.lblCostoTotDesc);
            this.panel1.Controls.Add(this.lblCostoActDesc);
            this.panel1.Controls.Add(this.lblCostoTot);
            this.panel1.Controls.Add(this.lblCostoAct);
            this.panel1.Controls.Add(this.lblOnHandDesc);
            this.panel1.Controls.Add(this.lblOnHand);
            this.panel1.Location = new System.Drawing.Point(14, 153);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(441, 202);
            this.panel1.TabIndex = 83;
            // 
            // cbPagar
            // 
            this.cbPagar.AutoSize = true;
            this.cbPagar.Location = new System.Drawing.Point(102, 103);
            this.cbPagar.Name = "cbPagar";
            this.cbPagar.Size = new System.Drawing.Size(183, 17);
            this.cbPagar.TabIndex = 87;
            this.cbPagar.Text = "Check Seleccionado = Pargado  ";
            this.cbPagar.UseVisualStyleBackColor = true;
            this.cbPagar.CheckedChanged += new System.EventHandler(this.cbPagar_CheckedChanged);
            // 
            // lblPagado
            // 
            this.lblPagado.AutoSize = true;
            this.lblPagado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPagado.Location = new System.Drawing.Point(12, 103);
            this.lblPagado.Name = "lblPagado";
            this.lblPagado.Size = new System.Drawing.Size(84, 13);
            this.lblPagado.TabIndex = 86;
            this.lblPagado.Text = "Directo a Pagar:";
            // 
            // lblCostoBonNueDesc
            // 
            this.lblCostoBonNueDesc.AutoSize = true;
            this.lblCostoBonNueDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoBonNueDesc.Location = new System.Drawing.Point(331, 31);
            this.lblCostoBonNueDesc.Name = "lblCostoBonNueDesc";
            this.lblCostoBonNueDesc.Size = new System.Drawing.Size(17, 17);
            this.lblCostoBonNueDesc.TabIndex = 85;
            this.lblCostoBonNueDesc.Text = "1";
            // 
            // lblCostoBonNue
            // 
            this.lblCostoBonNue.AutoSize = true;
            this.lblCostoBonNue.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoBonNue.Location = new System.Drawing.Point(195, 35);
            this.lblCostoBonNue.Name = "lblCostoBonNue";
            this.lblCostoBonNue.Size = new System.Drawing.Size(130, 13);
            this.lblCostoBonNue.TabIndex = 84;
            this.lblCostoBonNue.Text = "Costo bonificación nuevo:";
            // 
            // lblMensage
            // 
            this.lblMensage.AutoSize = true;
            this.lblMensage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMensage.Location = new System.Drawing.Point(97, 148);
            this.lblMensage.Name = "lblMensage";
            this.lblMensage.Size = new System.Drawing.Size(28, 13);
            this.lblMensage.TabIndex = 83;
            this.lblMensage.Text = "error";
            // 
            // tbCalNueva
            // 
            this.tbCalNueva.Location = new System.Drawing.Point(187, 76);
            this.tbCalNueva.MaxLength = 5;
            this.tbCalNueva.Name = "tbCalNueva";
            this.tbCalNueva.Size = new System.Drawing.Size(81, 20);
            this.tbCalNueva.TabIndex = 82;
            this.tbCalNueva.TextChanged += new System.EventHandler(this.tbCalNueva_TextChanged);
            this.tbCalNueva.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCalNueva_KeyPress);
            // 
            // lblPorNueva
            // 
            this.lblPorNueva.AutoSize = true;
            this.lblPorNueva.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPorNueva.Location = new System.Drawing.Point(12, 79);
            this.lblPorNueva.Name = "lblPorNueva";
            this.lblPorNueva.Size = new System.Drawing.Size(169, 13);
            this.lblPorNueva.TabIndex = 81;
            this.lblPorNueva.Text = "Porcentaje de bonificación nuevo:";
            // 
            // lblMotivo
            // 
            this.lblMotivo.AutoSize = true;
            this.lblMotivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMotivo.Location = new System.Drawing.Point(52, 126);
            this.lblMotivo.Name = "lblMotivo";
            this.lblMotivo.Size = new System.Drawing.Size(42, 13);
            this.lblMotivo.TabIndex = 77;
            this.lblMotivo.Text = "Motivo:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblComprador);
            this.groupBox1.Controls.Add(this.lblNumReprog);
            this.groupBox1.Controls.Add(this.lblEstilo);
            this.groupBox1.Controls.Add(this.lblCompradorDesc);
            this.groupBox1.Controls.Add(this.lblDescEstilo);
            this.groupBox1.Controls.Add(this.lblidEstilo);
            this.groupBox1.Controls.Add(this.lblDescProveedor);
            this.groupBox1.Controls.Add(this.lblMarca);
            this.groupBox1.Controls.Add(this.lblNumProg);
            this.groupBox1.Controls.Add(this.lblOCDesc);
            this.groupBox1.Controls.Add(this.lblOC);
            this.groupBox1.Controls.Add(this.lblDescMarca);
            this.groupBox1.Controls.Add(this.lblNombreProv);
            this.groupBox1.Controls.Add(this.lblTemporada);
            this.groupBox1.Controls.Add(this.lblTem);
            this.groupBox1.Controls.Add(this.lblProveedor);
            this.groupBox1.Location = new System.Drawing.Point(14, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(439, 135);
            this.groupBox1.TabIndex = 96;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Informción general";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // lblComprador
            // 
            this.lblComprador.AutoSize = true;
            this.lblComprador.Location = new System.Drawing.Point(13, 43);
            this.lblComprador.Name = "lblComprador";
            this.lblComprador.Size = new System.Drawing.Size(61, 13);
            this.lblComprador.TabIndex = 99;
            this.lblComprador.Text = "Comprador:";
            // 
            // lblNumReprog
            // 
            this.lblNumReprog.AutoSize = true;
            this.lblNumReprog.Location = new System.Drawing.Point(273, 22);
            this.lblNumReprog.Name = "lblNumReprog";
            this.lblNumReprog.Size = new System.Drawing.Size(84, 13);
            this.lblNumReprog.TabIndex = 98;
            this.lblNumReprog.Text = "Número Evento:";
            // 
            // lblEstilo
            // 
            this.lblEstilo.AutoSize = true;
            this.lblEstilo.Location = new System.Drawing.Point(13, 85);
            this.lblEstilo.Name = "lblEstilo";
            this.lblEstilo.Size = new System.Drawing.Size(35, 13);
            this.lblEstilo.TabIndex = 97;
            this.lblEstilo.Text = "Estilo:";
            // 
            // lblCompradorDesc
            // 
            this.lblCompradorDesc.AutoSize = true;
            this.lblCompradorDesc.Location = new System.Drawing.Point(85, 43);
            this.lblCompradorDesc.Name = "lblCompradorDesc";
            this.lblCompradorDesc.Size = new System.Drawing.Size(27, 13);
            this.lblCompradorDesc.TabIndex = 104;
            this.lblCompradorDesc.Text = "com";
            // 
            // lblDescEstilo
            // 
            this.lblDescEstilo.AutoSize = true;
            this.lblDescEstilo.Location = new System.Drawing.Point(126, 85);
            this.lblDescEstilo.Name = "lblDescEstilo";
            this.lblDescEstilo.Size = new System.Drawing.Size(55, 13);
            this.lblDescEstilo.TabIndex = 103;
            this.lblDescEstilo.Text = "descEstilo";
            // 
            // lblidEstilo
            // 
            this.lblidEstilo.AutoSize = true;
            this.lblidEstilo.Location = new System.Drawing.Point(84, 85);
            this.lblidEstilo.Name = "lblidEstilo";
            this.lblidEstilo.Size = new System.Drawing.Size(15, 13);
            this.lblidEstilo.TabIndex = 102;
            this.lblidEstilo.Text = "id";
            // 
            // lblDescProveedor
            // 
            this.lblDescProveedor.AutoSize = true;
            this.lblDescProveedor.Location = new System.Drawing.Point(84, 64);
            this.lblDescProveedor.Name = "lblDescProveedor";
            this.lblDescProveedor.Size = new System.Drawing.Size(15, 13);
            this.lblDescProveedor.TabIndex = 100;
            this.lblDescProveedor.Text = "id";
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = true;
            this.lblMarca.Location = new System.Drawing.Point(13, 22);
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.Size = new System.Drawing.Size(40, 13);
            this.lblMarca.TabIndex = 106;
            this.lblMarca.Text = "Marca:";
            // 
            // lblNumProg
            // 
            this.lblNumProg.AutoSize = true;
            this.lblNumProg.ForeColor = System.Drawing.Color.DarkRed;
            this.lblNumProg.Location = new System.Drawing.Point(367, 22);
            this.lblNumProg.Name = "lblNumProg";
            this.lblNumProg.Size = new System.Drawing.Size(27, 13);
            this.lblNumProg.TabIndex = 105;
            this.lblNumProg.Text = "num";
            // 
            // lblOCDesc
            // 
            this.lblOCDesc.AutoSize = true;
            this.lblOCDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOCDesc.ForeColor = System.Drawing.Color.DarkRed;
            this.lblOCDesc.Location = new System.Drawing.Point(367, 42);
            this.lblOCDesc.Name = "lblOCDesc";
            this.lblOCDesc.Size = new System.Drawing.Size(25, 13);
            this.lblOCDesc.TabIndex = 109;
            this.lblOCDesc.Text = "orc";
            // 
            // lblOC
            // 
            this.lblOC.AutoSize = true;
            this.lblOC.Location = new System.Drawing.Point(273, 42);
            this.lblOC.Name = "lblOC";
            this.lblOC.Size = new System.Drawing.Size(78, 13);
            this.lblOC.TabIndex = 108;
            this.lblOC.Text = "Orden Compra:";
            // 
            // lblDescMarca
            // 
            this.lblDescMarca.AutoSize = true;
            this.lblDescMarca.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescMarca.Location = new System.Drawing.Point(85, 22);
            this.lblDescMarca.Name = "lblDescMarca";
            this.lblDescMarca.Size = new System.Drawing.Size(23, 13);
            this.lblDescMarca.TabIndex = 107;
            this.lblDescMarca.Text = "ma";
            // 
            // lblNombreProv
            // 
            this.lblNombreProv.AutoSize = true;
            this.lblNombreProv.Location = new System.Drawing.Point(126, 64);
            this.lblNombreProv.Name = "lblNombreProv";
            this.lblNombreProv.Size = new System.Drawing.Size(70, 13);
            this.lblNombreProv.TabIndex = 101;
            this.lblNombreProv.Text = "nombreProve";
            // 
            // lblTemporada
            // 
            this.lblTemporada.AutoSize = true;
            this.lblTemporada.Location = new System.Drawing.Point(84, 106);
            this.lblTemporada.Name = "lblTemporada";
            this.lblTemporada.Size = new System.Drawing.Size(24, 13);
            this.lblTemporada.TabIndex = 111;
            this.lblTemporada.Text = "tem";
            // 
            // lblTem
            // 
            this.lblTem.AutoSize = true;
            this.lblTem.Location = new System.Drawing.Point(13, 106);
            this.lblTem.Name = "lblTem";
            this.lblTem.Size = new System.Drawing.Size(64, 13);
            this.lblTem.TabIndex = 110;
            this.lblTem.Text = "Temporada:";
            // 
            // lblProveedor
            // 
            this.lblProveedor.AutoSize = true;
            this.lblProveedor.Location = new System.Drawing.Point(13, 64);
            this.lblProveedor.Name = "lblProveedor";
            this.lblProveedor.Size = new System.Drawing.Size(59, 13);
            this.lblProveedor.TabIndex = 96;
            this.lblProveedor.Text = "Proveedor:";
            // 
            // boniDevolucion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 366);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "boniDevolucion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bonificación por Devolución";
            this.Load += new System.EventHandler(this.boniDevolucion_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblCostoTotDesc;
        private System.Windows.Forms.Label lblCostoActDesc;
        private System.Windows.Forms.Label lblCostoTot;
        private System.Windows.Forms.Label lblCostoAct;
        private System.Windows.Forms.Label lblOnHandDesc;
        private System.Windows.Forms.Label lblOnHand;
        private System.Windows.Forms.Button btAceptar;
        private System.Windows.Forms.Button btCancelar;
        private System.Windows.Forms.ComboBox cboMotivo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblMotivo;
        private System.Windows.Forms.TextBox tbCalNueva;
        private System.Windows.Forms.Label lblPorNueva;
        private System.Windows.Forms.Label lblMensage;
        private System.Windows.Forms.Label lblCostoBonNueDesc;
        private System.Windows.Forms.Label lblCostoBonNue;
        private System.Windows.Forms.CheckBox cbPagar;
        private System.Windows.Forms.Label lblPagado;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblComprador;
        private System.Windows.Forms.Label lblNumReprog;
        private System.Windows.Forms.Label lblEstilo;
        private System.Windows.Forms.Label lblCompradorDesc;
        private System.Windows.Forms.Label lblDescEstilo;
        private System.Windows.Forms.Label lblidEstilo;
        private System.Windows.Forms.Label lblDescProveedor;
        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.Label lblNumProg;
        private System.Windows.Forms.Label lblOCDesc;
        private System.Windows.Forms.Label lblOC;
        private System.Windows.Forms.Label lblDescMarca;
        private System.Windows.Forms.Label lblNombreProv;
        private System.Windows.Forms.Label lblTemporada;
        private System.Windows.Forms.Label lblTem;
        private System.Windows.Forms.Label lblProveedor;
    }
}