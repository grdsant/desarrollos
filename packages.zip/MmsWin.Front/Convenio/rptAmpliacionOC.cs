﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class rptAmpliacionOC : Form
    {
        /// <summary>
        /// Recibe el número de folio del reporte seleccionado para imprimir.
        /// </summary>
        public int Folio { get; set; }

        public rptAmpliacionOC()
        {
            InitializeComponent();
        }

        private void rptAmpliacionOC_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'sAT176AOC.SAT176AOC' Puede moverla o quitarla según sea necesario.
            //this.sAT176AOCTableAdapter.Fill(this.sAT176AOC.SAT176AOC);
            // TODO: esta línea de código carga datos en la tabla 'dsSAT177AOC.SAT177AOC' Puede moverla o quitarla según sea necesario.
            this.sAT176AOCTableAdapter.Fill(this.sAT176AOC._SAT176AOC,Folio);

            this.reportViewer1.RefreshReport();
        }
    }
}
