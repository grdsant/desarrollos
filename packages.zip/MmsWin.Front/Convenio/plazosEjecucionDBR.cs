﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class plazosEjecucionDBR : Form
    {
        #region " Variables Globales"
        int nr;

        private static string comprador = string.Empty;
        private static string marca = string.Empty;

        System.Data.DataTable dtFiltroPlazos = null;
        private BindingSource bsFiltroPlazos;
        #endregion

        #region " Metodo de clase Proncipal "
        public plazosEjecucionDBR()
        {
            InitializeComponent();
        }
        #endregion

        #region " Page load "
        private void plazosEjecucionDBR_Load(object sender, EventArgs e)
        {
            try
            {
                cargaComprador();
                cargaMarca();
                cargaGrid();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region  " Metodo que llena el Grid "
        protected void cargaGrid()
        {
            try
            {
                gvPlazos.DataSource = null;
                dtFiltroPlazos = MmsWin.Negocio.Plazos.plazos.GetInstance().detallePlazosDBR(marca, comprador);

                if (dtFiltroPlazos != null)
                {
                    if (dtFiltroPlazos.Rows.Count > 0)
                    {
                        bsFiltroPlazos = new BindingSource(dtFiltroPlazos, null);
                        gvPlazos.DataSource = bsFiltroPlazos;
                        gvPlazos.Focus();
                        gvPlazos.Select();
                        filtraPlazos();
                        estilosGridView();
                    }
                    else
                    {
                        bsFiltroPlazos = new BindingSource(dtFiltroPlazos, null);
                    }
                }
                else
                {
                    bsFiltroPlazos = new BindingSource(dtFiltroPlazos, null);
                }

                this.Cursor = Cursors.Default;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region "  llena los Drop Marca  "
        protected void cargaMarca()
        {
            try
            {
                cbMarca.DataSource = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();
                cbMarca.DisplayMember = "Value";
                cbMarca.ValueMember = "Key";
                marca = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region "  llena los Drop Comprador  "
        protected void cargaComprador()
        {
            try
            {
                cbCompradores.DataSource = MmsWin.Negocio.Catalogos.Compradores.GetInstance().ObtenCompradors().ToList();
                cbCompradores.DisplayMember = "Value";
                cbCompradores.ValueMember = "Key";
                comprador = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region "  Semanejan todos los estilos de los Gridview  "
        public void estilosGridView()
        {
            this.gvPlazos.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
            this.gvPlazos.EnableHeadersVisualStyles = false;
            this.gvPlazos.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.gvPlazos.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.gvPlazos.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.gvPlazos.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.gvPlazos.RowsDefaultCellStyle.ForeColor = Color.Black;

            //Fuente
            this.gvPlazos.Columns["IDMARCA"].Visible = false;

            this.gvPlazos.Columns["IDPROV"].Frozen = true;
            this.gvPlazos.Columns["IDPROV"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del Proveedor  
            this.gvPlazos.Columns["IDPROV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.gvPlazos.Columns["PROVEEDOR"].Frozen = true;
            //this.gvPlazos.Columns["PROVEEDOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del Proveedor
            this.gvPlazos.Columns["PROVEEDOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            this.gvPlazos.Columns["IDESTILO"].Frozen = true;
            this.gvPlazos.Columns["IDESTILO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del Estilo
            this.gvPlazos.Columns["IDESTILO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.gvPlazos.Columns["ESTILO"].Frozen = true;
            // this.gvPlazos.Columns["ESTILO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del Estilo
            this.gvPlazos.Columns["ESTILO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            this.gvPlazos.Columns["IDCOMPRADOR"].Frozen = true;
            this.gvPlazos.Columns["IDCOMPRADOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del comprador
            this.gvPlazos.Columns["IDCOMPRADOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.gvPlazos.Columns["COMPRADOR"].Frozen = true;
            // this.gvPlazos.Columns["COMPRADOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del Comprador
            this.gvPlazos.Columns["COMPRADOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            this.gvPlazos.Columns["FECHA"].Frozen = true;
            this.gvPlazos.Columns["FECHA"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// dia Entro en tabla 10
            this.gvPlazos.Columns["FECHA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.gvPlazos.Columns["FECHADOS"].Frozen = true;
            this.gvPlazos.Columns["FECHADOS"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Fecha Entro en tabla 10
            this.gvPlazos.Columns["FECHADOS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.gvPlazos.Columns["FECHATRES"].Frozen = true;
            this.gvPlazos.Columns["FECHATRES"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Fecha Actual
            this.gvPlazos.Columns["FECHATRES"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.gvPlazos.Columns["MARCA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // Marca

            //Título de los encabezados
            this.gvPlazos.Columns["IDPROV"].HeaderText = "# Prov.";
            this.gvPlazos.Columns["PROVEEDOR"].HeaderText = "Proveedor";
            this.gvPlazos.Columns["IDESTILO"].HeaderText = "# Estilo";
            this.gvPlazos.Columns["ESTILO"].HeaderText = "Estilo";
            this.gvPlazos.Columns["IDCOMPRADOR"].HeaderText = "# Comprador";
            this.gvPlazos.Columns["COMPRADOR"].HeaderText = "Comprador";
            this.gvPlazos.Columns["FECHA"].HeaderText = "Días";
            this.gvPlazos.Columns["FECHADOS"].HeaderText = "Fecha Sistema";
            this.gvPlazos.Columns["FECHATRES"].HeaderText = "Fecha Sistema";
            this.gvPlazos.Columns["MARCA"].HeaderText = "Marca";

            //Ancho
            this.gvPlazos.Columns["IDPROV"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gvPlazos.Columns["PROVEEDOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.gvPlazos.Columns["IDESTILO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gvPlazos.Columns["ESTILO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.gvPlazos.Columns["IDCOMPRADOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gvPlazos.Columns["COMPRADOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.gvPlazos.Columns["FECHA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gvPlazos.Columns["FECHADOS"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gvPlazos.Columns["FECHATRES"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.gvPlazos.Columns["MARCA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;

        }
        #endregion

        #region " Evento que exportra a Excel "
        private void pbExcel_Click(object sender, EventArgs e)
        {
            if (cbCompradores.SelectedValue.ToString() == "999")
            {
                MessageBox.Show("!!! Selecciona un Comprador ¡¡¡");
                return;
            }

            if (cbMarca.SelectedValue.ToString() == "999")
            {
                MessageBox.Show("!!! Selecciona una marca ¡¡¡");
                return;
            }

            if (bsFiltroPlazos != null)
            {
                if (bsFiltroPlazos.Count > 0)
                {
                    rptPlazosEjecucionDBR f = new rptPlazosEjecucionDBR();
                    f.StartPosition = FormStartPosition.CenterParent;
                    f.idComprador = cbCompradores.SelectedValue.ToString();
                    f.idMarca = cbMarca.SelectedValue.ToString();
                    f.ShowDialog(this);
                    //ExportaExcel();
                }
                else
                {
                    MessageBox.Show("!!! No existe información ¡¡¡");
                }
            }
            else
            {
                MessageBox.Show("!!! No existe información ¡¡¡");
            }
        }
        #endregion

        #region " Metodo que Exporta el contenido del grid a Excel. "
        private void ExportaExcel()
        {
            DataGridView gv = new DataGridView();
            this.Controls.Add(gv);
            gv.DataSource = bsFiltroPlazos.List;

            Microsoft.Office.Interop.Excel._Application excel = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel._Workbook libro = excel.Workbooks.Add(Type.Missing);
            Microsoft.Office.Interop.Excel._Worksheet hoja = null;

            try
            {
                hoja = libro.ActiveSheet;
                hoja.Name = "PlazoDias";

                // Almacenar la parte del encabezado en Excel
                for (int i = 1; i < gv.Columns.Count + 1; i++)
                {
                    hoja.Cells[1, i] = gv.Columns[i - 1].HeaderText;
                }

                // Almacenar Cada valor de fila y columna para sobresalir hoja
                for (int i = 0; i < gv.Rows.Count - 1; i++)
                {
                    for (int j = 0; j < gv.Columns.Count; j++)
                    {
                        hoja.Cells[i + 2, j + 1] = gv.Rows[i].Cells[j].Value.ToString();
                    }
                }

                SaveFileDialog saveDialog = new SaveFileDialog();
                saveDialog.Filter = "Excel files (*.xlsx)|*.xlsx";
                saveDialog.FilterIndex = 2;

                if (saveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    libro.SaveAs(saveDialog.FileName);
                    MessageBox.Show("!!! Se Exporto correctamente ¡¡¡");
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                excel.Quit();
                libro = null;
                excel = null;
            }

        }
        #endregion

        #region " Evenntos de los Drops  SelectedValueChanged "
        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            ComboBox cbMarca = (ComboBox)sender;
            marca = cbMarca.SelectedValue.ToString();
            cargaGrid();
        }

        private void cbCompradores_SelectedValueChanged(object sender, EventArgs e)
        {
            ComboBox cmbComprador = (ComboBox)sender;
            comprador = cmbComprador.SelectedValue.ToString();
            cargaGrid();
        }
        #endregion

        #region " Eventos para filtrare el grid con los parametros de proveeedores y estilos"
        private void tbProveedor_TextChanged(object sender, EventArgs e)
        {
            filtraPlazos();
        }

        private void tbNombre_TextChanged(object sender, EventArgs e)
        {
            filtraPlazos();
        }

        private void tbEstilo_TextChanged(object sender, EventArgs e)
        {
            filtraPlazos();
        }

        private void tbDescripcion_TextChanged(object sender, EventArgs e)
        {
            filtraPlazos();
        }
        #endregion

        #region " Filtra los registros de la grid de Plazos de ejecución de devoluciones, bonificaciones y rebajas. de los textBox "
        private void filtraPlazos()
        {
            try
            {
                if (tbProveedor.Text == string.Empty && tbNombre.Text == string.Empty && tbEstilo.Text == string.Empty && tbDescripcion.Text == string.Empty)
                {
                    nr = bsFiltroPlazos.Count;
                    this.Text = "Plazos de ejecución de devoluciones, bonificaciones y rebajas. / " + " " + (nr).ToString() + " Registro(s)";
                    bsFiltroPlazos.RemoveFilter();
                    return;
                }

                int cantidad = 0;

                if (tbProveedor.Text != string.Empty)
                    cantidad++;

                if (tbNombre.Text != string.Empty)
                    cantidad++;

                if (tbEstilo.Text != string.Empty)
                    cantidad++;

                if (tbDescripcion.Text != string.Empty)
                    cantidad++;


                string[] filtro = new string[cantidad];

                int numArrelgo = 0;

                if (tbProveedor.Text != string.Empty)
                {
                    filtro[numArrelgo] = string.Format("CONVERT(IDPROV, System.String) LIKE '*{0}*'", tbProveedor.Text);

                    numArrelgo++;
                }
                if (tbNombre.Text != string.Empty)
                {
                    filtro[numArrelgo] = string.Format("PROVEEDOR LIKE '*{0}*' ", tbNombre.Text);

                    numArrelgo++;
                }
                if (tbEstilo.Text != string.Empty)
                {
                    filtro[numArrelgo] = string.Format("CONVERT(IDESTILO, System.String)   LIKE '*{0}*' ", tbEstilo.Text);

                    numArrelgo++;
                }
                if (tbDescripcion.Text != string.Empty)
                {
                    filtro[numArrelgo] = string.Format("ESTILO LIKE '*{0}*'", tbDescripcion.Text);

                    numArrelgo++;
                }

                numArrelgo = 0;

                string resulFiltro = string.Empty;
                for (int i = 0; i <= filtro.Length - 1; i++)
                {
                    resulFiltro += filtro[i].ToString() + " AND ";
                }

                resulFiltro = resulFiltro.Remove(resulFiltro.Length - 4);

                bsFiltroPlazos.Filter = resulFiltro;

                nr = bsFiltroPlazos.Count;
                this.Text = "Plazos de ejecución de devoluciones, bonificaciones y rebajas. / " + " " + (nr).ToString() + " Registro(s)";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion
    }
}
