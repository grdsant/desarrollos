﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class CambioPrecio : Form
    {
        #region " Variables Globales"
        //Se les asigna su valor desde la pantalla de convenio
        //dependiendo de la selección de los combos de marca y comprador
        public Comun.Engine.Marca Marca { get; set; }
        public int Comprador { get; set; }

        public string idComCombo = string.Empty;
        public string usuariCap = string.Empty;
        //Se usan para el marcado y desmarcado de los checkbox en las grid
        bool CheckMarcados = false;
        bool CheckMarcadosDetalle = false;

        private static decimal precioPermitido = 0;

        private static int redonP0 = 0;
        private static int redonP1 = 0;

        private static string limite1 = string.Empty;
        private static string limite2 = string.Empty;
        private static string limite3 = string.Empty;

        private static int redonP01 = 0;
        private static int redonP2 = 0;

        private static int redonP02 = 0;
        private static int redonP3 = 0;

        private static int multiplo1 = 0;
        private static int multiplo2 = 0;
        private static int multiplo3 = 0;
        /// Número de folio de la solicitud
        string Folio = "";

        ///Matriz para separar el folio y el estatus del estilo 
        string[] item;

        private static int marcarTodas = 0;

        DataTable dtFiltroFolio = null;
        private BindingSource bsFiltroPre;

        bool[] segAutorizar = new bool[4];

        #endregion

        public CambioPrecio()
        {
            InitializeComponent();
        }

        #region  " Page Load "
        private void CambioPrecio_Load(object sender, EventArgs e)
        {
            try
            {
                limpiaFiltros();

               // cargaComprador();

                idComCombo = MmsWin.Front.Utilerias.VarTem.tmpComprador;

                //if (MmsWin.Front.Utilerias.VarTem.tmpUser != "COMRRG" && MmsWin.Front.Utilerias.VarTem.tmpUser != "CPRJGC" && MmsWin.Front.Utilerias.VarTem.tmpUser != "PGMCGC")
                //{
                //    this.btnAutorizar.Enabled = false;
                //    usuariCap = MmsWin.Front.Utilerias.VarTem.tmpUser;
                //}
                //cbCompradores.SelectedValue = idComCombo;

                //if (idComCombo != "999")
                //    cbCompradores.Enabled = false;

                this.lblMarcaDesc.Text = string.Empty;
                this.lblError.Text = string.Empty;
                precioPermitido = 0;
                limite1 = string.Empty;
                limite2 = string.Empty;
                limite3 = string.Empty;

                multiplo1 = 0;
                multiplo2 = 0;
                multiplo3 = 0;

                redonP0 = 0;
                redonP1 = 0;

                redonP01 = 0;
                redonP2 = 0;

                redonP02 = 0;
                redonP3 = 0;

              //  this.cboEstatus.ComboBox.SelectedItem = "Pendientes";

                this.pnlActualizar.Visible = false;

                string[] Fechas;
                Fechas = DateTime.Now.GetDateTimeFormats();

                
                lblFechaMod.Text = Fechas[8].ToUpper();

                marcarTodas = 0;

                //Limpia los controles que van a modificar el cambio de precio
                limpialCambioPrecio();

                // Carga Grid´s
                cargaGrid();

                #region " Agregar CheckBox a los GridView "
                //Agregar columna "CheckBox" a los estilos que se seleccionaran para agregar al formato
                DataGridViewCheckBoxColumn CheckboxColumn = new DataGridViewCheckBoxColumn();
                CheckboxColumn.TrueValue = true;
                CheckboxColumn.FalseValue = false;
                CheckboxColumn.Width = 100;
                dgvEstilosPreautorizados.Columns.Insert(0, CheckboxColumn);

                DataGridViewCheckBoxColumn Checkbox_Column = new DataGridViewCheckBoxColumn();
                CheckboxColumn.TrueValue = true;
                CheckboxColumn.FalseValue = false;
                CheckboxColumn.Width = 100;
                dgvDetalleFolios.Columns.Insert(0, Checkbox_Column);

                dgvEstilosPreautorizados.EditMode = DataGridViewEditMode.EditOnKeystroke;
                dgvDetalleFolios.EditMode = DataGridViewEditMode.EditOnKeystroke;
                #endregion

                estilosGridView();
                //Carga los Folis Existentes 
                CargaFolios();
                this.cboEstatus.ComboBox.SelectedItem = "Pendientes";

                //Aplicar la seguridad
                Seguridad("CambioCostoPrecio", "CambioCostoPrecio", MmsWin.Front.Utilerias.VarTem.tmpUser);

                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region "  llena los Drop Comprador  "
        protected void cargaComprador()
        {
            try
            {
                cbCompradores.DataSource = MmsWin.Negocio.Catalogos.Compradores.GetInstance().ObtenCompradors().ToList();
                cbCompradores.ValueMember = "Key";
                cbCompradores.DisplayMember = "Value";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region "  Semanejan todos los estilos de los Gridview  "
        public void estilosGridView()
        {
            if (dgvEstilosPreautorizados.Rows.Count > 0)
            {
                #region [ Dar formato a la grid de Estilos Preautorizados ]

                this.lblFolio.Text = "Folio: N/G";

                //Fuente
                this.dgvEstilosPreautorizados.Columns[0].Frozen = true;
                this.dgvEstilosPreautorizados.Columns["IDPROV"].Frozen = true;
                //this.dgvEstilosPreautorizados.Columns["IDPROV"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del Proveedor  
                this.dgvEstilosPreautorizados.Columns["IDPROV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                // this.dgvEstilosPreautorizados.Columns["IDPROV"].DefaultCellStyle.ForeColor = Color.Maroon;

                this.dgvEstilosPreautorizados.Columns["PROVEEDOR"].Frozen = true;
                this.dgvEstilosPreautorizados.Columns["PROVEEDOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del Proveedor
                this.dgvEstilosPreautorizados.Columns["PROVEEDOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

                this.dgvEstilosPreautorizados.Columns["IDESTILO"].Frozen = true;
                //this.dgvEstilosPreautorizados.Columns["IDESTILO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del Estilo
                this.dgvEstilosPreautorizados.Columns["IDESTILO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                this.dgvEstilosPreautorizados.Columns["ESTILO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del Estilo
                this.dgvEstilosPreautorizados.Columns["ESTILO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

                this.dgvEstilosPreautorizados.Columns["IDCOMPRADOR"].Visible = false;
                //this.dgvEstilosPreautorizados.Columns["COMPRADOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del Comprador
                this.dgvEstilosPreautorizados.Columns["COMPRADOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

                this.dgvEstilosPreautorizados.Columns["ONHAND"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Inventario
                this.dgvEstilosPreautorizados.Columns["CSTOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Costo del Estilo Original
                this.dgvEstilosPreautorizados.Columns["PRCOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;  // Precio del Estilo Original
                this.dgvEstilosPreautorizados.Columns["MAROR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Margen del Estilo  Original ((PRECIO/COSTO)-1)*100

                this.dgvEstilosPreautorizados.Columns["CSTAC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Costo del Estilo ACTUAL
                this.dgvEstilosPreautorizados.Columns["PRCAC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;  // Precio del Estilo ACTUAL
                this.dgvEstilosPreautorizados.Columns["MARAC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Margen del Estilo ACTUAL ((PRECIO/COSTO)-1)*100

                this.dgvEstilosPreautorizados.Columns["ONHAND"].DefaultCellStyle.Format = "###,###,###,###0";
                this.dgvEstilosPreautorizados.Columns["PRCOR"].DefaultCellStyle.Format = "###,###,###,###0.00";
                this.dgvEstilosPreautorizados.Columns["CSTOR"].DefaultCellStyle.Format = "###,###,###,###0.00";
                this.dgvEstilosPreautorizados.Columns["MAROR"].DefaultCellStyle.Format = "0.00\\%";
                this.dgvEstilosPreautorizados.Columns["PRCAC"].DefaultCellStyle.Format = "###,###,###,###0.00";
                this.dgvEstilosPreautorizados.Columns["CSTAC"].DefaultCellStyle.Format = "###,###,###,###0.00";
                this.dgvEstilosPreautorizados.Columns["MARAC"].DefaultCellStyle.Format = "0.00\\%";

                this.dgvEstilosPreautorizados.Columns["IDMARCA"].Visible = false;
                this.dgvEstilosPreautorizados.Columns["MARCA"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold); // El # de la Marca
                this.dgvEstilosPreautorizados.Columns["MARCA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                //Título de los encabezados
                this.dgvEstilosPreautorizados.Columns["IDPROV"].HeaderText = "No Prov.";
                this.dgvEstilosPreautorizados.Columns["PROVEEDOR"].HeaderText = "Proveedor";
                this.dgvEstilosPreautorizados.Columns["IDESTILO"].HeaderText = "No Estilo";
                this.dgvEstilosPreautorizados.Columns["ESTILO"].HeaderText = "Estilo";
                this.dgvEstilosPreautorizados.Columns["ONHAND"].HeaderText = "On Hand";
                this.dgvEstilosPreautorizados.Columns["CSTOR"].HeaderText = "Costo Original";
                this.dgvEstilosPreautorizados.Columns["PRCOR"].HeaderText = "Precio Original";
                this.dgvEstilosPreautorizados.Columns["MAROR"].HeaderText = "Margen Original";
                this.dgvEstilosPreautorizados.Columns["CSTAC"].HeaderText = "Costo Actual";
                this.dgvEstilosPreautorizados.Columns["PRCAC"].HeaderText = "Precio Actual";
                this.dgvEstilosPreautorizados.Columns["MARAC"].HeaderText = "Margen Actual";
                this.dgvEstilosPreautorizados.Columns["MARCA"].HeaderText = "Marca";
                this.dgvEstilosPreautorizados.Columns["TEMP"].HeaderText = "Temporada";
                this.dgvEstilosPreautorizados.Columns["TEMP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                this.dgvEstilosPreautorizados.Columns["COMPRADOR"].HeaderText = "Comprador";

                ////Ancho
                this.dgvEstilosPreautorizados.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
                this.dgvEstilosPreautorizados.Columns["IDPROV"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                this.dgvEstilosPreautorizados.Columns["PROVEEDOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
                this.dgvEstilosPreautorizados.Columns["IDESTILO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                this.dgvEstilosPreautorizados.Columns["ESTILO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
                this.dgvEstilosPreautorizados.Columns["ONHAND"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                this.dgvEstilosPreautorizados.Columns["CSTOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                this.dgvEstilosPreautorizados.Columns["PRCOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                this.dgvEstilosPreautorizados.Columns["MAROR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                this.dgvEstilosPreautorizados.Columns["CSTAC"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                this.dgvEstilosPreautorizados.Columns["PRCAC"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                this.dgvEstilosPreautorizados.Columns["MARAC"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                this.dgvEstilosPreautorizados.Columns["MARCA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                this.dgvEstilosPreautorizados.Columns["TEMP"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
                this.dgvEstilosPreautorizados.Columns["COMPRADOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
                #endregion
            }
            #region [ Dar formato a la grid de estilos seleccionados ]

            // IDCOMPRADOR  COMPRADOR

            this.dgvCPSeleccionadas.Columns.Add("IDPROV", "IDPROV");
            this.dgvCPSeleccionadas.Columns.Add("PROVEEDOR", "PROVEEDOR");
            this.dgvCPSeleccionadas.Columns.Add("IDESTILO", "IDESTILO");
            this.dgvCPSeleccionadas.Columns.Add("IDMARCA", "IDMARCA");
            this.dgvCPSeleccionadas.Columns.Add("TEMP", "TEMP");
            this.dgvCPSeleccionadas.Columns.Add("IDCOMPRADOR", "IDCOMPRADOR");
            this.dgvCPSeleccionadas.Columns.Add("COMPRADOR", "COMPRADOR");
            //Fuente
            this.dgvCPSeleccionadas.Columns["IDPROV"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del Proveedor 
            this.dgvCPSeleccionadas.Columns["PROVEEDOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del Proveedor
            this.dgvCPSeleccionadas.Columns["IDESTILO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del Estilo
            //this.dgvCPSeleccionadas.Columns["IDMARCA"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # de la Marca
            //this.dgvCPSeleccionadas.Columns["TEMP"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//  Temporada 
            this.dgvCPSeleccionadas.Columns["COMPRADOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del Estilo

            this.dgvCPSeleccionadas.Columns["IDMARCA"].Visible = false;
            this.dgvCPSeleccionadas.Columns["TEMP"].Visible = false;
            this.dgvCPSeleccionadas.Columns["IDCOMPRADOR"].Visible = false;

            //Ancho
            this.dgvCPSeleccionadas.Columns["IDPROV"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvCPSeleccionadas.Columns["PROVEEDOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvCPSeleccionadas.Columns["IDESTILO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvCPSeleccionadas.Columns["COMPRADOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            //this.dgvCPSeleccionadas.Columns["IDMARCA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            //this.dgvCPSeleccionadas.Columns["TEMP"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;

            #endregion
        }
        #endregion

        #region  " Limpia contrles que van a cambiar el cambio de precio "
        protected void limpialCambioPrecio()
        {
            this.lblIdComp.Text = string.Empty;
            this.lblComDesc.Text = string.Empty;
            this.lblTemporada.Text = string.Empty;
            this.lblMarcaDesc.Text = string.Empty;
            this.txtCosto.Text = string.Empty;
            this.txtPrecio.Text = string.Empty;
            this.lblTotalMargen.Text = string.Empty;
            this.lblFolioDesc.Text = string.Empty;
            this.lblProvDesc.Text = string.Empty;
            this.lblEstiloDesc.Text = string.Empty;
            this.lblFolioDesc.Text = string.Empty;
            this.lblIdProv.Text = string.Empty;
            this.lblProvDesc.Text = string.Empty;
            this.lblIdEstilo.Text = string.Empty;
            this.lblEstiloDesc.Text = string.Empty;
            this.lblTCA.Text = string.Empty;
            this.lblTPA.Text = string.Empty;
            this.lblTMA.Text = string.Empty;
        }
        #endregion

        #region " Carga los folios que ya estan y no autolizados "
        private void CargaFolios(string Folio = "")
        {
            int imagen = 0;

            string status = "";

            status = (this.cboEstatus.ComboBox.SelectedItem == "Pendientes") ? "P" : "A";

            dtFiltroFolio = MmsWin.Negocio.CambioPrecio.CambioPrecio.CargaListaFolios(idComCombo, status);

            this.lsvFolios.Items.Clear();

            for (int i = 0; i < dtFiltroFolio.Rows.Count; i++)
            {

                DataRow dr = dtFiltroFolio.Rows[i];

                if (dr["ESTATUS"].ToString() == "Autorizado")
                {
                    imagen = 3;
                }
                else
                {
                    imagen = 0;
                }

                this.lsvFolios.Items.Add(dr["FOLIO"].ToString() + "," + dr["ESTATUS"].ToString(), dr["FOLIO"].ToString() + "\n" + dr["ESTATUS"].ToString(), imagen);
            }

            dtFiltroFolio.Dispose();
        }
        #endregion

        #region  " Metodo que llena el Grid's "
        protected void cargaGrid()
        {
            dgvEstilosPreautorizados.DataSource = null;
            System.Data.DataTable dtCambioPrecio = null;

            try
            {
                dtCambioPrecio = MmsWin.Negocio.CambioPrecio.CambioPrecio.GetInstance().CambioPrecioSinFolio(idComCombo);

                if (dtCambioPrecio != null)
                {
                    if (dtCambioPrecio.Rows.Count > 0)
                    {
                        bsFiltroPre = new BindingSource(dtCambioPrecio, null);
                        dgvEstilosPreautorizados.DataSource = bsFiltroPre;
                        dgvEstilosPreautorizados.Focus();
                        dgvEstilosPreautorizados.Select();
                    }
                    else
                    {
                        MessageBox.Show("No se encontró ninguna información", "Cambio de Precio", MessageBoxButtons.OK);
                    }
                }
                else
                {
                    MessageBox.Show("No existe ninguna información", "Cambio de Precio", MessageBoxButtons.OK);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region "  Evento que ejecuta todos los botones de la Pantalla "
        private void Buttons_Click(object sender, EventArgs e)
        {
            dgvEstilosPreautorizados.EndEdit();
            dgvEstilosPreautorizados.ClearSelection();
            this.dgvEstilosPreautorizados.Refresh();

            this.dgvDetalleFolios.EndEdit();
            this.dgvDetalleFolios.ClearSelection();
            this.dgvDetalleFolios.Refresh();

            string msg = "";

            try
            {
                if (sender == this.btnAutorizar)
                {
                    AutorizarEstilos("A");
                }

                if (sender == this.btnLiberar)
                {
                    if (this.pnlActualizar.Visible == true)
                        this.pnlActualizar.Visible = false;

                    limpialCambioPrecio();
                    msg = "El Proveedor - Estilos, Se eliminara del folio.\n\n¿Desea continuar?";
                    if (MessageBox.Show(msg, "Cambio de Precio", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                    {
                        DesautorizarEstilos();
                        this.dgvDetalleFolios.DataSource = Negocio.CambioPrecio.CambioPrecio.CargaDetalleFolio(item[0]);
                        CargaFolios();
                        dgvDetalleFolios.ClearSelection();
                        if (dgvDetalleFolios.Rows.Count == 0)
                        {
                            item[0] = null;
                        }
                    }
                }

                if (sender == this.btnMarcarTodas)
                {
                    if (marcarTodas == 1)
                        marcarTodas = 0;
                    else
                        marcarTodas = 1;

                    //Marcar o desmarcar todos los estilos de la lista
                    foreach (DataGridViewRow row in this.dgvEstilosPreautorizados.Rows)
                    {
                        row.Cells[0].Value = !CheckMarcados;
                    }
                    CheckMarcados = !CheckMarcados;
                }

                if (sender == this.btnMarcarDetalle)
                {
                    //Marcar o desmarcar todos los estilos de la lista
                    foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
                    {
                        row.Cells[0].Value = !CheckMarcadosDetalle;
                    }

                    CheckMarcadosDetalle = !CheckMarcadosDetalle;
                }

                if (sender == this.btnAgregar)
                {
                    agregaAntesDeFolio();
                }

                if (sender == this.btnImprimir)
                {
                    if (this.pnlActualizar.Visible == true)
                        this.pnlActualizar.Visible = false;

                    if (item != null)
                    {
                        dgvDetalleFolios.ClearSelection();
                        limpialCambioPrecio();

                        foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
                        {
                            if (dgvDetalleFolios.Rows[row.Index].Cells["PRCNU"].Value.ToString()[0] == '0')
                            {
                                MessageBox.Show("Para imprimir el folio [ " + item[0] + " ] es necesario que se haya generado el cambio de precio nuevo.", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                return;
                            }
                            if (dgvDetalleFolios.Rows[row.Index].Cells["ESTATUS"].Value.ToString()[0] == 'A')
                            {
                                MessageBox.Show("Para imprimir el folio [ " + item[0] + " ] el estatus tiene que estar en pendiente.", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                return;
                            }
                        }

                        if (Convert.ToInt32(item[0]) > 0)
                        {
                            MmsWin.Negocio.CambioPrecio.CambioPrecio.GetInstance().ObtenEstilosPrepedidos(item[0]);
                            rptCambioPrecio f = new rptCambioPrecio();
                            f.StartPosition = FormStartPosition.CenterParent;
                            f.Folio = Convert.ToInt32(item[0]);
                            f.ShowDialog(this);
                        }
                        else
                        {
                            MessageBox.Show("Debe seleccionar una solicitud para imprimirla", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Debe seleccionar una solicitud para imprimirla", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }

                if (sender == this.tsbEliminarSeleccion)
                {
                    if (this.dgvCPSeleccionadas.SelectedRows.Count > 0)
                    {
                        eliminaPorRegistro();
                        this.dgvCPSeleccionadas.ClearSelection();
                    }
                    else
                    {
                        MessageBox.Show("Debe seleccionar una solicitud para elimiarla", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }

                if (sender == this.btnGenerarFormato)
                {
                    if (this.dgvCPSeleccionadas.Rows.Count > 0)
                    {
                        if (MessageBox.Show("Los Registros de Proveedor - Estilo seleccionados se asignaran a un nuevo folio\n\n¿Desea continuar?", "Cambio de Precio", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                        {
                            Folio = MmsWin.Negocio.CambioPrecio.CambioPrecio.ObtieneFolio();
                            this.lblFolio.Text = string.Format("Folio: {0}", Folio);

                            if (insertaFolioCP() > 0)
                            {
                                MessageBox.Show(string.Format("Se genero la solicitud con el número de folio: {0}", Folio), "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                Folio = "";
                                CargaFolios();
                                EliminaRegistros();
                            }
                            else
                            {
                                MessageBox.Show("ERROR!\nNo se almacenaron los registros seleccionados, haga click en el botón de 'Generar' \n !Si el problema persiste comuniquese a 'Soporte' ", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            }
                        }
                        else
                        {
                            MessageBox.Show("La operación fue cancelada, no se realizaron cambios.", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("ATENCIÓN!\nNo se han seleccionado estilos para asignar un folio, marquelos y haga click en el botón de 'Agregar a Formatos'", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }

                if (sender == this.btnCancelar)
                {
                    dgvDetalleFolios.ClearSelection();
                    limpialCambioPrecio();
                    this.pnlActualizar.Visible = false;
                }

                if (sender == this.btnGuardarCambios)
                {
                    if (this.txtCosto.Text != string.Empty && this.txtPrecio.Text != string.Empty && this.lblTotalMargen.Text != string.Empty)
                    {
                        if (MessageBox.Show("El nuevo costo '" + this.txtCosto.Text + "' , \nel nuevo precio '" + this.txtPrecio.Text + "' \ny el nuevo margen '" + this.lblTotalMargen.Text + "' \n\n¿Desea continuar?", "Cambio de Precio", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                        {
                            string folioMod = this.lblFolioDesc.Text.Trim();
                            string costoMod = this.txtCosto.Text.Trim();
                            string precioMod = this.txtPrecio.Text.Trim();
                            string margenMod = this.lblTotalMargen.Text.Split('%')[0].Trim();
                            string proveeMod = this.lblIdProv.Text.Trim();
                            string estiloMod = this.lblIdEstilo.Text.Trim();
                            string marcaDes = this.lblMarcaDesc.Text.Trim() == "MELODY" ? "10" : this.lblMarcaDesc.Text.Trim() == "MILANO" ? "30" : "60";
                            string TemporadaId = this.lblTemporada.Text.Trim();
                            string costoActual = this.lblTCA.Text.Trim();
                            string precioActual = this.lblTPA.Text.Trim();
                            string margenActual = this.lblTMA.Text.Split('%')[0].Trim();
                            string idComprador = this.lblIdComp.Text;

                            if (costoActual == costoMod && precioActual == precioMod)
                            {
                                MessageBox.Show("ATENCIÓN!\nEl 'Costo y el Precio ' siguen siendo los mismos", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                return;
                            }

                            if (modificaFolioCP(folioMod, costoMod, precioMod, margenMod, proveeMod, estiloMod, marcaDes, TemporadaId, idComprador) > 0)
                            {
                                MessageBox.Show("Se guardaron los cambios correctamente", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                dgvDetalleFolios.ClearSelection();
                                gridDetalleFolio(folioMod);
                                limpialCambioPrecio();
                                this.pnlActualizar.Visible = false;
                            }
                            else
                            {
                                MessageBox.Show("ERROR!\nNo se guardaron los cambios, haga click en el botón de nuevamente \n !Si el problema persiste comuniquese a 'Soporte' ", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            }
                        }
                        else
                        {
                            MessageBox.Show("La operación fue cancelada, no se realizaron cambios.", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("ATENCIÓN!\nPara poder guardar los cambios verifique que el campo 'Costo - Precio - Margen' no estén vacíos", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }

                if (sender == this.btnBuscarCP)
                {
                    filtraPreautorizados();
                }

                //if (sender == this.btnTemporada)
                //{
                //    filtraTemporafa();
                //}

                if (sender == this.btnBuscarFolio)
                {
                    dgvDetalleFolios.ClearSelection();
                    filtraFolios();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion

        #region " Metodo que afrega los estilos con compradores no repetidos que van a genrarles folio "
        private void agregaAntesDeFolio()
        {
            //Limpiar los registros autorizados
            int Proveedor = 0;

            foreach (DataGridViewRow row in this.dgvEstilosPreautorizados.Rows)
            {
                if (this.dgvCPSeleccionadas.RowCount == 0)
                {
                    Proveedor = Convert.ToInt32(dgvEstilosPreautorizados.Rows[row.Index].Cells["IDPROV"].Value);
                }

                DataGridViewCheckBoxCell chk = dgvEstilosPreautorizados.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                if (Convert.ToBoolean(chk.Value) == true)
                {
                    if (this.dgvCPSeleccionadas.Rows.Count > 0)
                    {
                        bool existe = false;
                        foreach (DataGridViewRow rowCP in dgvCPSeleccionadas.Rows)
                        {
                            if (Convert.ToString(rowCP.Cells["COMPRADOR"].Value).Trim() != dgvEstilosPreautorizados.Rows[row.Index].Cells["COMPRADOR"].Value.ToString().Trim())
                            {
                                string comp1 = Convert.ToString(rowCP.Cells["COMPRADOR"].Value).Trim();
                                string comp2 = dgvEstilosPreautorizados.Rows[row.Index].Cells["COMPRADOR"].Value.ToString().Trim();
                                MessageBox.Show(string.Format("Solicitud de un solo comprador y tienes seleccionados al comprador {0} y el comprador {1}", comp1, comp2), "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                                return;
                            }

                            if (
                                Convert.ToString(rowCP.Cells["IDPROV"].Value).Trim().Equals(dgvEstilosPreautorizados.Rows[row.Index].Cells["IDPROV"].Value.ToString().Trim()) &&
                                Convert.ToString(rowCP.Cells["IDESTILO"].Value).Trim().Equals(dgvEstilosPreautorizados.Rows[row.Index].Cells["IDESTILO"].Value.ToString().Trim()) &&
                                Convert.ToString(rowCP.Cells["IDMARCA"].Value).Trim().Equals(dgvEstilosPreautorizados.Rows[row.Index].Cells["IDMARCA"].Value.ToString().Trim()) &&
                                Convert.ToString(rowCP.Cells["TEMP"].Value).Trim().Equals(dgvEstilosPreautorizados.Rows[row.Index].Cells["TEMP"].Value.ToString().Trim()) &&
                                Convert.ToString(rowCP.Cells["COMPRADOR"].Value).Trim().Equals(dgvEstilosPreautorizados.Rows[row.Index].Cells["COMPRADOR"].Value.ToString().Trim()))
                            {
                                existe = true;
                            }
                        }
                        if (existe == true)
                        {

                        }
                        else
                        {
                            this.dgvCPSeleccionadas.Rows.Add(dgvEstilosPreautorizados.Rows[row.Index].Cells["IDPROV"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["PROVEEDOR"].Value,
                                                          dgvEstilosPreautorizados.Rows[row.Index].Cells["IDESTILO"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["IDMARCA"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["TEMP"].Value,
                                                          dgvEstilosPreautorizados.Rows[row.Index].Cells["IDCOMPRADOR"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["COMPRADOR"].Value);
                            this.dgvCPSeleccionadas.Sort(dgvCPSeleccionadas.Columns["PROVEEDOR"], ListSortDirection.Ascending);
                            this.dgvCPSeleccionadas.Columns["IDPROV"].Frozen = true;
                        }
                    }
                    else
                    {
                        this.dgvCPSeleccionadas.Rows.Add(dgvEstilosPreautorizados.Rows[row.Index].Cells["IDPROV"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["PROVEEDOR"].Value,
                                                 dgvEstilosPreautorizados.Rows[row.Index].Cells["IDESTILO"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["IDMARCA"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["TEMP"].Value,
                                                 dgvEstilosPreautorizados.Rows[row.Index].Cells["IDCOMPRADOR"].Value, dgvEstilosPreautorizados.Rows[row.Index].Cells["COMPRADOR"].Value);
                        this.dgvCPSeleccionadas.Sort(dgvCPSeleccionadas.Columns["PROVEEDOR"], ListSortDirection.Ascending);
                        this.dgvCPSeleccionadas.Columns["IDPROV"].Frozen = true;
                    }
                }
            }

            this.dgvCPSeleccionadas.ClearSelection();
        }
        #endregion

        #region " Metodo que autoriza los estilos "
        private void AutorizarEstilos(string estatus)
        {
            int check = 0, noCheck = 0, precios = 0;
            Folio = item[0];

            foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
            {
                DataGridViewCheckBoxCell chk = dgvDetalleFolios.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                if (Convert.ToBoolean(chk.Value) == true)
                {
                    check++;
                }
                else
                {
                    noCheck++;
                }

                if (dgvDetalleFolios.Rows[row.Index].Cells["PRCNU"].Value.ToString()[0] == '0')
                {
                    precios++;
                }
            }

            if (precios > 0)
            {
                MessageBox.Show("Para autorizar el folio [ " + Folio + " ] es necesario que se haya generado el cambio de precio nuevo.", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (noCheck == 0)
            {

                Negocio.CambioPrecio.CambioPrecio.AutorizaFolio(
                       Folio,
                       estatus, usuariCap);

                this.dgvDetalleFolios.DataSource = Negocio.CambioPrecio.CambioPrecio.CargaDetalleFolio(item[0]);
                CargaFolios();
                this.btnMarcarDetalle.Enabled = false;
                this.btnAutorizar.Enabled = false;
                this.btnLiberar.Enabled = false;
                dgvDetalleFolios.ClearSelection();

                if (this.pnlActualizar.Visible == true)
                    this.pnlActualizar.Visible = false;

                limpialCambioPrecio();
                MessageBox.Show("SOLICITUD [ " + Folio + " ] AUTORIZADA correctamente.", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Debe de seleccionar todas las casillas para autorizar la solicitud.", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion

        #region " Metodo que se utiliza para dezautorizar los estilos "
        private void DesautorizarEstilos()
        {
            string folioEs = string.Empty;
            foreach (DataGridViewRow row in this.dgvDetalleFolios.Rows)
            {
                string marcaD = dgvDetalleFolios.Rows[row.Index].Cells["MARCA"].Value.ToString() == "MELODY" ? "10" :
                                  dgvDetalleFolios.Rows[row.Index].Cells["MARCA"].Value.ToString() == "MILANO" ? "30" : "60";

                DataGridViewCheckBoxCell chk = dgvDetalleFolios.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;
                if (Convert.ToBoolean(chk.Value) == true)
                {
                    folioEs = dgvDetalleFolios.Rows[row.Index].Cells["FOLIO"].Value.ToString();
                    Negocio.CambioPrecio.CambioPrecio.EliminaNoAutorizados(
                              folioEs,
                              dgvDetalleFolios.Rows[row.Index].Cells["IDESTILO"].Value.ToString(),
                              dgvDetalleFolios.Rows[row.Index].Cells["IDPROV"].Value.ToString(), marcaD,
                              dgvDetalleFolios.Rows[row.Index].Cells["TEMP"].Value.ToString(),
                              dgvDetalleFolios.Rows[row.Index].Cells["IDCOMPRADOR"].Value.ToString()
                              );
                }
            }

            if (folioEs == string.Empty)
            {
                MessageBox.Show("Debe de seleccionar todas las casillas para dezautorizar la solicitud.", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        #endregion

        #region " Liga los Proveedores y estilos seleccionados a un nuevo folio "
        private int modificaFolioCP(string folioMod, string costoMod, string precioMod, string margenMod, string proveeMod, string estiloMod, string marcaDes, string tempo, string idComprador)
        {
            return MmsWin.Negocio.CambioPrecio.CambioPrecio.modificaFolioCP(folioMod, costoMod, precioMod, margenMod, proveeMod, estiloMod, marcaDes, tempo, idComprador);
        }
        #endregion

        #region " Liga los Proveedores y estilos seleccionados a un nuevo folio "
        private int insertaFolioCP()
        {
            DataTable dtProvedorEstilo = new DataTable("ProvedorEstilo");
            dtProvedorEstilo.Columns.Add("FOLIO", typeof(int));
            dtProvedorEstilo.Columns.Add("IDPROV", typeof(int));
            dtProvedorEstilo.Columns.Add("IDESTILO", typeof(string));
            dtProvedorEstilo.Columns.Add("IDMARCA", typeof(int));
            dtProvedorEstilo.Columns.Add("MARCA", typeof(string));
            dtProvedorEstilo.Columns.Add("TEMP", typeof(string));
            dtProvedorEstilo.Columns.Add("IDCOMPRADOR", typeof(string));

            foreach (DataGridViewRow row in this.dgvCPSeleccionadas.Rows)
            {
                string marcaD = dgvCPSeleccionadas.Rows[row.Index].Cells["IDMARCA"].Value.ToString() == "10" ? "MELODY" :
                                   dgvCPSeleccionadas.Rows[row.Index].Cells["IDMARCA"].Value.ToString() == "30" ? "MILANO" : "KALTEX";

                dtProvedorEstilo.Rows.Add(
                        Folio, dgvCPSeleccionadas.Rows[row.Index].Cells["IDPROV"].Value,
                               dgvCPSeleccionadas.Rows[row.Index].Cells["IDESTILO"].Value.ToString(),
                               dgvCPSeleccionadas.Rows[row.Index].Cells["IDMARCA"].Value,
                               marcaD,
                               dgvCPSeleccionadas.Rows[row.Index].Cells["TEMP"].Value.ToString(),
                               dgvCPSeleccionadas.Rows[row.Index].Cells["IDCOMPRADOR"].Value.ToString()
                        );
            }

            //desmarcar todos los estilos de la lista
            foreach (DataGridViewRow row in this.dgvEstilosPreautorizados.Rows)
            {
                row.Cells[0].Value = false;
            }
            CheckMarcados = false;

            String usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;

            return MmsWin.Negocio.CambioPrecio.CambioPrecio.nuevoFolioCP(dtProvedorEstilo, usuario);
        }
        #endregion

        #region " Filtra los registros de la grid de estilos Preautorizados "
        private void filtraPreautorizados()
        {
            if (txtBuscarCP.Text == string.Empty)
                bsFiltroPre.RemoveFilter();
            else
            {
                bsFiltroPre.Filter = string.Format("IDPROV = '{0}' OR  IDESTILO = '{0}' ", txtBuscarCP.Text);
//                if(bsFiltroPre.Filter.Count == 0)

            }
                //bsFiltroPre.Filter = string.Format("PROVEEDOR LIKE '*{0}*' OR ESTILO LIKE '*{0}*' OR IDESTILO LIKE '*{0}*' OR IDPROV LIKE '*{0}*' OR COMPRADOR LIKE '*{0}*'", txtBuscarCP.Text);
        }

        private void filtraFolios()
        {
            try
            {
                if (this.pnlActualizar.Visible == true)
                    this.pnlActualizar.Visible = false;

                limpialCambioPrecio();

                DataView Dv = dtFiltroFolio.DefaultView;
                Dv.RowFilter = string.Format("CONVERT(FOLIO, System.String) LIKE '*{0}*' OR ESTATUS LIKE '*{0}*'", txtBuscar.Text);

                int imagen = 0;

                this.lsvFolios.Items.Clear();

                foreach (DataRowView rowView in Dv)
                {
                    DataRow dr = rowView.Row;
                    if (dr["ESTATUS"].ToString() == "Autorizado")
                    {
                        imagen = 3;
                    }
                    else
                    {
                        imagen = 0;
                    }

                    this.lsvFolios.Items.Add(dr["FOLIO"].ToString() + "," + dr["ESTATUS"].ToString(), dr["FOLIO"].ToString() + "\n" + dr["ESTATUS"].ToString(), imagen);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Borrar los registros de la grid de estilos seleccionado "
        private void EliminaRegistros()
        {
            dgvCPSeleccionadas.Rows.Clear();
        }

        protected void eliminaPorRegistro()
        {
            Int32 rowDelete = this.dgvCPSeleccionadas.Rows.GetFirstRow(DataGridViewElementStates.Selected);

            if (rowDelete > -1)
            {
                this.dgvCPSeleccionadas.Rows.RemoveAt(rowDelete);
            }
        }
        #endregion

        #region " Evento txtBuscarCP para filtrar lo que contiene el grid "
        private void txtBuscarCP_TextChanged(object sender, EventArgs e)
        {
            filtraPreautorizados();
        }
        #endregion

        #region " Evento que selecciona los folio  "
        private void lsvFolios_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void lsvFolios_Click(object sender, EventArgs e)
        {
            if (this.pnlActualizar.Visible == true)
                this.pnlActualizar.Visible = false;

            //Recuperar el folio
            item = this.lsvFolios.SelectedItems[0].Name.Split(',');
            gridDetalleFolio(item[0]);
            dgvDetalleFolios.ClearSelection();
            limpialCambioPrecio();


            if (item[1] == "Autorizado" || item[1] == "Vencido")
            {
                this.btnMarcarDetalle.Enabled = false;
                this.btnAutorizar.Enabled = false;
                this.btnLiberar.Enabled = false;
            }
            else
            {
                if (segAutorizar[0] == true)
                {
                    this.btnAutorizar.Enabled = true;
                }

                if (segAutorizar[2] == true)
                {
                    this.btnLiberar.Enabled = true;
                }

                this.btnMarcarDetalle.Enabled = true;
            }

        }
        #endregion

        #region " llena el detalle del grid por folio seleccionado "
        protected void gridDetalleFolio(string folio)
        {
            this.dgvDetalleFolios.DataSource = Negocio.CambioPrecio.CambioPrecio.CargaDetalleFolio(folio);

            #region " formato a la grid de Estilos Preautorizados "
            //Fuente
            this.dgvDetalleFolios.Columns[0].Frozen = true;
            this.dgvDetalleFolios.Columns["FOLIO"].Frozen = true;
            this.dgvDetalleFolios.Columns["FOLIO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del FOLIO  
            this.dgvDetalleFolios.Columns["FOLIO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.dgvDetalleFolios.Columns["IDPROV"].Frozen = true;
            this.dgvDetalleFolios.Columns["IDPROV"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del Proveedor  
            this.dgvDetalleFolios.Columns["IDPROV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.dgvDetalleFolios.Columns["PROVEEDOR"].Frozen = true;
            this.dgvDetalleFolios.Columns["PROVEEDOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del Proveedor
            this.dgvDetalleFolios.Columns["PROVEEDOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            this.dgvDetalleFolios.Columns["IDESTILO"].Frozen = true;
            this.dgvDetalleFolios.Columns["IDESTILO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del Estilo
            this.dgvDetalleFolios.Columns["IDESTILO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            this.dgvDetalleFolios.Columns["ESTILO"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// Nombre del Estilo
            this.dgvDetalleFolios.Columns["ESTILO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            this.dgvDetalleFolios.Columns["IDCOMPRADOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);// # del COMPARADOR
            this.dgvDetalleFolios.Columns["IDCOMPRADOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // # del COMPARADOR

            this.dgvDetalleFolios.Columns["COMPRADOR"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//  COMPARADOR
            this.dgvDetalleFolios.Columns["COMPRADOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft; //  COMPARADOR

            this.dgvDetalleFolios.Columns["ONHAND"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Inventario
            this.dgvDetalleFolios.Columns["CSTOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Costo del Estilo Original
            this.dgvDetalleFolios.Columns["PRCOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;  // Precio del Estilo Original
            this.dgvDetalleFolios.Columns["MAROR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Margen del Estilo  Original ((PRECIO/COSTO)-1)*100

            this.dgvDetalleFolios.Columns["CSTAC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Costo del Estilo ACTUAL
            this.dgvDetalleFolios.Columns["PRCAC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;  // Precio del Estilo ACTUAL
            this.dgvDetalleFolios.Columns["MARAC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Margen del Estilo ACTUAL ((PRECIO/COSTO)-1)*100

            this.dgvDetalleFolios.Columns["CSTNU"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Costo del Estilo NUEVO
            this.dgvDetalleFolios.Columns["PRCNU"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;  // Precio del Estilo NUEVO
            this.dgvDetalleFolios.Columns["MARNU"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Margen del Estilo NUEVO ((PRECIO/COSTO)-1)*100

            this.dgvDetalleFolios.Columns["PORCINCL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // % De Incremento Vs Último	
            this.dgvDetalleFolios.Columns["PORCINOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // % De Incremento Vs Original	
            this.dgvDetalleFolios.Columns["FECHAUC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; //  Fecha Ultimo Cambio
            this.dgvDetalleFolios.Columns["NOEVENTOSCST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // # de Eventos Costos
            this.dgvDetalleFolios.Columns["NOEVENTOSPRC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // # de Eventos Precio
            this.dgvDetalleFolios.Columns["NOEVENTOS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // # de Eventos 
            this.dgvDetalleFolios.Columns["ESTATUS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // Estatus
            this.dgvDetalleFolios.Columns["TEMP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; // Estatus

            this.dgvDetalleFolios.Columns["ONHAND"].DefaultCellStyle.Format = "###,###,###,###0";
            this.dgvDetalleFolios.Columns["PRCOR"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["CSTOR"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["MAROR"].DefaultCellStyle.Format = "0.00\\%";
            this.dgvDetalleFolios.Columns["PRCAC"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["CSTAC"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["MARAC"].DefaultCellStyle.Format = "0.00\\%";
            this.dgvDetalleFolios.Columns["PRCNU"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["CSTNU"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetalleFolios.Columns["MARNU"].DefaultCellStyle.Format = "0.00\\%";
            this.dgvDetalleFolios.Columns["PORCINCL"].DefaultCellStyle.Format = "0.00\\%";
            this.dgvDetalleFolios.Columns["PORCINOR"].DefaultCellStyle.Format = "0.00\\%";

            this.dgvDetalleFolios.Columns["IDMARCA"].Visible = false;
            this.dgvDetalleFolios.Columns["MARCA"].DefaultCellStyle.Font = new Font("Tahoma", 8, FontStyle.Bold);//Nombre de la marca
            this.dgvDetalleFolios.Columns["MARCA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //Título de los encabezados
            this.dgvDetalleFolios.Columns["FOLIO"].HeaderText = "No Folio";
            this.dgvDetalleFolios.Columns["IDPROV"].HeaderText = "No Prov.";
            this.dgvDetalleFolios.Columns["PROVEEDOR"].HeaderText = "Proveedor";
            this.dgvDetalleFolios.Columns["IDESTILO"].HeaderText = "No Estilo";
            this.dgvDetalleFolios.Columns["ESTILO"].HeaderText = "Estilo";
            this.dgvDetalleFolios.Columns["ONHAND"].HeaderText = "On Hand";
            this.dgvDetalleFolios.Columns["CSTOR"].HeaderText = "Costo Original";
            this.dgvDetalleFolios.Columns["PRCOR"].HeaderText = "Precio Original";
            this.dgvDetalleFolios.Columns["MAROR"].HeaderText = "Margen Original";
            this.dgvDetalleFolios.Columns["CSTAC"].HeaderText = "Costo Actual";
            this.dgvDetalleFolios.Columns["PRCAC"].HeaderText = "Precio Actual";
            this.dgvDetalleFolios.Columns["MARAC"].HeaderText = "Margen Actual";
            this.dgvDetalleFolios.Columns["CSTNU"].HeaderText = "Costo Nuevo";
            this.dgvDetalleFolios.Columns["PRCNU"].HeaderText = "Precio Nuevo";
            this.dgvDetalleFolios.Columns["MARNU"].HeaderText = "Margen Nuevo";
            this.dgvDetalleFolios.Columns["PORCINCL"].HeaderText = "% De Incremento\n Vs Último";
            this.dgvDetalleFolios.Columns["PORCINOR"].HeaderText = "% De Incremento\n Vs Original	";
            this.dgvDetalleFolios.Columns["FECHAUC"].HeaderText = "Fecha Ultimo\n Cambio";
            this.dgvDetalleFolios.Columns["NOEVENTOSCST"].HeaderText = "No Eventos Costo";
            this.dgvDetalleFolios.Columns["NOEVENTOSPRC"].HeaderText = "No Eventos Precio";
            this.dgvDetalleFolios.Columns["NOEVENTOS"].HeaderText = "No Eventos";
            this.dgvDetalleFolios.Columns["ESTATUS"].HeaderText = "Estatus";
            this.dgvDetalleFolios.Columns["MARCA"].HeaderText = "Marca";
            this.dgvDetalleFolios.Columns["TEMP"].HeaderText = "Temporada";
            this.dgvDetalleFolios.Columns["IDCOMPRADOR"].HeaderText = "No Compdor.";
            this.dgvDetalleFolios.Columns["COMPRADOR"].HeaderText = "Comprador";

            ////Ancho
            this.dgvDetalleFolios.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["FOLIO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["IDPROV"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["PROVEEDOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["IDESTILO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["ESTILO"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["ONHAND"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["CSTOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["PRCOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["MAROR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["CSTAC"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["PRCAC"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["MARAC"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["CSTNU"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["PRCNU"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["MARNU"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["PORCINCL"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["PORCINOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["FECHAUC"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["NOEVENTOSCST"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["NOEVENTOSPRC"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["NOEVENTOS"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["ESTATUS"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            this.dgvDetalleFolios.Columns["MARCA"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["TEMP"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["IDCOMPRADOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetalleFolios.Columns["COMPRADOR"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            #endregion

            if (item[1] == "Autorizados" || item[1] == "Vencido")
            {
                this.btnMarcarDetalle.Enabled = false;
                this.btnAutorizar.Enabled = false;
                this.btnLiberar.Enabled = false;
            }
            else
            {
                this.btnMarcarDetalle.Enabled = true;
                this.btnAutorizar.Enabled = true;
                this.btnLiberar.Enabled = true;
            }
            if (MmsWin.Front.Utilerias.VarTem.tmpUser != "COMRRG" && MmsWin.Front.Utilerias.VarTem.tmpUser != "CPRJGC" && MmsWin.Front.Utilerias.VarTem.tmpUser != "PGMCGC")
            {
                this.btnAutorizar.Enabled = false;
                usuariCap = MmsWin.Front.Utilerias.VarTem.tmpUser;
            }
        }
        #endregion

        #region " Evento txtBuscar para filtrar lo que contiene el List de los folios "
        private void txtBuscar_TextChanged(object sender, EventArgs e)
        {
            if (this.pnlActualizar.Visible == true)
                this.pnlActualizar.Visible = false;

            limpialCambioPrecio();
            dgvDetalleFolios.ClearSelection();
            filtraFolios();
        }
        #endregion

        #region " Evento del Grid del detalle de folio que cambiara elprecio doubleClic "
        private void dgvDetalleFolios_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex >= 0 && e.RowIndex >= 0)
                {
                    limpialCambioPrecio();

                    if (dgvDetalleFolios.Rows[e.RowIndex].Cells["ESTATUS"].Value.ToString()[0] == 'A')
                    {
                        MessageBox.Show("El Folio " + dgvDetalleFolios.Rows[e.RowIndex].Cells["FOLIO"].Value.ToString() + " ya fue autorizado.\n ! Los folios autorizados no pueden cambiar los precios ¡", "Cambio de Precio", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        string idMar = dgvDetalleFolios.Rows[e.RowIndex].Cells["IDMARCA"].Value.ToString().Trim();

                        precioPermitido = MmsWin.Negocio.CambioPrecio.CambioPrecio.GetInstance().obtenMargenPrecio(idMar);

                        DataTable redondeos = MmsWin.Negocio.CambioPrecio.CambioPrecio.GetInstance().obtenRedondeoPre(idMar);

                        int cont = 0;
                        foreach (DataRow row in redondeos.Rows)
                        {
                            cont++;
                            if (cont == 1)
                            {
                                redonP0 = int.Parse(row["PINI"].ToString());
                                redonP1 = int.Parse(row["PFIN"].ToString());
                                limite1 = row["PORCE"].ToString();
                                multiplo1 = int.Parse(row["REDONDEO"].ToString());
                            }
                            if (cont == 2)
                            {
                                redonP01 = int.Parse(row["PINI"].ToString());
                                redonP2 = int.Parse(row["PFIN"].ToString());
                                limite2 = row["PORCE"].ToString();
                                multiplo2 = int.Parse(row["REDONDEO"].ToString());
                            }
                            if (cont == 3)
                            {
                                redonP02 = int.Parse(row["PINI"].ToString());
                                redonP3 = int.Parse(row["PFIN"].ToString());
                                limite3 = row["PORCE"].ToString();
                                multiplo3 = int.Parse(row["REDONDEO"].ToString());
                            }
                        }

                        cont = 0;

                        this.lblMarcaDesc.Text = dgvDetalleFolios.Rows[e.RowIndex].Cells["MARCA"].Value.ToString().Trim();
                        this.lblFolioDesc.Text = dgvDetalleFolios.Rows[e.RowIndex].Cells["FOLIO"].Value.ToString().Trim();
                        this.lblIdProv.Text = dgvDetalleFolios.Rows[e.RowIndex].Cells["IDPROV"].Value.ToString().Trim();
                        this.lblProvDesc.Text = dgvDetalleFolios.Rows[e.RowIndex].Cells["PROVEEDOR"].Value.ToString();
                        this.lblIdEstilo.Text = dgvDetalleFolios.Rows[e.RowIndex].Cells["IDESTILO"].Value.ToString().Trim();
                        this.lblEstiloDesc.Text = dgvDetalleFolios.Rows[e.RowIndex].Cells["ESTILO"].Value.ToString();
                        this.lblIdComp.Text = dgvDetalleFolios.Rows[e.RowIndex].Cells["IDCOMPRADOR"].Value.ToString().Trim();
                        this.lblComDesc.Text = dgvDetalleFolios.Rows[e.RowIndex].Cells["COMPRADOR"].Value.ToString();
                        this.lblTemporada.Text = dgvDetalleFolios.Rows[e.RowIndex].Cells["TEMP"].Value.ToString();
                        this.lblTCA.Text = string.Format("{0:###,###,###,###0.00}", dgvDetalleFolios.Rows[e.RowIndex].Cells["CSTAC"].Value);
                        this.lblTPA.Text = string.Format("{0:###,###,###,###0.00}", dgvDetalleFolios.Rows[e.RowIndex].Cells["PRCAC"].Value);
                        this.lblTMA.Text = string.Format("{0:0.00\\%}", dgvDetalleFolios.Rows[e.RowIndex].Cells["MARAC"].Value);

                        gridDetalleFolioBitacira(this.lblFolioDesc.Text, this.lblIdProv.Text, this.lblIdEstilo.Text, idMar, this.lblTemporada.Text);
                        dgvDetallePorFolio.ClearSelection();
                        this.pnlActualizar.Visible = true;
                    }
                }
                else
                {
                    this.pnlActualizar.Visible = false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " llena el detalle del grid por folio seleccionado "
        protected void gridDetalleFolioBitacira(string Folio, string proveedor, string estilo, string idMarc, string temp)
        {
            this.dgvDetallePorFolio.DataSource = Negocio.CambioPrecio.CambioPrecio.cargaDetallePorFolio(Folio, proveedor, estilo, idMarc, temp);

            #region " formato a la grid de Estilos ya para el cambio de precio bitacora de cuantas veces a cambiado el precio "
            //Fuente
            this.dgvDetallePorFolio.Columns["FECHACAM"].Frozen = true;
            this.dgvDetallePorFolio.Columns["FECHACAM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter; //  Fecha Ultimo Cambio

            this.dgvDetallePorFolio.Columns["CSTCAM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Costo del Estilo cambio
            this.dgvDetallePorFolio.Columns["PRCCAM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;  // Precio del Estilo cambio
            this.dgvDetallePorFolio.Columns["MARCAM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; // Margen del Estilo cambio ((PRECIO/COSTO)-1)*100

            this.dgvDetallePorFolio.Columns["PRCCAM"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetallePorFolio.Columns["CSTCAM"].DefaultCellStyle.Format = "###,###,###,###0.00";
            this.dgvDetallePorFolio.Columns["MARCAM"].DefaultCellStyle.Format = "0.00\\%";

            //Título de los encabezados

            this.dgvDetallePorFolio.Columns["CSTCAM"].HeaderText = "Costo Cambio";
            this.dgvDetallePorFolio.Columns["PRCCAM"].HeaderText = "Precio Cambio";
            this.dgvDetallePorFolio.Columns["MARCAM"].HeaderText = "Margen Cambio";
            this.dgvDetallePorFolio.Columns["FECHACAM"].HeaderText = "Fecha \n Cambio";


            ////Ancho
            this.dgvDetallePorFolio.Columns["CSTCAM"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetallePorFolio.Columns["PRCCAM"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetallePorFolio.Columns["MARCAM"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dgvDetallePorFolio.Columns["FECHACAM"].AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;

            #endregion
        }
        #endregion

        #region " eventos de los textbox que van a actualizar el precio y formula "
        private void txtCosto_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double iva = 1.16;
                this.lblError.Text = string.Empty;
                this.lblTotalMargen.Text = string.Empty;
                Decimal margennuevo = 0;
                margennuevo = this.txtPrecio.Text == "" && this.txtCosto.Text == "" ? 0 :
                                       this.txtPrecio.Text == "" && this.txtCosto.Text != "" ? 0 :
                                        this.txtPrecio.Text != "" && this.txtCosto.Text == "" ? 0 :
                                        (1 - ((Convert.ToDecimal(this.txtCosto.Text) * Convert.ToDecimal(iva)) / Convert.ToDecimal(this.txtPrecio.Text))) * 100;

                this.lblTotalMargen.Text = string.Format("{0:0.00\\%}", margennuevo);

                if (margennuevo <= precioPermitido)
                {
                    this.lblError.Text = "El margen debe ser superior al " + Convert.ToDouble(precioPermitido) + "%.";
                    this.lblTotalMargen.ForeColor = Color.Red;
                    this.btnGuardarCambios.Enabled = false;
                }
                else if (this.txtPrecio.Text.Contains(".") && margennuevo >= precioPermitido)
                {
                    //if (txtPrecio.Text.Split('.')[1].Trim() == "99")
                    //{
                    bool precio = false;
                    string msg = string.Empty;
                    string[] wlimite = new string[10];

                    if (Convert.ToDecimal(txtPrecio.Text) >= redonP0 && Convert.ToDecimal(txtPrecio.Text) <= redonP1)
                    {
                        msg = "Del precio " + Math.Round(Convert.ToDecimal(Convert.ToDouble(redonP0) - 0.01), 2).ToString() + " a el precio " + Math.Round(Convert.ToDecimal(Convert.ToDouble(redonP1) - 0.01), 2).ToString() + ", son con multiplos de " + multiplo1 + ".";

                        if (limite1.Contains("|"))
                            wlimite = limite1.Split('|');
                        else
                            wlimite[0] = limite1;

                        String var = txtPrecio.Text;
                        int tamanio = var.Length;
                        String varValida = var.Substring((tamanio - 3), 3);

                        for (int i = 0; i < wlimite.Length; i++)
                        {
                            if (wlimite[i] == varValida)
                            {
                                precio = true;//multiplo(Convert.ToDecimal(txtPrecio.Text), multiplo1);
                                break;
                            }
                            else
                                precio = false;
                        }
                    }
                    else if (Convert.ToDecimal(txtPrecio.Text) > redonP01 && Convert.ToDecimal(txtPrecio.Text) <= redonP2)
                    {
                        msg = "Del precio " + Math.Round(Convert.ToDecimal(Convert.ToDouble(redonP01) - 0.01), 2).ToString() + " a el precio " + Math.Round(Convert.ToDecimal(Convert.ToDouble(redonP2) - 0.01), 2).ToString() + ", son con multiplos de " + multiplo2 + ".";

                        if (limite2.Contains("|"))
                            wlimite = limite2.Split('|');
                        else
                            wlimite[0] = limite2;

                        String var = txtPrecio.Text;
                        int tamanio = var.Length;
                        String varValida = var.Substring((tamanio - 4), 4);

                        for (int i = 0; i < wlimite.Length; i++)
                        {
                            if (wlimite[i] == varValida)
                            {
                                precio = true;
                                break;
                            }
                            else
                                precio = false;
                        }
                        // precio = multiplo(Convert.ToDecimal(txtPrecio.Text), multiplo2);
                    }
                    else if (Convert.ToDecimal(txtPrecio.Text) > redonP02 && Convert.ToDecimal(txtPrecio.Text) <= redonP3)
                    {
                        msg = "Del precio " + Math.Round(Convert.ToDecimal(Convert.ToDouble(redonP02) - 0.01), 2).ToString() + ", son con multiplos de " + multiplo3 + ".";

                        if (limite3.Contains("|"))
                            wlimite = limite3.Split('|');
                        else
                            wlimite[0] = limite3;

                        String var = txtPrecio.Text;
                        int tamanio = var.Length;
                        String varValida = var.Substring((tamanio - 4), 4);

                        for (int i = 0; i < wlimite.Length; i++)
                        {
                            if (wlimite[i] == varValida)
                            {
                                precio = true;
                                break;
                            }
                            else
                                precio = false;
                        }
                        //precio = multiplo(Convert.ToDecimal(txtPrecio.Text), multiplo3);
                    }

                    if (precio == true)
                    {
                        this.lblError.Text = string.Empty;
                        this.btnGuardarCambios.Enabled = true;
                        this.lblTotalMargen.ForeColor = Color.Black;
                    }
                    else
                    {
                        this.lblError.Text = msg;
                        this.lblTotalMargen.ForeColor = Color.Red;
                        this.btnGuardarCambios.Enabled = false;
                    }
                    //}
                    //else
                    //{
                    //    this.lblError.Text = "El precio contiene el valor que es permitido, tiene que terminar en .99";
                    //    this.lblTotalMargen.ForeColor = Color.Red;
                    //    this.btnGuardarCambios.Enabled = false;
                    //}
                }
                else
                {
                    this.lblError.Text = "El margen debe ser superior al " + Convert.ToDouble(precioPermitido) + "%, y tiene que terminar en " + comparaFinalPre() + ".";
                    this.lblTotalMargen.ForeColor = Color.Red;
                    this.btnGuardarCambios.Enabled = false;
                }
            }
            catch
            { }
        }

        private void txtPrecio_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double iva = 1.16;
                this.lblError.Text = string.Empty;
                this.lblTotalMargen.Text = string.Empty;
                Decimal margennuevo = 0;
                margennuevo = this.txtPrecio.Text == "" && this.txtCosto.Text == "" ? 0 :
                                       this.txtPrecio.Text == "" && this.txtCosto.Text != "" ? 0 :
                                        this.txtPrecio.Text != "" && this.txtCosto.Text == "" ? 0 :
                                       (1 - ((Convert.ToDecimal(this.txtCosto.Text) * Convert.ToDecimal(iva)) / Convert.ToDecimal(this.txtPrecio.Text))) * 100;

                this.lblTotalMargen.Text = string.Format("{0:0.00\\%}", margennuevo);

                if (margennuevo <= precioPermitido)
                {
                    this.lblError.Text = "El margen debe ser superior al " + Convert.ToDouble(precioPermitido) + "%.";
                    this.lblTotalMargen.ForeColor = Color.Red;
                    this.btnGuardarCambios.Enabled = false;
                }
                else if (this.txtPrecio.Text.Contains(".") && margennuevo >= precioPermitido)
                {
                    //if (txtPrecio.Text.Split('.')[1].Trim() == "99")
                    //{
                    bool precio = false;
                    string msg = string.Empty;
                    string[] wlimite = new string[10];

                    if (Convert.ToDecimal(txtPrecio.Text) >= redonP0 && Convert.ToDecimal(txtPrecio.Text) <= redonP1)
                    {
                        msg = "Del precio " + Math.Round(Convert.ToDecimal(Convert.ToDouble(redonP0) - 0.01), 2).ToString() + " a el precio " + Math.Round(Convert.ToDecimal(Convert.ToDouble(redonP1) - 0.01), 2).ToString() + ", son con multiplos de " + multiplo1 + ".";

                        if (limite1.Contains("|"))
                            wlimite = limite1.Split('|');
                        else
                            wlimite[0] = limite1;

                        String var = txtPrecio.Text;
                        int tamanio = var.Length;
                        String varValida = var.Substring((tamanio - 3), 3);

                        for (int i = 0; i < wlimite.Length; i++)
                        {
                            if (wlimite[i] == varValida)
                            {
                                precio = true;//multiplo(Convert.ToDecimal(txtPrecio.Text), multiplo1);
                                break;
                            }
                            else
                                precio = false;
                        }
                    }
                    else if (Convert.ToDecimal(txtPrecio.Text) > redonP01 && Convert.ToDecimal(txtPrecio.Text) <= redonP2)
                    {
                        msg = "Del precio " + Math.Round(Convert.ToDecimal(Convert.ToDouble(redonP01) - 0.01), 2).ToString() + " a el precio " + Math.Round(Convert.ToDecimal(Convert.ToDouble(redonP2) - 0.01), 2).ToString() + ", son con multiplos de " + multiplo2 + ".";

                        if (limite2.Contains("|"))
                            wlimite = limite2.Split('|');
                        else
                            wlimite[0] = limite2;

                        String var = txtPrecio.Text;
                        int tamanio = var.Length;
                        String varValida = var.Substring((tamanio - 4), 4);

                        for (int i = 0; i < wlimite.Length; i++)
                        {
                            if (wlimite[i] == varValida)
                            {
                                precio = true;
                                break;
                            }
                            else
                                precio = false;
                        }
                        // precio = multiplo(Convert.ToDecimal(txtPrecio.Text), multiplo2);
                    }
                    else if (Convert.ToDecimal(txtPrecio.Text) > redonP02 && Convert.ToDecimal(txtPrecio.Text) <= redonP3)
                    {
                        msg = "Del precio " + Math.Round(Convert.ToDecimal(Convert.ToDouble(redonP02) - 0.01), 2).ToString() + ", son con multiplos de " + multiplo3 + ".";

                        if (limite3.Contains("|"))
                            wlimite = limite3.Split('|');
                        else
                            wlimite[0] = limite3;

                        String var = txtPrecio.Text;
                        int tamanio = var.Length;
                        String varValida = var.Substring((tamanio - 4), 4);

                        for (int i = 0; i < wlimite.Length; i++)
                        {
                            if (wlimite[i] == varValida)
                            {
                                precio = true;
                                break;
                            }
                            else
                                precio = false;
                        }
                        //precio = multiplo(Convert.ToDecimal(txtPrecio.Text), multiplo3);
                    }

                    if (precio == true)
                    {
                        this.lblError.Text = string.Empty;
                        this.btnGuardarCambios.Enabled = true;
                        this.lblTotalMargen.ForeColor = Color.Black;
                    }
                    else
                    {
                        this.lblError.Text = msg;
                        this.lblTotalMargen.ForeColor = Color.Red;
                        this.btnGuardarCambios.Enabled = false;
                    }
                    //}
                    //else
                    //{
                    //    this.lblError.Text = "El precio contiene el valor que es permitido, tiene que terminar en .99";
                    //    this.lblTotalMargen.ForeColor = Color.Red;
                    //    this.btnGuardarCambios.Enabled = false;
                    //}
                }
                else
                {
                    this.lblError.Text = "El margen debe ser superior al " + Convert.ToDouble(precioPermitido) + "%, y tiene que terminar en " + comparaFinalPre() + ".";
                    this.lblTotalMargen.ForeColor = Color.Red;
                    this.btnGuardarCambios.Enabled = false;
                }
            }
            catch
            { }
        }

        private string comparaFinalPre()
        {
            string regresa = string.Empty;
            string msg2 = string.Empty;

            if (Convert.ToDecimal(txtPrecio.Text) >= redonP0 && Convert.ToDecimal(txtPrecio.Text) <= redonP1)
                msg2 = limite1;
            else if (Convert.ToDecimal(txtPrecio.Text) > redonP01 && Convert.ToDecimal(txtPrecio.Text) <= redonP2)
                msg2 = limite2;
            else if (Convert.ToDecimal(txtPrecio.Text) > redonP02 && Convert.ToDecimal(txtPrecio.Text) <= redonP3)
                msg2 = limite3;

            regresa = msg2;
            return regresa;
        }

        private bool multiplo(decimal numMul, int multiplo)
        {
            int recnum = Convert.ToInt32(Math.Round(Convert.ToDecimal(Convert.ToDouble(numMul) + 0.01), 2));
            //recnum = Math.Round(Convert.ToDecimal(Convert.ToDouble(numMul) - 0.01), 2).ToString();
            bool multi = false;
            if (recnum % multiplo == 0)
                multi = true;
            else
                multi = false;

            return multi;
        }

        private void txtCosto_KeyPress(object sender, KeyPressEventArgs e)
        {
            // numeros 0-9, barra de escpacio, y un . para decimal
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }
            if (e.KeyChar == 46)
            {
                if ((sender as TextBox).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }

        private void txtPrecio_KeyPress(object sender, KeyPressEventArgs e)
        {
            // numeros 0-9, barra de escpacio, y un . para decimal
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }
            if (e.KeyChar == 46)
            {
                if ((sender as TextBox).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }
        #endregion

        #region  "  Evento de Tab manipula las pestañas para la visivilidad de los controles del cambio de precio "
        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            this.pnlActualizar.Visible = false;
            dgvDetalleFolios.ClearSelection();
            limpialCambioPrecio();
        }
        #endregion

        #region " evento que muestra el filtro de Pendientes DropdownList   "
        private void Event_cbo_SelectIndexChanged(object sender, EventArgs e)
        {
            if (this.pnlActualizar.Visible == true)
                this.pnlActualizar.Visible = false;

            this.dgvDetalleFolios.DataSource = null;

            if (sender == this.cboEstatus)
            {
                CargaFolios();
                if (this.cboEstatus.SelectedItem == "Autorizados")
                {
                    this.btnImprimir.Enabled = false;
                }
                else
                { this.btnImprimir.Enabled = true; }
            }
        }
        #endregion

        #region " Evento txtBuscarTemporada para filtrar lo que contiene el grid por pura temporada "
        private void txtTemporada_TextChanged(object sender, EventArgs e)
        {
            filtraTemporafa();
        }

        private void filtraTemporafa()
        {
            //if (txtTemporada.Text == string.Empty)
            //    bsFiltroPre.RemoveFilter();
            //else
            //    bsFiltroPre.Filter = string.Format("TEMP LIKE '*{0}*'", txtTemporada.Text);
        }
        #endregion

        #region " Selecciona y limpia Comprador "
        private void cbCompradores_SelectedIndexChanged(object sender, EventArgs e)
        {
            limpiaFiltros();
            ComboBox cmbComprador = (ComboBox)sender;
            idComCombo = cmbComprador.SelectedValue.ToString();
            if (idComCombo != "[999, Todos]")
            {
                cargaGrid();
                estilosGridView();
            }
        }

        private void limpiaFiltros()
        {
            tbProveedor.Text = string.Empty;
            tbNombre.Text = string.Empty;
            tbEstilo.Text = string.Empty;
            tbDescripcion.Text = string.Empty;
        }
        #endregion

        #region " Eventos para filtrare el grid con los parametros de proveeedores y estilos"
        private void tbProveedor_TextChanged(object sender, EventArgs e)
        {
            filtraPlazos();
        }

        private void tbNombre_TextChanged(object sender, EventArgs e)
        {
            filtraPlazos();
        }

        private void tbEstilo_TextChanged(object sender, EventArgs e)
        {
            filtraPlazos();
        }

        private void tbDescripcion_TextChanged(object sender, EventArgs e)
        {
            filtraPlazos();
        }
        #endregion

        #region " Filtra los registros de la grid de Plazos de ejecución de devoluciones, bonificaciones y rebajas. de los textBox "
        private void filtraPlazos()
        {
            try
            {
                if (tbProveedor.Text == string.Empty && tbNombre.Text == string.Empty && tbEstilo.Text == string.Empty && tbDescripcion.Text == string.Empty)
                {
                    bsFiltroPre.RemoveFilter();
                    return;
                }

                int cantidad = 0;

                if (tbProveedor.Text != string.Empty)
                    cantidad++;

                if (tbNombre.Text != string.Empty)
                    cantidad++;

                if (tbEstilo.Text != string.Empty)
                    cantidad++;

                if (tbDescripcion.Text != string.Empty)
                    cantidad++;


                string[] filtro = new string[cantidad];

                int numArrelgo = 0;

                if (tbProveedor.Text != string.Empty)
                {
                    filtro[numArrelgo] = string.Format("CONVERT(IDPROV, System.String) LIKE '*{0}*'", tbProveedor.Text);

                    numArrelgo++;
                }
                if (tbNombre.Text != string.Empty)
                {
                    filtro[numArrelgo] = string.Format("PROVEEDOR LIKE '*{0}*' ", tbNombre.Text);

                    numArrelgo++;
                }
                if (tbEstilo.Text != string.Empty)
                {
                    filtro[numArrelgo] = string.Format("CONVERT(IDESTILO, System.String)   LIKE '*{0}*' ", tbEstilo.Text);

                    numArrelgo++;
                }
                if (tbDescripcion.Text != string.Empty)
                {
                    filtro[numArrelgo] = string.Format("ESTILO LIKE '*{0}*'", tbDescripcion.Text);

                    numArrelgo++;
                }

                numArrelgo = 0;

                string resulFiltro = string.Empty;
                for (int i = 0; i <= filtro.Length - 1; i++)
                {
                    resulFiltro += filtro[i].ToString() + " AND ";
                }

                resulFiltro = resulFiltro.Remove(resulFiltro.Length - 4);

                bsFiltroPre.Filter = resulFiltro;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion


        #region Seguridad
        
        private void CambioPrecio_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MmsWin.Front.Utilerias.VarTem.tmpUSRVIL == "ADMINISTRADOR")
            {
                CargaSeguridad("CambioCostoPrecio", "CambioCostoPrecio", MmsWin.Front.Utilerias.VarTem.tmpUser);
            }
        }

        /// <summary>
        /// Inserta los controles del formulario a la tabla MMSATOBJ.SAT177SCLS
        /// </summary>
        /// <param name="Aplicacion">Nombre de la aplicación</param>
        /// <param name="Modulo">Nombre del módulo</param>
        /// <param name="Usuario">Usuario que inicio sesión</param>
        /// <remarks>
        ///     Desarrollador: Gustavo de los Santos | 08/12/2016
        ///     Actualizo: Omar Cervantes  | 28/02/2017
        ///     Paso seguridad: 2
        /// </remarks>
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");

            //Definición de la estructura del DataTable
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (ToolStripItem item in tspGeneracionFormatos.Items)
            {
                DataRow toolStripControls = dtControles.NewRow();

                //Valores generales para cada renglon  
                toolStripControls["Aplicacion"] = Aplicacion;
                toolStripControls["Modulo"] = Modulo;
                toolStripControls["Usuario"] = Usuario;

                //Si el control es del tipo "ToolStripButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripComboBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripComboBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripComboBox";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripSplitButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripSplitButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripSplitButton";

                    dtControles.Rows.Add(toolStripControls);
                }



                //Si el control es del tipo "ToolStripLabel"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripTextBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripTextBox";

                    dtControles.Rows.Add(toolStripControls);
                }
            }

            foreach (ToolStripItem item in this.tspOrdenesSeleccionadas.Items)
            {
                DataRow toolStripControls = dtControles.NewRow();

                //Valores generales para cada renglon  
                toolStripControls["Aplicacion"] = Aplicacion;
                toolStripControls["Modulo"] = Modulo;
                toolStripControls["Usuario"] = Usuario;

                //Si el control es del tipo "ToolStripButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripComboBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripComboBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripComboBox";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripSplitButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripSplitButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripSplitButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripLabel"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripTextBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripTextBox";

                    dtControles.Rows.Add(toolStripControls);
                }
            }

            foreach (ToolStripItem item in this.tspConsultaAutorizadas.Items)
            {
                DataRow toolStripControls = dtControles.NewRow();

                //Valores generales para cada renglon  
                toolStripControls["Aplicacion"] = Aplicacion;
                toolStripControls["Modulo"] = Modulo;
                toolStripControls["Usuario"] = Usuario;

                //Si el control es del tipo "ToolStripButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripComboBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripComboBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripComboBox";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripSplitButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripSplitButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripSplitButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripTextBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripTextBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripTextBox";

                    dtControles.Rows.Add(toolStripControls);
                }
            }

            foreach (ToolStripItem item in this.tspAutorizadas.Items)
            {
                DataRow toolStripControls = dtControles.NewRow();

                //Valores generales para cada renglon  
                toolStripControls["Aplicacion"] = Aplicacion;
                toolStripControls["Modulo"] = Modulo;
                toolStripControls["Usuario"] = Usuario;

                //Si el control es del tipo "ToolStripButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripComboBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripComboBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripComboBox";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripSplitButton"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripSplitButton))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripSplitButton";

                    dtControles.Rows.Add(toolStripControls);
                }

                //Si el control es del tipo "ToolStripTextBox"
                if (item.GetType() == typeof(System.Windows.Forms.ToolStripTextBox))
                {
                    toolStripControls["Control"] = item.Name;
                    toolStripControls["Tipo"] = "ToolStripTextBox";

                    dtControles.Rows.Add(toolStripControls);
                }

            }

            //Guardar los controles recuperados de la pantalla.
            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        /// <summary>
        /// Recupera los niveles del perfil del usuario y aplica los permisos
        /// a los controles del formulario
        /// </summary>
        /// <param name="Aplicacion">Nombre de aplicación o pantalla</param>
        /// <param name="Modulo">Nombre del módulo</param>
        /// <param name="Usuario">ID del usuario</param>
        /// <remarks>
        ///     Desarrollador: Gustavo de los Santos | 08/12/2016
        ///     Actualizo: Omar Cervantes  | 28/02/2017
        ///     Paso seguridad: 3
        /// </remarks>
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            // Buscar el control dentro del DataTable
            DataRow[] foundRows;

            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);

            string busca = string.Empty;

            //Aplicar seguridad de los controles que no se encuentran dentro de un control 
            //contenedor
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }

            foreach (ToolStripItem item in this.tspAutorizadas.Items)
            {
                foundRows = tbSeguridad.Select("SEGCLS Like '" + item.Name + "%'");

                if (foundRows.Count() > 0)
                {
                    if (item.Name == (foundRows[0]["SEGCLS"].ToString()))
                    {
                        item.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        item.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }

            }

            foreach (ToolStripItem item in this.tspConsultaAutorizadas.Items)
            {
                foundRows = tbSeguridad.Select("SEGCLS Like '" + item.Name + "%'");

                if (foundRows.Count() > 0)
                {
                    if (item.Name == (foundRows[0]["SEGCLS"].ToString()))
                    {
                        item.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        item.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }

            }

            foreach (ToolStripItem item in this.tspGeneracionFormatos.Items)
            {
                foundRows = tbSeguridad.Select("SEGCLS Like '" + item.Name + "%'");

                if (foundRows.Count() > 0)
                {
                    if (item.Name == (foundRows[0]["SEGCLS"].ToString()))
                    {
                        item.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        item.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }

            }

            foreach (ToolStripItem item in this.tspOrdenesSeleccionadas.Items)
            {
                foundRows = tbSeguridad.Select("SEGCLS Like '" + item.Name + "%'");

                if (foundRows.Count() > 0)
                {
                    if (item.Name == (foundRows[0]["SEGCLS"].ToString()))
                    {
                        item.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        item.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }

            }

            foreach (Control X in this.Controls)
            {

                busca = X.Name;


                foundRows = tbSeguridad.Select("SEGCLS Like '" + busca + "%'");

                if (foundRows.Count() > 0)
                {
                    if (X.GetType() != typeof(ToolStrip))
                    {
                        X.Enabled = Convert.ToBoolean(foundRows[0]["SEGHAC"]);
                        X.Visible = Convert.ToBoolean(foundRows[0]["SEGVIC"]);
                    }
                }
            }

            //Recupera de la seguridad, el valor de las propiedades "Enabled" y "Visible"
            segAutorizar[0] = this.btnAutorizar.Enabled;
            segAutorizar[1] = this.btnAutorizar.Visible;

            segAutorizar[2] = this.btnLiberar.Enabled;
            segAutorizar[3] = this.btnLiberar.Visible;
        }

        /// <summary>
        /// Aplicar seguridad de los controles que no se encuentran dentro de un control 
        /// contenedor
        /// </summary>
        /// <param name="Controles">Nombre del control</param>
        /// <param name="ValHab">Valor para aplicar a "Enabled"</param>
        /// <param name="ValVis">Valor para aplicar a  "Visibkle"</param>
        /// <param name="tipo">Tipo de objeto</param>
        /// <remarks>
        ///     Desarrollador: Gustavo de los Santos | 08/12/2016
        ///     Actualizo: Omar Cervantes  | 01/03/2017
        ///     Paso seguridad: 4
        /// </remarks>
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                this.Controls[Controles].Enabled = Convert.ToBoolean(ValHab);
                this.Controls[Controles].Visible = Convert.ToBoolean(ValVis);
            }
        }



        #endregion
    }
}
