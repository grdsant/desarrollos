﻿using MmsWin.Negocio.Catalogos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class SolCamCalificacion : Form
    {
        #region " Variables Globales "

        public Entidades.Reprogramaciones eReprogramaciones = new Entidades.Reprogramaciones();

        //private static string fecharevicion = string.Empty;
        //private static string marca = string.Empty;
        //private static decimal calificacion = 0;
        private static decimal montoPermitido = 0;

        #endregion

        public SolCamCalificacion()
        {
            InitializeComponent();
        }

        #region " Page Load  "
        private void SolCamCalificacion_Load(object sender, EventArgs e)
        {
            this.cboMotivo.DataSource = Motivos.CargaMotivosDSB();
            cboMotivo.DisplayMember = "DSCMOV";
            cboMotivo.ValueMember = "MOVOID";

            this.cboMotivo.SelectedValue = "0";

            cbPagar.Checked = false;
            controlaCheck();

            this.lblMensage.Text = string.Empty;
            this.tbCalNueva.Text = string.Empty;
            this.lblCostoBonNueDesc.Text = string.Empty;
            this.lblDifBonDesc.Text = string.Empty;

            this.lblcaltificacion.Text = eReprogramaciones.strCalificacion;
            //calificacion = eReprogramaciones.decCalificacion;

            //fecharevicion = MmsWin.Front.Utilerias.VarTem.tmpFchRev;

            this.lblDescProveedor.Text = eReprogramaciones.ProveedorID;
            this.lblNombreProv.Text = eReprogramaciones.Proveedor;
            this.lblidEstilo.Text = eReprogramaciones.EstiloID;
            this.lblDescEstilo.Text = eReprogramaciones.Estilo;
            this.lblCompradorDesc.Text = eReprogramaciones.Comprador;
            this.lblOnHandDesc.Text = string.Format("{0:###,###,###,###0}", Convert.ToDecimal(eReprogramaciones.OnHand));
            this.lblCostoActDesc.Text = string.Format("{0:###,###,###,###0.00}", Convert.ToDecimal(eReprogramaciones.CostoActual));
            this.lblCostoTotDesc.Text = string.Format("{0:###,###,###,###0}", Convert.ToDecimal(eReprogramaciones.CostoTotal));
            this.lblCostoBonActDesc.Text = string.Format("{0:###,###,###,###0.00}", Convert.ToDecimal(eReprogramaciones.MontoBonificacion));
            this.lblNumProg.Text = eReprogramaciones.NoEventos;

            this.lblDescMarca.Text = eReprogramaciones.MarcaID == "10" ? "MELODY" : eReprogramaciones.MarcaID == "30" ? "MILANO" : "KALTEX";

            this.lblTemporada.Text = eReprogramaciones.Temporada;
            this.lblOCDesc.Text = eReprogramaciones.OrdenCompra;

            montoPermitido = MmsWin.Negocio.Convenio.Convenio.GetInstance().obtenMaximoCalificacion(eReprogramaciones.MarcaID);

            
        }
        #endregion

        #region " evento de cancelar que cierra el formulario "
        private void btCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        #region " guarda la calificacion modificada con los parametros correspondientes "
        private void btAceptar_Click(object sender, EventArgs e)
        {
            if (cbPagar.Checked == false)
            {
                if (string.IsNullOrEmpty(this.tbCalNueva.Text))
                    return;
            }
            else if (cbPagar.Checked == true)
            {
                if (this.cboMotivo.SelectedValue.ToString() == "0")
                {
                    MessageBox.Show("Debe seleccionar un motivo para porder guardar el cambio de calificación", "Cambio de Calificación", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }

            //string idEstilo = this.lblidEstilo.Text.Trim().ToUpper();
            //string idProv = this.lblDescProveedor.Text.Trim().ToUpper(), ordenCompra = this.lblOCDesc.Text.Trim().ToUpper();
            //string calificacion = cbPagar.Checked == true ? "0" : this.tbCalNueva.Text;
            // string    noEvento = Convert.ToString(Convert.ToInt32(this.lblNumProg.Text) + 1);
            //string estatus = "T", tipoReporte = "C", usuario = MmsWin.Front.Utilerias.VarTem.tmpUser, temp = this.lblTemporada.Text;
            decimal costoNvo = Convert.ToDecimal(this.lblCostoBonNueDesc.Text);
            decimal difNuevo = Convert.ToDecimal(this.lblDifBonDesc.Text);
            string motivo = cbPagar.Checked == true ? this.cboMotivo.SelectedValue.ToString() : "0";
            string calDirecta = cbPagar.Checked == true ? "P a g a r" : "";

            if (eReprogramaciones.NoEventos == "")
                eReprogramaciones.NoEventos = "0";


            bool ejecuta = MmsWin.Negocio.Convenio.Convenio.GetInstance().insertNuevoCambioCal(
                                eReprogramaciones.EstiloID,
                                eReprogramaciones.ProveedorID,
                                eReprogramaciones.OrdenCompra,
                                eReprogramaciones.MarcaID,
                                (cbPagar.Checked == true ? "0" : this.tbCalNueva.Text), //Calificación
                                "T", //Estatus 
                                Convert.ToString(Convert.ToInt32(eReprogramaciones.NoEventos) + 1),
                                eReprogramaciones.intFechaRevision,
                                eReprogramaciones.Usuario,
                                eReprogramaciones.Temporada,
                                "C", //Tipo de reporte 
                                costoNvo,
                                difNuevo,
                                motivo,
                                calDirecta);

            if (ejecuta == true)
            {
                MessageBox.Show("El porcentaje de calificación se guardo correctamente.\n !Recuerda generar tu formato para firma.¡", "Cambio de Calificación", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.Close();
            }
            else
            {
                MessageBox.Show("El porcentaje de calificación no fue generada, por favor reintentar, \n si el problema perciste comucate a soporte.", "Cambio de Calificación", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        #endregion

        #region " eventos de textbox que cambiaran la calificacion "
        private void tbCalNueva_TextChanged(object sender, EventArgs e)
        {
            try
            {
                this.lblMensage.Text = string.Empty;
                this.lblCostoBonNueDesc.Text = string.Empty;
                this.lblDifBonDesc.Text = string.Empty;
                decimal porMaximo = 0, porcentaPermitido = 0, permitido = 0, valorProce = 0;

                //if (calificacion == 0)
                //    calificacion = Convert.ToDecimal(this.lblcaltificacion.Text.Split('%')[0]);

                porcentaPermitido = Convert.ToDecimal(this.tbCalNueva.Text.PadLeft(4, '0'));
                permitido = eReprogramaciones.decCalificacion - Convert.ToDecimal(this.tbCalNueva.Text.PadLeft(4, '0'));
                porMaximo = eReprogramaciones.decCalificacion - montoPermitido;

                valorProce = Convert.ToDecimal(this.tbCalNueva.Text);
                this.lblCostoBonNueDesc.Text = string.Format("{0:0,0.0}", ((Convert.ToDecimal(this.lblCostoTotDesc.Text) * valorProce)) / 100);

                this.lblDifBonDesc.Text = string.Format("{0:0,0.0}", Convert.ToDecimal(this.lblCostoBonActDesc.Text) - Convert.ToDecimal(this.lblCostoBonNueDesc.Text));

                //if (Convert.ToDecimal(this.tbCalNueva.Text) > calificacion)
                //{
                //    lblMensage.ForeColor = Color.Red;
                //    lblMensage.Text = "Tu Porcentaje de calificacion " + string.Format("{0:0\\%}", Convert.ToDecimal(this.tbCalNueva.Text)) + ", es mayor al actual: ";
                //    btAceptar.Enabled = false;
                //}
                //else 
                if (Convert.ToDecimal(this.tbCalNueva.Text) < 0 || (porMaximo > porcentaPermitido && eReprogramaciones.decCalificacion >= porcentaPermitido))
                {
                    lblMensage.ForeColor = Color.Red;
                    lblMensage.Text = "El porcentaje de calificación debe ser mayor al 0% y no menor al " + string.Format("{0:0\\%}", montoPermitido) + " \n del porcentaje actual de la bonificación.";
                    btAceptar.Enabled = false;
                }
                else
                    if (Convert.ToDecimal(this.tbCalNueva.Text) >= 0)
                    {
                        btAceptar.Enabled = true;
                        lblMensage.ForeColor = Color.Black;
                        lblMensage.Text = string.Empty;
                    }
            }
            catch
            { }
        }

        private void tbCalNueva_KeyPress(object sender, KeyPressEventArgs e)
        {
            // numeros 0-9, barra espaciadora, y un . para decimal
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }
            if (e.KeyChar == 46)
            {
                if ((sender as TextBox).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }
        #endregion

        #region " Evento del check para saber si se envia a pagar directo  "
        private void cbPagar_CheckedChanged(object sender, EventArgs e)
        {
            this.cboMotivo.SelectedValue = "0";
            controlaCheck();
        }

        private void controlaCheck()
        {
            if (cbPagar.Checked == true)
            {
                this.lblMotivo.Visible = true;
                this.cboMotivo.Visible = true;
                this.lblMensage.Text = string.Empty;
                this.lblDifBonDesc.Text = "0";
                this.lblCostoBonNueDesc.Text = "0";
                this.tbCalNueva.Text = string.Empty;
                this.tbCalNueva.Enabled = false;
            }
            else
            {
                this.lblMotivo.Visible = false;
                this.cboMotivo.Visible = false;
                this.tbCalNueva.Enabled = true;
            }
        }
        #endregion
    }
}
