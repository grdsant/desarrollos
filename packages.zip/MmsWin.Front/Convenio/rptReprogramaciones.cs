﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class rptReprogramaciones : Form
    {
        /// <summary>
        /// Recibe el número de folio del reporte seleccionado para imprimir.
        /// </summary>
        public int Folio { get; set; }

        public rptReprogramaciones()
        {
            InitializeComponent();
        }

        private void rptReprogramaciones_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dsSAT177rpt.SAT177REP' 
            //Puede moverla o quitarla según sea necesario.
            this.SAT177REPTableAdapter.Fill(this.dsSAT177REP.SAT177REP,Folio);

            this.reportViewer1.RefreshReport();
        }
    }
}
