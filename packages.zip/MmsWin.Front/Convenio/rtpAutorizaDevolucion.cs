﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class rtpAutorizaDevolucion : Form
    {
        public int Folio { get; set; }
        public rtpAutorizaDevolucion()
        {
            InitializeComponent();
        }

        private void rtpAutorizaDevolucion_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'sAT177CDP1.SAT177CDP1' Puede moverla o quitarla según sea necesario.
            this.sAT177CDP1TableAdapter.Fill(this.sAT177CDP1._SAT177CDP1, Convert.ToDecimal(Folio));
            this.reportViewer1.RefreshReport();
        }
    }
}
