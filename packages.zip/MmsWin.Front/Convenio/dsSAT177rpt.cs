﻿namespace MmsWin.Front.Convenio {
    
    
    public partial class dsSAT177rpt {
    }
}
