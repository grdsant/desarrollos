﻿using MmsWin.Negocio.Catalogos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class boniDevolucion : Form
    {
        #region " Variables Globales "

        public Entidades.Reprogramaciones eReprogramaciones = new Entidades.Reprogramaciones();

        public string penalizacionMov { get; set; }

        private static string fecharevicion = string.Empty;
        private static string marca = string.Empty;
        private static decimal montoPermitido = 0;
        #endregion

        #region Metodo de  la clase "
        public boniDevolucion()
        {
            InitializeComponent();
        }
        #endregion

        #region "Page Load "
        private void boniDevolucion_Load(object sender, EventArgs e)
        {
            this.cboMotivo.DataSource = Motivos.CargaMotivosDSB();
            cboMotivo.DisplayMember = "DSCMOV";
            cboMotivo.ValueMember = "MOVOID";

            cbPagar.Checked = false;

            this.cboMotivo.SelectedValue = "0";

            this.lblMensage.Text = string.Empty;
            this.lblCostoBonNueDesc.Text = string.Empty;
            this.tbCalNueva.Text = string.Empty;


            fecharevicion = MmsWin.Front.Utilerias.VarTem.tmpFchRev;
            this.lblDescProveedor.Text = eReprogramaciones.ProveedorID;
            this.lblNombreProv.Text = eReprogramaciones.Proveedor;
            this.lblidEstilo.Text = eReprogramaciones.EstiloID;
            this.lblDescEstilo.Text = eReprogramaciones.Estilo;
            this.lblCompradorDesc.Text = eReprogramaciones.Comprador;
            this.lblOnHandDesc.Text = string.Format("{0:###,###,###,###0}", Convert.ToDecimal(eReprogramaciones.OnHand));
            this.lblCostoActDesc.Text = string.Format("{0:###,###,###,###0.00}", Convert.ToDecimal(eReprogramaciones.CostoActual));
            this.lblCostoTotDesc.Text = string.Format("{0:###,###,###,###0}", Convert.ToDecimal(eReprogramaciones.CostoTotal));
            
            this.lblNumProg.Text = eReprogramaciones.NoEventos;

            marca = eReprogramaciones.MarcaID;
            this.lblDescMarca.Text = marca == "10" ? "MELODY" : marca == "30" ? "MILANO" : "KALTEX";
            string temp = eReprogramaciones.Temporada;
            this.lblTemporada.Text = temp == "999" ? "TT" : temp;
            this.lblOCDesc.Text = eReprogramaciones.OrdenCompra;

            montoPermitido = MmsWin.Negocio.Convenio.Convenio.GetInstance().obtenBoXDevo(marca);
        }
        #endregion

        #region "Guarda el tipo de motivo de penalizacion que se muestra "
        private void btAceptar_Click(object sender, EventArgs e)
        {
            if (cbPagar.Checked == false)
            {
                if (string.IsNullOrEmpty(this.tbCalNueva.Text) || this.cboMotivo.SelectedValue.ToString() == "0")
                {
                    MessageBox.Show("Debe seleccionar un motivo y agregar el porcentaje de bonificación nuevo para guardar la Bonificación", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }
            else if (cbPagar.Checked == true)
            {
                if (this.cboMotivo.SelectedValue.ToString() == "0")
                {
                    MessageBox.Show("Debe seleccionar un motivo para guardar la Bonificación",this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }

            string idEstilo = this.lblidEstilo.Text.Trim().ToUpper();
            string idProv = this.lblDescProveedor.Text.Trim().ToUpper();
            string ordenCompra = this.lblOCDesc.Text.Trim().ToUpper();
            string noEvento = Convert.ToString(int.Parse(this.lblNumProg.Text) + 1);
            string estatus = "T";
            string usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
            string temp = this.lblTemporada.Text;
            string motivo = this.cboMotivo.SelectedValue.ToString();
            string costoNuevo = this.lblCostoBonNueDesc.Text;
            string porcentageNvo = cbPagar.Checked == true ? "0" : this.tbCalNueva.Text;
            string calDirecta = cbPagar.Checked == true ? "P a g a r" : ""; 

            bool ejecuta = MmsWin.Negocio.Convenio.Convenio.GetInstance().insertNuevaBonXDev(idEstilo, idProv, ordenCompra, marca, porcentageNvo, costoNuevo, motivo, estatus, noEvento, eReprogramaciones.intFechaRevision, usuario, temp, calDirecta);

            if (ejecuta == true)
            {
                MessageBox.Show("La Bonificación se guardo correctamente.\n !Recuerda generar tu formato para firma.¡", "Bonificación por Devolución", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.Close();
            }
            else
            {
                MessageBox.Show("La Bonificación no fue generada, por favor reintentar, \n si el problema perciste comucate a soporte.", "Bonificación por Devolución", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        #endregion

        #region " Cierra el formulario de la devolución"
        private void btCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion

        #region " eventos de textbox que cambiaran la calificacion "
        private void tbCalNueva_TextChanged(object sender, EventArgs e)
      {
            try
            {
                this.lblMensage.Text = string.Empty;
                this.lblCostoBonNueDesc.Text = string.Empty;
                decimal valorProce = 0;

                valorProce = Convert.ToDecimal(this.tbCalNueva.Text);
                this.lblCostoBonNueDesc.Text = string.Format("{0:0,0.0}", ((Convert.ToDecimal(this.lblCostoTotDesc.Text) * valorProce)) / 100);

                if (Convert.ToDecimal(this.tbCalNueva.Text) < montoPermitido)
                {
                    lblMensage.ForeColor = Color.Red;
                    lblMensage.Text = "El porcentaje de calificación debe ser mayor al " + string.Format("{0:0\\%}", montoPermitido) + ".";
                    btAceptar.Enabled = false;
                }
                else if (Convert.ToDecimal(this.tbCalNueva.Text) >= 0)
                {
                    btAceptar.Enabled = true;
                    lblMensage.ForeColor = Color.Black;
                    lblMensage.Text = string.Empty;
                }
            }
            catch
            { }
        }

        private void tbCalNueva_KeyPress(object sender, KeyPressEventArgs e)
        {
            // numeros 0-9, barra espaciadora, y un . para decimal
            if (((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 8 && e.KeyChar != 46))
            {
                e.Handled = true;
                return;
            }
            if (e.KeyChar == 46)
            {
                if ((sender as TextBox).Text.IndexOf(e.KeyChar) != -1)
                    e.Handled = true;
            }
        }
        #endregion

        #region " Evento del check para saber si se envia a pagar directo  "
        private void cbPagar_CheckedChanged(object sender, EventArgs e)
        {
            this.cboMotivo.SelectedValue = "0";
            controlaCheck();
        }

        private void controlaCheck()
        {
            if (cbPagar.Checked == true)
            {
                this.lblMensage.Text = string.Empty;
                this.lblCostoBonNueDesc.Text = "0";
                this.tbCalNueva.Text = string.Empty;
                this.tbCalNueva.Enabled = false;
            }
            else
            {
                this.tbCalNueva.Enabled = true;
            }
        }
        #endregion

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
