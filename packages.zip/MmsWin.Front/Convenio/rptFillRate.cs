﻿
using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class rptFillRate : Form
    {
        public int Folio { get; set; }
        public string FillRate { get; set; }
        public string Penalizacion { get; set; }
        public string Monto { get; set; }

        public rptFillRate()
        {
            InitializeComponent();
        }

        private void rptFillRate_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dsSAT177REFR.SAT177REFR' Puede moverla o quitarla según sea necesario.
            this.sAT177REFRTableAdapter.Fill(this.dsSAT177REFR.SAT177REFR,Folio);

            ReportParameter[] parameters = new ReportParameter[4];
            parameters[0] = new ReportParameter("pFillRate", FillRate + " - 6M");
            parameters[1] = new ReportParameter("pPenalizacion", Penalizacion);         
            parameters[2] = new ReportParameter("pMonto", Monto);

            if (Convert.ToInt32(FillRate) < 70)
            {
                parameters[3] = new ReportParameter("pBlackList", "PROVEEDOR EN BLACK LIST");

            }
            

            this.reportViewer1.LocalReport.SetParameters(parameters);

            this.reportViewer1.RefreshReport();
        }
    }
}
