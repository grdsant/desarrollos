﻿namespace MmsWin.Front.Convenio
{
    partial class TblRentabilidad
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.actualizarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.borrarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.tbTabla = new System.Windows.Forms.TextBox();
            this.tbMarca = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.cmMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.ContextMenuStrip = this.cmMenu;
            this.dgvGridView.Location = new System.Drawing.Point(3, 26);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.Size = new System.Drawing.Size(842, 389);
            this.dgvGridView.TabIndex = 0;
            this.dgvGridView.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvGridView_CellMouseDown);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.actualizarTSMI,
            this.borrarTSMI});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(127, 48);
            // 
            // actualizarTSMI
            // 
            this.actualizarTSMI.Name = "actualizarTSMI";
            this.actualizarTSMI.Size = new System.Drawing.Size(126, 22);
            this.actualizarTSMI.Text = "Actualizar";
            this.actualizarTSMI.Click += new System.EventHandler(this.actualizarTSMI_Click);
            // 
            // borrarTSMI
            // 
            this.borrarTSMI.Name = "borrarTSMI";
            this.borrarTSMI.Size = new System.Drawing.Size(126, 22);
            this.borrarTSMI.Text = "Borrar";
            this.borrarTSMI.Click += new System.EventHandler(this.borrarTSMI_Click);
            // 
            // tbTabla
            // 
            this.tbTabla.Location = new System.Drawing.Point(44, 5);
            this.tbTabla.Name = "tbTabla";
            this.tbTabla.Size = new System.Drawing.Size(80, 20);
            this.tbTabla.TabIndex = 1;
            this.tbTabla.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTabla_KeyPress);
            // 
            // tbMarca
            // 
            this.tbMarca.Location = new System.Drawing.Point(126, 5);
            this.tbMarca.Name = "tbMarca";
            this.tbMarca.Size = new System.Drawing.Size(80, 20);
            this.tbMarca.TabIndex = 2;
            this.tbMarca.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbMarca_KeyPress);
            // 
            // TblRentabilidad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSlateGray;
            this.ClientSize = new System.Drawing.Size(848, 417);
            this.Controls.Add(this.tbMarca);
            this.Controls.Add(this.tbTabla);
            this.Controls.Add(this.dgvGridView);
            this.Name = "TblRentabilidad";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tablas de Rentabilidad";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TblRentabilidad_FormClosing);
            this.Load += new System.EventHandler(this.TblRentabilidad_Load);
            this.Resize += new System.EventHandler(this.TblRentabilidad_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.cmMenu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.TextBox tbTabla;
        private System.Windows.Forms.TextBox tbMarca;
        private System.Windows.Forms.ToolStripMenuItem actualizarTSMI;
        private System.Windows.Forms.ToolStripMenuItem borrarTSMI;
    }
}