﻿namespace MmsWin.Front
{
    partial class devolBonificacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(devolBonificacion));
            this.lblPenalizacion = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbPagar = new System.Windows.Forms.CheckBox();
            this.lblPagado = new System.Windows.Forms.Label();
            this.btAceptar = new System.Windows.Forms.Button();
            this.btCancelar = new System.Windows.Forms.Button();
            this.cboMotivo = new System.Windows.Forms.ComboBox();
            this.lblMotivo = new System.Windows.Forms.Label();
            this.lblPorDesc = new System.Windows.Forms.Label();
            this.lblPor = new System.Windows.Forms.Label();
            this.lblCostoTotDesc = new System.Windows.Forms.Label();
            this.lblCostoActDesc = new System.Windows.Forms.Label();
            this.lblCostoTot = new System.Windows.Forms.Label();
            this.lblCostoAct = new System.Windows.Forms.Label();
            this.lblOnHandDesc = new System.Windows.Forms.Label();
            this.lblOnHand = new System.Windows.Forms.Label();
            this.lblPorNueva = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblCompradorDesc = new System.Windows.Forms.Label();
            this.lblDescEstilo = new System.Windows.Forms.Label();
            this.lblidEstilo = new System.Windows.Forms.Label();
            this.lblDescProveedor = new System.Windows.Forms.Label();
            this.lblMarca = new System.Windows.Forms.Label();
            this.lblNumProg = new System.Windows.Forms.Label();
            this.lblOCDesc = new System.Windows.Forms.Label();
            this.lblOC = new System.Windows.Forms.Label();
            this.lblDescMarca = new System.Windows.Forms.Label();
            this.lblNombreProv = new System.Windows.Forms.Label();
            this.lblTemporada = new System.Windows.Forms.Label();
            this.lblComprador = new System.Windows.Forms.Label();
            this.lblNumReprog = new System.Windows.Forms.Label();
            this.lblEstilo = new System.Windows.Forms.Label();
            this.lblTem = new System.Windows.Forms.Label();
            this.lblProveedor = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPenalizacion
            // 
            this.lblPenalizacion.AutoSize = true;
            this.lblPenalizacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPenalizacion.Location = new System.Drawing.Point(147, 112);
            this.lblPenalizacion.Name = "lblPenalizacion";
            this.lblPenalizacion.Size = new System.Drawing.Size(31, 13);
            this.lblPenalizacion.TabIndex = 44;
            this.lblPenalizacion.Text = "9999";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.PowderBlue;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cbPagar);
            this.panel1.Controls.Add(this.lblPagado);
            this.panel1.Controls.Add(this.btAceptar);
            this.panel1.Controls.Add(this.btCancelar);
            this.panel1.Controls.Add(this.cboMotivo);
            this.panel1.Controls.Add(this.lblMotivo);
            this.panel1.Controls.Add(this.lblPorDesc);
            this.panel1.Controls.Add(this.lblPor);
            this.panel1.Controls.Add(this.lblCostoTotDesc);
            this.panel1.Controls.Add(this.lblCostoActDesc);
            this.panel1.Controls.Add(this.lblCostoTot);
            this.panel1.Controls.Add(this.lblCostoAct);
            this.panel1.Controls.Add(this.lblOnHandDesc);
            this.panel1.Controls.Add(this.lblOnHand);
            this.panel1.Controls.Add(this.lblPenalizacion);
            this.panel1.Controls.Add(this.lblPorNueva);
            this.panel1.Location = new System.Drawing.Point(12, 160);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(441, 231);
            this.panel1.TabIndex = 64;
            // 
            // cbPagar
            // 
            this.cbPagar.AutoSize = true;
            this.cbPagar.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPagar.Location = new System.Drawing.Point(89, 135);
            this.cbPagar.Name = "cbPagar";
            this.cbPagar.Size = new System.Drawing.Size(151, 17);
            this.cbPagar.TabIndex = 81;
            this.cbPagar.Text = "Casilla marcada = Pagado ";
            this.cbPagar.UseVisualStyleBackColor = true;
            // 
            // lblPagado
            // 
            this.lblPagado.AutoSize = true;
            this.lblPagado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPagado.Location = new System.Drawing.Point(4, 135);
            this.lblPagado.Name = "lblPagado";
            this.lblPagado.Size = new System.Drawing.Size(83, 13);
            this.lblPagado.TabIndex = 78;
            this.lblPagado.Text = "Directo a pagar:";
            // 
            // btAceptar
            // 
            this.btAceptar.Location = new System.Drawing.Point(130, 202);
            this.btAceptar.Name = "btAceptar";
            this.btAceptar.Size = new System.Drawing.Size(75, 23);
            this.btAceptar.TabIndex = 80;
            this.btAceptar.Text = "Aceptar";
            this.btAceptar.UseVisualStyleBackColor = true;
            this.btAceptar.Click += new System.EventHandler(this.btAceptar_Click);
            // 
            // btCancelar
            // 
            this.btCancelar.Location = new System.Drawing.Point(248, 202);
            this.btCancelar.Name = "btCancelar";
            this.btCancelar.Size = new System.Drawing.Size(75, 23);
            this.btCancelar.TabIndex = 79;
            this.btCancelar.Text = "Cancelar";
            this.btCancelar.UseVisualStyleBackColor = true;
            this.btCancelar.Click += new System.EventHandler(this.btCancelar_Click);
            // 
            // cboMotivo
            // 
            this.cboMotivo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboMotivo.FormattingEnabled = true;
            this.cboMotivo.Location = new System.Drawing.Point(52, 158);
            this.cboMotivo.Name = "cboMotivo";
            this.cboMotivo.Size = new System.Drawing.Size(334, 21);
            this.cboMotivo.TabIndex = 78;
            // 
            // lblMotivo
            // 
            this.lblMotivo.AutoSize = true;
            this.lblMotivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMotivo.Location = new System.Drawing.Point(4, 161);
            this.lblMotivo.Name = "lblMotivo";
            this.lblMotivo.Size = new System.Drawing.Size(42, 13);
            this.lblMotivo.TabIndex = 77;
            this.lblMotivo.Text = "Motivo:";
            // 
            // lblPorDesc
            // 
            this.lblPorDesc.AutoSize = true;
            this.lblPorDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPorDesc.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lblPorDesc.Location = new System.Drawing.Point(264, 62);
            this.lblPorDesc.Name = "lblPorDesc";
            this.lblPorDesc.Size = new System.Drawing.Size(25, 26);
            this.lblPorDesc.TabIndex = 56;
            this.lblPorDesc.Text = "1";
            // 
            // lblPor
            // 
            this.lblPor.AutoSize = true;
            this.lblPor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPor.Location = new System.Drawing.Point(266, 49);
            this.lblPor.Name = "lblPor";
            this.lblPor.Size = new System.Drawing.Size(105, 13);
            this.lblPor.TabIndex = 51;
            this.lblPor.Text = "Monto penalizacicón";
            // 
            // lblCostoTotDesc
            // 
            this.lblCostoTotDesc.AutoSize = true;
            this.lblCostoTotDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoTotDesc.Location = new System.Drawing.Point(74, 79);
            this.lblCostoTotDesc.Name = "lblCostoTotDesc";
            this.lblCostoTotDesc.Size = new System.Drawing.Size(13, 13);
            this.lblCostoTotDesc.TabIndex = 50;
            this.lblCostoTotDesc.Text = "1";
            // 
            // lblCostoActDesc
            // 
            this.lblCostoActDesc.AutoSize = true;
            this.lblCostoActDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoActDesc.Location = new System.Drawing.Point(75, 54);
            this.lblCostoActDesc.Name = "lblCostoActDesc";
            this.lblCostoActDesc.Size = new System.Drawing.Size(13, 13);
            this.lblCostoActDesc.TabIndex = 49;
            this.lblCostoActDesc.Text = "1";
            // 
            // lblCostoTot
            // 
            this.lblCostoTot.AutoSize = true;
            this.lblCostoTot.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoTot.Location = new System.Drawing.Point(4, 79);
            this.lblCostoTot.Name = "lblCostoTot";
            this.lblCostoTot.Size = new System.Drawing.Size(60, 13);
            this.lblCostoTot.TabIndex = 48;
            this.lblCostoTot.Text = "Costo total:";
            // 
            // lblCostoAct
            // 
            this.lblCostoAct.AutoSize = true;
            this.lblCostoAct.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCostoAct.Location = new System.Drawing.Point(4, 54);
            this.lblCostoAct.Name = "lblCostoAct";
            this.lblCostoAct.Size = new System.Drawing.Size(69, 13);
            this.lblCostoAct.TabIndex = 47;
            this.lblCostoAct.Text = "Costo actual:";
            // 
            // lblOnHandDesc
            // 
            this.lblOnHandDesc.AutoSize = true;
            this.lblOnHandDesc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOnHandDesc.Location = new System.Drawing.Point(75, 29);
            this.lblOnHandDesc.Name = "lblOnHandDesc";
            this.lblOnHandDesc.Size = new System.Drawing.Size(13, 13);
            this.lblOnHandDesc.TabIndex = 46;
            this.lblOnHandDesc.Text = "1";
            // 
            // lblOnHand
            // 
            this.lblOnHand.AutoSize = true;
            this.lblOnHand.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOnHand.Location = new System.Drawing.Point(4, 29);
            this.lblOnHand.Name = "lblOnHand";
            this.lblOnHand.Size = new System.Drawing.Size(53, 13);
            this.lblOnHand.TabIndex = 45;
            this.lblOnHand.Text = "On Hand:";
            // 
            // lblPorNueva
            // 
            this.lblPorNueva.AutoSize = true;
            this.lblPorNueva.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPorNueva.Location = new System.Drawing.Point(3, 112);
            this.lblPorNueva.Name = "lblPorNueva";
            this.lblPorNueva.Size = new System.Drawing.Size(138, 13);
            this.lblPorNueva.TabIndex = 35;
            this.lblPorNueva.Text = "Porcentaje de penalización:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblCompradorDesc);
            this.groupBox1.Controls.Add(this.lblDescEstilo);
            this.groupBox1.Controls.Add(this.lblidEstilo);
            this.groupBox1.Controls.Add(this.lblDescProveedor);
            this.groupBox1.Controls.Add(this.lblMarca);
            this.groupBox1.Controls.Add(this.lblNumProg);
            this.groupBox1.Controls.Add(this.lblOCDesc);
            this.groupBox1.Controls.Add(this.lblOC);
            this.groupBox1.Controls.Add(this.lblDescMarca);
            this.groupBox1.Controls.Add(this.lblNombreProv);
            this.groupBox1.Controls.Add(this.lblTemporada);
            this.groupBox1.Controls.Add(this.lblComprador);
            this.groupBox1.Controls.Add(this.lblNumReprog);
            this.groupBox1.Controls.Add(this.lblEstilo);
            this.groupBox1.Controls.Add(this.lblTem);
            this.groupBox1.Controls.Add(this.lblProveedor);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(441, 142);
            this.groupBox1.TabIndex = 77;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Información general";
            // 
            // lblCompradorDesc
            // 
            this.lblCompradorDesc.AutoSize = true;
            this.lblCompradorDesc.Location = new System.Drawing.Point(87, 47);
            this.lblCompradorDesc.Name = "lblCompradorDesc";
            this.lblCompradorDesc.Size = new System.Drawing.Size(27, 13);
            this.lblCompradorDesc.TabIndex = 87;
            this.lblCompradorDesc.Text = "com";
            // 
            // lblDescEstilo
            // 
            this.lblDescEstilo.AutoSize = true;
            this.lblDescEstilo.Location = new System.Drawing.Point(125, 90);
            this.lblDescEstilo.Name = "lblDescEstilo";
            this.lblDescEstilo.Size = new System.Drawing.Size(55, 13);
            this.lblDescEstilo.TabIndex = 86;
            this.lblDescEstilo.Text = "descEstilo";
            // 
            // lblidEstilo
            // 
            this.lblidEstilo.AutoSize = true;
            this.lblidEstilo.Location = new System.Drawing.Point(87, 90);
            this.lblidEstilo.Name = "lblidEstilo";
            this.lblidEstilo.Size = new System.Drawing.Size(15, 13);
            this.lblidEstilo.TabIndex = 85;
            this.lblidEstilo.Text = "id";
            // 
            // lblDescProveedor
            // 
            this.lblDescProveedor.AutoSize = true;
            this.lblDescProveedor.Location = new System.Drawing.Point(87, 68);
            this.lblDescProveedor.Name = "lblDescProveedor";
            this.lblDescProveedor.Size = new System.Drawing.Size(15, 13);
            this.lblDescProveedor.TabIndex = 83;
            this.lblDescProveedor.Text = "id";
            // 
            // lblMarca
            // 
            this.lblMarca.AutoSize = true;
            this.lblMarca.Location = new System.Drawing.Point(18, 27);
            this.lblMarca.Name = "lblMarca";
            this.lblMarca.Size = new System.Drawing.Size(40, 13);
            this.lblMarca.TabIndex = 89;
            this.lblMarca.Text = "Marca:";
            // 
            // lblNumProg
            // 
            this.lblNumProg.AutoSize = true;
            this.lblNumProg.Location = new System.Drawing.Point(358, 47);
            this.lblNumProg.Name = "lblNumProg";
            this.lblNumProg.Size = new System.Drawing.Size(27, 13);
            this.lblNumProg.TabIndex = 88;
            this.lblNumProg.Text = "num";
            // 
            // lblOCDesc
            // 
            this.lblOCDesc.AutoSize = true;
            this.lblOCDesc.Location = new System.Drawing.Point(358, 27);
            this.lblOCDesc.Name = "lblOCDesc";
            this.lblOCDesc.Size = new System.Drawing.Size(22, 13);
            this.lblOCDesc.TabIndex = 92;
            this.lblOCDesc.Text = "orc";
            // 
            // lblOC
            // 
            this.lblOC.AutoSize = true;
            this.lblOC.Location = new System.Drawing.Point(263, 27);
            this.lblOC.Name = "lblOC";
            this.lblOC.Size = new System.Drawing.Size(78, 13);
            this.lblOC.TabIndex = 91;
            this.lblOC.Text = "Orden Compra:";
            // 
            // lblDescMarca
            // 
            this.lblDescMarca.AutoSize = true;
            this.lblDescMarca.Location = new System.Drawing.Point(87, 27);
            this.lblDescMarca.Name = "lblDescMarca";
            this.lblDescMarca.Size = new System.Drawing.Size(21, 13);
            this.lblDescMarca.TabIndex = 90;
            this.lblDescMarca.Text = "ma";
            // 
            // lblNombreProv
            // 
            this.lblNombreProv.AutoSize = true;
            this.lblNombreProv.Location = new System.Drawing.Point(125, 68);
            this.lblNombreProv.Name = "lblNombreProv";
            this.lblNombreProv.Size = new System.Drawing.Size(70, 13);
            this.lblNombreProv.TabIndex = 84;
            this.lblNombreProv.Text = "nombreProve";
            // 
            // lblTemporada
            // 
            this.lblTemporada.AutoSize = true;
            this.lblTemporada.Location = new System.Drawing.Point(87, 112);
            this.lblTemporada.Name = "lblTemporada";
            this.lblTemporada.Size = new System.Drawing.Size(24, 13);
            this.lblTemporada.TabIndex = 94;
            this.lblTemporada.Text = "tem";
            // 
            // lblComprador
            // 
            this.lblComprador.AutoSize = true;
            this.lblComprador.Location = new System.Drawing.Point(18, 47);
            this.lblComprador.Name = "lblComprador";
            this.lblComprador.Size = new System.Drawing.Size(61, 13);
            this.lblComprador.TabIndex = 82;
            this.lblComprador.Text = "Comprador:";
            // 
            // lblNumReprog
            // 
            this.lblNumReprog.AutoSize = true;
            this.lblNumReprog.Location = new System.Drawing.Point(263, 47);
            this.lblNumReprog.Name = "lblNumReprog";
            this.lblNumReprog.Size = new System.Drawing.Size(49, 13);
            this.lblNumReprog.TabIndex = 81;
            this.lblNumReprog.Text = "Eventos:";
            // 
            // lblEstilo
            // 
            this.lblEstilo.AutoSize = true;
            this.lblEstilo.Location = new System.Drawing.Point(18, 90);
            this.lblEstilo.Name = "lblEstilo";
            this.lblEstilo.Size = new System.Drawing.Size(35, 13);
            this.lblEstilo.TabIndex = 79;
            this.lblEstilo.Text = "Estilo:";
            // 
            // lblTem
            // 
            this.lblTem.AutoSize = true;
            this.lblTem.Location = new System.Drawing.Point(18, 112);
            this.lblTem.Name = "lblTem";
            this.lblTem.Size = new System.Drawing.Size(64, 13);
            this.lblTem.TabIndex = 93;
            this.lblTem.Text = "Temporada:";
            // 
            // lblProveedor
            // 
            this.lblProveedor.AutoSize = true;
            this.lblProveedor.Location = new System.Drawing.Point(18, 68);
            this.lblProveedor.Name = "lblProveedor";
            this.lblProveedor.Size = new System.Drawing.Size(59, 13);
            this.lblProveedor.TabIndex = 77;
            this.lblProveedor.Text = "Proveedor:";
            // 
            // devolBonificacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(460, 399);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "devolBonificacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Devolución por Bonificación";
            this.Load += new System.EventHandler(this.devolBonificacion_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblPenalizacion;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblPorNueva;
        private System.Windows.Forms.ComboBox cboMotivo;
        private System.Windows.Forms.Label lblMotivo;
        private System.Windows.Forms.Label lblPorDesc;
        private System.Windows.Forms.Label lblPor;
        private System.Windows.Forms.Label lblCostoTotDesc;
        private System.Windows.Forms.Label lblCostoActDesc;
        private System.Windows.Forms.Label lblCostoTot;
        private System.Windows.Forms.Label lblCostoAct;
        private System.Windows.Forms.Label lblOnHandDesc;
        private System.Windows.Forms.Label lblOnHand;
        private System.Windows.Forms.Button btAceptar;
        private System.Windows.Forms.Button btCancelar;
        private System.Windows.Forms.CheckBox cbPagar;
        private System.Windows.Forms.Label lblPagado;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblCompradorDesc;
        private System.Windows.Forms.Label lblDescEstilo;
        private System.Windows.Forms.Label lblidEstilo;
        private System.Windows.Forms.Label lblDescProveedor;
        private System.Windows.Forms.Label lblMarca;
        private System.Windows.Forms.Label lblNumProg;
        private System.Windows.Forms.Label lblOCDesc;
        private System.Windows.Forms.Label lblOC;
        private System.Windows.Forms.Label lblDescMarca;
        private System.Windows.Forms.Label lblNombreProv;
        private System.Windows.Forms.Label lblTemporada;
        private System.Windows.Forms.Label lblComprador;
        private System.Windows.Forms.Label lblNumReprog;
        private System.Windows.Forms.Label lblEstilo;
        private System.Windows.Forms.Label lblTem;
        private System.Windows.Forms.Label lblProveedor;

    }
}