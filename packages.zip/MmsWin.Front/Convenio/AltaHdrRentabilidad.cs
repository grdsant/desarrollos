﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Convenio
{
    public partial class AltaHdrRentabilidad : Form
    {

        string ParUser;

        public AltaHdrRentabilidad()
        {
            InitializeComponent();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            GuardaTablaHdrRentabilidad();
        }

        private void GuardaTablaHdrRentabilidad()
        {

            string fchVal;
            Boolean indFch;
            fchVal = tbFechaInicial.Text;
            indFch = MmsWin.Negocio.Utilerias.Utilerias.fecha(fchVal);
            string fchVal2;
            Boolean indFch2;
            fchVal2 = tbFechaFinal.Text;
            indFch2 = MmsWin.Negocio.Utilerias.Utilerias.fecha(fchVal2);

            if (indFch == true | indFch2 == true)
            {
                string ParMarca = tbMarca.Text;
                string ParTabla = tbTabla.Text;
                string ParDesc = tbDescripcion.Text;
                string ParFchIni = tbFechaInicial.Text;
                ParFchIni = ParFchIni.Substring(8, 2) + ParFchIni.Substring(3, 2) + ParFchIni.Substring(0, 2);
                string ParFchFin = tbFechaFinal.Text;
                ParFchFin = ParFchFin.Substring(8, 2) + ParFchFin.Substring(3, 2) + ParFchFin.Substring(0, 2);
                string ParUser = tbUsuario.Text;
                string ParEstatus = tbEstatus.Text;
                string FechaTbl = DateTime.Now.ToString("dd/MM/yyyy");
                FechaTbl = FechaTbl.Substring(8, 2) + FechaTbl.Substring(3, 2) + FechaTbl.Substring(0, 2);
                string HoraTbl = DateTime.Now.ToString("HH:mm:ss");
                HoraTbl = HoraTbl.Substring(0, 2) + HoraTbl.Substring(3, 2) + HoraTbl.Substring(6, 2);

                MmsWin.Negocio.Convenio.TblHdrRentabilidad.GetInstance().WriteTblHdrRentabilidad1(ParMarca, ParTabla, ParDesc, ParFchIni, ParFchFin, ParUser, FechaTbl, HoraTbl, ParEstatus);
                MessageBox.Show("Alta de Tabla Exitosa...");
                this.Close();

            }
            else
            {
                MessageBox.Show("La fecha es incorrecta");
            }

        }

        private void AltaHdrRentabilidad_Load(object sender, EventArgs e)
        {
            tbUsuario.Text = MmsWin.Front.Utilerias.VarTem.tmpUser;
            tbEstatus.Text = "A";
            // Seguridad...                                                                     
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("tblRentabilidad", "Alta", ParUser);

        }

        // Seguridad                                                                                 
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                          
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
        }

        private void tbFechaInicial_Click(object sender, EventArgs e)
        {
            mcCal01.Visible = true; 
        }

        private void tbFechaFinal_Click(object sender, EventArgs e)
        {
            mcCal02.Visible = true; 
        }

        private void AltaHdrRentabilidad_FormClosing(object sender, FormClosingEventArgs e)
        {
        string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
        if (Nivel == "ADMINISTRADOR")
           {
               CargaSeguridad("tblRentabilidad", "Alta", ParUser);
           }
        }

        // Carga Seguridad                                                                                
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            // Controles                                                                  
            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void mcCal02_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbFechaFinal.Text = mcCal02.SelectionEnd.ToShortDateString();
            mcCal02.Visible = false;
        }

        private void mcCal01_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbFechaInicial.Text = mcCal01.SelectionEnd.ToShortDateString();
            mcCal01.Visible = false;
        }

    }
}
