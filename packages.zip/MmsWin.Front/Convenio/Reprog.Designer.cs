﻿namespace MmsWin.Front.Convenio
{
    partial class Reprog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Reprog));
            this.tbProveedor = new System.Windows.Forms.TextBox();
            this.lblProveedor = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.lblEstilo = new System.Windows.Forms.Label();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbNumReprog = new System.Windows.Forms.TextBox();
            this.lblNumReprog = new System.Windows.Forms.Label();
            this.btCancelar = new System.Windows.Forms.Button();
            this.btAceptar = new System.Windows.Forms.Button();
            this.mcCal01 = new System.Windows.Forms.MonthCalendar();
            this.label3 = new System.Windows.Forms.Label();
            this.tbObservacion = new System.Windows.Forms.TextBox();
            this.lblComprador = new System.Windows.Forms.Label();
            this.tbCompDesc = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtCalificacion = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cboMotivo = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbFchReprog = new System.Windows.Forms.TextBox();
            this.lblReprog = new System.Windows.Forms.Label();
            this.tbFchRev = new System.Windows.Forms.TextBox();
            this.lblRevision = new System.Windows.Forms.Label();
            this.txtOrdenCompra = new System.Windows.Forms.TextBox();
            this.lblOrdenCompra = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbProveedor
            // 
            this.tbProveedor.Enabled = false;
            this.tbProveedor.Location = new System.Drawing.Point(108, 32);
            this.tbProveedor.Name = "tbProveedor";
            this.tbProveedor.Size = new System.Drawing.Size(140, 20);
            this.tbProveedor.TabIndex = 0;
            this.tbProveedor.TextChanged += new System.EventHandler(this.tbProveedor_TextChanged);
            // 
            // lblProveedor
            // 
            this.lblProveedor.AutoSize = true;
            this.lblProveedor.Location = new System.Drawing.Point(17, 35);
            this.lblProveedor.Name = "lblProveedor";
            this.lblProveedor.Size = new System.Drawing.Size(59, 13);
            this.lblProveedor.TabIndex = 1;
            this.lblProveedor.Text = "Proveedor:";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(17, 61);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(47, 13);
            this.lblNombre.TabIndex = 2;
            this.lblNombre.Text = "Nombre:";
            // 
            // tbNombre
            // 
            this.tbNombre.Enabled = false;
            this.tbNombre.Location = new System.Drawing.Point(108, 58);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(334, 20);
            this.tbNombre.TabIndex = 3;
            // 
            // lblEstilo
            // 
            this.lblEstilo.AutoSize = true;
            this.lblEstilo.Location = new System.Drawing.Point(17, 87);
            this.lblEstilo.Name = "lblEstilo";
            this.lblEstilo.Size = new System.Drawing.Size(35, 13);
            this.lblEstilo.TabIndex = 4;
            this.lblEstilo.Text = "Estilo:";
            // 
            // tbEstilo
            // 
            this.tbEstilo.Enabled = false;
            this.tbEstilo.Location = new System.Drawing.Point(108, 84);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(140, 20);
            this.tbEstilo.TabIndex = 5;
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.Enabled = false;
            this.tbDescripcion.Location = new System.Drawing.Point(108, 110);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(334, 20);
            this.tbDescripcion.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 113);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Descripcion:";
            // 
            // tbNumReprog
            // 
            this.tbNumReprog.Enabled = false;
            this.tbNumReprog.Location = new System.Drawing.Point(108, 343);
            this.tbNumReprog.Name = "tbNumReprog";
            this.tbNumReprog.Size = new System.Drawing.Size(39, 20);
            this.tbNumReprog.TabIndex = 13;
            // 
            // lblNumReprog
            // 
            this.lblNumReprog.AutoSize = true;
            this.lblNumReprog.Location = new System.Drawing.Point(17, 346);
            this.lblNumReprog.Name = "lblNumReprog";
            this.lblNumReprog.Size = new System.Drawing.Size(85, 13);
            this.lblNumReprog.TabIndex = 12;
            this.lblNumReprog.Text = "Número Reprog:";
            // 
            // btCancelar
            // 
            this.btCancelar.Location = new System.Drawing.Point(296, 378);
            this.btCancelar.Name = "btCancelar";
            this.btCancelar.Size = new System.Drawing.Size(75, 23);
            this.btCancelar.TabIndex = 14;
            this.btCancelar.Text = "Cancelar";
            this.btCancelar.UseVisualStyleBackColor = true;
            this.btCancelar.Click += new System.EventHandler(this.btCancelar_Click);
            // 
            // btAceptar
            // 
            this.btAceptar.Location = new System.Drawing.Point(379, 378);
            this.btAceptar.Name = "btAceptar";
            this.btAceptar.Size = new System.Drawing.Size(75, 23);
            this.btAceptar.TabIndex = 15;
            this.btAceptar.Text = "Aceptar";
            this.btAceptar.UseVisualStyleBackColor = true;
            this.btAceptar.Click += new System.EventHandler(this.btAceptar_Click);
            // 
            // mcCal01
            // 
            this.mcCal01.BackColor = System.Drawing.Color.Gray;
            this.mcCal01.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mcCal01.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.mcCal01.Location = new System.Drawing.Point(64, 60);
            this.mcCal01.Name = "mcCal01";
            this.mcCal01.TabIndex = 16;
            this.mcCal01.Visible = false;
            this.mcCal01.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcCal01_DateSelected);
            this.mcCal01.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcCal01_KeyUp);
            this.mcCal01.Leave += new System.EventHandler(this.mcCal01_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 294);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "Observacion:";
            // 
            // tbObservacion
            // 
            this.tbObservacion.Location = new System.Drawing.Point(108, 291);
            this.tbObservacion.Name = "tbObservacion";
            this.tbObservacion.Size = new System.Drawing.Size(334, 20);
            this.tbObservacion.TabIndex = 19;
            // 
            // lblComprador
            // 
            this.lblComprador.AutoSize = true;
            this.lblComprador.Location = new System.Drawing.Point(18, 320);
            this.lblComprador.Name = "lblComprador";
            this.lblComprador.Size = new System.Drawing.Size(61, 13);
            this.lblComprador.TabIndex = 20;
            this.lblComprador.Text = "Comprador:";
            // 
            // tbCompDesc
            // 
            this.tbCompDesc.Enabled = false;
            this.tbCompDesc.Location = new System.Drawing.Point(108, 317);
            this.tbCompDesc.Name = "tbCompDesc";
            this.tbCompDesc.Size = new System.Drawing.Size(334, 20);
            this.tbCompDesc.TabIndex = 21;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Moccasin;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.txtCalificacion);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.cboMotivo);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.tbFchReprog);
            this.panel1.Controls.Add(this.lblReprog);
            this.panel1.Controls.Add(this.tbFchRev);
            this.panel1.Controls.Add(this.lblRevision);
            this.panel1.Location = new System.Drawing.Point(13, 161);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(441, 125);
            this.panel1.TabIndex = 27;
            // 
            // txtCalificacion
            // 
            this.txtCalificacion.Enabled = false;
            this.txtCalificacion.Location = new System.Drawing.Point(93, 12);
            this.txtCalificacion.Name = "txtCalificacion";
            this.txtCalificacion.Size = new System.Drawing.Size(140, 20);
            this.txtCalificacion.TabIndex = 43;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 15);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 13);
            this.label5.TabIndex = 42;
            this.label5.Text = "Calificación:";
            // 
            // cboMotivo
            // 
            this.cboMotivo.FormattingEnabled = true;
            this.cboMotivo.Location = new System.Drawing.Point(93, 90);
            this.cboMotivo.Name = "cboMotivo";
            this.cboMotivo.Size = new System.Drawing.Size(334, 21);
            this.cboMotivo.TabIndex = 41;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(2, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 40;
            this.label4.Text = "Motivo:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(244, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 39;
            this.label2.Text = "DD/MM/AAAA";
            // 
            // tbFchReprog
            // 
            this.tbFchReprog.Location = new System.Drawing.Point(93, 64);
            this.tbFchReprog.Name = "tbFchReprog";
            this.tbFchReprog.Size = new System.Drawing.Size(140, 20);
            this.tbFchReprog.TabIndex = 38;
            this.tbFchReprog.Click += new System.EventHandler(this.tbFchReprog_Click);
            // 
            // lblReprog
            // 
            this.lblReprog.AutoSize = true;
            this.lblReprog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReprog.Location = new System.Drawing.Point(2, 67);
            this.lblReprog.Name = "lblReprog";
            this.lblReprog.Size = new System.Drawing.Size(78, 13);
            this.lblReprog.TabIndex = 37;
            this.lblReprog.Text = "Fecha Reprog:";
            // 
            // tbFchRev
            // 
            this.tbFchRev.Enabled = false;
            this.tbFchRev.Location = new System.Drawing.Point(93, 38);
            this.tbFchRev.Name = "tbFchRev";
            this.tbFchRev.Size = new System.Drawing.Size(140, 20);
            this.tbFchRev.TabIndex = 36;
            // 
            // lblRevision
            // 
            this.lblRevision.AutoSize = true;
            this.lblRevision.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRevision.Location = new System.Drawing.Point(2, 41);
            this.lblRevision.Name = "lblRevision";
            this.lblRevision.Size = new System.Drawing.Size(79, 13);
            this.lblRevision.TabIndex = 35;
            this.lblRevision.Text = "Fecha revision:";
            // 
            // txtOrdenCompra
            // 
            this.txtOrdenCompra.Enabled = false;
            this.txtOrdenCompra.Location = new System.Drawing.Point(108, 136);
            this.txtOrdenCompra.Name = "txtOrdenCompra";
            this.txtOrdenCompra.Size = new System.Drawing.Size(140, 20);
            this.txtOrdenCompra.TabIndex = 28;
            // 
            // lblOrdenCompra
            // 
            this.lblOrdenCompra.AutoSize = true;
            this.lblOrdenCompra.Location = new System.Drawing.Point(18, 139);
            this.lblOrdenCompra.Name = "lblOrdenCompra";
            this.lblOrdenCompra.Size = new System.Drawing.Size(78, 13);
            this.lblOrdenCompra.TabIndex = 29;
            this.lblOrdenCompra.Text = "Orden Compra:";
            // 
            // Reprog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(473, 409);
            this.Controls.Add(this.mcCal01);
            this.Controls.Add(this.lblOrdenCompra);
            this.Controls.Add(this.txtOrdenCompra);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tbCompDesc);
            this.Controls.Add(this.lblComprador);
            this.Controls.Add(this.tbObservacion);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btAceptar);
            this.Controls.Add(this.btCancelar);
            this.Controls.Add(this.tbNumReprog);
            this.Controls.Add(this.lblNumReprog);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbEstilo);
            this.Controls.Add(this.lblEstilo);
            this.Controls.Add(this.tbNombre);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.lblProveedor);
            this.Controls.Add(this.tbProveedor);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Reprog";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Reprogramación";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Reprog_FormClosing);
            this.Load += new System.EventHandler(this.Reprog_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Reprog_KeyUp);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbProveedor;
        private System.Windows.Forms.Label lblProveedor;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.Label lblEstilo;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbNumReprog;
        private System.Windows.Forms.Label lblNumReprog;
        private System.Windows.Forms.Button btCancelar;
        private System.Windows.Forms.Button btAceptar;
        private System.Windows.Forms.MonthCalendar mcCal01;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbObservacion;
        private System.Windows.Forms.Label lblComprador;
        private System.Windows.Forms.TextBox tbCompDesc;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtCalificacion;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cboMotivo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbFchReprog;
        private System.Windows.Forms.Label lblReprog;
        private System.Windows.Forms.TextBox tbFchRev;
        private System.Windows.Forms.Label lblRevision;
        private System.Windows.Forms.TextBox txtOrdenCompra;
        private System.Windows.Forms.Label lblOrdenCompra;
    }
}