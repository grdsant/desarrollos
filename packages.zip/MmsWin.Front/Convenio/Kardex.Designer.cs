﻿namespace MmsWin.Front.Convenio
{
    partial class Kardex
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.btActualizarKardex = new System.Windows.Forms.Button();
            this.btOnHand = new System.Windows.Forms.Button();
            this.btOnHandDat = new System.Windows.Forms.Button();
            this.btTransitoDat = new System.Windows.Forms.Button();
            this.btTransito = new System.Windows.Forms.Button();
            this.btInventarioTotDat = new System.Windows.Forms.Button();
            this.btTotalInv = new System.Windows.Forms.Button();
            this.gbMms = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.Location = new System.Drawing.Point(12, 48);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.ReadOnly = true;
            this.dgvGridView.Size = new System.Drawing.Size(1112, 596);
            this.dgvGridView.TabIndex = 0;
            this.dgvGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellDoubleClick);
            this.dgvGridView.Sorted += new System.EventHandler(this.dgvGridView_Sorted);
            // 
            // btActualizarKardex
            // 
            this.btActualizarKardex.Location = new System.Drawing.Point(12, 19);
            this.btActualizarKardex.Name = "btActualizarKardex";
            this.btActualizarKardex.Size = new System.Drawing.Size(122, 28);
            this.btActualizarKardex.TabIndex = 1;
            this.btActualizarKardex.Text = "Actualizar Kardex";
            this.btActualizarKardex.UseVisualStyleBackColor = true;
            this.btActualizarKardex.Click += new System.EventHandler(this.btActualizarKardex_Click);
            // 
            // btOnHand
            // 
            this.btOnHand.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btOnHand.ForeColor = System.Drawing.SystemColors.Control;
            this.btOnHand.Location = new System.Drawing.Point(382, 10);
            this.btOnHand.Name = "btOnHand";
            this.btOnHand.Size = new System.Drawing.Size(61, 28);
            this.btOnHand.TabIndex = 2;
            this.btOnHand.Text = "On Hand:";
            this.btOnHand.UseVisualStyleBackColor = false;
            // 
            // btOnHandDat
            // 
            this.btOnHandDat.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btOnHandDat.ForeColor = System.Drawing.SystemColors.Control;
            this.btOnHandDat.Location = new System.Drawing.Point(440, 10);
            this.btOnHandDat.Name = "btOnHandDat";
            this.btOnHandDat.Size = new System.Drawing.Size(89, 28);
            this.btOnHandDat.TabIndex = 3;
            this.btOnHandDat.UseVisualStyleBackColor = false;
            // 
            // btTransitoDat
            // 
            this.btTransitoDat.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btTransitoDat.ForeColor = System.Drawing.SystemColors.Control;
            this.btTransitoDat.Location = new System.Drawing.Point(592, 10);
            this.btTransitoDat.Name = "btTransitoDat";
            this.btTransitoDat.Size = new System.Drawing.Size(89, 28);
            this.btTransitoDat.TabIndex = 5;
            this.btTransitoDat.UseVisualStyleBackColor = false;
            // 
            // btTransito
            // 
            this.btTransito.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btTransito.ForeColor = System.Drawing.SystemColors.Control;
            this.btTransito.Location = new System.Drawing.Point(534, 10);
            this.btTransito.Name = "btTransito";
            this.btTransito.Size = new System.Drawing.Size(61, 28);
            this.btTransito.TabIndex = 4;
            this.btTransito.Text = "Transito:";
            this.btTransito.UseVisualStyleBackColor = false;
            // 
            // btInventarioTotDat
            // 
            this.btInventarioTotDat.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btInventarioTotDat.ForeColor = System.Drawing.SystemColors.Control;
            this.btInventarioTotDat.Location = new System.Drawing.Point(775, 10);
            this.btInventarioTotDat.Name = "btInventarioTotDat";
            this.btInventarioTotDat.Size = new System.Drawing.Size(98, 28);
            this.btInventarioTotDat.TabIndex = 7;
            this.btInventarioTotDat.UseVisualStyleBackColor = false;
            // 
            // btTotalInv
            // 
            this.btTotalInv.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btTotalInv.ForeColor = System.Drawing.SystemColors.Control;
            this.btTotalInv.Location = new System.Drawing.Point(685, 10);
            this.btTotalInv.Name = "btTotalInv";
            this.btTotalInv.Size = new System.Drawing.Size(93, 28);
            this.btTotalInv.TabIndex = 6;
            this.btTotalInv.Text = "Inventario Total:";
            this.btTotalInv.UseVisualStyleBackColor = false;
            // 
            // gbMms
            // 
            this.gbMms.ForeColor = System.Drawing.SystemColors.Control;
            this.gbMms.Location = new System.Drawing.Point(364, -3);
            this.gbMms.Name = "gbMms";
            this.gbMms.Size = new System.Drawing.Size(525, 48);
            this.gbMms.TabIndex = 8;
            this.gbMms.TabStop = false;
            this.gbMms.Text = "Mms";
            // 
            // Kardex
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1136, 656);
            this.Controls.Add(this.btInventarioTotDat);
            this.Controls.Add(this.btTotalInv);
            this.Controls.Add(this.btTransitoDat);
            this.Controls.Add(this.btTransito);
            this.Controls.Add(this.btOnHandDat);
            this.Controls.Add(this.btOnHand);
            this.Controls.Add(this.btActualizarKardex);
            this.Controls.Add(this.dgvGridView);
            this.Controls.Add(this.gbMms);
            this.Name = "Kardex";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kardex";
            this.Load += new System.EventHandler(this.Kardex_Load);
            this.Resize += new System.EventHandler(this.Kardex_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.Button btActualizarKardex;
        private System.Windows.Forms.Button btOnHand;
        private System.Windows.Forms.Button btOnHandDat;
        private System.Windows.Forms.Button btTransitoDat;
        private System.Windows.Forms.Button btTransito;
        private System.Windows.Forms.Button btInventarioTotDat;
        private System.Windows.Forms.Button btTotalInv;
        private System.Windows.Forms.GroupBox gbMms;
    }
}