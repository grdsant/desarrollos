﻿namespace MmsWin.Front.Configuracion
{
    partial class ProveedoresTipo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProveedoresTipo));
            this.gpbProveedoresDisponibles = new System.Windows.Forms.GroupBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.lblNoProveedor = new System.Windows.Forms.ToolStripLabel();
            this.txtProveedor = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.lblTipo = new System.Windows.Forms.ToolStripLabel();
            this.cboTipoProveedor = new System.Windows.Forms.ToolStripComboBox();
            this.btnAgregarProveedor = new System.Windows.Forms.ToolStripButton();
            this.dgvProveedoresDisponibles = new System.Windows.Forms.DataGridView();
            this.gpbProveedoresTipo = new System.Windows.Forms.GroupBox();
            this.toolStrip3 = new System.Windows.Forms.ToolStrip();
            this.btnQuitarProveedor = new System.Windows.Forms.ToolStripButton();
            this.dgvProveedoresTipo = new System.Windows.Forms.DataGridView();
            this.gpbProveedoresDisponibles.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProveedoresDisponibles)).BeginInit();
            this.gpbProveedoresTipo.SuspendLayout();
            this.toolStrip3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProveedoresTipo)).BeginInit();
            this.SuspendLayout();
            // 
            // gpbProveedoresDisponibles
            // 
            this.gpbProveedoresDisponibles.Controls.Add(this.toolStrip1);
            this.gpbProveedoresDisponibles.Controls.Add(this.dgvProveedoresDisponibles);
            this.gpbProveedoresDisponibles.Location = new System.Drawing.Point(12, 12);
            this.gpbProveedoresDisponibles.Name = "gpbProveedoresDisponibles";
            this.gpbProveedoresDisponibles.Size = new System.Drawing.Size(502, 377);
            this.gpbProveedoresDisponibles.TabIndex = 0;
            this.gpbProveedoresDisponibles.TabStop = false;
            this.gpbProveedoresDisponibles.Text = "Proveedores disponibles";
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.lblNoProveedor,
            this.txtProveedor,
            this.toolStripSeparator2,
            this.lblTipo,
            this.cboTipoProveedor,
            this.btnAgregarProveedor});
            this.toolStrip1.Location = new System.Drawing.Point(3, 16);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(496, 25);
            this.toolStrip1.TabIndex = 4;
            this.toolStrip1.Text = "tspProveedoresDisponibles";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // lblNoProveedor
            // 
            this.lblNoProveedor.Name = "lblNoProveedor";
            this.lblNoProveedor.Size = new System.Drawing.Size(86, 22);
            this.lblNoProveedor.Text = "No. Proveedor:";
            // 
            // txtProveedor
            // 
            this.txtProveedor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtProveedor.Name = "txtProveedor";
            this.txtProveedor.Size = new System.Drawing.Size(100, 25);
            this.txtProveedor.TextChanged += new System.EventHandler(this.txtProveedor_TextChanged);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // lblTipo
            // 
            this.lblTipo.Name = "lblTipo";
            this.lblTipo.Size = new System.Drawing.Size(34, 22);
            this.lblTipo.Text = "Tipo:";
            // 
            // cboTipoProveedor
            // 
            this.cboTipoProveedor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTipoProveedor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboTipoProveedor.Name = "cboTipoProveedor";
            this.cboTipoProveedor.Size = new System.Drawing.Size(121, 25);
            // 
            // btnAgregarProveedor
            // 
            this.btnAgregarProveedor.AutoToolTip = false;
            this.btnAgregarProveedor.Image = global::MmsWin.Front.Properties.Resources._112_RightArrowShort_Blue_16x16_72;
            this.btnAgregarProveedor.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAgregarProveedor.Name = "btnAgregarProveedor";
            this.btnAgregarProveedor.Size = new System.Drawing.Size(69, 22);
            this.btnAgregarProveedor.Text = "Agregar";
            this.btnAgregarProveedor.ToolTipText = "Agregar proveedor";
            this.btnAgregarProveedor.Click += new System.EventHandler(this.Buttons_Click_Event);
            // 
            // dgvProveedoresDisponibles
            // 
            this.dgvProveedoresDisponibles.AllowUserToAddRows = false;
            this.dgvProveedoresDisponibles.AllowUserToDeleteRows = false;
            this.dgvProveedoresDisponibles.AllowUserToOrderColumns = true;
            this.dgvProveedoresDisponibles.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvProveedoresDisponibles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProveedoresDisponibles.Location = new System.Drawing.Point(3, 44);
            this.dgvProveedoresDisponibles.Name = "dgvProveedoresDisponibles";
            this.dgvProveedoresDisponibles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProveedoresDisponibles.Size = new System.Drawing.Size(493, 327);
            this.dgvProveedoresDisponibles.TabIndex = 3;
            // 
            // gpbProveedoresTipo
            // 
            this.gpbProveedoresTipo.Controls.Add(this.toolStrip3);
            this.gpbProveedoresTipo.Controls.Add(this.dgvProveedoresTipo);
            this.gpbProveedoresTipo.Location = new System.Drawing.Point(520, 12);
            this.gpbProveedoresTipo.Name = "gpbProveedoresTipo";
            this.gpbProveedoresTipo.Size = new System.Drawing.Size(475, 377);
            this.gpbProveedoresTipo.TabIndex = 2;
            this.gpbProveedoresTipo.TabStop = false;
            this.gpbProveedoresTipo.Text = "Proveedores identificados";
            // 
            // toolStrip3
            // 
            this.toolStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnQuitarProveedor});
            this.toolStrip3.Location = new System.Drawing.Point(3, 16);
            this.toolStrip3.Name = "toolStrip3";
            this.toolStrip3.Size = new System.Drawing.Size(469, 25);
            this.toolStrip3.TabIndex = 4;
            this.toolStrip3.Text = "toolStrip3";
            // 
            // btnQuitarProveedor
            // 
            this.btnQuitarProveedor.Image = global::MmsWin.Front.Properties.Resources._109_AllAnnotations_Error_16x16_72;
            this.btnQuitarProveedor.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnQuitarProveedor.Name = "btnQuitarProveedor";
            this.btnQuitarProveedor.Size = new System.Drawing.Size(117, 22);
            this.btnQuitarProveedor.Text = "Quitar proveedor";
            this.btnQuitarProveedor.Click += new System.EventHandler(this.Buttons_Click_Event);
            // 
            // dgvProveedoresTipo
            // 
            this.dgvProveedoresTipo.AllowUserToAddRows = false;
            this.dgvProveedoresTipo.AllowUserToDeleteRows = false;
            this.dgvProveedoresTipo.AllowUserToOrderColumns = true;
            this.dgvProveedoresTipo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvProveedoresTipo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProveedoresTipo.Location = new System.Drawing.Point(3, 44);
            this.dgvProveedoresTipo.Name = "dgvProveedoresTipo";
            this.dgvProveedoresTipo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvProveedoresTipo.Size = new System.Drawing.Size(466, 327);
            this.dgvProveedoresTipo.TabIndex = 3;
            // 
            // ProveedoresTipo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 401);
            this.Controls.Add(this.gpbProveedoresTipo);
            this.Controls.Add(this.gpbProveedoresDisponibles);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProveedoresTipo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProveedoresTipo";
            this.Load += new System.EventHandler(this.Form_Load_Event);
            this.gpbProveedoresDisponibles.ResumeLayout(false);
            this.gpbProveedoresDisponibles.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProveedoresDisponibles)).EndInit();
            this.gpbProveedoresTipo.ResumeLayout(false);
            this.gpbProveedoresTipo.PerformLayout();
            this.toolStrip3.ResumeLayout(false);
            this.toolStrip3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProveedoresTipo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gpbProveedoresDisponibles;
        private System.Windows.Forms.DataGridView dgvProveedoresDisponibles;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripLabel lblNoProveedor;
        private System.Windows.Forms.ToolStripTextBox txtProveedor;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripLabel lblTipo;
        private System.Windows.Forms.ToolStripComboBox cboTipoProveedor;
        private System.Windows.Forms.ToolStripButton btnAgregarProveedor;
        private System.Windows.Forms.GroupBox gpbProveedoresTipo;
        private System.Windows.Forms.ToolStrip toolStrip3;
        private System.Windows.Forms.ToolStripButton btnQuitarProveedor;
        private System.Windows.Forms.DataGridView dgvProveedoresTipo;
    }
}