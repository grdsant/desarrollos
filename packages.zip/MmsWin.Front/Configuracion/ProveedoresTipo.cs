﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Configuracion
{
    public partial class ProveedoresTipo : Form
    {

        DataTable dtProveedores = null;
        private BindingSource bsProveedores;
        string msg = "";
        Entidades.SAT177SORD iSAT177SORD = new Entidades.SAT177SORD();

        public ProveedoresTipo()
        {
            InitializeComponent();
        }

        private void Form_Load_Event(object sender, EventArgs e)
        {

            #region Enlazar cboTipoProveedor

            this.cboTipoProveedor.ComboBox.DataSource = new BindingSource(Negocio.Convenio.Reprogramacion.obtCatalogoTiposProveedor(), null);
            this.cboTipoProveedor.ComboBox.DisplayMember = "Value";
            this.cboTipoProveedor.ComboBox.ValueMember = "ID";

            this.cboTipoProveedor.ComboBox.SelectedValue = "999";

            #endregion

            #region Enlazar y configurar dgvProveedoresDisponibles

            bsProveedores = new BindingSource(Negocio.Convenio.Reprogramacion.obtCatalogoProveedores(), null);

            DataGridViewCheckBoxColumn CheckboxColumn = new DataGridViewCheckBoxColumn();
            CheckboxColumn.TrueValue = true;
            CheckboxColumn.FalseValue = false;
            CheckboxColumn.Width = 100;

            dgvProveedoresDisponibles.Columns.Insert(0, CheckboxColumn);

            this.dgvProveedoresDisponibles.DataSource = bsProveedores;//--Negocio.Convenio.Reprogramacion.obtCatalogoProveedores();

            dgvProveedoresDisponibles.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
            dgvProveedoresDisponibles.Columns["ID"].Width = 70;
            dgvProveedoresDisponibles.Columns["ID"].HeaderText = "# No.";
            dgvProveedoresDisponibles.Columns["VALUE"].Width = 340;
            dgvProveedoresDisponibles.Columns["VALUE"].HeaderText = "Proveedor";

            dgvProveedoresDisponibles.EditMode = DataGridViewEditMode.EditOnKeystroke;
           
            #endregion

            #region Enlazar y configurar dgvProveedoresTipo

            this.dgvProveedoresTipo.DataSource = Negocio.Convenio.Reprogramacion.obtProveedoresTipo();

            DataGridViewCheckBoxColumn CheckboxColumn2 = new DataGridViewCheckBoxColumn();
            CheckboxColumn2.TrueValue = true;
            CheckboxColumn2.FalseValue = false;
            CheckboxColumn2.Width = 100;

            dgvProveedoresTipo.Columns.Insert(0, CheckboxColumn2);

            dgvProveedoresTipo.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader;
           
            dgvProveedoresTipo.Columns["ProveedorID"].Width = 50;
            dgvProveedoresTipo.Columns["ProveedorID"].HeaderText = "#No";
            dgvProveedoresTipo.Columns["Proveedor"].Width = 240;
            dgvProveedoresTipo.Columns["TipoID"].Width = 40;
            dgvProveedoresTipo.Columns["Tipo"].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCellsExceptHeader; ;


            dgvProveedoresTipo.EditMode = DataGridViewEditMode.EditOnKeystroke;

            #endregion
        }


        private void Filtrar(string Proveedor = "")
        {
            bsProveedores.RemoveFilter();

            if (Proveedor != string.Empty)
            {
                bsProveedores.Filter = string.Format(" ID LIKE '*{0}*' ", Proveedor);
            }
        }

        private void txtProveedor_TextChanged(object sender, EventArgs e)
        {
            Filtrar(this.txtProveedor.Text);
        }

        private void Buttons_Click_Event(object sender, EventArgs e)
        {

            this.dgvProveedoresDisponibles.EndEdit();
            dgvProveedoresDisponibles.ClearSelection();
            this.dgvProveedoresDisponibles.Refresh();

            this.dgvProveedoresTipo.EndEdit();
            this.dgvProveedoresTipo.ClearSelection();
            this.dgvProveedoresTipo.Refresh();

            if (sender == this.btnAgregarProveedor)
            {
                if (this.cboTipoProveedor.ComboBox.SelectedValue.ToString() == "999")
                {
                    msg = "Debe seleccionar el *TIPO*, que se asignará a los proveedores.";
                    MessageBox.Show(msg, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                msg = string.Format("¿Esta seguro de querer asignar el tipo *{0}* a los proveedores seleccionados?", this.cboTipoProveedor.Text);

                if (MessageBox.Show(msg, this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                {
                    iSAT177SORD.ORDID = this.cboTipoProveedor.Text.Substring(0, 3);

                    foreach (DataGridViewRow row in this.dgvProveedoresDisponibles.Rows)
                    {
                        //Instanciar la columna checkbox
                        DataGridViewCheckBoxCell chk = dgvProveedoresDisponibles.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                        //Orden de Compra seleccionada??
                        if (Convert.ToBoolean(chk.Value) == true)
                        {
                            iSAT177SORD.ORDPRV = Convert.ToInt32(dgvProveedoresDisponibles.Rows[row.Index].Cells["ID"].Value);
                            iSAT177SORD.ORDDES = dgvProveedoresDisponibles.Rows[row.Index].Cells["VALUE"].Value.ToString();

                            //Cortar la cadena por que la tabla solo soporta 30 caracteres y aumentar el tamaño implica muchos cambios
                            iSAT177SORD.ORDDES = (iSAT177SORD.ORDDES.Length > 30)? iSAT177SORD.ORDDES.Substring(1,30):iSAT177SORD.ORDDES;


                            if (!Negocio.Global.SAT177SORD_insert(iSAT177SORD))
                            {
                                msg = string.Format("Excepción al agregar el proveedor {0} {1}, favor de revisar.", iSAT177SORD.ORDPRV,  iSAT177SORD.ORDDES);
                                MessageBox.Show(msg, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            } 
                        }
                    }

                    //Actualizar la grid de Proveedores
                    bsProveedores = new BindingSource(Negocio.Convenio.Reprogramacion.obtCatalogoProveedores(), null);
                    this.dgvProveedoresDisponibles.DataSource = bsProveedores;

                    this.dgvProveedoresTipo.DataSource = Negocio.Convenio.Reprogramacion.obtProveedoresTipo();
                }
            }

            if (sender == this.btnQuitarProveedor)
            {
                msg = string.Format("¿Esta seguro de querer quitar los proveedores seleccionados?", this.cboTipoProveedor.SelectedText);

                if (MessageBox.Show(msg, this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                {

                    foreach (DataGridViewRow row in this.dgvProveedoresTipo.Rows)
                    {
                        //Instanciar la columna checkbox
                        DataGridViewCheckBoxCell chk = dgvProveedoresTipo.Rows[row.Index].Cells[0] as DataGridViewCheckBoxCell;

                        //Proveedor seleccionado?
                        if (Convert.ToBoolean(chk.Value) == true)
                        {
                            iSAT177SORD.ORDPRV = Convert.ToInt32(dgvProveedoresTipo.Rows[row.Index].Cells["ProveedorID"].Value);
                            //iSAT177SORD.ORDDES = dgvProveedoresDisponibles.Rows[row.Index].Cells["VALUE"].Value.ToString();

                            if (!Negocio.Global.SAT177SORD_delete(iSAT177SORD))
                            {
                                msg = string.Format("Excepción al quitar el proveedor {0} {1}, favor de revisar.", iSAT177SORD.ORDPRV);
                                MessageBox.Show(msg, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }

                    //Actualizar la grid de Proveedores
                    bsProveedores = new BindingSource(Negocio.Convenio.Reprogramacion.obtCatalogoProveedores(), null);
                    this.dgvProveedoresDisponibles.DataSource = bsProveedores;

                    this.dgvProveedoresTipo.DataSource = Negocio.Convenio.Reprogramacion.obtProveedoresTipo();
                }
            }
        }
    }
}
