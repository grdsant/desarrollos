﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Configuracion
{
    public partial class Configuracion : Form
    {
        string ParUser;

        public Configuracion()
        {
            InitializeComponent();
        }

        private void Configuracion_Load(object sender, EventArgs e)
        {
            BindConfiguracion();

            // Seguridad...                                                                     
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("Configuracion", "Configuracion", ParUser);
        }

        // Seguridad                                                                                        
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                                     
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvGridView.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvGridView.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenu.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenu.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        protected void BindConfiguracion()
        {
            this.Cursor = Cursors.WaitCursor;

            dgvGridView.DataSource = null;
            System.Data.DataTable Configuracion = null;
            try
            {
                Configuracion = MmsWin.Negocio.Configuracion.Configuracion.GetInstance().ObtenConfiguracion1();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (Configuracion.Rows.Count > 0)
            {
                dgvGridView.DataSource = Configuracion;
                int nr = dgvGridView.RowCount;
                this.Text = "Configuracion / " + " " + (nr).ToString() + " Registro(s)";
                SetFontAndColors();
                rowStyle();
            }
            this.Cursor = Cursors.Default;
        }

        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvGridView.Columns[3].Frozen = true;

            dgvGridView.Columns[0].HeaderText = "Marca Texto";  
            dgvGridView.Columns[1].HeaderText = "Descripcion";
            dgvGridView.Columns[2].HeaderText = "Marca Numerico";
            dgvGridView.Columns[3].HeaderText = "Dias x Omision";
            dgvGridView.Columns[4].HeaderText = "Sem_a Reprogramar";
            dgvGridView.Columns[5].HeaderText = "Fecha Abierta";
            dgvGridView.Columns[6].HeaderText = " % Nota Credito";

            dgvGridView.Columns[7].HeaderText = "% L. Calificación";
            dgvGridView.Columns[8].HeaderText = "% Margen Precio";
         //   dgvGridView.Columns[9].HeaderText = "Redondeo - Mult.";

            dgvGridView.Columns[9].HeaderText = "Veces_a Reprogramas";
            dgvGridView.Columns[10].HeaderText = "Estatus";
            dgvGridView.Columns[11].HeaderText = "Fecha";
            dgvGridView.Columns[12].HeaderText = "Hora";


            dgvGridView.Columns[0].Width = 80;
            dgvGridView.Columns[1].Width = 80;
            dgvGridView.Columns[2].Width = 80;
            dgvGridView.Columns[3].Width = 80;
            dgvGridView.Columns[4].Width = 80;
            dgvGridView.Columns[5].Width = 80;
            dgvGridView.Columns[6].Width = 80;

            dgvGridView.Columns[7].Width = 80;
            dgvGridView.Columns[8].Width = 70;
           // dgvGridView.Columns[9].Width = 80;

            dgvGridView.Columns[9].Width = 80;
            dgvGridView.Columns[10].Width = 70;
            dgvGridView.Columns[11].Width = 80;
            dgvGridView.Columns[12].Width = 80;

            dgvGridView.Columns[0].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[1].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[2].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[3].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[4].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[5].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[6].DefaultCellStyle.NullValue = true;

            dgvGridView.Columns[7].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[8].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[9].DefaultCellStyle.NullValue = true;

            dgvGridView.Columns[10].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[11].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns[12].DefaultCellStyle.NullValue = true;
           // dgvGridView.Columns[13].DefaultCellStyle.NullValue = true;

            dgvGridView.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[11].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[12].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
           // dgvGridView.Columns[13].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns[5].DefaultCellStyle.Format = "20##-##-##";
            //dgvGridView.Columns[9].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns[11].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns[12].DefaultCellStyle.Format = "##:##:##";
           // dgvGridView.Columns[13].DefaultCellStyle.Format = "##:##:##";

            dgvGridView.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[1].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[2].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[3].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns[4].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[5].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns[6].HeaderCell.Style.BackColor = Color.LightSalmon;

            dgvGridView.Columns[7].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[8].HeaderCell.Style.BackColor = Color.LightGreen;
          //  dgvGridView.Columns[9].HeaderCell.Style.BackColor = Color.LightSkyBlue;

            dgvGridView.Columns[9].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns[10].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[11].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[12].HeaderCell.Style.BackColor = Color.LightSkyBlue;
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }

        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            //
            string NomCol;
            Int32 NoCol = dgvGridView.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvGridView.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      
            //
            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }
        // Ejecuta Carga de Seguridad                                                                  
        //
        private void Configuracion_FormClosing(object sender, FormClosingEventArgs e)
        {
            CargaSeguridad("Configuracion", "Configuracion", ParUser);
        }

        private void dgvGridView_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                var hti = dgvGridView.HitTest(e.X, e.Y);
                int Row = e.RowIndex;
                int Col = e.ColumnIndex;

                cmMenu.Visible = true;
            }
        }

        private void ActualizarTSMI_Click(object sender, EventArgs e)
        {
            ActualizaConfiguracion();
        }

        private void ActualizaConfiguracion()
        {
            System.Data.DataTable dtConfiguracion = new System.Data.DataTable("Configuracion");
            dtConfiguracion.Columns.Add("MarcaT", typeof(String));
            dtConfiguracion.Columns.Add("Descripcion", typeof(String));
            dtConfiguracion.Columns.Add("MarcaN", typeof(String));
            dtConfiguracion.Columns.Add("DiasxO", typeof(String));
            dtConfiguracion.Columns.Add("SemAReprog", typeof(String));
            dtConfiguracion.Columns.Add("FechaAbierta", typeof(String));
            dtConfiguracion.Columns.Add("PorNtaCred", typeof(String));

            dtConfiguracion.Columns.Add("Calificacion", typeof(String));
            dtConfiguracion.Columns.Add("MargenPrecio", typeof(String));
           // dtConfiguracion.Columns.Add("RedondeoMult", typeof(String));

            dtConfiguracion.Columns.Add("VezAReprog", typeof(String));
            dtConfiguracion.Columns.Add("Estatus", typeof(String));
            dtConfiguracion.Columns.Add("Fecha", typeof(String));
            dtConfiguracion.Columns.Add("Hora", typeof(String));

            DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                DataRow workRow = dtConfiguracion.NewRow();
                workRow["MarcaT"] = item.Cells[0].Value.ToString();
                workRow["Descripcion"] = item.Cells[1].Value.ToString();
                workRow["MarcaN"] = item.Cells[2].Value.ToString();
                workRow["DiasxO"] = item.Cells[3].Value.ToString();
                workRow["SemAReprog"] = item.Cells[4].Value.ToString();
                workRow["FechaAbierta"] = item.Cells[5].Value.ToString();
                workRow["PorNtaCred"] = item.Cells[6].Value.ToString();

                workRow["Calificacion"] = item.Cells[7].Value.ToString();
                workRow["MargenPrecio"] = item.Cells[8].Value.ToString();
               // workRow["RedondeoMult"] = item.Cells[9].Value.ToString();

                workRow["VezAReprog"] = item.Cells[9].Value.ToString();
                workRow["Estatus"] = item.Cells[10].Value.ToString();
                workRow["Fecha"] = item.Cells[11].Value.ToString();
                workRow["Hora"] = item.Cells[12].Value.ToString();

                dtConfiguracion.Rows.Add(workRow);
            }
            MmsWin.Negocio.Configuracion.Configuracion.GetInstance().UpdateConfiguracion(dtConfiguracion);
            BindConfiguracion();
            MessageBox.Show("Actualizacion completa...");
            BindConfiguracion();
        }

        private void eliminarTSMI_Click(object sender, EventArgs e)
        {
            string marca;
            string message = "Corfirmar la Eliminación del Registro";
            string caption = "Advertencia...";
            DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                marca = item.Cells[2].Value.ToString();

                message = "Confirma la Eliminacion del Registro:"  + " con la marca : " + marca;
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;
                result = MessageBox.Show(message, caption, buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    MmsWin.Negocio.Configuracion.Configuracion.GetInstance().EliminaConfiguracion(marca);
                    MessageBox.Show("Regitro Eliminado...");
                }
            }

            BindConfiguracion();
        }
    }
}
