﻿namespace MmsWin.Front.CalificacionAllocation
{
    partial class CalAlloc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pgbProg = new System.Windows.Forms.ProgressBar();
            this.dgvGridview = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.FotoTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.cosnsultaPDFTSM = new System.Windows.Forms.ToolStripMenuItem();
            this.cargaPDFTSM = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.EliminarTSM1 = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblDesde = new System.Windows.Forms.Label();
            this.lblHasta = new System.Windows.Forms.Label();
            this.tbCal01 = new System.Windows.Forms.TextBox();
            this.tbHasta = new System.Windows.Forms.TextBox();
            this.cbCompradores = new System.Windows.Forms.ComboBox();
            this.gbMarca = new System.Windows.Forms.GroupBox();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.gbComprador = new System.Windows.Forms.GroupBox();
            this.mcCal01 = new System.Windows.Forms.MonthCalendar();
            this.mcC1 = new System.Windows.Forms.MonthCalendar();
            this.tbTdaNombre = new System.Windows.Forms.TextBox();
            this.tbIdTda = new System.Windows.Forms.TextBox();
            this.tbTemporada = new System.Windows.Forms.TextBox();
            this.tbTipoCal = new System.Windows.Forms.TextBox();
            this.tbRelleno02 = new System.Windows.Forms.TextBox();
            this.Relleno = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbProveedor = new System.Windows.Forms.TextBox();
            this.gbTipoConsulta = new System.Windows.Forms.GroupBox();
            this.cbTipoConsulta = new System.Windows.Forms.ComboBox();
            this.gbTemporada = new System.Windows.Forms.GroupBox();
            this.cbTemporada = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridview)).BeginInit();
            this.cmMenu.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gbMarca.SuspendLayout();
            this.SuspendLayout();
            // 
            // pgbProg
            // 
            this.pgbProg.Location = new System.Drawing.Point(4, 386);
            this.pgbProg.Name = "pgbProg";
            this.pgbProg.Size = new System.Drawing.Size(1223, 10);
            this.pgbProg.TabIndex = 11;
            this.pgbProg.Visible = false;
            // 
            // dgvGridview
            // 
            this.dgvGridview.AllowUserToAddRows = false;
            this.dgvGridview.AllowUserToDeleteRows = false;
            this.dgvGridview.AllowUserToOrderColumns = true;
            this.dgvGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridview.ContextMenuStrip = this.cmMenu;
            this.dgvGridview.Location = new System.Drawing.Point(3, 65);
            this.dgvGridview.Name = "dgvGridview";
            this.dgvGridview.Size = new System.Drawing.Size(1224, 333);
            this.dgvGridview.TabIndex = 12;
            this.dgvGridview.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvGridview_CellMouseDown);
            this.dgvGridview.Sorted += new System.EventHandler(this.dgvGridview_Sorted);
            this.dgvGridview.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvGridview_KeyUp);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FotoTSMI,
            this.cosnsultaPDFTSM,
            this.cargaPDFTSM,
            this.toolStripMenuItem2,
            this.EliminarTSM1});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(146, 114);
            // 
            // FotoTSMI
            // 
            this.FotoTSMI.Name = "FotoTSMI";
            this.FotoTSMI.Size = new System.Drawing.Size(145, 22);
            this.FotoTSMI.Text = "Foto";
            this.FotoTSMI.Click += new System.EventHandler(this.fotoToolStripMenuItem_Click);
            // 
            // cosnsultaPDFTSM
            // 
            this.cosnsultaPDFTSM.Name = "cosnsultaPDFTSM";
            this.cosnsultaPDFTSM.Size = new System.Drawing.Size(145, 22);
            this.cosnsultaPDFTSM.Text = "Consulta PDF";
            this.cosnsultaPDFTSM.Click += new System.EventHandler(this.cosnsultaPDFTSM_Click);
            // 
            // cargaPDFTSM
            // 
            this.cargaPDFTSM.Name = "cargaPDFTSM";
            this.cargaPDFTSM.Size = new System.Drawing.Size(145, 22);
            this.cargaPDFTSM.Text = "Carga PDF";
            this.cargaPDFTSM.Click += new System.EventHandler(this.cargaPDFTSM_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(145, 22);
            this.toolStripMenuItem2.Text = "____________";
            // 
            // EliminarTSM1
            // 
            this.EliminarTSM1.Name = "EliminarTSM1";
            this.EliminarTSM1.Size = new System.Drawing.Size(145, 22);
            this.EliminarTSM1.Text = "Eliminar";
            this.EliminarTSM1.Click += new System.EventHandler(this.EliminarTSM1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblDesde);
            this.groupBox1.Controls.Add(this.lblHasta);
            this.groupBox1.Controls.Add(this.tbCal01);
            this.groupBox1.Controls.Add(this.tbHasta);
            this.groupBox1.Location = new System.Drawing.Point(245, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(253, 40);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Rango";
            // 
            // lblDesde
            // 
            this.lblDesde.AutoSize = true;
            this.lblDesde.Location = new System.Drawing.Point(7, 17);
            this.lblDesde.Name = "lblDesde";
            this.lblDesde.Size = new System.Drawing.Size(38, 13);
            this.lblDesde.TabIndex = 44;
            this.lblDesde.Text = "Desde";
            // 
            // lblHasta
            // 
            this.lblHasta.AutoSize = true;
            this.lblHasta.Location = new System.Drawing.Point(135, 17);
            this.lblHasta.Name = "lblHasta";
            this.lblHasta.Size = new System.Drawing.Size(35, 13);
            this.lblHasta.TabIndex = 45;
            this.lblHasta.Text = "Hasta";
            // 
            // tbCal01
            // 
            this.tbCal01.Location = new System.Drawing.Point(54, 13);
            this.tbCal01.Name = "tbCal01";
            this.tbCal01.ReadOnly = true;
            this.tbCal01.Size = new System.Drawing.Size(69, 20);
            this.tbCal01.TabIndex = 18;
            this.tbCal01.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbCal01.Click += new System.EventHandler(this.tbCal01_Click);
            // 
            // tbHasta
            // 
            this.tbHasta.Location = new System.Drawing.Point(172, 13);
            this.tbHasta.Name = "tbHasta";
            this.tbHasta.ReadOnly = true;
            this.tbHasta.Size = new System.Drawing.Size(71, 20);
            this.tbHasta.TabIndex = 44;
            this.tbHasta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbHasta.Click += new System.EventHandler(this.tbHasta_Click);
            // 
            // cbCompradores
            // 
            this.cbCompradores.FormattingEnabled = true;
            this.cbCompradores.Location = new System.Drawing.Point(98, 15);
            this.cbCompradores.Name = "cbCompradores";
            this.cbCompradores.Size = new System.Drawing.Size(141, 21);
            this.cbCompradores.TabIndex = 14;
            this.cbCompradores.SelectedValueChanged += new System.EventHandler(this.cbCompradores_SelectedValueChanged);
            // 
            // gbMarca
            // 
            this.gbMarca.Controls.Add(this.cbMarca);
            this.gbMarca.Location = new System.Drawing.Point(6, 2);
            this.gbMarca.Name = "gbMarca";
            this.gbMarca.Size = new System.Drawing.Size(84, 40);
            this.gbMarca.TabIndex = 13;
            this.gbMarca.TabStop = false;
            this.gbMarca.Text = "Marca";
            // 
            // cbMarca
            // 
            this.cbMarca.Location = new System.Drawing.Point(5, 13);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(74, 21);
            this.cbMarca.TabIndex = 2;
            this.cbMarca.SelectedValueChanged += new System.EventHandler(this.cbMarca_SelectedValueChanged);
            // 
            // gbComprador
            // 
            this.gbComprador.Location = new System.Drawing.Point(93, 2);
            this.gbComprador.Name = "gbComprador";
            this.gbComprador.Size = new System.Drawing.Size(150, 40);
            this.gbComprador.TabIndex = 15;
            this.gbComprador.TabStop = false;
            this.gbComprador.Text = "Comprador";
            // 
            // mcCal01
            // 
            this.mcCal01.BackColor = System.Drawing.Color.Gray;
            this.mcCal01.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.mcCal01.Location = new System.Drawing.Point(502, 66);
            this.mcCal01.Name = "mcCal01";
            this.mcCal01.TabIndex = 18;
            this.mcCal01.Visible = false;
            this.mcCal01.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcCal01_DateSelected);
            this.mcCal01.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcCal01_KeyUp);
            this.mcCal01.Leave += new System.EventHandler(this.mcCal01_Leave);
            // 
            // mcC1
            // 
            this.mcC1.BackColor = System.Drawing.Color.Gray;
            this.mcC1.ForeColor = System.Drawing.Color.Black;
            this.mcC1.Location = new System.Drawing.Point(368, 66);
            this.mcC1.Name = "mcC1";
            this.mcC1.TabIndex = 44;
            this.mcC1.Visible = false;
            this.mcC1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcC1_DateSelected);
            this.mcC1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcC1_KeyUp);
            this.mcC1.Leave += new System.EventHandler(this.mcC1_Leave);
            // 
            // tbTdaNombre
            // 
            this.tbTdaNombre.Enabled = false;
            this.tbTdaNombre.Location = new System.Drawing.Point(305, 45);
            this.tbTdaNombre.Name = "tbTdaNombre";
            this.tbTdaNombre.Size = new System.Drawing.Size(100, 20);
            this.tbTdaNombre.TabIndex = 56;
            // 
            // tbIdTda
            // 
            this.tbIdTda.Enabled = false;
            this.tbIdTda.Location = new System.Drawing.Point(255, 45);
            this.tbIdTda.Name = "tbIdTda";
            this.tbIdTda.Size = new System.Drawing.Size(50, 20);
            this.tbIdTda.TabIndex = 55;
            // 
            // tbTemporada
            // 
            this.tbTemporada.Enabled = false;
            this.tbTemporada.Location = new System.Drawing.Point(205, 45);
            this.tbTemporada.Name = "tbTemporada";
            this.tbTemporada.Size = new System.Drawing.Size(50, 20);
            this.tbTemporada.TabIndex = 54;
            // 
            // tbTipoCal
            // 
            this.tbTipoCal.Enabled = false;
            this.tbTipoCal.Location = new System.Drawing.Point(125, 45);
            this.tbTipoCal.Name = "tbTipoCal";
            this.tbTipoCal.Size = new System.Drawing.Size(80, 20);
            this.tbTipoCal.TabIndex = 53;
            // 
            // tbRelleno02
            // 
            this.tbRelleno02.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbRelleno02.Enabled = false;
            this.tbRelleno02.Location = new System.Drawing.Point(1055, 45);
            this.tbRelleno02.Name = "tbRelleno02";
            this.tbRelleno02.Size = new System.Drawing.Size(172, 20);
            this.tbRelleno02.TabIndex = 52;
            // 
            // Relleno
            // 
            this.Relleno.Enabled = false;
            this.Relleno.Location = new System.Drawing.Point(4, 45);
            this.Relleno.Name = "Relleno";
            this.Relleno.Size = new System.Drawing.Size(121, 20);
            this.Relleno.TabIndex = 51;
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDescripcion.Location = new System.Drawing.Point(805, 45);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(250, 20);
            this.tbDescripcion.TabIndex = 50;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress_1);
            // 
            // tbEstilo
            // 
            this.tbEstilo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbEstilo.Location = new System.Drawing.Point(705, 45);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(100, 20);
            this.tbEstilo.TabIndex = 49;
            this.tbEstilo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbEstilo_KeyPress_1);
            // 
            // tbNombre
            // 
            this.tbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNombre.Location = new System.Drawing.Point(455, 45);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(250, 20);
            this.tbNombre.TabIndex = 48;
            this.tbNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNombre_KeyPress_1);
            // 
            // tbProveedor
            // 
            this.tbProveedor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbProveedor.Location = new System.Drawing.Point(405, 45);
            this.tbProveedor.Name = "tbProveedor";
            this.tbProveedor.Size = new System.Drawing.Size(50, 20);
            this.tbProveedor.TabIndex = 47;
            this.tbProveedor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbProveedor_KeyPress_1);
            // 
            // gbTipoConsulta
            // 
            this.gbTipoConsulta.BackColor = System.Drawing.Color.Transparent;
            this.gbTipoConsulta.Location = new System.Drawing.Point(703, -3);
            this.gbTipoConsulta.Name = "gbTipoConsulta";
            this.gbTipoConsulta.Size = new System.Drawing.Size(125, 37);
            this.gbTipoConsulta.TabIndex = 58;
            this.gbTipoConsulta.TabStop = false;
            this.gbTipoConsulta.Text = "Tipo de Calificación";
            // 
            // cbTipoConsulta
            // 
            this.cbTipoConsulta.BackColor = System.Drawing.Color.GhostWhite;
            this.cbTipoConsulta.FormattingEnabled = true;
            this.cbTipoConsulta.Items.AddRange(new object[] {
            "Todas",
            "Calificación",
            "PreCalificación",
            "Rebaja 01",
            "Rebaja 02"});
            this.cbTipoConsulta.Location = new System.Drawing.Point(705, 11);
            this.cbTipoConsulta.Name = "cbTipoConsulta";
            this.cbTipoConsulta.Size = new System.Drawing.Size(119, 21);
            this.cbTipoConsulta.TabIndex = 24;
            // 
            // gbTemporada
            // 
            this.gbTemporada.BackColor = System.Drawing.Color.Transparent;
            this.gbTemporada.Location = new System.Drawing.Point(516, 12);
            this.gbTemporada.Name = "gbTemporada";
            this.gbTemporada.Size = new System.Drawing.Size(131, 47);
            this.gbTemporada.TabIndex = 57;
            this.gbTemporada.TabStop = false;
            this.gbTemporada.Text = "Temporada";
            // 
            // cbTemporada
            // 
            this.cbTemporada.BackColor = System.Drawing.Color.GhostWhite;
            this.cbTemporada.FormattingEnabled = true;
            this.cbTemporada.Location = new System.Drawing.Point(528, 15);
            this.cbTemporada.Name = "cbTemporada";
            this.cbTemporada.Size = new System.Drawing.Size(119, 21);
            this.cbTemporada.TabIndex = 24;
            // 
            // CalAlloc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1231, 402);
            this.Controls.Add(this.cbTipoConsulta);
            this.Controls.Add(this.cbTemporada);
            this.Controls.Add(this.gbTipoConsulta);
            this.Controls.Add(this.gbTemporada);
            this.Controls.Add(this.tbTdaNombre);
            this.Controls.Add(this.tbIdTda);
            this.Controls.Add(this.tbTemporada);
            this.Controls.Add(this.tbTipoCal);
            this.Controls.Add(this.tbRelleno02);
            this.Controls.Add(this.Relleno);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.tbEstilo);
            this.Controls.Add(this.tbNombre);
            this.Controls.Add(this.tbProveedor);
            this.Controls.Add(this.mcC1);
            this.Controls.Add(this.mcCal01);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbCompradores);
            this.Controls.Add(this.gbMarca);
            this.Controls.Add(this.gbComprador);
            this.Controls.Add(this.pgbProg);
            this.Controls.Add(this.dgvGridview);
            this.Name = "CalAlloc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calificacion Allocation";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CalAlloc_FormClosing);
            this.Load += new System.EventHandler(this.CalAlloc_Load);
            this.Resize += new System.EventHandler(this.CalAlloc_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridview)).EndInit();
            this.cmMenu.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbMarca.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar pgbProg;
        private System.Windows.Forms.DataGridView dgvGridview;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbCompradores;
        private System.Windows.Forms.GroupBox gbMarca;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.GroupBox gbComprador;
        private System.Windows.Forms.TextBox tbCal01;
        private System.Windows.Forms.MonthCalendar mcCal01;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem FotoTSMI;
        private System.Windows.Forms.ToolStripMenuItem EliminarTSM1;
        private System.Windows.Forms.ToolStripMenuItem cosnsultaPDFTSM;
        private System.Windows.Forms.ToolStripMenuItem cargaPDFTSM;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.Label lblHasta;
        private System.Windows.Forms.TextBox tbHasta;
        private System.Windows.Forms.Label lblDesde;
        private System.Windows.Forms.MonthCalendar mcC1;
        private System.Windows.Forms.TextBox tbTdaNombre;
        private System.Windows.Forms.TextBox tbIdTda;
        private System.Windows.Forms.TextBox tbTemporada;
        private System.Windows.Forms.TextBox tbTipoCal;
        private System.Windows.Forms.TextBox tbRelleno02;
        private System.Windows.Forms.TextBox Relleno;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.TextBox tbProveedor;
        private System.Windows.Forms.GroupBox gbTipoConsulta;
        private System.Windows.Forms.ComboBox cbTipoConsulta;
        private System.Windows.Forms.GroupBox gbTemporada;
        private System.Windows.Forms.ComboBox cbTemporada;
    }
}