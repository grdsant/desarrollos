﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using MmsWin.Front.Utilerias;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using MmsWin.Front.CalificacionAllocation;
using MmsWin.Front.Bonificaciones; 

namespace MmsWin.Front.CalificacionAllocation
{
    public partial class CalAlloc : Form
    {

        int nr;
        string ParUser;
        String marca;
        bool Carga;
        String FchDe;
        String FchHas;
        long FchDeN;
        long FchHasN;
        String comprador;
        string FechaCal;
        string FechaFmt;
        long FechaApli;
        int dgvOffset;
        int pgbOffset;
        int dgvOffset2;

        public static string ParTienda      { get; set; }
        public static string parProveedor   { get; set; }
        public static string parEstilo      { get; set; }
        public static string ParProveedor   { get; set; }
        public static string PartbNombre    { get; set; }
        public static string PartbEstilo    { get; set; }
        public static string ParDescripcion { get; set; }

        public CalAlloc()
        {
            InitializeComponent();
            dgvOffset  = this.Width  - dgvGridview.Width;
            dgvOffset2 = this.Height - dgvGridview.Height;
            pgbOffset  = this.Width  - pgbProg.Width;
        }

        private void CalAlloc_Load(object sender, EventArgs e)
        {
            Carga        = false;
            marca        = "999";
            comprador    = "999";
            tbCal01.Text = "0000000000";
            tbHasta.Text = "0000000000";
            FchDe        = "10/10/2000";
            FchHas       = "10/10/2000";
            tbCal01.Text = FchDe;
            tbHasta.Text = FchHas;

            // Carga de Marca
            try
            {
                BindMarca();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            // Carga de Compradores
            try
            {
                BindCompradores();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            try
            {
                System.Data.DataTable tbFechaInicial = null;
                tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();

                foreach (DataRow row in tbFechaInicial.Rows)
                {
                    tbCal01.Text = row["DSPFCH"].ToString();

                    FechaCal = tbCal01.Text;
                    FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                    tbCal01.Text = FechaFmt.ToString();

                    tbHasta.Text = row["DSPFCH"].ToString();
                    FechaCal = tbHasta.Text;
                    FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                    tbHasta.Text = FechaFmt.ToString();

                    FechaCal = tbCal01.Text;
                    FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                    FchDeN = long.Parse(FechaFmt.ToString());
                    FchDe = FechaFmt.ToString();

                    FechaCal = tbHasta.Text;
                    FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                    FchHasN = long.Parse(FechaFmt.ToString());
                    FchHas = FechaFmt.ToString();

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


            comprador = MmsWin.Front.Utilerias.VarTem.tmpUSRCOM;
            cbCompradores.SelectedValue = comprador;
            marca     = MmsWin.Front.Utilerias.VarTem.tmpUSRMAR;
            cbMarca.SelectedValue       = marca;

            // Carga de Datos
            try
            {
                Carga = true;
                BindCalAlloc();

                // Seguridad...
                ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                Seguridad("CalificacionAllocation", "CalAlloc", ParUser);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        // Seguridad                                                                                
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                         
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvGridview.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvGridview.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenu.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenu.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        protected void BindCalAlloc()
        {
            if (Carga == true)
            {
                nr = 0;
                this.Cursor = Cursors.WaitCursor;
                dgvGridview.DataSource = null;
                System.Data.DataTable CalAlloc = null;
                try
                {
                    ParTienda      = tbIdTda.Text;
                    ParProveedor   = tbProveedor.Text;
                    PartbNombre    = tbNombre.Text;
                    PartbEstilo    = tbEstilo.Text;
                    ParDescripcion = tbDescripcion.Text;

                    CalAlloc = MmsWin.Negocio.CalificacionAllocation.CalAlloc.GetInstance().ObtenCalAlloc1(marca, comprador, FchDe, FchHas, ParTienda, ParProveedor, PartbNombre, PartbEstilo, ParDescripcion);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                if (CalAlloc != null)
                {
                    if (CalAlloc.Rows.Count > 0)
                    {
                        dgvGridview.DataSource = CalAlloc;
                        SetFontAndColors();
                        rowStyle();
                        SetDoubleBuffered(dgvGridview);

                        nr = dgvGridview.RowCount;
                        this.Text = "CalAlloc (Notas de Credito/Adendum/Excepciones) / " + " " + (nr).ToString() + " Registro(s)";

                        // Seguridad...
                        ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        Seguridad("CalificacionAllocation", "CalAlloc", ParUser);
                    }
                }
                this.Cursor = Cursors.Default;
            }
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        protected void BindMarca()
        {
            try
            {
                cbMarca.DataSource = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();
                cbMarca.DisplayMember = "Value";
                cbMarca.ValueMember = "Key";
                marca = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void BindCompradores()
        {
            try
            {
                cbCompradores.DataSource = MmsWin.Negocio.Catalogos.Compradores.GetInstance().ObtenCompradors().ToList();
                cbCompradores.DisplayMember = "Value";
                cbCompradores.ValueMember = "Key";
                comprador = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void SetFontAndColors()
        {
            this.dgvGridview.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvGridview.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridview.EnableHeadersVisualStyles = false;
            this.dgvGridview.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridview.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvGridview.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridview.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridview.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvGridview.Columns["RDDSTY"].Frozen = true;

            dgvGridview.Columns["RDDBON"].HeaderText  = "Fecha Bonificacion";
            dgvGridview.Columns["RDDTPO"].HeaderText  = "Tipo Calificación";
            dgvGridview.Columns["RDDTMP"].HeaderText  = "Temporada";
            dgvGridview.Columns["RDDSTR"].HeaderText  = "Id Tienda";
            dgvGridview.Columns["RDDNAM"].HeaderText  = "Nombre";
            dgvGridview.Columns["RDDPRV"].HeaderText  = "Proveedor";
            dgvGridview.Columns["RDDPRN"].HeaderText  = "Nombre";
            dgvGridview.Columns["RDDSTY"].HeaderText  = "Estilo";
            dgvGridview.Columns["RDDDES"].HeaderText  = "Descripción";
            dgvGridview.Columns["RDDDCP"].HeaderText  = "Comprador";
            dgvGridview.Columns["RDDNOT"].HeaderText  = "Nota de Credito";
            dgvGridview.Columns["RDDSUB"].HeaderText  = "Sub Total";
            dgvGridview.Columns["RDDIVA"].HeaderText  = "Iva";
            dgvGridview.Columns["RDDTOT"].HeaderText  = "Total";
            dgvGridview.Columns["RDDCST"].HeaderText  = "Costo Actual";
            dgvGridview.Columns["RDDPRC"].HeaderText  = "Precio Actual";
            dgvGridview.Columns["RDDMRG"].HeaderText  = "Margen";
            dgvGridview.Columns["RDDNCA"].HeaderText  = "No. Calificación";
            dgvGridview.Columns["RDDFCM"].HeaderText  = "Fecha Compra";
            dgvGridview.Columns["RDDFRE"].HeaderText  = "Fecha Revision";
            dgvGridview.Columns["RDDPZA"].HeaderText  = "Piezas";
            dgvGridview.Columns["RDDVTA"].HeaderText  = "Venta";
            dgvGridview.Columns["RDDONH"].HeaderText  = "On Hand";
            dgvGridview.Columns["RDDPVT"].HeaderText  = "% Ventas";
            dgvGridview.Columns["RDDCAL"].HeaderText  = "Calificación";
            dgvGridview.Columns["RDDTAB"].HeaderText  = "Tabla de_Acción";
            dgvGridview.Columns["RDDCMP"].HeaderText  = "Compras Obs";
            dgvGridview.Columns["RDDRUT"].HeaderText  = "Ruta NC_PDF";
            dgvGridview.Columns["RDDMAR"].HeaderText  = "Marca";
            dgvGridview.Columns["RDDCOM"].HeaderText  = "Comprador";
            dgvGridview.Columns["RDDBDG"].HeaderText  = "Bodega";
            dgvGridview.Columns["RDDNMR"].HeaderText  = "Marca";
            dgvGridview.Columns["RDDFCHA"].HeaderText = "Fecha Actualizacion";
            dgvGridview.Columns["RDDHORA"].HeaderText = "Hora Actualizacion";
            dgvGridview.Columns["RDDUSR"].HeaderText  = "Usuario";

            dgvGridview.Columns["RDDBON"].Width  = 80;
            dgvGridview.Columns["RDDTPO"].Width  = 80;
            dgvGridview.Columns["RDDTMP"].Width  = 50;
            dgvGridview.Columns["RDDSTR"].Width  = 50;
            dgvGridview.Columns["RDDNAM"].Width  = 100;
            dgvGridview.Columns["RDDPRV"].Width  = 50;
            dgvGridview.Columns["RDDPRN"].Width  = 250;
            dgvGridview.Columns["RDDSTY"].Width  = 100;
            dgvGridview.Columns["RDDDES"].Width  = 250;
            dgvGridview.Columns["RDDDCP"].Width  = 150;
            dgvGridview.Columns["RDDNOT"].Width  = 100;
            dgvGridview.Columns["RDDSUB"].Width  = 85;
            dgvGridview.Columns["RDDIVA"].Width  = 85;
            dgvGridview.Columns["RDDTOT"].Width  = 85;
            dgvGridview.Columns["RDDCST"].Width  = 60;
            dgvGridview.Columns["RDDPRC"].Width  = 60;
            dgvGridview.Columns["RDDMRG"].Width  = 60;
            dgvGridview.Columns["RDDNCA"].Width  = 80;
            dgvGridview.Columns["RDDFCM"].Width  = 80;
            dgvGridview.Columns["RDDFRE"].Width  = 80;
            dgvGridview.Columns["RDDPZA"].Width  = 80;
            dgvGridview.Columns["RDDVTA"].Width  = 80;
            dgvGridview.Columns["RDDONH"].Width  = 80;
            dgvGridview.Columns["RDDPVT"].Width  = 80;
            dgvGridview.Columns["RDDCAL"].Width  = 80;
            dgvGridview.Columns["RDDTAB"].Width  = 80;
            dgvGridview.Columns["RDDCMP"].Width  = 80;
            dgvGridview.Columns["RDDRUT"].Width  = 60;
            dgvGridview.Columns["RDDMAR"].Width  = 60;
            dgvGridview.Columns["RDDCOM"].Width  = 60;
            dgvGridview.Columns["RDDBDG"].Width  = 60;
            dgvGridview.Columns["RDDNMR"].Width  = 60;
            dgvGridview.Columns["RDDFCHA"].Width = 80;
            dgvGridview.Columns["RDDHORA"].Width = 80;
            dgvGridview.Columns["RDDUSR"].Width  = 60;

            dgvGridview.Columns["RDDPRV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["RDDDCP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridview.Columns["RDDNOT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["RDDSUB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["RDDIVA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["RDDTOT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["RDDCST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["RDDPRC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["RDDMRG"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["RDDNCA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["RDDFCM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["RDDFRE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["RDDPZA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["RDDVTA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["RDDONH"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["RDDPVT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["RDDCAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["RDDTAB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["RDDCMP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["RDDRUT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["RDDMAR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["RDDCOM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["RDDBDG"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["RDDNMR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["RDDFCHA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["RDDHORA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["RDDUSR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridview.Columns["RDDBON"].DefaultCellStyle.Format = "20##-##-##";

            dgvGridview.Columns["RDDSUB"].DefaultCellStyle.Format = "###,###.00";
            dgvGridview.Columns["RDDIVA"].DefaultCellStyle.Format = "###,###.00";
            dgvGridview.Columns["RDDTOT"].DefaultCellStyle.Format = "###,###.00";
            dgvGridview.Columns["RDDCST"].DefaultCellStyle.Format = "00.00";
            dgvGridview.Columns["RDDPRC"].DefaultCellStyle.Format = "00.00";
            dgvGridview.Columns["RDDMRG"].DefaultCellStyle.Format = "##.00";
            dgvGridview.Columns["RDDFCM"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridview.Columns["RDDFRE"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridview.Columns["RDDPZA"].DefaultCellStyle.Format = "#,###,###";
            dgvGridview.Columns["RDDVTA"].DefaultCellStyle.Format = "#,###,###";
            dgvGridview.Columns["RDDONH"].DefaultCellStyle.Format = "#,###,###";
            dgvGridview.Columns["RDDFCHA"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridview.Columns["RDDHORA"].DefaultCellStyle.Format = "##-##-##";

            dgvGridview.Columns["RDDBON"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridview.Columns["RDDTPO"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["RDDTMP"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["RDDSTR"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["RDDNAM"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["RDDPRV"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["RDDPRN"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["RDDSTY"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["RDDDES"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["RDDDCP"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridview.Columns["RDDNOT"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["RDDSUB"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["RDDIVA"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["RDDTOT"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["RDDCST"].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridview.Columns["RDDPRC"].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridview.Columns["RDDMRG"].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridview.Columns["RDDNCA"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridview.Columns["RDDFCM"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["RDDFRE"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["RDDPZA"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            dgvGridview.Columns["RDDVTA"].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridview.Columns["RDDONH"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["RDDPVT"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["RDDCAL"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["RDDTAB"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridview.Columns["RDDCMP"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridview.Columns["RDDRUT"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["RDDMAR"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["RDDCOM"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["RDDBDG"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["RDDNMR"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["RDDFCHA"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["RDDHORA"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["RDDUSR"].HeaderCell.Style.BackColor = Color.LightSlateGray;

            dgvGridview.Columns["RDDNCA"].Visible = false;

            foreach (DataGridViewRow row in dgvGridview.Rows)
            {
                // Pagar
                if (Convert.ToString(row.Cells["RDDCAL"].Value) == " P a g a r") { row.Cells["RDDCAL"].Style.BackColor = Color.LightGreen; }
                // 15%
                if (Convert.ToString(row.Cells["RDDCAL"].Value) == " 15%") { row.Cells["RDDCAL"].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(row.Cells["RDDCAL"].Value) == " 20%") { row.Cells["RDDCAL"].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(row.Cells["RDDCAL"].Value) == " 25%") { row.Cells["RDDCAL"].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(row.Cells["RDDCAL"].Value) == " 30%") { row.Cells["RDDCAL"].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(row.Cells["RDDCAL"].Value) == " 35%") { row.Cells["RDDCAL"].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(row.Cells["RDDCAL"].Value) == " 40%") { row.Cells["RDDCAL"].Style.BackColor = Color.LightSalmon; }
                // Dev ó 40%
                if (Convert.ToString(row.Cells["RDDCAL"].Value) == " 40%") { row.Cells["RDDCAL"].Style.BackColor = Color.Red; row.Cells["RDDCAL"].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(row.Cells["RDDCAL"].Value) == " 50%") { row.Cells["RDDCAL"].Style.BackColor = Color.Red; row.Cells["RDDCAL"].Style.ForeColor = Color.White; }
                //Dev ó 50%
                if (Convert.ToString(row.Cells["RDDCAL"].Value) == " 50%") { row.Cells["RDDCAL"].Style.BackColor = Color.Red; row.Cells["RDDCAL"].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(row.Cells["RDDCAL"].Value) == "Devolucion") { row.Cells["RDDCAL"].Style.BackColor = Color.Red; row.Cells["RDDCAL"].Style.ForeColor = Color.White; }

                if (Convert.ToString(row.Cells["RDDRUT"].Value) != "") { row.Cells["RDDNOT"].Style.ForeColor = Color.Green; }
                if (Convert.ToString(row.Cells["RDDRUT"].Value) == "") { row.Cells["RDDNOT"].Style.ForeColor = Color.Red; }
            }

        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridview.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvGridview.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }

        private void CalAlloc_Resize(object sender, EventArgs e)
        {
            dgvGridview.Width = this.Width - dgvOffset;
            dgvGridview.Height = this.Height - dgvOffset2;
            pgbProg.Width = this.Width - pgbOffset;
        }

        private void tbCal01_Click(object sender, EventArgs e)
        {
            mcC1.Visible = true;
        }

        private void mcCal01_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbHasta.Text = mcCal01.SelectionEnd.ToShortDateString();
            FechaCal = tbHasta.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchHasN = long.Parse(FechaFmt.ToString());
            FchHas = FechaFmt.ToString();

            mcCal01.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbHasta.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    BindCalAlloc();
                }
            }

        }

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            marca = " ";
            ComboBox cmbMarca = (ComboBox)sender;
            marca = cmbMarca.SelectedValue.ToString();

            BindCalAlloc();
        }

        private void cbCompradores_SelectedValueChanged(object sender, EventArgs e)
        {
            comprador = " ";
            ComboBox cmbComprador = (ComboBox)sender;
            comprador = cmbComprador.SelectedValue.ToString();

            BindCalAlloc();
        }

        private void fotoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MuestraFoto();
        }

        private void MuestraFoto()
        {
            try
            {
                Fotos i = new Fotos();
                i.Show();
            }
            catch { }
            finally { }
        }

        private void dgvGridview_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            MmsWin.Front.Utilerias.VarTem.rddFchBon = this.dgvGridview.CurrentRow.Cells["RDDBON"].Value.ToString();

            MmsWin.Front.Utilerias.VarTem.rddTipoCal   = this.dgvGridview.CurrentRow.Cells["RDDTPO"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.rddTemporada = this.dgvGridview.CurrentRow.Cells["RDDTMP"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.rddTienda    = this.dgvGridview.CurrentRow.Cells["RDDSTR"].Value.ToString();

            MmsWin.Front.Utilerias.VarTem.rddFchRev    = this.dgvGridview.CurrentRow.Cells["RDDFRE"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.rddProveedor = this.dgvGridview.CurrentRow.Cells["RDDPRV"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.rddEstilo    = this.dgvGridview.CurrentRow.Cells["RDDSTY"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.rddNota      = this.dgvGridview.CurrentRow.Cells["RDDNOT"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpRutaPdf   = this.dgvGridview.CurrentRow.Cells["RDDRUT"].Value.ToString();

            MmsWin.Front.Utilerias.Fotos.numPrv = this.dgvGridview.CurrentRow.Cells["RDDPRV"].Value.ToString();
            MmsWin.Front.Utilerias.Fotos.numSty = this.dgvGridview.CurrentRow.Cells["RDDSTY"].Value.ToString();
        }

        private void dgvGridview_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                FechaCal = tbCal01.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FechaApli = long.Parse(FechaFmt.ToString());

                BindCalAlloc();
            }
        }

        private void EliminarTSM1_Click(object sender, EventArgs e)
        {
            string message = "Corfirmar la Eliminación del Registro";
            string caption = "Advertencia...";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                string ParFchBon    = MmsWin.Front.Utilerias.VarTem.rddFchBon;

                string ParTipoCal   = MmsWin.Front.Utilerias.VarTem.rddTipoCal;
                string ParTemporada = MmsWin.Front.Utilerias.VarTem.rddTemporada;
                string ParTienda    = MmsWin.Front.Utilerias.VarTem.rddTienda;

                string ParFchRev    = MmsWin.Front.Utilerias.VarTem.rddFchRev;
                string ParProveedor = MmsWin.Front.Utilerias.VarTem.rddProveedor;
                string ParEstilo    = MmsWin.Front.Utilerias.VarTem.rddEstilo;
                string ParNota      = MmsWin.Front.Utilerias.VarTem.rddNota;

                MmsWin.Negocio.CalificacionAllocation.CalAlloc.GetInstance().EliminaDocumentos(ParFchBon, ParFchRev, ParTipoCal, ParTemporada, ParTienda, ParProveedor, ParEstilo, ParNota);

                BindCalAlloc();
            }
        }

        private void CalAlloc_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("CalificacionAllocation", "CalAlloc", ParUser);
            }
        }
        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            //
            string NomCol;
            Int32 NoCol = dgvGridview.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvGridview.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      
            //
            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void dgvGridview_Sorted(object sender, EventArgs e)
        {
            SetFontAndColors();
            rowStyle();
        }

        private void cargaPDFTSM_Click(object sender, EventArgs e)
        {
            CargaPDF();
        }

        private void CargaPDF()
        {
            try
            {
                CargaPDF i = new CargaPDF();
                i.Show();
            }
            catch { }
            finally { }
        }

        private void cosnsultaPDFTSM_Click(object sender, EventArgs e)
        {
            try
            {
                string notaPDF = MmsWin.Front.Utilerias.VarTem.tmpRutaPdf;
                Process.Start(notaPDF);
            }
            catch { MessageBox.Show("No hay PDF Cargado"); }
        }

        private void tbProveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbCal01.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindCalAlloc();
                tbProveedor.Focus();
            }
        }

        private void tbNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbCal01.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindCalAlloc();
                tbNombre.Focus();
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbCal01.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindCalAlloc();
                tbDescripcion.Focus();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbCal01.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindCalAlloc();
                tbDescripcion.Focus();
            }
        }

        private void mcC1_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbCal01.Text = mcC1.SelectionEnd.ToShortDateString();
            FechaCal = tbCal01.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchDeN = long.Parse(FechaFmt.ToString());
            FchDe = FechaFmt.ToString();

            mcC1.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbCal01.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    BindCalAlloc(); ;
                }
            }
        }

        private void mcC1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcC1.Visible = false;
            }
        }

        private void mcC1_Leave(object sender, EventArgs e)
        {
            mcC1.Visible = false;
        }

        private void mcCal01_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcCal01.Visible = false;
            }
        }

        private void mcCal01_Leave(object sender, EventArgs e)
        {
            mcCal01.Visible = false;
        }

        private void tbHasta_Click(object sender, EventArgs e)
        {
            mcCal01.Visible = true;
            mcCal01.Focus();
        }

        private void pbExcel_Click(object sender, EventArgs e)
        {
            System.Data.DataTable dtDowns = (System.Data.DataTable)(dgvGridview.DataSource);
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            int nc = dgvGridview.Columns.Count;


            for (int ii = 1; ii <= nc; ii++)
            {
                xlWorkSheet.Cells[1, ii] = dgvGridview.Columns[ii - 1].HeaderText;
            }

            System.Data.DataTable dtDocumentos = (System.Data.DataTable)(dgvGridview.DataSource);
            int nr = dgvGridview.RowCount;

            int r = 0;
            int rt = 3;
            foreach (DataRow row in dtDocumentos.Rows)
            {
                var gsArray = new[]       {
                                                    row["NOTBON"], //01 Fecha Bonificacion
                                                    row["NOTPRV"], //02 Proveedor
                                                    row["NOTPRN"], //03 Nombre
                                                    row["NOTSTY"], //04 Estilo
                                                    row["NOTDES"], //05 Descripcion
                                                    row["NOTDCP"], //06 Comprador
                                                    row["NOTNOT"], //07 Nota de Credito
                                                    row["NOTSUB"], //08 Subtotal
                                                    row["NOTIVA"], //09 Iva
                                                    row["NOTTOT"], //10 Total
                                                    row["NOTCST"], //11 Costo
                                                    row["NOTPRC"], //12 Precio
                                                    row["NOTMRG"], //13 Margen
                                                    row["NOTNCA"], //14 No Calificacion
                                                    row["NOTFCM"], //15 Fecha Compra
                                                    row["NOTFRE"], //16 Fecha Revision
                                                    row["NOTPZA"], //17 Piezas
                                                    row["NOTVTA"], //18 Venta
                                                    row["NOTONH"], //19 on Hand
                                                    row["NOTPVT"], //20 % Venta
                                                    row["NOTCAL"], //21 Calificaion
                                                    row["NOTTAB"], //22 Tabla de Accion
                                                    row["NOTCMP"], //23 Compras Obsercvaciones
                                                    row["NOTRUT"], //24 Ruta
                                                    row["NOTMAR"], //25 Marca
                                                    row["NOTCOM"], //26 Comprador
                                                    row["NOTBDG"], //27 Bodega
                                                    row["NOTNMR"], //28 Marca
                                                    row["NOTFCHA"],//29 Fecha
                                                    row["NOTHORA"],//30 Hora
                                                    row["NOTUSR"]  //31 Usuario

                                                   };

                Range rng = xlWorkSheet.get_Range("A" + rt, "AE" + rt);
                rng.Value = gsArray;

                this.Text = "Notas de Crédito / " + " " + (r += 1).ToString() + " Registro(s) de " + nr;

                rt++;
            }

            xlWorkSheet.Columns[1].ColumnWidth = 3;
            xlWorkSheet.Columns[2].ColumnWidth = 15;
            xlWorkSheet.Columns[3].ColumnWidth = 50;
            xlWorkSheet.Columns[4].ColumnWidth = 15;
            xlWorkSheet.Columns[5].ColumnWidth = 50;
            xlWorkSheet.Columns[6].ColumnWidth = 20;
            xlWorkSheet.Columns[7].ColumnWidth = 10;
            xlWorkSheet.Columns[8].ColumnWidth = 10;
            xlWorkSheet.Columns[9].ColumnWidth = 10;
            xlWorkSheet.Columns[10].ColumnWidth = 10;
            xlWorkSheet.Columns[11].ColumnWidth = 11;
            xlWorkSheet.Columns[12].ColumnWidth = 11;
            xlWorkSheet.Columns[13].ColumnWidth = 11;
            xlWorkSheet.Columns[14].ColumnWidth = 11;
            xlWorkSheet.Columns[15].ColumnWidth = 11;
            xlWorkSheet.Columns[16].ColumnWidth = 11;
            xlWorkSheet.Columns[17].ColumnWidth = 11;
            xlWorkSheet.Columns[18].ColumnWidth = 11;
            xlWorkSheet.Columns[19].ColumnWidth = 11;
            xlWorkSheet.Columns[20].ColumnWidth = 11;
            xlWorkSheet.Columns[21].ColumnWidth = 11;
            xlWorkSheet.Columns[22].ColumnWidth = 11;
            xlWorkSheet.Columns[23].ColumnWidth = 11;
            xlWorkSheet.Columns[24].ColumnWidth = 11;
            xlWorkSheet.Columns[25].ColumnWidth = 11;
            xlWorkSheet.Columns[26].ColumnWidth = 11;
            xlWorkSheet.Columns[27].ColumnWidth = 11;
            xlWorkSheet.Columns[28].ColumnWidth = 11;
            xlWorkSheet.Columns[29].ColumnWidth = 11;
            xlWorkSheet.Columns[30].ColumnWidth = 11;
            xlWorkSheet.Columns[31].ColumnWidth = 11;


            var Rang1 = xlWorkSheet.get_Range("A1", "A1");
            Rang1.Interior.Color = Color.LightGreen;

            xlWorkSheet.Cells[1, 2].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 3].Cells.Interior.Color = Color.LightSkyBlue;

            xlWorkSheet.Cells[1, 4].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 5].Cells.Interior.Color = Color.LightSalmon;

            var Rang2 = xlWorkSheet.get_Range("F1", "F1");
            Rang2.Interior.Color = Color.LightGreen;

            var Rang3 = xlWorkSheet.get_Range("G1", "G1");
            Rang3.Interior.Color = Color.LightSkyBlue;

            var Rang4 = xlWorkSheet.get_Range("H1", "H1");
            Rang4.Interior.Color = Color.LightSalmon;

            var Rang5 = xlWorkSheet.get_Range("I1", "I1");
            Rang5.Interior.Color = Color.LightSkyBlue;

            var Rang6 = xlWorkSheet.get_Range("J1", "J1");
            Rang6.Interior.Color = Color.LightGreen;

            var Rang7 = xlWorkSheet.get_Range("K1", "K1");
            Rang7.Interior.Color = Color.LightSalmon;

            var Rang9 = xlWorkSheet.get_Range("L1", "L1");
            Rang9.Interior.Color = Color.LightGray;

            var Rang8 = xlWorkSheet.get_Range("M1", "M1");
            Rang8.WrapText = true;
            Rang8.Font.Bold = true;
            Rang8.Font.Color = Color.Black;
            Rang8.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang8.Font.Underline = true;
            Rang8.HorizontalAlignment = HorizontalAlignment.Center;
            Rang8.Interior.Color = Color.LightGray;

            xlWorkSheet.Cells[1, 14].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 15].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 16].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 17].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 18].Cells.Interior.Color = Color.LightGray;
            xlWorkSheet.Cells[1, 19].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 20].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 21].Cells.Interior.Color = Color.LightGray;
            xlWorkSheet.Cells[1, 22].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 23].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 24].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 25].Cells.Interior.Color = Color.LightGray;
            xlWorkSheet.Cells[1, 26].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 27].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 28].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 29].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 30].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 31].Cells.Interior.Color = Color.LightGray;



            String Rango = "A2" + ":" + "AE" + rt;
            Excel.Range SourceRange = (Excel.Range)xlWorkSheet.get_Range("A2", "AE" + rt); // or whatever range you want here
            FormatAsTable(SourceRange, "Table1", "TableStyleMedium2");

            xlWorkSheet.Rows[2].Hidden = true;

            xlWorkSheet.Columns["A"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["G"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["K:M"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["O:P"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["T:V"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["Y:AE"].HorizontalAlignment  = XlHAlign.xlHAlignCenter;

            xlWorkSheet.Columns["A"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["O"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["P"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["AC"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["AD"].NumberFormat = "00-00-00";

            var range = xlWorkSheet.get_Range("A3", "A3");
            range.Select();

            string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
            xlApp.ActiveWindow.Zoom = 80;
            xlWorkBook.SaveAs("C:\\Reportes\\NotasCredito" + Hoy + ".xlsx", Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            string comando = @"C:\\Reportes\\NotasCredito" + Hoy + ".xlsx";
            ExecuteCommand(comando);
        }

        static void ExecuteCommand(string _Command)
        {
            //Indicamos que deseamos inicializar el proceso cmd.exe junto a un comando de arranque. 
            //(/C, le indicamos al proceso cmd que deseamos que cuando termine la tarea asignada se cierre el proceso).
            //Para mas informacion consulte la ayuda de la consola con cmd.exe /? 
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;
            //Inicializa el proceso
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            string result = proc.StandardOutput.ReadToEnd();
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        public void FormatAsTable(Excel.Range SourceRange, string TableName, string TableStyleName)
        {
            SourceRange.Worksheet.ListObjects.Add(XlListObjectSourceType.xlSrcRange,
            SourceRange, System.Type.Missing, XlYesNoGuess.xlYes, System.Type.Missing).Name =
                TableName;
            SourceRange.Select();
            SourceRange.Worksheet.ListObjects[TableName].TableStyle = TableStyleName;
            SourceRange.Worksheet.ListObjects[TableName].ShowAutoFilter = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowHeaders = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowTotals = false;
        }

        private void tbProveedor_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindCalAlloc();
                tbProveedor.Focus();
            }
        }

        private void tbNombre_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindCalAlloc();
                tbNombre.Focus();
            }
        }

        private void tbEstilo_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindCalAlloc();
                tbEstilo.Focus();
            }
        }

        private void tbDescripcion_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindCalAlloc();
                tbDescripcion.Focus();
            }
        }

    }
}
