﻿namespace MmsWin.Front {
    
    
    public partial class dsSAT177MMNETLIB {
    }
}

namespace MmsWin.Front.dsSAT177MMNETLIBTableAdapters {
    partial class SAT177RPCCPTableAdapter
    {
    }
    
    
    public partial class SAT177SCCRV1TableAdapter {
    }
}
