﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;

using System.Reflection;

using System.Diagnostics; 

//using System.Diagnostics; 

namespace MmsWin.Front.Convenio
{
    public partial class CxP : Form
    {

        int nr;
        bool ind;
        bool Carga;
        string ParUser;
        string marca;
        string FechaCal;
        string FechaFmt;
        String FchDe;
        String FchHas;
        long FchDeN;
        long FchHasN;
        string comprador;
        int dgvOffset;
        int dgvOffset2;

        public CxP()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }

        private void CxP_Load(object sender, EventArgs e)
        {
            Carga = false;

            MmsWin.Front.Utilerias.VarTem.tmpPrv = "";
            MmsWin.Front.Utilerias.VarTem.tmpSty = "";
            MmsWin.Front.Utilerias.VarTem.tmpFchRev = "";
            MmsWin.Front.Utilerias.VarTem.tmpMarca = "";
            MmsWin.Front.Utilerias.VarTem.tmpComprador = "";

            marca = "999";
            comprador = "999";
       
            tbDesde.Text = "0000000000";

            FchDe = "10/10/2000";
            FchHas = "10/10/2000";
            tbDesde.Text = FchDe;
            tbHasta.Text = FchHas;

            try
            {
                System.Data.DataTable tbFechaInicial = null;
                tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();

                foreach (DataRow row in tbFechaInicial.Rows)
                {
                    tbDesde.Text = row["DSPFCH"].ToString();
                    FechaCal = tbDesde.Text;
                    FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                    tbDesde.Text = FechaFmt.ToString();
                    tbHasta.Text = FechaFmt.ToString();

                    FechaCal = tbDesde.Text;
                    FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                    FchDeN = long.Parse(FechaFmt.ToString());
                    FchDe = FechaFmt.ToString();

                    FechaCal = tbHasta.Text;
                    FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                    FchHasN = long.Parse(FechaFmt.ToString());
                    FchHas = FechaFmt.ToString();
                }




            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // Carga de Marcatry
            try 
            {
                BindMarca();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            // Carga de Compradores
            try
            {
                BindCompradores();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            // Seguridad...
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("Convenio", "CxP", ParUser);

            comprador = MmsWin.Front.Utilerias.VarTem.tmpUSRCOM;
            cbCompradores.SelectedValue = comprador;
            marca = MmsWin.Front.Utilerias.VarTem.tmpUSRMAR;
            cbMarca.SelectedValue = marca;

            // Carga de Datos
            try
            {
                Carga = true;
                BindCxP();
                // Recupera Marca y Comprador                                                        
                MmsWin.Front.Utilerias.VarTem.tmpMarca = cbMarca.SelectedValue.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpComprador = cbCompradores.SelectedValue.ToString(); 
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void CxP_Resize(object sender, EventArgs e)
        {
            dgvGridView.Width = this.Width - dgvOffset;
            dgvGridView.Height = this.Height - dgvOffset2;
        }

        protected void BindMarca()
        {
            try
            {
                cbMarca.DataSource = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();
                cbMarca.DisplayMember = "Value";
                cbMarca.ValueMember = "Key";
                marca = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void BindCompradores()
        {
            try
            {
                cbCompradores.DataSource = MmsWin.Negocio.Catalogos.Compradores.GetInstance().ObtenCompradors().ToList();
                cbCompradores.DisplayMember = "Value";
                cbCompradores.ValueMember = "Key";
                comprador = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        // Seguridad                                                                                
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                         
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvGridView.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvGridView.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenu.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenu.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        protected void BindCxP()
        {
            if (Carga == true)
            {
                nr = 0;
                this.Cursor = Cursors.WaitCursor;
                dgvGridView.DataSource       = null;
                System.Data.DataTable dtCxP = null;
                try
                {
                    string Folio            = tbFolio.Text;
                    string ParPrv           = tbPrv.Text;
                    string ParNombre        = tbNombre.Text;
                    string ParEstilo        = tbEstilo.Text;
                    string ParDescripcion   = tbDescripcion.Text;
                    string ParFechaRevision = tbFchRevision.Text;
                    string ParFechaReprog   = tbFchReprog.Text;

                    dtCxP = MmsWin.Negocio.CxP.CxP.GetInstance().ObtenCxP(marca, FchDe, FchHas, Folio, comprador, ParPrv, ParNombre, ParEstilo, ParDescripcion, ParFechaRevision);

                }

                catch { }
                finally { }

                if (dtCxP != null)
                {
                    if (dtCxP.Rows.Count > 0)
                    {
                        dgvGridView.DataSource = dtCxP;
                        SetFontAndColors();
                        rowStyle();

                        nr = dgvGridView.RowCount;
                        this.Text = "Cuentas x Pagar / " + " " + (nr).ToString() + " Registro(s)";
                        SetDoubleBuffered(dgvGridView);
                        // Seguridad...
                        ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        Seguridad("Convenio", "CxP", ParUser);
                    }
                }
                this.Cursor = Cursors.Default;
            }
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }
        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvGridView.Columns[3].Frozen = true;

            dgvGridView.Columns["CXPNMR"].HeaderText   = "Marca ";
            dgvGridView.Columns["CXPMAR"].HeaderText   = "Nombre ";
            dgvGridView.Columns["CXPFPR"].HeaderText   = "Fecha ";
            dgvGridView.Columns["CXPPRV"].HeaderText   = "Proveedor ";
            dgvGridView.Columns["CXPPRN"].HeaderText   = "Nombre ";
            dgvGridView.Columns["CXPSTY"].HeaderText   = "Estilo ";
            dgvGridView.Columns["CXPDES"].HeaderText   = "Descripción ";
            dgvGridView.Columns["CXPORD"].HeaderText   = "Orden ";
            dgvGridView.Columns["CXPFOR"].HeaderText   = "Fecha Orden ";
            dgvGridView.Columns["CXPPZO"].HeaderText   = "Piezas Ordenadas ";
            dgvGridView.Columns["CXPCST"].HeaderText   = "Costo ";
            dgvGridView.Columns["CXPCAL"].HeaderText   = "Calificación ";
            dgvGridView.Columns["CXPDGA"].HeaderText   = "Devolución Garantizada ";
            dgvGridView.Columns["CXPFCA"].HeaderText   = "Fecha Calificación ";
            dgvGridView.Columns["CXPFCR"].HeaderText   = "Fecha Corte ";
            dgvGridView.Columns["CXPDAS"].HeaderText   = "Dias ";
            dgvGridView.Columns["CXPATG"].HeaderText   = "Antiguedad ";
            dgvGridView.Columns["CXPATG2"].HeaderText  = "Antiguedad2 ";
            dgvGridView.Columns["CXPMES"].HeaderText   = "Mes ";
            dgvGridView.Columns["CXPANI"].HeaderText   = "Año ";
            dgvGridView.Columns["CXPSTS"].HeaderText   = "Estatus ";
            dgvGridView.Columns["CXPMRC"].HeaderText   = "Mes Recibo ";
            dgvGridView.Columns["CXPPZR"].HeaderText   = "Piezas Recibidas ";
            dgvGridView.Columns["CXPFIL"].HeaderText   = "% Fill Rate ";
            dgvGridView.Columns["CXPPZP"].HeaderText   = "Piezas % ";
            dgvGridView.Columns["CXPPZD"].HeaderText   = "Piezas Diferencia ";
            dgvGridView.Columns["CXPCSP"].HeaderText   = "Costo Penalización ";
            dgvGridView.Columns["CXPPPE"].HeaderText   = "% Penalización ";
            dgvGridView.Columns["CXPTTP"].HeaderText   = "Total Penalización ";
            dgvGridView.Columns["CXPCMP"].HeaderText   = "Comparativo ";
            dgvGridView.Columns["CXPCID"].HeaderText   = "Comprador Id ";
            dgvGridView.Columns["CXPDCP"].HeaderText   = "Comprador ";
            dgvGridView.Columns["CXPDEP"].HeaderText   = "Depto ";
            dgvGridView.Columns["CXPSDP"].HeaderText   = "Sup_Dep ";
            dgvGridView.Columns["CXPCLS"].HeaderText   = "Clase ";
            dgvGridView.Columns["CXPSCL"].HeaderText   = "Sub_Cls ";
            dgvGridView.Columns["CXPDEPD"].HeaderText  = "Departamento ";
            dgvGridView.Columns["CXPSDPD"].HeaderText  = "Sup_Departamento ";
            dgvGridView.Columns["CXPCLSD"].HeaderText  = "Clase ";
            dgvGridView.Columns["CXPSCLD"].HeaderText  = "Sub_Clase ";
            dgvGridView.Columns["CXPTAB"].HeaderText   = "Tabla de Acción ";
            dgvGridView.Columns["CXPFOLID"].HeaderText = "Folio ";
            dgvGridView.Columns["CXPPREF"].HeaderText  = "Prefijo ";
            dgvGridView.Columns["CXPNFOL"].HeaderText  = "No Folio ";
            dgvGridView.Columns["CXPCCP"].HeaderText   = "Id  ";
            dgvGridView.Columns["CXPCCD"].HeaderText   = "Concepto Desc ";
            dgvGridView.Columns["CXPSUB"].HeaderText   = "Sub Total ";
            dgvGridView.Columns["CXPIVA"].HeaderText   = "Iva  ";
            dgvGridView.Columns["CXPTOT"].HeaderText   = "Total ";
            dgvGridView.Columns["CXPSUBF"].HeaderText  = "Sub Total ";
            dgvGridView.Columns["CXPIVAF"].HeaderText  = "Iva ";
            dgvGridView.Columns["CXPTOTF"].HeaderText  = "Total ";
            dgvGridView.Columns["CXPCK1"].HeaderText   = "Chek 01 ";
            dgvGridView.Columns["CXPCK2"].HeaderText   = "Chek 02 ";
            dgvGridView.Columns["CXPCK3"].HeaderText   = "Chek 03 ";
            dgvGridView.Columns["CXPCK4"].HeaderText   = "Chek 04 ";
            dgvGridView.Columns["CXPCK5"].HeaderText   = "Chek 05 ";
            dgvGridView.Columns["CXPUAL"].HeaderText   = "User Alta ";
            dgvGridView.Columns["CXPFAL"].HeaderText   = "Fecha Alta ";
            dgvGridView.Columns["CXPHAL"].HeaderText   = "Hora Alta ";
            dgvGridView.Columns["CXPUC1"].HeaderText   = "User Check1 ";
            dgvGridView.Columns["CXPFC1"].HeaderText   = "Fecha Check1 ";
            dgvGridView.Columns["CXPHC1"].HeaderText   = "Hora Check1 ";
            dgvGridView.Columns["CXPUC2"].HeaderText   = "User Check2 ";
            dgvGridView.Columns["CXPFC2"].HeaderText   = "Fecha Check2 ";
            dgvGridView.Columns["CXPHC2"].HeaderText   = "Hora Check2 ";
            dgvGridView.Columns["CXPUC3"].HeaderText   = "User Check3 ";
            dgvGridView.Columns["CXPFC3"].HeaderText   = "Fecha Check3 ";
            dgvGridView.Columns["CXPHC3"].HeaderText   = "Hora Check3 ";
            dgvGridView.Columns["CXPUC4"].HeaderText   = "User Check4 ";
            dgvGridView.Columns["CXPFC4"].HeaderText   = "Fecha Check4 ";
            dgvGridView.Columns["CXPHC4"].HeaderText   = "Hora Check4 ";
            dgvGridView.Columns["CXPUC5"].HeaderText   = "User Check5 ";
            dgvGridView.Columns["CXPFC5"].HeaderText   = "Fecha Check5  ";
            dgvGridView.Columns["CXPHC5"].HeaderText   = "Hora Check5 ";


            dgvGridView.Columns["CXPNMR"].Width   = 40;
            dgvGridView.Columns["CXPMAR"].Width   = 50;
            dgvGridView.Columns["CXPFPR"].Width   = 80;
            dgvGridView.Columns["CXPPRV"].Width   = 40;
            dgvGridView.Columns["CXPPRN"].Width   = 200;
            dgvGridView.Columns["CXPSTY"].Width   = 80;
            dgvGridView.Columns["CXPDES"].Width   = 200;
            dgvGridView.Columns["CXPORD"].Width   = 70;
            dgvGridView.Columns["CXPFOR"].Width   = 80;
            dgvGridView.Columns["CXPPZO"].Width   = 80;
            dgvGridView.Columns["CXPCST"].Width   = 50;
            dgvGridView.Columns["CXPCAL"].Width   = 80;
            dgvGridView.Columns["CXPDGA"].Width   = 80;
            dgvGridView.Columns["CXPFCA"].Width   = 80;
            dgvGridView.Columns["CXPFCR"].Width   = 80;
            dgvGridView.Columns["CXPDAS"].Width   = 80;
            dgvGridView.Columns["CXPATG"].Width   = 80;
            dgvGridView.Columns["CXPATG2"].Width  = 80;
            dgvGridView.Columns["CXPMES"].Width   = 80;
            dgvGridView.Columns["CXPANI"].Width   = 80;
            dgvGridView.Columns["CXPSTS"].Width   = 80;
            dgvGridView.Columns["CXPMRC"].Width   = 80;
            dgvGridView.Columns["CXPPZR"].Width   = 80;
            dgvGridView.Columns["CXPFIL"].Width   = 80;
            dgvGridView.Columns["CXPPZP"].Width   = 80;
            dgvGridView.Columns["CXPPZD"].Width   = 80;
            dgvGridView.Columns["CXPCSP"].Width   = 80;
            dgvGridView.Columns["CXPPPE"].Width   = 80;
            dgvGridView.Columns["CXPTTP"].Width   = 80;
            dgvGridView.Columns["CXPCMP"].Width   = 80;
            dgvGridView.Columns["CXPCID"].Width   = 40;
            dgvGridView.Columns["CXPDCP"].Width   = 80;
            dgvGridView.Columns["CXPDEP"].Width   = 40;
            dgvGridView.Columns["CXPSDP"].Width   = 40;
            dgvGridView.Columns["CXPCLS"].Width   = 40;
            dgvGridView.Columns["CXPSCL"].Width   = 40;
            dgvGridView.Columns["CXPDEPD"].Width  = 80;
            dgvGridView.Columns["CXPSDPD"].Width  = 80;
            dgvGridView.Columns["CXPCLSD"].Width  = 80;
            dgvGridView.Columns["CXPSCLD"].Width  = 80;
            dgvGridView.Columns["CXPTAB"].Width   = 40;
            dgvGridView.Columns["CXPFOLID"].Width = 80;
            dgvGridView.Columns["CXPPREF"].Width  = 80;
            dgvGridView.Columns["CXPNFOL"].Width  = 80;
            dgvGridView.Columns["CXPCCP"].Width   = 80;
            dgvGridView.Columns["CXPCCD"].Width   = 80;
            dgvGridView.Columns["CXPSUB"].Width   = 80;
            dgvGridView.Columns["CXPIVA"].Width   = 80;
            dgvGridView.Columns["CXPTOT"].Width   = 80;
            dgvGridView.Columns["CXPSUBF"].Width  = 80;
            dgvGridView.Columns["CXPIVAF"].Width  = 80;
            dgvGridView.Columns["CXPTOTF"].Width  = 80;
            dgvGridView.Columns["CXPCK1"].Width   = 80;
            dgvGridView.Columns["CXPCK2"].Width   = 80;
            dgvGridView.Columns["CXPCK3"].Width   = 80;
            dgvGridView.Columns["CXPCK4"].Width   = 80;
            dgvGridView.Columns["CXPCK5"].Width   = 80;
            dgvGridView.Columns["CXPUAL"].Width   = 80;
            dgvGridView.Columns["CXPFAL"].Width   = 80;
            dgvGridView.Columns["CXPHAL"].Width   = 80;
            dgvGridView.Columns["CXPUC1"].Width   = 80;
            dgvGridView.Columns["CXPFC1"].Width   = 80;
            dgvGridView.Columns["CXPHC1"].Width   = 80;
            dgvGridView.Columns["CXPUC2"].Width   = 80;
            dgvGridView.Columns["CXPFC2"].Width   = 80;
            dgvGridView.Columns["CXPHC2"].Width   = 80;
            dgvGridView.Columns["CXPUC3"].Width   = 80;
            dgvGridView.Columns["CXPFC3"].Width   = 80;
            dgvGridView.Columns["CXPHC3"].Width   = 80;
            dgvGridView.Columns["CXPUC4"].Width   = 80;
            dgvGridView.Columns["CXPFC4"].Width   = 80;
            dgvGridView.Columns["CXPHC4"].Width   = 80;
            dgvGridView.Columns["CXPUC5"].Width   = 80;
            dgvGridView.Columns["CXPFC5"].Width   = 80;
            dgvGridView.Columns["CXPHC5"].Width   = 80;

            dgvGridView.Columns["CXPNMR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPMAR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPFPR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPPRV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPPRN"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CXPSTY"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CXPDES"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CXPORD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPFOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPPZO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPCST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPCAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPDGA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CXPFCA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPFCR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPDAS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPATG"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPATG2"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPMES"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CXPANI"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPSTS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPMRC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPPZR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPFIL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPPZP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPPZD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPCSP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPPPE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPTTP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPCMP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPCID"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPDCP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CXPDEP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPSDP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPCLS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPSCL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPDEPD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CXPSDPD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CXPCLSD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CXPSCLD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CXPTAB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPFOLID"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CXPPREF"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CXPNFOL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPCCP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPCCD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CXPSUB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPIVA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPTOT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPSUBF"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPIVAF"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPTOTF"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPCK1"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPCK2"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPCK3"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPCK4"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPCK5"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["CXPUAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPFAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPHAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPUC1"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPFC1"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPHC1"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPUC2"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPFC2"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPHC2"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPUC3"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPFC3"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPHC3"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPUC4"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPFC4"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPHC4"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPUC5"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPFC5"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CXPHC5"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;


            dgvGridView.Columns["CXPNMR"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPMAR"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPFPR"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPPRV"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPPRN"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPSTY"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPDES"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPORD"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPFOR"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPPZO"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPCST"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPCAL"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPDGA"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPFCA"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPFCR"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPDAS"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPATG"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPATG2"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPMES"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPANI"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPSTS"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPMRC"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPPZR"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPFIL"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPPZP"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPPZD"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPCSP"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPPPE"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPTTP"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPCMP"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPCID"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPDCP"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPDEP"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPSDP"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPCLS"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPSCL"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPDEPD"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPSDPD"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPCLSD"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPSCLD"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPTAB"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPFOLID"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPPREF"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPNFOL"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPCCP"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPCCD"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPSUB"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPIVA"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPTOT"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPSUBF"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPIVAF"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPTOTF"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPCK1"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPCK2"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPCK3"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPCK4"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPCK5"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPUAL"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPFAL"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPHAL"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPUC1"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPFC1"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPHC1"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPUC2"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPFC2"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPHC2"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPUC3"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPFC3"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPHC3"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPUC4"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPFC4"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPHC4"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPUC5"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPFC5"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["CXPHC5"].HeaderCell.Style.BackColor = Color.LightSalmon;

            //dgvGridView.Columns["CXPNMR"].Width = 40;
            //dgvGridView.Columns["CXPMAR"].Width = 50;
            dgvGridView.Columns["CXPFPR"].DefaultCellStyle.Format = "20##-##-##";
            //dgvGridView.Columns["CXPPRV"].Width = 40;
            //dgvGridView.Columns["CXPPRN"].Width = 200;
            //dgvGridView.Columns["CXPSTY"].Width = 80;
            //dgvGridView.Columns["CXPDES"].Width = 200;
            //dgvGridView.Columns["CXPORD"].Width = 70;
            dgvGridView.Columns["CXPFOR"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns["CXPPZO"].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns["CXPCST"].DefaultCellStyle.Format = "###,##0.00";
            //dgvGridView.Columns["CXPCAL"].Width = 80;
            //dgvGridView.Columns["CXPDGA"].Width = 80;
            dgvGridView.Columns["CXPFCA"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns["CXPFCR"].DefaultCellStyle.Format = "20##-##-##";
            //dgvGridView.Columns["CXPDAS"].Width = 80;
            //dgvGridView.Columns["CXPATG"].Width = 80;
            //dgvGridView.Columns["CXPATG2"].Width = 80;
            //dgvGridView.Columns["CXPMES"].Width = 80;
            //dgvGridView.Columns["CXPANI"].Width = 80;
            //dgvGridView.Columns["CXPSTS"].Width = 80;
            //dgvGridView.Columns["CXPMRC"].Width = 80;
            //dgvGridView.Columns["CXPPZR"].Width = 80;
            dgvGridView.Columns["CXPFIL"].DefaultCellStyle.Format = "###,##0.00";
            //dgvGridView.Columns["CXPPZP"].Width = 80;
            //dgvGridView.Columns["CXPPZD"].Width = 80;
            dgvGridView.Columns["CXPCSP"].DefaultCellStyle.Format = "###,##0.00";
            dgvGridView.Columns["CXPPPE"].DefaultCellStyle.Format = "###,##0.00";
            dgvGridView.Columns["CXPTTP"].DefaultCellStyle.Format = "###,##0.00";
            dgvGridView.Columns["CXPCMP"].DefaultCellStyle.Format = "###,##0.00";
            //dgvGridView.Columns["CXPCID"].Width = 40;
            //dgvGridView.Columns["CXPDCP"].Width = 80;
            //dgvGridView.Columns["CXPDEP"].Width = 40;
            //dgvGridView.Columns["CXPSDP"].Width = 40;
            //dgvGridView.Columns["CXPCLS"].Width = 40;
            //dgvGridView.Columns["CXPSCL"].Width = 40;
            //dgvGridView.Columns["CXPDEPD"].Width = 80;
            //dgvGridView.Columns["CXPSDPD"].Width = 80;
            //dgvGridView.Columns["CXPCLSD"].Width = 80;
            //dgvGridView.Columns["CXPSCLD"].Width = 80;
            //dgvGridView.Columns["CXPTAB"].Width = 40;
            //dgvGridView.Columns["CXPFOLID"].Width = 80;
            //dgvGridView.Columns["CXPPREF"].Width = 80;
            //dgvGridView.Columns["CXPNFOL"].Width = 80;
            //dgvGridView.Columns["CXPCCP"].Width = 80;
            //dgvGridView.Columns["CXPCCD"].Width = 80;
            dgvGridView.Columns["CXPSUB"].DefaultCellStyle.Format = "###,##0.00";
            dgvGridView.Columns["CXPIVA"].DefaultCellStyle.Format = "###,##0.00";
            dgvGridView.Columns["CXPTOT"].DefaultCellStyle.Format = "###,##0.00";
            dgvGridView.Columns["CXPSUBF"].DefaultCellStyle.Format = "###,##0.00";
            dgvGridView.Columns["CXPIVAF"].DefaultCellStyle.Format = "###,##0.00";
            dgvGridView.Columns["CXPTOTF"].DefaultCellStyle.Format = "###,##0.00";
            //dgvGridView.Columns["CXPCK1"].Width = 80;
            //dgvGridView.Columns["CXPCK2"].Width = 80;
            //dgvGridView.Columns["CXPCK3"].Width = 80;
            //dgvGridView.Columns["CXPCK4"].Width = 80;
            //dgvGridView.Columns["CXPCK5"].Width = 80;
            //dgvGridView.Columns["CXPUAL"].Width = 80;
            dgvGridView.Columns["CXPFAL"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns["CXPHAL"].DefaultCellStyle.Format = "##:##:##";
            //dgvGridView.Columns["CXPUC1"].Width = 80;
            dgvGridView.Columns["CXPFC1"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns["CXPHC1"].DefaultCellStyle.Format = "##:##:##";
            //dgvGridView.Columns["CXPUC2"].Width = 80;
            dgvGridView.Columns["CXPFC2"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns["CXPHC2"].DefaultCellStyle.Format = "##:##:##";
            //dgvGridView.Columns["CXPUC3"].Width = 80;
            dgvGridView.Columns["CXPFC3"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns["CXPHC3"].DefaultCellStyle.Format = "##:##:##";
            //dgvGridView.Columns["CXPUC4"].Width = 80;
            dgvGridView.Columns["CXPFC4"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns["CXPHC4"].DefaultCellStyle.Format = "##:##:##";
            //dgvGridView.Columns["CXPUC5"].Width = 80;
            dgvGridView.Columns["CXPFC5"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns["CXPHC5"].DefaultCellStyle.Format = "##:##:##";

            //dgvGridView.Columns["CDOPRV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            //dgvGridView.Columns["CDOPRN"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            //dgvGridView.Columns["CDOCID"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            //dgvGridView.Columns["CDOPRV"].HeaderCell.Style.BackColor = Color.LightSalmon;

            //dgvGridView.Columns["CDOCID"].HeaderCell.Style.BackColor   = Color.LightGreen;
            //dgvGridView.Columns["CDODCP"].HeaderCell.Style.BackColor   = Color.LightSeaGreen;
            //dgvGridView.Columns["CDOFRV"].HeaderCell.Style.BackColor   = Color.LightCoral;
            //dgvGridView.Columns["CDOFOLID"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            //dgvGridView.Columns["CDONFOL"].HeaderCell.Style.BackColor  = Color.LightSlateGray;
            //dgvGridView.Columns["CDOCCP"].HeaderCell.Style.BackColor   = Color.LightCoral;


            dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            dgvGridView.EnableHeadersVisualStyles = false;
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }

        private void CxP_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("Convenio", "CxP", ParUser);
            }
        }
        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            //
            string NomCol;
            Int32 NoCol = dgvGridView.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvGridView.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      
            //
            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void dgvGridView_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F6)
            {
                try
                {
                    Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                                  "Nota").SingleOrDefault<Form>();
                    {
                        if (existe != null)
                        {
                            MessageBox.Show("La Ventana ya esta abierta...");
                        }
                        else
                        {
                            ValidaReprog();
                            if (ind == true)
                            {
                                Reprog i = new Reprog();
                                i.Show();
                            }
                            else
                            {
                                MessageBox.Show("Se debe seleccionar Marca y Comprador ...");
                            }
                        }
                    }
                }
                catch { }
                finally { }
            }

            if (e.KeyCode == Keys.F5)
            {
                BindCxP();
            }


        }

        private void ValidaReprog()
        {
            string IndMarca = MmsWin.Front.Utilerias.VarTem.tmpMarca;
            string IndComprador = MmsWin.Front.Utilerias.VarTem.tmpComprador;

            if (IndMarca == "999" | IndComprador == "999" | IndMarca == "" | IndComprador == "")
            {
                ind = false;
            }
            else
            {
                ind = true;
            }
        }

        private void dgvGridView_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                var hti = dgvGridView.HitTest(e.X, e.Y);
                int Row = e.RowIndex;
                int Col = e.ColumnIndex;
            }
           }

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            marca = " ";
            ComboBox cmbMarca = (ComboBox)sender;
            marca = cmbMarca.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpMarca = cbMarca.SelectedValue.ToString();

            BindCxP();
        }

        private void cbCompradores_SelectedValueChanged(object sender, EventArgs e)
        {
            comprador = " ";
            ComboBox cmbComprador = (ComboBox)sender;
            comprador = cmbComprador.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpComprador = cmbComprador.SelectedValue.ToString();

            BindCxP();
        }

        private void dgvGridView_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                dgvGridView.Select();
                MmsWin.Front.Utilerias.VarTem.tmpPrv = this.dgvGridView.CurrentRow.Cells[0].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpNom = this.dgvGridView.CurrentRow.Cells[1].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpSty = this.dgvGridView.CurrentRow.Cells[2].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpDes = this.dgvGridView.CurrentRow.Cells[3].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.tmpFchRev = this.dgvGridView.CurrentRow.Cells[4].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpFchReprog = this.dgvGridView.CurrentRow.Cells[5].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpCompDesc = this.dgvGridView.CurrentRow.Cells[6].Value.ToString();

                MmsWin.Front.Utilerias.Fotos.numPrv = this.dgvGridView.CurrentRow.Cells[0].Value.ToString();
                MmsWin.Front.Utilerias.Fotos.numSty = this.dgvGridView.CurrentRow.Cells[2].Value.ToString();
            }
            catch { }
        }

        private void fotoTSMI_Click(object sender, EventArgs e)
        {
            MuestraFoto();
        }

        private void MuestraFoto()
        {
            try
            {
                MmsWin.Front.Utilerias.Fotos i = new MmsWin.Front.Utilerias.Fotos();
                i.Show();
            }
            catch { }
            finally { }
        }

        private void pbExcel_Click(object sender, EventArgs e)
        {
            System.Data.DataTable dtDowns = (System.Data.DataTable)(dgvGridView.DataSource);
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            int nc = dgvGridView.Columns.Count;


            for (int ii = 1; ii <= nc; ii++)
            {
                xlWorkSheet.Cells[1, ii] = dgvGridView.Columns[ii - 1].HeaderText;
            }

            System.Data.DataTable dtCalificaciones = (System.Data.DataTable)(dgvGridView.DataSource);
            int nr = dgvGridView.RowCount;

            int r = 0;
            int rt = 3;
            foreach (DataRow row in dtCalificaciones.Rows)
            {
                var gsArray = new[]       {
                                                    row["REPPRV"],
                                                    row["REPPDS"],
                                                    row["REPSTY"],
                                                    row["REPSDS"],
                                                    row["REPFRV"],
                                                    row["REPFRP"],
                                                    row["REPCDS"],
                                                    row["REPOBS"],
                                                    row["REPMAR"],
                                                    row["REPCOM"],
                                                    row["REPFCHA"],
                                                    row["REPHORA"],
                                                    row["REPUSR"]
                                                   };

                Range rng = xlWorkSheet.get_Range("A" + rt, "M" + rt);
                rng.Value = gsArray;

                this.Text = "CxPes / " + " " + (r += 1).ToString() + " Registro(s) de " + nr;

                rt++;
            }

            xlWorkSheet.Columns[1].ColumnWidth = 5;
            xlWorkSheet.Columns[2].ColumnWidth = 45;
            xlWorkSheet.Columns[3].ColumnWidth = 10;
            xlWorkSheet.Columns[4].ColumnWidth = 45;
            xlWorkSheet.Columns[5].ColumnWidth = 15;
            xlWorkSheet.Columns[6].ColumnWidth = 15;
            xlWorkSheet.Columns[7].ColumnWidth = 35;
            xlWorkSheet.Columns[8].ColumnWidth = 45;
            xlWorkSheet.Columns[9].ColumnWidth = 10;
            xlWorkSheet.Columns[10].ColumnWidth = 2;
            xlWorkSheet.Columns[11].ColumnWidth = 11;
            xlWorkSheet.Columns[12].ColumnWidth = 11;
            xlWorkSheet.Columns[13].ColumnWidth = 11;

            var Rang1 = xlWorkSheet.get_Range("A1", "A1");
            Rang1.Interior.Color = Color.LightGreen;

            xlWorkSheet.Cells[1, 2].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 3].Cells.Interior.Color = Color.LightSkyBlue;

            xlWorkSheet.Cells[1, 4].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 5].Cells.Interior.Color = Color.LightSalmon;

            var Rang2 = xlWorkSheet.get_Range("F1", "F1");
            Rang2.Interior.Color = Color.LightGreen;

            var Rang3 = xlWorkSheet.get_Range("G1", "G1");
            Rang3.Interior.Color = Color.LightSkyBlue;

            var Rang4 = xlWorkSheet.get_Range("H1", "H1");
            Rang4.Interior.Color = Color.LightSalmon;

            var Rang5 = xlWorkSheet.get_Range("I1", "I1");
            Rang5.Interior.Color = Color.LightSkyBlue;

            var Rang6 = xlWorkSheet.get_Range("J1", "J1");
            Rang6.Interior.Color = Color.LightGreen;

            var Rang7 = xlWorkSheet.get_Range("K1", "K1");
            Rang7.Interior.Color = Color.LightSalmon;

            var Rang9 = xlWorkSheet.get_Range("L1", "L1");
            Rang9.Interior.Color = Color.LightGray;

            var Rang8 = xlWorkSheet.get_Range("M1", "M1");
            Rang8.WrapText = true;
            Rang8.Font.Bold = true;
            Rang8.Font.Color = Color.Black;
            Rang8.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang8.Font.Underline = true;
            Rang8.HorizontalAlignment = HorizontalAlignment.Center;
            Rang8.Interior.Color = Color.LightGray;

            String Rango = "A2" + ":" + "M" + rt;
            Excel.Range SourceRange = (Excel.Range)xlWorkSheet.get_Range("A2", "M" + rt); // or whatever range you want here
            FormatAsTable(SourceRange, "Table1", "TableStyleMedium2");

            xlWorkSheet.Rows[2].Hidden = true;

            xlWorkSheet.Columns["A"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["C"].HorizontalAlignment = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["E"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["F"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["I"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["J"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["K"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["L"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["M"].HorizontalAlignment = XlHAlign.xlHAlignCenter;


            xlWorkSheet.Columns["E"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["F"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["K"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["L"].NumberFormat = "00-00-00";

            var range = xlWorkSheet.get_Range("A3", "A3");
            range.Select();

            string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
            xlApp.ActiveWindow.Zoom = 80;
            xlWorkBook.SaveAs("C:\\Reportes\\CxPes" + Hoy + ".xlsx", Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            string comando = @"C:\\Reportes\\CxP" + Hoy + ".xlsx";
            ExecuteCommand(comando);
        }

        static void ExecuteCommand(string _Command)
        {
            //Indicamos que deseamos inicializar el proceso cmd.exe junto a un comando de arranque. 
            //(/C, le indicamos al proceso cmd que deseamos que cuando termine la tarea asignada se cierre el proceso).
            //Para mas informacion consulte la ayuda de la consola con cmd.exe /? 
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;
            //Inicializa el proceso
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            string result = proc.StandardOutput.ReadToEnd();
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        public void FormatAsTable(Excel.Range SourceRange, string TableName, string TableStyleName)
        {
            SourceRange.Worksheet.ListObjects.Add(XlListObjectSourceType.xlSrcRange,
            SourceRange, System.Type.Missing, XlYesNoGuess.xlYes, System.Type.Missing).Name =
                TableName;
            SourceRange.Select();
            SourceRange.Worksheet.ListObjects[TableName].TableStyle = TableStyleName;
            SourceRange.Worksheet.ListObjects[TableName].ShowAutoFilter = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowHeaders = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowTotals = false;
        }

        private void tbPrv_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindCxP();
                tbPrv.Focus();
            }
        }

        private void tbNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindCxP();
                tbNombre.Focus();
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindCxP();
                tbEstilo.Focus();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindCxP();
                tbDescripcion.Focus();
            }

        }

        private void tbFchRevision_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindCxP();
                tbFchRevision.Focus();
            }
        }

        private void tbFchReprog_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindCxP();
                tbFchReprog.Focus();
            }
        }

        private void eliminarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string message = "Corfirmar la Eliminacion del Registro";
            string caption = "Advertencia...";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                string ParProveedor = MmsWin.Front.Utilerias.VarTem.tmpPrv;
                string ParEstilo = MmsWin.Front.Utilerias.VarTem.tmpSty;
                string ParFchRev = MmsWin.Front.Utilerias.VarTem.tmpFchRev;
                string ParFchRepro = MmsWin.Front.Utilerias.VarTem.tmpFchReprog;
              //  MmsWin.Negocio.Convenio.CxP.GetInstance().EliminaCxP1(ParProveedor, ParEstilo, ParFchRev, ParFchRepro);
                BindCxP();
                tbFchReprog.Focus();
            }
        }

        private void mcC1_DateChanged(object sender, DateRangeEventArgs e)
        {
            tbDesde.Text = mcC1.SelectionEnd.ToShortDateString();
            FechaCal = tbDesde.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchDeN = long.Parse(FechaFmt.ToString());
            FchDe = FechaFmt.ToString();

            mcC1.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbDesde.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    //tipoDeConsulta();
                    //BindData();
                }
            }
        }

        private void mcC1_Leave(object sender, EventArgs e)
        {
            mcC1.Visible = false;
        }

        private void mcC1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcC1.Visible = false;
            }
        }

        private void mcC2_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbHasta.Text = mcC2.SelectionEnd.ToShortDateString();
            FechaCal = tbHasta.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchHasN = long.Parse(FechaFmt.ToString());
            FchHas = FechaFmt.ToString();

            mcC2.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbHasta.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    //tipoDeConsulta();
                    //BindData();
                }
            }
        }

        private void mcC2_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcC2.Visible = false;
            }
        }

        private void tbDesde_Click(object sender, EventArgs e)
        {
            mcC1.Visible = true;
            mcC1.Focus();
        }

        private void tbHasta_Click(object sender, EventArgs e)
        {
            mcC2.Visible = true;
            mcC2.Focus();
        }

    }
}
