﻿namespace MmsWin.Front.Convenio
{
    partial class CxP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CxP));
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.fotoTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tbPrv = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbFchRevision = new System.Windows.Forms.TextBox();
            this.tbFchReprog = new System.Windows.Forms.TextBox();
            this.cbCompradores = new System.Windows.Forms.ComboBox();
            this.gbMarca = new System.Windows.Forms.GroupBox();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.gbComprador = new System.Windows.Forms.GroupBox();
            this.pbExcel = new System.Windows.Forms.PictureBox();
            this.btRelleno = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pgbProg = new System.Windows.Forms.ProgressBar();
            this.gbRangoFecha = new System.Windows.Forms.GroupBox();
            this.lblHasta = new System.Windows.Forms.Label();
            this.lblDesde = new System.Windows.Forms.Label();
            this.tbHasta = new System.Windows.Forms.TextBox();
            this.tbDesde = new System.Windows.Forms.TextBox();
            this.mcC1 = new System.Windows.Forms.MonthCalendar();
            this.mcC2 = new System.Windows.Forms.MonthCalendar();
            this.tbFolio = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.cmMenu.SuspendLayout();
            this.gbMarca.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbExcel)).BeginInit();
            this.gbRangoFecha.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.ContextMenuStrip = this.cmMenu;
            this.dgvGridView.Location = new System.Drawing.Point(2, 74);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.ReadOnly = true;
            this.dgvGridView.Size = new System.Drawing.Size(1352, 397);
            this.dgvGridView.TabIndex = 0;
            this.dgvGridView.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvGridView_CellMouseDown);
            this.dgvGridView.SelectionChanged += new System.EventHandler(this.dgvGridView_SelectionChanged);
            this.dgvGridView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvGridView_KeyUp);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fotoTSMI,
            this.eliminarToolStripMenuItem});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(118, 48);
            // 
            // fotoTSMI
            // 
            this.fotoTSMI.Name = "fotoTSMI";
            this.fotoTSMI.Size = new System.Drawing.Size(117, 22);
            this.fotoTSMI.Text = "Foto";
            this.fotoTSMI.Click += new System.EventHandler(this.fotoTSMI_Click);
            // 
            // eliminarToolStripMenuItem
            // 
            this.eliminarToolStripMenuItem.Name = "eliminarToolStripMenuItem";
            this.eliminarToolStripMenuItem.Size = new System.Drawing.Size(117, 22);
            this.eliminarToolStripMenuItem.Text = "Eliminar";
            this.eliminarToolStripMenuItem.Click += new System.EventHandler(this.eliminarToolStripMenuItem_Click);
            // 
            // tbPrv
            // 
            this.tbPrv.Location = new System.Drawing.Point(44, 53);
            this.tbPrv.Name = "tbPrv";
            this.tbPrv.Size = new System.Drawing.Size(46, 20);
            this.tbPrv.TabIndex = 1;
            this.tbPrv.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbPrv_KeyPress);
            // 
            // tbNombre
            // 
            this.tbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNombre.Location = new System.Drawing.Point(90, 53);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(198, 20);
            this.tbNombre.TabIndex = 2;
            this.tbNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNombre_KeyPress);
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDescripcion.Location = new System.Drawing.Point(356, 53);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(197, 20);
            this.tbDescripcion.TabIndex = 4;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress);
            // 
            // tbEstilo
            // 
            this.tbEstilo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbEstilo.Location = new System.Drawing.Point(288, 53);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(68, 20);
            this.tbEstilo.TabIndex = 3;
            this.tbEstilo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbEstilo_KeyPress);
            // 
            // tbFchRevision
            // 
            this.tbFchRevision.Location = new System.Drawing.Point(707, 53);
            this.tbFchRevision.Name = "tbFchRevision";
            this.tbFchRevision.Size = new System.Drawing.Size(83, 20);
            this.tbFchRevision.TabIndex = 5;
            this.tbFchRevision.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFchRevision.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbFchRevision_KeyPress);
            // 
            // tbFchReprog
            // 
            this.tbFchReprog.Location = new System.Drawing.Point(790, 53);
            this.tbFchReprog.Name = "tbFchReprog";
            this.tbFchReprog.Size = new System.Drawing.Size(77, 20);
            this.tbFchReprog.TabIndex = 6;
            this.tbFchReprog.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFchReprog.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbFchReprog_KeyPress);
            // 
            // cbCompradores
            // 
            this.cbCompradores.FormattingEnabled = true;
            this.cbCompradores.Location = new System.Drawing.Point(196, 20);
            this.cbCompradores.Name = "cbCompradores";
            this.cbCompradores.Size = new System.Drawing.Size(168, 21);
            this.cbCompradores.TabIndex = 21;
            this.cbCompradores.SelectedValueChanged += new System.EventHandler(this.cbCompradores_SelectedValueChanged);
            // 
            // gbMarca
            // 
            this.gbMarca.Controls.Add(this.cbMarca);
            this.gbMarca.Location = new System.Drawing.Point(61, 7);
            this.gbMarca.Name = "gbMarca";
            this.gbMarca.Size = new System.Drawing.Size(113, 40);
            this.gbMarca.TabIndex = 20;
            this.gbMarca.TabStop = false;
            this.gbMarca.Text = "Marca";
            // 
            // cbMarca
            // 
            this.cbMarca.Location = new System.Drawing.Point(24, 13);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(74, 21);
            this.cbMarca.TabIndex = 2;
            this.cbMarca.SelectedValueChanged += new System.EventHandler(this.cbMarca_SelectedValueChanged);
            // 
            // gbComprador
            // 
            this.gbComprador.Location = new System.Drawing.Point(178, 7);
            this.gbComprador.Name = "gbComprador";
            this.gbComprador.Size = new System.Drawing.Size(203, 40);
            this.gbComprador.TabIndex = 22;
            this.gbComprador.TabStop = false;
            this.gbComprador.Text = "Comprador";
            // 
            // pbExcel
            // 
            this.pbExcel.Image = ((System.Drawing.Image)(resources.GetObject("pbExcel.Image")));
            this.pbExcel.Location = new System.Drawing.Point(-7, 1);
            this.pbExcel.Name = "pbExcel";
            this.pbExcel.Size = new System.Drawing.Size(65, 47);
            this.pbExcel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbExcel.TabIndex = 18;
            this.pbExcel.TabStop = false;
            this.pbExcel.Click += new System.EventHandler(this.pbExcel_Click);
            // 
            // btRelleno
            // 
            this.btRelleno.Location = new System.Drawing.Point(-1, 52);
            this.btRelleno.Name = "btRelleno";
            this.btRelleno.Size = new System.Drawing.Size(47, 22);
            this.btRelleno.TabIndex = 23;
            this.btRelleno.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(866, 52);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(489, 22);
            this.button1.TabIndex = 35;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // pgbProg
            // 
            this.pgbProg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pgbProg.Location = new System.Drawing.Point(2, 473);
            this.pgbProg.Name = "pgbProg";
            this.pgbProg.Size = new System.Drawing.Size(1349, 10);
            this.pgbProg.TabIndex = 36;
            this.pgbProg.Visible = false;
            // 
            // gbRangoFecha
            // 
            this.gbRangoFecha.Controls.Add(this.lblHasta);
            this.gbRangoFecha.Controls.Add(this.lblDesde);
            this.gbRangoFecha.Controls.Add(this.tbHasta);
            this.gbRangoFecha.Controls.Add(this.tbDesde);
            this.gbRangoFecha.Location = new System.Drawing.Point(386, 7);
            this.gbRangoFecha.Name = "gbRangoFecha";
            this.gbRangoFecha.Size = new System.Drawing.Size(247, 40);
            this.gbRangoFecha.TabIndex = 37;
            this.gbRangoFecha.TabStop = false;
            this.gbRangoFecha.Text = "Rango";
            // 
            // lblHasta
            // 
            this.lblHasta.AutoSize = true;
            this.lblHasta.Location = new System.Drawing.Point(130, 18);
            this.lblHasta.Name = "lblHasta";
            this.lblHasta.Size = new System.Drawing.Size(35, 13);
            this.lblHasta.TabIndex = 38;
            this.lblHasta.Text = "Hasta";
            // 
            // lblDesde
            // 
            this.lblDesde.AutoSize = true;
            this.lblDesde.Location = new System.Drawing.Point(9, 18);
            this.lblDesde.Name = "lblDesde";
            this.lblDesde.Size = new System.Drawing.Size(38, 13);
            this.lblDesde.TabIndex = 37;
            this.lblDesde.Text = "Desde";
            // 
            // tbHasta
            // 
            this.tbHasta.Location = new System.Drawing.Point(167, 15);
            this.tbHasta.Name = "tbHasta";
            this.tbHasta.ReadOnly = true;
            this.tbHasta.Size = new System.Drawing.Size(74, 20);
            this.tbHasta.TabIndex = 36;
            this.tbHasta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbHasta.Click += new System.EventHandler(this.tbHasta_Click);
            // 
            // tbDesde
            // 
            this.tbDesde.Location = new System.Drawing.Point(50, 15);
            this.tbDesde.Name = "tbDesde";
            this.tbDesde.ReadOnly = true;
            this.tbDesde.Size = new System.Drawing.Size(76, 20);
            this.tbDesde.TabIndex = 35;
            this.tbDesde.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbDesde.Click += new System.EventHandler(this.tbDesde_Click);
            // 
            // mcC1
            // 
            this.mcC1.BackColor = System.Drawing.Color.Gray;
            this.mcC1.ForeColor = System.Drawing.Color.Black;
            this.mcC1.Location = new System.Drawing.Point(264, 85);
            this.mcC1.Name = "mcC1";
            this.mcC1.TabIndex = 43;
            this.mcC1.Visible = false;
            this.mcC1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.mcC1_DateChanged);
            this.mcC1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcC1_KeyUp);
            this.mcC1.Leave += new System.EventHandler(this.mcC1_Leave);
            // 
            // mcC2
            // 
            this.mcC2.BackColor = System.Drawing.Color.Gray;
            this.mcC2.ForeColor = System.Drawing.Color.Black;
            this.mcC2.Location = new System.Drawing.Point(530, 85);
            this.mcC2.Name = "mcC2";
            this.mcC2.TabIndex = 44;
            this.mcC2.Visible = false;
            this.mcC2.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcC2_DateSelected);
            this.mcC2.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcC2_KeyUp);
            // 
            // tbFolio
            // 
            this.tbFolio.Location = new System.Drawing.Point(553, 53);
            this.tbFolio.Name = "tbFolio";
            this.tbFolio.Size = new System.Drawing.Size(154, 20);
            this.tbFolio.TabIndex = 45;
            this.tbFolio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // CxP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1354, 486);
            this.Controls.Add(this.tbFolio);
            this.Controls.Add(this.mcC2);
            this.Controls.Add(this.mcC1);
            this.Controls.Add(this.gbRangoFecha);
            this.Controls.Add(this.pgbProg);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btRelleno);
            this.Controls.Add(this.cbCompradores);
            this.Controls.Add(this.gbMarca);
            this.Controls.Add(this.gbComprador);
            this.Controls.Add(this.pbExcel);
            this.Controls.Add(this.tbFchReprog);
            this.Controls.Add(this.tbFchRevision);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.tbEstilo);
            this.Controls.Add(this.tbNombre);
            this.Controls.Add(this.tbPrv);
            this.Controls.Add(this.dgvGridView);
            this.Name = "CxP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cuentas x Pagar";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CxP_FormClosing);
            this.Load += new System.EventHandler(this.CxP_Load);
            this.Resize += new System.EventHandler(this.CxP_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.cmMenu.ResumeLayout(false);
            this.gbMarca.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbExcel)).EndInit();
            this.gbRangoFecha.ResumeLayout(false);
            this.gbRangoFecha.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.TextBox tbPrv;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbFchRevision;
        private System.Windows.Forms.TextBox tbFchReprog;
        private System.Windows.Forms.ComboBox cbCompradores;
        private System.Windows.Forms.GroupBox gbMarca;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.GroupBox gbComprador;
        private System.Windows.Forms.PictureBox pbExcel;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem fotoTSMI;
        private System.Windows.Forms.Button btRelleno;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ProgressBar pgbProg;
        private System.Windows.Forms.ToolStripMenuItem eliminarToolStripMenuItem;
        private System.Windows.Forms.GroupBox gbRangoFecha;
        private System.Windows.Forms.Label lblHasta;
        private System.Windows.Forms.Label lblDesde;
        private System.Windows.Forms.TextBox tbHasta;
        private System.Windows.Forms.TextBox tbDesde;
        private System.Windows.Forms.MonthCalendar mcC1;
        private System.Windows.Forms.MonthCalendar mcC2;
        private System.Windows.Forms.TextBox tbFolio;
    }
}