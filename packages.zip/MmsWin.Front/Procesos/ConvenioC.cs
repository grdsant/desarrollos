﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Procesos
{
    public partial class ConvenioC : Form
    {

        string FechaCal;
        string FechaFmt;

        string ParUser;
        public ConvenioC()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnProcesar_Click(object sender, EventArgs e)
        {
            string fchVal;
            Boolean indFch;
            fchVal = tbFecha.Text;
            indFch = MmsWin.Negocio.Utilerias.Utilerias.fecha(fchVal);

            if (tbFecha.Text != "")
            {
                if (indFch == true)
                {
                    string message = "Esta seguro de procesar esta fecha?";
                    string caption = "Confirmación";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result;
                    result = MessageBox.Show(message, caption, buttons);
                    if (result == System.Windows.Forms.DialogResult.Yes)
                    {
                        this.Cursor = Cursors.WaitCursor;
                        ProcesaConvenio();
                        this.Cursor = Cursors.Default;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Proceso cancelado por el usuario");
                    }
                }
                else
                {
                    MessageBox.Show("La fecha es incorrecta.");
                }
            }
            else
            {
                MessageBox.Show("No debe quedar en blanco la fecha");
            }
        }
        private void ProcesaConvenio()
        {
                MmsWin.Front.Utilerias.VarTem.tmpUsrConv = "CALIFICA";
                MmsWin.Front.Utilerias.VarTem.simulador = false;
                FechaCal = tbFecha.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                string ParFchIni = FechaFmt;
                string ParFchFin = FechaFmt;
                string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUsrConv;

                string message = "Se va a ejecutar la Calificación del Convenio";
                string caption = "Aviso";   
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;
                result = MessageBox.Show(message, caption, buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    this.Cursor = Cursors.WaitCursor;
                    MmsWin.Negocio.Convenio.Convenio.GetInstance().EjecutaCalificaciones(ParFchIni, ParFchFin, ParUsuario);
                    this.Cursor = Cursors.Default;
                    MessageBox.Show("Calificacion Terminada...");
                }
        }

        private void mcCalendar_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbFecha.Text = mcCalendar.SelectionEnd.ToShortDateString();
            mcCalendar.Visible = false;

            string fchReprog;
            string NomDiaSem;
            tbFecha.Text = mcCalendar.SelectionEnd.ToShortDateString();
            fchReprog = tbFecha.Text;
            NomDiaSem = MmsWin.Negocio.Utilerias.Utilerias.NombreDiaSem(fchReprog);
            if (NomDiaSem == "lunes")
            {
                tbFecha.Text = mcCalendar.SelectionEnd.ToShortDateString();
                mcCalendar.Visible = false;
            }
            else
            {
                MessageBox.Show("La fecha no es lunes");
                tbFecha.Text = "";
            } 
        }

        private void ConvenioC_Load(object sender, EventArgs e)
        {
            // Seguridad...
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("Procesos", "ConvenioC", ParUser);
        }

        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }

        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
        }

        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void ConvenioC_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("Procesos", "Convenio", ParUser);
            }
        }

        private void tbFecha_Click(object sender, EventArgs e)
        {
            mcCalendar.Visible = true;
            mcCalendar.Focus();
        }

        private void mcCalendar_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcCalendar.Visible = false;
            }
        }

    }
}
