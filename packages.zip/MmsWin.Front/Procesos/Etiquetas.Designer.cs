﻿namespace MmsWin.Front.Procesos
{
    partial class Etiquetas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbFechaCalificacion = new System.Windows.Forms.TextBox();
            this.mcFchCalificacion = new System.Windows.Forms.MonthCalendar();
            this.btnProcesar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.gbFechaCalificacion = new System.Windows.Forms.GroupBox();
            this.mcCalFechaEfectiva = new System.Windows.Forms.MonthCalendar();
            this.gbFechaEfectiva = new System.Windows.Forms.GroupBox();
            this.tbFechaEfectiva = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.lbDescripcion = new System.Windows.Forms.Label();
            this.gbFechaCalificacion.SuspendLayout();
            this.gbFechaEfectiva.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbFechaCalificacion
            // 
            this.tbFechaCalificacion.Location = new System.Drawing.Point(20, 29);
            this.tbFechaCalificacion.Name = "tbFechaCalificacion";
            this.tbFechaCalificacion.Size = new System.Drawing.Size(100, 20);
            this.tbFechaCalificacion.TabIndex = 1;
            this.tbFechaCalificacion.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFechaCalificacion.Click += new System.EventHandler(this.tbFechaCalificacion_Click);
            // 
            // mcFchCalificacion
            // 
            this.mcFchCalificacion.Location = new System.Drawing.Point(155, 18);
            this.mcFchCalificacion.Name = "mcFchCalificacion";
            this.mcFchCalificacion.TabIndex = 3;
            this.mcFchCalificacion.Visible = false;
            this.mcFchCalificacion.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcFchCalificacion_DateSelected);
            this.mcFchCalificacion.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcFchCalificacion_KeyUp);
            // 
            // btnProcesar
            // 
            this.btnProcesar.Location = new System.Drawing.Point(311, 294);
            this.btnProcesar.Name = "btnProcesar";
            this.btnProcesar.Size = new System.Drawing.Size(75, 23);
            this.btnProcesar.TabIndex = 4;
            this.btnProcesar.Text = "Procesar";
            this.btnProcesar.UseVisualStyleBackColor = true;
            this.btnProcesar.Click += new System.EventHandler(this.btnProcesar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(12, 294);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 2;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // gbFechaCalificacion
            // 
            this.gbFechaCalificacion.Controls.Add(this.tbFechaCalificacion);
            this.gbFechaCalificacion.Location = new System.Drawing.Point(142, 16);
            this.gbFechaCalificacion.Name = "gbFechaCalificacion";
            this.gbFechaCalificacion.Size = new System.Drawing.Size(139, 65);
            this.gbFechaCalificacion.TabIndex = 19;
            this.gbFechaCalificacion.TabStop = false;
            this.gbFechaCalificacion.Text = "Fecha de Calificacion";
            // 
            // mcCalFechaEfectiva
            // 
            this.mcCalFechaEfectiva.Location = new System.Drawing.Point(155, 120);
            this.mcCalFechaEfectiva.Name = "mcCalFechaEfectiva";
            this.mcCalFechaEfectiva.TabIndex = 21;
            this.mcCalFechaEfectiva.Visible = false;
            this.mcCalFechaEfectiva.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.mcCalFechaEfectiva_DateChanged);
            this.mcCalFechaEfectiva.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcCalFechaEfectiva_DateSelected);
            this.mcCalFechaEfectiva.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcCalFechaEfectiva_KeyUp);
            // 
            // gbFechaEfectiva
            // 
            this.gbFechaEfectiva.Controls.Add(this.tbFechaEfectiva);
            this.gbFechaEfectiva.Location = new System.Drawing.Point(142, 112);
            this.gbFechaEfectiva.Name = "gbFechaEfectiva";
            this.gbFechaEfectiva.Size = new System.Drawing.Size(139, 66);
            this.gbFechaEfectiva.TabIndex = 22;
            this.gbFechaEfectiva.TabStop = false;
            this.gbFechaEfectiva.Text = "Fecha Efectiva";
            // 
            // tbFechaEfectiva
            // 
            this.tbFechaEfectiva.Location = new System.Drawing.Point(20, 28);
            this.tbFechaEfectiva.Name = "tbFechaEfectiva";
            this.tbFechaEfectiva.Size = new System.Drawing.Size(100, 20);
            this.tbFechaEfectiva.TabIndex = 23;
            this.tbFechaEfectiva.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFechaEfectiva.Click += new System.EventHandler(this.tbFechaEfectiva_Click);
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.Location = new System.Drawing.Point(12, 251);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(374, 20);
            this.tbDescripcion.TabIndex = 23;
            // 
            // lbDescripcion
            // 
            this.lbDescripcion.AutoSize = true;
            this.lbDescripcion.Location = new System.Drawing.Point(13, 232);
            this.lbDescripcion.Name = "lbDescripcion";
            this.lbDescripcion.Size = new System.Drawing.Size(63, 13);
            this.lbDescripcion.TabIndex = 24;
            this.lbDescripcion.Text = "Descripcion";
            // 
            // Etiquetas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSlateGray;
            this.ClientSize = new System.Drawing.Size(404, 352);
            this.Controls.Add(this.lbDescripcion);
            this.Controls.Add(this.mcCalFechaEfectiva);
            this.Controls.Add(this.mcFchCalificacion);
            this.Controls.Add(this.btnProcesar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.gbFechaCalificacion);
            this.Controls.Add(this.gbFechaEfectiva);
            this.Controls.Add(this.tbDescripcion);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Etiquetas";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Identificador de estilos(Etiquetas)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Etiquetas_FormClosing);
            this.Load += new System.EventHandler(this.Etiquetas_Load);
            this.gbFechaCalificacion.ResumeLayout(false);
            this.gbFechaCalificacion.PerformLayout();
            this.gbFechaEfectiva.ResumeLayout(false);
            this.gbFechaEfectiva.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbFechaCalificacion;
        private System.Windows.Forms.MonthCalendar mcFchCalificacion;
        private System.Windows.Forms.Button btnProcesar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.GroupBox gbFechaCalificacion;
        private System.Windows.Forms.MonthCalendar mcCalFechaEfectiva;
        private System.Windows.Forms.GroupBox gbFechaEfectiva;
        private System.Windows.Forms.TextBox tbFechaEfectiva;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.Label lbDescripcion;
    }
}