﻿namespace MmsWin.Front.Procesos
{
    partial class BonificacionesP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbFecha = new System.Windows.Forms.TextBox();
            this.mcCalendar = new System.Windows.Forms.MonthCalendar();
            this.btnProcesar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.gbFecha = new System.Windows.Forms.GroupBox();
            this.tbFechaInicio = new System.Windows.Forms.TextBox();
            this.gbFchInicio = new System.Windows.Forms.GroupBox();
            this.mcCalendarInicio = new System.Windows.Forms.MonthCalendar();
            this.gbFecha.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbFecha
            // 
            this.tbFecha.Location = new System.Drawing.Point(49, 28);
            this.tbFecha.Name = "tbFecha";
            this.tbFecha.Size = new System.Drawing.Size(100, 20);
            this.tbFecha.TabIndex = 8;
            this.tbFecha.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFecha.Click += new System.EventHandler(this.tbFecha_Click);
            // 
            // mcCalendar
            // 
            this.mcCalendar.Location = new System.Drawing.Point(272, 102);
            this.mcCalendar.Name = "mcCalendar";
            this.mcCalendar.TabIndex = 7;
            this.mcCalendar.Visible = false;
            this.mcCalendar.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcCalendar_DateSelected);
            this.mcCalendar.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcCalendar_KeyUp);
            // 
            // btnProcesar
            // 
            this.btnProcesar.Location = new System.Drawing.Point(342, 163);
            this.btnProcesar.Name = "btnProcesar";
            this.btnProcesar.Size = new System.Drawing.Size(75, 23);
            this.btnProcesar.TabIndex = 6;
            this.btnProcesar.Text = "Procesar";
            this.btnProcesar.UseVisualStyleBackColor = true;
            this.btnProcesar.Click += new System.EventHandler(this.btnProcesar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(84, 163);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 5;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // gbFecha
            // 
            this.gbFecha.Controls.Add(this.tbFecha);
            this.gbFecha.Location = new System.Drawing.Point(289, 25);
            this.gbFecha.Name = "gbFecha";
            this.gbFecha.Size = new System.Drawing.Size(180, 65);
            this.gbFecha.TabIndex = 9;
            this.gbFecha.TabStop = false;
            this.gbFecha.Text = "Fecha Contenedor";
            // 
            // tbFechaInicio
            // 
            this.tbFechaInicio.Location = new System.Drawing.Point(84, 53);
            this.tbFechaInicio.Name = "tbFechaInicio";
            this.tbFechaInicio.Size = new System.Drawing.Size(100, 20);
            this.tbFechaInicio.TabIndex = 10;
            this.tbFechaInicio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFechaInicio.Click += new System.EventHandler(this.tbFechaInicio_Click);
            // 
            // gbFchInicio
            // 
            this.gbFchInicio.Location = new System.Drawing.Point(36, 25);
            this.gbFchInicio.Name = "gbFchInicio";
            this.gbFchInicio.Size = new System.Drawing.Size(180, 65);
            this.gbFchInicio.TabIndex = 11;
            this.gbFchInicio.TabStop = false;
            this.gbFchInicio.Text = "Fecha Inicio";
            // 
            // mcCalendarInicio
            // 
            this.mcCalendarInicio.Location = new System.Drawing.Point(6, 102);
            this.mcCalendarInicio.Name = "mcCalendarInicio";
            this.mcCalendarInicio.TabIndex = 12;
            this.mcCalendarInicio.Visible = false;
            this.mcCalendarInicio.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcCalendarInicio_DateSelected);
            this.mcCalendarInicio.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcCalendarInicio_KeyUp);
            // 
            // BonificacionesP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSlateGray;
            this.ClientSize = new System.Drawing.Size(538, 270);
            this.Controls.Add(this.mcCalendarInicio);
            this.Controls.Add(this.mcCalendar);
            this.Controls.Add(this.tbFechaInicio);
            this.Controls.Add(this.gbFchInicio);
            this.Controls.Add(this.btnProcesar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.gbFecha);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BonificacionesP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calificacion por Omisión";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.BonificacionesP_FormClosing);
            this.Load += new System.EventHandler(this.BonificacionesP_Load);
            this.gbFecha.ResumeLayout(false);
            this.gbFecha.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbFecha;
        private System.Windows.Forms.MonthCalendar mcCalendar;
        private System.Windows.Forms.Button btnProcesar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.GroupBox gbFecha;
        private System.Windows.Forms.TextBox tbFechaInicio;
        private System.Windows.Forms.GroupBox gbFchInicio;
        private System.Windows.Forms.MonthCalendar mcCalendarInicio;
    }
}