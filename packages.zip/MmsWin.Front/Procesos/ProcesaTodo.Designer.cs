﻿namespace MmsWin.Front.Procesos
{
    partial class ProcesaTodo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mcCalendar = new System.Windows.Forms.MonthCalendar();
            this.btnProcesar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.tbFecha = new System.Windows.Forms.TextBox();
            this.gbFecha = new System.Windows.Forms.GroupBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.lbDescripcion = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // mcCalendar
            // 
            this.mcCalendar.Location = new System.Drawing.Point(79, 47);
            this.mcCalendar.Name = "mcCalendar";
            this.mcCalendar.TabIndex = 4;
            this.mcCalendar.Visible = false;
            this.mcCalendar.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcCalendar_DateSelected);
            this.mcCalendar.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcCalendar_KeyUp);
            // 
            // btnProcesar
            // 
            this.btnProcesar.Location = new System.Drawing.Point(323, 310);
            this.btnProcesar.Name = "btnProcesar";
            this.btnProcesar.Size = new System.Drawing.Size(75, 23);
            this.btnProcesar.TabIndex = 9;
            this.btnProcesar.Text = "Procesar";
            this.btnProcesar.UseVisualStyleBackColor = true;
            this.btnProcesar.Click += new System.EventHandler(this.btnProcesar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(7, 311);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 8;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // tbFecha
            // 
            this.tbFecha.Location = new System.Drawing.Point(152, 166);
            this.tbFecha.Name = "tbFecha";
            this.tbFecha.Size = new System.Drawing.Size(100, 20);
            this.tbFecha.TabIndex = 10;
            this.tbFecha.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFecha.Click += new System.EventHandler(this.tbFecha_Click);
            // 
            // gbFecha
            // 
            this.gbFecha.Location = new System.Drawing.Point(112, 144);
            this.gbFecha.Name = "gbFecha";
            this.gbFecha.Size = new System.Drawing.Size(180, 65);
            this.gbFecha.TabIndex = 11;
            this.gbFecha.TabStop = false;
            this.gbFecha.Text = "Fecha de calificacion";
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.Location = new System.Drawing.Point(20, 269);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(367, 20);
            this.tbDescripcion.TabIndex = 26;
            // 
            // lbDescripcion
            // 
            this.lbDescripcion.AutoSize = true;
            this.lbDescripcion.Location = new System.Drawing.Point(17, 253);
            this.lbDescripcion.Name = "lbDescripcion";
            this.lbDescripcion.Size = new System.Drawing.Size(63, 13);
            this.lbDescripcion.TabIndex = 27;
            this.lbDescripcion.Text = "Descripcion";
            // 
            // ProcesaTodo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSlateGray;
            this.ClientSize = new System.Drawing.Size(404, 352);
            this.Controls.Add(this.lbDescripcion);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.btnProcesar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.mcCalendar);
            this.Controls.Add(this.tbFecha);
            this.Controls.Add(this.gbFecha);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProcesaTodo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Procesa Todo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MonthCalendar mcCalendar;
        private System.Windows.Forms.Button btnProcesar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.TextBox tbFecha;
        private System.Windows.Forms.GroupBox gbFecha;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.Label lbDescripcion;
    }
}