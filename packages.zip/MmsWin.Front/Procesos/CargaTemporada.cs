﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using MmsWin.Entidades;
namespace MmsWin.Front.Procesos
{
    public partial class CargaTemporada : Form
    {
        string marca;
        string comprador;
        public CargaTemporada()
        {
            InitializeComponent();
        }
        int dgvOffset;
        int dgvOffset2;
        static bool isExcel;
        private void CargaTemporada_Load(object sender, EventArgs e)
        {

            dgvOffset = this.Width - gvPrincipal.Width;
            dgvOffset2 = this.Height - gvPrincipal.Height;

            var lstmarca = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();

            cbMarca.DataSource = lstmarca;
            cbMarca.DisplayMember = "Value";
            cbMarca.ValueMember = "Key";
            marca = "999";

            cbMarcaCarga.DataSource = lstmarca;
            cbMarcaCarga.DisplayMember = "Value";
            cbMarcaCarga.ValueMember = "Key";

            ddlMarcaCal.DataSource = lstmarca;
            ddlMarcaCal.DisplayMember = "Value";
            ddlMarcaCal.ValueMember = "Key";

            var lstcompradores = MmsWin.Negocio.Catalogos.Compradores.GetInstance().ObtenCompradors().ToList();
            cbCompradores.DataSource = lstcompradores;
            cbCompradores.DisplayMember = "Value";
            cbCompradores.ValueMember = "Key";

            cbCompradorCarga.DataSource = lstcompradores;
            cbCompradorCarga.DisplayMember = "Value";
            cbCompradorCarga.ValueMember = "Key";

                System.Data.DataTable dtTemporadas = new System.Data.DataTable("Temporada");
            dtTemporadas.Columns.Add("Des", typeof(String));
            dtTemporadas.Columns.Add("Id", typeof(String));

            dtTemporadas = MmsWin.Negocio.Catalogos.Temporada.GetInstance().ObtenTemporada();

            ddlTempCal.DataSource = dtTemporadas;
            ddlTempCal.DisplayMember = "Des";
            ddlTempCal.ValueMember = "Id";

            gvAdminDet.Visible = false;
            DataBind();
        }

        public void DataBind()
        {
            try
            {
                DataTable dt = Negocio.Procesos.Temporada.GetInstance().ObtenTemporada(0,
                     cbCompradores.SelectedValue.ToString(), "", "");

                gvPrincipal.DataSource = dt;

                SetFontAndColors();

                DataTable dtl = Negocio.Procesos.Temporada.GetInstance().ObtenHeaderTemporadas(0);

                gvAdminHeader.DataSource = dtl;

                SetFontAndColorsBlack();

            }
            catch (Exception err)
            {
                //MessageBox.Show("Error al cargar el control.", "Milano", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SetFontAndColors()
        {
            this.gvPrincipal.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            //   this.gvPrincipal.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.gvPrincipal.EnableHeadersVisualStyles = false;
            this.gvPrincipal.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.gvPrincipal.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.gvPrincipal.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.gvPrincipal.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.gvPrincipal.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.gvPrincipal.Columns[2].Frozen = true;

            gvPrincipal.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            gvPrincipal.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            gvPrincipal.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvPrincipal.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            gvPrincipal.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvPrincipal.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            gvPrincipal.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            gvPrincipal.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            gvPrincipal.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            gvPrincipal.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvPrincipal.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvPrincipal.Columns[11].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //gvPrincipal.Columns[12].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //gvPrincipal.Columns[13].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            //gvPrincipal.Columns[14].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            gvPrincipal.Columns[0].Width = 45;
            gvPrincipal.Columns[1].Width = 45;
            gvPrincipal.Columns[2].Width = 200;
            gvPrincipal.Columns[3].Width = 65;
            gvPrincipal.Columns[4].Width = 200;
            gvPrincipal.Columns[5].Width = 50;
            gvPrincipal.Columns[6].Width = 50;
            gvPrincipal.Columns[7].Width = 50;
            gvPrincipal.Columns[8].Width = 50;
            gvPrincipal.Columns[9].Width = 50;
            gvPrincipal.Columns[10].Width = 50;
            gvPrincipal.Columns[11].Width = 50;
            //gvPrincipal.Columns[12].Width = 80;
            //gvPrincipal.Columns[13].Width = 80;
            //gvPrincipal.Columns[14].Width = 80;

            gvPrincipal.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvPrincipal.Columns[1].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvPrincipal.Columns[2].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvPrincipal.Columns[3].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvPrincipal.Columns[4].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvPrincipal.Columns[5].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            gvPrincipal.Columns[6].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            gvPrincipal.Columns[7].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            gvPrincipal.Columns[8].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            gvPrincipal.Columns[9].HeaderCell.Style.BackColor = Color.LightSlateGray;
            gvPrincipal.Columns[10].HeaderCell.Style.BackColor = Color.LightSlateGray;
            gvPrincipal.Columns[11].HeaderCell.Style.BackColor = Color.LightSalmon;
            //gvPrincipal.Columns[12].HeaderCell.Style.BackColor = Color.LightCoral;
            //gvPrincipal.Columns[13].HeaderCell.Style.BackColor = Color.LightCoral;
            //gvPrincipal.Columns[14].HeaderCell.Style.BackColor = Color.LightCoral;

            gvPrincipal.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gvPrincipal.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            gvPrincipal.EnableHeadersVisualStyles = false;


        }

        private void SetFontAndColorsBlack()
        {
            this.gvAdminHeader.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            //   this.gvPrincipal.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.gvAdminHeader.EnableHeadersVisualStyles = false;
            this.gvAdminHeader.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.gvAdminHeader.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.gvAdminHeader.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.gvAdminHeader.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.gvAdminHeader.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.gvAdminHeader.Columns[2].Frozen = true;

            gvAdminHeader.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            gvAdminHeader.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            gvAdminHeader.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvAdminHeader.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            gvAdminHeader.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            gvAdminHeader.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            gvAdminHeader.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            gvAdminHeader.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            gvAdminHeader.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            gvAdminHeader.Columns[0].Width = 45;
            gvAdminHeader.Columns[1].Width = 45;
            gvAdminHeader.Columns[2].Width = 45;
            gvAdminHeader.Columns[3].Width = 95;
            gvAdminHeader.Columns[4].Width = 115;
            gvAdminHeader.Columns[5].Width = 105;
            gvAdminHeader.Columns[6].Width = 105;
            gvAdminHeader.Columns[7].Width = 105;
            gvAdminHeader.Columns[8].Width = 105;

            gvAdminHeader.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvAdminHeader.Columns[1].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvAdminHeader.Columns[2].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvAdminHeader.Columns[3].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            gvAdminHeader.Columns[4].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            gvAdminHeader.Columns[5].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            gvAdminHeader.Columns[6].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            gvAdminHeader.Columns[7].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            gvAdminHeader.Columns[8].HeaderCell.Style.BackColor = Color.LightSeaGreen;

            gvAdminHeader.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gvAdminHeader.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            gvAdminHeader.EnableHeadersVisualStyles = false;
        }


        private void btnGuardar_Click(object sender, EventArgs e)
        {

        }

        private void btnActualiza_Click(object sender, EventArgs e)
        {
            try
            {
                openFileDialog1.FileName = "";

                openFileDialog1.InitialDirectory = txtExcel.Text;


                if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    this.Cursor = Cursors.WaitCursor;

                    DataTable tb = RecogerDatosExcel(openFileDialog1.FileName);

                    gvCargaEstilos.DataSource = tb;
                }

                this.Cursor = Cursors.Default;

            }
            catch (Exception)
            {
                MessageBox.Show("Error al leer el archivo, favor de verificar", "Milano", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            finally
            {
                lblEstatus.Visible = false;
                System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default;
            }
        }

        public DataTable RecogerDatosExcel(string fileName)
        {
            isExcel = true;
            Microsoft.Office.Interop.Excel._Application xlApp;
            Microsoft.Office.Interop.Excel._Workbook xlLibro;
            Microsoft.Office.Interop.Excel._Worksheet xlHoja1;
            Microsoft.Office.Interop.Excel.Sheets xlHojas;

            DataTable tbl = new DataTable();

            tbl.Columns.Add("Origen", typeof(string));
            tbl.Columns.Add("Temporada", typeof(string));
            tbl.Columns.Add("Marca", typeof(string));
            tbl.Columns.Add("CodEstilo", typeof(string));
            tbl.Columns.Add("Estilo", typeof(string));
            tbl.Columns.Add("IdProveedor", typeof(string));
            tbl.Columns.Add("Proveedor", typeof(string));

            tbl.Columns.Add("Departamento", typeof(string));
            tbl.Columns.Add("Subdepartamento", typeof(string));
            tbl.Columns.Add("Clase", typeof(string));
            tbl.Columns.Add("Subclase", typeof(string));
            tbl.Columns.Add("Estatus", typeof(string));
            tbl.Columns.Add("Id_Comprador", typeof(string));
            tbl.Columns.Add("Comprador", typeof(string));

            string origen, temporada, codestilo, estatus, proveedorN, estilo, comprador, id_comprador;

            DateTime fechaIni, fechaFin, fechaCal;
            bool exito;
            int marca, proveedor, departamento, subdepartamento, clase, subclase, error = 0;

            xlApp = new Microsoft.Office.Interop.Excel.Application();

            xlApp.Visible = false;

            xlLibro = xlApp.Workbooks.Open(fileName, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value, Missing.Value);

            xlHojas = xlLibro.Sheets;

            xlHoja1 = (Microsoft.Office.Interop.Excel._Worksheet)xlHojas["Temporada"];

            System.Data.DataRow row;
            try
            {
                int j = 2;

                for (int i = 0; i < 100000; i++)
                {

                    row = tbl.NewRow();
                    exito = true;

                    if (string.IsNullOrEmpty(xlHoja1.get_Range("A" + j, Missing.Value).Text))
                        break;

                    origen = xlHoja1.get_Range("A" + j, Missing.Value).Text;
                    temporada = xlHoja1.get_Range("B" + j, Missing.Value).Text;
                    marca = int.Parse(xlHoja1.get_Range("C" + j, Missing.Value).Text);
                    int.TryParse(xlHoja1.get_Range("D" + j, Missing.Value).Text, out proveedor);
                    proveedorN = xlHoja1.get_Range("E" + j, Missing.Value).Text;
                    codestilo = xlHoja1.get_Range("F" + j, Missing.Value).Text;
                    estilo = xlHoja1.get_Range("G" + j, Missing.Value).Text;
                    int.TryParse(xlHoja1.get_Range("H" + j, Missing.Value).Text, out departamento);
                    int.TryParse(xlHoja1.get_Range("I" + j, Missing.Value).Text, out subdepartamento);
                    int.TryParse(xlHoja1.get_Range("J" + j, Missing.Value).Text, out clase);
                    int.TryParse(xlHoja1.get_Range("K" + j, Missing.Value).Text, out subclase);

                    estatus = exito ? "OK" : "ERROR";

                    id_comprador = xlHoja1.get_Range("L" + j, Missing.Value).Text;
                    //comprador = xlHoja1.get_Range("P" + j, Missing.Value).Text;

                    row["Origen"] = origen;
                    row["Temporada"] = temporada;
                    row["Marca"] = marca;
                    row["CodEstilo"] = codestilo;
                    row["Estilo"] = estilo;
                    row["IdProveedor"] = proveedor;
                    row["Proveedor"] = proveedorN;
                    row["Departamento"] = departamento;
                    row["Subdepartamento"] = subdepartamento;
                    row["Clase"] = clase;
                    row["Subclase"] = subclase;
                    row["Estatus"] = estatus;
                    row["Id_Comprador"] = id_comprador;
                    row["Comprador"] = "";

                    tbl.Rows.Add(row);

                    if (!exito)
                    {
                        tbl.Rows[i].SetColumnError(0, "Error");
                        error++;
                    }
                    j++;
                }

                return tbl;
            }
            catch (Exception)
            {
                throw new Exception();
            }
            finally
            {
                if (error > 0)
                    MessageBox.Show("El archivo contiene datos erroneos, favor de verificar", "Milano", MessageBoxButtons.OK, MessageBoxIcon.Error);

                try { xlLibro.Close(false, Missing.Value, Missing.Value); }
                catch (Exception) { }
            }
        }

        private void btnGuardaCarga_Click(object sender, EventArgs e)
        {
            Entidades.Temporada temp;

            string origen, temporada, codestilo, estatus, proveedorN, estilo, comprador, id_comprador;

            DateTime fechaIni, fechaFin, fechaCal;

            int marca, proveedor, departamento, subdepartamento, clase, subclase;

            temp = new Entidades.Temporada();

            this.Cursor = Cursors.WaitCursor;

            try
            {
                DataTable tb = (DataTable)gvCargaEstilos.DataSource;

                foreach (DataRow item in tb.Rows)
                {
                    if (item.RowState != DataRowState.Deleted)
                    {
                        origen = item[0].ToString().Length > 3 ? item[0].ToString().Substring(0, 3) : item[0].ToString();
                        temporada = item[1].ToString().Length > 3 ? item[1].ToString().Substring(0, 3) : item[1].ToString();
                        marca = item[2].ToString() == string.Empty ? 0 : int.Parse(item[2].ToString());
                        codestilo = item[3].ToString();
                        estilo = item[4].ToString();
                        int.TryParse(item[5].ToString(), out proveedor);
                        proveedorN = item[6].ToString().Length > 30 ? item[6].ToString().Substring(0, 30) : item[6].ToString();

                        if (!isExcel)
                        {
                            int.TryParse(item[7].ToString(), out departamento);
                            int.TryParse(item[9].ToString(), out subdepartamento);
                            int.TryParse(item[11].ToString(), out clase);
                            int.TryParse(item[13].ToString(), out subclase);

                            fechaCal = DateTime.Now;
                            estatus = "A";
                            id_comprador = item[15].ToString();
                            comprador = "";

                        }
                        else
                        {
                            int.TryParse(item[7].ToString(), out departamento);
                            int.TryParse(item[8].ToString(), out subdepartamento);
                            int.TryParse(item[9].ToString(), out clase);
                            int.TryParse(item[10].ToString(), out subclase);

                            fechaCal = DateTime.Now;
                            estatus = "A";
                            id_comprador = item[12].ToString();
                            comprador = "";
                        }

                        temp.Origen = origen;
                        temp.CodTemporada = temporada;
                        temp.Marca = marca;
                        temp.Id_Proveedor = proveedor;
                        temp.Proveedor = proveedorN;
                        temp.Id_Estilo = codestilo;
                        temp.Estilo = estilo;
                        temp.Id_Departamento = departamento;
                        temp.Id_Subdepartamento = subdepartamento;
                        temp.Id_Clase = clase;
                        temp.Id_SubClase = subclase;

                        temp.Comprador = id_comprador.ToString();
                        //select * from paso.sat178f2c--CONVENIO
                        Negocio.Procesos.Temporada.GetInstance().GuardaTemporada(temp, "ulises");
                    }
                }

                MessageBox.Show("Datos cargados correctamente", "Milano", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Cursor = Cursors.Default;
            }
            catch (Exception err)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Incluya los datos a procesar.", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            DataBind();
        }

        public void cargaDatos()
        {

        }

        private void btnManualAceptar_Click(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                isExcel = false;
                if (cbTempCarga.SelectedItem == null)
                {
                    throw new Exception("Seleccione una temporada");
                }
                if (cbOrigenCarga.SelectedItem == null)
                {
                    throw new Exception("Seleccione un origen");
                }

                int depto, subdepto, clase, subclase, prov;

                int.TryParse(txtDepartamentoManual.Text, out depto);
                int.TryParse(txtSubpartamentoManual.Text, out subdepto);
                int.TryParse(txtClaseManual.Text, out clase);
                int.TryParse(txtSubclaseManual.Text, out subclase);
                int.TryParse(txtProveedorManual.Text, out prov);

                gvCargaEstilos.DataSource = Negocio.Procesos.Temporada.GetInstance().ObtenEstilos(cbMarcaCarga.SelectedValue.ToString(),
                    depto, subdepto, clase, subclase, prov, txtEstiloManual.Text, cbTempCarga.SelectedItem.ToString(),
                    cbOrigenCarga.SelectedItem.ToString());
                this.Cursor = Cursors.Default;
            }
            catch (Exception err)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show(err.Message, "Milano", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtDepartamentoManual_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar))
            {
                MessageBox.Show("Solo se permiten numeros", "Milano", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbMarcaCarga_SelectedIndexChanged(object sender, EventArgs e)
        {
            marca = " ";
            ComboBox cmbMarca = (ComboBox)sender;
            marca = cmbMarca.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpMarca = cbMarca.SelectedValue.ToString();

        }

        private void CargaTemporada_Resize(object sender, EventArgs e)
        {
            gvPrincipal.Width = this.Width - dgvOffset;
            gvPrincipal.Height = this.Height - dgvOffset2;

            int nr = gvPrincipal.RowCount;

            if (nr > 0)
            {
                DataBind();
            }
        }

        //BUSQUEDA DE GRID PRINCIPAL
        private void txtmarca_TextChanged(object sender, EventArgs e)
        {
            int marca, idprov, depto, subdepto, clase, subclase;

            int.TryParse(txtmarca.Text, out marca);
            int.TryParse(txtpro.Text, out idprov);
            int.TryParse(txtDepto.Text, out depto);
            int.TryParse(txtSubdepto.Text, out subdepto);
            int.TryParse(txtClase.Text, out clase);
            int.TryParse(txtSubclase.Text, out subclase);

            DataTable dt = Negocio.Procesos.Temporada.GetInstance().ObtenTemporada(marca,
                   cbCompradores.SelectedValue.ToString(), "", "", idprov, txtProveedor.Text, txtest.Text, txtEstilo.Text,
                   depto, subdepto, clase, subclase);

            gvPrincipal.DataSource = dt;

            SetFontAndColors();
        }



        private void gvPrincipal_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            int marca, prov;

            int.TryParse(e.Row.Cells["marca"].Value.ToString(), out marca);
            int.TryParse(e.Row.Cells["id_prov"].Value.ToString(), out prov);

            Negocio.Procesos.Temporada.GetInstance().EliminaTemporada(marca, prov, e.Row.Cells["id_estilo"].Value.ToString());

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataBind();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void gvAdminHeader_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            short temp = short.Parse(this.gvAdminHeader.CurrentRow.Cells[2].Value.ToString());
            short marca = short.Parse(this.gvAdminHeader.CurrentRow.Cells[1].Value.ToString());
            short anio = short.Parse(this.gvAdminHeader.CurrentRow.Cells[0].Value.ToString());
         
            gvAdminDet.Visible = true;

            DataTable dtl = Negocio.Procesos.Temporada.GetInstance().ObtenDetalleTemporadas(marca, temp, anio);

            gvAdminDet.DataSource = dtl;
        }

        private void gvAdminDet_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            int marca, anio, depto, subdepto, clase, subclase;
            int temporada ;

            int.TryParse(e.Row.Cells["marca"].Value.ToString(), out marca);
            int.TryParse(e.Row.Cells["anio"].Value.ToString(), out anio);

            int.TryParse(e.Row.Cells["departamento"].Value.ToString(), out depto);
            int.TryParse(e.Row.Cells["subdepartamento"].Value.ToString(), out subdepto);

            int.TryParse(e.Row.Cells["clase"].Value.ToString(), out clase);
            int.TryParse(e.Row.Cells["subclase"].Value.ToString(), out subclase);

            temporada =  int.Parse(e.Row.Cells["id"].Value.ToString());

            Negocio.Procesos.Temporada.GetInstance().EliminaJerarquia_Black(marca, depto, subdepto, clase, subclase, temporada, anio);
        }

        private void gvAdminDet_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            AgregaTemporada tem = new AgregaTemporada();

            tem.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;

                int marca = int.Parse(ddlMarcaCal.SelectedValue.ToString());

                string temp = ddlTempCal.SelectedValue.ToString();

                string fecha_inicio = dtInicio.Value.ToString("yy") + dtInicio.Value.ToString("MM") + dtInicio.Value.Day;

                string fecha_fin = dtFin.Value.ToString("yy") + dtFin.Value.ToString("MM") + dtFin.Value.Day;

                if (marca == 999 || temp == "999")
                    throw new Exception("Seleccione todos los valores");

                string tipo = ddlTIpo.SelectedItem.ToString();
                int tabla = 0;
                if (tipo == "RENTABILIDAD")
                    tabla = 3;
                else if (tipo == "DESPLAZAMIENTO")
                    tabla = 30;

                SetDoubleBuffered(gvCalificacion);

                DataTable tb = Negocio.Procesos.Temporada.GetInstance().CalificaTemporada(marca, temp, fecha_inicio, fecha_fin, tabla);

                gvCalificacion.DataSource = tb;

                SetFontAndColorsTemporada();

                this.Cursor = Cursors.Default;
            }
            catch (Exception err)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show(err.Message, "Milano", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SetFontAndColorsTemporada()
        {
            this.gvCalificacion.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            //   this.gvCalificacion.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.gvCalificacion.EnableHeadersVisualStyles = false;
            this.gvCalificacion.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.gvCalificacion.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.gvCalificacion.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.gvCalificacion.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.gvCalificacion.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.gvCalificacion.Columns[2].Frozen = true;

            gvCalificacion.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvCalificacion.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvCalificacion.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvCalificacion.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvCalificacion.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvCalificacion.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvCalificacion.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvCalificacion.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvCalificacion.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvCalificacion.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvCalificacion.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvCalificacion.Columns[11].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvCalificacion.Columns[12].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;//Descripcion Subclase
            gvCalificacion.Columns[13].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvCalificacion.Columns[14].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvCalificacion.Columns[15].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvCalificacion.Columns[16].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvCalificacion.Columns[17].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvCalificacion.Columns[18].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvCalificacion.Columns[19].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvCalificacion.Columns[20].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvCalificacion.Columns[21].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvCalificacion.Columns[22].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvCalificacion.Columns[23].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvCalificacion.Columns[24].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvCalificacion.Columns[25].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvCalificacion.Columns[26].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            gvCalificacion.Columns[27].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;//onhand plus
            gvCalificacion.Columns[28].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            gvCalificacion.Columns[29].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;


            gvCalificacion.Columns[0].Width = 45;
            gvCalificacion.Columns[1].Width = 200;
            gvCalificacion.Columns[2].Width = 65;
            gvCalificacion.Columns[3].Width = 200;
            gvCalificacion.Columns[4].Width = 45;//comprador
            gvCalificacion.Columns[5].Width = 200;
            gvCalificacion.Columns[6].Width = 45;
            gvCalificacion.Columns[7].Width = 200;
            gvCalificacion.Columns[8].Width = 45;
            gvCalificacion.Columns[9].Width = 200;
            gvCalificacion.Columns[10].Width = 45;
            gvCalificacion.Columns[11].Width = 200;//subclase
            gvCalificacion.Columns[12].Width = 45;
            gvCalificacion.Columns[13].Width = 80;
            gvCalificacion.Columns[14].Width = 80;
            gvCalificacion.Columns[15].Width = 80;
            gvCalificacion.Columns[16].Width = 80;
            gvCalificacion.Columns[17].Width = 60;
            gvCalificacion.Columns[18].Width = 60;
            gvCalificacion.Columns[19].Width = 80;
            gvCalificacion.Columns[20].Width = 80;
            gvCalificacion.Columns[21].Width = 80;
            gvCalificacion.Columns[22].Width = 80;
            gvCalificacion.Columns[23].Width = 80;
            gvCalificacion.Columns[24].Width = 80;
            gvCalificacion.Columns[25].Width = 80;
            gvCalificacion.Columns[26].Width = 80;
            gvCalificacion.Columns[27].Width = 80;
            gvCalificacion.Columns[28].Width = 120;
            gvCalificacion.Columns[29].Width = 80;



            gvCalificacion.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvCalificacion.Columns[1].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvCalificacion.Columns[2].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvCalificacion.Columns[3].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvCalificacion.Columns[4].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvCalificacion.Columns[5].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvCalificacion.Columns[6].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvCalificacion.Columns[7].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvCalificacion.Columns[8].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvCalificacion.Columns[9].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvCalificacion.Columns[10].HeaderCell.Style.BackColor = Color.LightSalmon;
            gvCalificacion.Columns[11].HeaderCell.Style.BackColor = Color.LightSalmon;//subclase

            gvCalificacion.Columns[12].HeaderCell.Style.BackColor = Color.LightCoral;
            gvCalificacion.Columns[13].HeaderCell.Style.BackColor = Color.LightCoral;//costos anterior

            gvCalificacion.Columns[14].HeaderCell.Style.BackColor = Color.LightGreen;
            gvCalificacion.Columns[15].HeaderCell.Style.BackColor = Color.LightGreen;//costos actual
            gvCalificacion.Columns[16].HeaderCell.Style.BackColor = Color.LightGreen;

            gvCalificacion.Columns[17].HeaderCell.Style.BackColor = Color.LightPink;
            gvCalificacion.Columns[18].HeaderCell.Style.BackColor = Color.LightPink;//ventas piezas
            gvCalificacion.Columns[19].HeaderCell.Style.BackColor = Color.LightPink;

            gvCalificacion.Columns[20].HeaderCell.Style.BackColor = Color.LightSeaGreen;//inventario
            gvCalificacion.Columns[21].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            gvCalificacion.Columns[22].HeaderCell.Style.BackColor = Color.LightSeaGreen;//

            gvCalificacion.Columns[23].HeaderCell.Style.BackColor = Color.LightSkyBlue;//bonificacion
            gvCalificacion.Columns[24].HeaderCell.Style.BackColor = Color.LightSkyBlue;//efectiva
            gvCalificacion.Columns[25].HeaderCell.Style.BackColor = Color.LightSkyBlue;//calificacion

            gvCalificacion.Columns[26].HeaderCell.Style.BackColor = Color.LightCoral;
            gvCalificacion.Columns[27].HeaderCell.Style.BackColor = Color.LightCoral;//onhandplus
            gvCalificacion.Columns[28].HeaderCell.Style.BackColor = Color.LightCoral;
            gvCalificacion.Columns[29].HeaderCell.Style.BackColor = Color.LightCoral;


            gvCalificacion.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            gvCalificacion.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            gvCalificacion.EnableHeadersVisualStyles = false;

            foreach (DataGridViewRow row in gvCalificacion.Rows)
            {
                // Pagar
                if (Convert.ToString(row.Cells[27].Value) == "P a g a r") { row.Cells[27].Style.BackColor = Color.LightGreen; }
                // 15%
                if (Convert.ToString(row.Cells[27].Value) == "15%") { row.Cells[27].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(row.Cells[27].Value) ==  "20%") { row.Cells[27].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(row.Cells[27].Value) == "25%") { row.Cells[27].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(row.Cells[27].Value) == "30%") { row.Cells[27].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(row.Cells[27].Value) == "35%") { row.Cells[27].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(row.Cells[27].Value) == "40%") { row.Cells[27].Style.BackColor = Color.LightSalmon; }
                // Dev ó 40%
                if (Convert.ToString(row.Cells[27].Value) == "Dev ó 40%") { row.Cells[27].Style.BackColor = Color.Red; row.Cells[27].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(row.Cells[27].Value) == "Dev o 50%") { row.Cells[27].Style.BackColor = Color.Red; row.Cells[27].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(row.Cells[27].Value) == "Dev ó 50%") { row.Cells[27].Style.BackColor = Color.Red; row.Cells[27].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(row.Cells[27].Value) == "Devolucion") { row.Cells[27].Style.BackColor = Color.Red; row.Cells[27].Style.ForeColor = Color.White; }

                //try
                //{
                //    gvCalificacion.Columns["COMPRAS"].DisplayIndex = 44;
                //    gvCalificacion.Columns[44].Visible = false;
                //    gvCalificacion.Columns["CONTRALORIA"].DisplayIndex = 50;
                //    gvCalificacion.Columns[51].Visible = false;

                //    gvCalificacion.Columns[53].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                //    gvCalificacion.Columns[54].HeaderCell.Style.BackColor = Color.LightSalmon;
                //}
                //catch (Exception er) { }
            }
        }
      
        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }


        private void gvAdminHeader_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            //string s = e.Row.Cells[1].Value.ToString();
            //Negocio.Procesos.Temporada.GetInstance().AgregaHeaderTemporadas(0, 0, 0, "", "", "", "", "", "");
        }

    }
}