﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace MmsWin.Front.Procesos
{
    public partial class EnvioCorreoDiferenciado : Form
    {
        string marca;
        string marcaTXT;

        public EnvioCorreoDiferenciado()
        {
            InitializeComponent();
        }

        private void mcCalendar_DateSelected(object sender, DateRangeEventArgs e)
        {
            string fechaVal;
            string NomDiaSem;
            tbFchEfec.Text = mcCalendar.SelectionEnd.ToShortDateString();
            fechaVal = tbFchEfec.Text;
            NomDiaSem = MmsWin.Negocio.Utilerias.Utilerias.NombreDiaSem(fechaVal);
            if (NomDiaSem != "")
            {
                tbFchEfec.Text = mcCalendar.SelectionEnd.ToShortDateString();
                mcCalendar.Visible = false;
                btnProcesar.Focus();
            }
            else
            {
                MessageBox.Show("La fecha no es lunes");
                tbFchEfec.Text = "";
            } 
        }

        private void mcCalendar_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcCalendar.Visible = false;
                tbFchEfec.Focus();
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private DataTable ObtenerTdasDiferenciadas(string tienda, DataTable dtacumulaTdas)
        {

            return dtacumulaTdas;
        }

        private void btnProcesar_Click(object sender, EventArgs e)
        {
            string fchVal;
            Boolean indFchBon;
            Boolean indFchEfe;
            fchVal = tbFechaBon.Text;

            indFchBon = MmsWin.Negocio.Utilerias.Utilerias.fecha(fchVal);
            fchVal = tbFchEfec.Text;
            indFchEfe = MmsWin.Negocio.Utilerias.Utilerias.fecha(fchVal);

            if (tbFechaBon.Text != "")
            {
                if (indFchBon == true && indFchEfe == true)
                {
                    if (marca != "999")
                    {
                        string message = "Esta seguro de procesar esta fecha?";
                        string caption = "Confirmación";
                        MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                        DialogResult result;
                        result = MessageBox.Show(message, caption, buttons);
                        if (result == System.Windows.Forms.DialogResult.Yes)
                        {
                            this.Cursor = Cursors.WaitCursor;
                            string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                            string ParFchBon = tbFechaBon.Text;
                            ParFchBon = ParFchBon.Substring(8, 2) + ParFchBon.Substring(3, 2) + ParFchBon.Substring(0, 2);
                            string ParFchEfe = tbFchEfec.Text;
                            ParFchEfe = ParFchEfe.Substring(8, 2) + ParFchEfe.Substring(3, 2) + ParFchEfe.Substring(0, 2);

                            // Genera Estilos y tiendas a enviar RPG
                            MmsWin.Negocio.Utilerias.Utilerias.EjecutaCorreosDiferenciados(ParFchBon, ParFchEfe, ParUsuario);

                            string ParMarca = marca;
                            string textMarca = marcaTXT.Trim();

                            #region tbEstilosDiferenciados CAMPOS DE TODOS LOS ESTILOS A ENVIAR POR TIENDA
                            System.Data.DataTable tbEstilosDiferenciados = null;

                            System.Data.DataTable tbEstilosDifSeleccinados = new System.Data.DataTable("EstilosDifSeleccinados");
                            tbEstilosDifSeleccinados.Columns.Add("ENVMAR", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVFBO", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVPRO", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVSTR", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVNST", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVPRV", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVNOM", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVSTY", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVDES", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVCST", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVDEP", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVDEPD", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVSDP", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVSDPD", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVCLS", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVCLSD", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVSCL", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVSCLD", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVPRA", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVPRN", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVFEF", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVUSR", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVFCH", typeof(String));
                            tbEstilosDifSeleccinados.Columns.Add("ENVHOR", typeof(String));
                            #endregion

                            System.Data.DataTable dtDestinatarioTodos = new System.Data.DataTable("DestinatariosTodos");
                            System.Data.DataTable dtDestinatario = new System.Data.DataTable("TiendasDiferenciadas");
                            dtDestinatario.Columns.Add("Correo", typeof(String));

                            // Toma los Estilos Generardos por marca 
                            tbEstilosDiferenciados = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenCorreosDiferenciados(ParFchBon, ParFchEfe, ParMarca, ParUsuario);

                            // Tomar los Correos Destinos para el envio
                            dtDestinatarioTodos = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenDestinoDiferenciados(textMarca);

                            #region TIENDAS MELODY
                            string tiendaAnterior = string.Empty;
                            foreach (DataRow row in tbEstilosDiferenciados.Rows)
                            {
                                // Envio por tienda ---------------------------------------------------
                                if (row["ENVSTR"].ToString() != tiendaAnterior && tiendaAnterior != "")
                                {
                                    if (tbEstilosDiferenciados.Rows.Count > 0)
                                    {
                                        // Evento      
                                        string strEventos = Eventos(tbEstilosDiferenciados, tiendaAnterior);

                                        // Destinatarios Varios

                                        DataRow workRow = dtDestinatario.NewRow();
                                        foreach (DataRow row1 in dtDestinatarioTodos.Rows)
                                        {
                                            workRow = dtDestinatario.NewRow();
                                            workRow["Correo"] = row1["LSTCOR"].ToString();
                                            dtDestinatario.Rows.Add(workRow);
                                        }

                                        // Tienda Destino 
                                        workRow = dtDestinatario.NewRow();
                                        
                                        if (textMarca == "Milano")
                                        {
                                            workRow["Correo"] = "tda" + (tiendaAnterior) + "@milano.com";
                                        }
                                        if (textMarca == "Tokyo")
                                        {
                                            workRow["Correo"] = "tda" + (tiendaAnterior) + "@tokyomx.mx";
                                        }
                                        if (textMarca == "Kaltex")
                                        {
                                            workRow["Correo"] = "tda" + (tiendaAnterior) + "@outlethf.com";
                                        }

                                        dtDestinatario.Rows.Add(workRow);

                                        // Envio de Correo
                                        EnvioEmail(tbEstilosDifSeleccinados, textMarca, ParFchEfe, strEventos, dtDestinatario);

                                        tiendaAnterior = row["ENVSTR"].ToString();

                                        dtDestinatario = null;
                                        dtDestinatario = new System.Data.DataTable("TiendasDiferenciadas");
                                        dtDestinatario.Columns.Add("Correo", typeof(String));

                                        tbEstilosDifSeleccinados = null;
                                        tbEstilosDifSeleccinados = new System.Data.DataTable("EstilosDifSeleccinados");
                                        #region Campos Melody Inizializados
                                        tbEstilosDifSeleccinados.Columns.Add("ENVMAR", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVFBO", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVPRO", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVSTR", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVNST", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVPRV", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVNOM", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVSTY", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVDES", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVCST", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVDEP", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVDEPD", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVSDP", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVSDPD", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVCLS", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVCLSD", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVSCL", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVSCLD", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVPRA", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVPRN", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVFEF", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVUSR", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVFCH", typeof(String));
                                        tbEstilosDifSeleccinados.Columns.Add("ENVHOR", typeof(String));
                                        #endregion // fin Campos Melody
                                        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                                        DataRow workRowS = tbEstilosDifSeleccinados.NewRow();
                                        #region Registros Melody Primer Registro
                                        workRowS["ENVMAR"] = row["ENVMAR"].ToString();
                                        workRowS["ENVFBO"] = row["ENVFBO"].ToString();
                                        workRowS["ENVPRO"] = row["ENVPRO"].ToString();
                                        workRowS["ENVSTR"] = row["ENVSTR"].ToString();
                                        workRowS["ENVNST"] = row["ENVNST"].ToString();
                                        workRowS["ENVPRV"] = row["ENVPRV"].ToString();
                                        workRowS["ENVNOM"] = row["ENVNOM"].ToString();
                                        workRowS["ENVSTY"] = row["ENVSTY"].ToString();
                                        workRowS["ENVDES"] = row["ENVDES"].ToString();
                                        workRowS["ENVCST"] = row["ENVCST"].ToString();
                                        workRowS["ENVDEP"] = row["ENVDEP"].ToString();
                                        workRowS["ENVDEPD"] = row["ENVDEPD"].ToString();
                                        workRowS["ENVSDP"] = row["ENVSDP"].ToString();
                                        workRowS["ENVSDPD"] = row["ENVSDPD"].ToString();
                                        workRowS["ENVCLS"] = row["ENVCLS"].ToString();
                                        workRowS["ENVCLSD"] = row["ENVCLSD"].ToString();
                                        workRowS["ENVSCL"] = row["ENVSCL"].ToString();
                                        workRowS["ENVSCLD"] = row["ENVSCLD"].ToString();
                                        workRowS["ENVPRA"] = row["ENVPRA"].ToString();
                                        workRowS["ENVPRN"] = row["ENVPRN"].ToString();
                                        workRowS["ENVFEF"] = row["ENVFEF"].ToString();
                                        workRowS["ENVUSR"] = row["ENVUSR"].ToString();
                                        workRowS["ENVFCH"] = row["ENVFCH"].ToString();
                                        workRowS["ENVHOR"] = row["ENVHOR"].ToString();
                                        tbEstilosDifSeleccinados.Rows.Add(workRowS);
                                        #endregion // fin registros melody
                                    }
                                }
                                else
                                {
                                    tiendaAnterior = row["ENVSTR"].ToString();

                                    DataRow workRowS = tbEstilosDifSeleccinados.NewRow();
                                    #region Registros Acumulados Melody
                                    workRowS["ENVMAR"] = row["ENVMAR"].ToString();
                                    workRowS["ENVFBO"] = row["ENVFBO"].ToString();
                                    workRowS["ENVPRO"] = row["ENVPRO"].ToString();
                                    workRowS["ENVSTR"] = row["ENVSTR"].ToString();
                                    workRowS["ENVNST"] = row["ENVNST"].ToString();
                                    workRowS["ENVPRV"] = row["ENVPRV"].ToString();
                                    workRowS["ENVNOM"] = row["ENVNOM"].ToString();
                                    workRowS["ENVSTY"] = row["ENVSTY"].ToString();
                                    workRowS["ENVDES"] = row["ENVDES"].ToString();
                                    workRowS["ENVCST"] = row["ENVCST"].ToString();
                                    workRowS["ENVDEP"] = row["ENVDEP"].ToString();
                                    workRowS["ENVDEPD"] = row["ENVDEPD"].ToString();
                                    workRowS["ENVSDP"] = row["ENVSDP"].ToString();
                                    workRowS["ENVSDPD"] = row["ENVSDPD"].ToString();
                                    workRowS["ENVCLS"] = row["ENVCLS"].ToString();
                                    workRowS["ENVCLSD"] = row["ENVCLSD"].ToString();
                                    workRowS["ENVSCL"] = row["ENVSCL"].ToString();
                                    workRowS["ENVSCLD"] = row["ENVSCLD"].ToString();
                                    workRowS["ENVPRA"] = row["ENVPRA"].ToString();
                                    workRowS["ENVPRN"] = row["ENVPRN"].ToString();
                                    workRowS["ENVFEF"] = row["ENVFEF"].ToString();
                                    workRowS["ENVUSR"] = row["ENVUSR"].ToString();
                                    workRowS["ENVFCH"] = row["ENVFCH"].ToString();
                                    workRowS["ENVHOR"] = row["ENVHOR"].ToString();
                                    #endregion // fin de Registros acumulados Melody
                                    tbEstilosDifSeleccinados.Rows.Add(workRowS);
                                }
                            }       // End foreach -------------------------------------------------

                            #region ENVIO DE LA ULTIMA TIENDA
                            if (tbEstilosDiferenciados.Rows.Count > 0)
                            {
                                // Evento      
                                string strEventos = Eventos(tbEstilosDiferenciados, tiendaAnterior);

                                // Destinatarios Varios
                                DataRow workRow = dtDestinatario.NewRow();
                                foreach (DataRow row1 in dtDestinatarioTodos.Rows)
                                {
                                    workRow = dtDestinatario.NewRow();
                                    workRow["Correo"] = row1["LSTCOR"].ToString();
                                    dtDestinatario.Rows.Add(workRow);
                                }

                                // Tienda Destino 
                                workRow = dtDestinatario.NewRow();

                                if (textMarca == "Milano")
                                {
                                    workRow["Correo"] = "tda" + (tiendaAnterior) + "@milano.com";
                                }
                                if (textMarca == "Tokyo")
                                {
                                    workRow["Correo"] = "tda" + (tiendaAnterior) + "@tokyomx.mx";
                                }
                                if (textMarca == "Kaltex")
                                {
                                    workRow["Correo"] = "tda" + (tiendaAnterior) + "@outlethf.com";
                                }

                                dtDestinatario.Rows.Add(workRow);

                                // Envio de Correo
                                EnvioEmail(tbEstilosDifSeleccinados, textMarca, ParFchEfe, strEventos, dtDestinatario);
                            #endregion
                            }
                            #endregion

                            #region TIENDAS MILANO
                            //ParMarca = "30";
                            //textMarca = "MILANO";
                            //tbEstilosDiferenciados = null;
                            //dtDestinatario = null;
                            //dtDestinatario.Columns.Add("Correo", typeof(String));
                            //tbEstilosDiferenciados = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenCorreosDiferenciados(ParFchBon, ParFchEfe, ParMarca, ParUsuario);
                            //dtDestinatarioTodos       = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenDestinoDiferenciados(textMarca);

                            //tiendaAnterior = "";
                            //foreach (DataRow row in tbEstilosDiferenciados.Rows)
                            //{
                            //    if (row["ENVPRN"].ToString() != tiendaAnterior && tiendaAnterior != "")
                            //    {
                            //        if (tbEstilosDiferenciados.Rows.Count > 0)
                            //        {
                            //            // Envia Correo                                                                               
                            //            string strEventos = Eventos(tbEstilosDiferenciados, tiendaAnterior);
                            //            EnvioEmail(tbEstilosDiferenciados, textMarca, ParFchEfe, strEventos, dtDestinatario);
                            //            MessageBox.Show("Se envió la Marca Milano");
                            //            this.Cursor = Cursors.Default;
                            //            this.Close();

                            //            tiendaAnterior = row["ENVPRN"].ToString();

                            //            dtDestinatario = null;
                            //            DataRow workRow = dtDestinatario.NewRow();
                            //            workRow["Correo"] = "tda" + (row["ENVSTR"].ToString()) + "@melody-milano.com.mx";
                            //            dtDestinatario.Rows.Add(workRow);
                            //        }
                            //    }
                            //    else
                            //    {
                            //        tiendaAnterior = row["ENVPRN"].ToString();

                            //        DataRow workRow = dtDestinatario.NewRow();
                            //        workRow["Correo"] = "tda" + (row["ENVSTR"].ToString()) + "@melody-milano.com.mx";
                            //        dtDestinatario.Rows.Add(workRow);
                            //    }
                            //}
                            //if (tbEstilosDiferenciados.Rows.Count > 0)
                            //{
                            //    // Envia Correo                                                                               
                            //    string strEventosMilano = Eventos(tbEstilosDiferenciados, tiendaAnterior);
                            //    EnvioEmail(tbEstilosDiferenciados, textMarca, ParFchEfe, strEventosMilano, dtDestinatario);
                            //    MessageBox.Show("Se envió la Marca Milano");
                            //    this.Cursor = Cursors.Default;
                            //    this.Close();
                            //}
                            #endregion   //fin TIENDAS MILANO

                            #region TIENDAS KALTEX
                            //ParMarca = "60";
                            //textMarca = "KALTEX";
                            //tbEstilosDiferenciados = null;
                            //dtDestinatario = null;
                            //dtDestinatario.Columns.Add("Correo", typeof(String));
                            //tbEstilosDiferenciados = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenCorreosDiferenciados(ParFchBon, ParFchEfe, ParMarca, ParUsuario);

                            //dtDestinatario            = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenDestinoDiferenciados(textMarca);

                            //tiendaAnterior = "";
                            //foreach (DataRow row in tbEstilosDiferenciados.Rows)
                            //{
                            //    if (row["ENVPRN"].ToString() != tiendaAnterior && tiendaAnterior != "")
                            //    {
                            //        if (tbEstilosDiferenciados.Rows.Count > 0)
                            //        {
                            //            // Envia Correo                                                                               
                            //            string strEventos = Eventos(tbEstilosDiferenciados, tiendaAnterior);
                            //            EnvioEmail(tbEstilosDiferenciados, textMarca, ParFchEfe, strEventos, dtDestinatario);
                            //            MessageBox.Show("Se envió la Marca Kaltex");
                            //            this.Cursor = Cursors.Default;
                            //            this.Close();

                            //            tiendaAnterior = row["ENVPRN"].ToString();
                            //            dtDestinatario = null;
                            //            DataRow workRow = dtDestinatario.NewRow();
                            //            workRow["Correo"] = "tda" + (row["ENVSTR"].ToString()) + "@melody-milano.com.mx";
                            //            dtDestinatario.Rows.Add(workRow);
                            //        }
                            //    }
                            //    else
                            //    {
                            //        tiendaAnterior = row["ENVPRN"].ToString();
                            //        DataRow workRow = dtDestinatario.NewRow();
                            //        workRow["Correo"] = "tda" + (row["ENVSTR"].ToString()) + "@melody-milano.com.mx";
                            //        dtDestinatario.Rows.Add(workRow);
                            //    }
                            //}
                            //if (tbEstilosDiferenciados.Rows.Count > 0)
                            //{
                            //    // Envia Correo                                                                               
                            //    string strEventosKaltex = Eventos(tbEstilosDiferenciados, tiendaAnterior);
                            //    EnvioEmail(tbEstilosDiferenciados, textMarca, ParFchEfe, strEventosKaltex, dtDestinatario);
                            //    MessageBox.Show("Se envió la Marca Kaltex");
                            //    this.Cursor = Cursors.Default;
                            //    this.Close();
                            //}
                            #endregion   fin tiendas KALTEX
                        }
                        else
                        {
                            MessageBox.Show("Proceso cancelado por el usuario");
                        }
                    }
                    else
                    {
                        MessageBox.Show("La marca no es valida...");
                    }
                }
                else
                {
                    MessageBox.Show("La fecha es incorrecta.");
                }
            }
            else
            {
                MessageBox.Show("No debe quedar en blanco la fecha");
            }
            this.Cursor = Cursors.Default;
            MessageBox.Show("Correos Enviados...");
            this.Close();
        }

        private void EnvioEmail(DataTable tbEnvioCorreoDiferenciado, string textMarca, string ParFchEfe, string ParEvento, DataTable dtDestinatarios)
        {
            string NumDia = "";
            string NomMes = "";
            string añoEfe = "20" + ParFchEfe.Substring(0, 2);
            int    NumMes = Convert.ToInt16(ParFchEfe.Substring(2, 2));
                   NumDia = ParFchEfe.Substring(4, 2);

            DateTime dateValue = new DateTime(Convert.ToInt16("20" + ParFchEfe.Substring(0, 2)), Convert.ToInt16(ParFchEfe.Substring(2, 2)), Convert.ToInt16(ParFchEfe.Substring(4, 2)));
            DateTimeFormatInfo formatoFecha = CultureInfo.CurrentCulture.DateTimeFormat;
            NomMes = formatoFecha.GetMonthName(NumMes);
            NomMes = NomMes.ToUpper(); 
 
            string lin01 = "nowrap='' valign='bottom' style='width:30.25pt;border:solid windowtext 1.0pt;background:yellow;padding:0cm 3.5pt 0cm 3.5pt;height:10.0pt'> ";
            string lin02 = " align='center' style='text-align:center'><b><span style='font-size:10.0pt;font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'> ";
            string lin03 = "nowrap='' valign='bottom' style='width:30.25pt;border:solid windowtext 1.0pt;border-top:none;padding:0cm 3.5pt 0cm 3.5pt;height:10.0pt;";
            string lin04 = "<span style='font-size:10.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;";
            string lin05 = "</span><o:p></o:p></p>";

            StringBuilder mensaje = new StringBuilder();
            mensaje.Append("<html>\n");

            mensaje.Append("<p class='MsoNormal'><b><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;'>E<span style='color:black'>stimados Gerentes de Tiendas</span></span></b><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>,<o:p></o:p></span></p>");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>El presente es para comunicarles que estamos realizando rebajas de precio en punto de venta.");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>Los nuevos precios de venta &nbsp;</span><b><u><span lang='ES' style='font-size:12.0pt;font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:red'>entrarán en vigor a partir del día " + "<span style='color:Blue'>" + NumDia + " " + "<span style='color:Red'>" + "de " + "<span style='color:Blue'>" + NomMes + " " + "<span style='color:Red'>" + "del " + "<span style='color:Blue'>" + añoEfe + "  </b> </u>");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>El número de evento con el cual podrán identificar su inventario en el sistema es el:" + " <b><u> <span style='color:Blue'>" + ParEvento + " " + "  </u></b> ");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>En La ruta " + "<u><b> <span style='color:BLack'>" + "06/30/8/12/7/28</b></u>" + "<span style='color:BLack'>" + " podrán extraer del MMS el listado con las existencias de sus tiendas.");

          //  mensaje.Append("<p class='MsoNormal'><span lang='ES' style='color:#1F497D'>Los estilos que se están rebajando son los siguientes:</span><o:p></o:p></p>");
            //mensaje.Append("<p class='MsoNormal'><span lang='ES' style='background:green;color:white'> --ETIQUETA VERDE-- </span><o:p></o:p></p>");
            //mensaje.Append("<p class='MsoNormal'><span lang='ES' style='background:yellow;color:red'> --ETIQUETA AMARILLA-- </span><o:p></o:p></p>");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='background:red;color:white'> --ETIQUETA ROJA-- </span><o:p></o:p></p>");
            mensaje.Append("<table class='MsoNormalTable' border='0' cellspacing='0' cellpadding='0' width='738' style='width:553.6pt;margin-left:-1.15pt;border-collapse:collapse'>");
            mensaje.Append("   <tbody>");
            // Cabecero                                                                                                           
            mensaje.Append("     <tr style='height:10.0pt'> ");

            mensaje.Append("        <td width='40' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + " No. " + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='40' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "&nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='300' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "&nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='40' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "&nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='65' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "&nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='450' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + " &nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='51' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Costo" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='47' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "&nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='47' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Sub" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='45' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "&nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='45' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Sub" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='51' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Precio" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='100' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + " Nuevo " + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");
            mensaje.Append("     </tr> ");

            // Cabecero                                                                                                           
            mensaje.Append("     <tr style='height:10.0pt'> ");

            mensaje.Append("        <td width='40' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Prom" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='40' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Tienda" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='300' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "__________Nombre__________" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='40' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Prov" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='65' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Estilo" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='450' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "_______________Descripción________________" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='51' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Actual" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='47' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Depto" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='47' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Depto" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='45' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Clase" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='45' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Clase" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='100' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Actual " + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='100' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "_Precio._" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");
            mensaje.Append("     </tr> ");

            foreach (DataRow row in     tbEnvioCorreoDiferenciado.Rows)
            {
                string promocion = row["ENVPRO"].ToString();
                string tienda    = row["ENVSTR"].ToString();
                string nombreTda = row["ENVNST"].ToString();
                string proveedor = row["ENVPRV"].ToString();
                string estilo    = row["ENVSTY"].ToString();
                string descrip   = row["ENVDES"].ToString();
                string costo     = row["ENVCST"].ToString();
                string depto     = row["ENVDEP"].ToString();
                string subDepto  = row["ENVSDP"].ToString();
                string clase     = row["ENVCLS"].ToString();
                string subClase  = row["ENVSCL"].ToString();
                string precioAct = row["ENVPRA"].ToString();
                string precioNue = row["ENVPRN"].ToString();

                // Detalle                                                                                                           
                mensaje.Append("     <tr style='height:10.0pt'> ");
                mensaje.Append("<td width='40' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='center'>" + lin04 + "color:black'>" + promocion + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='40' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='right'>" + lin04 + "color:black'>" + tienda + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='300' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='left'>" + lin04 + "color:black'>" + nombreTda + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='40' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='right'>" + lin04 + "color:black'>"  + proveedor + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='65' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='left'>" + lin04 + "color:black'>"   + estilo + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='450' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='left'>" + lin04 + "color:black'>"   + descrip + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='51' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='right'>" + lin04 + "color:black'>"  + costo + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='47' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='center'>" + lin04 + "color:black'>" + depto + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='47' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='center'>" + lin04 + "color:black'>" + subDepto + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='45' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='center'>" + lin04 + "color:black'>" + clase + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='45' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='center'>" + lin04 + "color:black'>" + subClase + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='51' " + lin03 + "background:#FFC000" + "'>");
                mensaje.Append("<p class='MsoNormal' align='right'>" + lin04 + "background:#FFC000;color:black'>" + precioAct + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='82' " + lin03 + "background:yellow" + "'>" );
                mensaje.Append("<p class='MsoNormal' align='right'>" + lin04 + "background:yellow;color:black'><b>" + "$ " + precioNue + lin05 + "</b>");
                mensaje.Append("</td>");
                mensaje.Append("     </tr> ");
            }
            mensaje.Append("   </tbody>");
            mensaje.Append("</table>");
            mensaje.Append("<p class='MsoNormal'><b><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>Se les pide identificar la mercancía, imprimir sus etiquetas con el nuevo precio y etiquetarla </span></b><b><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:#1F497D'>");
            mensaje.Append("</span></b><b><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'> ya que no les llegaran etiquetas por valija.</span></b><o:p></o:p></p>");  
            mensaje.Append("<p class='MsoNormal'><b><u><span lang='ES' style='font-size:12.0pt;font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;'>Por favor les pedimos que hagan su cierre de día correctamente para efectos de que no tengan problema en su punto de venta</span></u></b><o:p></o:p></p>");

            mensaje.Append("</html>\n");

            EnviarCorreo("REBAJAS DIFERENCIADAS EN PUNTO DE VENTA " + textMarca, mensaje.ToString(), dtDestinatarios); 
        }

        private void EnviarCorreo(string asunto, string mensaje, DataTable dtDestinatarios) 
        {
            string[] archivosPDF = new string[1];

            MailMessage correo = new MailMessage();

            correo.From = new System.Net.Mail.MailAddress("rebajas_gop@milano.com"); 

            foreach (DataRow row in dtDestinatarios.Rows)
            {
                string destinatarios = row["Correo"].ToString();
                correo.To.Add(destinatarios);
            }
            correo.Subject    = asunto;
            correo.Body       = mensaje;
            correo.IsBodyHtml = true;

            
            enviarRecursivo(correo);
        }

        public void enviarRecursivo(MailMessage correo)
        {
            correo.Priority = System.Net.Mail.MailPriority.Normal;

            SmtpClient smtp = new SmtpClient();
            smtp.Host = "SRV-EXCHANGE.milano-melody.net"; 
            smtp.Port = 587;
            smtp.Credentials = new System.Net.NetworkCredential("rebajas_gop", "MILANO.30"); 
            smtp.EnableSsl = true;

            try
            {
                smtp.Send(correo);
            }
            catch (Exception ex)
            {
                Thread.Sleep(10000);
                enviarRecursivo(correo);
            }
        }


        private string Eventos(DataTable dtEnvioCorreoDiferenciado, string tiendaAnterior)
        {
            string promocion = "";
            foreach (DataRow row in dtEnvioCorreoDiferenciado.Rows)
            {
                if (row["ENVSTR"].ToString() == tiendaAnterior)
                {
                    promocion = row["ENVPRO"].ToString();
                    break;
                }
            }
            return promocion;
        }

        private void ProcessAll_Load(object sender, EventArgs e)
        {
            marca = "999";

            // Carga de Marca
            try
            {
                BindMarca();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            lbDe.Text = "Rebajas GOP ";
            tbAsunto.Text = " REBAJAS DIFERENCIADAS EN PUNTO DE VENTA ";

            // Combos x Default


            marca = MmsWin.Front.Utilerias.VarTem.tmpUSRMAR;
            cbMarca.SelectedValue = marca;

            marca = cbMarca.SelectedValue.ToString();
            if (marca == "999")
            {
                this.Controls["gbMarca"].Enabled = true;
            }

        }

        protected void BindMarca()
        {
            try
            {
                cbMarca.DataSource = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();
                cbMarca.DisplayMember = "Value";
                cbMarca.ValueMember = "Key";
                marca = "30";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void tbFechaBon_Click(object sender, EventArgs e)
        {
            mcCal01.Visible = true;
            mcCal01.Focus();
        }

        private void mCal01_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcCal01.Visible = false;
                tbFechaBon.Focus();
            }
        }

        private void mcCal01_DateSelected(object sender, DateRangeEventArgs e)
        {
            string fechaVal;
            string NomDiaSem;
            tbFechaBon.Text = mcCal01.SelectionEnd.ToShortDateString();
            fechaVal = tbFechaBon.Text;
            NomDiaSem = MmsWin.Negocio.Utilerias.Utilerias.NombreDiaSem(fechaVal);
            //if (NomDiaSem == "lunes")
            //{
                tbFechaBon.Text = mcCal01.SelectionEnd.ToShortDateString();
                mcCal01.Visible = false;
                btnProcesar.Focus();
            //}
            //else
            //{
            //    MessageBox.Show("La fecha no es lunes");
            //    tbFechaBon.Text = "";
            //}
        }

        private void tbFchEfec_Click(object sender, EventArgs e)
        {
            mcCalendar.Visible = true;
            mcCalendar.Focus();
        }

        private void btPara_Click(object sender, EventArgs e)
        {

        }

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                marca = " ";
                ComboBox cmbMarca = (ComboBox)sender;
                marca = cmbMarca.SelectedValue.ToString();
                marcaTXT = cmbMarca.SelectedItem.ToString().Split(',')[1].Replace("]","");
                MmsWin.Front.Utilerias.VarTem.tmpMarca = marca;
                MmsWin.Front.Utilerias.VarTem.parmarca = marca;

                //eMarcaComprador.MarcaID = cmbMarca.SelectedValue.ToString();
                //this.Opener.RecibeEntidades(eMarcaComprador);
            }
            catch { }
        }
    }
}
