﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Procesos
{
    public partial class EnvioCorreo : Form
    {
        public EnvioCorreo()
        {
            InitializeComponent();
        }

        private void mcCalendar_DateSelected(object sender, DateRangeEventArgs e)
        {
            string fechaVal;
            string NomDiaSem;
            tbFchEfec.Text = mcCalendar.SelectionEnd.ToShortDateString();
            fechaVal = tbFchEfec.Text;
            NomDiaSem = MmsWin.Negocio.Utilerias.Utilerias.NombreDiaSem(fechaVal);
            if (NomDiaSem != "")
            {
                tbFchEfec.Text = mcCalendar.SelectionEnd.ToShortDateString();
                mcCalendar.Visible = false;
                btnProcesar.Focus();
            }
            else
            {
                MessageBox.Show("La fecha no es lunes");
                tbFchEfec.Text = "";
            } 
        }

        private void mcCalendar_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcCalendar.Visible = false;
                tbFchEfec.Focus();
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnProcesar_Click(object sender, EventArgs e)
        {
            string fchVal;
            Boolean indFchBon;
            Boolean indFchEfe;
            fchVal = tbFechaBon.Text;
            indFchBon = MmsWin.Negocio.Utilerias.Utilerias.fecha(fchVal);
            fchVal = tbFchEfec.Text;
            indFchEfe = MmsWin.Negocio.Utilerias.Utilerias.fecha(fchVal);

            if (tbFechaBon.Text != "")
            {
                if (indFchBon == true && indFchEfe == true)
                {
                    string message = "Esta seguro de procesar esta fecha?";
                    string caption = "Confirmación";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result;
                    result = MessageBox.Show(message, caption, buttons);
                    if (result == System.Windows.Forms.DialogResult.Yes)
                    {
                        this.Cursor = Cursors.WaitCursor;
                        string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        string ParFchBon = tbFechaBon.Text;
                        ParFchBon = ParFchBon.Substring(8, 2) + ParFchBon.Substring(3, 2) + ParFchBon.Substring(0, 2);
                        string ParFchEfe = tbFchEfec.Text;
                        ParFchEfe = ParFchEfe.Substring(8, 2) + ParFchEfe.Substring(3, 2) + ParFchEfe.Substring(0, 2);

                        MmsWin.Negocio.Utilerias.Utilerias.EjecutaCorreos(ParFchBon, ParFchEfe, ParUsuario);

                        string ParMarca = "10";
                        string textMarca = "MELODY"; 
                        System.Data.DataTable tbEnvioCorreo = null;
                        System.Data.DataTable dtDestinatario = null;
                        tbEnvioCorreo = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenCorreos(ParFchBon, ParFchEfe, ParMarca, ParUsuario);
                        dtDestinatario = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenDestino(textMarca);

                        if (tbEnvioCorreo.Rows.Count > 0)
                        {
                            // Envia Correo                                                                               
                            string strEventos = Eventos(tbEnvioCorreo);
                            EnvioEmail(tbEnvioCorreo, textMarca, ParFchEfe, strEventos, dtDestinatario);

                            MessageBox.Show("Se envió la Marca Melody");    
                            this.Cursor = Cursors.Default;
                            this.Close();
                        }

                        ParMarca = "30";
                        textMarca = "MILANO";
                        tbEnvioCorreo = null;
                        tbEnvioCorreo = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenCorreos(ParFchBon, ParFchEfe, ParMarca, ParUsuario);
                        dtDestinatario = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenDestino(textMarca);

                        if (tbEnvioCorreo.Rows.Count > 0)
                        {
                            // Envia Correo                                                                               
                            string strEventos = Eventos(tbEnvioCorreo);
                            EnvioEmail(tbEnvioCorreo, textMarca, ParFchEfe, strEventos, dtDestinatario);

                            MessageBox.Show("Se envió la Marca Milano");
                            this.Cursor = Cursors.Default;
                            this.Close();
                        }

                        ParMarca = "60";
                        textMarca = "KALTEX";
                        tbEnvioCorreo = null;
                        tbEnvioCorreo = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenCorreos(ParFchBon, ParFchEfe, ParMarca, ParUsuario);
                        dtDestinatario = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenDestino(textMarca);

                        if (tbEnvioCorreo.Rows.Count > 0)
                        {
                            // Envia Correo                                                                               
                            string strEventos = Eventos(tbEnvioCorreo);
                            EnvioEmail(tbEnvioCorreo, textMarca, ParFchEfe, strEventos, dtDestinatario);

                            MessageBox.Show("Se envió la Marca Kaltex");
                            this.Cursor = Cursors.Default;
                            this.Close();
                        }
                        this.Cursor = Cursors.Default;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Proceso cancelado por el usuario");
                    }
                }
                else
                {
                    MessageBox.Show("La fecha es incorrecta.");
                }
            }
            else
            {
                MessageBox.Show("No debe quedar en blanco la fecha");
            }
        }

        private void EnvioEmail(DataTable tbEnvioCorreo, string textMarca, string ParFchEfe, string ParEvento, DataTable dtDestinatarios)
        {
            string NumDia = "";
            string NomMes = "";
            string añoEfe = "20" + ParFchEfe.Substring(0, 2);
            int    NumMes = Convert.ToInt16(ParFchEfe.Substring(2, 2));
                   NumDia = ParFchEfe.Substring(4, 2);

            DateTime dateValue = new DateTime(Convert.ToInt16("20" + ParFchEfe.Substring(0, 2)), Convert.ToInt16(ParFchEfe.Substring(2, 2)), Convert.ToInt16(ParFchEfe.Substring(4, 2)));
            DateTimeFormatInfo formatoFecha = CultureInfo.CurrentCulture.DateTimeFormat;
            NomMes = formatoFecha.GetMonthName(NumMes);
            NomMes = NomMes.ToUpper(); 
 
            string lin01 = "nowrap='' valign='bottom' style='width:30.25pt;border:solid windowtext 1.0pt;background:yellow;padding:0cm 3.5pt 0cm 3.5pt;height:10.0pt'> ";
            string lin02 = " align='center' style='text-align:center'><b><span style='font-size:10.0pt;font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'> ";
            string lin03 = "nowrap='' valign='bottom' style='width:30.25pt;border:solid windowtext 1.0pt;border-top:none;padding:0cm 3.5pt 0cm 3.5pt;height:10.0pt;";
            string lin04 = "<span style='font-size:10.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;";
            string lin05 = "</span><o:p></o:p></p>";

            StringBuilder mensaje = new StringBuilder();
            mensaje.Append("<html>\n");

            mensaje.Append("<p class='MsoNormal'><b><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;'>E<span style='color:black'>stimados Gerentes de Tiendas</span></span></b><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>,<o:p></o:p></span></p>");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>El presente es para comunicarles que estamos realizando rebajas de precio en punto de venta.");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>Los nuevos precios de venta &nbsp;</span><b><u><span lang='ES' style='font-size:12.0pt;font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:red'>entrarán en vigor a partir del día " + "<span style='color:Blue'>" + NumDia + " " + "<span style='color:Red'>" + "de " + "<span style='color:Blue'>" + NomMes + " " + "<span style='color:Red'>" + "del " + "<span style='color:Blue'>" + añoEfe + "  </b> </u>");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>El número de evento con el cual podrán identificar su inventario en el sistema es el:" + " <b><u> <span style='color:Blue'>" + ParEvento + " " + "  </u></b> ");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>En La ruta " + "<u><b> <span style='color:BLack'>" + "06/30/8/12/7/28</b></u>" + "<span style='color:BLack'>" + " podrán extraer del MMS el listado con las existencias de sus tiendas.");

            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='color:#1F497D'>Los estilos que se están rebajando son los siguientes:</span><o:p></o:p></p>");
            mensaje.Append("<table class='MsoNormalTable' border='0' cellspacing='0' cellpadding='0' width='738' style='width:553.6pt;margin-left:-1.15pt;border-collapse:collapse'>");
            mensaje.Append("   <tbody>");
            // Cabecero                                                                                                           
            mensaje.Append("     <tr style='height:10.0pt'> ");
            mensaje.Append("        <td width='40' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + " No. " + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='40' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "&nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='65' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "&nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='450' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + " &nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='51' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Costo" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='47' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "&nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='47' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Sub" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='45' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "&nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='45' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Sub" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='51' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Precio" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='100' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + " Nuevo " + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");
            mensaje.Append("     </tr> ");

            // Cabecero                                                                                                           
            mensaje.Append("     <tr style='height:10.0pt'> ");
            mensaje.Append("        <td width='40' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Prom" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='40' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Prov" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='65' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Estilo" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='450' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "___________Descripción________________" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='51' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Actual" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='47' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Depto" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='47' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Depto" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='45' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Clase" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='45' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Clase" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='100' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Actual " + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='100' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "_Precio._" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");
            mensaje.Append("     </tr> ");

            foreach (DataRow row in tbEnvioCorreo.Rows)
            {
                string promocion = row["ENVPRO"].ToString();
                string proveedor = row["ENVPRV"].ToString();
                string estilo    = row["ENVSTY"].ToString();
                string descrip   = row["ENVDES"].ToString();
                string costo     = row["ENVCST"].ToString();
                string depto     = row["ENVDEP"].ToString();
                string subDepto  = row["ENVSDP"].ToString();
                string clase     = row["ENVCLS"].ToString();
                string subClase  = row["ENVSCL"].ToString();
                string precioAct = row["ENVPRA"].ToString();
                string precioNue = row["ENVPRN"].ToString();

                // Detalle                                                                                                           
                mensaje.Append("     <tr style='height:10.0pt'> ");
                mensaje.Append("<td width='40' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='center'>" + lin04 + "color:black'>" + promocion + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='40' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='right'>" + lin04 + "color:black'>"  + proveedor + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='65' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='left'>" + lin04 + "color:black'>"   + estilo + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='450' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='left'>" + lin04 + "color:black'>"   + descrip + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='51' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='right'>" + lin04 + "color:black'>"  + costo + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='47' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='center'>" + lin04 + "color:black'>" + depto + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='47' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='center'>" + lin04 + "color:black'>" + subDepto + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='45' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='center'>" + lin04 + "color:black'>" + clase + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='45' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='center'>" + lin04 + "color:black'>" + subClase + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='51' " + lin03 + "background:#FFC000" + "'>");
                mensaje.Append("<p class='MsoNormal' align='right'>" + lin04 + "background:#FFC000;color:black'>" + precioAct + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='82' " + lin03 + "background:yellow" + "'>" );
                mensaje.Append("<p class='MsoNormal' align='right'>" + lin04 + "background:yellow;color:black'><b>" + "$ " + precioNue + lin05 + "</b>");
                mensaje.Append("</td>");
                mensaje.Append("     </tr> ");
            }
            mensaje.Append("   </tbody>");
            mensaje.Append("</table>");
            mensaje.Append("<p class='MsoNormal'><b><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>Se les pide identificar la mercancía, imprimir sus etiquetas con el nuevo precio y etiquetarla </span></b><b><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:#1F497D'>");
            mensaje.Append("</span></b><b><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'> ya que no les llegaran etiquetas por valija.</span></b><o:p></o:p></p>");  
            mensaje.Append("<p class='MsoNormal'><b><u><span lang='ES' style='font-size:12.0pt;font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;'>Por favor les pedimos que hagan su cierre de día correctamente para efectos de que no tengan problema en su punto de venta</span></u></b><o:p></o:p></p>");

            mensaje.Append("</html>\n");

            EnviarCorreo("REBAJAS EN PUNTO DE VENTA " + textMarca, mensaje.ToString(), dtDestinatarios); //, archivosPDF);
        }

        private void EnviarCorreo(string asunto, string mensaje, DataTable dtDestinatarios) //, string[] adjuntos)
        {
            string[] archivosPDF = new string[1];
            //archivosPDF[0] = "C:\\csharp-Excel1.xls";    // Ruta para Adjuntar Archivos al Correo

            MailMessage correo = new MailMessage();
            //correo.From = new System.Net.Mail.MailAddress("crm.mm@melody-milano.com.mx");
            //correo.From = new System.Net.Mail.MailAddress("rebajas_gop@melody-milano.com.mx");
            correo.From = new System.Net.Mail.MailAddress("rebajas_gop@milano.com");

            // for (int i = 0; i < destinatarios.Length; i++)  en la prueba no
            //     correo.Bcc.Add(destinatarios[i]);           en la prueba no  

            foreach (DataRow row in dtDestinatarios.Rows)
            {
                string Marca = row["LSTLST"].ToString();
                string destinatarios = row["LSTCOR"].ToString();
                string Nombre = row["LSTNOM"].ToString();

            correo.To.Add(destinatarios);
            //correo.CC.Add(((Usuario)Session["UsuarioActual"]).Email.Trim());
            }
            correo.Subject = asunto;
            correo.Body = mensaje;
            correo.IsBodyHtml = true;

            //for (int i = 0; i < archivosPDF.Length; i++)
            //{
            //    FileStream fs = new FileStream(archivosPDF[i], FileMode.Open, FileAccess.Read);
            //    Attachment a = new Attachment(fs, Path.GetFileName(archivosPDF[i]), MediaTypeNames.Application.Octet);
            //    correo.Attachments.Add(a);
            //}

            correo.Priority = System.Net.Mail.MailPriority.Normal;

            SmtpClient smtp = new SmtpClient();

            //smtp.Host = "172.16.50.3"; // Antes de Sep/2014
            //smtp.Port = 465;
            //smtp.Credentials = new System.Net.NetworkCredential("crm.mm", "Vtiger"); // Antes de Ene/2015
            //smtp.EnableSsl = false;

            //smtp.Host = "SRV-EXCHANGE.milano-melody.net"; // A partir de Sep/2014
            //smtp.Host = "srv-exchange.milano-melody.net"; // A partir de Sep/2014
            smtp.Host = "mail.melody-milano.com.mx"; // A partir de Abril/2019
            smtp.Port = 25;
            //smtp.Port = 587;
            //smtp.Credentials = new System.Net.NetworkCredential("crm.mm", "MILANO*164"); // A partir de Ene/2015

            // Se bloquea en el caso del puerto 25, este puerto no tiene seguridad
            //smtp.Credentials = new System.Net.NetworkCredential("rebajas_gop", "MILANO.30"); // A partir de 15/Mayo/2015
            //smtp.EnableSsl = true;

            try
            {
                smtp.Send(correo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string Eventos(DataTable dtEnvioCorreo)
        {
            string promocion = "";
            foreach (DataRow row in dtEnvioCorreo.Rows)
            {
                     promocion = row["ENVPRO"].ToString();
            }
            return promocion;
        }

        private void ProcessAll_Load(object sender, EventArgs e)
        {
            lbDe.Text = "Rebajas GOP ";
            tbAsunto.Text = " REBAJAS EN PUNTO DE VENTA ";
        }

        private void tbFechaBon_Click(object sender, EventArgs e)
        {
            mcCal01.Visible = true;
            mcCal01.Focus();
        }

        private void mCal01_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcCal01.Visible = false;
                tbFechaBon.Focus();
            }
        }

        private void mcCal01_DateSelected(object sender, DateRangeEventArgs e)
        {
            string fechaVal;
            string NomDiaSem;
            tbFechaBon.Text = mcCal01.SelectionEnd.ToShortDateString();
            fechaVal = tbFechaBon.Text;
            NomDiaSem = MmsWin.Negocio.Utilerias.Utilerias.NombreDiaSem(fechaVal);
            //if (NomDiaSem == "lunes")
            //{
                tbFechaBon.Text = mcCal01.SelectionEnd.ToShortDateString();
                mcCal01.Visible = false;
                btnProcesar.Focus();
            //}
            //else
            //{
            //    MessageBox.Show("La fecha no es lunes");
            //    tbFechaBon.Text = "";
            //}
        }

        private void tbFchEfec_Click(object sender, EventArgs e)
        {
            mcCalendar.Visible = true;
            mcCalendar.Focus();
        }

        private void btPara_Click(object sender, EventArgs e)
        {

        }
    }
}
