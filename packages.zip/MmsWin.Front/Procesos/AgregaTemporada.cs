﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Procesos
{
    public partial class AgregaTemporada : Form
    {
        public AgregaTemporada()
        {
            InitializeComponent();
            lblError.Visible = false;
        }

        private void AgregaTemporada_Load(object sender, EventArgs e)
        {
            ddlmarca.DataSource = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();
            ddlmarca.DisplayMember = "Value";
            ddlmarca.ValueMember = "Key";

            System.Data.DataTable dtTemporadas = new System.Data.DataTable("Temporada");
            dtTemporadas.Columns.Add("Des", typeof(String));
            dtTemporadas.Columns.Add("Id", typeof(String));

            dtTemporadas = MmsWin.Negocio.Catalogos.Temporada.GetInstance().ObtenTemporada();

            ddltemp.DataSource = dtTemporadas;
            ddltemp.DisplayMember = "Des";
            ddltemp.ValueMember = "Id";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int marca = int.Parse(ddlmarca.SelectedValue.ToString());

                int depto = int.Parse(txtDepto.Text);

                int subdepto = int.Parse(txtSubDepto.Text);

                int clase = int.Parse(txtClase.Text);

                int subclase = int.Parse(txtSubClase.Text);

                int temporada = int.Parse(ddltemp.SelectedValue.ToString());

                if (temporada == 999)
                {
                    throw new Exception("Seleccione una temporada");
                }

                if(marca == 999)
                {
                    throw new Exception("Seleccione una marca");
                }

                if (Negocio.Procesos.Temporada.GetInstance().ValidaJerarquia(marca, depto, subdepto, clase, subclase)                    )
                {
                    Negocio.Procesos.Temporada.GetInstance().InsertaJerarquia_Black(marca, depto, subdepto, clase, subclase, temporada, DateTime.Now.Year);
                }
                else
                {
                    throw new Exception("Jerarquia no valida.");
                }

                lblError.Visible = true;
                lblError.Text = "Guardado con Exito";
            }
            catch (Exception err)
            {
                lblError.Visible = true;
                lblError.Text = err.Message;
            }
        }


    }
}
