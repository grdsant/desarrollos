﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Procesos
{
    public partial class BonificacionesP : Form
    {

        string ParUser;
        string FechaCal;
        string FechaFmt;

        public BonificacionesP()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnProcesar_Click(object sender, EventArgs e)
        {
            string fchVal;
            Boolean indFch;
            fchVal = tbFecha.Text;
            indFch = MmsWin.Negocio.Utilerias.Utilerias.fecha(fchVal);

            if (tbFecha.Text != "" && tbFechaInicio.Text != "")
            {
                if (indFch == true)
                {
                string message = "Esta seguro de procesar esta fecha?";
                string caption = "Confirmación";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;
                result = MessageBox.Show(message, caption, buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    this.Cursor = Cursors.WaitCursor;
                    string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                    string ParFchInicio = tbFechaInicio.Text;
                    string ParFchBon = tbFecha.Text;
                    ParFchInicio = ParFchInicio.Substring(8, 2) + ParFchInicio.Substring(3, 2) + ParFchInicio.Substring(0, 2);
                    ParFchBon = ParFchBon.Substring(8, 2) + ParFchBon.Substring(3, 2) + ParFchBon.Substring(0, 2);
                    MmsWin.Negocio.Procesos.BonificacionesP.GetInstance().EjecutaBonificacionesP1(ParFchInicio, ParFchBon, ParUsuario);
                    MessageBox.Show("Se proceso la fecha indicada");
                    this.Cursor = Cursors.Default;
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Proceso cancelado por el usuario");
                }
                }
                else
                {
                    MessageBox.Show("La fecha es incorrecta.");
                }
            }
            else
            {
                MessageBox.Show("No debe quedar en blanco la fecha");
            }
        }

        private void mcCalendar_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbFecha.Text = mcCalendar.SelectionEnd.ToShortDateString();
            mcCalendar.Visible = false;

            string fchReprog;
            string NomDiaSem;
            tbFecha.Text = mcCalendar.SelectionEnd.ToShortDateString();
            fchReprog = tbFecha.Text;
            NomDiaSem = MmsWin.Negocio.Utilerias.Utilerias.NombreDiaSem(fchReprog);
            //if (NomDiaSem == "lunes")
            //{
                tbFecha.Text = mcCalendar.SelectionEnd.ToShortDateString();
                mcCalendar.Visible = false;
            //}
            //else
            //{
            //    MessageBox.Show("La fecha no es lunes");
            //    tbFecha.Text = "";
            //} 
        }

        private void BonificacionesP_Load(object sender, EventArgs e)
        {
            System.Data.DataTable tbFechaInicial = null;
            tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();

            foreach (DataRow row in tbFechaInicial.Rows)
            {
                tbFecha.Text = row["DSPFCH"].ToString();
                FechaCal = tbFecha.Text;
                FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                tbFecha.Text = FechaFmt.ToString();
                tbFechaInicio.Text = FechaFmt.ToString();
            }
                // Seguridad...
                ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                Seguridad("Procesos", "BonificacionesP", ParUser);
         }

        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
            {
                System.Data.DataTable tbSeguridad = null;
                tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
                foreach (DataRow row in tbSeguridad.Rows)
                {
                    string Controles = row["SEGCLS"].ToString();
                    string ValHab = row["SEGHAC"].ToString();
                    string ValVis = row["SEGVIC"].ToString();
                    string tipo = row["SEGTIP"].ToString();

                    AplicaSeguridad(Controles, ValHab, ValVis, tipo);
                }
            }

        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
            {
                // Aplica a Controles
                if (tipo == "Control")
                {
                    try
                    {
                        bool valorHab = false;
                        if (ValHab == "1") { valorHab = true; }

                        this.Controls[Controles].Enabled = valorHab;
                    }
                    catch { }

                    try
                    {
                        bool valorVis = false;
                        if (ValVis == "1") { valorVis = true; }
                        this.Controls[Controles].Visible = valorVis;
                    }
                    catch { }
                }
            }

        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void BonificacionesP_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("Procesos", "Bonificaciones", ParUser);
            }
        }

        private void mcCalendar_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcCalendar.Visible = false;
            }
        }

        private void tbFecha_Click(object sender, EventArgs e)
        {
            mcCalendar.Visible = true;
            mcCalendar.Focus();
        }

        private void tbFechaInicio_Click(object sender, EventArgs e)
        {
            mcCalendarInicio.Visible = true;
            mcCalendarInicio.Focus();
        }

        private void mcCalendarInicio_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbFechaInicio.Text = mcCalendarInicio.SelectionEnd.ToShortDateString(); 
            mcCalendar.Visible = false;

            string fchReprog;
            string NomDiaSem;
            tbFechaInicio.Text = mcCalendarInicio.SelectionEnd.ToShortDateString();
            fchReprog = tbFechaInicio.Text;
            NomDiaSem = MmsWin.Negocio.Utilerias.Utilerias.NombreDiaSem(fchReprog);
            //if (NomDiaSem == "lunes")
            //{
                tbFechaInicio.Text = mcCalendarInicio.SelectionEnd.ToShortDateString();
                mcCalendarInicio.Visible = false;
            //}
            //else
            //{
            //    MessageBox.Show("La fecha no es lunes");
            //    tbFechaInicio.Text = "";
            //} 
        }

        private void mcCalendarInicio_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcCalendarInicio.Visible = false;
            }
        }

    }
}
