﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Procesos
{
    public partial class EnvioCorreoDev : Form
    {
        public EnvioCorreoDev()
        {
            InitializeComponent();
        }

        private void mcCalendar_DateSelected(object sender, DateRangeEventArgs e)
        {
            string fechaVal;
            string NomDiaSem;
            tbFchEfec.Text = mcCalendar.SelectionEnd.ToShortDateString();
            fechaVal = tbFchEfec.Text;
            NomDiaSem = MmsWin.Negocio.Utilerias.Utilerias.NombreDiaSem(fechaVal);
            if (NomDiaSem != "")
            {
                tbFchEfec.Text = mcCalendar.SelectionEnd.ToShortDateString();
                mcCalendar.Visible = false;
                btnProcesar.Focus();
            }
            else
            {
                MessageBox.Show("La fecha no es lunes");
                tbFchEfec.Text = "";
            } 
        }

        private void mcCalendar_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcCalendar.Visible = false;
                tbFchEfec.Focus();
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnProcesar_Click(object sender, EventArgs e)
        {
            string fchVal;
            Boolean indFchBon;
            Boolean indFchEfe;
            fchVal = tbFechaBon.Text;
            indFchBon = MmsWin.Negocio.Utilerias.Utilerias.fecha(fchVal);
            fchVal = tbFchEfec.Text;
            indFchEfe = MmsWin.Negocio.Utilerias.Utilerias.fecha(fchVal);

            if (tbFechaBon.Text != "")
            {
                if (indFchBon == true && indFchEfe == true)
                {
                    string bodega = string.Empty;
                    string message = "Esta seguro de procesar esta fecha para devoluciones?";
                    string caption = "Confirmación";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result;
                    result = MessageBox.Show(message, caption, buttons);
                    if (result == System.Windows.Forms.DialogResult.Yes)
                    {
                        this.Cursor = Cursors.WaitCursor;
                        string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        string ParFchBon = tbFechaBon.Text;
                        ParFchBon = ParFchBon.Substring(8, 2) + ParFchBon.Substring(3, 2) + ParFchBon.Substring(0, 2);
                        string ParFchEfe = tbFchEfec.Text;
                        ParFchEfe = ParFchEfe.Substring(8, 2) + ParFchEfe.Substring(3, 2) + ParFchEfe.Substring(0, 2);

                        MmsWin.Negocio.Utilerias.Utilerias.EjecutaCorreosDev(ParFchBon, ParFchEfe, ParUsuario);

                        string ParMarca = "10";
                        string textMarca = "TOKYO";
                        
                        bodega = "908";

                        System.Data.DataTable tbEnvioCorreo = null;
                        System.Data.DataTable dtDestinatario = null;
                        tbEnvioCorreo = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenCorreosDev(ParFchBon, ParFchEfe, ParMarca, ParUsuario);
                        dtDestinatario = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenDestinoDev(textMarca);

                        if (tbEnvioCorreo.Rows.Count > 0)
                        {
                            // Envia Correo                                                                               
                            string strEventos = Eventos(tbEnvioCorreo);
                            EnvioEmail(tbEnvioCorreo, textMarca, ParFchEfe, strEventos, dtDestinatario, bodega);

                            MessageBox.Show("Se envió la Marca " + textMarca);    
                            this.Cursor = Cursors.Default;
                            this.Close();
                        }

                        ParMarca = "30";
                        textMarca = "MILANO";

                        bodega = "951";

                        tbEnvioCorreo = null;
                        tbEnvioCorreo = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenCorreosDev(ParFchBon, ParFchEfe, ParMarca, ParUsuario);
                        dtDestinatario = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenDestinoDev(textMarca);

                        if (tbEnvioCorreo.Rows.Count > 0)
                        {
                            // Envia Correo                                                                               
                            string strEventos = Eventos(tbEnvioCorreo);
                            EnvioEmail(tbEnvioCorreo, textMarca, ParFchEfe, strEventos, dtDestinatario, bodega);

                            MessageBox.Show("Se envió la Marca Milano");
                            this.Cursor = Cursors.Default;
                            this.Close();
                        }

                        ParMarca = "60";
                        textMarca = "KALTEX";

                        bodega = "997";

                        tbEnvioCorreo = null;
                        tbEnvioCorreo = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenCorreosDev(ParFchBon, ParFchEfe, ParMarca, ParUsuario);
                        dtDestinatario = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenDestinoDev(textMarca);

                        if (tbEnvioCorreo.Rows.Count > 0)
                        {
                            // Envia Correo                                                                               
                            string strEventos = Eventos(tbEnvioCorreo);
                            EnvioEmail(tbEnvioCorreo, textMarca, ParFchEfe, strEventos, dtDestinatario, bodega);

                            MessageBox.Show("Se envió la Marca Kaltex");
                            this.Cursor = Cursors.Default;
                            this.Close();
                        }
                        this.Cursor = Cursors.Default;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Proceso cancelado por el usuario");
                    }
                }
                else
                {
                    MessageBox.Show("La fecha es incorrecta.");
                }
            }
            else
            {
                MessageBox.Show("No debe quedar en blanco la fecha");
            }
        }

        private void EnvioEmail(DataTable tbEnvioCorreo, string textMarca, string ParFchEfe, string ParEvento, DataTable dtDestinatarios, string bodega)
        {
            string NumDia = "";
            string NomMes = "";
            string añoEfe = "20" + ParFchEfe.Substring(0, 2);
            int    NumMes = Convert.ToInt16(ParFchEfe.Substring(2, 2));
                   NumDia = ParFchEfe.Substring(4, 2);

            DateTime dateValue = new DateTime(Convert.ToInt16("20" + ParFchEfe.Substring(0, 2)), Convert.ToInt16(ParFchEfe.Substring(2, 2)), Convert.ToInt16(ParFchEfe.Substring(4, 2)));
            DateTimeFormatInfo formatoFecha = CultureInfo.CurrentCulture.DateTimeFormat;
            NomMes = formatoFecha.GetMonthName(NumMes);
            NomMes = NomMes.ToUpper(); 
 
            string lin01 = "nowrap='' valign='bottom' style='width:30.25pt;border:solid windowtext 1.0pt;background:blue;padding:0cm 3.5pt 0cm 3.5pt;height:10.0pt'> ";
            string lin02 = " align='center' style='text-align:center'><b><span style='font-size:10.0pt;font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:white'> ";
            string lin03 = "nowrap='' valign='bottom' style='width:30.25pt;border:solid windowtext 1.0pt;border-top:none;padding:0cm 3.5pt 0cm 3.5pt;height:10.0pt;";
            string lin04 = "<span style='font-size:10.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;;";
            string lin05 = "</span><o:p></o:p></p>";

            StringBuilder mensaje = new StringBuilder();
            mensaje.Append("<html>\n");

            mensaje.Append("<p class='MsoNormal'><b><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;'>E<span style='color:black'>stimados Gerentes de Tiendas</span></span></b><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>,<o:p></o:p></span></p>");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>Adjunto encontrarán proveedor/estilo que están sujetos a " + "&nbsp;</span><b><u><span lang='ES' style='font-size:12.0pt;font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:blue'> Devolucion a Proveedor,</b></u>" + "<span style='color:BLack'>" + " la cadena para la cual está dictada la devolución es: <b><u>" + "<span style='color:Blue'>" + textMarca + "</b></u>");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>Los datos de la devolución cargada en el sistema son: &nbsp;</span><b><u><span lang='ES' style='font-size:12.0pt;font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:blue'> " + ParEvento + " -DEV. " + "<span style='color:Blue'>" + NumDia + " " + "<span style='color:Blue'>" + "de " + "<span style='color:Blue'>" + NomMes + " " + "<span style='color:Blue'>" + "del " + "<span style='color:Blue'>" + añoEfe + ".  </b> </u>");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>La bodega a la cual tienen que hacer su devolución es la :" + " <b><u> <span style='color:Blue'>" + bodega + " " + "  </u></b> ");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>El envío de su mercancía debe hacerse a la brevedad posible y en el próximo camión como <b><u>" + "<span style='color:Blue'> URGENTE. </b></u>");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>Les sugiero impriman sus reportes del MMS con la finalidad de que puedan identificar rápidamente el inventario que tienen en sus tiendas.");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>La ruta en MMS es la siguiente: " + "<u><b> <span style='color:blue'>" + "06/30/08/12/06/28</b></u>");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>Recuerden que pueden consultar las imagenes de los estilos a devolver desde el reporte de devoluciones accesible desde la siguiente liga");
            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='font-family:&quot;Century Gothic&quot;,&quot;sans-serif&quot;;color:black'>http://reportes.melody-milano.com.mx/reportes/report/Tiendas/Operaciones/Eventos%20de%20devoluci%C3%B3n");

            mensaje.Append("<p class='MsoNormal'><span lang='ES' style='color:#3949AB'>Los estilos que están sujetos a devolución son:</span><o:p></o:p></p>");
            mensaje.Append("<table class='MsoNormalTable' border='0' cellspacing='0' cellpadding='0' width='738' style='width:553.6pt;margin-left:-1.15pt;border-collapse:collapse'>");
            mensaje.Append("   <tbody>");
            // Cabecero                                                                                                           
            mensaje.Append("     <tr style='height:10.0pt'> ");
            mensaje.Append("        <td width='40' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + " No. " + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='40' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "&nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='65' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "&nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='450' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + " &nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='47' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "&nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='47' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Sub" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='45' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "&nbsp;" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='45' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Sub" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("     </tr> ");

            // Cabecero                                                                                                           
            mensaje.Append("     <tr style='height:10.0pt'> ");
            mensaje.Append("        <td width='40' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Dev." + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='40' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Prov" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='65' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Estilo" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='450' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "___________Descripción________________" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='47' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Depto" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='47' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Depto" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='45' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Clase" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("        <td width='45' " + lin01);
            mensaje.Append("         <p class='MsoNormal' " + lin02 + "Clase" + "<o:p></o:p></span></b></p>");
            mensaje.Append("        </td>");

            mensaje.Append("     </tr> ");

            foreach (DataRow row in tbEnvioCorreo.Rows)
            {
                string promocion = row["ENVPRO"].ToString();
                string proveedor = row["ENVPRV"].ToString();
                string estilo    = row["ENVSTY"].ToString();
                string descrip   = row["ENVDES"].ToString();
                string depto     = row["ENVDEP"].ToString();
                string subDepto  = row["ENVSDP"].ToString();
                string clase     = row["ENVCLS"].ToString();
                string subClase  = row["ENVSCL"].ToString();

                // Detalle                                                                                                           
                mensaje.Append("     <tr style='height:10.0pt'> ");
                mensaje.Append("<td width='40' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='center'>" + lin04 + "color:black'>" + promocion + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='40' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='right'>" + lin04 + "color:black'>"  + proveedor + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='65' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='left'>" + lin04 + "color:black'>"   + estilo + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='450' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='left'>" + lin04 + "color:black'>"   + descrip + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='47' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='center'>" + lin04 + "color:black'>" + depto + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='47' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='center'>" + lin04 + "color:black'>" + subDepto + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='45' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='center'>" + lin04 + "color:black'>" + clase + lin05);
                mensaje.Append("</td>");
                mensaje.Append("<td width='45' " + lin03);
                mensaje.Append("<p class='MsoNormal' align='center'>" + lin04 + "color:black'>" + subClase + lin05);
                mensaje.Append("</td>");

                mensaje.Append("     </tr> ");
            }
            mensaje.Append("   </tbody>");
            mensaje.Append("</table>");

            mensaje.Append("</html>\n");

            EnviarCorreo("DEVOLUCION No. " + ParEvento + " - " + textMarca, mensaje.ToString(), dtDestinatarios); //, archivosPDF);
        }

        private void EnviarCorreo(string asunto, string mensaje, DataTable dtDestinatarios) //, string[] adjuntos)
        {
            string[] archivosPDF = new string[1];

            MailMessage correo = new MailMessage();

            //correo.From = new System.Net.Mail.MailAddress("devoluciones_gop@melody-milano.com.mx");

            correo.From = new System.Net.Mail.MailAddress("devoluciones_gop@milano.com");
                                                           
            foreach (DataRow row in dtDestinatarios.Rows)
            {
                string Marca = row["LSTLST"].ToString();
                string destinatarios = row["LSTCOR"].ToString();
                string Nombre = row["LSTNOM"].ToString();

            correo.To.Add(destinatarios);

            }
            correo.Subject = asunto;
            correo.Body = mensaje;
            correo.IsBodyHtml = true;

            correo.Priority = System.Net.Mail.MailPriority.Normal;

            SmtpClient smtp = new SmtpClient();

            //smtp.Host = "srv-exchange.milano-melody.net"; // A partir de Sep/2014
            smtp.Host = "mail.melody-milano.com.mx"; // A partir de Abril/2019

            //smtp.Port = 25;
            smtp.Port = 587;

            smtp.Credentials = new System.Net.NetworkCredential("devoluciones_gop", "MILANO.30"); // A partir de 15/Mayo/2015
            smtp.EnableSsl = true;

            try
            {
                smtp.Send(correo);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string Eventos(DataTable dtEnvioCorreo)
        {
            string promocion = "";
            foreach (DataRow row in dtEnvioCorreo.Rows)
            {
                     promocion = row["ENVPRO"].ToString();
            }
            return promocion;
        }

        private void ProcessAll_Load(object sender, EventArgs e)
        {
            lbDe.Text = "Devoluciones GOP ";
            tbAsunto.Text = " DEVOLUCIONES EN PUNTO DE VENTA ";
        }

        private void tbFechaBon_Click(object sender, EventArgs e)
        {
            mcCal01.Visible = true;
            mcCal01.Focus();
        }

        private void mCal01_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcCal01.Visible = false;
                tbFechaBon.Focus();
            }
        }

        private void mcCal01_DateSelected(object sender, DateRangeEventArgs e)
        {
            string fechaVal;
            string NomDiaSem;
            tbFechaBon.Text = mcCal01.SelectionEnd.ToShortDateString();
            fechaVal = tbFechaBon.Text;
            NomDiaSem = MmsWin.Negocio.Utilerias.Utilerias.NombreDiaSem(fechaVal);
            //if (NomDiaSem == "lunes")
            //{
                tbFechaBon.Text = mcCal01.SelectionEnd.ToShortDateString();
                mcCal01.Visible = false;
                btnProcesar.Focus();
            //}
            //else
            //{
            //    MessageBox.Show("La fecha no es lunes");
            //    tbFechaBon.Text = "";
            //}
        }

        private void tbFchEfec_Click(object sender, EventArgs e)
        {
            mcCalendar.Visible = true;
            mcCalendar.Focus();
        }

        private void btPara_Click(object sender, EventArgs e)
        {

        }
    }
}
