﻿namespace MmsWin.Front.Procesos
{
    partial class CargaTemporada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Consulta = new System.Windows.Forms.TabPage();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.txtSubclase = new System.Windows.Forms.TextBox();
            this.txtClase = new System.Windows.Forms.TextBox();
            this.txtSubdepto = new System.Windows.Forms.TextBox();
            this.txtDepto = new System.Windows.Forms.TextBox();
            this.txtEstilo = new System.Windows.Forms.TextBox();
            this.txtest = new System.Windows.Forms.TextBox();
            this.txtProveedor = new System.Windows.Forms.TextBox();
            this.txtpro = new System.Windows.Forms.TextBox();
            this.txtmarca = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cbOrigen = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cbTemporada = new System.Windows.Forms.ComboBox();
            this.gvPrincipal = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.cbCompradores = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.Carga = new System.Windows.Forms.TabPage();
            this.btnGuardaCarga = new System.Windows.Forms.Button();
            this.gvCargaEstilos = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbOrigenCarga = new System.Windows.Forms.ComboBox();
            this.cbTempCarga = new System.Windows.Forms.ComboBox();
            this.cbCompradorCarga = new System.Windows.Forms.ComboBox();
            this.cbMarcaCarga = new System.Windows.Forms.ComboBox();
            this.lblEstatusManual = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtEstiloManual = new System.Windows.Forms.TextBox();
            this.btnManualAceptar = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.txtProveedorManual = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtDepartamentoManual = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtSubpartamentoManual = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtClaseManual = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtSubclaseManual = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblEstatus = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtExcel = new System.Windows.Forms.TextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.gvAdminDet = new System.Windows.Forms.DataGridView();
            this.gvAdminHeader = new System.Windows.Forms.DataGridView();
            this.Calificar = new System.Windows.Forms.TabPage();
            this.label12 = new System.Windows.Forms.Label();
            this.ddlTIpo = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dtFin = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dtInicio = new System.Windows.Forms.DateTimePicker();
            this.ddlTempCal = new System.Windows.Forms.ComboBox();
            this.ddlMarcaCal = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.gvCalificacion = new System.Windows.Forms.DataGridView();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabControl1.SuspendLayout();
            this.Consulta.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvPrincipal)).BeginInit();
            this.Carga.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvCargaEstilos)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvAdminDet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvAdminHeader)).BeginInit();
            this.Calificar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvCalificacion)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Consulta);
            this.tabControl1.Controls.Add(this.Carga);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.Calificar);
            this.tabControl1.Location = new System.Drawing.Point(13, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1139, 623);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // Consulta
            // 
            this.Consulta.Controls.Add(this.textBox10);
            this.Consulta.Controls.Add(this.txtSubclase);
            this.Consulta.Controls.Add(this.txtClase);
            this.Consulta.Controls.Add(this.txtSubdepto);
            this.Consulta.Controls.Add(this.txtDepto);
            this.Consulta.Controls.Add(this.txtEstilo);
            this.Consulta.Controls.Add(this.txtest);
            this.Consulta.Controls.Add(this.txtProveedor);
            this.Consulta.Controls.Add(this.txtpro);
            this.Consulta.Controls.Add(this.txtmarca);
            this.Consulta.Controls.Add(this.label5);
            this.Consulta.Controls.Add(this.cbOrigen);
            this.Consulta.Controls.Add(this.label4);
            this.Consulta.Controls.Add(this.cbTemporada);
            this.Consulta.Controls.Add(this.gvPrincipal);
            this.Consulta.Controls.Add(this.label2);
            this.Consulta.Controls.Add(this.cbCompradores);
            this.Consulta.Controls.Add(this.label1);
            this.Consulta.Controls.Add(this.cbMarca);
            this.Consulta.Location = new System.Drawing.Point(4, 22);
            this.Consulta.Name = "Consulta";
            this.Consulta.Padding = new System.Windows.Forms.Padding(3);
            this.Consulta.Size = new System.Drawing.Size(1131, 597);
            this.Consulta.TabIndex = 0;
            this.Consulta.Text = "Consulta";
            this.Consulta.UseVisualStyleBackColor = true;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(0, 68);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(45, 20);
            this.textBox10.TabIndex = 18;
            // 
            // txtSubclase
            // 
            this.txtSubclase.Location = new System.Drawing.Point(748, 68);
            this.txtSubclase.Name = "txtSubclase";
            this.txtSubclase.Size = new System.Drawing.Size(50, 20);
            this.txtSubclase.TabIndex = 17;
            this.txtSubclase.TextChanged += new System.EventHandler(this.txtmarca_TextChanged);
            // 
            // txtClase
            // 
            this.txtClase.Location = new System.Drawing.Point(698, 68);
            this.txtClase.Name = "txtClase";
            this.txtClase.Size = new System.Drawing.Size(50, 20);
            this.txtClase.TabIndex = 16;
            this.txtClase.TextChanged += new System.EventHandler(this.txtmarca_TextChanged);
            // 
            // txtSubdepto
            // 
            this.txtSubdepto.Location = new System.Drawing.Point(648, 68);
            this.txtSubdepto.Name = "txtSubdepto";
            this.txtSubdepto.Size = new System.Drawing.Size(50, 20);
            this.txtSubdepto.TabIndex = 15;
            this.txtSubdepto.TextChanged += new System.EventHandler(this.txtmarca_TextChanged);
            // 
            // txtDepto
            // 
            this.txtDepto.Location = new System.Drawing.Point(598, 68);
            this.txtDepto.Name = "txtDepto";
            this.txtDepto.Size = new System.Drawing.Size(50, 20);
            this.txtDepto.TabIndex = 14;
            this.txtDepto.TextChanged += new System.EventHandler(this.txtmarca_TextChanged);
            // 
            // txtEstilo
            // 
            this.txtEstilo.Location = new System.Drawing.Point(398, 68);
            this.txtEstilo.Name = "txtEstilo";
            this.txtEstilo.Size = new System.Drawing.Size(200, 20);
            this.txtEstilo.TabIndex = 13;
            this.txtEstilo.TextChanged += new System.EventHandler(this.txtmarca_TextChanged);
            // 
            // txtest
            // 
            this.txtest.Location = new System.Drawing.Point(333, 68);
            this.txtest.Name = "txtest";
            this.txtest.Size = new System.Drawing.Size(65, 20);
            this.txtest.TabIndex = 12;
            this.txtest.TextChanged += new System.EventHandler(this.txtmarca_TextChanged);
            // 
            // txtProveedor
            // 
            this.txtProveedor.Location = new System.Drawing.Point(133, 68);
            this.txtProveedor.Name = "txtProveedor";
            this.txtProveedor.Size = new System.Drawing.Size(200, 20);
            this.txtProveedor.TabIndex = 11;
            this.txtProveedor.TextChanged += new System.EventHandler(this.txtmarca_TextChanged);
            // 
            // txtpro
            // 
            this.txtpro.Location = new System.Drawing.Point(90, 68);
            this.txtpro.Name = "txtpro";
            this.txtpro.Size = new System.Drawing.Size(45, 20);
            this.txtpro.TabIndex = 10;
            this.txtpro.TextChanged += new System.EventHandler(this.txtmarca_TextChanged);
            // 
            // txtmarca
            // 
            this.txtmarca.Location = new System.Drawing.Point(45, 68);
            this.txtmarca.Name = "txtmarca";
            this.txtmarca.Size = new System.Drawing.Size(45, 20);
            this.txtmarca.TabIndex = 9;
            this.txtmarca.TextChanged += new System.EventHandler(this.txtmarca_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(416, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Origen";
            // 
            // cbOrigen
            // 
            this.cbOrigen.FormattingEnabled = true;
            this.cbOrigen.Location = new System.Drawing.Point(470, 35);
            this.cbOrigen.Name = "cbOrigen";
            this.cbOrigen.Size = new System.Drawing.Size(121, 21);
            this.cbOrigen.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(220, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Temporada";
            // 
            // cbTemporada
            // 
            this.cbTemporada.FormattingEnabled = true;
            this.cbTemporada.Items.AddRange(new object[] {
            "INVERNAL",
            "ESCOLAR"});
            this.cbTemporada.Location = new System.Drawing.Point(284, 35);
            this.cbTemporada.Name = "cbTemporada";
            this.cbTemporada.Size = new System.Drawing.Size(121, 21);
            this.cbTemporada.TabIndex = 5;
            // 
            // gvPrincipal
            // 
            this.gvPrincipal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvPrincipal.Location = new System.Drawing.Point(0, 85);
            this.gvPrincipal.Name = "gvPrincipal";
            this.gvPrincipal.Size = new System.Drawing.Size(1182, 445);
            this.gvPrincipal.TabIndex = 4;
            this.gvPrincipal.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.gvPrincipal_UserDeletingRow);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Comprador";
            // 
            // cbCompradores
            // 
            this.cbCompradores.FormattingEnabled = true;
            this.cbCompradores.Location = new System.Drawing.Point(83, 35);
            this.cbCompradores.Name = "cbCompradores";
            this.cbCompradores.Size = new System.Drawing.Size(121, 21);
            this.cbCompradores.TabIndex = 2;
            this.cbCompradores.SelectedValueChanged += new System.EventHandler(this.cbMarca_SelectedValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(735, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Marca";
            this.label1.Visible = false;
            // 
            // cbMarca
            // 
            this.cbMarca.FormattingEnabled = true;
            this.cbMarca.Location = new System.Drawing.Point(778, 35);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(74, 21);
            this.cbMarca.TabIndex = 0;
            this.cbMarca.Visible = false;
            this.cbMarca.SelectedValueChanged += new System.EventHandler(this.cbMarca_SelectedValueChanged);
            // 
            // Carga
            // 
            this.Carga.Controls.Add(this.btnGuardaCarga);
            this.Carga.Controls.Add(this.gvCargaEstilos);
            this.Carga.Controls.Add(this.groupBox2);
            this.Carga.Controls.Add(this.groupBox1);
            this.Carga.Location = new System.Drawing.Point(4, 22);
            this.Carga.Name = "Carga";
            this.Carga.Padding = new System.Windows.Forms.Padding(3);
            this.Carga.Size = new System.Drawing.Size(1131, 597);
            this.Carga.TabIndex = 1;
            this.Carga.Text = "Carga de Datos";
            this.Carga.UseVisualStyleBackColor = true;
            // 
            // btnGuardaCarga
            // 
            this.btnGuardaCarga.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnGuardaCarga.Location = new System.Drawing.Point(199, 446);
            this.btnGuardaCarga.Name = "btnGuardaCarga";
            this.btnGuardaCarga.Size = new System.Drawing.Size(75, 23);
            this.btnGuardaCarga.TabIndex = 21;
            this.btnGuardaCarga.Text = "Guardar";
            this.btnGuardaCarga.UseVisualStyleBackColor = true;
            this.btnGuardaCarga.Click += new System.EventHandler(this.btnGuardaCarga_Click);
            // 
            // gvCargaEstilos
            // 
            this.gvCargaEstilos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvCargaEstilos.Location = new System.Drawing.Point(497, 32);
            this.gvCargaEstilos.Name = "gvCargaEstilos";
            this.gvCargaEstilos.Size = new System.Drawing.Size(685, 487);
            this.gvCargaEstilos.TabIndex = 2;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbOrigenCarga);
            this.groupBox2.Controls.Add(this.cbTempCarga);
            this.groupBox2.Controls.Add(this.cbCompradorCarga);
            this.groupBox2.Controls.Add(this.cbMarcaCarga);
            this.groupBox2.Controls.Add(this.lblEstatusManual);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.txtEstiloManual);
            this.groupBox2.Controls.Add(this.btnManualAceptar);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.txtProveedorManual);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.txtDepartamentoManual);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.txtSubpartamentoManual);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.txtClaseManual);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.txtSubclaseManual);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Location = new System.Drawing.Point(6, 163);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(474, 251);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Carga Manual";
            // 
            // cbOrigenCarga
            // 
            this.cbOrigenCarga.FormattingEnabled = true;
            this.cbOrigenCarga.Items.AddRange(new object[] {
            "NACIONAL",
            "IMPORTACION"});
            this.cbOrigenCarga.Location = new System.Drawing.Point(356, 89);
            this.cbOrigenCarga.Name = "cbOrigenCarga";
            this.cbOrigenCarga.Size = new System.Drawing.Size(100, 21);
            this.cbOrigenCarga.TabIndex = 27;
            // 
            // cbTempCarga
            // 
            this.cbTempCarga.FormattingEnabled = true;
            this.cbTempCarga.Items.AddRange(new object[] {
            "INVERNAL",
            "ESCOLAR"});
            this.cbTempCarga.Location = new System.Drawing.Point(356, 62);
            this.cbTempCarga.Name = "cbTempCarga";
            this.cbTempCarga.Size = new System.Drawing.Size(100, 21);
            this.cbTempCarga.TabIndex = 26;
            // 
            // cbCompradorCarga
            // 
            this.cbCompradorCarga.FormattingEnabled = true;
            this.cbCompradorCarga.Location = new System.Drawing.Point(356, 35);
            this.cbCompradorCarga.Name = "cbCompradorCarga";
            this.cbCompradorCarga.Size = new System.Drawing.Size(100, 21);
            this.cbCompradorCarga.TabIndex = 25;
            // 
            // cbMarcaCarga
            // 
            this.cbMarcaCarga.FormattingEnabled = true;
            this.cbMarcaCarga.Location = new System.Drawing.Point(115, 30);
            this.cbMarcaCarga.Name = "cbMarcaCarga";
            this.cbMarcaCarga.Size = new System.Drawing.Size(104, 21);
            this.cbMarcaCarga.TabIndex = 24;
            this.cbMarcaCarga.SelectedIndexChanged += new System.EventHandler(this.cbMarcaCarga_SelectedIndexChanged);
            // 
            // lblEstatusManual
            // 
            this.lblEstatusManual.AutoSize = true;
            this.lblEstatusManual.ForeColor = System.Drawing.Color.Red;
            this.lblEstatusManual.Location = new System.Drawing.Point(15, 228);
            this.lblEstatusManual.Name = "lblEstatusManual";
            this.lblEstatusManual.Size = new System.Drawing.Size(41, 13);
            this.lblEstatusManual.TabIndex = 22;
            this.lblEstatusManual.Text = "label23";
            this.lblEstatusManual.Visible = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(19, 196);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(32, 13);
            this.label24.TabIndex = 23;
            this.label24.Text = "Estilo";
            // 
            // txtEstiloManual
            // 
            this.txtEstiloManual.Location = new System.Drawing.Point(119, 193);
            this.txtEstiloManual.Name = "txtEstiloManual";
            this.txtEstiloManual.Size = new System.Drawing.Size(100, 20);
            this.txtEstiloManual.TabIndex = 22;
            // 
            // btnManualAceptar
            // 
            this.btnManualAceptar.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnManualAceptar.Location = new System.Drawing.Point(359, 215);
            this.btnManualAceptar.Name = "btnManualAceptar";
            this.btnManualAceptar.Size = new System.Drawing.Size(75, 23);
            this.btnManualAceptar.TabIndex = 20;
            this.btnManualAceptar.Text = "Cargar";
            this.btnManualAceptar.UseVisualStyleBackColor = true;
            this.btnManualAceptar.Click += new System.EventHandler(this.btnManualAceptar_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(19, 170);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(56, 13);
            this.label23.TabIndex = 21;
            this.label23.Text = "Proveedor";
            // 
            // txtProveedorManual
            // 
            this.txtProveedorManual.Location = new System.Drawing.Point(119, 167);
            this.txtProveedorManual.Name = "txtProveedorManual";
            this.txtProveedorManual.Size = new System.Drawing.Size(100, 20);
            this.txtProveedorManual.TabIndex = 20;
            this.txtProveedorManual.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDepartamentoManual_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(256, 95);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(38, 13);
            this.label15.TabIndex = 15;
            this.label15.Text = "Origen";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(256, 67);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 13);
            this.label16.TabIndex = 13;
            this.label16.Text = "Temporada";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(256, 38);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(58, 13);
            this.label17.TabIndex = 11;
            this.label17.Text = "Comprador";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(19, 64);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(74, 13);
            this.label18.TabIndex = 9;
            this.label18.Text = "Departamento";
            // 
            // txtDepartamentoManual
            // 
            this.txtDepartamentoManual.Location = new System.Drawing.Point(119, 61);
            this.txtDepartamentoManual.Name = "txtDepartamentoManual";
            this.txtDepartamentoManual.Size = new System.Drawing.Size(100, 20);
            this.txtDepartamentoManual.TabIndex = 8;
            this.txtDepartamentoManual.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDepartamentoManual_KeyPress);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(19, 91);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(91, 13);
            this.label19.TabIndex = 7;
            this.label19.Text = "Subdepartamento";
            // 
            // txtSubpartamentoManual
            // 
            this.txtSubpartamentoManual.Location = new System.Drawing.Point(119, 88);
            this.txtSubpartamentoManual.Name = "txtSubpartamentoManual";
            this.txtSubpartamentoManual.Size = new System.Drawing.Size(100, 20);
            this.txtSubpartamentoManual.TabIndex = 6;
            this.txtSubpartamentoManual.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDepartamentoManual_KeyPress);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(19, 117);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(33, 13);
            this.label20.TabIndex = 5;
            this.label20.Text = "Clase";
            // 
            // txtClaseManual
            // 
            this.txtClaseManual.Location = new System.Drawing.Point(119, 114);
            this.txtClaseManual.Name = "txtClaseManual";
            this.txtClaseManual.Size = new System.Drawing.Size(100, 20);
            this.txtClaseManual.TabIndex = 4;
            this.txtClaseManual.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDepartamentoManual_KeyPress);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(19, 143);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(51, 13);
            this.label21.TabIndex = 3;
            this.label21.Text = "Subclase";
            // 
            // txtSubclaseManual
            // 
            this.txtSubclaseManual.Location = new System.Drawing.Point(119, 140);
            this.txtSubclaseManual.Name = "txtSubclaseManual";
            this.txtSubclaseManual.Size = new System.Drawing.Size(100, 20);
            this.txtSubclaseManual.TabIndex = 2;
            this.txtSubclaseManual.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDepartamentoManual_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(19, 38);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(37, 13);
            this.label22.TabIndex = 1;
            this.label22.Text = "Marca";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblEstatus);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtExcel);
            this.groupBox1.Location = new System.Drawing.Point(6, 32);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(471, 125);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Carga Excel";
            // 
            // lblEstatus
            // 
            this.lblEstatus.AutoSize = true;
            this.lblEstatus.ForeColor = System.Drawing.Color.Maroon;
            this.lblEstatus.Location = new System.Drawing.Point(19, 84);
            this.lblEstatus.Name = "lblEstatus";
            this.lblEstatus.Size = new System.Drawing.Size(41, 13);
            this.lblEstatus.TabIndex = 23;
            this.lblEstatus.Text = "label23";
            this.lblEstatus.Visible = false;
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Location = new System.Drawing.Point(294, 79);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 21;
            this.button1.Text = "Cargar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnActualiza_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Ruta:";
            // 
            // txtExcel
            // 
            this.txtExcel.Location = new System.Drawing.Point(58, 35);
            this.txtExcel.Name = "txtExcel";
            this.txtExcel.Size = new System.Drawing.Size(311, 20);
            this.txtExcel.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.gvAdminDet);
            this.tabPage1.Controls.Add(this.gvAdminHeader);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(1131, 597);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Admin";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(33, 25);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(402, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "MANTENIMIENTO BLACK OUT DATES Y FECHAS DE CALIFICACION";
            // 
            // gvAdminDet
            // 
            this.gvAdminDet.AllowUserToAddRows = false;
            this.gvAdminDet.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvAdminDet.Location = new System.Drawing.Point(33, 223);
            this.gvAdminDet.Name = "gvAdminDet";
            this.gvAdminDet.Size = new System.Drawing.Size(785, 314);
            this.gvAdminDet.TabIndex = 4;
            this.gvAdminDet.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvAdminDet_CellDoubleClick);
            this.gvAdminDet.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.gvAdminDet_UserDeletingRow);
            // 
            // gvAdminHeader
            // 
            this.gvAdminHeader.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvAdminHeader.Location = new System.Drawing.Point(33, 62);
            this.gvAdminHeader.Name = "gvAdminHeader";
            this.gvAdminHeader.Size = new System.Drawing.Size(785, 155);
            this.gvAdminHeader.TabIndex = 3;
            this.gvAdminHeader.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.gvAdminHeader_CellContentDoubleClick);
            this.gvAdminHeader.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.gvPrincipal_UserDeletingRow);
            // 
            // Calificar
            // 
            this.Calificar.Controls.Add(this.label12);
            this.Calificar.Controls.Add(this.ddlTIpo);
            this.Calificar.Controls.Add(this.label11);
            this.Calificar.Controls.Add(this.dtFin);
            this.Calificar.Controls.Add(this.label10);
            this.Calificar.Controls.Add(this.label9);
            this.Calificar.Controls.Add(this.label8);
            this.Calificar.Controls.Add(this.dtInicio);
            this.Calificar.Controls.Add(this.ddlTempCal);
            this.Calificar.Controls.Add(this.ddlMarcaCal);
            this.Calificar.Controls.Add(this.button2);
            this.Calificar.Controls.Add(this.gvCalificacion);
            this.Calificar.Location = new System.Drawing.Point(4, 22);
            this.Calificar.Name = "Calificar";
            this.Calificar.Size = new System.Drawing.Size(1131, 597);
            this.Calificar.TabIndex = 3;
            this.Calificar.Text = "Califica";
            this.Calificar.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(632, 26);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(28, 13);
            this.label12.TabIndex = 16;
            this.label12.Text = "Tipo";
            // 
            // ddlTIpo
            // 
            this.ddlTIpo.FormattingEnabled = true;
            this.ddlTIpo.Items.AddRange(new object[] {
            "DESPLAZAMIENTO",
            "RENTABILIDAD"});
            this.ddlTIpo.Location = new System.Drawing.Point(666, 21);
            this.ddlTIpo.Name = "ddlTIpo";
            this.ddlTIpo.Size = new System.Drawing.Size(116, 21);
            this.ddlTIpo.TabIndex = 15;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(507, 26);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(13, 13);
            this.label11.TabIndex = 14;
            this.label11.Text = "a";
            // 
            // dtFin
            // 
            this.dtFin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtFin.Location = new System.Drawing.Point(526, 22);
            this.dtFin.Name = "dtFin";
            this.dtFin.Size = new System.Drawing.Size(100, 20);
            this.dtFin.TabIndex = 13;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(331, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(64, 13);
            this.label10.TabIndex = 12;
            this.label10.Text = "Recibos de:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(161, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 13);
            this.label9.TabIndex = 11;
            this.label9.Text = "Temporada";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "Marca";
            // 
            // dtInicio
            // 
            this.dtInicio.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtInicio.Location = new System.Drawing.Point(401, 23);
            this.dtInicio.Name = "dtInicio";
            this.dtInicio.Size = new System.Drawing.Size(100, 20);
            this.dtInicio.TabIndex = 9;
            // 
            // ddlTempCal
            // 
            this.ddlTempCal.FormattingEnabled = true;
            this.ddlTempCal.Location = new System.Drawing.Point(228, 22);
            this.ddlTempCal.Name = "ddlTempCal";
            this.ddlTempCal.Size = new System.Drawing.Size(97, 21);
            this.ddlTempCal.TabIndex = 8;
            // 
            // ddlMarcaCal
            // 
            this.ddlMarcaCal.FormattingEnabled = true;
            this.ddlMarcaCal.Location = new System.Drawing.Point(58, 21);
            this.ddlMarcaCal.Name = "ddlMarcaCal";
            this.ddlMarcaCal.Size = new System.Drawing.Size(97, 21);
            this.ddlMarcaCal.TabIndex = 7;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(811, 20);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 6;
            this.button2.Text = "Califica";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // gvCalificacion
            // 
            this.gvCalificacion.AllowUserToAddRows = false;
            this.gvCalificacion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gvCalificacion.Location = new System.Drawing.Point(3, 64);
            this.gvCalificacion.Name = "gvCalificacion";
            this.gvCalificacion.Size = new System.Drawing.Size(1108, 512);
            this.gvCalificacion.TabIndex = 5;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // CargaTemporada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 648);
            this.Controls.Add(this.tabControl1);
            this.Name = "CargaTemporada";
            this.Text = "Carga Temporada";
            this.Load += new System.EventHandler(this.CargaTemporada_Load);
            this.Resize += new System.EventHandler(this.CargaTemporada_Resize);
            this.tabControl1.ResumeLayout(false);
            this.Consulta.ResumeLayout(false);
            this.Consulta.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvPrincipal)).EndInit();
            this.Carga.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gvCargaEstilos)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvAdminDet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvAdminHeader)).EndInit();
            this.Calificar.ResumeLayout(false);
            this.Calificar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvCalificacion)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Consulta;
        private System.Windows.Forms.TabPage Carga;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbCompradores;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.DataGridView gvPrincipal;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtExcel;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnManualAceptar;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtDepartamentoManual;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtSubpartamentoManual;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtClaseManual;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtSubclaseManual;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblEstatusManual;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtEstiloManual;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtProveedorManual;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label lblEstatus;
        private System.Windows.Forms.DataGridView gvCargaEstilos;
        private System.Windows.Forms.Button btnGuardaCarga;
        private System.Windows.Forms.ComboBox cbCompradorCarga;
        private System.Windows.Forms.ComboBox cbMarcaCarga;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cbOrigen;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbTemporada;
        private System.Windows.Forms.ComboBox cbOrigenCarga;
        private System.Windows.Forms.ComboBox cbTempCarga;
        private System.Windows.Forms.TextBox txtmarca;
        private System.Windows.Forms.TextBox txtpro;
        private System.Windows.Forms.TextBox txtProveedor;
        private System.Windows.Forms.TextBox txtEstilo;
        private System.Windows.Forms.TextBox txtest;
        private System.Windows.Forms.TextBox txtSubclase;
        private System.Windows.Forms.TextBox txtClase;
        private System.Windows.Forms.TextBox txtSubdepto;
        private System.Windows.Forms.TextBox txtDepto;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView gvAdminHeader;
        private System.Windows.Forms.DataGridView gvAdminDet;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TabPage Calificar;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridView gvCalificacion;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox ddlTIpo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dtFin;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtInicio;
        private System.Windows.Forms.ComboBox ddlTempCal;
        private System.Windows.Forms.ComboBox ddlMarcaCal;
    }
}