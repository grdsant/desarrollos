﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Procesos
{
    public partial class ProcesaTodo : Form
    {
        public ProcesaTodo()
        {
            InitializeComponent();
        }

        private void tbFecha_Click(object sender, EventArgs e)
        {
            mcCalendar.Visible = true;
            mcCalendar.Focus();
        }

        private void mcCalendar_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbFecha.Text = mcCalendar.SelectionEnd.ToShortDateString();
            mcCalendar.Visible = false;

            string fchReprog;
            string NomDiaSem;
            tbFecha.Text = mcCalendar.SelectionEnd.ToShortDateString();
            fchReprog = tbFecha.Text;
            NomDiaSem = MmsWin.Negocio.Utilerias.Utilerias.NombreDiaSem(fchReprog);
            if (NomDiaSem == "lunes")
            {
                tbFecha.Text = mcCalendar.SelectionEnd.ToShortDateString();
                mcCalendar.Visible = false;
            }
            else
            {
                MessageBox.Show("La fecha no es lunes");
                tbFecha.Text = "";
            } 
        }

        private void mcCalendar_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcCalendar.Visible = false;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnProcesar_Click(object sender, EventArgs e)
        {
            string fchVal;
            Boolean indFch;
            fchVal = tbFecha.Text;
            indFch = MmsWin.Negocio.Utilerias.Utilerias.fecha(fchVal);

            if (tbFecha.Text != "")
            {
                if (indFch == true)
                {
                    string message = "Esta seguro de procesar esta fecha?";
                    string caption = "Confirmación";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result;
                    result = MessageBox.Show(message, caption, buttons);
                    if (result == System.Windows.Forms.DialogResult.Yes)
                    {
                        this.Cursor = Cursors.WaitCursor;
                        string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        string ParFchBon = tbFecha.Text;
                        ParFchBon = ParFchBon.Substring(8, 2) + ParFchBon.Substring(3, 2) + ParFchBon.Substring(0, 2);
                        //          MmsWin.Negocio.Procesos.BonificacionesP.GetInstance().EjecutaBonificacionesP1(ParFchBon, ParUsuario);
                        MessageBox.Show("Se proceso la fecha indicada");
                        this.Cursor = Cursors.Default;
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Proceso cancelado por el usuario");
                    }
                }
                else
                {
                    MessageBox.Show("La fecha es incorrecta.");
                }
            }
            else
            {
                MessageBox.Show("No debe quedar en blanco la fecha");
            }
        }
    }
}
