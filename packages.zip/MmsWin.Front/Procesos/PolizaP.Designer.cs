﻿namespace MmsWin.Front.Procesos
{
    partial class PolizaP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbFecha = new System.Windows.Forms.TextBox();
            this.mcCalendar = new System.Windows.Forms.MonthCalendar();
            this.btnProcesar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.gbFecha = new System.Windows.Forms.GroupBox();
            this.SuspendLayout();
            // 
            // tbFecha
            // 
            this.tbFecha.Location = new System.Drawing.Point(163, 158);
            this.tbFecha.Name = "tbFecha";
            this.tbFecha.Size = new System.Drawing.Size(100, 20);
            this.tbFecha.TabIndex = 18;
            this.tbFecha.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFecha.Click += new System.EventHandler(this.tbFecha_Click);
            // 
            // mcCalendar
            // 
            this.mcCalendar.Location = new System.Drawing.Point(90, 106);
            this.mcCalendar.Name = "mcCalendar";
            this.mcCalendar.TabIndex = 17;
            this.mcCalendar.Visible = false;
            this.mcCalendar.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcCalendar_DateSelected);
            this.mcCalendar.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcCalendar_KeyUp);
            // 
            // btnProcesar
            // 
            this.btnProcesar.Location = new System.Drawing.Point(327, 286);
            this.btnProcesar.Name = "btnProcesar";
            this.btnProcesar.Size = new System.Drawing.Size(75, 23);
            this.btnProcesar.TabIndex = 16;
            this.btnProcesar.Text = "Procesar";
            this.btnProcesar.UseVisualStyleBackColor = true;
            this.btnProcesar.Click += new System.EventHandler(this.btnProcesar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(11, 287);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 15;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // gbFecha
            // 
            this.gbFecha.Location = new System.Drawing.Point(115, 131);
            this.gbFecha.Name = "gbFecha";
            this.gbFecha.Size = new System.Drawing.Size(180, 65);
            this.gbFecha.TabIndex = 19;
            this.gbFecha.TabStop = false;
            this.gbFecha.Text = "Fecha de Proceso";
            // 
            // PolizaP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSlateGray;
            this.ClientSize = new System.Drawing.Size(412, 338);
            this.Controls.Add(this.mcCalendar);
            this.Controls.Add(this.btnProcesar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.tbFecha);
            this.Controls.Add(this.gbFecha);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PolizaP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Poliza";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PolizaP_FormClosing);
            this.Load += new System.EventHandler(this.PolizaP_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbFecha;
        private System.Windows.Forms.MonthCalendar mcCalendar;
        private System.Windows.Forms.Button btnProcesar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.GroupBox gbFecha;
    }
}