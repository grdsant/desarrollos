﻿namespace MmsWin.Front.Procesos
{
    partial class EnvioCorreoDev
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mcCalendar = new System.Windows.Forms.MonthCalendar();
            this.tbFechaBon = new System.Windows.Forms.TextBox();
            this.btnProcesar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.rtbMensaje = new System.Windows.Forms.RichTextBox();
            this.lbAsunto = new System.Windows.Forms.Label();
            this.tbAsunto = new System.Windows.Forms.TextBox();
            this.tbFchEfec = new System.Windows.Forms.TextBox();
            this.mcCal01 = new System.Windows.Forms.MonthCalendar();
            this.lbFechaBon = new System.Windows.Forms.Label();
            this.lbFechaEfectiva = new System.Windows.Forms.Label();
            this.btPara = new System.Windows.Forms.Button();
            this.btDe = new System.Windows.Forms.Button();
            this.lbDe = new System.Windows.Forms.Label();
            this.lbPara = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // mcCalendar
            // 
            this.mcCalendar.Location = new System.Drawing.Point(303, 54);
            this.mcCalendar.Name = "mcCalendar";
            this.mcCalendar.TabIndex = 3;
            this.mcCalendar.Visible = false;
            this.mcCalendar.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcCalendar_DateSelected);
            this.mcCalendar.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcCalendar_KeyUp);
            // 
            // tbFechaBon
            // 
            this.tbFechaBon.Location = new System.Drawing.Point(156, 19);
            this.tbFechaBon.Name = "tbFechaBon";
            this.tbFechaBon.Size = new System.Drawing.Size(91, 20);
            this.tbFechaBon.TabIndex = 4;
            this.tbFechaBon.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFechaBon.Click += new System.EventHandler(this.tbFechaBon_Click);
            // 
            // btnProcesar
            // 
            this.btnProcesar.Location = new System.Drawing.Point(748, 435);
            this.btnProcesar.Name = "btnProcesar";
            this.btnProcesar.Size = new System.Drawing.Size(75, 23);
            this.btnProcesar.TabIndex = 7;
            this.btnProcesar.Text = "Enviar";
            this.btnProcesar.UseVisualStyleBackColor = true;
            this.btnProcesar.Click += new System.EventHandler(this.btnProcesar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(113, 435);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 6;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // rtbMensaje
            // 
            this.rtbMensaje.Location = new System.Drawing.Point(33, 186);
            this.rtbMensaje.Name = "rtbMensaje";
            this.rtbMensaje.Size = new System.Drawing.Size(898, 243);
            this.rtbMensaje.TabIndex = 8;
            this.rtbMensaje.Text = "";
            // 
            // lbAsunto
            // 
            this.lbAsunto.AutoSize = true;
            this.lbAsunto.Location = new System.Drawing.Point(52, 137);
            this.lbAsunto.Name = "lbAsunto";
            this.lbAsunto.Size = new System.Drawing.Size(40, 13);
            this.lbAsunto.TabIndex = 12;
            this.lbAsunto.Text = "Asunto";
            // 
            // tbAsunto
            // 
            this.tbAsunto.Enabled = false;
            this.tbAsunto.Location = new System.Drawing.Point(113, 134);
            this.tbAsunto.Name = "tbAsunto";
            this.tbAsunto.Size = new System.Drawing.Size(818, 20);
            this.tbAsunto.TabIndex = 13;
            // 
            // tbFchEfec
            // 
            this.tbFchEfec.Location = new System.Drawing.Point(365, 20);
            this.tbFchEfec.Name = "tbFchEfec";
            this.tbFchEfec.Size = new System.Drawing.Size(91, 20);
            this.tbFchEfec.TabIndex = 15;
            this.tbFchEfec.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFchEfec.Click += new System.EventHandler(this.tbFchEfec_Click);
            // 
            // mcCal01
            // 
            this.mcCal01.Location = new System.Drawing.Point(69, 54);
            this.mcCal01.Name = "mcCal01";
            this.mcCal01.TabIndex = 16;
            this.mcCal01.Visible = false;
            this.mcCal01.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcCal01_DateSelected);
            this.mcCal01.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mCal01_KeyUp);
            // 
            // lbFechaBon
            // 
            this.lbFechaBon.AutoSize = true;
            this.lbFechaBon.Location = new System.Drawing.Point(39, 23);
            this.lbFechaBon.Name = "lbFechaBon";
            this.lbFechaBon.Size = new System.Drawing.Size(109, 13);
            this.lbFechaBon.TabIndex = 17;
            this.lbFechaBon.Text = "Fecha de Devolucion";
            // 
            // lbFechaEfectiva
            // 
            this.lbFechaEfectiva.AutoSize = true;
            this.lbFechaEfectiva.Location = new System.Drawing.Point(264, 23);
            this.lbFechaEfectiva.Name = "lbFechaEfectiva";
            this.lbFechaEfectiva.Size = new System.Drawing.Size(78, 13);
            this.lbFechaEfectiva.TabIndex = 18;
            this.lbFechaEfectiva.Text = "Fecha efectiva";
            // 
            // btPara
            // 
            this.btPara.Location = new System.Drawing.Point(33, 89);
            this.btPara.Name = "btPara";
            this.btPara.Size = new System.Drawing.Size(74, 34);
            this.btPara.TabIndex = 19;
            this.btPara.Text = "Para...";
            this.btPara.UseVisualStyleBackColor = true;
            this.btPara.Click += new System.EventHandler(this.btPara_Click);
            // 
            // btDe
            // 
            this.btDe.Location = new System.Drawing.Point(33, 54);
            this.btDe.Name = "btDe";
            this.btDe.Size = new System.Drawing.Size(74, 34);
            this.btDe.TabIndex = 20;
            this.btDe.Text = "De";
            this.btDe.UseVisualStyleBackColor = true;
            // 
            // lbDe
            // 
            this.lbDe.AutoSize = true;
            this.lbDe.Location = new System.Drawing.Point(113, 65);
            this.lbDe.Name = "lbDe";
            this.lbDe.Size = new System.Drawing.Size(53, 13);
            this.lbDe.TabIndex = 21;
            this.lbDe.Text = "Correo de";
            // 
            // lbPara
            // 
            this.lbPara.AutoSize = true;
            this.lbPara.Location = new System.Drawing.Point(113, 100);
            this.lbPara.Name = "lbPara";
            this.lbPara.Size = new System.Drawing.Size(116, 13);
            this.lbPara.TabIndex = 22;
            this.lbPara.Text = "Predefinidos por Marca";
            // 
            // EnvioCorreoDev
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSlateGray;
            this.ClientSize = new System.Drawing.Size(943, 470);
            this.Controls.Add(this.lbFechaEfectiva);
            this.Controls.Add(this.lbFechaBon);
            this.Controls.Add(this.mcCal01);
            this.Controls.Add(this.tbFchEfec);
            this.Controls.Add(this.lbAsunto);
            this.Controls.Add(this.btnProcesar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.mcCalendar);
            this.Controls.Add(this.tbFechaBon);
            this.Controls.Add(this.rtbMensaje);
            this.Controls.Add(this.tbAsunto);
            this.Controls.Add(this.btDe);
            this.Controls.Add(this.btPara);
            this.Controls.Add(this.lbDe);
            this.Controls.Add(this.lbPara);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "EnvioCorreoDev";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Envio de Correo Devoluciones";
            this.Load += new System.EventHandler(this.ProcessAll_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MonthCalendar mcCalendar;
        private System.Windows.Forms.TextBox tbFechaBon;
        private System.Windows.Forms.Button btnProcesar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.RichTextBox rtbMensaje;
        private System.Windows.Forms.Label lbAsunto;
        private System.Windows.Forms.TextBox tbAsunto;
        private System.Windows.Forms.TextBox tbFchEfec;
        private System.Windows.Forms.MonthCalendar mcCal01;
        private System.Windows.Forms.Label lbFechaBon;
        private System.Windows.Forms.Label lbFechaEfectiva;
        private System.Windows.Forms.Button btPara;
        private System.Windows.Forms.Button btDe;
        private System.Windows.Forms.Label lbDe;
        private System.Windows.Forms.Label lbPara;
    }
}