﻿namespace MmsWin.Front.Procesos
{
    partial class CostosDiferenciados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mcCalFchEfectiva = new System.Windows.Forms.MonthCalendar();
            this.lbDescripcion = new System.Windows.Forms.Label();
            this.mcFchProceso = new System.Windows.Forms.MonthCalendar();
            this.gbFechaEfectiva = new System.Windows.Forms.GroupBox();
            this.tbFechaEfectiva = new System.Windows.Forms.TextBox();
            this.btnProcesar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.gbFechaProceso = new System.Windows.Forms.GroupBox();
            this.tbFechaCalificacion = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.gbFechaEfectiva.SuspendLayout();
            this.gbFechaProceso.SuspendLayout();
            this.SuspendLayout();
            // 
            // mcCalFchEfectiva
            // 
            this.mcCalFchEfectiva.Location = new System.Drawing.Point(97, 29);
            this.mcCalFchEfectiva.Name = "mcCalFchEfectiva";
            this.mcCalFchEfectiva.TabIndex = 20;
            this.mcCalFchEfectiva.Visible = false;
            this.mcCalFchEfectiva.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcCalFchEfectiva_DateSelected);
            this.mcCalFchEfectiva.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcCalFchEfectiva_KeyUp);
            // 
            // lbDescripcion
            // 
            this.lbDescripcion.AutoSize = true;
            this.lbDescripcion.Location = new System.Drawing.Point(11, 200);
            this.lbDescripcion.Name = "lbDescripcion";
            this.lbDescripcion.Size = new System.Drawing.Size(63, 13);
            this.lbDescripcion.TabIndex = 26;
            this.lbDescripcion.Text = "Descripcion";
            // 
            // mcFchProceso
            // 
            this.mcFchProceso.Location = new System.Drawing.Point(86, 76);
            this.mcFchProceso.Name = "mcFchProceso";
            this.mcFchProceso.TabIndex = 21;
            this.mcFchProceso.Visible = false;
            this.mcFchProceso.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcFchProceso_DateSelected);
            this.mcFchProceso.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcFchProceso_KeyUp);
            // 
            // gbFechaEfectiva
            // 
            this.gbFechaEfectiva.Controls.Add(this.tbFechaEfectiva);
            this.gbFechaEfectiva.Location = new System.Drawing.Point(115, 114);
            this.gbFechaEfectiva.Name = "gbFechaEfectiva";
            this.gbFechaEfectiva.Size = new System.Drawing.Size(151, 69);
            this.gbFechaEfectiva.TabIndex = 24;
            this.gbFechaEfectiva.TabStop = false;
            this.gbFechaEfectiva.Text = "Fecha Efectiva";
            // 
            // tbFechaEfectiva
            // 
            this.tbFechaEfectiva.Location = new System.Drawing.Point(28, 31);
            this.tbFechaEfectiva.Name = "tbFechaEfectiva";
            this.tbFechaEfectiva.Size = new System.Drawing.Size(100, 20);
            this.tbFechaEfectiva.TabIndex = 15;
            this.tbFechaEfectiva.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFechaEfectiva.Click += new System.EventHandler(this.tbFechaEfectiva_Click);
            // 
            // btnProcesar
            // 
            this.btnProcesar.Location = new System.Drawing.Point(326, 250);
            this.btnProcesar.Name = "btnProcesar";
            this.btnProcesar.Size = new System.Drawing.Size(75, 23);
            this.btnProcesar.TabIndex = 22;
            this.btnProcesar.Text = "Procesar";
            this.btnProcesar.UseVisualStyleBackColor = true;
            this.btnProcesar.Click += new System.EventHandler(this.btnProcesar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(10, 251);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 19;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // gbFechaProceso
            // 
            this.gbFechaProceso.Controls.Add(this.tbFechaCalificacion);
            this.gbFechaProceso.Location = new System.Drawing.Point(114, 29);
            this.gbFechaProceso.Name = "gbFechaProceso";
            this.gbFechaProceso.Size = new System.Drawing.Size(152, 68);
            this.gbFechaProceso.TabIndex = 23;
            this.gbFechaProceso.TabStop = false;
            this.gbFechaProceso.Text = "Fecha de Calificacion";
            // 
            // tbFechaCalificacion
            // 
            this.tbFechaCalificacion.Location = new System.Drawing.Point(29, 29);
            this.tbFechaCalificacion.Name = "tbFechaCalificacion";
            this.tbFechaCalificacion.Size = new System.Drawing.Size(100, 20);
            this.tbFechaCalificacion.TabIndex = 1;
            this.tbFechaCalificacion.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFechaCalificacion.Click += new System.EventHandler(this.tbFechaCalificacion_Click);
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.Location = new System.Drawing.Point(10, 214);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(391, 20);
            this.tbDescripcion.TabIndex = 25;
            // 
            // CostosDiferenciados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSlateGray;
            this.ClientSize = new System.Drawing.Size(410, 303);
            this.Controls.Add(this.mcCalFchEfectiva);
            this.Controls.Add(this.lbDescripcion);
            this.Controls.Add(this.mcFchProceso);
            this.Controls.Add(this.gbFechaEfectiva);
            this.Controls.Add(this.btnProcesar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.gbFechaProceso);
            this.Controls.Add(this.tbDescripcion);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CostosDiferenciados";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Costos Diferenciados";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CostosDiferenciados_FormClosing);
            this.Load += new System.EventHandler(this.CostosDiferenciados_Load);
            this.gbFechaEfectiva.ResumeLayout(false);
            this.gbFechaEfectiva.PerformLayout();
            this.gbFechaProceso.ResumeLayout(false);
            this.gbFechaProceso.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MonthCalendar mcCalFchEfectiva;
        private System.Windows.Forms.Label lbDescripcion;
        private System.Windows.Forms.MonthCalendar mcFchProceso;
        private System.Windows.Forms.GroupBox gbFechaEfectiva;
        private System.Windows.Forms.TextBox tbFechaEfectiva;
        private System.Windows.Forms.Button btnProcesar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.GroupBox gbFechaProceso;
        private System.Windows.Forms.TextBox tbFechaCalificacion;
        private System.Windows.Forms.TextBox tbDescripcion;
    }
}