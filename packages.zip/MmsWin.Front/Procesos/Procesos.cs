﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Procesos
{
    public partial class Procesos : Form
    {

        string ParUser;
        public Procesos()
        {
            InitializeComponent();
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct Margins
        {
            public int derecha;
            public int izquierda;
            public int superior;
            public int inferior;
        }

        [DllImport("dwmapi.dll")]
        public static extern int DwmExtendFrameIntoClientArea(IntPtr hWnd, ref Margins margs);

        private void Procesos_Load(object sender, EventArgs e)
        {
            BackColor = System.Drawing.Color.Black;
            Margins margenes = new Margins();
            margenes.derecha = -1;
            margenes.izquierda = -1;
            margenes.superior = -1;
            margenes.inferior = -1;
            IntPtr hwnd = this.Handle;
            int result = DwmExtendFrameIntoClientArea(hwnd, ref margenes);

            // Seguridad...
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("Procesos", "Procesos", ParUser);
        }

        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }

        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
        }

        private void pbCalifica_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "ConvenioC").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del proceso del Convenio esta abierta");
                    }
                    else
                    {
                        ConvenioC i = new ConvenioC();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbDevoluciones_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "DevolucionesP").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del proceso de Devoluciones esta abierta");
                    }
                    else
                    {
                        DevolucionesP i = new DevolucionesP();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbRebajas_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "RebajasP").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del proceso de Rebajas esta abierta");
                    }
                    else
                    {
                        RebajasP i = new RebajasP();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbEtiquetas_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Etiquetas").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del proceso de Concentraciones esta abierta");
                    }
                    else
                    {
                        Etiquetas i = new Etiquetas();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void Procesos_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("Procesos", "Procesos", ParUser);
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "CostosP").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del proceso de Rebajas esta abierta");
                    }
                    else
                    {
                        CostosP i = new CostosP();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbEnvioCorreo_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "EnvioCorreo").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del proceso de Envio de Correo esta abierta");
                    }
                    else
                    {
                        EnvioCorreo i = new EnvioCorreo();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void btCopiaFoto_Click(object sender, EventArgs e)
        {
            DataTable dtFotos = null;

            dtFotos = MmsWin.Negocio.Procesos.Obtenfotos1.GetInstance().ObtenFotos();

            foreach (DataRow row in dtFotos.Rows)
            {
                string charPrv = row["FINNUM"].ToString();
                charPrv = charPrv.PadLeft(6, '0');
                string numSty = row["FINYLQ"].ToString();

                string ext = ".jpg";
                //string path = @"\\192.168.2.79\www\showroom\images3\";
                string path = @"\\192.168.2.79\www\showroom\images3\thumbs\";
                string foto = path + "F" + charPrv + numSty + "s" + ext + " ";

                string comando = "copy " + foto + @"C:\Fotos_small";

                //ExecuteCommand(comando); //desbloquear para que funcione
             }
        }

        static void ExecuteCommand(string _Command)
        {
            //Indicamos que deseamos inicializar el proceso cmd.exe junto a un comando de arranque. 
            //(/C, le indicamos al proceso cmd que deseamos que cuando termine la tarea asignada se cierre el proceso).
            //Para mas informacion consulte la ayuda de la consola con cmd.exe /? 
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;  // Para no mostrar la pantalla negra  de DOS
            //Inicializa el proceso
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            //string result = proc.StandardOutput.ReadToEnd();
            //Muestra en pantalla la salida del Comando
            //Console.WriteLine(result);
        }

        private void pbEnvioCorreoDev_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "EnvioCorreo").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del proceso de Envio de Correo de devoluciones ya esta abierta");
                    }
                    else
                    {
                        EnvioCorreoDev i = new EnvioCorreoDev();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbEnvioCorreoDev_MouseLeave(object sender, EventArgs e)
        {
            pbEnvioCorreoDev.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void pbEnvioCorreoDev_MouseMove(object sender, MouseEventArgs e)
        {
            pbEnvioCorreoDev.SizeMode = PictureBoxSizeMode.Zoom;
        }

        private void pbBonXomision_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "BonificacionesP").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del proceso del Bonificaciones esta abierta");
                    }
                    else
                    {
                        BonificacionesP i = new BonificacionesP();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbCostosDif_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "CostosDiferenciados").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del proceso de Rebajas esta abierta");
                    }
                    else
                    {
                        CostosDiferenciados i = new CostosDiferenciados();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbPreciosDif_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "PreciosDiferenciados").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del proceso de Rebajas esta abierta");
                    }
                    else
                    {
                        PrecioDiferenciado i = new PrecioDiferenciado();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbEtiquetasDif_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "EtiquetasDiferenciadas").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del proceso de Etiquetas esta abierta");
                    }
                    else
                    {
                        EtiquetasDiferenciadas i = new EtiquetasDiferenciadas();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbCorreosDif_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "EnvioCorreoDiferenciado").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del proceso de Envio de Correo esta abierta");
                    }
                    else
                    {
                        EnvioCorreoDiferenciado i = new EnvioCorreoDiferenciado();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbCostosMasivos_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "CostosMasivos").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana de Costos Masivos esta abierta");
                    }
                    else
                    {
                        CostosMasivos i = new CostosMasivos();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbPreciosMasivos_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "PreciosMasivos").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana de Precios Masivos esta abierta");
                    }
                    else
                    {
                        PreciosMasivos i = new PreciosMasivos();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

    }
}
