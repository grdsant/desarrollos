﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Net.Mime;
using System.Text;
using System.Windows.Forms;
using MmsWin.Negocio.Procesos;

namespace MmsWin.Front.Procesos
{
    public partial class EtiquetasDiferenciadas : Form
    {

        string ParUser;
        string FechaCal;
        string FechaFmt;

        public EtiquetasDiferenciadas()
        {
            InitializeComponent();
        }

        private void EtiquetasDiferenciadas_Load(object sender, EventArgs e)
        {
            System.Data.DataTable tbFechaInicial = null;
            tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();

            foreach (DataRow row in tbFechaInicial.Rows)
            {
                tbFechaCalificacion.Text = row["DSPFCH"].ToString();
                FechaCal = tbFechaCalificacion.Text;
                FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                tbFechaCalificacion.Text = FechaFmt.ToString();

                tbFechaCalificacion.Focus();
            }

            // Seguridad...
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("Procesos", "EtiquetasDiferenciadas", ParUser);
        }

        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }

        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
        }

        private void btnProcesar_Click(object sender, EventArgs e)
        {
            string fchVal;
            Boolean indFch;
            fchVal = tbFechaCalificacion.Text;
            indFch = MmsWin.Negocio.Utilerias.Utilerias.fecha(fchVal);
            string fchVal2;
            Boolean indFch2;
            fchVal2 = tbFechaCalificacion.Text;
            indFch2 = MmsWin.Negocio.Utilerias.Utilerias.fecha(fchVal2);

            if (indFch == true && indFch2 == true)
            {

                if (tbFechaCalificacion.Text != "")
                {
                    if (tbFechaEfectiva.Text == "")
                    {
                        MessageBox.Show("No debe quedar en blanco la fecha efectiva");
                    }
                    else
                    {
                        if (tbDescripcion.Text == "")
                        {
                            MessageBox.Show("No debe quedar en blanco el campo de Descripcion");
                        }
                        else
                        {
                            string message = "Esta seguro de procesar esta fecha?";
                            string caption = "Confirmación";
                            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                            DialogResult result;
                            result = MessageBox.Show(message, caption, buttons);
                            if (result == System.Windows.Forms.DialogResult.Yes)
                            {
                                string fCal = "";
                                string fFmt = "";
                                fCal = tbFechaCalificacion.Text;
                                fFmt = fCal.Substring(8, 2) + fCal.Substring(3, 2) + fCal.Substring(0, 2);
                                string ParFCal = fFmt;
                                string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;

                                string ParfEfe = "";
                                fFmt = "";
                                fCal = tbFechaEfectiva.Text;
                                fFmt = fCal.Substring(8, 2) + fCal.Substring(3, 2) + fCal.Substring(0, 2);
                                ParfEfe = fFmt;
                                ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                                string ParDescrip = tbDescripcion.Text;

                                this.Cursor = Cursors.WaitCursor;
                               MmsWin.Negocio.Procesos.EtiquetasDiferenciadas.GetInstance().EjecutaEtiquetasDiferenciadas(ParFCal, ParfEfe, ParDescrip, ParUsuario);
                                this.Cursor = Cursors.Default;

                                MessageBox.Show("Proceso Terminado...");
                                this.Close();
                            }
                            else
                            {
                                MessageBox.Show("Proceso Cancelado por el Usuario");
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No debe quedar en blanco la fecha de Calificacion");
                }
            }
            else 
            {
                MessageBox.Show("Fecha erronea, revisar fecha de calificacion y fecha efectiva...");
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void EtiquetasDiferenciadas_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("Procesos", "EtiquetasDiferenciadas", ParUser);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void tbFechaCalificacion_Click(object sender, EventArgs e)
        {
            mcFchCalificacion.Visible = true;
            mcFchCalificacion.Focus(); 
        }

        private void tbFechaEfectiva_Click(object sender, EventArgs e)
        {
            mcCalFechaEfectiva.Visible = true;
            mcCalFechaEfectiva.Focus();
        }

        private void mcFchCalificacion_DateSelected(object sender, DateRangeEventArgs e)
        {
            string fchReprog;
            string NomDiaSem;
            tbFechaCalificacion.Text = mcFchCalificacion.SelectionEnd.ToShortDateString();
            fchReprog = tbFechaCalificacion.Text;
            NomDiaSem = MmsWin.Negocio.Utilerias.Utilerias.NombreDiaSem(fchReprog);
            //if (NomDiaSem == "lunes")
            //{
                tbFechaCalificacion.Text = mcFchCalificacion.SelectionEnd.ToShortDateString();
                mcFchCalificacion.Visible = false;
            //}
            //else
            //{
            //    MessageBox.Show("La fecha no es lunes");
            //    tbFechaCalificacion.Text = "";
            //}  
        }

        private void mcCalFechaEfectiva_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbFechaEfectiva.Text = mcCalFechaEfectiva.SelectionEnd.ToShortDateString();
            DateTime fechaEfectiva = Convert.ToDateTime(tbFechaEfectiva.Text);

            DateTime Hoy = DateTime.Today;
            string fecha_actual = Hoy.ToString("dd-MM-yyyy");

            if (fechaEfectiva < Hoy)
            {
                MessageBox.Show("La fecha no es valida");
                tbFechaEfectiva.Text = "";
            }
            else
            {
                mcCalFechaEfectiva.Visible = false;
            }    
        }

        private void mcFchCalificacion_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcFchCalificacion.Visible = false; 
            }
        }

        private void mcCalFechaEfectiva_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcCalFechaEfectiva.Visible = false;
            }
        }

    }
}
