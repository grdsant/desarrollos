﻿namespace MmsWin.Front.Procesos
{
    partial class Procesos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Procesos));
            this.pbCalifica = new System.Windows.Forms.PictureBox();
            this.pbBonXomision = new System.Windows.Forms.PictureBox();
            this.pbDevoluciones = new System.Windows.Forms.PictureBox();
            this.pbPrecios = new System.Windows.Forms.PictureBox();
            this.lblCalifica = new System.Windows.Forms.Label();
            this.lblRebajas = new System.Windows.Forms.Label();
            this.lblDevoluciones = new System.Windows.Forms.Label();
            this.pbEtiquetas = new System.Windows.Forms.PictureBox();
            this.lblEtiquetas = new System.Windows.Forms.Label();
            this.pbCostos = new System.Windows.Forms.PictureBox();
            this.lblCostos = new System.Windows.Forms.Label();
            this.pbEnvioCorreo = new System.Windows.Forms.PictureBox();
            this.lbEnvioCorreo = new System.Windows.Forms.Label();
            this.btCopiaFoto = new System.Windows.Forms.Button();
            this.pbEnvioCorreoDev = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pbCorreosDif = new System.Windows.Forms.PictureBox();
            this.pbCostosDif = new System.Windows.Forms.PictureBox();
            this.pbEtiquetasDif = new System.Windows.Forms.PictureBox();
            this.pbPreciosDif = new System.Windows.Forms.PictureBox();
            this.lbCostoDif = new System.Windows.Forms.Label();
            this.lbPrecioDif = new System.Windows.Forms.Label();
            this.lbEtiquetaDif = new System.Windows.Forms.Label();
            this.lbCorreoDif = new System.Windows.Forms.Label();
            this.gbRebajasGlobales = new System.Windows.Forms.GroupBox();
            this.gbDevoluciones = new System.Windows.Forms.GroupBox();
            this.gbCalificaciones = new System.Windows.Forms.GroupBox();
            this.gbRebajasDiferenciadas = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbCostosMasivos = new System.Windows.Forms.Label();
            this.pbCostosMasivos = new System.Windows.Forms.PictureBox();
            this.lbPreciosMasivos = new System.Windows.Forms.Label();
            this.pbPreciosMasivos = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbCalifica)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBonXomision)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDevoluciones)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPrecios)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEtiquetas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCostos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnvioCorreo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnvioCorreoDev)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCorreosDif)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCostosDif)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEtiquetasDif)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPreciosDif)).BeginInit();
            this.gbRebajasDiferenciadas.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCostosMasivos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPreciosMasivos)).BeginInit();
            this.SuspendLayout();
            // 
            // pbCalifica
            // 
            this.pbCalifica.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbCalifica.Image = ((System.Drawing.Image)(resources.GetObject("pbCalifica.Image")));
            this.pbCalifica.Location = new System.Drawing.Point(35, 37);
            this.pbCalifica.Name = "pbCalifica";
            this.pbCalifica.Size = new System.Drawing.Size(165, 107);
            this.pbCalifica.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCalifica.TabIndex = 0;
            this.pbCalifica.TabStop = false;
            this.pbCalifica.Click += new System.EventHandler(this.pbCalifica_Click);
            // 
            // pbBonXomision
            // 
            this.pbBonXomision.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbBonXomision.Image = ((System.Drawing.Image)(resources.GetObject("pbBonXomision.Image")));
            this.pbBonXomision.Location = new System.Drawing.Point(230, 37);
            this.pbBonXomision.Name = "pbBonXomision";
            this.pbBonXomision.Size = new System.Drawing.Size(165, 107);
            this.pbBonXomision.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbBonXomision.TabIndex = 1;
            this.pbBonXomision.TabStop = false;
            this.pbBonXomision.Click += new System.EventHandler(this.pbBonXomision_Click);
            // 
            // pbDevoluciones
            // 
            this.pbDevoluciones.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbDevoluciones.Image = ((System.Drawing.Image)(resources.GetObject("pbDevoluciones.Image")));
            this.pbDevoluciones.Location = new System.Drawing.Point(462, 352);
            this.pbDevoluciones.Name = "pbDevoluciones";
            this.pbDevoluciones.Size = new System.Drawing.Size(165, 107);
            this.pbDevoluciones.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbDevoluciones.TabIndex = 3;
            this.pbDevoluciones.TabStop = false;
            this.pbDevoluciones.Click += new System.EventHandler(this.pbDevoluciones_Click);
            // 
            // pbPrecios
            // 
            this.pbPrecios.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbPrecios.Image = ((System.Drawing.Image)(resources.GetObject("pbPrecios.Image")));
            this.pbPrecios.Location = new System.Drawing.Point(659, 37);
            this.pbPrecios.Name = "pbPrecios";
            this.pbPrecios.Size = new System.Drawing.Size(165, 107);
            this.pbPrecios.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPrecios.TabIndex = 4;
            this.pbPrecios.TabStop = false;
            this.pbPrecios.Click += new System.EventHandler(this.pbRebajas_Click);
            // 
            // lblCalifica
            // 
            this.lblCalifica.AutoSize = true;
            this.lblCalifica.BackColor = System.Drawing.Color.Transparent;
            this.lblCalifica.ForeColor = System.Drawing.Color.White;
            this.lblCalifica.Location = new System.Drawing.Point(93, 147);
            this.lblCalifica.Name = "lblCalifica";
            this.lblCalifica.Size = new System.Drawing.Size(41, 13);
            this.lblCalifica.TabIndex = 8;
            this.lblCalifica.Text = "Califica";
            // 
            // lblRebajas
            // 
            this.lblRebajas.AutoSize = true;
            this.lblRebajas.BackColor = System.Drawing.Color.Transparent;
            this.lblRebajas.ForeColor = System.Drawing.Color.White;
            this.lblRebajas.Location = new System.Drawing.Point(723, 152);
            this.lblRebajas.Name = "lblRebajas";
            this.lblRebajas.Size = new System.Drawing.Size(42, 13);
            this.lblRebajas.TabIndex = 10;
            this.lblRebajas.Text = "Precios";
            // 
            // lblDevoluciones
            // 
            this.lblDevoluciones.AutoSize = true;
            this.lblDevoluciones.BackColor = System.Drawing.Color.Transparent;
            this.lblDevoluciones.ForeColor = System.Drawing.Color.White;
            this.lblDevoluciones.Location = new System.Drawing.Point(502, 462);
            this.lblDevoluciones.Name = "lblDevoluciones";
            this.lblDevoluciones.Size = new System.Drawing.Size(72, 13);
            this.lblDevoluciones.TabIndex = 12;
            this.lblDevoluciones.Text = "Devoluciones";
            // 
            // pbEtiquetas
            // 
            this.pbEtiquetas.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbEtiquetas.Image = ((System.Drawing.Image)(resources.GetObject("pbEtiquetas.Image")));
            this.pbEtiquetas.Location = new System.Drawing.Point(464, 184);
            this.pbEtiquetas.Name = "pbEtiquetas";
            this.pbEtiquetas.Size = new System.Drawing.Size(165, 107);
            this.pbEtiquetas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEtiquetas.TabIndex = 14;
            this.pbEtiquetas.TabStop = false;
            this.pbEtiquetas.Click += new System.EventHandler(this.pbEtiquetas_Click);
            // 
            // lblEtiquetas
            // 
            this.lblEtiquetas.AutoSize = true;
            this.lblEtiquetas.BackColor = System.Drawing.Color.Transparent;
            this.lblEtiquetas.ForeColor = System.Drawing.Color.White;
            this.lblEtiquetas.Location = new System.Drawing.Point(468, 294);
            this.lblEtiquetas.Name = "lblEtiquetas";
            this.lblEtiquetas.Size = new System.Drawing.Size(161, 13);
            this.lblEtiquetas.TabIndex = 15;
            this.lblEtiquetas.Text = "Identificador de estilos(etiquetas)";
            // 
            // pbCostos
            // 
            this.pbCostos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbCostos.Image = ((System.Drawing.Image)(resources.GetObject("pbCostos.Image")));
            this.pbCostos.Location = new System.Drawing.Point(462, 37);
            this.pbCostos.Name = "pbCostos";
            this.pbCostos.Size = new System.Drawing.Size(165, 107);
            this.pbCostos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCostos.TabIndex = 16;
            this.pbCostos.TabStop = false;
            this.pbCostos.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lblCostos
            // 
            this.lblCostos.AutoSize = true;
            this.lblCostos.BackColor = System.Drawing.Color.Transparent;
            this.lblCostos.ForeColor = System.Drawing.Color.White;
            this.lblCostos.Location = new System.Drawing.Point(524, 152);
            this.lblCostos.Name = "lblCostos";
            this.lblCostos.Size = new System.Drawing.Size(39, 13);
            this.lblCostos.TabIndex = 17;
            this.lblCostos.Text = "Costos";
            // 
            // pbEnvioCorreo
            // 
            this.pbEnvioCorreo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbEnvioCorreo.Image = ((System.Drawing.Image)(resources.GetObject("pbEnvioCorreo.Image")));
            this.pbEnvioCorreo.Location = new System.Drawing.Point(659, 184);
            this.pbEnvioCorreo.Name = "pbEnvioCorreo";
            this.pbEnvioCorreo.Size = new System.Drawing.Size(165, 107);
            this.pbEnvioCorreo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEnvioCorreo.TabIndex = 19;
            this.pbEnvioCorreo.TabStop = false;
            this.pbEnvioCorreo.Click += new System.EventHandler(this.pbEnvioCorreo_Click);
            // 
            // lbEnvioCorreo
            // 
            this.lbEnvioCorreo.AutoSize = true;
            this.lbEnvioCorreo.BackColor = System.Drawing.Color.Transparent;
            this.lbEnvioCorreo.ForeColor = System.Drawing.Color.White;
            this.lbEnvioCorreo.Location = new System.Drawing.Point(707, 294);
            this.lbEnvioCorreo.Name = "lbEnvioCorreo";
            this.lbEnvioCorreo.Size = new System.Drawing.Size(83, 13);
            this.lbEnvioCorreo.TabIndex = 20;
            this.lbEnvioCorreo.Text = "Envio de Correo";
            // 
            // btCopiaFoto
            // 
            this.btCopiaFoto.Enabled = false;
            this.btCopiaFoto.Location = new System.Drawing.Point(163, 266);
            this.btCopiaFoto.Name = "btCopiaFoto";
            this.btCopiaFoto.Size = new System.Drawing.Size(88, 26);
            this.btCopiaFoto.TabIndex = 23;
            this.btCopiaFoto.Text = "Copia Fotos";
            this.btCopiaFoto.UseVisualStyleBackColor = true;
            this.btCopiaFoto.Visible = false;
            this.btCopiaFoto.Click += new System.EventHandler(this.btCopiaFoto_Click);
            // 
            // pbEnvioCorreoDev
            // 
            this.pbEnvioCorreoDev.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbEnvioCorreoDev.Image = ((System.Drawing.Image)(resources.GetObject("pbEnvioCorreoDev.Image")));
            this.pbEnvioCorreoDev.Location = new System.Drawing.Point(657, 352);
            this.pbEnvioCorreoDev.Name = "pbEnvioCorreoDev";
            this.pbEnvioCorreoDev.Size = new System.Drawing.Size(165, 107);
            this.pbEnvioCorreoDev.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbEnvioCorreoDev.TabIndex = 25;
            this.pbEnvioCorreoDev.TabStop = false;
            this.pbEnvioCorreoDev.Click += new System.EventHandler(this.pbEnvioCorreoDev_Click);
            this.pbEnvioCorreoDev.MouseLeave += new System.EventHandler(this.pbEnvioCorreoDev_MouseLeave);
            this.pbEnvioCorreoDev.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbEnvioCorreoDev_MouseMove);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(665, 462);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 13);
            this.label1.TabIndex = 26;
            this.label1.Text = "Envio de Correo Devoluciones";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(258, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 13);
            this.label2.TabIndex = 31;
            this.label2.Text = "Calificacion por Omision";
            // 
            // pbCorreosDif
            // 
            this.pbCorreosDif.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbCorreosDif.Image = ((System.Drawing.Image)(resources.GetObject("pbCorreosDif.Image")));
            this.pbCorreosDif.Location = new System.Drawing.Point(232, 347);
            this.pbCorreosDif.Name = "pbCorreosDif";
            this.pbCorreosDif.Size = new System.Drawing.Size(165, 107);
            this.pbCorreosDif.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCorreosDif.TabIndex = 35;
            this.pbCorreosDif.TabStop = false;
            this.pbCorreosDif.Click += new System.EventHandler(this.pbCorreosDif_Click);
            // 
            // pbCostosDif
            // 
            this.pbCostosDif.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbCostosDif.Image = ((System.Drawing.Image)(resources.GetObject("pbCostosDif.Image")));
            this.pbCostosDif.Location = new System.Drawing.Point(35, 200);
            this.pbCostosDif.Name = "pbCostosDif";
            this.pbCostosDif.Size = new System.Drawing.Size(165, 107);
            this.pbCostosDif.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCostosDif.TabIndex = 34;
            this.pbCostosDif.TabStop = false;
            this.pbCostosDif.Click += new System.EventHandler(this.pbCostosDif_Click);
            // 
            // pbEtiquetasDif
            // 
            this.pbEtiquetasDif.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbEtiquetasDif.Image = ((System.Drawing.Image)(resources.GetObject("pbEtiquetasDif.Image")));
            this.pbEtiquetasDif.Location = new System.Drawing.Point(37, 347);
            this.pbEtiquetasDif.Name = "pbEtiquetasDif";
            this.pbEtiquetasDif.Size = new System.Drawing.Size(165, 107);
            this.pbEtiquetasDif.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbEtiquetasDif.TabIndex = 33;
            this.pbEtiquetasDif.TabStop = false;
            this.pbEtiquetasDif.Click += new System.EventHandler(this.pbEtiquetasDif_Click);
            // 
            // pbPreciosDif
            // 
            this.pbPreciosDif.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbPreciosDif.Image = ((System.Drawing.Image)(resources.GetObject("pbPreciosDif.Image")));
            this.pbPreciosDif.Location = new System.Drawing.Point(232, 200);
            this.pbPreciosDif.Name = "pbPreciosDif";
            this.pbPreciosDif.Size = new System.Drawing.Size(165, 107);
            this.pbPreciosDif.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPreciosDif.TabIndex = 32;
            this.pbPreciosDif.TabStop = false;
            this.pbPreciosDif.Click += new System.EventHandler(this.pbPreciosDif_Click);
            // 
            // lbCostoDif
            // 
            this.lbCostoDif.AutoSize = true;
            this.lbCostoDif.BackColor = System.Drawing.Color.Transparent;
            this.lbCostoDif.ForeColor = System.Drawing.Color.White;
            this.lbCostoDif.Location = new System.Drawing.Point(93, 310);
            this.lbCostoDif.Name = "lbCostoDif";
            this.lbCostoDif.Size = new System.Drawing.Size(39, 13);
            this.lbCostoDif.TabIndex = 36;
            this.lbCostoDif.Text = "Costos";
            // 
            // lbPrecioDif
            // 
            this.lbPrecioDif.AutoSize = true;
            this.lbPrecioDif.BackColor = System.Drawing.Color.Transparent;
            this.lbPrecioDif.ForeColor = System.Drawing.Color.White;
            this.lbPrecioDif.Location = new System.Drawing.Point(298, 310);
            this.lbPrecioDif.Name = "lbPrecioDif";
            this.lbPrecioDif.Size = new System.Drawing.Size(37, 13);
            this.lbPrecioDif.TabIndex = 37;
            this.lbPrecioDif.Text = "Precio";
            // 
            // lbEtiquetaDif
            // 
            this.lbEtiquetaDif.AutoSize = true;
            this.lbEtiquetaDif.BackColor = System.Drawing.Color.Transparent;
            this.lbEtiquetaDif.ForeColor = System.Drawing.Color.White;
            this.lbEtiquetaDif.Location = new System.Drawing.Point(83, 457);
            this.lbEtiquetaDif.Name = "lbEtiquetaDif";
            this.lbEtiquetaDif.Size = new System.Drawing.Size(51, 13);
            this.lbEtiquetaDif.TabIndex = 38;
            this.lbEtiquetaDif.Text = "Etiquetas";
            // 
            // lbCorreoDif
            // 
            this.lbCorreoDif.AutoSize = true;
            this.lbCorreoDif.BackColor = System.Drawing.Color.Transparent;
            this.lbCorreoDif.ForeColor = System.Drawing.Color.White;
            this.lbCorreoDif.Location = new System.Drawing.Point(285, 457);
            this.lbCorreoDif.Name = "lbCorreoDif";
            this.lbCorreoDif.Size = new System.Drawing.Size(38, 13);
            this.lbCorreoDif.TabIndex = 39;
            this.lbCorreoDif.Text = "Correo";
            // 
            // gbRebajasGlobales
            // 
            this.gbRebajasGlobales.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbRebajasGlobales.ForeColor = System.Drawing.Color.Maroon;
            this.gbRebajasGlobales.Location = new System.Drawing.Point(427, 12);
            this.gbRebajasGlobales.Name = "gbRebajasGlobales";
            this.gbRebajasGlobales.Size = new System.Drawing.Size(417, 304);
            this.gbRebajasGlobales.TabIndex = 40;
            this.gbRebajasGlobales.TabStop = false;
            this.gbRebajasGlobales.Text = "Rebajas Globales";
            // 
            // gbDevoluciones
            // 
            this.gbDevoluciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbDevoluciones.ForeColor = System.Drawing.Color.Maroon;
            this.gbDevoluciones.Location = new System.Drawing.Point(427, 324);
            this.gbDevoluciones.Name = "gbDevoluciones";
            this.gbDevoluciones.Size = new System.Drawing.Size(417, 156);
            this.gbDevoluciones.TabIndex = 41;
            this.gbDevoluciones.TabStop = false;
            this.gbDevoluciones.Text = "Devoluciones";
            // 
            // gbCalificaciones
            // 
            this.gbCalificaciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbCalificaciones.ForeColor = System.Drawing.Color.Maroon;
            this.gbCalificaciones.Location = new System.Drawing.Point(16, 12);
            this.gbCalificaciones.Name = "gbCalificaciones";
            this.gbCalificaciones.Size = new System.Drawing.Size(394, 156);
            this.gbCalificaciones.TabIndex = 42;
            this.gbCalificaciones.TabStop = false;
            this.gbCalificaciones.Text = "Calificaciones";
            // 
            // gbRebajasDiferenciadas
            // 
            this.gbRebajasDiferenciadas.Controls.Add(this.btCopiaFoto);
            this.gbRebajasDiferenciadas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbRebajasDiferenciadas.ForeColor = System.Drawing.Color.Maroon;
            this.gbRebajasDiferenciadas.Location = new System.Drawing.Point(16, 174);
            this.gbRebajasDiferenciadas.Name = "gbRebajasDiferenciadas";
            this.gbRebajasDiferenciadas.Size = new System.Drawing.Size(394, 306);
            this.gbRebajasDiferenciadas.TabIndex = 41;
            this.gbRebajasDiferenciadas.TabStop = false;
            this.gbRebajasDiferenciadas.Text = "Rebajas Diferenciadas";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lbCostosMasivos);
            this.groupBox1.Controls.Add(this.pbPreciosMasivos);
            this.groupBox1.Controls.Add(this.pbCostosMasivos);
            this.groupBox1.Controls.Add(this.lbPreciosMasivos);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Maroon;
            this.groupBox1.Location = new System.Drawing.Point(854, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(417, 304);
            this.groupBox1.TabIndex = 41;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Procesos Adicionales";
            // 
            // lbCostosMasivos
            // 
            this.lbCostosMasivos.AutoSize = true;
            this.lbCostosMasivos.BackColor = System.Drawing.Color.Transparent;
            this.lbCostosMasivos.ForeColor = System.Drawing.Color.White;
            this.lbCostosMasivos.Location = new System.Drawing.Point(49, 133);
            this.lbCostosMasivos.Name = "lbCostosMasivos";
            this.lbCostosMasivos.Size = new System.Drawing.Size(144, 16);
            this.lbCostosMasivos.TabIndex = 46;
            this.lbCostosMasivos.Text = "Carga Costos Masivos";
            // 
            // pbCostosMasivos
            // 
            this.pbCostosMasivos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbCostosMasivos.Image = ((System.Drawing.Image)(resources.GetObject("pbCostosMasivos.Image")));
            this.pbCostosMasivos.Location = new System.Drawing.Point(38, 18);
            this.pbCostosMasivos.Name = "pbCostosMasivos";
            this.pbCostosMasivos.Size = new System.Drawing.Size(165, 107);
            this.pbCostosMasivos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCostosMasivos.TabIndex = 45;
            this.pbCostosMasivos.TabStop = false;
            this.pbCostosMasivos.Click += new System.EventHandler(this.pbCostosMasivos_Click);
            // 
            // lbPreciosMasivos
            // 
            this.lbPreciosMasivos.AutoSize = true;
            this.lbPreciosMasivos.BackColor = System.Drawing.Color.Transparent;
            this.lbPreciosMasivos.ForeColor = System.Drawing.Color.White;
            this.lbPreciosMasivos.Location = new System.Drawing.Point(245, 133);
            this.lbPreciosMasivos.Name = "lbPreciosMasivos";
            this.lbPreciosMasivos.Size = new System.Drawing.Size(147, 16);
            this.lbPreciosMasivos.TabIndex = 44;
            this.lbPreciosMasivos.Text = "Carga precios masivos";
            // 
            // pbPreciosMasivos
            // 
            this.pbPreciosMasivos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbPreciosMasivos.Image = ((System.Drawing.Image)(resources.GetObject("pbPreciosMasivos.Image")));
            this.pbPreciosMasivos.Location = new System.Drawing.Point(235, 18);
            this.pbPreciosMasivos.Name = "pbPreciosMasivos";
            this.pbPreciosMasivos.Size = new System.Drawing.Size(165, 107);
            this.pbPreciosMasivos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPreciosMasivos.TabIndex = 43;
            this.pbPreciosMasivos.TabStop = false;
            this.pbPreciosMasivos.Click += new System.EventHandler(this.pbPreciosMasivos_Click);
            // 
            // Procesos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1283, 490);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lbCorreoDif);
            this.Controls.Add(this.lbEtiquetaDif);
            this.Controls.Add(this.lbPrecioDif);
            this.Controls.Add(this.lbCostoDif);
            this.Controls.Add(this.pbCorreosDif);
            this.Controls.Add(this.pbCostosDif);
            this.Controls.Add(this.pbEtiquetasDif);
            this.Controls.Add(this.pbPreciosDif);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbEnvioCorreoDev);
            this.Controls.Add(this.lbEnvioCorreo);
            this.Controls.Add(this.pbEnvioCorreo);
            this.Controls.Add(this.lblCostos);
            this.Controls.Add(this.pbCostos);
            this.Controls.Add(this.lblEtiquetas);
            this.Controls.Add(this.pbEtiquetas);
            this.Controls.Add(this.lblDevoluciones);
            this.Controls.Add(this.lblRebajas);
            this.Controls.Add(this.lblCalifica);
            this.Controls.Add(this.pbPrecios);
            this.Controls.Add(this.pbDevoluciones);
            this.Controls.Add(this.pbBonXomision);
            this.Controls.Add(this.pbCalifica);
            this.Controls.Add(this.gbRebajasGlobales);
            this.Controls.Add(this.gbDevoluciones);
            this.Controls.Add(this.gbCalificaciones);
            this.Controls.Add(this.gbRebajasDiferenciadas);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Procesos";
            this.Opacity = 0.9D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Procesos";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Procesos_FormClosing);
            this.Load += new System.EventHandler(this.Procesos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbCalifica)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBonXomision)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDevoluciones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPrecios)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEtiquetas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCostos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnvioCorreo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEnvioCorreoDev)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCorreosDif)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCostosDif)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbEtiquetasDif)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPreciosDif)).EndInit();
            this.gbRebajasDiferenciadas.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCostosMasivos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPreciosMasivos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbCalifica;
        private System.Windows.Forms.PictureBox pbBonXomision;
        private System.Windows.Forms.PictureBox pbDevoluciones;
        private System.Windows.Forms.PictureBox pbPrecios;
        private System.Windows.Forms.Label lblCalifica;
        private System.Windows.Forms.Label lblRebajas;
        private System.Windows.Forms.Label lblDevoluciones;
        private System.Windows.Forms.PictureBox pbEtiquetas;
        private System.Windows.Forms.Label lblEtiquetas;
        private System.Windows.Forms.PictureBox pbCostos;
        private System.Windows.Forms.Label lblCostos;
        private System.Windows.Forms.PictureBox pbEnvioCorreo;
        private System.Windows.Forms.Label lbEnvioCorreo;
        private System.Windows.Forms.Button btCopiaFoto;
        private System.Windows.Forms.PictureBox pbEnvioCorreoDev;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pbCorreosDif;
        private System.Windows.Forms.PictureBox pbCostosDif;
        private System.Windows.Forms.PictureBox pbEtiquetasDif;
        private System.Windows.Forms.PictureBox pbPreciosDif;
        private System.Windows.Forms.Label lbCostoDif;
        private System.Windows.Forms.Label lbPrecioDif;
        private System.Windows.Forms.Label lbEtiquetaDif;
        private System.Windows.Forms.Label lbCorreoDif;
        private System.Windows.Forms.GroupBox gbRebajasGlobales;
        private System.Windows.Forms.GroupBox gbDevoluciones;
        private System.Windows.Forms.GroupBox gbCalificaciones;
        private System.Windows.Forms.GroupBox gbRebajasDiferenciadas;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbCostosMasivos;
        private System.Windows.Forms.PictureBox pbPreciosMasivos;
        private System.Windows.Forms.PictureBox pbCostosMasivos;
        private System.Windows.Forms.Label lbPreciosMasivos;
    }
}