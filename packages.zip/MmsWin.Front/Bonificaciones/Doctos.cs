﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using MmsWin.Front.Utilerias;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;

namespace MmsWin.Front.Bonificaciones
{
    public partial class Doctos : Form
    {

        int nr;
        string ParUser;
        String marca;
        bool Carga;
        String FchDe;
        String FchHas;
        long FchDeN;
        long FchHasN;
        String comprador;
        string listaComprador;
        string FechaCal;
        string FechaFmt;
        long FechaApli;
        int dgvOffset;
        int pgbOffset;
        int dgvOffset2;

        public static string parProveedor;
        public static string parEstilo;
        public static string ParProveedor;
        public static string PartbNombre;
        public static string PartbEstilo;
        public static string ParDescripcion;

        public Doctos()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvDoctos.Width;
            dgvOffset2 = this.Height - dgvDoctos.Height;
            pgbOffset  = this.Width  - pgbProg.Width;
        }

        private void Doctos_Load(object sender, EventArgs e)
        {
            Carga = false;
            marca = "999";
            comprador = "999";
            tbCal01.Text = "0000000000";
            tbHasta.Text = "0000000000";
            FchDe = "10/10/2000";
            FchHas = "10/10/2000";
            tbCal01.Text = FchDe;
            tbHasta.Text = FchHas;

            // Carga de Marca
            try
            {
                BindMarca();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            // Carga de Compradores
            try
            {
                BindCompradores();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            try
            {
                System.Data.DataTable tbFechaInicial = null;
                tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();

                foreach (DataRow row in tbFechaInicial.Rows)
                {
                    tbCal01.Text = row["DSPFCH"].ToString();

                    FechaCal = tbCal01.Text;
                    FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                    tbCal01.Text = FechaFmt.ToString();

                    tbHasta.Text = row["DSPFCH"].ToString();
                    FechaCal = tbHasta.Text;
                    FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                    tbHasta.Text = FechaFmt.ToString();

                    FechaCal = tbCal01.Text;
                    FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                    FchDeN = long.Parse(FechaFmt.ToString());
                    FchDe = FechaFmt.ToString();

                    FechaCal = tbHasta.Text;
                    FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                    FchHasN = long.Parse(FechaFmt.ToString());
                    FchHas = FechaFmt.ToString();

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


            comprador = MmsWin.Front.Utilerias.VarTem.tmpUSRCOM;
            cbCompradores.SelectedValue = comprador;
            marca = MmsWin.Front.Utilerias.VarTem.tmpUSRMAR;
            cbMarca.SelectedValue = marca;

            // Carga de Datos
            try
            {
                Carga = true;
                BindDoctos();

                // Seguridad...
                ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                Seguridad("Bonificaciones", "Doctos", ParUser);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        // Seguridad                                                                                
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                         
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvDoctos.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvDoctos.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenu.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenu.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        protected void BindDoctos()
        {
            if (Carga == true)
            {
                nr = 0;
                this.Cursor = Cursors.WaitCursor;
                dgvDoctos.DataSource = null;
                System.Data.DataTable Doctos = null;
                try
                {
                    ParProveedor = tbProveedor.Text;
                    PartbNombre = tbNombre.Text;
                    PartbEstilo = tbEstilo.Text;
                    ParDescripcion = tbDescripcion.Text;

                    listaComprador = MmsWin.Front.Utilerias.VarTem.tmpDESC;
                    if (listaComprador != "")
                    {
                        comprador = listaComprador;
                    }
                    Doctos = MmsWin.Negocio.Bonificaciones.Doctos.GetInstance().ObtenDoctos1(marca, comprador, FchDe, FchHas, ParProveedor, PartbNombre, PartbEstilo, ParDescripcion);

                    comprador = MmsWin.Front.Utilerias.VarTem.tmpUSRCOM;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                if (Doctos != null)
                {
                    if (Doctos.Rows.Count > 0)
                    {
                        dgvDoctos.DataSource = Doctos;
                        SetFontAndColors();
                        rowStyle();
                        SetDoubleBuffered(dgvDoctos);

                        nr = dgvDoctos.RowCount;
                        this.Text = "Doctos (Notas de Credito/Adendum/Excepciones) / " + " " + (nr).ToString() + " Registro(s)";

                        // Seguridad...
                        ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        Seguridad("Bonificaciones", "Doctos", ParUser);
                    }
                }
                this.Cursor = Cursors.Default;
            }
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        protected void BindMarca()
        {
            try
            {
                cbMarca.DataSource = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();
                cbMarca.DisplayMember = "Value";
                cbMarca.ValueMember = "Key";
                marca = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void BindCompradores()
        {
            try
            {
                cbCompradores.DataSource = MmsWin.Negocio.Catalogos.Compradores.GetInstance().ObtenCompradors().ToList();
                cbCompradores.DisplayMember = "Value";
                cbCompradores.ValueMember = "Key";
                comprador = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void SetFontAndColors()
        {
            this.dgvDoctos.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvDoctos.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvDoctos.EnableHeadersVisualStyles = false;
            this.dgvDoctos.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvDoctos.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvDoctos.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvDoctos.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvDoctos.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvDoctos.Columns[3].Frozen = true;

            dgvDoctos.Columns[0].HeaderText =  "Fecha Bonificacion";
            dgvDoctos.Columns[1].HeaderText =  "Proveedor";
            dgvDoctos.Columns[2].HeaderText =  "Nombre";
            dgvDoctos.Columns[3].HeaderText =  "Estilo";
            dgvDoctos.Columns[4].HeaderText =  "Descripción";
            dgvDoctos.Columns[5].HeaderText =  "Comprador";
            dgvDoctos.Columns[6].HeaderText =  "Nota de Credito";
            dgvDoctos.Columns[7].HeaderText =  "Sub Total";
            dgvDoctos.Columns[8].HeaderText =  "Iva";
            dgvDoctos.Columns[9].HeaderText =  "Total";
            dgvDoctos.Columns[10].HeaderText = "Costo Actual";
            dgvDoctos.Columns[11].HeaderText = "Precio Actual";
            dgvDoctos.Columns[12].HeaderText = "Margen";
            dgvDoctos.Columns[13].HeaderText = "No. Calificación";
            dgvDoctos.Columns[14].HeaderText = "Fecha Compra";
            dgvDoctos.Columns[15].HeaderText = "Fecha Revision";
            dgvDoctos.Columns[16].HeaderText = "Piezas";
            dgvDoctos.Columns[17].HeaderText = "Venta";
            dgvDoctos.Columns[18].HeaderText = "On Hand";
            dgvDoctos.Columns[19].HeaderText = "% Ventas";
            dgvDoctos.Columns[20].HeaderText = "Calificación";
            dgvDoctos.Columns[21].HeaderText = "Tabla de_Acción";
            dgvDoctos.Columns[22].HeaderText = "Compras Obs";
            dgvDoctos.Columns[23].HeaderText = "Ruta NC_PDF";
            dgvDoctos.Columns[24].HeaderText = "Marca";
            dgvDoctos.Columns[25].HeaderText = "Comprador";
            dgvDoctos.Columns[26].HeaderText = "Bodega";
            dgvDoctos.Columns[27].HeaderText = "Marca";
            dgvDoctos.Columns[28].HeaderText = "Fecha Actualizacion";
            dgvDoctos.Columns[29].HeaderText = "Hora Actualizacion";
            dgvDoctos.Columns[30].HeaderText = "Usuario";

            dgvDoctos.Columns[0].Width = 80;
            dgvDoctos.Columns[1].Width = 50;
            dgvDoctos.Columns[2].Width = 250;
            dgvDoctos.Columns[3].Width = 100;
            dgvDoctos.Columns[4].Width = 250;
            dgvDoctos.Columns[5].Width = 150;
            dgvDoctos.Columns[6].Width = 100;
            dgvDoctos.Columns[7].Width = 85;
            dgvDoctos.Columns[8].Width = 85;
            dgvDoctos.Columns[9].Width = 85;
            dgvDoctos.Columns[10].Width = 60;
            dgvDoctos.Columns[11].Width = 60;
            dgvDoctos.Columns[12].Width = 60;
            dgvDoctos.Columns[13].Width = 80;
            dgvDoctos.Columns[14].Width = 80;
            dgvDoctos.Columns[15].Width = 80;
            dgvDoctos.Columns[16].Width = 80;
            dgvDoctos.Columns[17].Width = 80;
            dgvDoctos.Columns[18].Width = 80;
            dgvDoctos.Columns[19].Width = 80;
            dgvDoctos.Columns[20].Width = 80;
            dgvDoctos.Columns[21].Width = 80;
            dgvDoctos.Columns[22].Width = 80;
            dgvDoctos.Columns[23].Width = 60;
            dgvDoctos.Columns[24].Width = 60;
            dgvDoctos.Columns[25].Width = 60;
            dgvDoctos.Columns[26].Width = 60;
            dgvDoctos.Columns[27].Width = 60;
            dgvDoctos.Columns[28].Width = 80;
            dgvDoctos.Columns[29].Width = 80;
            dgvDoctos.Columns[30].Width = 60;

            dgvDoctos.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDoctos.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvDoctos.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDoctos.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvDoctos.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvDoctos.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvDoctos.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvDoctos.Columns[11].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvDoctos.Columns[12].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDoctos.Columns[13].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDoctos.Columns[14].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvDoctos.Columns[15].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvDoctos.Columns[16].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvDoctos.Columns[17].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvDoctos.Columns[18].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvDoctos.Columns[19].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDoctos.Columns[20].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDoctos.Columns[21].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDoctos.Columns[22].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvDoctos.Columns[23].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDoctos.Columns[24].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDoctos.Columns[25].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDoctos.Columns[26].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDoctos.Columns[27].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDoctos.Columns[28].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDoctos.Columns[29].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDoctos.Columns[30].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvDoctos.Columns[0].DefaultCellStyle.Format = "20##-##-##";

            dgvDoctos.Columns[7].DefaultCellStyle.Format = "###,###.00";
            dgvDoctos.Columns[8].DefaultCellStyle.Format = "###,###.00";
            dgvDoctos.Columns[9].DefaultCellStyle.Format = "###,###.00";
            dgvDoctos.Columns[10].DefaultCellStyle.Format = "00.00";
            dgvDoctos.Columns[11].DefaultCellStyle.Format = "00.00";
            dgvDoctos.Columns[12].DefaultCellStyle.Format = "##.00";
            dgvDoctos.Columns[14].DefaultCellStyle.Format = "20##-##-##";
            dgvDoctos.Columns[15].DefaultCellStyle.Format = "20##-##-##";
            dgvDoctos.Columns[16].DefaultCellStyle.Format = "#,###,###";
            dgvDoctos.Columns[17].DefaultCellStyle.Format = "#,###,###";
            dgvDoctos.Columns[18].DefaultCellStyle.Format = "#,###,###";
            dgvDoctos.Columns[28].DefaultCellStyle.Format = "20##-##-##";
            dgvDoctos.Columns[29].DefaultCellStyle.Format = "##-##-##";

            dgvDoctos.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvDoctos.Columns[1].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvDoctos.Columns[2].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvDoctos.Columns[3].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvDoctos.Columns[4].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvDoctos.Columns[5].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvDoctos.Columns[6].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvDoctos.Columns[7].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvDoctos.Columns[8].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvDoctos.Columns[9].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvDoctos.Columns[10].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvDoctos.Columns[11].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvDoctos.Columns[12].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvDoctos.Columns[13].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvDoctos.Columns[14].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvDoctos.Columns[15].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvDoctos.Columns[16].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            dgvDoctos.Columns[17].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvDoctos.Columns[18].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvDoctos.Columns[19].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvDoctos.Columns[20].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvDoctos.Columns[21].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvDoctos.Columns[22].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvDoctos.Columns[23].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvDoctos.Columns[24].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvDoctos.Columns[25].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvDoctos.Columns[26].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvDoctos.Columns[27].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvDoctos.Columns[28].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvDoctos.Columns[29].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvDoctos.Columns[30].HeaderCell.Style.BackColor = Color.LightSlateGray;

            dgvDoctos.Columns[13].Visible = false;

            foreach (DataGridViewRow row in dgvDoctos.Rows)
            {
                // Pagar
                if (Convert.ToString(row.Cells[20].Value) == " P a g a r") { row.Cells[20].Style.BackColor = Color.LightGreen; }
                // 15%
                if (Convert.ToString(row.Cells[20].Value) == " 15%") { row.Cells[20].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(row.Cells[20].Value) == " 20%") { row.Cells[20].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(row.Cells[20].Value) == " 25%") { row.Cells[20].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(row.Cells[20].Value) == " 30%") { row.Cells[20].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(row.Cells[20].Value) == " 35%") { row.Cells[20].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(row.Cells[20].Value) == " 40%") { row.Cells[20].Style.BackColor = Color.LightSalmon; }
                // Dev ó 40%
                if (Convert.ToString(row.Cells[20].Value) == " 40%") { row.Cells[20].Style.BackColor = Color.Red; row.Cells[20].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(row.Cells[20].Value) == " 50%") { row.Cells[20].Style.BackColor = Color.Red; row.Cells[20].Style.ForeColor = Color.White; }
                //Dev ó 50%
                if (Convert.ToString(row.Cells[20].Value) == " 50%") { row.Cells[20].Style.BackColor = Color.Red; row.Cells[20].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(row.Cells[20].Value) == "Devolucion") { row.Cells[20].Style.BackColor = Color.Red; row.Cells[20].Style.ForeColor = Color.White; }

                if (Convert.ToString(row.Cells[23].Value) != "") { row.Cells[6].Style.ForeColor = Color.Green; }
                if (Convert.ToString(row.Cells[23].Value) == "") { row.Cells[6].Style.ForeColor = Color.Red; }

            }

        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvDoctos.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvDoctos.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }

        private void Doctos_Resize(object sender, EventArgs e)
        {
            dgvDoctos.Width = this.Width - dgvOffset;
            dgvDoctos.Height = this.Height - dgvOffset2;
            pgbProg.Width = this.Width - pgbOffset;
        }

        private void tbCal01_Click(object sender, EventArgs e)
        {
            mcC1.Visible = true;
        }

        private void mcCal01_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbHasta.Text = mcCal01.SelectionEnd.ToShortDateString();
            FechaCal = tbHasta.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchHasN = long.Parse(FechaFmt.ToString());
            FchHas = FechaFmt.ToString();

            mcCal01.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbHasta.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    BindDoctos();
                }
            }

        }

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            marca = " ";
            ComboBox cmbMarca = (ComboBox)sender;
            marca = cmbMarca.SelectedValue.ToString();

            BindDoctos();
        }

        private void cbCompradores_SelectedValueChanged(object sender, EventArgs e)
        {
            comprador = " ";
            ComboBox cmbComprador = (ComboBox)sender;
            comprador = cmbComprador.SelectedValue.ToString();

            BindDoctos();
        }

        private void fotoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MuestraFoto();
        }

        private void MuestraFoto()
        {
            try
            {
                        Fotos i = new Fotos();
                        i.Show();
            }
            catch { }
            finally { }
        }

        private void dgvDoctos_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            MmsWin.Front.Utilerias.VarTem.tmpFchBon = this.dgvDoctos.CurrentRow.Cells[0].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpFchRev = this.dgvDoctos.CurrentRow.Cells[15].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpPrv = this.dgvDoctos.CurrentRow.Cells[1].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpSty = this.dgvDoctos.CurrentRow.Cells[3].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpNota = this.dgvDoctos.CurrentRow.Cells[6].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpRutaPdf = this.dgvDoctos.CurrentRow.Cells[23].Value.ToString();
          
            MmsWin.Front.Utilerias.Fotos.numPrv = this.dgvDoctos.CurrentRow.Cells[1].Value.ToString();
            MmsWin.Front.Utilerias.Fotos.numSty = this.dgvDoctos.CurrentRow.Cells[3].Value.ToString();
        }

        private void dgvDoctos_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                FechaCal = tbCal01.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FechaApli = long.Parse(FechaFmt.ToString());

                BindDoctos();
            }
        }

        private void EliminarTSM1_Click(object sender, EventArgs e)
        {
            string message = "Corfirmar la Eliminación del Registro";
            string caption = "Advertencia...";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                string ParFchBon = MmsWin.Front.Utilerias.VarTem.tmpFchBon;
                string ParFchRev = MmsWin.Front.Utilerias.VarTem.tmpFchRev;
                string ParProveedor = MmsWin.Front.Utilerias.VarTem.tmpPrv;
                string ParEstilo = MmsWin.Front.Utilerias.VarTem.tmpSty;
                string ParNota = MmsWin.Front.Utilerias.VarTem.tmpNota;
                MmsWin.Negocio.Bonificaciones.Doctos.GetInstance().EliminaDocumentos(ParFchBon, ParFchRev, ParProveedor, ParEstilo, ParNota);

                BindDoctos();
            }
        }

        private void Doctos_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("Bonificaciones", "Doctos", ParUser);
            }
        }
        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            //
            string NomCol;
            Int32 NoCol = dgvDoctos.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvDoctos.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      
            //
            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void dgvDoctos_Sorted(object sender, EventArgs e)
        {
            SetFontAndColors();
            rowStyle();
        }

        private void cargaPDFTSM_Click(object sender, EventArgs e)
        {
            CargaPDF();
        }

        private void CargaPDF()
        {
            try
            {
                CargaPDF i = new CargaPDF();
                i.Show();
            }
            catch { }
            finally { }
        }

        private void cosnsultaPDFTSM_Click(object sender, EventArgs e)
        {
            try
            {
                string notaPDF = MmsWin.Front.Utilerias.VarTem.tmpRutaPdf;
                Process.Start(notaPDF);
            }
            catch { MessageBox.Show("No hay PDF Cargado"); }
        }

        private void tbProveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbCal01.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindDoctos();
                tbProveedor.Focus();
            }
        }

        private void tbNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbCal01.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindDoctos();
                tbNombre.Focus();
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbCal01.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindDoctos();
                tbDescripcion.Focus();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbCal01.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindDoctos();
                tbDescripcion.Focus();
            }
        }

        private void mcC1_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbCal01.Text = mcC1.SelectionEnd.ToShortDateString();
            FechaCal = tbCal01.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchDeN = long.Parse(FechaFmt.ToString());
            FchDe = FechaFmt.ToString();

            mcC1.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbCal01.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    BindDoctos(); ;
                }
            }
        }

        private void mcC1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcC1.Visible = false;
            }
        }

        private void mcC1_Leave(object sender, EventArgs e)
        {
            mcC1.Visible = false;
        }

        private void mcCal01_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcCal01.Visible = false;
            }
        }

        private void mcCal01_Leave(object sender, EventArgs e)
        {
            mcCal01.Visible = false;
        }

        private void tbHasta_Click(object sender, EventArgs e)
        {
            mcCal01.Visible = true;
            mcCal01.Focus();
        }

        private void pbExcel_Click(object sender, EventArgs e)
        {
            System.Data.DataTable dtDowns = (System.Data.DataTable)(dgvDoctos.DataSource);
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            int nc = dgvDoctos.Columns.Count;


            for (int ii = 1; ii <= nc; ii++)
            {
                xlWorkSheet.Cells[1, ii] = dgvDoctos.Columns[ii - 1].HeaderText;
            }

            System.Data.DataTable dtDocumentos = (System.Data.DataTable)(dgvDoctos.DataSource);
            int nr = dgvDoctos.RowCount;

            int r = 0;
            int rt = 3;
            foreach (DataRow row in dtDocumentos.Rows)
            {
                var gsArray = new[]       {
                                                    row["NOTBON"], //01 Fecha Bonificacion
                                                    row["NOTPRV"], //02 Proveedor
                                                    row["NOTPRN"], //03 Nombre
                                                    row["NOTSTY"], //04 Estilo
                                                    row["NOTDES"], //05 Descripcion
                                                    row["NOTDCP"], //06 Comprador
                                                    row["NOTNOT"], //07 Nota de Credito
                                                    row["NOTSUB"], //08 Subtotal
                                                    row["NOTIVA"], //09 Iva
                                                    row["NOTTOT"], //10 Total
                                                    row["NOTCST"], //11 Costo
                                                    row["NOTPRC"], //12 Precio
                                                    row["NOTMRG"], //13 Margen
                                                    row["NOTNCA"], //14 No Calificacion
                                                    row["NOTFCM"], //15 Fecha Compra
                                                    row["NOTFRE"], //16 Fecha Revision
                                                    row["NOTPZA"], //17 Piezas
                                                    row["NOTVTA"], //18 Venta
                                                    row["NOTONH"], //19 on Hand
                                                    row["NOTPVT"], //20 % Venta
                                                    row["NOTCAL"], //21 Calificaion
                                                    row["NOTTAB"], //22 Tabla de Accion
                                                    row["NOTCMP"], //23 Compras Obsercvaciones
                                                    row["NOTRUT"], //24 Ruta
                                                    row["NOTMAR"], //25 Marca
                                                    row["NOTCOM"], //26 Comprador
                                                    row["NOTBDG"], //27 Bodega
                                                    row["NOTNMR"], //28 Marca
                                                    row["NOTFCHA"],//29 Fecha
                                                    row["NOTHORA"],//30 Hora
                                                    row["NOTUSR"]  //31 Usuario

                                                   };

                Range rng = xlWorkSheet.get_Range("A" + rt, "AE" + rt);
                rng.Value = gsArray;

                this.Text = "Notas de Crédito / " + " " + (r += 1).ToString() + " Registro(s) de " + nr;

                rt++;
            }

            xlWorkSheet.Columns[1].ColumnWidth = 3;
            xlWorkSheet.Columns[2].ColumnWidth = 15;
            xlWorkSheet.Columns[3].ColumnWidth = 50;
            xlWorkSheet.Columns[4].ColumnWidth = 15;
            xlWorkSheet.Columns[5].ColumnWidth = 50;
            xlWorkSheet.Columns[6].ColumnWidth = 20;
            xlWorkSheet.Columns[7].ColumnWidth = 10;
            xlWorkSheet.Columns[8].ColumnWidth = 10;
            xlWorkSheet.Columns[9].ColumnWidth = 10;
            xlWorkSheet.Columns[10].ColumnWidth = 10;
            xlWorkSheet.Columns[11].ColumnWidth = 11;
            xlWorkSheet.Columns[12].ColumnWidth = 11;
            xlWorkSheet.Columns[13].ColumnWidth = 11;
            xlWorkSheet.Columns[14].ColumnWidth = 11;
            xlWorkSheet.Columns[15].ColumnWidth = 11;
            xlWorkSheet.Columns[16].ColumnWidth = 11;
            xlWorkSheet.Columns[17].ColumnWidth = 11;
            xlWorkSheet.Columns[18].ColumnWidth = 11;
            xlWorkSheet.Columns[19].ColumnWidth = 11;
            xlWorkSheet.Columns[20].ColumnWidth = 11;
            xlWorkSheet.Columns[21].ColumnWidth = 11;
            xlWorkSheet.Columns[22].ColumnWidth = 11;
            xlWorkSheet.Columns[23].ColumnWidth = 11;
            xlWorkSheet.Columns[24].ColumnWidth = 11;
            xlWorkSheet.Columns[25].ColumnWidth = 11;
            xlWorkSheet.Columns[26].ColumnWidth = 11;
            xlWorkSheet.Columns[27].ColumnWidth = 11;
            xlWorkSheet.Columns[28].ColumnWidth = 11;
            xlWorkSheet.Columns[29].ColumnWidth = 11;
            xlWorkSheet.Columns[30].ColumnWidth = 11;
            xlWorkSheet.Columns[31].ColumnWidth = 11;


            var Rang1 = xlWorkSheet.get_Range("A1", "A1");
            Rang1.Interior.Color = Color.LightGreen;

            xlWorkSheet.Cells[1, 2].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 3].Cells.Interior.Color = Color.LightSkyBlue;

            xlWorkSheet.Cells[1, 4].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 5].Cells.Interior.Color = Color.LightSalmon;

            var Rang2 = xlWorkSheet.get_Range("F1", "F1");
            Rang2.Interior.Color = Color.LightGreen;

            var Rang3 = xlWorkSheet.get_Range("G1", "G1");
            Rang3.Interior.Color = Color.LightSkyBlue;

            var Rang4 = xlWorkSheet.get_Range("H1", "H1");
            Rang4.Interior.Color = Color.LightSalmon;

            var Rang5 = xlWorkSheet.get_Range("I1", "I1");
            Rang5.Interior.Color = Color.LightSkyBlue;

            var Rang6 = xlWorkSheet.get_Range("J1", "J1");
            Rang6.Interior.Color = Color.LightGreen;

            var Rang7 = xlWorkSheet.get_Range("K1", "K1");
            Rang7.Interior.Color = Color.LightSalmon;

            var Rang9 = xlWorkSheet.get_Range("L1", "L1");
            Rang9.Interior.Color = Color.LightGray;

            var Rang8 = xlWorkSheet.get_Range("M1", "M1");
            Rang8.WrapText = true;
            Rang8.Font.Bold = true;
            Rang8.Font.Color = Color.Black;
            Rang8.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang8.Font.Underline = true;
            Rang8.HorizontalAlignment = HorizontalAlignment.Center;
            Rang8.Interior.Color = Color.LightGray;

            xlWorkSheet.Cells[1, 14].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 15].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 16].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 17].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 18].Cells.Interior.Color = Color.LightGray;
            xlWorkSheet.Cells[1, 19].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 20].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 21].Cells.Interior.Color = Color.LightGray;
            xlWorkSheet.Cells[1, 22].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 23].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 24].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 25].Cells.Interior.Color = Color.LightGray;
            xlWorkSheet.Cells[1, 26].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 27].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 28].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 29].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 30].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 31].Cells.Interior.Color = Color.LightGray;



            String Rango = "A2" + ":" + "AE" + rt;
            Excel.Range SourceRange = (Excel.Range)xlWorkSheet.get_Range("A2", "AE" + rt); // or whatever range you want here
            FormatAsTable(SourceRange, "Table1", "TableStyleMedium2");

            xlWorkSheet.Rows[2].Hidden = true;

            xlWorkSheet.Columns["A"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["G"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["K:M"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["O:P"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["T:V"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["Y:AE"].HorizontalAlignment  = XlHAlign.xlHAlignCenter;

            xlWorkSheet.Columns["A"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["O"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["P"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["AC"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["AD"].NumberFormat = "00-00-00";

            var range = xlWorkSheet.get_Range("A3", "A3");
            range.Select();

            string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
            xlApp.ActiveWindow.Zoom = 80;
            xlWorkBook.SaveAs("C:\\Reportes\\NotasCredito" + Hoy + ".xlsx", Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            string comando = @"C:\\Reportes\\NotasCredito" + Hoy + ".xlsx";
            ExecuteCommand(comando);
        }

        static void ExecuteCommand(string _Command)
        {
            //Indicamos que deseamos inicializar el proceso cmd.exe junto a un comando de arranque. 
            //(/C, le indicamos al proceso cmd que deseamos que cuando termine la tarea asignada se cierre el proceso).
            //Para mas informacion consulte la ayuda de la consola con cmd.exe /? 
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;
            //Inicializa el proceso
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            string result = proc.StandardOutput.ReadToEnd();
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        public void FormatAsTable(Excel.Range SourceRange, string TableName, string TableStyleName)
        {
            SourceRange.Worksheet.ListObjects.Add(XlListObjectSourceType.xlSrcRange,
            SourceRange, System.Type.Missing, XlYesNoGuess.xlYes, System.Type.Missing).Name =
                TableName;
            SourceRange.Select();
            SourceRange.Worksheet.ListObjects[TableName].TableStyle = TableStyleName;
            SourceRange.Worksheet.ListObjects[TableName].ShowAutoFilter = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowHeaders = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowTotals = false;
        }

    }
}
