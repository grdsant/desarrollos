﻿namespace MmsWin.Front.Bonificaciones
{
    partial class Notas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbProvee = new System.Windows.Forms.TextBox();
            this.lblProveedor = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.lblEstilo = new System.Windows.Forms.Label();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.lblFchApl = new System.Windows.Forms.Label();
            this.lblFchCal = new System.Windows.Forms.Label();
            this.tbFchCal = new System.Windows.Forms.TextBox();
            this.tbFchApl = new System.Windows.Forms.TextBox();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.gbCmpBasicos = new System.Windows.Forms.GroupBox();
            this.tbComprador = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tbTablaAcc = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.mtbCalificacion = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.mtbPorc = new System.Windows.Forms.MaskedTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbFchRevision = new System.Windows.Forms.TextBox();
            this.tbFchCompra = new System.Windows.Forms.TextBox();
            this.mtbOnHand = new System.Windows.Forms.MaskedTextBox();
            this.mtbVenta = new System.Windows.Forms.MaskedTextBox();
            this.mtbRecibo = new System.Windows.Forms.MaskedTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btCalcula = new System.Windows.Forms.Button();
            this.gbNota = new System.Windows.Forms.GroupBox();
            this.mtbDifCosto = new System.Windows.Forms.MaskedTextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.mtbRevision = new System.Windows.Forms.MaskedTextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.mtbMargen2 = new System.Windows.Forms.MaskedTextBox();
            this.mtbPrecio2 = new System.Windows.Forms.MaskedTextBox();
            this.mtbCosto2 = new System.Windows.Forms.MaskedTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.mtbMargen1 = new System.Windows.Forms.MaskedTextBox();
            this.mtbPrecio1 = new System.Windows.Forms.MaskedTextBox();
            this.mtbCosto1 = new System.Windows.Forms.MaskedTextBox();
            this.lblMargen = new System.Windows.Forms.Label();
            this.mtbIva = new System.Windows.Forms.MaskedTextBox();
            this.LblNota = new System.Windows.Forms.Label();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.lblCosto = new System.Windows.Forms.Label();
            this.mtbSubTotal = new System.Windows.Forms.MaskedTextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.mtbTotal = new System.Windows.Forms.MaskedTextBox();
            this.lblIva = new System.Windows.Forms.Label();
            this.lblSubTot = new System.Windows.Forms.Label();
            this.mtbMargen = new System.Windows.Forms.MaskedTextBox();
            this.mtbPrecio = new System.Windows.Forms.MaskedTextBox();
            this.mtbCosto = new System.Windows.Forms.MaskedTextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tbTbAccFinal = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.mtbAplMarg = new System.Windows.Forms.MaskedTextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.mtbDifDif = new System.Windows.Forms.MaskedTextBox();
            this.mtbDifCostoDif = new System.Windows.Forms.MaskedTextBox();
            this.mtbDiferencia = new System.Windows.Forms.MaskedTextBox();
            this.mtbImpExistAct = new System.Windows.Forms.MaskedTextBox();
            this.mtbPromObs = new System.Windows.Forms.MaskedTextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.mtbOnHandActual = new System.Windows.Forms.MaskedTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.mtbDifCostoDif1 = new System.Windows.Forms.MaskedTextBox();
            this.mtbDiferencia1 = new System.Windows.Forms.MaskedTextBox();
            this.mtbImpExistAct1 = new System.Windows.Forms.MaskedTextBox();
            this.mtbOnHandActual1 = new System.Windows.Forms.MaskedTextBox();
            this.mtbNotaCred = new System.Windows.Forms.TextBox();
            this.gbCmpBasicos.SuspendLayout();
            this.gbNota.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbProvee
            // 
            this.tbProvee.Enabled = false;
            this.tbProvee.Location = new System.Drawing.Point(136, 84);
            this.tbProvee.Name = "tbProvee";
            this.tbProvee.Size = new System.Drawing.Size(55, 20);
            this.tbProvee.TabIndex = 2;
            // 
            // lblProveedor
            // 
            this.lblProveedor.AutoSize = true;
            this.lblProveedor.Location = new System.Drawing.Point(25, 87);
            this.lblProveedor.Name = "lblProveedor";
            this.lblProveedor.Size = new System.Drawing.Size(56, 13);
            this.lblProveedor.TabIndex = 8;
            this.lblProveedor.Text = "Proveedor";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Location = new System.Drawing.Point(25, 120);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(44, 13);
            this.lblNombre.TabIndex = 9;
            this.lblNombre.Text = "Nombre";
            // 
            // lblEstilo
            // 
            this.lblEstilo.AutoSize = true;
            this.lblEstilo.Location = new System.Drawing.Point(25, 153);
            this.lblEstilo.Name = "lblEstilo";
            this.lblEstilo.Size = new System.Drawing.Size(32, 13);
            this.lblEstilo.TabIndex = 10;
            this.lblEstilo.Text = "Estilo";
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.AutoSize = true;
            this.lblDescripcion.Location = new System.Drawing.Point(25, 186);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(63, 13);
            this.lblDescripcion.TabIndex = 11;
            this.lblDescripcion.Text = "Descripcion";
            // 
            // tbNombre
            // 
            this.tbNombre.Enabled = false;
            this.tbNombre.Location = new System.Drawing.Point(136, 117);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(202, 20);
            this.tbNombre.TabIndex = 3;
            // 
            // tbEstilo
            // 
            this.tbEstilo.Enabled = false;
            this.tbEstilo.Location = new System.Drawing.Point(136, 150);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(132, 20);
            this.tbEstilo.TabIndex = 4;
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.Enabled = false;
            this.tbDescripcion.Location = new System.Drawing.Point(136, 183);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(202, 20);
            this.tbDescripcion.TabIndex = 5;
            // 
            // lblFchApl
            // 
            this.lblFchApl.AutoSize = true;
            this.lblFchApl.Location = new System.Drawing.Point(25, 54);
            this.lblFchApl.Name = "lblFchApl";
            this.lblFchApl.Size = new System.Drawing.Size(104, 13);
            this.lblFchApl.TabIndex = 7;
            this.lblFchApl.Text = "Fecha de Aplicacion";
            // 
            // lblFchCal
            // 
            this.lblFchCal.AutoSize = true;
            this.lblFchCal.Location = new System.Drawing.Point(25, 21);
            this.lblFchCal.Name = "lblFchCal";
            this.lblFchCal.Size = new System.Drawing.Size(109, 13);
            this.lblFchCal.TabIndex = 6;
            this.lblFchCal.Text = "Fecha de Calificacion";
            // 
            // tbFchCal
            // 
            this.tbFchCal.Enabled = false;
            this.tbFchCal.Location = new System.Drawing.Point(136, 18);
            this.tbFchCal.Name = "tbFchCal";
            this.tbFchCal.Size = new System.Drawing.Size(82, 20);
            this.tbFchCal.TabIndex = 0;
            // 
            // tbFchApl
            // 
            this.tbFchApl.Enabled = false;
            this.tbFchApl.Location = new System.Drawing.Point(136, 51);
            this.tbFchApl.Name = "tbFchApl";
            this.tbFchApl.Size = new System.Drawing.Size(82, 20);
            this.tbFchApl.TabIndex = 1;
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(28, 510);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 15;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(800, 510);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 17;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // gbCmpBasicos
            // 
            this.gbCmpBasicos.Controls.Add(this.tbComprador);
            this.gbCmpBasicos.Controls.Add(this.label9);
            this.gbCmpBasicos.Controls.Add(this.tbTablaAcc);
            this.gbCmpBasicos.Controls.Add(this.label8);
            this.gbCmpBasicos.Controls.Add(this.mtbCalificacion);
            this.gbCmpBasicos.Controls.Add(this.label7);
            this.gbCmpBasicos.Controls.Add(this.mtbPorc);
            this.gbCmpBasicos.Controls.Add(this.label6);
            this.gbCmpBasicos.Controls.Add(this.tbFchRevision);
            this.gbCmpBasicos.Controls.Add(this.tbFchCompra);
            this.gbCmpBasicos.Controls.Add(this.mtbOnHand);
            this.gbCmpBasicos.Controls.Add(this.mtbVenta);
            this.gbCmpBasicos.Controls.Add(this.mtbRecibo);
            this.gbCmpBasicos.Controls.Add(this.label5);
            this.gbCmpBasicos.Controls.Add(this.label4);
            this.gbCmpBasicos.Controls.Add(this.label3);
            this.gbCmpBasicos.Controls.Add(this.label2);
            this.gbCmpBasicos.Controls.Add(this.label1);
            this.gbCmpBasicos.Location = new System.Drawing.Point(12, 0);
            this.gbCmpBasicos.Name = "gbCmpBasicos";
            this.gbCmpBasicos.Size = new System.Drawing.Size(336, 504);
            this.gbCmpBasicos.TabIndex = 3;
            this.gbCmpBasicos.TabStop = false;
            // 
            // tbComprador
            // 
            this.tbComprador.Enabled = false;
            this.tbComprador.Location = new System.Drawing.Point(119, 475);
            this.tbComprador.Name = "tbComprador";
            this.tbComprador.Size = new System.Drawing.Size(203, 20);
            this.tbComprador.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 478);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Comprador";
            // 
            // tbTablaAcc
            // 
            this.tbTablaAcc.Enabled = false;
            this.tbTablaAcc.Location = new System.Drawing.Point(122, 444);
            this.tbTablaAcc.Name = "tbTablaAcc";
            this.tbTablaAcc.Size = new System.Drawing.Size(203, 20);
            this.tbTablaAcc.TabIndex = 7;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 447);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Tabla  de Accion";
            // 
            // mtbCalificacion
            // 
            this.mtbCalificacion.Enabled = false;
            this.mtbCalificacion.Location = new System.Drawing.Point(123, 414);
            this.mtbCalificacion.Name = "mtbCalificacion";
            this.mtbCalificacion.Size = new System.Drawing.Size(100, 20);
            this.mtbCalificacion.TabIndex = 6;
            this.mtbCalificacion.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 417);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Calificacion";
            // 
            // mtbPorc
            // 
            this.mtbPorc.Enabled = false;
            this.mtbPorc.Location = new System.Drawing.Point(123, 381);
            this.mtbPorc.Name = "mtbPorc";
            this.mtbPorc.Size = new System.Drawing.Size(100, 20);
            this.mtbPorc.TabIndex = 5;
            this.mtbPorc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 384);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "% Venta";
            // 
            // tbFchRevision
            // 
            this.tbFchRevision.Enabled = false;
            this.tbFchRevision.Location = new System.Drawing.Point(123, 249);
            this.tbFchRevision.Name = "tbFchRevision";
            this.tbFchRevision.Size = new System.Drawing.Size(82, 20);
            this.tbFchRevision.TabIndex = 1;
            // 
            // tbFchCompra
            // 
            this.tbFchCompra.Enabled = false;
            this.tbFchCompra.Location = new System.Drawing.Point(123, 216);
            this.tbFchCompra.Name = "tbFchCompra";
            this.tbFchCompra.Size = new System.Drawing.Size(82, 20);
            this.tbFchCompra.TabIndex = 0;
            // 
            // mtbOnHand
            // 
            this.mtbOnHand.Enabled = false;
            this.mtbOnHand.Location = new System.Drawing.Point(123, 348);
            this.mtbOnHand.Name = "mtbOnHand";
            this.mtbOnHand.Size = new System.Drawing.Size(100, 20);
            this.mtbOnHand.TabIndex = 4;
            this.mtbOnHand.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbVenta
            // 
            this.mtbVenta.Enabled = false;
            this.mtbVenta.Location = new System.Drawing.Point(123, 315);
            this.mtbVenta.Name = "mtbVenta";
            this.mtbVenta.Size = new System.Drawing.Size(100, 20);
            this.mtbVenta.TabIndex = 3;
            this.mtbVenta.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbRecibo
            // 
            this.mtbRecibo.Enabled = false;
            this.mtbRecibo.Location = new System.Drawing.Point(123, 282);
            this.mtbRecibo.Name = "mtbRecibo";
            this.mtbRecibo.Size = new System.Drawing.Size(100, 20);
            this.mtbRecibo.TabIndex = 2;
            this.mtbRecibo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 351);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(50, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "On Hand";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 318);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Venta";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 285);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Recibo";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 252);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Fecha de Revision";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 219);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Fecha de Compra";
            // 
            // btCalcula
            // 
            this.btCalcula.Location = new System.Drawing.Point(426, 510);
            this.btCalcula.Name = "btCalcula";
            this.btCalcula.Size = new System.Drawing.Size(75, 23);
            this.btCalcula.TabIndex = 16;
            this.btCalcula.Text = "Calcular";
            this.btCalcula.UseVisualStyleBackColor = true;
            this.btCalcula.Click += new System.EventHandler(this.btCalcula_Click);
            // 
            // gbNota
            // 
            this.gbNota.Controls.Add(this.mtbNotaCred);
            this.gbNota.Controls.Add(this.mtbDifCosto);
            this.gbNota.Controls.Add(this.label17);
            this.gbNota.Controls.Add(this.mtbRevision);
            this.gbNota.Controls.Add(this.label16);
            this.gbNota.Controls.Add(this.label13);
            this.gbNota.Controls.Add(this.label14);
            this.gbNota.Controls.Add(this.label15);
            this.gbNota.Controls.Add(this.mtbMargen2);
            this.gbNota.Controls.Add(this.mtbPrecio2);
            this.gbNota.Controls.Add(this.mtbCosto2);
            this.gbNota.Controls.Add(this.label10);
            this.gbNota.Controls.Add(this.label11);
            this.gbNota.Controls.Add(this.label12);
            this.gbNota.Controls.Add(this.mtbMargen1);
            this.gbNota.Controls.Add(this.mtbPrecio1);
            this.gbNota.Controls.Add(this.mtbCosto1);
            this.gbNota.Controls.Add(this.lblMargen);
            this.gbNota.Controls.Add(this.mtbIva);
            this.gbNota.Controls.Add(this.LblNota);
            this.gbNota.Controls.Add(this.lblPrecio);
            this.gbNota.Controls.Add(this.lblCosto);
            this.gbNota.Controls.Add(this.mtbSubTotal);
            this.gbNota.Controls.Add(this.lblTotal);
            this.gbNota.Controls.Add(this.mtbTotal);
            this.gbNota.Controls.Add(this.lblIva);
            this.gbNota.Controls.Add(this.lblSubTot);
            this.gbNota.Controls.Add(this.mtbMargen);
            this.gbNota.Controls.Add(this.mtbPrecio);
            this.gbNota.Controls.Add(this.mtbCosto);
            this.gbNota.Location = new System.Drawing.Point(354, 0);
            this.gbNota.Name = "gbNota";
            this.gbNota.Size = new System.Drawing.Size(291, 504);
            this.gbNota.TabIndex = 2;
            this.gbNota.TabStop = false;
            this.gbNota.Text = "Notas de Credito";
            // 
            // mtbDifCosto
            // 
            this.mtbDifCosto.Enabled = false;
            this.mtbDifCosto.Location = new System.Drawing.Point(129, 440);
            this.mtbDifCosto.Name = "mtbDifCosto";
            this.mtbDifCosto.Size = new System.Drawing.Size(100, 20);
            this.mtbDifCosto.TabIndex = 14;
            this.mtbDifCosto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label17.Location = new System.Drawing.Point(20, 444);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(50, 13);
            this.label17.TabIndex = 29;
            this.label17.Text = "Dif Costo";
            // 
            // mtbRevision
            // 
            this.mtbRevision.Enabled = false;
            this.mtbRevision.Location = new System.Drawing.Point(129, 410);
            this.mtbRevision.Name = "mtbRevision";
            this.mtbRevision.Size = new System.Drawing.Size(156, 20);
            this.mtbRevision.TabIndex = 13;
            this.mtbRevision.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label16.Location = new System.Drawing.Point(20, 417);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 13);
            this.label16.TabIndex = 28;
            this.label16.Text = "Revision";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label13.ForeColor = System.Drawing.Color.Green;
            this.label13.Location = new System.Drawing.Point(18, 377);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 13);
            this.label13.TabIndex = 27;
            this.label13.Text = "Margen  Final";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label14.ForeColor = System.Drawing.Color.Green;
            this.label14.Location = new System.Drawing.Point(18, 348);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 13);
            this.label14.TabIndex = 26;
            this.label14.Text = "Precio Final     ";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label15.ForeColor = System.Drawing.Color.Green;
            this.label15.Location = new System.Drawing.Point(18, 319);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 13);
            this.label15.TabIndex = 25;
            this.label15.Text = "Costo  Final   ";
            // 
            // mtbMargen2
            // 
            this.mtbMargen2.Enabled = false;
            this.mtbMargen2.Location = new System.Drawing.Point(128, 371);
            this.mtbMargen2.Name = "mtbMargen2";
            this.mtbMargen2.Size = new System.Drawing.Size(100, 20);
            this.mtbMargen2.TabIndex = 12;
            this.mtbMargen2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPrecio2
            // 
            this.mtbPrecio2.Enabled = false;
            this.mtbPrecio2.Location = new System.Drawing.Point(128, 342);
            this.mtbPrecio2.Name = "mtbPrecio2";
            this.mtbPrecio2.Size = new System.Drawing.Size(100, 20);
            this.mtbPrecio2.TabIndex = 11;
            this.mtbPrecio2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbCosto2
            // 
            this.mtbCosto2.Enabled = false;
            this.mtbCosto2.Location = new System.Drawing.Point(128, 313);
            this.mtbCosto2.Name = "mtbCosto2";
            this.mtbCosto2.Size = new System.Drawing.Size(100, 20);
            this.mtbCosto2.TabIndex = 10;
            this.mtbCosto2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label10.ForeColor = System.Drawing.Color.Yellow;
            this.label10.Location = new System.Drawing.Point(18, 290);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 13);
            this.label10.TabIndex = 24;
            this.label10.Text = "Margen  Nuevo";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label11.ForeColor = System.Drawing.Color.Yellow;
            this.label11.Location = new System.Drawing.Point(18, 261);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 13);
            this.label11.TabIndex = 23;
            this.label11.Text = "Precio Nuevo     ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label12.ForeColor = System.Drawing.Color.Yellow;
            this.label12.Location = new System.Drawing.Point(18, 232);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(84, 13);
            this.label12.TabIndex = 22;
            this.label12.Text = "Costo  Nuevo    ";
            // 
            // mtbMargen1
            // 
            this.mtbMargen1.Enabled = false;
            this.mtbMargen1.Location = new System.Drawing.Point(128, 284);
            this.mtbMargen1.Name = "mtbMargen1";
            this.mtbMargen1.Size = new System.Drawing.Size(100, 20);
            this.mtbMargen1.TabIndex = 9;
            this.mtbMargen1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPrecio1
            // 
            this.mtbPrecio1.Enabled = false;
            this.mtbPrecio1.Location = new System.Drawing.Point(128, 255);
            this.mtbPrecio1.Name = "mtbPrecio1";
            this.mtbPrecio1.Size = new System.Drawing.Size(100, 20);
            this.mtbPrecio1.TabIndex = 8;
            this.mtbPrecio1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbCosto1
            // 
            this.mtbCosto1.Enabled = false;
            this.mtbCosto1.Location = new System.Drawing.Point(128, 226);
            this.mtbCosto1.Name = "mtbCosto1";
            this.mtbCosto1.Size = new System.Drawing.Size(100, 20);
            this.mtbCosto1.TabIndex = 7;
            this.mtbCosto1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblMargen
            // 
            this.lblMargen.AutoSize = true;
            this.lblMargen.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblMargen.Location = new System.Drawing.Point(18, 188);
            this.lblMargen.Name = "lblMargen";
            this.lblMargen.Size = new System.Drawing.Size(67, 13);
            this.lblMargen.TabIndex = 21;
            this.lblMargen.Text = "Margen        ";
            // 
            // mtbIva
            // 
            this.mtbIva.Enabled = false;
            this.mtbIva.Location = new System.Drawing.Point(129, 77);
            this.mtbIva.Name = "mtbIva";
            this.mtbIva.Size = new System.Drawing.Size(100, 20);
            this.mtbIva.TabIndex = 2;
            this.mtbIva.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LblNota
            // 
            this.LblNota.AutoSize = true;
            this.LblNota.BackColor = System.Drawing.Color.DarkGray;
            this.LblNota.Location = new System.Drawing.Point(18, 26);
            this.LblNota.Name = "LblNota";
            this.LblNota.Size = new System.Drawing.Size(87, 13);
            this.LblNota.TabIndex = 15;
            this.LblNota.Text = "Nota de Credito  ";
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblPrecio.Location = new System.Drawing.Point(18, 161);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(73, 13);
            this.lblPrecio.TabIndex = 20;
            this.lblPrecio.Text = "Precio            ";
            // 
            // lblCosto
            // 
            this.lblCosto.AutoSize = true;
            this.lblCosto.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblCosto.Location = new System.Drawing.Point(18, 134);
            this.lblCosto.Name = "lblCosto";
            this.lblCosto.Size = new System.Drawing.Size(82, 13);
            this.lblCosto.TabIndex = 19;
            this.lblCosto.Text = "Costo                ";
            // 
            // mtbSubTotal
            // 
            this.mtbSubTotal.Enabled = false;
            this.mtbSubTotal.Location = new System.Drawing.Point(129, 51);
            this.mtbSubTotal.Name = "mtbSubTotal";
            this.mtbSubTotal.Size = new System.Drawing.Size(100, 20);
            this.mtbSubTotal.TabIndex = 1;
            this.mtbSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblTotal.Location = new System.Drawing.Point(18, 107);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(79, 13);
            this.lblTotal.TabIndex = 18;
            this.lblTotal.Text = "Total                ";
            // 
            // mtbTotal
            // 
            this.mtbTotal.Enabled = false;
            this.mtbTotal.Location = new System.Drawing.Point(129, 103);
            this.mtbTotal.Name = "mtbTotal";
            this.mtbTotal.Size = new System.Drawing.Size(100, 20);
            this.mtbTotal.TabIndex = 3;
            this.mtbTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblIva
            // 
            this.lblIva.AutoSize = true;
            this.lblIva.BackColor = System.Drawing.Color.DarkGray;
            this.lblIva.Location = new System.Drawing.Point(18, 80);
            this.lblIva.Name = "lblIva";
            this.lblIva.Size = new System.Drawing.Size(82, 13);
            this.lblIva.TabIndex = 17;
            this.lblIva.Text = "Iva                    ";
            // 
            // lblSubTot
            // 
            this.lblSubTot.AutoSize = true;
            this.lblSubTot.BackColor = System.Drawing.Color.DarkGray;
            this.lblSubTot.Location = new System.Drawing.Point(18, 53);
            this.lblSubTot.Name = "lblSubTot";
            this.lblSubTot.Size = new System.Drawing.Size(83, 13);
            this.lblSubTot.TabIndex = 16;
            this.lblSubTot.Text = "Sub Total          ";
            // 
            // mtbMargen
            // 
            this.mtbMargen.Enabled = false;
            this.mtbMargen.Location = new System.Drawing.Point(129, 181);
            this.mtbMargen.Name = "mtbMargen";
            this.mtbMargen.Size = new System.Drawing.Size(100, 20);
            this.mtbMargen.TabIndex = 6;
            this.mtbMargen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPrecio
            // 
            this.mtbPrecio.Enabled = false;
            this.mtbPrecio.Location = new System.Drawing.Point(129, 155);
            this.mtbPrecio.Name = "mtbPrecio";
            this.mtbPrecio.Size = new System.Drawing.Size(100, 20);
            this.mtbPrecio.TabIndex = 5;
            this.mtbPrecio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbCosto
            // 
            this.mtbCosto.Enabled = false;
            this.mtbCosto.Location = new System.Drawing.Point(129, 129);
            this.mtbCosto.Name = "mtbCosto";
            this.mtbCosto.Size = new System.Drawing.Size(100, 20);
            this.mtbCosto.TabIndex = 4;
            this.mtbCosto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.mtbDifCostoDif1);
            this.groupBox2.Controls.Add(this.mtbDiferencia1);
            this.groupBox2.Controls.Add(this.mtbImpExistAct1);
            this.groupBox2.Controls.Add(this.mtbOnHandActual1);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label27);
            this.groupBox2.Controls.Add(this.label28);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.tbTbAccFinal);
            this.groupBox2.Controls.Add(this.label26);
            this.groupBox2.Controls.Add(this.mtbAplMarg);
            this.groupBox2.Controls.Add(this.label25);
            this.groupBox2.Controls.Add(this.mtbDifDif);
            this.groupBox2.Controls.Add(this.mtbDifCostoDif);
            this.groupBox2.Controls.Add(this.mtbDiferencia);
            this.groupBox2.Controls.Add(this.mtbImpExistAct);
            this.groupBox2.Controls.Add(this.mtbPromObs);
            this.groupBox2.Controls.Add(this.label24);
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.mtbOnHandActual);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Location = new System.Drawing.Point(651, 0);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(261, 504);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Diferencias";
            // 
            // tbTbAccFinal
            // 
            this.tbTbAccFinal.Enabled = false;
            this.tbTbAccFinal.Location = new System.Drawing.Point(120, 445);
            this.tbTbAccFinal.Name = "tbTbAccFinal";
            this.tbTbAccFinal.Size = new System.Drawing.Size(135, 20);
            this.tbTbAccFinal.TabIndex = 11;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(11, 454);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(98, 13);
            this.label26.TabIndex = 17;
            this.label26.Text = "Tabla  Accion Final";
            // 
            // mtbAplMarg
            // 
            this.mtbAplMarg.Enabled = false;
            this.mtbAplMarg.Location = new System.Drawing.Point(124, 403);
            this.mtbAplMarg.Name = "mtbAplMarg";
            this.mtbAplMarg.Size = new System.Drawing.Size(100, 20);
            this.mtbAplMarg.TabIndex = 10;
            this.mtbAplMarg.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(11, 405);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(106, 13);
            this.label25.TabIndex = 14;
            this.label25.Text = "Aplicacion al Margen";
            // 
            // mtbDifDif
            // 
            this.mtbDifDif.Enabled = false;
            this.mtbDifDif.Location = new System.Drawing.Point(124, 333);
            this.mtbDifDif.Name = "mtbDifDif";
            this.mtbDifDif.Size = new System.Drawing.Size(100, 20);
            this.mtbDifDif.TabIndex = 8;
            this.mtbDifDif.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbDifCostoDif
            // 
            this.mtbDifCostoDif.Enabled = false;
            this.mtbDifCostoDif.Location = new System.Drawing.Point(124, 124);
            this.mtbDifCostoDif.Name = "mtbDifCostoDif";
            this.mtbDifCostoDif.Size = new System.Drawing.Size(100, 20);
            this.mtbDifCostoDif.TabIndex = 3;
            this.mtbDifCostoDif.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbDiferencia
            // 
            this.mtbDiferencia.Enabled = false;
            this.mtbDiferencia.Location = new System.Drawing.Point(124, 89);
            this.mtbDiferencia.Name = "mtbDiferencia";
            this.mtbDiferencia.Size = new System.Drawing.Size(100, 20);
            this.mtbDiferencia.TabIndex = 2;
            this.mtbDiferencia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbImpExistAct
            // 
            this.mtbImpExistAct.Enabled = false;
            this.mtbImpExistAct.Location = new System.Drawing.Point(124, 54);
            this.mtbImpExistAct.Name = "mtbImpExistAct";
            this.mtbImpExistAct.Size = new System.Drawing.Size(100, 20);
            this.mtbImpExistAct.TabIndex = 1;
            this.mtbImpExistAct.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPromObs
            // 
            this.mtbPromObs.Enabled = false;
            this.mtbPromObs.Location = new System.Drawing.Point(124, 368);
            this.mtbPromObs.Name = "mtbPromObs";
            this.mtbPromObs.Size = new System.Drawing.Size(131, 20);
            this.mtbPromObs.TabIndex = 9;
            this.mtbPromObs.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(11, 371);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(85, 13);
            this.label24.TabIndex = 13;
            this.label24.Text = "Promocion_Obs.";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(11, 337);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(55, 13);
            this.label23.TabIndex = 12;
            this.label23.Text = "Diferencia";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.ForeColor = System.Drawing.Color.Yellow;
            this.label21.Location = new System.Drawing.Point(11, 128);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 13);
            this.label21.TabIndex = 10;
            this.label21.Text = "Dif_Costo";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.ForeColor = System.Drawing.Color.Yellow;
            this.label20.Location = new System.Drawing.Point(11, 94);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(55, 13);
            this.label20.TabIndex = 9;
            this.label20.Text = "Diferencia";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.Yellow;
            this.label19.Location = new System.Drawing.Point(11, 60);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(74, 13);
            this.label19.TabIndex = 8;
            this.label19.Text = "Imp_Exist_Act";
            // 
            // mtbOnHandActual
            // 
            this.mtbOnHandActual.Enabled = false;
            this.mtbOnHandActual.Location = new System.Drawing.Point(124, 19);
            this.mtbOnHandActual.Name = "mtbOnHandActual";
            this.mtbOnHandActual.Size = new System.Drawing.Size(100, 20);
            this.mtbOnHandActual.TabIndex = 0;
            this.mtbOnHandActual.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.ForeColor = System.Drawing.Color.Yellow;
            this.label18.Location = new System.Drawing.Point(11, 26);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(65, 13);
            this.label18.TabIndex = 7;
            this.label18.Text = "Exist_Actual";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.Color.Green;
            this.label22.Location = new System.Drawing.Point(15, 271);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 13);
            this.label22.TabIndex = 22;
            this.label22.Text = "Dif_Costo";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.ForeColor = System.Drawing.Color.Green;
            this.label27.Location = new System.Drawing.Point(15, 237);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(55, 13);
            this.label27.TabIndex = 21;
            this.label27.Text = "Diferencia";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.ForeColor = System.Drawing.Color.Green;
            this.label28.Location = new System.Drawing.Point(15, 203);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(74, 13);
            this.label28.TabIndex = 20;
            this.label28.Text = "Imp_Exist_Act";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.ForeColor = System.Drawing.Color.Green;
            this.label29.Location = new System.Drawing.Point(15, 169);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(65, 13);
            this.label29.TabIndex = 19;
            this.label29.Text = "Exist_Actual";
            // 
            // mtbDifCostoDif1
            // 
            this.mtbDifCostoDif1.Enabled = false;
            this.mtbDifCostoDif1.Location = new System.Drawing.Point(123, 273);
            this.mtbDifCostoDif1.Name = "mtbDifCostoDif1";
            this.mtbDifCostoDif1.Size = new System.Drawing.Size(100, 20);
            this.mtbDifCostoDif1.TabIndex = 7;
            this.mtbDifCostoDif1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbDiferencia1
            // 
            this.mtbDiferencia1.Enabled = false;
            this.mtbDiferencia1.Location = new System.Drawing.Point(123, 238);
            this.mtbDiferencia1.Name = "mtbDiferencia1";
            this.mtbDiferencia1.Size = new System.Drawing.Size(100, 20);
            this.mtbDiferencia1.TabIndex = 6;
            this.mtbDiferencia1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbImpExistAct1
            // 
            this.mtbImpExistAct1.Enabled = false;
            this.mtbImpExistAct1.Location = new System.Drawing.Point(123, 203);
            this.mtbImpExistAct1.Name = "mtbImpExistAct1";
            this.mtbImpExistAct1.Size = new System.Drawing.Size(100, 20);
            this.mtbImpExistAct1.TabIndex = 5;
            this.mtbImpExistAct1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbOnHandActual1
            // 
            this.mtbOnHandActual1.Enabled = false;
            this.mtbOnHandActual1.Location = new System.Drawing.Point(123, 168);
            this.mtbOnHandActual1.Name = "mtbOnHandActual1";
            this.mtbOnHandActual1.Size = new System.Drawing.Size(100, 20);
            this.mtbOnHandActual1.TabIndex = 4;
            this.mtbOnHandActual1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbNotaCred
            // 
            this.mtbNotaCred.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.mtbNotaCred.Location = new System.Drawing.Point(128, 26);
            this.mtbNotaCred.Name = "mtbNotaCred";
            this.mtbNotaCred.Size = new System.Drawing.Size(100, 20);
            this.mtbNotaCred.TabIndex = 30;
            this.mtbNotaCred.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mtbNotaCred_KeyPress);
            // 
            // Notas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.LightSlateGray;
            this.ClientSize = new System.Drawing.Size(925, 581);
            this.Controls.Add(this.btCalcula);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.tbFchApl);
            this.Controls.Add(this.tbFchCal);
            this.Controls.Add(this.lblFchCal);
            this.Controls.Add(this.lblFchApl);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.tbEstilo);
            this.Controls.Add(this.tbNombre);
            this.Controls.Add(this.lblDescripcion);
            this.Controls.Add(this.lblEstilo);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.lblProveedor);
            this.Controls.Add(this.tbProvee);
            this.Controls.Add(this.gbCmpBasicos);
            this.Controls.Add(this.gbNota);
            this.Controls.Add(this.groupBox2);
            this.Name = "Notas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Notas_Load);
            this.gbCmpBasicos.ResumeLayout(false);
            this.gbCmpBasicos.PerformLayout();
            this.gbNota.ResumeLayout(false);
            this.gbNota.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbProvee;
        private System.Windows.Forms.Label lblProveedor;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Label lblEstilo;
        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.Label lblFchApl;
        private System.Windows.Forms.Label lblFchCal;
        private System.Windows.Forms.TextBox tbFchCal;
        private System.Windows.Forms.TextBox tbFchApl;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.GroupBox gbCmpBasicos;
        private System.Windows.Forms.Button btCalcula;
        private System.Windows.Forms.GroupBox gbNota;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.MaskedTextBox mtbMargen;
        private System.Windows.Forms.MaskedTextBox mtbPrecio;
        private System.Windows.Forms.MaskedTextBox mtbCosto;
        private System.Windows.Forms.MaskedTextBox mtbIva;
        private System.Windows.Forms.Label LblNota;
        private System.Windows.Forms.MaskedTextBox mtbSubTotal;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.MaskedTextBox mtbTotal;
        private System.Windows.Forms.Label lblIva;
        private System.Windows.Forms.Label lblSubTot;
        private System.Windows.Forms.MaskedTextBox mtbPorc;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbFchRevision;
        private System.Windows.Forms.TextBox tbFchCompra;
        private System.Windows.Forms.MaskedTextBox mtbOnHand;
        private System.Windows.Forms.MaskedTextBox mtbVenta;
        private System.Windows.Forms.MaskedTextBox mtbRecibo;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblMargen;
        private System.Windows.Forms.Label lblCosto;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.MaskedTextBox mtbCalificacion;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbTablaAcc;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbComprador;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.MaskedTextBox mtbMargen2;
        private System.Windows.Forms.MaskedTextBox mtbPrecio2;
        private System.Windows.Forms.MaskedTextBox mtbCosto2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.MaskedTextBox mtbMargen1;
        private System.Windows.Forms.MaskedTextBox mtbPrecio1;
        private System.Windows.Forms.MaskedTextBox mtbCosto1;
        private System.Windows.Forms.MaskedTextBox mtbDifCosto;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.MaskedTextBox mtbRevision;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.MaskedTextBox mtbAplMarg;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.MaskedTextBox mtbDifDif;
        private System.Windows.Forms.MaskedTextBox mtbDifCostoDif;
        private System.Windows.Forms.MaskedTextBox mtbDiferencia;
        private System.Windows.Forms.MaskedTextBox mtbImpExistAct;
        private System.Windows.Forms.MaskedTextBox mtbPromObs;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.MaskedTextBox mtbOnHandActual;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tbTbAccFinal;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.MaskedTextBox mtbDifCostoDif1;
        private System.Windows.Forms.MaskedTextBox mtbDiferencia1;
        private System.Windows.Forms.MaskedTextBox mtbImpExistAct1;
        private System.Windows.Forms.MaskedTextBox mtbOnHandActual1;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox mtbNotaCred;
    }
}