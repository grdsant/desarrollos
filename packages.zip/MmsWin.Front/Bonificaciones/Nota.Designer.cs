﻿namespace MmsWin.Front.Bonificaciones
{
    partial class Nota
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mtbCosto = new System.Windows.Forms.MaskedTextBox();
            this.mtbPrecio = new System.Windows.Forms.MaskedTextBox();
            this.mtbMargen = new System.Windows.Forms.MaskedTextBox();
            this.lblSubTot = new System.Windows.Forms.Label();
            this.lblIva = new System.Windows.Forms.Label();
            this.mtbTotal = new System.Windows.Forms.MaskedTextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.mtbSubTotal = new System.Windows.Forms.MaskedTextBox();
            this.lblCosto = new System.Windows.Forms.Label();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.LblNota = new System.Windows.Forms.Label();
            this.mtbIva = new System.Windows.Forms.MaskedTextBox();
            this.lblMargen = new System.Windows.Forms.Label();
            this.gbNota = new System.Windows.Forms.GroupBox();
            this.mtbNOTIMF2 = new System.Windows.Forms.MaskedTextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.mtbNOTIDC2 = new System.Windows.Forms.MaskedTextBox();
            this.lbImpDiferenciaCosto = new System.Windows.Forms.Label();
            this.mtbNOTDCF2 = new System.Windows.Forms.MaskedTextBox();
            this.lbDifCostoFinal = new System.Windows.Forms.Label();
            this.mtbNOTIMP1 = new System.Windows.Forms.MaskedTextBox();
            this.lbImpOnHand = new System.Windows.Forms.Label();
            this.mtbNOTPZA1 = new System.Windows.Forms.MaskedTextBox();
            this.lbPzaOnHand = new System.Windows.Forms.Label();
            this.mtbNOTCSTD = new System.Windows.Forms.MaskedTextBox();
            this.lbDifCosto = new System.Windows.Forms.Label();
            this.lbTablaDeAccFinal = new System.Windows.Forms.Label();
            this.mtbNOTTABF = new System.Windows.Forms.MaskedTextBox();
            this.lbTablaDeAccNueva = new System.Windows.Forms.Label();
            this.mtbNOTTAB1 = new System.Windows.Forms.MaskedTextBox();
            this.lbTablaDeAccActual = new System.Windows.Forms.Label();
            this.mtbNOTTAB = new System.Windows.Forms.MaskedTextBox();
            this.lbTablaDeAccion = new System.Windows.Forms.Label();
            this.mtbNOTONH = new System.Windows.Forms.MaskedTextBox();
            this.lbOnHand = new System.Windows.Forms.Label();
            this.lbNotaPDF = new System.Windows.Forms.Label();
            this.tbFuentePDF = new System.Windows.Forms.TextBox();
            this.pbExaminarPDF = new System.Windows.Forms.Button();
            this.lbFinal = new System.Windows.Forms.Label();
            this.lbNuevo = new System.Windows.Forms.Label();
            this.lbActual = new System.Windows.Forms.Label();
            this.mtbMargenFinal = new System.Windows.Forms.MaskedTextBox();
            this.mtbPrecioFinal = new System.Windows.Forms.MaskedTextBox();
            this.mtbCostoFinal = new System.Windows.Forms.MaskedTextBox();
            this.mtbMargenNuevo = new System.Windows.Forms.MaskedTextBox();
            this.mtbPrecioNuevo = new System.Windows.Forms.MaskedTextBox();
            this.mtbCostoNuevo = new System.Windows.Forms.MaskedTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.mtbPorc = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbFchCal = new System.Windows.Forms.TextBox();
            this.tbFchApl = new System.Windows.Forms.TextBox();
            this.tbProvee = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.mtbNotaCred = new System.Windows.Forms.TextBox();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnCambiar = new System.Windows.Forms.Button();
            this.lbFormatoPDF = new System.Windows.Forms.Label();
            this.tbDestinoPDF = new System.Windows.Forms.TextBox();
            this.pbCargarPDF = new System.Windows.Forms.Button();
            this.gbNota.SuspendLayout();
            this.SuspendLayout();
            // 
            // mtbCosto
            // 
            this.mtbCosto.Enabled = false;
            this.mtbCosto.Location = new System.Drawing.Point(124, 290);
            this.mtbCosto.Name = "mtbCosto";
            this.mtbCosto.Size = new System.Drawing.Size(60, 20);
            this.mtbCosto.TabIndex = 10;
            this.mtbCosto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPrecio
            // 
            this.mtbPrecio.Enabled = false;
            this.mtbPrecio.Location = new System.Drawing.Point(124, 312);
            this.mtbPrecio.Name = "mtbPrecio";
            this.mtbPrecio.Size = new System.Drawing.Size(60, 20);
            this.mtbPrecio.TabIndex = 11;
            this.mtbPrecio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbMargen
            // 
            this.mtbMargen.Enabled = false;
            this.mtbMargen.Location = new System.Drawing.Point(124, 334);
            this.mtbMargen.Name = "mtbMargen";
            this.mtbMargen.Size = new System.Drawing.Size(60, 20);
            this.mtbMargen.TabIndex = 12;
            this.mtbMargen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblSubTot
            // 
            this.lblSubTot.AutoSize = true;
            this.lblSubTot.BackColor = System.Drawing.Color.LightGreen;
            this.lblSubTot.Location = new System.Drawing.Point(13, 183);
            this.lblSubTot.Name = "lblSubTot";
            this.lblSubTot.Size = new System.Drawing.Size(86, 13);
            this.lblSubTot.TabIndex = 20;
            this.lblSubTot.Text = "Sub Total           ";
            // 
            // lblIva
            // 
            this.lblIva.AutoSize = true;
            this.lblIva.BackColor = System.Drawing.Color.DarkGray;
            this.lblIva.Location = new System.Drawing.Point(13, 205);
            this.lblIva.Name = "lblIva";
            this.lblIva.Size = new System.Drawing.Size(85, 13);
            this.lblIva.TabIndex = 21;
            this.lblIva.Text = "Iva                     ";
            // 
            // mtbTotal
            // 
            this.mtbTotal.Enabled = false;
            this.mtbTotal.Location = new System.Drawing.Point(124, 223);
            this.mtbTotal.Name = "mtbTotal";
            this.mtbTotal.Size = new System.Drawing.Size(100, 20);
            this.mtbTotal.TabIndex = 9;
            this.mtbTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblTotal.Location = new System.Drawing.Point(13, 227);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(85, 13);
            this.lblTotal.TabIndex = 22;
            this.lblTotal.Text = "Total                  ";
            // 
            // mtbSubTotal
            // 
            this.mtbSubTotal.BackColor = System.Drawing.Color.LightGreen;
            this.mtbSubTotal.Enabled = false;
            this.mtbSubTotal.Location = new System.Drawing.Point(124, 179);
            this.mtbSubTotal.Name = "mtbSubTotal";
            this.mtbSubTotal.Size = new System.Drawing.Size(100, 20);
            this.mtbSubTotal.TabIndex = 2;
            this.mtbSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtbSubTotal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mtbSubTotal_KeyPress);
            // 
            // lblCosto
            // 
            this.lblCosto.AutoSize = true;
            this.lblCosto.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblCosto.Location = new System.Drawing.Point(13, 295);
            this.lblCosto.Name = "lblCosto";
            this.lblCosto.Size = new System.Drawing.Size(85, 13);
            this.lblCosto.TabIndex = 23;
            this.lblCosto.Text = "Costo                 ";
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblPrecio.Location = new System.Drawing.Point(13, 317);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(85, 13);
            this.lblPrecio.TabIndex = 24;
            this.lblPrecio.Text = "Precio                ";
            // 
            // LblNota
            // 
            this.LblNota.AutoSize = true;
            this.LblNota.BackColor = System.Drawing.Color.LightGreen;
            this.LblNota.Location = new System.Drawing.Point(13, 161);
            this.LblNota.Name = "LblNota";
            this.LblNota.Size = new System.Drawing.Size(87, 13);
            this.LblNota.TabIndex = 19;
            this.LblNota.Text = "Nota de Credito  ";
            // 
            // mtbIva
            // 
            this.mtbIva.Enabled = false;
            this.mtbIva.Location = new System.Drawing.Point(124, 201);
            this.mtbIva.Name = "mtbIva";
            this.mtbIva.Size = new System.Drawing.Size(100, 20);
            this.mtbIva.TabIndex = 8;
            this.mtbIva.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblMargen
            // 
            this.lblMargen.AutoSize = true;
            this.lblMargen.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblMargen.Location = new System.Drawing.Point(13, 339);
            this.lblMargen.Name = "lblMargen";
            this.lblMargen.Size = new System.Drawing.Size(85, 13);
            this.lblMargen.TabIndex = 25;
            this.lblMargen.Text = "Margen              ";
            // 
            // gbNota
            // 
            this.gbNota.Controls.Add(this.mtbNOTIMF2);
            this.gbNota.Controls.Add(this.label19);
            this.gbNota.Controls.Add(this.mtbNOTIDC2);
            this.gbNota.Controls.Add(this.lbImpDiferenciaCosto);
            this.gbNota.Controls.Add(this.mtbNOTDCF2);
            this.gbNota.Controls.Add(this.lbDifCostoFinal);
            this.gbNota.Controls.Add(this.mtbNOTIMP1);
            this.gbNota.Controls.Add(this.lbImpOnHand);
            this.gbNota.Controls.Add(this.mtbNOTPZA1);
            this.gbNota.Controls.Add(this.lbPzaOnHand);
            this.gbNota.Controls.Add(this.mtbNOTCSTD);
            this.gbNota.Controls.Add(this.lbDifCosto);
            this.gbNota.Controls.Add(this.lbTablaDeAccFinal);
            this.gbNota.Controls.Add(this.mtbNOTTABF);
            this.gbNota.Controls.Add(this.lbTablaDeAccNueva);
            this.gbNota.Controls.Add(this.mtbNOTTAB1);
            this.gbNota.Controls.Add(this.lbTablaDeAccActual);
            this.gbNota.Controls.Add(this.mtbNOTTAB);
            this.gbNota.Controls.Add(this.lbTablaDeAccion);
            this.gbNota.Controls.Add(this.mtbNOTONH);
            this.gbNota.Controls.Add(this.lbOnHand);
            this.gbNota.Controls.Add(this.lbNotaPDF);
            this.gbNota.Controls.Add(this.tbFuentePDF);
            this.gbNota.Controls.Add(this.pbExaminarPDF);
            this.gbNota.Controls.Add(this.lbFinal);
            this.gbNota.Controls.Add(this.lbNuevo);
            this.gbNota.Controls.Add(this.lbActual);
            this.gbNota.Controls.Add(this.mtbMargenFinal);
            this.gbNota.Controls.Add(this.mtbPrecioFinal);
            this.gbNota.Controls.Add(this.mtbCostoFinal);
            this.gbNota.Controls.Add(this.mtbMargenNuevo);
            this.gbNota.Controls.Add(this.mtbPrecioNuevo);
            this.gbNota.Controls.Add(this.mtbCostoNuevo);
            this.gbNota.Controls.Add(this.label8);
            this.gbNota.Controls.Add(this.mtbPorc);
            this.gbNota.Controls.Add(this.label7);
            this.gbNota.Controls.Add(this.tbDescripcion);
            this.gbNota.Controls.Add(this.tbEstilo);
            this.gbNota.Controls.Add(this.tbNombre);
            this.gbNota.Controls.Add(this.label6);
            this.gbNota.Controls.Add(this.label5);
            this.gbNota.Controls.Add(this.label4);
            this.gbNota.Controls.Add(this.tbFchCal);
            this.gbNota.Controls.Add(this.tbFchApl);
            this.gbNota.Controls.Add(this.tbProvee);
            this.gbNota.Controls.Add(this.label3);
            this.gbNota.Controls.Add(this.label2);
            this.gbNota.Controls.Add(this.label1);
            this.gbNota.Controls.Add(this.mtbNotaCred);
            this.gbNota.Controls.Add(this.lblMargen);
            this.gbNota.Controls.Add(this.mtbIva);
            this.gbNota.Controls.Add(this.LblNota);
            this.gbNota.Controls.Add(this.lblPrecio);
            this.gbNota.Controls.Add(this.lblCosto);
            this.gbNota.Controls.Add(this.mtbSubTotal);
            this.gbNota.Controls.Add(this.lblTotal);
            this.gbNota.Controls.Add(this.mtbTotal);
            this.gbNota.Controls.Add(this.lblIva);
            this.gbNota.Controls.Add(this.lblSubTot);
            this.gbNota.Controls.Add(this.mtbMargen);
            this.gbNota.Controls.Add(this.mtbPrecio);
            this.gbNota.Controls.Add(this.mtbCosto);
            this.gbNota.Location = new System.Drawing.Point(30, 12);
            this.gbNota.Name = "gbNota";
            this.gbNota.Size = new System.Drawing.Size(397, 550);
            this.gbNota.TabIndex = 0;
            this.gbNota.TabStop = false;
            this.gbNota.Text = "Nota de Crédito";
            // 
            // mtbNOTIMF2
            // 
            this.mtbNOTIMF2.Enabled = false;
            this.mtbNOTIMF2.Location = new System.Drawing.Point(333, 432);
            this.mtbNOTIMF2.Name = "mtbNOTIMF2";
            this.mtbNOTIMF2.Size = new System.Drawing.Size(60, 20);
            this.mtbNOTIMF2.TabIndex = 61;
            this.mtbNOTIMF2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label19.Location = new System.Drawing.Point(261, 438);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 13);
            this.label19.TabIndex = 60;
            this.label19.Text = "Imp Mrg Final";
            // 
            // mtbNOTIDC2
            // 
            this.mtbNOTIDC2.Enabled = false;
            this.mtbNOTIDC2.Location = new System.Drawing.Point(198, 433);
            this.mtbNOTIDC2.Name = "mtbNOTIDC2";
            this.mtbNOTIDC2.Size = new System.Drawing.Size(60, 20);
            this.mtbNOTIDC2.TabIndex = 59;
            this.mtbNOTIDC2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbImpDiferenciaCosto
            // 
            this.lbImpDiferenciaCosto.AutoSize = true;
            this.lbImpDiferenciaCosto.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbImpDiferenciaCosto.Location = new System.Drawing.Point(125, 438);
            this.lbImpDiferenciaCosto.Name = "lbImpDiferenciaCosto";
            this.lbImpDiferenciaCosto.Size = new System.Drawing.Size(70, 13);
            this.lbImpDiferenciaCosto.TabIndex = 58;
            this.lbImpDiferenciaCosto.Text = "Imp Dif Cst    ";
            // 
            // mtbNOTDCF2
            // 
            this.mtbNOTDCF2.Enabled = false;
            this.mtbNOTDCF2.Location = new System.Drawing.Point(62, 433);
            this.mtbNOTDCF2.Name = "mtbNOTDCF2";
            this.mtbNOTDCF2.Size = new System.Drawing.Size(60, 20);
            this.mtbNOTDCF2.TabIndex = 57;
            this.mtbNOTDCF2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbDifCostoFinal
            // 
            this.lbDifCostoFinal.AutoSize = true;
            this.lbDifCostoFinal.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDifCostoFinal.Location = new System.Drawing.Point(13, 438);
            this.lbDifCostoFinal.Name = "lbDifCostoFinal";
            this.lbDifCostoFinal.Size = new System.Drawing.Size(47, 13);
            this.lbDifCostoFinal.TabIndex = 56;
            this.lbDifCostoFinal.Text = "Dif Cst F";
            // 
            // mtbNOTIMP1
            // 
            this.mtbNOTIMP1.Enabled = false;
            this.mtbNOTIMP1.Location = new System.Drawing.Point(333, 404);
            this.mtbNOTIMP1.Name = "mtbNOTIMP1";
            this.mtbNOTIMP1.Size = new System.Drawing.Size(60, 20);
            this.mtbNOTIMP1.TabIndex = 55;
            this.mtbNOTIMP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbImpOnHand
            // 
            this.lbImpOnHand.AutoSize = true;
            this.lbImpOnHand.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbImpOnHand.Location = new System.Drawing.Point(261, 410);
            this.lbImpOnHand.Name = "lbImpOnHand";
            this.lbImpOnHand.Size = new System.Drawing.Size(70, 13);
            this.lbImpOnHand.TabIndex = 54;
            this.lbImpOnHand.Text = "Imp On Hand";
            // 
            // mtbNOTPZA1
            // 
            this.mtbNOTPZA1.Enabled = false;
            this.mtbNOTPZA1.Location = new System.Drawing.Point(198, 405);
            this.mtbNOTPZA1.Name = "mtbNOTPZA1";
            this.mtbNOTPZA1.Size = new System.Drawing.Size(60, 20);
            this.mtbNOTPZA1.TabIndex = 53;
            this.mtbNOTPZA1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbPzaOnHand
            // 
            this.lbPzaOnHand.AutoSize = true;
            this.lbPzaOnHand.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbPzaOnHand.Location = new System.Drawing.Point(125, 410);
            this.lbPzaOnHand.Name = "lbPzaOnHand";
            this.lbPzaOnHand.Size = new System.Drawing.Size(71, 13);
            this.lbPzaOnHand.TabIndex = 52;
            this.lbPzaOnHand.Text = "Pza On Hand";
            // 
            // mtbNOTCSTD
            // 
            this.mtbNOTCSTD.Enabled = false;
            this.mtbNOTCSTD.Location = new System.Drawing.Point(62, 405);
            this.mtbNOTCSTD.Name = "mtbNOTCSTD";
            this.mtbNOTCSTD.Size = new System.Drawing.Size(60, 20);
            this.mtbNOTCSTD.TabIndex = 51;
            this.mtbNOTCSTD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbDifCosto
            // 
            this.lbDifCosto.AutoSize = true;
            this.lbDifCosto.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbDifCosto.Location = new System.Drawing.Point(13, 410);
            this.lbDifCosto.Name = "lbDifCosto";
            this.lbDifCosto.Size = new System.Drawing.Size(47, 13);
            this.lbDifCosto.TabIndex = 50;
            this.lbDifCosto.Text = "Dif Cst   ";
            // 
            // lbTablaDeAccFinal
            // 
            this.lbTablaDeAccFinal.AutoSize = true;
            this.lbTablaDeAccFinal.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbTablaDeAccFinal.Location = new System.Drawing.Point(284, 358);
            this.lbTablaDeAccFinal.Name = "lbTablaDeAccFinal";
            this.lbTablaDeAccFinal.Size = new System.Drawing.Size(38, 13);
            this.lbTablaDeAccFinal.TabIndex = 49;
            this.lbTablaDeAccFinal.Text = "Final   ";
            this.lbTablaDeAccFinal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mtbNOTTABF
            // 
            this.mtbNOTTABF.Enabled = false;
            this.mtbNOTTABF.Location = new System.Drawing.Point(284, 373);
            this.mtbNOTTABF.Name = "mtbNOTTABF";
            this.mtbNOTTABF.Size = new System.Drawing.Size(38, 20);
            this.mtbNOTTABF.TabIndex = 48;
            this.mtbNOTTABF.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbTablaDeAccNueva
            // 
            this.lbTablaDeAccNueva.AutoSize = true;
            this.lbTablaDeAccNueva.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbTablaDeAccNueva.Location = new System.Drawing.Point(241, 358);
            this.lbTablaDeAccNueva.Name = "lbTablaDeAccNueva";
            this.lbTablaDeAccNueva.Size = new System.Drawing.Size(39, 13);
            this.lbTablaDeAccNueva.TabIndex = 47;
            this.lbTablaDeAccNueva.Text = "Nueva";
            this.lbTablaDeAccNueva.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mtbNOTTAB1
            // 
            this.mtbNOTTAB1.Enabled = false;
            this.mtbNOTTAB1.Location = new System.Drawing.Point(241, 373);
            this.mtbNOTTAB1.Name = "mtbNOTTAB1";
            this.mtbNOTTAB1.Size = new System.Drawing.Size(38, 20);
            this.mtbNOTTAB1.TabIndex = 46;
            this.mtbNOTTAB1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbTablaDeAccActual
            // 
            this.lbTablaDeAccActual.AutoSize = true;
            this.lbTablaDeAccActual.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbTablaDeAccActual.Location = new System.Drawing.Point(199, 358);
            this.lbTablaDeAccActual.Name = "lbTablaDeAccActual";
            this.lbTablaDeAccActual.Size = new System.Drawing.Size(37, 13);
            this.lbTablaDeAccActual.TabIndex = 45;
            this.lbTablaDeAccActual.Text = "Actual";
            this.lbTablaDeAccActual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mtbNOTTAB
            // 
            this.mtbNOTTAB.Enabled = false;
            this.mtbNOTTAB.Location = new System.Drawing.Point(199, 373);
            this.mtbNOTTAB.Name = "mtbNOTTAB";
            this.mtbNOTTAB.Size = new System.Drawing.Size(38, 20);
            this.mtbNOTTAB.TabIndex = 44;
            this.mtbNOTTAB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbTablaDeAccion
            // 
            this.lbTablaDeAccion.AutoSize = true;
            this.lbTablaDeAccion.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbTablaDeAccion.Location = new System.Drawing.Point(135, 377);
            this.lbTablaDeAccion.Name = "lbTablaDeAccion";
            this.lbTablaDeAccion.Size = new System.Drawing.Size(56, 13);
            this.lbTablaDeAccion.TabIndex = 43;
            this.lbTablaDeAccion.Text = "Tabla Acc";
            // 
            // mtbNOTONH
            // 
            this.mtbNOTONH.Enabled = false;
            this.mtbNOTONH.Location = new System.Drawing.Point(69, 373);
            this.mtbNOTONH.Name = "mtbNOTONH";
            this.mtbNOTONH.Size = new System.Drawing.Size(60, 20);
            this.mtbNOTONH.TabIndex = 42;
            this.mtbNOTONH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbOnHand
            // 
            this.lbOnHand.AutoSize = true;
            this.lbOnHand.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbOnHand.Location = new System.Drawing.Point(13, 376);
            this.lbOnHand.Name = "lbOnHand";
            this.lbOnHand.Size = new System.Drawing.Size(50, 13);
            this.lbOnHand.TabIndex = 41;
            this.lbOnHand.Text = "On Hand";
            // 
            // lbNotaPDF
            // 
            this.lbNotaPDF.AutoSize = true;
            this.lbNotaPDF.Location = new System.Drawing.Point(13, 462);
            this.lbNotaPDF.Name = "lbNotaPDF";
            this.lbNotaPDF.Size = new System.Drawing.Size(111, 13);
            this.lbNotaPDF.TabIndex = 40;
            this.lbNotaPDF.Text = "Nota de Crédito (PDF)";
            this.lbNotaPDF.Visible = false;
            // 
            // tbFuentePDF
            // 
            this.tbFuentePDF.Enabled = false;
            this.tbFuentePDF.Location = new System.Drawing.Point(14, 477);
            this.tbFuentePDF.Name = "tbFuentePDF";
            this.tbFuentePDF.Size = new System.Drawing.Size(315, 20);
            this.tbFuentePDF.TabIndex = 39;
            this.tbFuentePDF.Visible = false;
            // 
            // pbExaminarPDF
            // 
            this.pbExaminarPDF.Location = new System.Drawing.Point(330, 475);
            this.pbExaminarPDF.Name = "pbExaminarPDF";
            this.pbExaminarPDF.Size = new System.Drawing.Size(56, 23);
            this.pbExaminarPDF.TabIndex = 38;
            this.pbExaminarPDF.Text = "Examinar";
            this.pbExaminarPDF.UseVisualStyleBackColor = true;
            this.pbExaminarPDF.Visible = false;
            this.pbExaminarPDF.Click += new System.EventHandler(this.pbExaminarPDF_Click);
            // 
            // lbFinal
            // 
            this.lbFinal.AutoSize = true;
            this.lbFinal.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbFinal.Location = new System.Drawing.Point(253, 273);
            this.lbFinal.Name = "lbFinal";
            this.lbFinal.Size = new System.Drawing.Size(56, 13);
            this.lbFinal.TabIndex = 37;
            this.lbFinal.Text = "Final         ";
            // 
            // lbNuevo
            // 
            this.lbNuevo.AutoSize = true;
            this.lbNuevo.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbNuevo.Location = new System.Drawing.Point(189, 273);
            this.lbNuevo.Name = "lbNuevo";
            this.lbNuevo.Size = new System.Drawing.Size(57, 13);
            this.lbNuevo.TabIndex = 36;
            this.lbNuevo.Text = "Nuevo      ";
            // 
            // lbActual
            // 
            this.lbActual.AutoSize = true;
            this.lbActual.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lbActual.Location = new System.Drawing.Point(126, 273);
            this.lbActual.Name = "lbActual";
            this.lbActual.Size = new System.Drawing.Size(58, 13);
            this.lbActual.TabIndex = 35;
            this.lbActual.Text = "Actual       ";
            this.lbActual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mtbMargenFinal
            // 
            this.mtbMargenFinal.Enabled = false;
            this.mtbMargenFinal.Location = new System.Drawing.Point(252, 332);
            this.mtbMargenFinal.Name = "mtbMargenFinal";
            this.mtbMargenFinal.Size = new System.Drawing.Size(60, 20);
            this.mtbMargenFinal.TabIndex = 34;
            this.mtbMargenFinal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPrecioFinal
            // 
            this.mtbPrecioFinal.Enabled = false;
            this.mtbPrecioFinal.Location = new System.Drawing.Point(252, 310);
            this.mtbPrecioFinal.Name = "mtbPrecioFinal";
            this.mtbPrecioFinal.Size = new System.Drawing.Size(60, 20);
            this.mtbPrecioFinal.TabIndex = 33;
            this.mtbPrecioFinal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbCostoFinal
            // 
            this.mtbCostoFinal.Enabled = false;
            this.mtbCostoFinal.Location = new System.Drawing.Point(252, 288);
            this.mtbCostoFinal.Name = "mtbCostoFinal";
            this.mtbCostoFinal.Size = new System.Drawing.Size(60, 20);
            this.mtbCostoFinal.TabIndex = 32;
            this.mtbCostoFinal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbMargenNuevo
            // 
            this.mtbMargenNuevo.Enabled = false;
            this.mtbMargenNuevo.Location = new System.Drawing.Point(188, 333);
            this.mtbMargenNuevo.Name = "mtbMargenNuevo";
            this.mtbMargenNuevo.Size = new System.Drawing.Size(60, 20);
            this.mtbMargenNuevo.TabIndex = 31;
            this.mtbMargenNuevo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPrecioNuevo
            // 
            this.mtbPrecioNuevo.Enabled = false;
            this.mtbPrecioNuevo.Location = new System.Drawing.Point(188, 311);
            this.mtbPrecioNuevo.Name = "mtbPrecioNuevo";
            this.mtbPrecioNuevo.Size = new System.Drawing.Size(60, 20);
            this.mtbPrecioNuevo.TabIndex = 30;
            this.mtbPrecioNuevo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbCostoNuevo
            // 
            this.mtbCostoNuevo.Enabled = false;
            this.mtbCostoNuevo.Location = new System.Drawing.Point(188, 289);
            this.mtbCostoNuevo.Name = "mtbCostoNuevo";
            this.mtbCostoNuevo.Size = new System.Drawing.Size(60, 20);
            this.mtbCostoNuevo.TabIndex = 29;
            this.mtbCostoNuevo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label8.Location = new System.Drawing.Point(227, 249);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(141, 13);
            this.label8.TabIndex = 28;
            this.label8.Text = "Desde 0.0001 Hasta 1.0000";
            // 
            // mtbPorc
            // 
            this.mtbPorc.BackColor = System.Drawing.Color.LightGreen;
            this.mtbPorc.Enabled = false;
            this.mtbPorc.Location = new System.Drawing.Point(124, 245);
            this.mtbPorc.Name = "mtbPorc";
            this.mtbPorc.Size = new System.Drawing.Size(100, 20);
            this.mtbPorc.TabIndex = 1;
            this.mtbPorc.Text = "0";
            this.mtbPorc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtbPorc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mtbPorc_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.LightGreen;
            this.label7.Location = new System.Drawing.Point(13, 251);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "%  x Aplicar";
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDescripcion.Enabled = false;
            this.tbDescripcion.Location = new System.Drawing.Point(124, 135);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(190, 20);
            this.tbDescripcion.TabIndex = 5;
            // 
            // tbEstilo
            // 
            this.tbEstilo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbEstilo.Enabled = false;
            this.tbEstilo.Location = new System.Drawing.Point(124, 113);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(100, 20);
            this.tbEstilo.TabIndex = 4;
            // 
            // tbNombre
            // 
            this.tbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNombre.Enabled = false;
            this.tbNombre.Location = new System.Drawing.Point(124, 91);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(190, 20);
            this.tbNombre.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.DarkGray;
            this.label6.Location = new System.Drawing.Point(13, 139);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "Descripción";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.DarkGray;
            this.label5.Location = new System.Drawing.Point(13, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Estilo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.DarkGray;
            this.label4.Location = new System.Drawing.Point(13, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Nombre";
            // 
            // tbFchCal
            // 
            this.tbFchCal.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbFchCal.Enabled = false;
            this.tbFchCal.Location = new System.Drawing.Point(124, 25);
            this.tbFchCal.Name = "tbFchCal";
            this.tbFchCal.Size = new System.Drawing.Size(100, 20);
            this.tbFchCal.TabIndex = 2;
            // 
            // tbFchApl
            // 
            this.tbFchApl.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbFchApl.Enabled = false;
            this.tbFchApl.Location = new System.Drawing.Point(124, 47);
            this.tbFchApl.Name = "tbFchApl";
            this.tbFchApl.Size = new System.Drawing.Size(100, 20);
            this.tbFchApl.TabIndex = 1;
            // 
            // tbProvee
            // 
            this.tbProvee.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbProvee.Enabled = false;
            this.tbProvee.Location = new System.Drawing.Point(124, 69);
            this.tbProvee.Name = "tbProvee";
            this.tbProvee.Size = new System.Drawing.Size(100, 20);
            this.tbProvee.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkGray;
            this.label3.Location = new System.Drawing.Point(13, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Proveedor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkGray;
            this.label2.Location = new System.Drawing.Point(13, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Fecha Bonificacion  ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkGray;
            this.label1.Location = new System.Drawing.Point(13, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Fecha Revisión";
            // 
            // mtbNotaCred
            // 
            this.mtbNotaCred.BackColor = System.Drawing.Color.LightGreen;
            this.mtbNotaCred.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.mtbNotaCred.Location = new System.Drawing.Point(124, 157);
            this.mtbNotaCred.Name = "mtbNotaCred";
            this.mtbNotaCred.Size = new System.Drawing.Size(100, 20);
            this.mtbNotaCred.TabIndex = 0;
            this.mtbNotaCred.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mtbNotaCred_KeyPress);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(64, 569);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 1;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Location = new System.Drawing.Point(309, 569);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 3;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnCambiar
            // 
            this.btnCambiar.Location = new System.Drawing.Point(188, 569);
            this.btnCambiar.Name = "btnCambiar";
            this.btnCambiar.Size = new System.Drawing.Size(75, 23);
            this.btnCambiar.TabIndex = 2;
            this.btnCambiar.Text = "Cambiar";
            this.btnCambiar.UseVisualStyleBackColor = true;
            this.btnCambiar.Click += new System.EventHandler(this.btnCambiar_Click);
            // 
            // lbFormatoPDF
            // 
            this.lbFormatoPDF.AutoSize = true;
            this.lbFormatoPDF.Location = new System.Drawing.Point(42, 512);
            this.lbFormatoPDF.Name = "lbFormatoPDF";
            this.lbFormatoPDF.Size = new System.Drawing.Size(191, 13);
            this.lbFormatoPDF.TabIndex = 11;
            this.lbFormatoPDF.Text = "Formato de la Nota de Crédito a Cargar";
            this.lbFormatoPDF.Visible = false;
            // 
            // tbDestinoPDF
            // 
            this.tbDestinoPDF.Enabled = false;
            this.tbDestinoPDF.Location = new System.Drawing.Point(43, 527);
            this.tbDestinoPDF.Name = "tbDestinoPDF";
            this.tbDestinoPDF.Size = new System.Drawing.Size(315, 20);
            this.tbDestinoPDF.TabIndex = 10;
            this.tbDestinoPDF.Visible = false;
            // 
            // pbCargarPDF
            // 
            this.pbCargarPDF.Location = new System.Drawing.Point(359, 525);
            this.pbCargarPDF.Name = "pbCargarPDF";
            this.pbCargarPDF.Size = new System.Drawing.Size(58, 23);
            this.pbCargarPDF.TabIndex = 9;
            this.pbCargarPDF.Text = "Cargar";
            this.pbCargarPDF.UseVisualStyleBackColor = true;
            this.pbCargarPDF.Visible = false;
            this.pbCargarPDF.Click += new System.EventHandler(this.pbCargarPDF_Click);
            // 
            // Nota
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSlateGray;
            this.ClientSize = new System.Drawing.Size(453, 600);
            this.Controls.Add(this.lbFormatoPDF);
            this.Controls.Add(this.tbDestinoPDF);
            this.Controls.Add(this.pbCargarPDF);
            this.Controls.Add(this.btnCambiar);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.gbNota);
            this.MaximizeBox = false;
            this.Name = "Nota";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Captura de Nota de Crédito";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Nota_FormClosing);
            this.Load += new System.EventHandler(this.Nota_Load);
            this.gbNota.ResumeLayout(false);
            this.gbNota.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mtbCosto;
        private System.Windows.Forms.MaskedTextBox mtbPrecio;
        private System.Windows.Forms.MaskedTextBox mtbMargen;
        private System.Windows.Forms.Label lblSubTot;
        private System.Windows.Forms.Label lblIva;
        private System.Windows.Forms.MaskedTextBox mtbTotal;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.MaskedTextBox mtbSubTotal;
        private System.Windows.Forms.Label lblCosto;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Label LblNota;
        private System.Windows.Forms.MaskedTextBox mtbIva;
        private System.Windows.Forms.Label lblMargen;
        private System.Windows.Forms.GroupBox gbNota;
        private System.Windows.Forms.TextBox mtbNotaCred;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.TextBox tbFchCal;
        private System.Windows.Forms.TextBox tbFchApl;
        private System.Windows.Forms.TextBox tbProvee;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnCambiar;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.MaskedTextBox mtbPorc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbFinal;
        private System.Windows.Forms.Label lbNuevo;
        private System.Windows.Forms.Label lbActual;
        private System.Windows.Forms.MaskedTextBox mtbMargenFinal;
        private System.Windows.Forms.MaskedTextBox mtbPrecioFinal;
        private System.Windows.Forms.MaskedTextBox mtbCostoFinal;
        private System.Windows.Forms.MaskedTextBox mtbMargenNuevo;
        private System.Windows.Forms.MaskedTextBox mtbPrecioNuevo;
        private System.Windows.Forms.MaskedTextBox mtbCostoNuevo;
        private System.Windows.Forms.Label lbNotaPDF;
        private System.Windows.Forms.TextBox tbFuentePDF;
        private System.Windows.Forms.Button pbExaminarPDF;
        private System.Windows.Forms.Label lbFormatoPDF;
        private System.Windows.Forms.TextBox tbDestinoPDF;
        private System.Windows.Forms.Button pbCargarPDF;
        private System.Windows.Forms.Label lbTablaDeAccActual;
        private System.Windows.Forms.MaskedTextBox mtbNOTTAB;
        private System.Windows.Forms.Label lbTablaDeAccion;
        private System.Windows.Forms.MaskedTextBox mtbNOTONH;
        private System.Windows.Forms.Label lbOnHand;
        private System.Windows.Forms.MaskedTextBox mtbNOTIMF2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.MaskedTextBox mtbNOTIDC2;
        private System.Windows.Forms.Label lbImpDiferenciaCosto;
        private System.Windows.Forms.MaskedTextBox mtbNOTDCF2;
        private System.Windows.Forms.Label lbDifCostoFinal;
        private System.Windows.Forms.MaskedTextBox mtbNOTIMP1;
        private System.Windows.Forms.Label lbImpOnHand;
        private System.Windows.Forms.MaskedTextBox mtbNOTPZA1;
        private System.Windows.Forms.Label lbPzaOnHand;
        private System.Windows.Forms.MaskedTextBox mtbNOTCSTD;
        private System.Windows.Forms.Label lbDifCosto;
        private System.Windows.Forms.Label lbTablaDeAccFinal;
        private System.Windows.Forms.MaskedTextBox mtbNOTTABF;
        private System.Windows.Forms.Label lbTablaDeAccNueva;
        private System.Windows.Forms.MaskedTextBox mtbNOTTAB1;
    }
}