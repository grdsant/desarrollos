﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Bonificaciones
{
    public partial class CargaPDF : Form
    {
        #region Conexion
        public static string srv_Doctos = ConfigurationManager.ConnectionStrings["srvDoctos"].ToString();
        #endregion

        string ParUser;
        public CargaPDF()
        {
            InitializeComponent();
        }

        private void pbExaminarPDF_Click(object sender, EventArgs e)
        {
            OpenFileDialog buscar = new OpenFileDialog();
            if (buscar.ShowDialog() == DialogResult.OK)
            {
                tbFuentePDF.Text = buscar.FileName;
                string[] path = buscar.FileName.Split('\\');
                int contador = path.Count();
                string nombre = path[contador -1];

                string[] nomExt = nombre.Split('.');
                contador = nomExt.Count();
                string nomSinExt = nomExt[0];
                string ext = nomExt[contador -1 ];

                if (ext == "PDF" || ext == "pdf")
                {
                  string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
                  string newDest = lbNoNotaCredito.Text + "_" +
                                   lbNombrePrv.Text     + "_" +
                                   lbDescEstilo.Text    + "_" +
                                   Hoy                  +
                                   ".PDF";

                  string pathDest = @"\\" + srv_Doctos + @"\Notas_Credito_Proveedor\"; 

                  //string pathDest = @"\\172.16.50.25\Notas_Credito_Proveedor\";

                  tbDestinoPDF.Text = pathDest + newDest; 
                }
                else
                {
                    MessageBox.Show("Este documento no es tipo PDF");
                    tbFuentePDF.Text = "";
                }
            }
        }

        private void CargaPDF_Load(object sender, EventArgs e)
        {
            lbNoNotaCredito.Text = MmsWin.Front.Utilerias.VarTem.tmpNota;
            lbNombrePrv.Text = MmsWin.Front.Utilerias.VarTem.tmpPrv;
            lbDescEstilo.Text = MmsWin.Front.Utilerias.VarTem.tmpSty;

            // Seguridad...
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("Bonificaciones", "CargaPDF", ParUser);
        }
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
        }

        private void pbCargarPDF_Click(object sender, EventArgs e)
        {

            string comando = "copy " + '\u0022' + tbFuentePDF.Text + '\u0022' + ' ' + tbDestinoPDF.Text;


            string message = "Esta seguro de cargar esta Nota de Crédito";
            string caption = "Confirmación";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                MmsWin.Front.Utilerias.VarTem.tmpDestNcPDF = tbDestinoPDF.Text;

                String rutaPdf = MmsWin.Front.Utilerias.VarTem.tmpRutaPdf;
                if (rutaPdf != "")
                {
                    string borra = "del " + rutaPdf;
                    System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + borra);
                    procStartInfo.RedirectStandardOutput = true;
                    procStartInfo.UseShellExecute = false;
                    procStartInfo.CreateNoWindow = false;
                    System.Diagnostics.Process proc = new System.Diagnostics.Process();
                    proc.StartInfo = procStartInfo;
                    proc.Start();
                }
                // Copia Archivo PDF
                ExecuteCommand(comando);
                
                this.Close();

            }

        }

        static void ExecuteCommand(string _Command)
        {
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            procStartInfo.CreateNoWindow = false;
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            string result = proc.StandardOutput.ReadToEnd();
            if (result == "        1 archivo(s) copiado(s).\r\n")
            {
                string ParNota = MmsWin.Front.Utilerias.VarTem.tmpNota;
                string ParPrv = MmsWin.Front.Utilerias.VarTem.tmpPrv;
                string ParSty = MmsWin.Front.Utilerias.VarTem.tmpSty;
                string ParDest = MmsWin.Front.Utilerias.VarTem.tmpDestNcPDF;
                string ParTpo = "1";
                string ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                string ParFchBon = MmsWin.Front.Utilerias.VarTem.tmpFchBon;
                string ParFchCal = MmsWin.Front.Utilerias.VarTem.tmpFchRev;

                MmsWin.Front.Utilerias.VarTem.tmpRutaPdf = ParDest;
                MmsWin.Negocio.Bonificaciones.Doctos.GetInstance().EjecutaCargaPDF(ParFchBon, ParFchCal, ParNota, ParPrv, ParSty, ParDest, ParTpo, ParUser);

                MessageBox.Show(result);
            }
            else
            {
                MessageBox.Show("No se guardó el documento...Reportar a sistemas.");
            }
        }

        private void CargaPDF_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("Bonificaciones", "CargaPDF", ParUser);
            }
        }
        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }
    }
}
