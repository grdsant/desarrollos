﻿namespace MmsWin.Front.Bonificaciones
{
    partial class Calificaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Calificaciones));
            this.dgvCalificaciones = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.FotoTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.capturaTlSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.reprogramacionTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.devolverToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tbProveedor = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.gbRango = new System.Windows.Forms.GroupBox();
            this.mcCal02 = new System.Windows.Forms.MonthCalendar();
            this.mcCal01 = new System.Windows.Forms.MonthCalendar();
            this.lblHasta = new System.Windows.Forms.Label();
            this.tbHasta = new System.Windows.Forms.TextBox();
            this.lblDesde = new System.Windows.Forms.Label();
            this.tbDesde = new System.Windows.Forms.TextBox();
            this.rbPendientes = new System.Windows.Forms.RadioButton();
            this.rbBonificar_Devolver = new System.Windows.Forms.RadioButton();
            this.pgbProg = new System.Windows.Forms.ProgressBar();
            this.cbCompradores = new System.Windows.Forms.ComboBox();
            this.gbComprador = new System.Windows.Forms.GroupBox();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.gbMarca = new System.Windows.Forms.GroupBox();
            this.pbExcel = new System.Windows.Forms.PictureBox();
            this.mcC1 = new System.Windows.Forms.MonthCalendar();
            this.mcC2 = new System.Windows.Forms.MonthCalendar();
            this.Relleno = new System.Windows.Forms.TextBox();
            this.rbAplicados = new System.Windows.Forms.RadioButton();
            this.rbTodos = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pbBuscar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCalificaciones)).BeginInit();
            this.cmMenu.SuspendLayout();
            this.gbRango.SuspendLayout();
            this.gbMarca.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbExcel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBuscar)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvCalificaciones
            // 
            this.dgvCalificaciones.AllowUserToAddRows = false;
            this.dgvCalificaciones.AllowUserToDeleteRows = false;
            this.dgvCalificaciones.AllowUserToOrderColumns = true;
            this.dgvCalificaciones.BackgroundColor = System.Drawing.SystemColors.ControlLight;
            this.dgvCalificaciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCalificaciones.ContextMenuStrip = this.cmMenu;
            this.dgvCalificaciones.GridColor = System.Drawing.Color.LightGray;
            this.dgvCalificaciones.Location = new System.Drawing.Point(3, 80);
            this.dgvCalificaciones.Name = "dgvCalificaciones";
            this.dgvCalificaciones.ReadOnly = true;
            this.dgvCalificaciones.Size = new System.Drawing.Size(1013, 342);
            this.dgvCalificaciones.TabIndex = 0;
            this.dgvCalificaciones.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCalificaciones_CellDoubleClick);
            this.dgvCalificaciones.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvCalificaciones_CellMouseDown);
            this.dgvCalificaciones.SelectionChanged += new System.EventHandler(this.dgvCalificaciones_SelectionChanged);
            this.dgvCalificaciones.Sorted += new System.EventHandler(this.dgvCalificaciones_Sorted);
            this.dgvCalificaciones.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvCalificaciones_KeyUp);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FotoTSMI,
            this.capturaTlSMI,
            this.reprogramacionTSMI,
            this.devolverToolStripMenuItem});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(163, 92);
            // 
            // FotoTSMI
            // 
            this.FotoTSMI.Name = "FotoTSMI";
            this.FotoTSMI.Size = new System.Drawing.Size(162, 22);
            this.FotoTSMI.Text = "Foto";
            this.FotoTSMI.Click += new System.EventHandler(this.fotoToolStripMenuItem_Click);
            // 
            // capturaTlSMI
            // 
            this.capturaTlSMI.Name = "capturaTlSMI";
            this.capturaTlSMI.Size = new System.Drawing.Size(162, 22);
            this.capturaTlSMI.Text = "&Nota de Crédito";
            this.capturaTlSMI.Click += new System.EventHandler(this.capturaTlSMI_Click);
            // 
            // reprogramacionTSMI
            // 
            this.reprogramacionTSMI.Name = "reprogramacionTSMI";
            this.reprogramacionTSMI.Size = new System.Drawing.Size(162, 22);
            this.reprogramacionTSMI.Text = "&Reprogramacion";
            this.reprogramacionTSMI.Click += new System.EventHandler(this.reprogramacionTSMI_Click);
            // 
            // devolverToolStripMenuItem
            // 
            this.devolverToolStripMenuItem.Name = "devolverToolStripMenuItem";
            this.devolverToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.devolverToolStripMenuItem.Text = "Devolver";
            this.devolverToolStripMenuItem.Click += new System.EventHandler(this.devolverToolStripMenuItem_Click);
            // 
            // tbProveedor
            // 
            this.tbProveedor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbProveedor.Location = new System.Drawing.Point(124, 60);
            this.tbProveedor.Name = "tbProveedor";
            this.tbProveedor.Size = new System.Drawing.Size(51, 20);
            this.tbProveedor.TabIndex = 1;
            this.tbProveedor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbProveedor_KeyPress);
            // 
            // tbNombre
            // 
            this.tbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNombre.Location = new System.Drawing.Point(175, 60);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(250, 20);
            this.tbNombre.TabIndex = 2;
            this.tbNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNombre_KeyPress);
            // 
            // tbEstilo
            // 
            this.tbEstilo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbEstilo.Location = new System.Drawing.Point(425, 60);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(100, 20);
            this.tbEstilo.TabIndex = 3;
            this.tbEstilo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbEstilo_KeyPress);
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDescripcion.Location = new System.Drawing.Point(525, 60);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(250, 20);
            this.tbDescripcion.TabIndex = 4;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress);
            // 
            // gbRango
            // 
            this.gbRango.Controls.Add(this.mcCal02);
            this.gbRango.Controls.Add(this.mcCal01);
            this.gbRango.Controls.Add(this.lblHasta);
            this.gbRango.Controls.Add(this.tbHasta);
            this.gbRango.Controls.Add(this.lblDesde);
            this.gbRango.Controls.Add(this.tbDesde);
            this.gbRango.Location = new System.Drawing.Point(422, 1);
            this.gbRango.Name = "gbRango";
            this.gbRango.Size = new System.Drawing.Size(261, 53);
            this.gbRango.TabIndex = 5;
            this.gbRango.TabStop = false;
            this.gbRango.Text = "Rango de Fechas";
            // 
            // mcCal02
            // 
            this.mcCal02.BackColor = System.Drawing.Color.Gray;
            this.mcCal02.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.mcCal02.Location = new System.Drawing.Point(203, 97);
            this.mcCal02.Name = "mcCal02";
            this.mcCal02.TabIndex = 18;
            this.mcCal02.Visible = false;
            // 
            // mcCal01
            // 
            this.mcCal01.BackColor = System.Drawing.Color.Gray;
            this.mcCal01.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.mcCal01.Location = new System.Drawing.Point(18, 97);
            this.mcCal01.Name = "mcCal01";
            this.mcCal01.TabIndex = 17;
            this.mcCal01.Visible = false;
            // 
            // lblHasta
            // 
            this.lblHasta.AutoSize = true;
            this.lblHasta.Location = new System.Drawing.Point(137, 25);
            this.lblHasta.Name = "lblHasta";
            this.lblHasta.Size = new System.Drawing.Size(35, 13);
            this.lblHasta.TabIndex = 7;
            this.lblHasta.Text = "Hasta";
            // 
            // tbHasta
            // 
            this.tbHasta.Location = new System.Drawing.Point(178, 23);
            this.tbHasta.Name = "tbHasta";
            this.tbHasta.ReadOnly = true;
            this.tbHasta.Size = new System.Drawing.Size(71, 20);
            this.tbHasta.TabIndex = 6;
            this.tbHasta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbHasta.Click += new System.EventHandler(this.tbHasta_Click);
            // 
            // lblDesde
            // 
            this.lblDesde.AutoSize = true;
            this.lblDesde.Location = new System.Drawing.Point(5, 25);
            this.lblDesde.Name = "lblDesde";
            this.lblDesde.Size = new System.Drawing.Size(38, 13);
            this.lblDesde.TabIndex = 6;
            this.lblDesde.Text = "Desde";
            // 
            // tbDesde
            // 
            this.tbDesde.Location = new System.Drawing.Point(49, 23);
            this.tbDesde.Name = "tbDesde";
            this.tbDesde.ReadOnly = true;
            this.tbDesde.Size = new System.Drawing.Size(71, 20);
            this.tbDesde.TabIndex = 6;
            this.tbDesde.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbDesde.Click += new System.EventHandler(this.tbDesde_Click);
            // 
            // rbPendientes
            // 
            this.rbPendientes.AutoSize = true;
            this.rbPendientes.BackColor = System.Drawing.Color.LightSlateGray;
            this.rbPendientes.ForeColor = System.Drawing.Color.Yellow;
            this.rbPendientes.Location = new System.Drawing.Point(795, 5);
            this.rbPendientes.Name = "rbPendientes";
            this.rbPendientes.Size = new System.Drawing.Size(78, 17);
            this.rbPendientes.TabIndex = 6;
            this.rbPendientes.TabStop = true;
            this.rbPendientes.Text = "Pendientes";
            this.rbPendientes.UseVisualStyleBackColor = false;
            this.rbPendientes.Click += new System.EventHandler(this.rbPendientes_Click);
            // 
            // rbBonificar_Devolver
            // 
            this.rbBonificar_Devolver.AutoSize = true;
            this.rbBonificar_Devolver.BackColor = System.Drawing.Color.LightSlateGray;
            this.rbBonificar_Devolver.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.rbBonificar_Devolver.Location = new System.Drawing.Point(795, 23);
            this.rbBonificar_Devolver.Name = "rbBonificar_Devolver";
            this.rbBonificar_Devolver.Size = new System.Drawing.Size(114, 17);
            this.rbBonificar_Devolver.TabIndex = 7;
            this.rbBonificar_Devolver.TabStop = true;
            this.rbBonificar_Devolver.Text = "Bonificar/Devolver";
            this.rbBonificar_Devolver.UseVisualStyleBackColor = false;
            this.rbBonificar_Devolver.Click += new System.EventHandler(this.rbBonificar_Devolver_Click);
            // 
            // pgbProg
            // 
            this.pgbProg.Location = new System.Drawing.Point(3, 83);
            this.pgbProg.Name = "pgbProg";
            this.pgbProg.Size = new System.Drawing.Size(1000, 11);
            this.pgbProg.TabIndex = 13;
            this.pgbProg.Visible = false;
            // 
            // cbCompradores
            // 
            this.cbCompradores.FormattingEnabled = true;
            this.cbCompradores.Location = new System.Drawing.Point(254, 22);
            this.cbCompradores.Name = "cbCompradores";
            this.cbCompradores.Size = new System.Drawing.Size(148, 21);
            this.cbCompradores.TabIndex = 18;
            this.cbCompradores.SelectedValueChanged += new System.EventHandler(this.cbCompradores_SelectedValueChanged);
            // 
            // gbComprador
            // 
            this.gbComprador.Location = new System.Drawing.Point(242, 2);
            this.gbComprador.Name = "gbComprador";
            this.gbComprador.Size = new System.Drawing.Size(174, 50);
            this.gbComprador.TabIndex = 19;
            this.gbComprador.TabStop = false;
            this.gbComprador.Text = "Comprador";
            // 
            // cbMarca
            // 
            this.cbMarca.Location = new System.Drawing.Point(10, 22);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(92, 21);
            this.cbMarca.TabIndex = 2;
            this.cbMarca.SelectedValueChanged += new System.EventHandler(this.cbMarca_SelectedValueChanged);
            // 
            // gbMarca
            // 
            this.gbMarca.Controls.Add(this.cbMarca);
            this.gbMarca.Location = new System.Drawing.Point(126, 2);
            this.gbMarca.Name = "gbMarca";
            this.gbMarca.Size = new System.Drawing.Size(113, 50);
            this.gbMarca.TabIndex = 17;
            this.gbMarca.TabStop = false;
            this.gbMarca.Text = "Marca";
            // 
            // pbExcel
            // 
            this.pbExcel.Image = ((System.Drawing.Image)(resources.GetObject("pbExcel.Image")));
            this.pbExcel.Location = new System.Drawing.Point(0, 1);
            this.pbExcel.Name = "pbExcel";
            this.pbExcel.Size = new System.Drawing.Size(60, 47);
            this.pbExcel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbExcel.TabIndex = 16;
            this.pbExcel.TabStop = false;
            this.pbExcel.Click += new System.EventHandler(this.pbExcel_Click);
            // 
            // mcC1
            // 
            this.mcC1.BackColor = System.Drawing.Color.Gray;
            this.mcC1.ForeColor = System.Drawing.Color.Black;
            this.mcC1.Location = new System.Drawing.Point(317, 92);
            this.mcC1.Name = "mcC1";
            this.mcC1.TabIndex = 20;
            this.mcC1.Visible = false;
            this.mcC1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcC1_DateSelected_1);
            this.mcC1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcC1_KeyUp);
            this.mcC1.Leave += new System.EventHandler(this.mcC1_Leave);
            // 
            // mcC2
            // 
            this.mcC2.BackColor = System.Drawing.Color.Gray;
            this.mcC2.ForeColor = System.Drawing.Color.Black;
            this.mcC2.Location = new System.Drawing.Point(599, 92);
            this.mcC2.Name = "mcC2";
            this.mcC2.TabIndex = 21;
            this.mcC2.Visible = false;
            this.mcC2.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcC2_DateSelected_1);
            this.mcC2.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcC2_KeyUp);
            this.mcC2.Leave += new System.EventHandler(this.mcC2_Leave);
            // 
            // Relleno
            // 
            this.Relleno.Enabled = false;
            this.Relleno.Location = new System.Drawing.Point(3, 60);
            this.Relleno.Name = "Relleno";
            this.Relleno.Size = new System.Drawing.Size(121, 20);
            this.Relleno.TabIndex = 22;
            // 
            // rbAplicados
            // 
            this.rbAplicados.AutoSize = true;
            this.rbAplicados.BackColor = System.Drawing.Color.LightSlateGray;
            this.rbAplicados.ForeColor = System.Drawing.Color.Green;
            this.rbAplicados.Location = new System.Drawing.Point(795, 41);
            this.rbAplicados.Name = "rbAplicados";
            this.rbAplicados.Size = new System.Drawing.Size(77, 17);
            this.rbAplicados.TabIndex = 23;
            this.rbAplicados.TabStop = true;
            this.rbAplicados.Text = "Aplicados  ";
            this.rbAplicados.UseVisualStyleBackColor = false;
            this.rbAplicados.Click += new System.EventHandler(this.rbAplicados_Click);
            // 
            // rbTodos
            // 
            this.rbTodos.AutoSize = true;
            this.rbTodos.BackColor = System.Drawing.Color.LightSlateGray;
            this.rbTodos.Location = new System.Drawing.Point(795, 59);
            this.rbTodos.Name = "rbTodos";
            this.rbTodos.Size = new System.Drawing.Size(76, 17);
            this.rbTodos.TabIndex = 24;
            this.rbTodos.TabStop = true;
            this.rbTodos.Text = "Todos       ";
            this.rbTodos.UseVisualStyleBackColor = false;
            this.rbTodos.Click += new System.EventHandler(this.rbTodos_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(786, -5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(125, 85);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            // 
            // pbBuscar
            // 
            this.pbBuscar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbBuscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pbBuscar.Cursor = System.Windows.Forms.Cursors.Default;
            this.pbBuscar.Image = ((System.Drawing.Image)(resources.GetObject("pbBuscar.Image")));
            this.pbBuscar.Location = new System.Drawing.Point(962, 1);
            this.pbBuscar.Name = "pbBuscar";
            this.pbBuscar.Size = new System.Drawing.Size(56, 50);
            this.pbBuscar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbBuscar.TabIndex = 26;
            this.pbBuscar.TabStop = false;
            this.pbBuscar.Click += new System.EventHandler(this.pbBuscar_Click);
            // 
            // Calificaciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSlateGray;
            this.ClientSize = new System.Drawing.Size(1016, 425);
            this.ContextMenuStrip = this.cmMenu;
            this.Controls.Add(this.pbBuscar);
            this.Controls.Add(this.rbTodos);
            this.Controls.Add(this.rbAplicados);
            this.Controls.Add(this.Relleno);
            this.Controls.Add(this.mcC2);
            this.Controls.Add(this.mcC1);
            this.Controls.Add(this.cbCompradores);
            this.Controls.Add(this.gbComprador);
            this.Controls.Add(this.gbMarca);
            this.Controls.Add(this.pbExcel);
            this.Controls.Add(this.pgbProg);
            this.Controls.Add(this.rbBonificar_Devolver);
            this.Controls.Add(this.rbPendientes);
            this.Controls.Add(this.gbRango);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.tbEstilo);
            this.Controls.Add(this.tbNombre);
            this.Controls.Add(this.tbProveedor);
            this.Controls.Add(this.dgvCalificaciones);
            this.Controls.Add(this.groupBox1);
            this.Name = "Calificaciones";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calificaciones / Seguimiento";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Calificaciones_FormClosing);
            this.Load += new System.EventHandler(this.Calificaciones_Load);
            this.Resize += new System.EventHandler(this.Calificaciones_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCalificaciones)).EndInit();
            this.cmMenu.ResumeLayout(false);
            this.gbRango.ResumeLayout(false);
            this.gbRango.PerformLayout();
            this.gbMarca.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbExcel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBuscar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvCalificaciones;
        private System.Windows.Forms.TextBox tbProveedor;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.GroupBox gbRango;
        private System.Windows.Forms.Label lblHasta;
        private System.Windows.Forms.TextBox tbHasta;
        private System.Windows.Forms.Label lblDesde;
        private System.Windows.Forms.TextBox tbDesde;
        private System.Windows.Forms.RadioButton rbPendientes;
        private System.Windows.Forms.RadioButton rbBonificar_Devolver;
        private System.Windows.Forms.MonthCalendar mcCal02;
        private System.Windows.Forms.MonthCalendar mcCal01;
        private System.Windows.Forms.ProgressBar pgbProg;
        private System.Windows.Forms.ComboBox cbCompradores;
        private System.Windows.Forms.GroupBox gbComprador;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.GroupBox gbMarca;
        private System.Windows.Forms.PictureBox pbExcel;
        private System.Windows.Forms.MonthCalendar mcC1;
        private System.Windows.Forms.MonthCalendar mcC2;
        private System.Windows.Forms.TextBox Relleno;
        private System.Windows.Forms.RadioButton rbAplicados;
        private System.Windows.Forms.RadioButton rbTodos;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem FotoTSMI;
        private System.Windows.Forms.ToolStripMenuItem capturaTlSMI;
        private System.Windows.Forms.ToolStripMenuItem reprogramacionTSMI;
        private System.Windows.Forms.PictureBox pbBuscar;
        private System.Windows.Forms.ToolStripMenuItem devolverToolStripMenuItem;
    }
}