﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Threading;
using MmsWin.Front.Utilerias;
using System.Reflection;
using MmsWin.Front.Convenio;


namespace MmsWin.Front.Bonificaciones
{
    public partial class Calificaciones : Form
    {

        int nr;
        bool ind; 
        string FechaCal;
        string FechaFmt;
        bool Carga;
        String ParUser;
        String marca;
        String comprador;
        String FchDe;
        String FchHas;
        long   FchDeN;
        long   FchHasN;
        String ParPendiente;

        public static string ParFchRevision;
        public static string ParFchInicial;
        public static string ParProveedor;
        public static string PartbNombre;
        public static string PartbEstilo;
        public static string ParDescripcion;

        int dgvOffset;
        int pgbOffset;
        int dgvOffset2;

        public Calificaciones()
        {
            InitializeComponent();

            dgvOffset = this.Width - dgvCalificaciones.Width;
            dgvOffset2 = this.Height - dgvCalificaciones.Height;
            pgbOffset = this.Width - pgbProg.Width;
        }

        private void Calificaciones_Load(object sender, EventArgs e)
        {
            ToolTip Tooltip1 = new ToolTip();
            Tooltip1.SetToolTip(this.pbBuscar, "Historico de Reprogramacion"); 

            Carga = false;
            marca = "999";
            comprador = "999";

            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            FchDe = "10/10/2000";
            FchHas = "10/10/2000";
            tbDesde.Text = FchDe;
            tbHasta.Text = FchHas;

            try
            {

            rbBonificar_Devolver.PerformClick();

            System.Data.DataTable tbFechaInicial = null;
            tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();

            foreach (DataRow row in tbFechaInicial.Rows)
            {
             tbDesde.Text = row["DSPFCH"].ToString();
             FechaCal = tbDesde.Text;
             FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
             tbDesde.Text = FechaFmt.ToString();
             tbHasta.Text = FechaFmt.ToString();
            }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            // Carga de Marca
            try
            {
                BindMarca();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            // Carga de Compradores
            try
            {
                BindCompradores();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            comprador = MmsWin.Front.Utilerias.VarTem.tmpUSRCOM;
            cbCompradores.SelectedValue = comprador;
            marca = MmsWin.Front.Utilerias.VarTem.tmpUSRMAR;
            cbMarca.SelectedValue = marca;
            ParPendiente = "1";

            // Carga de Datos
            try
            {
                Carga = true;
                BindCalificaciones();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            // Seguridad...
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("Bonificaciones", "Calificaciones", ParUser);
        }

        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }

        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvCalificaciones.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvCalificaciones.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenu.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenu.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        protected void BindCalificaciones()
        {
            if (Carga == true)
            {
                nr = 0;
                System.Data.DataTable Calificaciones = null;
                try
                {
                    this.Cursor = Cursors.WaitCursor;
                    // 
                    ParPendiente = "0";
                    if (rbPendientes.Checked) {ParPendiente = "4";}
                    if (rbBonificar_Devolver.Checked) { ParPendiente = "3"; }
                    if (rbAplicados.Checked) { ParPendiente = "2"; }
                    if (rbTodos.Checked) { ParPendiente = "1"; }

                    ParProveedor = tbProveedor.Text;
                    PartbNombre = tbNombre.Text;
                    PartbEstilo = tbEstilo.Text;
                    ParDescripcion = tbDescripcion.Text;

                    Calificaciones = MmsWin.Negocio.Bonificaciones.Calificaciones.GetInstance().ObtenCalificaciones1(marca, comprador, FchDe, FchHas, ParPendiente, ParProveedor, PartbNombre, PartbEstilo, ParDescripcion, ParUser);

                    if (Calificaciones.Rows.Count > 0)
                    {
                        dgvCalificaciones.DataSource = Calificaciones;
                        nr = dgvCalificaciones.RowCount;
                        this.Text = "Historico de Calificaciones / " + " " + (nr).ToString() + " Registro(s)";

                        //   int nc = dgvConvenio.Columns.Count;
                        SetFontAndColors();
                        rowStyle();
                        SetDoubleBuffered(dgvCalificaciones);

                        // Seguridad...
                        ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        Seguridad("Bonificaciones", "Calificaciones", ParUser);
                    }
                    this.Cursor = Cursors.Default;
                }

                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }
        protected void BindMarca()
        {
            try
            {
                cbMarca.DataSource = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();
                cbMarca.DisplayMember = "Value";
                cbMarca.ValueMember = "Key";
                marca = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void BindCompradores()
        {
            try
            {
                cbCompradores.DataSource = MmsWin.Negocio.Catalogos.Compradores.GetInstance().ObtenCompradors().ToList();
                cbCompradores.DisplayMember = "Value";
                cbCompradores.ValueMember = "Key";
                comprador = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        } 

        private void SetFontAndColors()
        {
            this.dgvCalificaciones.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvCalificaciones.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvCalificaciones.EnableHeadersVisualStyles = false;
            this.dgvCalificaciones.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvCalificaciones.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvCalificaciones.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvCalificaciones.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvCalificaciones.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvCalificaciones.Columns[3].Frozen = true;

            dgvCalificaciones.Columns[0].HeaderText = "Fecha Revision";
            dgvCalificaciones.Columns[1].HeaderText = "Proveedor";
            dgvCalificaciones.Columns[2].HeaderText = "Nombre";
            dgvCalificaciones.Columns[3].HeaderText = "Estilo";
            dgvCalificaciones.Columns[4].HeaderText = "Descripcion";
            dgvCalificaciones.Columns[5].HeaderText = "Comprador";
            dgvCalificaciones.Columns[6].HeaderText = "No. Califica";
            dgvCalificaciones.Columns[7].HeaderText = "Fecha Compra";
            dgvCalificaciones.Columns[8].HeaderText = "Fecha Revision";
            dgvCalificaciones.Columns[9].HeaderText = "Piezas";
            dgvCalificaciones.Columns[10].HeaderText = "Venta";
            dgvCalificaciones.Columns[11].HeaderText = "OnHand";
            dgvCalificaciones.Columns[12].HeaderText = "% Ventas";
            dgvCalificaciones.Columns[13].HeaderText = "On Order";
            dgvCalificaciones.Columns[14].HeaderText = "Calificacion";
            dgvCalificaciones.Columns[15].HeaderText = "Calificacion Original";
            dgvCalificaciones.Columns[16].HeaderText = "Tabla de Accion";
            dgvCalificaciones.Columns[17].HeaderText = "Compras Obs";
            dgvCalificaciones.Columns[18].HeaderText = "Nota Credito";
            dgvCalificaciones.Columns[19].HeaderText = "Sub_Tot";
            dgvCalificaciones.Columns[20].HeaderText = "Iva";
            dgvCalificaciones.Columns[21].HeaderText = "Total";
            dgvCalificaciones.Columns[22].HeaderText = "% Bonificacion";
            dgvCalificaciones.Columns[23].HeaderText = "Costo Actual";
            dgvCalificaciones.Columns[24].HeaderText = "Precio Actual";
            dgvCalificaciones.Columns[25].HeaderText = "Margen Actual";
            dgvCalificaciones.Columns[26].HeaderText = "Costo Nuevo";
            dgvCalificaciones.Columns[27].HeaderText = "Precio Nuevo";
            dgvCalificaciones.Columns[28].HeaderText = "Margen Nuevo";
            dgvCalificaciones.Columns[29].HeaderText = "Costo Final";
            dgvCalificaciones.Columns[30].HeaderText = "Precio Final";
            dgvCalificaciones.Columns[31].HeaderText = "Margen Final";
            dgvCalificaciones.Columns[32].HeaderText = "Comprador";
            dgvCalificaciones.Columns[33].HeaderText = "Tbl Accion2";
            dgvCalificaciones.Columns[34].HeaderText = "Diferecia Consto";
            dgvCalificaciones.Columns[35].HeaderText = "Piezas OnHand";
            dgvCalificaciones.Columns[36].HeaderText = "Importe'OnHand";
            dgvCalificaciones.Columns[37].HeaderText = "Piezas OnHand";
            dgvCalificaciones.Columns[38].HeaderText = "Importe'OnHand ";
            dgvCalificaciones.Columns[39].HeaderText = "Piezas OnHand7";
            dgvCalificaciones.Columns[40].HeaderText = "Precio OnHand7";
            dgvCalificaciones.Columns[41].HeaderText = "Importe Dif7";
            dgvCalificaciones.Columns[42].HeaderText = "Promocion";
            dgvCalificaciones.Columns[43].HeaderText = "Tbl AccionF";
            dgvCalificaciones.Columns[44].HeaderText = "Fecha CXP";
            dgvCalificaciones.Columns[45].HeaderText = "Marca";
            dgvCalificaciones.Columns[46].HeaderText = "Comprador";
            dgvCalificaciones.Columns[47].HeaderText = "Bodega";
            dgvCalificaciones.Columns[48].HeaderText = "Marca ID";

            dgvCalificaciones.Columns[0].Width = 80;
            dgvCalificaciones.Columns[1].Width = 50;
            dgvCalificaciones.Columns[2].Width = 250;
            dgvCalificaciones.Columns[3].Width = 100;
            dgvCalificaciones.Columns[4].Width = 250;
            dgvCalificaciones.Columns[5].Width = 150;
            dgvCalificaciones.Columns[6].Width = 60;
            dgvCalificaciones.Columns[7].Width = 80;
            dgvCalificaciones.Columns[8].Width = 80;
            dgvCalificaciones.Columns[9].Width = 60;
            dgvCalificaciones.Columns[10].Width = 60;
            dgvCalificaciones.Columns[11].Width = 80;
            dgvCalificaciones.Columns[12].Width = 80;
            dgvCalificaciones.Columns[13].Width = 80;
            dgvCalificaciones.Columns[14].Width = 80;
            dgvCalificaciones.Columns[15].Width = 80;
            dgvCalificaciones.Columns[16].Width = 80;
            dgvCalificaciones.Columns[17].Width = 80;
            dgvCalificaciones.Columns[18].Width = 80;
            dgvCalificaciones.Columns[19].Width = 80;
            dgvCalificaciones.Columns[20].Width = 80;
            dgvCalificaciones.Columns[21].Width = 80;
            dgvCalificaciones.Columns[22].Width = 80;
            dgvCalificaciones.Columns[23].Width = 80;
            dgvCalificaciones.Columns[24].Width = 80;
            dgvCalificaciones.Columns[25].Width = 80;
            dgvCalificaciones.Columns[26].Width = 80;
            dgvCalificaciones.Columns[27].Width = 80;
            dgvCalificaciones.Columns[28].Width = 80;
            dgvCalificaciones.Columns[29].Width = 80;
            dgvCalificaciones.Columns[30].Width = 80;
            dgvCalificaciones.Columns[31].Width = 80;
            dgvCalificaciones.Columns[32].Width = 80;
            dgvCalificaciones.Columns[33].Width = 80;
            dgvCalificaciones.Columns[34].Width = 80;
            dgvCalificaciones.Columns[35].Width = 80;
            dgvCalificaciones.Columns[36].Width = 80;
            dgvCalificaciones.Columns[37].Width = 80;
            dgvCalificaciones.Columns[38].Width = 80;
            dgvCalificaciones.Columns[39].Width = 80;
            dgvCalificaciones.Columns[40].Width = 80;
            dgvCalificaciones.Columns[41].Width = 80;
            dgvCalificaciones.Columns[42].Width = 80;
            dgvCalificaciones.Columns[43].Width = 80;
            dgvCalificaciones.Columns[44].Width = 80;
            dgvCalificaciones.Columns[45].Width = 80;
            dgvCalificaciones.Columns[46].Width = 80;
            dgvCalificaciones.Columns[47].Width = 80;
            dgvCalificaciones.Columns[48].Width = 80;

            dgvCalificaciones.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[6].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[7].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[8].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[9].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[11].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[12].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[13].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[14].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[15].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[16].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[17].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[18].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[19].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[20].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[21].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[22].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[23].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[24].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[25].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[26].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[27].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[28].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[29].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[30].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[31].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[32].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[33].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[34].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[35].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[36].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[37].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[38].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[39].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[40].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[41].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvCalificaciones.Columns[42].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[43].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[44].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[45].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[46].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[47].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvCalificaciones.Columns[48].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;


            dgvCalificaciones.Columns[0].DefaultCellStyle.Format = "20##-##-##";
            dgvCalificaciones.Columns[7].DefaultCellStyle.Format = "20##-##-##";
            dgvCalificaciones.Columns[8].DefaultCellStyle.Format = "20##-##-##";
            dgvCalificaciones.Columns[9].DefaultCellStyle.Format = "#,000";
            dgvCalificaciones.Columns[10].DefaultCellStyle.Format = "#,###,###";
            dgvCalificaciones.Columns[11].DefaultCellStyle.Format = "#,###,###";
            dgvCalificaciones.Columns[12].DefaultCellStyle.Format = "00.00";
            dgvCalificaciones.Columns[13].DefaultCellStyle.Format = "#,###,###";
            dgvCalificaciones.Columns[14].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[15].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[16].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[18].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[19].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[20].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[21].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[22].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[23].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[24].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[25].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[26].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[27].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[28].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[29].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[30].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[32].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[33].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[34].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[35].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[36].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[37].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[38].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[39].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[40].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[41].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[42].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[43].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[44].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[45].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[46].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[47].DefaultCellStyle.Format = "#,###";
            dgvCalificaciones.Columns[48].DefaultCellStyle.Format = "#,###";

            dgvCalificaciones.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[1].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvCalificaciones.Columns[2].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvCalificaciones.Columns[3].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvCalificaciones.Columns[4].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvCalificaciones.Columns[5].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[6].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvCalificaciones.Columns[7].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvCalificaciones.Columns[8].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvCalificaciones.Columns[9].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvCalificaciones.Columns[10].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvCalificaciones.Columns[11].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            dgvCalificaciones.Columns[12].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvCalificaciones.Columns[13].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            dgvCalificaciones.Columns[14].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvCalificaciones.Columns[15].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvCalificaciones.Columns[16].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvCalificaciones.Columns[17].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvCalificaciones.Columns[18].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvCalificaciones.Columns[19].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvCalificaciones.Columns[20].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvCalificaciones.Columns[21].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvCalificaciones.Columns[22].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[23].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvCalificaciones.Columns[24].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvCalificaciones.Columns[25].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvCalificaciones.Columns[26].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[27].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[28].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[29].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvCalificaciones.Columns[30].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvCalificaciones.Columns[31].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvCalificaciones.Columns[32].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[33].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[34].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvCalificaciones.Columns[35].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[36].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[37].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[38].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[39].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[40].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[41].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvCalificaciones.Columns[42].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[43].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[44].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[45].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[46].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[47].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvCalificaciones.Columns[48].HeaderCell.Style.BackColor = Color.LightSalmon;
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvCalificaciones.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvCalificaciones.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }

            foreach (DataGridViewRow row in dgvCalificaciones.Rows)
            {
                // Pagar
                if (Convert.ToString(row.Cells[14].Value) == " P a g a r") { row.Cells[14].Style.BackColor = Color.LightGreen; }
                // 15%
                if (Convert.ToString(row.Cells[14].Value) == " 15%") { row.Cells[14].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(row.Cells[14].Value) == " 20%") { row.Cells[14].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(row.Cells[14].Value) == " 25%") { row.Cells[14].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(row.Cells[14].Value) == " 30%") { row.Cells[14].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(row.Cells[14].Value) == " 35%") { row.Cells[14].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(row.Cells[14].Value) == " 40%") { row.Cells[14].Style.BackColor = Color.LightSalmon; }
                // Dev ó 40%
                if (Convert.ToString(row.Cells[14].Value) == " 40%") { row.Cells[14].Style.BackColor = Color.Red; row.Cells[14].Style.ForeColor = Color.White; }
                // Dev ó 40%
                if (Convert.ToString(row.Cells[14].Value) == " 40%") { row.Cells[14].Style.BackColor = Color.Red; row.Cells[14].Style.ForeColor = Color.White; }
                //50%
                if (Convert.ToString(row.Cells[14].Value) == " 50%") { row.Cells[14].Style.BackColor = Color.Red; row.Cells[14].Style.ForeColor = Color.White; }
                //70%
                if (Convert.ToString(row.Cells[14].Value) == " 70%") { row.Cells[14].Style.BackColor = Color.Red; row.Cells[14].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(row.Cells[14].Value) == " 50%") { row.Cells[14].Style.BackColor = Color.Red; row.Cells[14].Style.ForeColor = Color.White; }
                //Dev ó 50%
                if (Convert.ToString(row.Cells[14].Value) == " 50%") { row.Cells[14].Style.BackColor = Color.Red; row.Cells[14].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(row.Cells[14].Value) == "Devolucion") { row.Cells[14].Style.BackColor = Color.Red; row.Cells[14].Style.ForeColor = Color.White; }

                // Pagar
                if (Convert.ToString(row.Cells[15].Value) == " P a g a r") { row.Cells[15].Style.BackColor = Color.LightGreen; }
                // 15%
                if (Convert.ToString(row.Cells[15].Value) == " 15%") { row.Cells[15].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(row.Cells[15].Value) == " 20%") { row.Cells[15].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(row.Cells[15].Value) == " 25%") { row.Cells[15].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(row.Cells[15].Value) == " 30%") { row.Cells[15].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(row.Cells[15].Value) == " 35%") { row.Cells[15].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(row.Cells[15].Value) == " 40%") { row.Cells[15].Style.BackColor = Color.LightSalmon; }
                // Dev ó 40%
                if (Convert.ToString(row.Cells[15].Value) == " 40%") { row.Cells[15].Style.BackColor = Color.Red; row.Cells[15].Style.ForeColor = Color.White; }
                // Dev ó 40%
                if (Convert.ToString(row.Cells[15].Value) == " 40%") { row.Cells[15].Style.BackColor = Color.Red; row.Cells[15].Style.ForeColor = Color.White; }
                //50%
                if (Convert.ToString(row.Cells[15].Value) == " 50%") { row.Cells[15].Style.BackColor = Color.Red; row.Cells[15].Style.ForeColor = Color.White; }
                //70%
                if (Convert.ToString(row.Cells[15].Value) == " 70%") { row.Cells[15].Style.BackColor = Color.Red; row.Cells[15].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(row.Cells[15].Value) == " 50%") { row.Cells[15].Style.BackColor = Color.Red; row.Cells[15].Style.ForeColor = Color.White; }
                //Dev ó 50%
                if (Convert.ToString(row.Cells[15].Value) == " 50%") { row.Cells[15].Style.BackColor = Color.Red; row.Cells[15].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(row.Cells[15].Value) == "Devolucion") { row.Cells[15].Style.BackColor = Color.Red; row.Cells[15].Style.ForeColor = Color.White; }
            }
        }

        private void Calificaciones_Resize(object sender, EventArgs e)
        {
            dgvCalificaciones.Width = this.Width - dgvOffset;
            dgvCalificaciones.Height = this.Height - dgvOffset2;
            pgbProg.Width = this.Width - pgbOffset;
        }

        private void tbDesde_Click(object sender, EventArgs e)
        {
            mcC1.Visible = true;
            mcC1.Focus();
        }

        private void tbHasta_Click(object sender, EventArgs e)
        {
            mcC2.Visible = true;
            mcC2.Focus();
        }

        private void mcC1_Leave(object sender, EventArgs e)
        {
            mcC1.Visible = false;
        }

        private void mcC2_Leave(object sender, EventArgs e)
        {
            mcC2.Visible = false;
        }

        private void mcC1_DateSelected_1(object sender, DateRangeEventArgs e)
        {
            tbDesde.Text = mcC1.SelectionEnd.ToShortDateString();
            FechaCal = tbDesde.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchDeN = long.Parse(FechaFmt.ToString());
            FchDe  = FechaFmt.ToString();

            mcC1.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbDesde.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    BindCalificaciones();;
                }
            }
        }

        private void mcC2_DateSelected_1(object sender, DateRangeEventArgs e)
        {
            tbHasta.Text = mcC2.SelectionEnd.ToShortDateString();
            FechaCal = tbHasta.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchHasN  = long.Parse(FechaFmt.ToString());
            FchHas   = FechaFmt.ToString();

            mcC2.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbHasta.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    BindCalificaciones();
                }
            }
        }

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            marca = " ";
            ComboBox cmbMarca = (ComboBox)sender;
            marca = cmbMarca.SelectedValue.ToString();

            FechaCal = tbHasta.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchHasN = long.Parse(FechaFmt.ToString());
            FchHas = FechaFmt.ToString();

            FechaCal = tbDesde.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchDeN = long.Parse(FechaFmt.ToString());
            FchDe = FechaFmt.ToString();

            BindCalificaciones();
        }

        private void cbCompradores_SelectedValueChanged(object sender, EventArgs e)
        {
            comprador = " ";
            ComboBox cmbComprador = (ComboBox)sender;
            comprador = cmbComprador.SelectedValue.ToString();

            FechaCal = tbHasta.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchHasN = long.Parse(FechaFmt.ToString());
            FchHas = FechaFmt.ToString();

            FechaCal = tbDesde.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchDeN = long.Parse(FechaFmt.ToString());
            FchDe = FechaFmt.ToString();

            BindCalificaciones();
        }

        private void tbNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                tbDesde.Text = "01/01/2014";
                FechaCal = tbDesde.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindCalificaciones();
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                tbDesde.Text = "01/01/2014";
                FechaCal = tbDesde.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindCalificaciones();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                tbDesde.Text = "01/01/2014";
                FechaCal = tbDesde.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindCalificaciones();
            }
        }

        private void MuestraFoto()
        {
            try
            {
                 Fotos i = new Fotos();
                 i.Show();
            }
            catch { }
            finally { }
        }

        private void dgvCalificaciones_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                var hti = dgvCalificaciones.HitTest(e.X, e.Y);
                int Row = e.RowIndex;
                int Col = e.ColumnIndex;
                
                // Guarda Fecha Revision /Calificacion
                ParFchRevision = this.dgvCalificaciones.CurrentRow.Cells[0].Value.ToString();
                FechaCal = ParFchRevision;
                FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                ParFchRevision = FechaFmt.ToString();
                MmsWin.Front.Utilerias.VarTem.NotaFchRevision = ParFchRevision;
                
                // Guarda Fecha Revision /Calificacion
                MmsWin.Front.Utilerias.VarTem.tmpFchRev = this.dgvCalificaciones.CurrentRow.Cells[0].Value.ToString();

                ParProveedor   = this.dgvCalificaciones.CurrentRow.Cells[1].Value.ToString();
                PartbNombre    = this.dgvCalificaciones.CurrentRow.Cells[2].Value.ToString();
                PartbEstilo    = this.dgvCalificaciones.CurrentRow.Cells[3].Value.ToString();
                ParDescripcion = this.dgvCalificaciones.CurrentRow.Cells[4].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.NotaProveedor = this.dgvCalificaciones.CurrentRow.Cells[1].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.NotaNombre = this.dgvCalificaciones.CurrentRow.Cells[2].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.NotaEstilo = this.dgvCalificaciones.CurrentRow.Cells[3].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.NotaDescripcion = this.dgvCalificaciones.CurrentRow.Cells[4].Value.ToString();

                MmsWin.Front.Utilerias.Fotos.numPrv = this.dgvCalificaciones.CurrentRow.Cells[1].Value.ToString();
                MmsWin.Front.Utilerias.Fotos.numSty = this.dgvCalificaciones.CurrentRow.Cells[3].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.tmpNotCal = this.dgvCalificaciones.CurrentRow.Cells[16].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpCalCalif = this.dgvCalificaciones.CurrentRow.Cells[14].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.ConvMarcaNo = this.dgvCalificaciones.CurrentRow.Cells[48].Value.ToString();

                cmMenu.Visible = true;
            }

        }

        private void fotoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MuestraFoto();
        }

        private void notaDeCreditoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Notas").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La Ventana ya esta abierta...");
                    }
                    else
                    {
                        Notas i = new Notas();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void tbProveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                tbDesde.Text = "01/01/2014";
                FechaCal = tbDesde.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindCalificaciones();
            }
        }

        private void capturaToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void dgvCalificaciones_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F6)
            {

            //    var hti = dgvCalificaciones.HitTest(e.X, e.Y);
            //    int Row = e.RowIndex;
            //    int Col = e.ColumnIndex;

                // Guarda Fecha Revision /Calificacion
                ParFchRevision = this.dgvCalificaciones.CurrentRow.Cells[0].Value.ToString();
                FechaCal = ParFchRevision;
                FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                ParFchRevision = FechaFmt.ToString();

                // Guarda Fecha Revision /Calificacion
                MmsWin.Front.Utilerias.VarTem.tmpFchRev = this.dgvCalificaciones.CurrentRow.Cells[0].Value.ToString();

                ParProveedor = this.dgvCalificaciones.CurrentRow.Cells[1].Value.ToString();
                PartbNombre = this.dgvCalificaciones.CurrentRow.Cells[2].Value.ToString();
                PartbEstilo = this.dgvCalificaciones.CurrentRow.Cells[3].Value.ToString();
                ParDescripcion = this.dgvCalificaciones.CurrentRow.Cells[4].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.NotaProveedor = this.dgvCalificaciones.CurrentRow.Cells[1].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.NotaNombre = this.dgvCalificaciones.CurrentRow.Cells[2].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.NotaEstilo = this.dgvCalificaciones.CurrentRow.Cells[3].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.NotaDescripcion = this.dgvCalificaciones.CurrentRow.Cells[4].Value.ToString();

                MmsWin.Front.Utilerias.Fotos.numPrv = this.dgvCalificaciones.CurrentRow.Cells[1].Value.ToString();
                MmsWin.Front.Utilerias.Fotos.numSty = this.dgvCalificaciones.CurrentRow.Cells[3].Value.ToString();
                MmsWin.Front.Utilerias.Fotos.numSty = this.dgvCalificaciones.CurrentRow.Cells[3].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpNotCal = this.dgvCalificaciones.CurrentRow.Cells[16].Value.ToString();

              //  cmMenu.Visible = true;

                try
                {
                    Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                                  "Nota").SingleOrDefault<Form>();
                    {
                        if (existe != null)
                        {
                            MessageBox.Show("La Ventana ya esta abierta...");
                        }
                        else
                        {
                        string calificaion = MmsWin.Front.Utilerias.VarTem.tmpCalCalif;
                      //  if (calificaion == " P a g a r")
                      //  {
                            MessageBox.Show("No aplica para esta calificacion...");
                      //  }
                      //  else
                      //  {
                            Nota i = new Nota();
                            i.Show();
                      //  }
                        }
                    }
                }
                catch { }
                finally { }
            }

        }

        private void Calificaciones_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("Bonificaciones", "Calificaciones", ParUser);
            }
        }
        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            //
            string NomCol;
            Int32 NoCol = dgvCalificaciones.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvCalificaciones.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      
            //
            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void dgvCalificaciones_Sorted(object sender, EventArgs e)
        {
            SetFontAndColors();
            rowStyle();
        }

        private void reprogramacionTSMI_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Reprog").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana de Reprogramacion ya esta abierta...");
                    }
                    else
                    {
                        ValidaReprog();
                        if (ind == true)
                        {
                      //      string calificaion  = MmsWin.Front.Utilerias.VarTem.tmpCalCalif;
                      //      if (calificaion == " P a g a r") //calificaion == "Devolucion" || calificaion == "Dev o 50%" || calificaion == "Dev ó 50%" ||
                      //      {
                      //          MessageBox.Show("No aplica para esta calificacion...");
                      //      }
                      //      else
                       //     {

                                Reprog i = new Reprog();
                                i.Show();
                       //     }
                        }
                        else
                        {
                            MessageBox.Show("Se debe seleccionar Marca y Comprador ...");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { }
        }

        private void ValidaReprog()
        {
            MmsWin.Front.Utilerias.VarTem.tmpMarca = cbMarca.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpComprador = cbCompradores.SelectedValue.ToString();

            string IndMarca = MmsWin.Front.Utilerias.VarTem.tmpMarca;
            string IndComprador = MmsWin.Front.Utilerias.VarTem.tmpComprador;

            if (IndMarca == "999" | IndComprador == "999" | IndMarca == "" | IndComprador == "")
            {
                ind = false;
            }
            else
            {
                ind = true;
            }
        }

        private void dgvCalificaciones_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                MmsWin.Front.Utilerias.Fotos.numPrv = this.dgvCalificaciones.CurrentRow.Cells[1].Value.ToString();
                MmsWin.Front.Utilerias.Fotos.numSty = this.dgvCalificaciones.CurrentRow.Cells[2].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.tmpPrv = this.dgvCalificaciones.CurrentRow.Cells[1].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpNom = this.dgvCalificaciones.CurrentRow.Cells[2].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpSty = this.dgvCalificaciones.CurrentRow.Cells[3].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpDes = this.dgvCalificaciones.CurrentRow.Cells[4].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpCompDesc = this.dgvCalificaciones.CurrentRow.Cells[5].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.tmpFchRev = this.dgvCalificaciones.CurrentRow.Cells[8].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.tmpCal = this.dgvCalificaciones.CurrentRow.Cells[13].Value.ToString();
            }
            catch { }
        }

        private void pbBuscar_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Reprogramacion").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana Reprogramacion ya esta abierta...");
                    }
                    else
                    {
                        Reprogramacion i = new Reprogramacion();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void devolverToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string Calificacion = MmsWin.Front.Utilerias.VarTem.tmpCalCalif;
            if (Calificacion == "Devolucion" ) // || Calificacion == "Dev ó 50%" || Calificacion == "Dev o 50%")
            {
                GuardarNotaDevolucion();
            }
            else
            {
                MessageBox.Show("No aplica para esta calificacion");
            }
        }

        private void GuardarNotaDevolucion()
        {
            string TpoMov = "DEV";
            string TpoCal = "NOR";

            string FchDvl = DateTime.Now.ToString("dd/MM/yyyy");
            FchDvl = FchDvl.Substring(8, 2) + FchDvl.Substring(3, 2) + FchDvl.Substring(0, 2);
            string HorDvl = DateTime.Now.ToString("HH:mm:ss");
            HorDvl = HorDvl.Substring(0, 2) + HorDvl.Substring(3, 2) + HorDvl.Substring(6, 2);
            string FchHorDvl = FchDvl + HorDvl;

            // Recalculo . . . . .
            System.Data.DataTable dtGuardaNota = null;

            string ParFchBon = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
            ParFchBon = ParFchBon.Substring(8, 2) + ParFchBon.Substring(3, 2) + ParFchBon.Substring(0, 2);
            string ParFchRev = this.dgvCalificaciones.CurrentRow.Cells[8].Value.ToString();
            string ParProveedor = this.dgvCalificaciones.CurrentRow.Cells[1].Value.ToString();
            string PartbEstilo = this.dgvCalificaciones.CurrentRow.Cells[3].Value.ToString();
            string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
            string ParNotCal = FchHorDvl;
            string ParSubtot = "0";
            string ParPorc = "0";
            string varInd1 = "0";
            string varInd2 = "0";

            ParSubtot = ParSubtot.Replace(".", "");
            ParSubtot = ParSubtot.Replace(",", "");
            ParPorc = ParPorc.Replace(".", "");
            String RutaPdf = MmsWin.Front.Utilerias.VarTem.tmpRutaPdf;
            dtGuardaNota = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().GuardaNota(ParFchBon, ParFchRev, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, ParPorc, varInd1, varInd2, TpoMov, TpoCal, RutaPdf);

            if (dtGuardaNota.Rows.Count > 0)
            {
                foreach (DataRow row in dtGuardaNota.Rows)
                {
                    varInd1 = row["NOTIN1"].ToString();
                    varInd2 = row["NOTIN2"].ToString();

                    if (varInd1 == "1" && varInd2 == "0")
                    {
                        MessageBox.Show("Se generó el registro exitosamente");
                   //     this.Close();

                    }
                    else
                    {
                        if (varInd2 == "1")
                        {
                            string message = "Ya existe La Nota de Crédito, Haz Click en (Si) para remplazar ";
                            string caption = "Aviso";
                            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                            DialogResult result;
                            result = MessageBox.Show(message, caption, buttons);
                            if (result == System.Windows.Forms.DialogResult.Yes)
                            {
                                varInd1 = "2";
                                varInd2 = "2";
                                RutaPdf = MmsWin.Front.Utilerias.VarTem.tmpRutaPdf;
                                MmsWin.Negocio.Utilerias.Utilerias.GetInstance().GuardaNota(ParFchBon, ParFchRev, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, ParPorc, varInd1, varInd2, TpoMov, TpoCal, RutaPdf);
                                MessageBox.Show("Se actualizo la Nota de Crédito exitosamente");
                           //     this.Close();
                            }
                        }
                    }
                }
            }
        }

        private void rbTodos_Click(object sender, EventArgs e)
        {
            BindCalificaciones();
        }

        private void rbAplicados_Click(object sender, EventArgs e)
        {
            BindCalificaciones();
        }

        private void rbBonificar_Devolver_Click(object sender, EventArgs e)
        {
            BindCalificaciones();
        }

        private void rbPendientes_Click(object sender, EventArgs e)
        {
            BindCalificaciones();
        }

        private void pbExcel_Click(object sender, EventArgs e)
        {
            System.Data.DataTable dtDowns = (System.Data.DataTable)(dgvCalificaciones.DataSource);
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            int nc = dgvCalificaciones.Columns.Count;


            for (int ii = 1; ii <= nc; ii++)
            {
                xlWorkSheet.Cells[1, ii] = dgvCalificaciones.Columns[ii - 1].HeaderText;
            }

            System.Data.DataTable dtCalificaciones = (System.Data.DataTable)(dgvCalificaciones.DataSource);
            int nr = dgvCalificaciones.RowCount;
            this.pgbProg.Visible = true;

            pgbProg.Maximum = nr;
            pgbProg.Value = 0;
            int r = 0; 
            int rt = 3; 
            foreach (DataRow row in dtCalificaciones.Rows)
            {
                var gsArray = new[]       {
                                                    row["CSTFRV"],
                                                    row["CSTPRV"],
                                                    row["CSTPRN"],
                                                    row["CSTSTY"],
                                                    row["CSTDES"],
                                                    row["CSTDCP"],
                                                    row["CSTNCA"],
                                                    row["CSTFCM"],
                                                    row["CSTFRE"],
                                                    row["CSTPZA"],
                                                    row["CSTVTA"],
                                                    row["CSTONH"],
                                                    row["CSTPVT"],
                                                    row["CSTONO"],
                                                    row["CSTCAL"],
                                                    row["CSTCOR"],
                                                    row["CSTTAB"],
                                                    row["CSTCMP"],
                                                    row["CSTNOT"],
                                                    row["CSTSUB"],
                                                    row["CSTIVA"],
                                                    row["CSTTOT"],
                                                    row["CSTPBO"],
                                                    row["CSTCST"],
                                                    row["CSTPRC"],
                                                    row["CSTMRG"],
                                                    row["CSTCST1"],
                                                    row["CSTPRC1"],
                                                    row["CSTMRG1"],
                                                    row["CSTCST2"],
                                                    row["CSTPRC2"],
                                                    row["CSTMRG2"],
                                                    row["CSTCMC"],
                                                    row["CSTTAB2"],
                                                    row["CSTCSTD"],
                                                    row["CSTPZA1"],
                                                    row["CSTIMP1"],
                                                    row["CSTPZD2"],
                                                    row["CSTIMD2"],
                                                    row["CSTONH7"],
                                                    row["CSTPRO7"],
                                                    row["CSTIMD7"],
                                                    row["CSTPRO"],
                                                    row["CSTTABF"],
                                                    row["CSTFCXP"],
                                                    row["CSTMAR"],
                                                    row["CSTCOM"],
                                                    row["CSTBDG"],
                                                    row["CSTNMR"]
                                                   };

                Range rng = xlWorkSheet.get_Range("A" + rt, "AW" + rt);
                rng.Value = gsArray;

                pgbProg.Value += 1;

                this.Text = "Convenio / " + " " + (r += 1).ToString() + " Registro(s)";

                // Pagar
                if (row["CSTCAL"].ToString() == " P a g a r") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.LightGreen; }
                // 15%
                if (row["CSTCAL"].ToString() == " 15%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Yellow; }
                // 20%
                if (row["CSTCAL"].ToString() == " 20%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Yellow; }
                // 25%
                if (row["CSTCAL"].ToString() == " 25%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Yellow; }
                // 30%
                if (row["CSTCAL"].ToString() == " 30%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.LightSalmon; }
                // 35%
                if (row["CSTCAL"].ToString() == " 35%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.LightSalmon; }
                // 40%
                if (row["CSTCAL"].ToString() == " 40%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.LightSalmon; }
                // Dev ó 40%
                if (row["CSTCAL"].ToString() == " 40%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 15].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["CSTCAL"].ToString() == " 50%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 15].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["CSTCAL"].ToString() == " 50%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 15].Cells.Font.Color = Color.White; }
                // Devolucion
                if (row["CSTCAL"].ToString() == "Devolucion") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 15].Cells.Font.Color = Color.White; }

                // Pagar
                if (row["CSTCOR"].ToString() == " P a g a r") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.LightGreen; }
                // 15%
                if (row["CSTCOR"].ToString() == " 15%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.Yellow; }
                // 20%
                if (row["CSTCOR"].ToString() == " 20%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.Yellow; }
                // 25%
                if (row["CSTCOR"].ToString() == " 25%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.Yellow; }
                // 30%
                if (row["CSTCOR"].ToString() == " 30%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.LightSalmon; }
                // 35%
                if (row["CSTCOR"].ToString() == " 35%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.LightSalmon; }
                // 40%
                if (row["CSTCOR"].ToString() == " 40%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.LightSalmon; }
                // Dev ó 40%
                if (row["CSTCOR"].ToString() == " 40%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 16].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["CSTCOR"].ToString() == " 50%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 16].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["CSTCOR"].ToString() == " 50%") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 16].Cells.Font.Color = Color.White; }
                // Devolucion
                if (row["CSTCOR"].ToString() == "Devolucion") { xlWorkSheet.Cells[rt, 16].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 16].Cells.Font.Color = Color.White; }
                rt++;
            }
            xlWorkSheet.Columns[1].ColumnWidth = 4;
            xlWorkSheet.Columns[2].ColumnWidth = 3;
            xlWorkSheet.Columns[3].ColumnWidth = 30;
            xlWorkSheet.Columns[4].ColumnWidth = 15;
            xlWorkSheet.Columns[5].ColumnWidth = 30;
            xlWorkSheet.Columns[6].ColumnWidth = 20;
            xlWorkSheet.Columns[7].ColumnWidth = 10;
            xlWorkSheet.Columns[8].ColumnWidth = 6;
            xlWorkSheet.Columns[9].ColumnWidth = 6;
            xlWorkSheet.Columns[10].ColumnWidth = 10;
            xlWorkSheet.Columns[11].ColumnWidth = 10;
            xlWorkSheet.Columns[12].ColumnWidth = 5;
            xlWorkSheet.Columns[13].ColumnWidth = 5;
            xlWorkSheet.Columns[14].ColumnWidth = 5;
            xlWorkSheet.Columns[15].ColumnWidth = 5;
            xlWorkSheet.Columns[16].ColumnWidth = 5;
            xlWorkSheet.Columns[17].ColumnWidth = 5;
            xlWorkSheet.Columns[18].ColumnWidth = 10;
            xlWorkSheet.Columns[19].ColumnWidth = 4;
            xlWorkSheet.Columns[20].ColumnWidth = 4;
            xlWorkSheet.Columns[21].ColumnWidth = 4;
            xlWorkSheet.Columns[22].ColumnWidth = 4;
            xlWorkSheet.Columns[23].ColumnWidth = 4;
            xlWorkSheet.Columns[24].ColumnWidth = 4;
            xlWorkSheet.Columns[25].ColumnWidth = 4;
            xlWorkSheet.Columns[26].ColumnWidth = 4;
            xlWorkSheet.Columns[27].ColumnWidth = 4;
            xlWorkSheet.Columns[28].ColumnWidth = 4;
            xlWorkSheet.Columns[29].ColumnWidth = 10;
            xlWorkSheet.Columns[30].ColumnWidth = 10;
            xlWorkSheet.Columns[31].ColumnWidth = 10;
            xlWorkSheet.Columns[32].ColumnWidth = 10;
            xlWorkSheet.Columns[33].ColumnWidth = 10;
            xlWorkSheet.Columns[34].ColumnWidth = 10;
            xlWorkSheet.Columns[35].ColumnWidth = 10;

            xlWorkSheet.Cells[1, 1].Cells.Interior.Color = Color.LightSalmon;
            var Rang1 = xlWorkSheet.get_Range("B1", "C1");
            Rang1.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 4].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 5].Cells.Interior.Color = Color.LightSkyBlue;

            xlWorkSheet.Cells[1, 6].Cells.Interior.Color = Color.LightSalmon;
            
            var Rang3 = xlWorkSheet.get_Range("G1", "K1");
            Rang3.Interior.Color = Color.LightGreen;

            xlWorkSheet.Cells[1, 12].Cells.Interior.Color = Color.LightSeaGreen;
            xlWorkSheet.Cells[1, 13].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 14].Cells.Interior.Color = Color.LightSeaGreen;
            var Rang4 = xlWorkSheet.get_Range("O1", "P1");
            Rang4.Interior.Color = Color.LightSkyBlue;

            xlWorkSheet.Cells[1, 17].Cells.Interior.Color = Color.LightSeaGreen;
            xlWorkSheet.Cells[1, 18].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 19].Cells.Interior.Color = Color.LightCoral;
            xlWorkSheet.Cells[1, 20].Cells.Interior.Color = Color.LightCoral;
            xlWorkSheet.Cells[1, 21].Cells.Interior.Color = Color.LightCoral;
            xlWorkSheet.Cells[1, 22].Cells.Interior.Color = Color.LightCoral;
            xlWorkSheet.Cells[1, 23].Cells.Interior.Color = Color.LightSalmon;
            
            xlWorkSheet.Cells[1, 24].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 25].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 26].Cells.Interior.Color = Color.LightGreen;
            
            xlWorkSheet.Cells[1, 27].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 28].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 29].Cells.Interior.Color = Color.LightSalmon;

            xlWorkSheet.Cells[1, 30].Cells.Interior.Color = Color.LightCoral;
            xlWorkSheet.Cells[1, 31].Cells.Interior.Color = Color.LightCoral;
            xlWorkSheet.Cells[1, 32].Cells.Interior.Color = Color.LightCoral;

            xlWorkSheet.Cells[1, 33].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 34].Cells.Interior.Color = Color.LightSalmon;

            xlWorkSheet.Cells[1, 35].Cells.Interior.Color = Color.LightGreen;

            xlWorkSheet.Cells[1, 36].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 37].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 38].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 39].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 40].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 41].Cells.Interior.Color = Color.LightSalmon;

            xlWorkSheet.Cells[1, 42].Cells.Interior.Color = Color.LightCoral;

            xlWorkSheet.Cells[1, 43].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 44].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 45].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 46].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 47].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 48].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 49].Cells.Interior.Color = Color.LightSalmon;

            var Rang2 = xlWorkSheet.get_Range("A1", "AW1");
            Rang2.WrapText = true;
            Rang2.Font.Bold = true;
            Rang2.Font.Color = Color.White;
            Rang2.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang2.Font.Underline = true;
            Rang2.HorizontalAlignment = HorizontalAlignment.Center;

            String Rango = "A2" + ":" + "AW" + rt;
            Excel.Range SourceRange = (Excel.Range)xlWorkSheet.get_Range("A2", "AW" + rt); // or whatever range you want here
            FormatAsTable(SourceRange, "Table1", "TableStyleMedium2");

            xlWorkSheet.Rows[2].Hidden = true;

            xlWorkSheet.Columns["A:B"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["D"].HorizontalAlignment = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["C"].HorizontalAlignment = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["F"].HorizontalAlignment = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["G"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["H"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["I"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["M:N"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["O"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["P"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AB:AC"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AG"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AH"].HorizontalAlignment = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["AK:AQ"].HorizontalAlignment = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["AR:AW"].HorizontalAlignment = XlHAlign.xlHAlignCenter;

            xlWorkSheet.Columns["A"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["H"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["I"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["J:M"].NumberFormat = "#,###.00";
            xlWorkSheet.Columns["N"].NumberFormat = "#,###,###";
            xlWorkSheet.Columns["Q:AF"].NumberFormat = "#,###.##";
            xlWorkSheet.Columns["AH"].NumberFormat = "#,###";
            xlWorkSheet.Columns["AI:AJ"].NumberFormat = "#,###.00";
            xlWorkSheet.Columns["AK:AW"].NumberFormat = "#,###";
            var range = xlWorkSheet.get_Range("A3", "A3");
            range.Select();

            string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
            xlApp.ActiveWindow.Zoom = 80;
            xlWorkBook.SaveAs("C:\\Reportes\\Calificaciones" + Hoy + ".xlsx", Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            string comando = @"C:\\Reportes\\Calificaciones" + Hoy + ".xlsx";
            ExecuteCommand(comando);

            this.pgbProg.Visible = false;
        }

        static void ExecuteCommand(string _Command)
        {
            //Indicamos que deseamos inicializar el proceso cmd.exe junto a un comando de arranque. 
            //(/C, le indicamos al proceso cmd que deseamos que cuando termine la tarea asignada se cierre el proceso).
            //Para mas informacion consulte la ayuda de la consola con cmd.exe /? 
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;
            //Inicializa el proceso
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            string result = proc.StandardOutput.ReadToEnd();
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        public void FormatAsTable(Excel.Range SourceRange, string TableName, string TableStyleName)
        {
            SourceRange.Worksheet.ListObjects.Add(XlListObjectSourceType.xlSrcRange,
            SourceRange, System.Type.Missing, XlYesNoGuess.xlYes, System.Type.Missing).Name =
                TableName;
            SourceRange.Select();
            SourceRange.Worksheet.ListObjects[TableName].TableStyle = TableStyleName;
            SourceRange.Worksheet.ListObjects[TableName].ShowAutoFilter = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowHeaders = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowTotals = false;
        }

        private void capturaTlSMI_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Nota").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La Ventana ya esta abierta...");
                    }
                    else
                    {
                            string FechaBon = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
                            string convMarcaNo = MmsWin.Front.Utilerias.VarTem.ConvMarcaNo;

                            string FechaBinificacion = FechaBon.Substring(8, 2) + FechaBon.Substring(3, 2) + FechaBon.Substring(0, 2);
                            string FechaAbierta = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenMarcaConfiguracion1(convMarcaNo);
                            if (FechaBinificacion == FechaAbierta)
                            {
                                Nota i = new Nota();
                                i.Show();
                            }
                            else
                            {
                                MessageBox.Show("La fecha " + FechaBon + " No esta abierta para captura de Notas de Credito");
                            }
                    }
                }
            }
            catch { }
            finally { }
        }

        private void dgvCalificaciones_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Kardex();
        }

        private void Kardex()
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Kardex").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del Kardex ya esta abierta");
                    }
                    else
                    {
                        Kardex i = new Kardex();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void mcC1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcC1.Visible = false;
            }
        }

        private void mcC2_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcC2.Visible = false;
            }
        }
    }
}
