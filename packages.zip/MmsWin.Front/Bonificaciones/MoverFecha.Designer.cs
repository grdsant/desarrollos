﻿namespace MmsWin.Front.Bonificaciones
{
    partial class MoverFecha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbMoverA = new System.Windows.Forms.TextBox();
            this.btCancelar = new System.Windows.Forms.Button();
            this.btAceptar = new System.Windows.Forms.Button();
            this.mcC1 = new System.Windows.Forms.MonthCalendar();
            this.SuspendLayout();
            // 
            // tbMoverA
            // 
            this.tbMoverA.Enabled = false;
            this.tbMoverA.Location = new System.Drawing.Point(150, 16);
            this.tbMoverA.Name = "tbMoverA";
            this.tbMoverA.Size = new System.Drawing.Size(100, 20);
            this.tbMoverA.TabIndex = 0;
            this.tbMoverA.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btCancelar
            // 
            this.btCancelar.Location = new System.Drawing.Point(39, 215);
            this.btCancelar.Name = "btCancelar";
            this.btCancelar.Size = new System.Drawing.Size(75, 23);
            this.btCancelar.TabIndex = 1;
            this.btCancelar.Text = "Cancelar";
            this.btCancelar.UseVisualStyleBackColor = true;
            this.btCancelar.Click += new System.EventHandler(this.btCancelar_Click);
            // 
            // btAceptar
            // 
            this.btAceptar.Location = new System.Drawing.Point(282, 215);
            this.btAceptar.Name = "btAceptar";
            this.btAceptar.Size = new System.Drawing.Size(75, 23);
            this.btAceptar.TabIndex = 2;
            this.btAceptar.Text = "Aceptar";
            this.btAceptar.UseVisualStyleBackColor = true;
            this.btAceptar.Click += new System.EventHandler(this.btAceptar_Click);
            // 
            // mcC1
            // 
            this.mcC1.BackColor = System.Drawing.Color.Gray;
            this.mcC1.ForeColor = System.Drawing.Color.Black;
            this.mcC1.Location = new System.Drawing.Point(73, 43);
            this.mcC1.Name = "mcC1";
            this.mcC1.TabIndex = 42;
            this.mcC1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcC1_DateSelected);
            // 
            // MoverFecha
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(399, 248);
            this.Controls.Add(this.mcC1);
            this.Controls.Add(this.btAceptar);
            this.Controls.Add(this.btCancelar);
            this.Controls.Add(this.tbMoverA);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MoverFecha";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Fecha a Mover";
            this.Load += new System.EventHandler(this.MoverFecha_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbMoverA;
        private System.Windows.Forms.Button btCancelar;
        private System.Windows.Forms.Button btAceptar;
        private System.Windows.Forms.MonthCalendar mcC1;
    }
}