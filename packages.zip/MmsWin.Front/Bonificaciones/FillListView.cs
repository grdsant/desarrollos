﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Bonificaciones
{
    public static class ListViewExtensions
    {
        public static void Fill(this ListView listView, DataTable data)
        {
            if (data == null) throw new ArgumentNullException("Es necesario enviar una tabla.");
            if (data.Columns.Count == 0) return;
            if (data.Rows.Count == 0) return;
            data.Columns.Cast<DataColumn>().ToList().ForEach(column => listView.Columns.Add(column.Caption));

            data.AsEnumerable().ToList().ForEach(row =>
            {
                ListViewItem item = new ListViewItem(Convert.ToString(row[0]));
                row.ItemArray.ToList().Skip(1).ToList().ForEach(value =>
                    item.SubItems.Add(Convert.ToString(value)));
                listView.Items.Add(item);
            });
        }
    }
}
