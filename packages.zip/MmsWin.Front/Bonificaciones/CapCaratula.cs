﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Bonificaciones
{
    public partial class CapCaratula : Form
    {
        public CapCaratula()
        {
            InitializeComponent();
        }
    }
}
