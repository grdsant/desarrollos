﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Bonificaciones
{
    public partial class MoverFecha : Form
    {
        string FechaCal  = string.Empty;
        string FechaFmt  = string.Empty;
        string FchAmover = string.Empty;

        public MoverFecha()
        {
            InitializeComponent();
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btAceptar_Click(object sender, EventArgs e)
        {
            if (tbMoverA.Text != "")
            {
                string message = "Esta seguro de Mover los estilos seleccionados?";
                string caption = "Confirmación";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;
                result = MessageBox.Show(message, caption, buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    System.Data.DataTable dtMoverFecha = new System.Data.DataTable("MoverFechas");

                    dtMoverFecha = MmsWin.Front.Utilerias.VarTem.BkFechaAmover;

                    MmsWin.Negocio.Bonificaciones.Bonificaciones.GetInstance().UpdateFechaAmover(dtMoverFecha, FchAmover);
                    MessageBox.Show("Se ha movido los estilos seleccionados a la Fecha :" + tbMoverA.Text);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Proceso cancelado por el usuario");
                }
            }
            else 
            {
                MessageBox.Show("Debe indicar la fecha a la que movera el proveedor estilo");
            }
        }

        private void mcC1_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbMoverA.Text = mcC1.SelectionEnd.ToShortDateString();
            FechaCal = tbMoverA.Text;
            FchAmover = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
        }

        private void MoverFecha_Load(object sender, EventArgs e)
        {

        }

    }
}
