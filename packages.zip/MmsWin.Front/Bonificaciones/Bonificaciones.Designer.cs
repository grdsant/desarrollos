﻿namespace MmsWin.Front.Bonificaciones
{
    partial class Bonificaciones
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Bonificaciones));
            this.dgvBonificaciones = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.FotoTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.documentoPDFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TSMImoverFecha = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ActualizarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminarTSM1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pgbProg = new System.Windows.Forms.ProgressBar();
            this.pbExcel = new System.Windows.Forms.PictureBox();
            this.cbCompradores = new System.Windows.Forms.ComboBox();
            this.gbMarca = new System.Windows.Forms.GroupBox();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.gbComprador = new System.Windows.Forms.GroupBox();
            this.pbBuscar = new System.Windows.Forms.PictureBox();
            this.pbBonAnticipada = new System.Windows.Forms.PictureBox();
            this.pbOmisionXTemp = new System.Windows.Forms.PictureBox();
            this.btCheckBox = new System.Windows.Forms.Button();
            this.chbCheckApli = new System.Windows.Forms.CheckBox();
            this.chbCheckBsts = new System.Windows.Forms.CheckBox();
            this.btRecalculo = new System.Windows.Forms.Button();
            this.tbRelleno02 = new System.Windows.Forms.TextBox();
            this.Relleno = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbProveedor = new System.Windows.Forms.TextBox();
            this.gbRangoFecha = new System.Windows.Forms.GroupBox();
            this.tbDesde = new System.Windows.Forms.TextBox();
            this.lblHasta = new System.Windows.Forms.Label();
            this.lblDesde = new System.Windows.Forms.Label();
            this.tbHasta = new System.Windows.Forms.TextBox();
            this.mcC2 = new System.Windows.Forms.MonthCalendar();
            this.mcC1 = new System.Windows.Forms.MonthCalendar();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBonificaciones)).BeginInit();
            this.cmMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbExcel)).BeginInit();
            this.gbMarca.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbBuscar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBonAnticipada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOmisionXTemp)).BeginInit();
            this.gbRangoFecha.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvBonificaciones
            // 
            this.dgvBonificaciones.AllowUserToAddRows = false;
            this.dgvBonificaciones.AllowUserToDeleteRows = false;
            this.dgvBonificaciones.AllowUserToOrderColumns = true;
            this.dgvBonificaciones.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBonificaciones.ContextMenuStrip = this.cmMenu;
            this.dgvBonificaciones.Location = new System.Drawing.Point(3, 73);
            this.dgvBonificaciones.Name = "dgvBonificaciones";
            this.dgvBonificaciones.Size = new System.Drawing.Size(1224, 356);
            this.dgvBonificaciones.TabIndex = 0;
            this.dgvBonificaciones.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBonificaciones_CellClick);
            this.dgvBonificaciones.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBonificaciones_CellDoubleClick);
            this.dgvBonificaciones.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvBonificaciones_CellMouseDown);
            this.dgvBonificaciones.CellParsing += new System.Windows.Forms.DataGridViewCellParsingEventHandler(this.dgvBonificaciones_CellParsing_1);
            this.dgvBonificaciones.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgvBonificaciones_DataError);
            this.dgvBonificaciones.SelectionChanged += new System.EventHandler(this.dgvBonificaciones_SelectionChanged);
            this.dgvBonificaciones.Sorted += new System.EventHandler(this.dgvBonificaciones_Sorted);
            this.dgvBonificaciones.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dgvBonificaciones_KeyPress);
            this.dgvBonificaciones.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvBonificaciones_KeyUp);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FotoTSMI,
            this.documentoPDFToolStripMenuItem,
            this.TSMImoverFecha,
            this.toolStripMenuItem2,
            this.ActualizarTSMI,
            this.eliminarTSM1});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(170, 136);
            // 
            // FotoTSMI
            // 
            this.FotoTSMI.Name = "FotoTSMI";
            this.FotoTSMI.Size = new System.Drawing.Size(169, 22);
            this.FotoTSMI.Text = "Foto";
            this.FotoTSMI.Click += new System.EventHandler(this.fotoToolStripMenuItem_Click);
            // 
            // documentoPDFToolStripMenuItem
            // 
            this.documentoPDFToolStripMenuItem.Name = "documentoPDFToolStripMenuItem";
            this.documentoPDFToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.documentoPDFToolStripMenuItem.Text = "Consultar NC PDF";
            this.documentoPDFToolStripMenuItem.Click += new System.EventHandler(this.documentoPDFToolStripMenuItem_Click);
            // 
            // TSMImoverFecha
            // 
            this.TSMImoverFecha.Name = "TSMImoverFecha";
            this.TSMImoverFecha.Size = new System.Drawing.Size(169, 22);
            this.TSMImoverFecha.Text = "Mover a la Fecha";
            this.TSMImoverFecha.Click += new System.EventHandler(this.TSMImoverFecha_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(169, 22);
            this.toolStripMenuItem2.Text = "_ _ _ _ _ _ _ _ _";
            // 
            // ActualizarTSMI
            // 
            this.ActualizarTSMI.Name = "ActualizarTSMI";
            this.ActualizarTSMI.Size = new System.Drawing.Size(169, 22);
            this.ActualizarTSMI.Text = "Actualizar";
            this.ActualizarTSMI.Click += new System.EventHandler(this.ActualizarTSMI_Click);
            // 
            // eliminarTSM1
            // 
            this.eliminarTSM1.Name = "eliminarTSM1";
            this.eliminarTSM1.Size = new System.Drawing.Size(169, 22);
            this.eliminarTSM1.Text = "Eliminar";
            this.eliminarTSM1.Click += new System.EventHandler(this.eliminarTSM1_Click);
            // 
            // pgbProg
            // 
            this.pgbProg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pgbProg.Location = new System.Drawing.Point(3, 431);
            this.pgbProg.Name = "pgbProg";
            this.pgbProg.Size = new System.Drawing.Size(1299, 11);
            this.pgbProg.TabIndex = 7;
            this.pgbProg.Visible = false;
            // 
            // pbExcel
            // 
            this.pbExcel.Image = ((System.Drawing.Image)(resources.GetObject("pbExcel.Image")));
            this.pbExcel.Location = new System.Drawing.Point(3, 2);
            this.pbExcel.Name = "pbExcel";
            this.pbExcel.Size = new System.Drawing.Size(65, 44);
            this.pbExcel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbExcel.TabIndex = 9;
            this.pbExcel.TabStop = false;
            this.pbExcel.Click += new System.EventHandler(this.pbExcel_Click);
            // 
            // cbCompradores
            // 
            this.cbCompradores.FormattingEnabled = true;
            this.cbCompradores.Location = new System.Drawing.Point(216, 17);
            this.cbCompradores.Name = "cbCompradores";
            this.cbCompradores.Size = new System.Drawing.Size(168, 21);
            this.cbCompradores.TabIndex = 12;
            this.cbCompradores.SelectedIndexChanged += new System.EventHandler(this.cbCompradores_SelectedIndexChanged);
            // 
            // gbMarca
            // 
            this.gbMarca.Controls.Add(this.cbMarca);
            this.gbMarca.Location = new System.Drawing.Point(74, 0);
            this.gbMarca.Name = "gbMarca";
            this.gbMarca.Size = new System.Drawing.Size(113, 46);
            this.gbMarca.TabIndex = 11;
            this.gbMarca.TabStop = false;
            this.gbMarca.Text = "Marca";
            // 
            // cbMarca
            // 
            this.cbMarca.Location = new System.Drawing.Point(24, 18);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(74, 21);
            this.cbMarca.TabIndex = 2;
            this.cbMarca.SelectedValueChanged += new System.EventHandler(this.cbMarca_SelectedValueChanged);
            // 
            // gbComprador
            // 
            this.gbComprador.Location = new System.Drawing.Point(193, -1);
            this.gbComprador.Name = "gbComprador";
            this.gbComprador.Size = new System.Drawing.Size(203, 47);
            this.gbComprador.TabIndex = 13;
            this.gbComprador.TabStop = false;
            this.gbComprador.Text = "Comprador";
            // 
            // pbBuscar
            // 
            this.pbBuscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pbBuscar.Cursor = System.Windows.Forms.Cursors.Default;
            this.pbBuscar.Image = ((System.Drawing.Image)(resources.GetObject("pbBuscar.Image")));
            this.pbBuscar.Location = new System.Drawing.Point(791, 3);
            this.pbBuscar.Name = "pbBuscar";
            this.pbBuscar.Size = new System.Drawing.Size(65, 43);
            this.pbBuscar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbBuscar.TabIndex = 17;
            this.pbBuscar.TabStop = false;
            this.pbBuscar.Click += new System.EventHandler(this.pbBuscar_Click);
            // 
            // pbBonAnticipada
            // 
            this.pbBonAnticipada.Image = ((System.Drawing.Image)(resources.GetObject("pbBonAnticipada.Image")));
            this.pbBonAnticipada.Location = new System.Drawing.Point(649, 4);
            this.pbBonAnticipada.Name = "pbBonAnticipada";
            this.pbBonAnticipada.Size = new System.Drawing.Size(65, 42);
            this.pbBonAnticipada.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbBonAnticipada.TabIndex = 19;
            this.pbBonAnticipada.TabStop = false;
            this.pbBonAnticipada.Click += new System.EventHandler(this.pbBonAnticipada_Click);
            // 
            // pbOmisionXTemp
            // 
            this.pbOmisionXTemp.Image = ((System.Drawing.Image)(resources.GetObject("pbOmisionXTemp.Image")));
            this.pbOmisionXTemp.Location = new System.Drawing.Point(720, 3);
            this.pbOmisionXTemp.Name = "pbOmisionXTemp";
            this.pbOmisionXTemp.Size = new System.Drawing.Size(65, 43);
            this.pbOmisionXTemp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbOmisionXTemp.TabIndex = 21;
            this.pbOmisionXTemp.TabStop = false;
            this.pbOmisionXTemp.Visible = false;
            this.pbOmisionXTemp.Click += new System.EventHandler(this.pbOmisionXTemp_Click);
            // 
            // btCheckBox
            // 
            this.btCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btCheckBox.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCheckBox.Location = new System.Drawing.Point(1144, 6);
            this.btCheckBox.Name = "btCheckBox";
            this.btCheckBox.Size = new System.Drawing.Size(83, 40);
            this.btCheckBox.TabIndex = 23;
            this.btCheckBox.Text = "Actualiza Check Box";
            this.btCheckBox.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btCheckBox.UseVisualStyleBackColor = true;
            this.btCheckBox.Click += new System.EventHandler(this.btCheckBox_Click);
            // 
            // chbCheckApli
            // 
            this.chbCheckApli.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chbCheckApli.AutoSize = true;
            this.chbCheckApli.Location = new System.Drawing.Point(1043, 9);
            this.chbCheckApli.Name = "chbCheckApli";
            this.chbCheckApli.Size = new System.Drawing.Size(102, 17);
            this.chbCheckApli.TabIndex = 28;
            this.chbCheckApli.Text = "Check B Aplicar";
            this.chbCheckApli.UseVisualStyleBackColor = true;
            this.chbCheckApli.CheckStateChanged += new System.EventHandler(this.chbCheckApli_CheckStateChanged);
            // 
            // chbCheckBsts
            // 
            this.chbCheckBsts.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chbCheckBsts.AutoSize = true;
            this.chbCheckBsts.Location = new System.Drawing.Point(1043, 26);
            this.chbCheckBsts.Name = "chbCheckBsts";
            this.chbCheckBsts.Size = new System.Drawing.Size(96, 17);
            this.chbCheckBsts.TabIndex = 29;
            this.chbCheckBsts.Text = "Check Box Sts";
            this.chbCheckBsts.UseVisualStyleBackColor = true;
            this.chbCheckBsts.CheckStateChanged += new System.EventHandler(this.chbCheckBsts_CheckStateChanged);
            // 
            // btRecalculo
            // 
            this.btRecalculo.Location = new System.Drawing.Point(862, 4);
            this.btRecalculo.Name = "btRecalculo";
            this.btRecalculo.Size = new System.Drawing.Size(75, 42);
            this.btRecalculo.TabIndex = 30;
            this.btRecalculo.Text = "Recálculo";
            this.btRecalculo.UseVisualStyleBackColor = true;
            this.btRecalculo.Visible = false;
            this.btRecalculo.Click += new System.EventHandler(this.btRecalculo_Click);
            // 
            // tbRelleno02
            // 
            this.tbRelleno02.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbRelleno02.Enabled = false;
            this.tbRelleno02.Location = new System.Drawing.Point(637, 51);
            this.tbRelleno02.Name = "tbRelleno02";
            this.tbRelleno02.Size = new System.Drawing.Size(590, 20);
            this.tbRelleno02.TabIndex = 39;
            // 
            // Relleno
            // 
            this.Relleno.Enabled = false;
            this.Relleno.Location = new System.Drawing.Point(3, 51);
            this.Relleno.Name = "Relleno";
            this.Relleno.Size = new System.Drawing.Size(123, 20);
            this.Relleno.TabIndex = 38;
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDescripcion.Location = new System.Drawing.Point(436, 51);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(201, 20);
            this.tbDescripcion.TabIndex = 37;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress);
            // 
            // tbEstilo
            // 
            this.tbEstilo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbEstilo.Location = new System.Drawing.Point(371, 51);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(65, 20);
            this.tbEstilo.TabIndex = 36;
            this.tbEstilo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbEstilo_KeyPress);
            // 
            // tbNombre
            // 
            this.tbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNombre.Location = new System.Drawing.Point(172, 51);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(199, 20);
            this.tbNombre.TabIndex = 35;
            this.tbNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNombre_KeyPress);
            // 
            // tbProveedor
            // 
            this.tbProveedor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbProveedor.Location = new System.Drawing.Point(126, 51);
            this.tbProveedor.Name = "tbProveedor";
            this.tbProveedor.Size = new System.Drawing.Size(46, 20);
            this.tbProveedor.TabIndex = 34;
            this.tbProveedor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbProveedor_KeyPress);
            // 
            // gbRangoFecha
            // 
            this.gbRangoFecha.Controls.Add(this.tbDesde);
            this.gbRangoFecha.Controls.Add(this.lblHasta);
            this.gbRangoFecha.Controls.Add(this.lblDesde);
            this.gbRangoFecha.Controls.Add(this.tbHasta);
            this.gbRangoFecha.Location = new System.Drawing.Point(402, -1);
            this.gbRangoFecha.Name = "gbRangoFecha";
            this.gbRangoFecha.Size = new System.Drawing.Size(241, 47);
            this.gbRangoFecha.TabIndex = 40;
            this.gbRangoFecha.TabStop = false;
            this.gbRangoFecha.Text = "Rango";
            // 
            // tbDesde
            // 
            this.tbDesde.Location = new System.Drawing.Point(47, 20);
            this.tbDesde.Name = "tbDesde";
            this.tbDesde.ReadOnly = true;
            this.tbDesde.Size = new System.Drawing.Size(71, 20);
            this.tbDesde.TabIndex = 33;
            this.tbDesde.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbDesde.Click += new System.EventHandler(this.tbDesde_Click);
            // 
            // lblHasta
            // 
            this.lblHasta.AutoSize = true;
            this.lblHasta.Location = new System.Drawing.Point(124, 24);
            this.lblHasta.Name = "lblHasta";
            this.lblHasta.Size = new System.Drawing.Size(35, 13);
            this.lblHasta.TabIndex = 34;
            this.lblHasta.Text = "Hasta";
            // 
            // lblDesde
            // 
            this.lblDesde.AutoSize = true;
            this.lblDesde.Location = new System.Drawing.Point(6, 24);
            this.lblDesde.Name = "lblDesde";
            this.lblDesde.Size = new System.Drawing.Size(38, 13);
            this.lblDesde.TabIndex = 33;
            this.lblDesde.Text = "Desde";
            // 
            // tbHasta
            // 
            this.tbHasta.Location = new System.Drawing.Point(161, 20);
            this.tbHasta.Name = "tbHasta";
            this.tbHasta.ReadOnly = true;
            this.tbHasta.Size = new System.Drawing.Size(71, 20);
            this.tbHasta.TabIndex = 12;
            this.tbHasta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbHasta.Click += new System.EventHandler(this.tbHasta_Click);
            // 
            // mcC2
            // 
            this.mcC2.BackColor = System.Drawing.Color.Gray;
            this.mcC2.ForeColor = System.Drawing.Color.Black;
            this.mcC2.Location = new System.Drawing.Point(511, 74);
            this.mcC2.Name = "mcC2";
            this.mcC2.TabIndex = 42;
            this.mcC2.Visible = false;
            this.mcC2.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcC2_DateSelected);
            this.mcC2.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcC2_KeyUp);
            this.mcC2.Leave += new System.EventHandler(this.mcC2_Leave);
            // 
            // mcC1
            // 
            this.mcC1.BackColor = System.Drawing.Color.Gray;
            this.mcC1.ForeColor = System.Drawing.Color.Black;
            this.mcC1.Location = new System.Drawing.Point(336, 74);
            this.mcC1.Name = "mcC1";
            this.mcC1.TabIndex = 41;
            this.mcC1.Visible = false;
            this.mcC1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcC1_DateSelected);
            this.mcC1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcC1_KeyUp);
            this.mcC1.Leave += new System.EventHandler(this.mcC1_Leave);
            // 
            // Bonificaciones
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1231, 445);
            this.Controls.Add(this.mcC2);
            this.Controls.Add(this.mcC1);
            this.Controls.Add(this.gbRangoFecha);
            this.Controls.Add(this.tbRelleno02);
            this.Controls.Add(this.Relleno);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.tbEstilo);
            this.Controls.Add(this.tbNombre);
            this.Controls.Add(this.tbProveedor);
            this.Controls.Add(this.btRecalculo);
            this.Controls.Add(this.chbCheckBsts);
            this.Controls.Add(this.chbCheckApli);
            this.Controls.Add(this.btCheckBox);
            this.Controls.Add(this.pbOmisionXTemp);
            this.Controls.Add(this.pbBonAnticipada);
            this.Controls.Add(this.pbBuscar);
            this.Controls.Add(this.cbCompradores);
            this.Controls.Add(this.gbMarca);
            this.Controls.Add(this.gbComprador);
            this.Controls.Add(this.pbExcel);
            this.Controls.Add(this.pgbProg);
            this.Controls.Add(this.dgvBonificaciones);
            this.HelpButton = true;
            this.Name = "Bonificaciones";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Bonificaciones 3";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Bonificaciones_FormClosing);
            this.Load += new System.EventHandler(this.Bonificaciones_Load);
            this.Resize += new System.EventHandler(this.Bonificaciones_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBonificaciones)).EndInit();
            this.cmMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbExcel)).EndInit();
            this.gbMarca.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbBuscar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBonAnticipada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbOmisionXTemp)).EndInit();
            this.gbRangoFecha.ResumeLayout(false);
            this.gbRangoFecha.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvBonificaciones;
        private System.Windows.Forms.ProgressBar pgbProg;
        private System.Windows.Forms.PictureBox pbExcel;
        private System.Windows.Forms.ComboBox cbCompradores;
        private System.Windows.Forms.GroupBox gbMarca;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.GroupBox gbComprador;
        private System.Windows.Forms.PictureBox pbBuscar;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem FotoTSMI;
        private System.Windows.Forms.ToolStripMenuItem documentoPDFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eliminarTSM1;
        private System.Windows.Forms.PictureBox pbBonAnticipada;
        private System.Windows.Forms.PictureBox pbOmisionXTemp;
        private System.Windows.Forms.ToolStripMenuItem ActualizarTSMI;
        private System.Windows.Forms.Button btCheckBox;
        private System.Windows.Forms.CheckBox chbCheckApli;
        private System.Windows.Forms.CheckBox chbCheckBsts;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.Button btRecalculo;
        private System.Windows.Forms.TextBox tbRelleno02;
        private System.Windows.Forms.TextBox Relleno;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.TextBox tbProveedor;
        private System.Windows.Forms.GroupBox gbRangoFecha;
        private System.Windows.Forms.TextBox tbDesde;
        private System.Windows.Forms.Label lblHasta;
        private System.Windows.Forms.Label lblDesde;
        private System.Windows.Forms.TextBox tbHasta;
        private System.Windows.Forms.MonthCalendar mcC2;
        private System.Windows.Forms.MonthCalendar mcC1;
        private System.Windows.Forms.ToolStripMenuItem TSMImoverFecha;
    }
}