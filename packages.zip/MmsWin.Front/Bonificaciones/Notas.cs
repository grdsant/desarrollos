﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Bonificaciones
{
    public partial class Notas : Form
    {
        public Notas()
        {
            InitializeComponent();
        }

        private void Notas_Load(object sender, EventArgs e)
        {
            // Carga Datos del DatagridView
            tbFchCal.Text = MmsWin.Front.Bonificaciones.Calificaciones.ParFchRevision;
            tbFchApl.Text = MmsWin.Front.Bonificaciones.Bonificaciones.ParFechaBon;
            tbProvee.Text = MmsWin.Front.Bonificaciones.Calificaciones.ParProveedor;
            tbNombre.Text = MmsWin.Front.Bonificaciones.Calificaciones.PartbNombre;
            tbEstilo.Text = MmsWin.Front.Bonificaciones.Calificaciones.PartbEstilo;
            tbDescripcion.Text = MmsWin.Front.Bonificaciones.Calificaciones.ParDescripcion;
            mtbNotaCred.Text = " ";
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {

        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btCalcula_Click(object sender, EventArgs e)
        {
            Calcula();
        }

        private void Calcula()
        { 
                    System.Data.DataTable dtCalculo = null;

            string valNota = mtbNotaCred.Text;
            if (valNota == " ")
            {
                MessageBox.Show("La nota de Credito no debe quedar en Blanco");
            }
            else
            {
                string ParFchBon = MmsWin.Front.Utilerias.VarTem.tmpFchBon;
                string ParFchRev = MmsWin.Front.Utilerias.VarTem.tmpFchRev;
                string ParProveedor = tbProvee.Text;
                string PartbEstilo = tbEstilo.Text;
                string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                string ParNotCal = MmsWin.Front.Utilerias.VarTem.tmpNotCal;

                dtCalculo = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenCalculos1(ParFchBon, ParFchRev, ParProveedor, PartbEstilo, ParNotCal, ParUsuario);

                if (dtCalculo.Rows.Count > 0)
                {
                    foreach (DataRow row in dtCalculo.Rows)
                    {

                        tbComprador.Text = row["CALDCP"].ToString();
                        
                        tbFchCompra.Text = row["CALFCM"].ToString();
                        if (tbFchCompra.Text != "")
                        { tbFchCompra.Text = tbFchCompra.Text.Substring(4, 2) + "/" + tbFchCompra.Text.Substring(2, 2) + "/20" + tbFchCompra.Text.Substring(0, 2); }
                        
                        tbFchRevision.Text = row["CALFRE"].ToString();
                        if (tbFchRevision.Text != "")
                        { tbFchRevision.Text = tbFchRevision.Text.Substring(4, 2) + "/" + tbFchRevision.Text.Substring(2, 2) + "/20" + tbFchRevision.Text.Substring(0, 2); }

                        mtbRecibo.Text = string.Format("{0:n0}",double.Parse(row["CALPZA"].ToString()));
                        mtbVenta.Text = string.Format("{0:n0}",double.Parse(row["CALVTA"].ToString()));
                        mtbOnHand.Text = string.Format("{0:n0}",double.Parse(row["CALONH"].ToString()));
                        mtbPorc.Text = string.Format("{0:n2}",double.Parse(row["CALPVT"].ToString()));
                        mtbCalificacion.Text = row["CALCAL"].ToString();
                        tbTablaAcc.Text = row["CALTAB"].ToString();

                        mtbSubTotal.Text = string.Format("{0:n2}", double.Parse(row["CALSUB"].ToString())); 
                        mtbIva.Text = string.Format("{0:n2}", double.Parse(row["CALIVA"].ToString()));
                        mtbTotal.Text = string.Format("{0:n2}", double.Parse(row["CALTOT"].ToString()));

                        mtbCosto.Text = string.Format("{0:n2}", double.Parse(row["CALCST"].ToString()));
                        mtbPrecio.Text = string.Format("{0:n2}", double.Parse(row["CALPRC"].ToString()));
                        mtbMargen.Text = string.Format("{0:n2}", double.Parse(row["CALMRG"].ToString()));

                        mtbCosto1.Text = string.Format("{0:n2}", double.Parse(row["CALCST1"].ToString()));
                        mtbPrecio1.Text = string.Format("{0:n2}", double.Parse(row["CALPRC1"].ToString()));
                        mtbMargen1.Text = string.Format("{0:n2}", double.Parse(row["CALMRG1"].ToString()));

                        mtbCosto2.Text = string.Format("{0:n2}", double.Parse(row["CALCST2"].ToString()));
                        mtbPrecio2.Text = string.Format("{0:n2}", double.Parse(row["CALPRC2"].ToString()));
                        mtbMargen2.Text = string.Format("{0:n2}", double.Parse(row["CALMRG2"].ToString()));

                        // Diferencia
                        mtbDifCosto.Text = string.Format("{0:n2}", double.Parse(row["CALDIF"].ToString()));

                        // On Hand Actual
                        mtbOnHandActual.Text = string.Format("{0:n2}", double.Parse(row["CALPZA1"].ToString()));
                        mtbImpExistAct.Text = string.Format("{0:n2}", double.Parse(row["CALIMP1"].ToString()));
                        // Diferencia 
                        mtbDiferencia.Text = string.Format("{0:n2}", double.Parse(row["CALDIF1"].ToString()));
                        mtbDifCostoDif.Text = string.Format("{0:n2}", double.Parse(row["CALCSTD1"].ToString()));

                        // On Hand Actual
                        mtbOnHandActual1.Text = string.Format("{0:n2}", double.Parse(row["CALPZA2"].ToString()));
                        mtbImpExistAct1.Text = string.Format("{0:n2}", double.Parse(row["CALIMP2"].ToString()));
                        // Diferencia 
                        mtbDiferencia1.Text = string.Format("{0:n2}", double.Parse(row["CALDIF2"].ToString()));
                        mtbDifCostoDif1.Text = string.Format("{0:n2}", double.Parse(row["CALCSTD2"].ToString()));

                    }

                    //      MessageBox.Show("Calculo terminado...");
                    //      this.Close();
                }
                //  this.Close();
            }
        }

        private void mtbNotaCred_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                Calcula();
            }
        }  // fin de calcula

    }
}
