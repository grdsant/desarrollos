﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Bonificaciones
{


    public partial class CapBonifAnticipada : Form
    {
        int nr;
        string FechaCal;
        public CapBonifAnticipada()
        {
            InitializeComponent();
        }

        private void CapBonifAnticipada_Load(object sender, EventArgs e)
        {
            tbFechaRecibo.Text = "0";
            tbBodega.Text = "0";
            tbOrden.Text = "0";
            tbPiezas.Text = "0";

            tbFchCal.Text = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
            tbFchApl.Text = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            decimal bonActual = 0;

            if (this.dgvDatos.RowCount > 0)
            {
                MessageBox.Show("La Orden de Compra se encuentra asignada a un folio de 'Bonificación parcial con revisión a los 45 días' y será procesada de esa forma.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);

                if (dgvDatos.Rows[0].Cells["FOLIOS"].Value.ToString() == "0" || dgvDatos.Rows[0].Cells["ESTA"].Value.ToString() != "A")
                {
                    MessageBox.Show("La Orden de Compra no se encuentra autorizada.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                bonActual = Convert.ToDecimal(dgvDatos.Rows[0].Cells["BONACTUAL"].Value.ToString());

                if (Convert.ToDecimal(this.mtbTotal.Text) >= bonActual)
                {

                }
                else
                {
                    MessageBox.Show("El monto de bonificación debe de ser mayor o igual que " + String.Format("{0,5:###,###.##}", Convert.ToDecimal(dgvDatos.Rows[0].Cells["BONACTUAL"].Value.ToString()))
                        , this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
            }

            if (tbProvee.Text != "" && tbEstilo.Text != "" && mtbNotaCred.Text != " " && mtbSubTotal.Text != "" && mtbPorc.Text != "")
            {
                string OrdenCompra = "";

               GuardarNota();

                if (this.dgvDatos.RowCount > 0)
                {
                    OrdenCompra = dgvDatos.Rows[0].Cells[2].Value.ToString();

                    Negocio.Convenio.Convenio.BonificacionParcial_actualizaNotCre(
                 Convert.ToInt32(OrdenCompra),
                 MmsWin.Front.Utilerias.VarTem.tmpUser);

                }

            }
            else
            {
                MessageBox.Show("No debe quedar en blanco ningun campo");
            }
        }

        private void GuardarNota()
        {
            string TpoMov = "BON";
            string TpoCal = "NOR";
            // Recalculo . . . . .
            System.Data.DataTable dtGuardaNota = null;

            string ParFchBon = tbFchApl.Text;
            ParFchBon = ParFchBon.Substring(8, 2) + ParFchBon.Substring(3, 2) + ParFchBon.Substring(0, 2);
            string ParFchRev = tbFchCal.Text;
            ParFchRev = ParFchRev.Substring(8, 2) + ParFchRev.Substring(3, 2) + ParFchRev.Substring(0, 2);

            string ParProveedor = tbProvee.Text;
            string PartbEstilo = tbEstilo.Text;
            string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
            string ParNotCal = mtbNotaCred.Text;
            string ParSubtot = mtbSubTotal.Text;
            string ParPorc = mtbPorc.Text;
            string varInd1 = "0";
            string varInd2 = "0";


            string ParFechaRcb = "0";
            string ParBodega = "0";
            string ParOrden = "0";
            string ParPzas = "0";

            if (MmsWin.Front.Utilerias.VarTem.tmpBonAntFch != null) { ParFechaRcb = MmsWin.Front.Utilerias.VarTem.tmpBonAntFch; }
            if (MmsWin.Front.Utilerias.VarTem.tmpBonAntBdg != null) { ParBodega = MmsWin.Front.Utilerias.VarTem.tmpBonAntBdg; }
            if (MmsWin.Front.Utilerias.VarTem.tmpBonAntOrd != null) { ParOrden = MmsWin.Front.Utilerias.VarTem.tmpBonAntOrd; }
            if (MmsWin.Front.Utilerias.VarTem.tmpBonAntPza != null) { ParPzas = MmsWin.Front.Utilerias.VarTem.tmpBonAntPza; }

            ParSubtot = ParSubtot.Replace(".", "");
            ParSubtot = ParSubtot.Replace(",", "");
            ParPorc = ParPorc.Replace(".", "");

            dtGuardaNota = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().GuardaNotaAnt(ParFchBon, ParFchRev, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, ParPorc, varInd1, varInd2, TpoMov, ParFechaRcb, ParBodega, ParOrden, ParPzas, TpoCal);

            if (dtGuardaNota.Rows.Count > 0)
            {
                foreach (DataRow row in dtGuardaNota.Rows)
                {
                    mtbSubTotal.Text = string.Format("{0:n2}", double.Parse(row["NOTSUB"].ToString()));
                    mtbIva.Text = string.Format("{0:n2}", double.Parse(row["NOTIVA"].ToString()));
                    mtbTotal.Text = string.Format("{0:n2}", double.Parse(row["NOTTOT"].ToString()));
                    mtbCosto.Text = string.Format("{0:n2}", double.Parse(row["NOTCST"].ToString()));
                    mtbPrecio.Text = string.Format("{0:n2}", double.Parse(row["NOTPRC"].ToString()));
                    mtbMargen.Text = string.Format("{0:n2}", double.Parse(row["NOTMRG"].ToString()));
                    varInd1 = row["NOTIN1"].ToString();
                    varInd2 = row["NOTIN2"].ToString();

                    if (varInd1 == "1" && varInd2 == "0")
                    {
                        MessageBox.Show("Se guardó la Nota de Crédito exitosamente");
                        this.Close();
                    }
                    else
                    {
                        if (varInd2 == "1")
                        {
                            string message = "Ya existe La Nota de Crédito, Haz Click en (Si) para remplazar ";
                            string caption = "Aviso";
                            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                            DialogResult result;
                            result = MessageBox.Show(message, caption, buttons);
                            if (result == System.Windows.Forms.DialogResult.Yes)
                            {
                                varInd1 = "2";
                                varInd2 = "2";

                                MmsWin.Negocio.Utilerias.Utilerias.GetInstance().GuardaNotaAnt(ParFchBon, ParFchRev, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, ParPorc, varInd1, varInd2, TpoMov, ParFechaRcb, ParBodega, ParOrden, ParPzas, TpoCal);
                                MessageBox.Show("Se actualizo la Nota de Crédito exitosamente");
                                this.Close();
                            }
                        }
                    }
                }
            }
            mtbSubTotal.Enabled = false;   // Bloquea Numero de Nota de Crédito 
        }

        private void tbProvee_Leave(object sender, EventArgs e)
        {
            BkEstiloBonAnt();
            string ParPrv = tbProvee.Text;
            string ParSty = tbEstilo.Text;
            ObtenEstilo(ParPrv, ParSty);
            BindRecibos();

            EnableGuardar();
        }

        private void tbEstilo_Leave(object sender, EventArgs e)
        {
            BkEstiloBonAnt();
            string ParPrv = tbProvee.Text;
            string ParSty = tbEstilo.Text;
            ObtenEstilo(ParPrv, ParSty);
            BindRecibos();

            EnableGuardar();
        }

        private void mtbNotaCred_Leave(object sender, EventArgs e)
        {
            string ParPrv = tbProvee.Text;
            string ParSty = tbEstilo.Text;
            ObtenEstilo(ParPrv, ParSty);


            EnableGuardar();
        }

        private void mtbSubTotal_Leave(object sender, EventArgs e)
        {
            string ParPrv = tbProvee.Text;
            string ParSty = tbEstilo.Text;
            ObtenEstilo(ParPrv, ParSty);
            CalculaSubTot();
            EnableGuardar();
        }

        private void mtbPorc_Leave(object sender, EventArgs e)
        {
            string ParPrv = tbProvee.Text;
            string ParSty = tbEstilo.Text;
            ObtenEstilo(ParPrv, ParSty);

            EnableGuardar();
        }

        private void EnableGuardar()
        {
            if (tbProvee.Text != "" && tbEstilo.Text != "" && mtbNotaCred.Text != "" && mtbSubTotal.Text != "" && mtbPorc.Text != "")
            { btnGuardar.Enabled = true; }
            else
            {
                btnGuardar.Enabled = false;
            }
        }

        private void ObtenEstilo(string ParPrv, string ParSty)
        {
            if (ParPrv != "" && ParSty != "")
            {
                tbNombre.Text = "";
                tbDescripcion.Text = "";

                System.Data.DataTable tbEstilo = null;

                tbEstilo = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenEstilo(ParPrv, ParSty);

                try
                {
                    if (tbEstilo.Rows.Count > 0)
                    {
                        foreach (DataRow row in tbEstilo.Rows)
                        {
                            tbNombre.Text = row["ASNAME"].ToString();
                            tbDescripcion.Text = row["SSTYLE"].ToString();
                        }
                        ObtenPrcCst(ParPrv, ParSty);
                    }
                }
                catch { }

                if (tbNombre.Text == "")
                {
                    MessageBox.Show("No esxiste la combinacion Proveedor Estilo");
                }

            }
        }

        private void ObtenPrcCst(string ParPrv, string ParSty)
        {
            if (ParPrv != "" && ParSty != "")
            {
                mtbCosto.Text = "";
                mtbPrecio.Text = "";

                System.Data.DataTable tbPrcCst = null;

                tbPrcCst = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenPrcCst(ParPrv, ParSty);

                try
                {
                    if (tbPrcCst.Rows.Count > 0)
                    {
                        foreach (DataRow row in tbPrcCst.Rows)
                        {
                            mtbCosto.Text = row["CST"].ToString();
                            mtbPrecio.Text = row["PRC"].ToString();
                        }
                    }
                }
                catch { }

                if (tbNombre.Text == "")
                {
                    MessageBox.Show("No esxiste el Precio Costo para este proveedor estilo");
                }

            }
        }

        private void CalculaSubTot()
        {
            if (mtbSubTotal.Text != "")
            {
                double Por = .16;
                double SubTot = Convert.ToDouble(mtbSubTotal.Text);
                double Iva = (SubTot * Por);
                double Tot = SubTot + Iva;
                mtbIva.Text = Convert.ToString(Iva);
                mtbTotal.Text = Convert.ToString(Tot);
            }
        }

        private void mtbSubTotal_GiveFeedback(object sender, GiveFeedbackEventArgs e)
        {

        }

        private void tbProvee_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (tbProvee.Text != "")
                {
                    BkEstiloBonAnt();
                    string ParPrv = tbProvee.Text;
                    string ParSty = tbEstilo.Text;
                    ObtenEstilo(ParPrv, ParSty);
                    BindRecibos();

                    EnableGuardar();
                }
                else
                {
                    MessageBox.Show("No debe quedar en blanco el proveedor...");
                }
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (tbEstilo.Text != "")
                {
                    BkEstiloBonAnt();
                    string ParPrv = tbProvee.Text;
                    string ParSty = tbEstilo.Text;
                    ObtenEstilo(ParPrv, ParSty);
                    BindRecibos();

                    EnableGuardar();
                    mtbNotaCred.Focus();
                }
                else
                {
                    MessageBox.Show("No debe quedar en blanco el estilo...");
                }
            }
        }

        private void mtbNotaCred_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (mtbNotaCred.Text != "")
                {
                    string ParPrv = tbProvee.Text;
                    string ParSty = tbEstilo.Text;
                    ObtenEstilo(ParPrv, ParSty);

                    EnableGuardar();

                    mtbSubTotal.Focus();
                }
                else
                {
                    MessageBox.Show("No debe quedar en blanco el número de nota...");
                }
            }
        }

        private void mtbSubTotal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (mtbSubTotal.Text != "")
                {
                    string ParPrv = tbProvee.Text;
                    string ParSty = tbEstilo.Text;
                    ObtenEstilo(ParPrv, ParSty);

                    EnableGuardar();
                    mtbPorc.Focus();
                }
                else
                {
                    MessageBox.Show("No debe quedar en blanco el Subtotal...");
                }
            }
        }

        private void mtbPorc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (mtbPorc.Text != "")
                {
                    string ParPrv = tbProvee.Text;
                    string ParSty = tbEstilo.Text;
                    ObtenEstilo(ParPrv, ParSty);

                    EnableGuardar();

                    ValidaProcentaje();
                }
                else
                {
                    MessageBox.Show("No debe quedar en blanco el porcentaje de descuento...");
                }
            }
        }

        private void ValidaProcentaje()
        {
            try
            {
                double ValPor = Convert.ToDouble(mtbPorc.Text);
                if (ValPor > .0 && ValPor < 1)
                { }
                else
                {
                    MessageBox.Show("El Porcentaje es incorrecto...");
                    mtbPorc.Text = "";
                    mtbPorc.Focus();
                }
            }
            catch
            {
                mtbPorc.Text = "";
                MessageBox.Show("El Porcentaje es incorrecto...");
                mtbPorc.Focus();
            }

            //mtbPorc.Mask = ".0000%";
        }

        private void tbFechaRecibo_Click(object sender, EventArgs e)
        {
            //    Recibos i = new Recibos();
            //    i.Show();
        }

        private void BkEstiloBonAnt()
        {
            MmsWin.Front.Utilerias.VarTem.tmpBonAntPrv = tbProvee.Text;
            MmsWin.Front.Utilerias.VarTem.tmpBonAntSty = tbEstilo.Text;
        }

        private void BindRecibos()
        {
            nr = 0;
            this.Cursor = Cursors.WaitCursor;
            dgvDataGridView.DataSource = null;
            System.Data.DataTable dtRecibos = null;
            try
            {
                string ParPrv = MmsWin.Front.Utilerias.VarTem.tmpBonAntPrv;
                string ParSty = MmsWin.Front.Utilerias.VarTem.tmpBonAntSty;

                dtRecibos = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenRecibos(ParPrv, ParSty);

                if (dtRecibos != null)
                {
                    if (dtRecibos.Rows.Count > 0)
                    {
                        dgvDataGridView.DataSource = dtRecibos;
                        SetFontAndColors();
                        rowStyle();
                        SetDoubleBuffered(dgvDataGridView);

                        nr = dgvDataGridView.RowCount;
                        this.Text = "Numero de veces Recibido / " + " " + (nr).ToString() + " Registro(s)";

                    }
                }
                this.Cursor = Cursors.Default;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        private void SetFontAndColors()
        {
            this.dgvDataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvDataGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvDataGridView.EnableHeadersVisualStyles = false;
            this.dgvDataGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvDataGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvDataGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvDataGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvDataGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
            //this.dgvDataGridView.Columns[3].Frozen = true;
            dgvDataGridView.RowHeadersVisible = false;

            dgvDataGridView.Columns[0].HeaderText = "Fecha Recibo";
            dgvDataGridView.Columns[1].HeaderText = "Bodega";
            dgvDataGridView.Columns[2].HeaderText = "Orden";
            dgvDataGridView.Columns[3].HeaderText = "Piezas";

            dgvDataGridView.Columns[0].Width = 80;
            dgvDataGridView.Columns[1].Width = 60;
            dgvDataGridView.Columns[2].Width = 80;
            dgvDataGridView.Columns[3].Width = 70;

            dgvDataGridView.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDataGridView.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDataGridView.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDataGridView.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgvDataGridView.Columns[0].DefaultCellStyle.Format = "20##-##-##";
            dgvDataGridView.Columns[1].DefaultCellStyle.Format = "#####";
            dgvDataGridView.Columns[2].DefaultCellStyle.Format = "##########";
            dgvDataGridView.Columns[3].DefaultCellStyle.Format = "##,###,###";

            dgvDataGridView.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvDataGridView.Columns[1].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvDataGridView.Columns[2].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvDataGridView.Columns[3].HeaderCell.Style.BackColor = Color.LightSkyBlue;

            // dgvDoctos.Columns[13].Visible = false;
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvDataGridView.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvDataGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.LightGray;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }

        private void dgvDataGridView_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                DatosRecibo();
            }
        }

        private void dgvDataGridView_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            DatosRecibo();
        }

        private void DatosRecibo()
        {
            tbFechaRecibo.Text = this.dgvDataGridView.CurrentRow.Cells[0].Value.ToString();
            FechaCal = tbFechaRecibo.Text;
            tbFechaRecibo.Text = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
            tbBodega.Text = this.dgvDataGridView.CurrentRow.Cells[1].Value.ToString();
            tbOrden.Text = this.dgvDataGridView.CurrentRow.Cells[2].Value.ToString();
            tbPiezas.Text = string.Format("{0:n0}", double.Parse(this.dgvDataGridView.CurrentRow.Cells[3].Value.ToString()));

            MmsWin.Front.Utilerias.VarTem.tmpBonAntFch = this.dgvDataGridView.CurrentRow.Cells[0].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpBonAntBdg = this.dgvDataGridView.CurrentRow.Cells[1].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpBonAntOrd = this.dgvDataGridView.CurrentRow.Cells[2].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpBonAntPza = this.dgvDataGridView.CurrentRow.Cells[3].Value.ToString();
        }

        private void tbOrden_TextChanged(object sender, EventArgs e)
        {
            DataTable dtbDatos = new DataTable();

            dtbDatos = Negocio.Convenio.Convenio.CargaLSTBonPar(Convert.ToInt32(this.tbOrden.Text));
            this.dgvDatos.DataSource = dtbDatos;

            dgvDatos.Columns["FOLIOS"].HeaderText = "#";
            dgvDatos.Columns["FOLIOS"].ToolTipText = "FOLIO DE AUTORIZACIÓN";
            dgvDatos.Columns["FOLIOS"].Width = 20;
            dgvDatos.Columns["FOLIOS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDatos.Columns["FOLIOS"].DefaultCellStyle.Format = "###,###,###,###";

            dgvDatos.Columns["ESTA"].HeaderText = "S";
            dgvDatos.Columns["ESTA"].ToolTipText = "ESTATUS DE LA AUTORIZACIÓN";
            dgvDatos.Columns["ESTA"].Width = 20;
            dgvDatos.Columns["ESTA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvDatos.Columns["PROV"].HeaderText = "PROV";
            dgvDatos.Columns["PROV"].ToolTipText = "PROVEEDOR";
            dgvDatos.Columns["PROV"].Width = 50;
            dgvDatos.Columns["PROV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;


            dgvDatos.Columns["ORDCOM"].HeaderText = "OC";
            dgvDatos.Columns["ORDCOM"].ToolTipText = "ORDEN DE COMPRA";
            dgvDatos.Columns["ORDCOM"].Width = 60;
            dgvDatos.Columns["ORDCOM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvDatos.Columns["EST"].HeaderText = "EST";
            dgvDatos.Columns["EST"].ToolTipText = "ESTILO";
            dgvDatos.Columns["EST"].Width = 50;
            dgvDatos.Columns["EST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvDatos.Columns["ONHAND"].HeaderText = "OH";
            dgvDatos.Columns["ONHAND"].ToolTipText = "ONHAND";
            dgvDatos.Columns["ONHAND"].Width = 40;
            dgvDatos.Columns["ONHAND"].DefaultCellStyle.Format = "###,###,###,###";
            dgvDatos.Columns["ONHAND"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgvDatos.Columns["COSTO"].HeaderText = "CST";
            dgvDatos.Columns["COSTO"].ToolTipText = "COSTO";
            dgvDatos.Columns["COSTO"].Width = 60;
            dgvDatos.Columns["COSTO"].DefaultCellStyle.Format = "###,###,###,###.00";
            dgvDatos.Columns["COSTO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgvDatos.Columns["BONORIGINAL"].HeaderText = "BONIF";
            dgvDatos.Columns["BONORIGINAL"].ToolTipText = "BONIFICACIÓN ORIGINAL";
            dgvDatos.Columns["BONORIGINAL"].Width = 60;
            dgvDatos.Columns["BONORIGINAL"].DefaultCellStyle.Format = "###,###,###,###.00";
            dgvDatos.Columns["BONORIGINAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvDatos.Columns["BONORIGINAL"].Visible = false;


            dgvDatos.Columns["BONACTUAL"].HeaderText = "BONIF";
            dgvDatos.Columns["BONACTUAL"].ToolTipText = "BONIFICACIÓN ACTUAL";
            dgvDatos.Columns["BONACTUAL"].Width = 60;
            dgvDatos.Columns["BONACTUAL"].DefaultCellStyle.Format = "###,###,###,###.00";
            dgvDatos.Columns["BONACTUAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

        }
    }
}
