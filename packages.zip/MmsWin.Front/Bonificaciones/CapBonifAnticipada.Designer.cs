﻿namespace MmsWin.Front.Bonificaciones
{
    partial class CapBonifAnticipada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.gbNota = new System.Windows.Forms.GroupBox();
            this.dgvDatos = new System.Windows.Forms.DataGridView();
            this.tbPiezas = new System.Windows.Forms.TextBox();
            this.lbPiezas = new System.Windows.Forms.Label();
            this.lbOrden = new System.Windows.Forms.Label();
            this.mtbPorc = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lbBodega = new System.Windows.Forms.Label();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbFechaRecibo = new System.Windows.Forms.TextBox();
            this.lbFechaRecibo = new System.Windows.Forms.Label();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbBodega = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbOrden = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbFchCal = new System.Windows.Forms.TextBox();
            this.tbFchApl = new System.Windows.Forms.TextBox();
            this.tbProvee = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.mtbNotaCred = new System.Windows.Forms.TextBox();
            this.lblMargen = new System.Windows.Forms.Label();
            this.mtbIva = new System.Windows.Forms.MaskedTextBox();
            this.LblNota = new System.Windows.Forms.Label();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.lblCosto = new System.Windows.Forms.Label();
            this.mtbSubTotal = new System.Windows.Forms.MaskedTextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.mtbTotal = new System.Windows.Forms.MaskedTextBox();
            this.lblIva = new System.Windows.Forms.Label();
            this.lblSubTot = new System.Windows.Forms.Label();
            this.mtbMargen = new System.Windows.Forms.MaskedTextBox();
            this.mtbPrecio = new System.Windows.Forms.MaskedTextBox();
            this.mtbCosto = new System.Windows.Forms.MaskedTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dgvDataGridView = new System.Windows.Forms.DataGridView();
            this.gbNota.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGuardar
            // 
            this.btnGuardar.Enabled = false;
            this.btnGuardar.Location = new System.Drawing.Point(300, 467);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 2;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(70, 467);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 1;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // gbNota
            // 
            this.gbNota.Controls.Add(this.dgvDatos);
            this.gbNota.Controls.Add(this.tbPiezas);
            this.gbNota.Controls.Add(this.lbPiezas);
            this.gbNota.Controls.Add(this.lbOrden);
            this.gbNota.Controls.Add(this.mtbPorc);
            this.gbNota.Controls.Add(this.label7);
            this.gbNota.Controls.Add(this.lbBodega);
            this.gbNota.Controls.Add(this.tbDescripcion);
            this.gbNota.Controls.Add(this.tbFechaRecibo);
            this.gbNota.Controls.Add(this.lbFechaRecibo);
            this.gbNota.Controls.Add(this.tbEstilo);
            this.gbNota.Controls.Add(this.tbBodega);
            this.gbNota.Controls.Add(this.tbNombre);
            this.gbNota.Controls.Add(this.tbOrden);
            this.gbNota.Controls.Add(this.label6);
            this.gbNota.Controls.Add(this.label5);
            this.gbNota.Controls.Add(this.label4);
            this.gbNota.Controls.Add(this.tbFchCal);
            this.gbNota.Controls.Add(this.tbFchApl);
            this.gbNota.Controls.Add(this.tbProvee);
            this.gbNota.Controls.Add(this.label3);
            this.gbNota.Controls.Add(this.label2);
            this.gbNota.Controls.Add(this.label1);
            this.gbNota.Controls.Add(this.mtbNotaCred);
            this.gbNota.Controls.Add(this.lblMargen);
            this.gbNota.Controls.Add(this.mtbIva);
            this.gbNota.Controls.Add(this.LblNota);
            this.gbNota.Controls.Add(this.lblPrecio);
            this.gbNota.Controls.Add(this.lblCosto);
            this.gbNota.Controls.Add(this.mtbSubTotal);
            this.gbNota.Controls.Add(this.lblTotal);
            this.gbNota.Controls.Add(this.mtbTotal);
            this.gbNota.Controls.Add(this.lblIva);
            this.gbNota.Controls.Add(this.lblSubTot);
            this.gbNota.Controls.Add(this.mtbMargen);
            this.gbNota.Controls.Add(this.mtbPrecio);
            this.gbNota.Controls.Add(this.mtbCosto);
            this.gbNota.Location = new System.Drawing.Point(25, 20);
            this.gbNota.Name = "gbNota";
            this.gbNota.Size = new System.Drawing.Size(717, 433);
            this.gbNota.TabIndex = 0;
            this.gbNota.TabStop = false;
            this.gbNota.Text = "Bonificacion Anticipada";
            // 
            // dgvDatos
            // 
            this.dgvDatos.AllowUserToAddRows = false;
            this.dgvDatos.AllowUserToDeleteRows = false;
            this.dgvDatos.AllowUserToOrderColumns = true;
            this.dgvDatos.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.dgvDatos.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dgvDatos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dgvDatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDatos.Location = new System.Drawing.Point(323, 356);
            this.dgvDatos.MultiSelect = false;
            this.dgvDatos.Name = "dgvDatos";
            this.dgvDatos.ReadOnly = true;
            this.dgvDatos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDatos.Size = new System.Drawing.Size(385, 64);
            this.dgvDatos.TabIndex = 40;
            // 
            // tbPiezas
            // 
            this.tbPiezas.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbPiezas.Enabled = false;
            this.tbPiezas.Location = new System.Drawing.Point(127, 225);
            this.tbPiezas.Name = "tbPiezas";
            this.tbPiezas.Size = new System.Drawing.Size(100, 20);
            this.tbPiezas.TabIndex = 38;
            this.tbPiezas.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbPiezas
            // 
            this.lbPiezas.AutoSize = true;
            this.lbPiezas.BackColor = System.Drawing.Color.DarkGray;
            this.lbPiezas.Location = new System.Drawing.Point(18, 229);
            this.lbPiezas.Name = "lbPiezas";
            this.lbPiezas.Size = new System.Drawing.Size(38, 13);
            this.lbPiezas.TabIndex = 37;
            this.lbPiezas.Text = "Piezas";
            // 
            // lbOrden
            // 
            this.lbOrden.AutoSize = true;
            this.lbOrden.BackColor = System.Drawing.Color.DarkGray;
            this.lbOrden.Location = new System.Drawing.Point(18, 207);
            this.lbOrden.Name = "lbOrden";
            this.lbOrden.Size = new System.Drawing.Size(36, 13);
            this.lbOrden.TabIndex = 36;
            this.lbOrden.Text = "Orden";
            // 
            // mtbPorc
            // 
            this.mtbPorc.BackColor = System.Drawing.Color.LightGreen;
            this.mtbPorc.Location = new System.Drawing.Point(127, 334);
            this.mtbPorc.Name = "mtbPorc";
            this.mtbPorc.Size = new System.Drawing.Size(100, 20);
            this.mtbPorc.TabIndex = 4;
            this.mtbPorc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtbPorc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mtbPorc_KeyPress);
            this.mtbPorc.Leave += new System.EventHandler(this.mtbPorc_Leave);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.LightGreen;
            this.label7.Location = new System.Drawing.Point(18, 338);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "%  x Aplicar";
            // 
            // lbBodega
            // 
            this.lbBodega.AutoSize = true;
            this.lbBodega.BackColor = System.Drawing.Color.DarkGray;
            this.lbBodega.Location = new System.Drawing.Point(18, 185);
            this.lbBodega.Name = "lbBodega";
            this.lbBodega.Size = new System.Drawing.Size(44, 13);
            this.lbBodega.TabIndex = 35;
            this.lbBodega.Text = "Bodega";
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDescripcion.Enabled = false;
            this.tbDescripcion.Location = new System.Drawing.Point(127, 136);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(190, 20);
            this.tbDescripcion.TabIndex = 10;
            // 
            // tbFechaRecibo
            // 
            this.tbFechaRecibo.BackColor = System.Drawing.SystemColors.Window;
            this.tbFechaRecibo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbFechaRecibo.Enabled = false;
            this.tbFechaRecibo.Location = new System.Drawing.Point(127, 159);
            this.tbFechaRecibo.Name = "tbFechaRecibo";
            this.tbFechaRecibo.Size = new System.Drawing.Size(100, 20);
            this.tbFechaRecibo.TabIndex = 31;
            this.tbFechaRecibo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbFechaRecibo.Click += new System.EventHandler(this.tbFechaRecibo_Click);
            // 
            // lbFechaRecibo
            // 
            this.lbFechaRecibo.AutoSize = true;
            this.lbFechaRecibo.BackColor = System.Drawing.Color.DarkGray;
            this.lbFechaRecibo.Location = new System.Drawing.Point(18, 163);
            this.lbFechaRecibo.Name = "lbFechaRecibo";
            this.lbFechaRecibo.Size = new System.Drawing.Size(74, 13);
            this.lbFechaRecibo.TabIndex = 34;
            this.lbFechaRecibo.Text = "Fecha Recibo";
            // 
            // tbEstilo
            // 
            this.tbEstilo.BackColor = System.Drawing.Color.LightGreen;
            this.tbEstilo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbEstilo.Location = new System.Drawing.Point(127, 114);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(100, 20);
            this.tbEstilo.TabIndex = 1;
            this.tbEstilo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbEstilo_KeyPress);
            this.tbEstilo.Leave += new System.EventHandler(this.tbEstilo_Leave);
            // 
            // tbBodega
            // 
            this.tbBodega.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbBodega.Enabled = false;
            this.tbBodega.Location = new System.Drawing.Point(127, 181);
            this.tbBodega.Name = "tbBodega";
            this.tbBodega.Size = new System.Drawing.Size(100, 20);
            this.tbBodega.TabIndex = 32;
            this.tbBodega.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbNombre
            // 
            this.tbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNombre.Enabled = false;
            this.tbNombre.Location = new System.Drawing.Point(127, 92);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(190, 20);
            this.tbNombre.TabIndex = 3;
            // 
            // tbOrden
            // 
            this.tbOrden.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbOrden.Enabled = false;
            this.tbOrden.Location = new System.Drawing.Point(127, 203);
            this.tbOrden.Name = "tbOrden";
            this.tbOrden.Size = new System.Drawing.Size(100, 20);
            this.tbOrden.TabIndex = 33;
            this.tbOrden.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbOrden.TextChanged += new System.EventHandler(this.tbOrden_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.DarkGray;
            this.label6.Location = new System.Drawing.Point(18, 140);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "Descripción";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.LightGreen;
            this.label5.Location = new System.Drawing.Point(18, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Estilo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.DarkGray;
            this.label4.Location = new System.Drawing.Point(18, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Nombre";
            // 
            // tbFchCal
            // 
            this.tbFchCal.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbFchCal.Enabled = false;
            this.tbFchCal.Location = new System.Drawing.Point(127, 26);
            this.tbFchCal.Name = "tbFchCal";
            this.tbFchCal.Size = new System.Drawing.Size(100, 20);
            this.tbFchCal.TabIndex = 0;
            this.tbFchCal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbFchApl
            // 
            this.tbFchApl.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbFchApl.Enabled = false;
            this.tbFchApl.Location = new System.Drawing.Point(127, 48);
            this.tbFchApl.Name = "tbFchApl";
            this.tbFchApl.Size = new System.Drawing.Size(100, 20);
            this.tbFchApl.TabIndex = 1;
            this.tbFchApl.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbProvee
            // 
            this.tbProvee.BackColor = System.Drawing.Color.LightGreen;
            this.tbProvee.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbProvee.Location = new System.Drawing.Point(127, 70);
            this.tbProvee.Name = "tbProvee";
            this.tbProvee.Size = new System.Drawing.Size(100, 20);
            this.tbProvee.TabIndex = 0;
            this.tbProvee.WordWrap = false;
            this.tbProvee.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbProvee_KeyPress);
            this.tbProvee.Leave += new System.EventHandler(this.tbProvee_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.LightGreen;
            this.label3.Location = new System.Drawing.Point(18, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Proveedor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkGray;
            this.label2.Location = new System.Drawing.Point(17, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Fecha Bonificacion  ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkGray;
            this.label1.Location = new System.Drawing.Point(18, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Fecha Revisión";
            // 
            // mtbNotaCred
            // 
            this.mtbNotaCred.BackColor = System.Drawing.Color.LightGreen;
            this.mtbNotaCred.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.mtbNotaCred.Location = new System.Drawing.Point(127, 247);
            this.mtbNotaCred.Name = "mtbNotaCred";
            this.mtbNotaCred.Size = new System.Drawing.Size(100, 20);
            this.mtbNotaCred.TabIndex = 2;
            this.mtbNotaCred.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mtbNotaCred_KeyPress);
            this.mtbNotaCred.Leave += new System.EventHandler(this.mtbNotaCred_Leave);
            // 
            // lblMargen
            // 
            this.lblMargen.AutoSize = true;
            this.lblMargen.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblMargen.Location = new System.Drawing.Point(18, 404);
            this.lblMargen.Name = "lblMargen";
            this.lblMargen.Size = new System.Drawing.Size(85, 13);
            this.lblMargen.TabIndex = 25;
            this.lblMargen.Text = "Margen              ";
            // 
            // mtbIva
            // 
            this.mtbIva.Enabled = false;
            this.mtbIva.Location = new System.Drawing.Point(127, 290);
            this.mtbIva.Name = "mtbIva";
            this.mtbIva.Size = new System.Drawing.Size(100, 20);
            this.mtbIva.TabIndex = 7;
            this.mtbIva.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // LblNota
            // 
            this.LblNota.AutoSize = true;
            this.LblNota.BackColor = System.Drawing.Color.LightGreen;
            this.LblNota.Location = new System.Drawing.Point(18, 250);
            this.LblNota.Name = "LblNota";
            this.LblNota.Size = new System.Drawing.Size(87, 13);
            this.LblNota.TabIndex = 19;
            this.LblNota.Text = "Nota de Credito  ";
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblPrecio.Location = new System.Drawing.Point(18, 382);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(85, 13);
            this.lblPrecio.TabIndex = 24;
            this.lblPrecio.Text = "Precio                ";
            // 
            // lblCosto
            // 
            this.lblCosto.AutoSize = true;
            this.lblCosto.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblCosto.Location = new System.Drawing.Point(18, 360);
            this.lblCosto.Name = "lblCosto";
            this.lblCosto.Size = new System.Drawing.Size(85, 13);
            this.lblCosto.TabIndex = 23;
            this.lblCosto.Text = "Costo                 ";
            // 
            // mtbSubTotal
            // 
            this.mtbSubTotal.BackColor = System.Drawing.Color.LightGreen;
            this.mtbSubTotal.Location = new System.Drawing.Point(127, 268);
            this.mtbSubTotal.Name = "mtbSubTotal";
            this.mtbSubTotal.Size = new System.Drawing.Size(100, 20);
            this.mtbSubTotal.TabIndex = 3;
            this.mtbSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtbSubTotal.GiveFeedback += new System.Windows.Forms.GiveFeedbackEventHandler(this.mtbSubTotal_GiveFeedback);
            this.mtbSubTotal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mtbSubTotal_KeyPress);
            this.mtbSubTotal.Leave += new System.EventHandler(this.mtbSubTotal_Leave);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.lblTotal.Location = new System.Drawing.Point(18, 316);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(85, 13);
            this.lblTotal.TabIndex = 22;
            this.lblTotal.Text = "Total                  ";
            // 
            // mtbTotal
            // 
            this.mtbTotal.Enabled = false;
            this.mtbTotal.Location = new System.Drawing.Point(127, 312);
            this.mtbTotal.Name = "mtbTotal";
            this.mtbTotal.Size = new System.Drawing.Size(100, 20);
            this.mtbTotal.TabIndex = 8;
            this.mtbTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblIva
            // 
            this.lblIva.AutoSize = true;
            this.lblIva.BackColor = System.Drawing.Color.DarkGray;
            this.lblIva.Location = new System.Drawing.Point(18, 294);
            this.lblIva.Name = "lblIva";
            this.lblIva.Size = new System.Drawing.Size(85, 13);
            this.lblIva.TabIndex = 21;
            this.lblIva.Text = "Iva                     ";
            // 
            // lblSubTot
            // 
            this.lblSubTot.AutoSize = true;
            this.lblSubTot.BackColor = System.Drawing.Color.LightGreen;
            this.lblSubTot.Location = new System.Drawing.Point(18, 272);
            this.lblSubTot.Name = "lblSubTot";
            this.lblSubTot.Size = new System.Drawing.Size(86, 13);
            this.lblSubTot.TabIndex = 20;
            this.lblSubTot.Text = "Sub Total           ";
            // 
            // mtbMargen
            // 
            this.mtbMargen.Enabled = false;
            this.mtbMargen.Location = new System.Drawing.Point(127, 400);
            this.mtbMargen.Name = "mtbMargen";
            this.mtbMargen.Size = new System.Drawing.Size(100, 20);
            this.mtbMargen.TabIndex = 12;
            this.mtbMargen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPrecio
            // 
            this.mtbPrecio.Enabled = false;
            this.mtbPrecio.Location = new System.Drawing.Point(127, 378);
            this.mtbPrecio.Name = "mtbPrecio";
            this.mtbPrecio.Size = new System.Drawing.Size(100, 20);
            this.mtbPrecio.TabIndex = 11;
            this.mtbPrecio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbCosto
            // 
            this.mtbCosto.Enabled = false;
            this.mtbCosto.Location = new System.Drawing.Point(127, 356);
            this.mtbCosto.Name = "mtbCosto";
            this.mtbCosto.Size = new System.Drawing.Size(100, 20);
            this.mtbCosto.TabIndex = 10;
            this.mtbCosto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.label10.Location = new System.Drawing.Point(485, 467);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(141, 13);
            this.label10.TabIndex = 39;
            this.label10.Text = "Desde 0.0001 Hasta 1.0000";
            this.label10.Visible = false;
            // 
            // dgvDataGridView
            // 
            this.dgvDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDataGridView.Location = new System.Drawing.Point(348, 46);
            this.dgvDataGridView.Name = "dgvDataGridView";
            this.dgvDataGridView.Size = new System.Drawing.Size(385, 324);
            this.dgvDataGridView.TabIndex = 3;
            this.dgvDataGridView.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDataGridView_CellEnter);
            this.dgvDataGridView.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvDataGridView_CellMouseDown);
            // 
            // CapBonifAnticipada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(774, 498);
            this.Controls.Add(this.dgvDataGridView);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.gbNota);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CapBonifAnticipada";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Captura de Bonificiones  Anticipadas";
            this.Load += new System.EventHandler(this.CapBonifAnticipada_Load);
            this.gbNota.ResumeLayout(false);
            this.gbNota.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDatos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.GroupBox gbNota;
        private System.Windows.Forms.MaskedTextBox mtbPorc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbFchCal;
        private System.Windows.Forms.TextBox tbFchApl;
        private System.Windows.Forms.TextBox tbProvee;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox mtbNotaCred;
        private System.Windows.Forms.Label lblMargen;
        private System.Windows.Forms.MaskedTextBox mtbIva;
        private System.Windows.Forms.Label LblNota;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Label lblCosto;
        private System.Windows.Forms.MaskedTextBox mtbSubTotal;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.MaskedTextBox mtbTotal;
        private System.Windows.Forms.Label lblIva;
        private System.Windows.Forms.Label lblSubTot;
        private System.Windows.Forms.MaskedTextBox mtbMargen;
        private System.Windows.Forms.MaskedTextBox mtbPrecio;
        private System.Windows.Forms.MaskedTextBox mtbCosto;
        private System.Windows.Forms.TextBox tbOrden;
        private System.Windows.Forms.TextBox tbBodega;
        private System.Windows.Forms.TextBox tbFechaRecibo;
        private System.Windows.Forms.TextBox tbPiezas;
        private System.Windows.Forms.Label lbPiezas;
        private System.Windows.Forms.Label lbOrden;
        private System.Windows.Forms.Label lbBodega;
        private System.Windows.Forms.Label lbFechaRecibo;
        private System.Windows.Forms.DataGridView dgvDataGridView;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dgvDatos;
    }
}