﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Bonificaciones
{
    public partial class BonificaAnticipada : Form
    {
        //int nr;
        //string ParUser;
        String marca;
        bool Carga = false;
        String comprador;
        string FechaCal;
        string FechaFmt;
        long FechaApli;
        int dgvOffset;
        int dgvOffset2;

        public BonificaAnticipada()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvDataGridView.Width;
            dgvOffset2 = this.Height - dgvDataGridView.Height;
        }

        private void BonificaAnticipada_Load(object sender, EventArgs e)
        {
            Carga = false;
            marca = "999";
            comprador = "999";
            tbCal01.Text = "0000000000";

            // Carga de Marca
            try
            {
                BindMarca();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            // Carga de Compradores
            try
            {
                BindCompradores();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            try
            {
                System.Data.DataTable tbFechaInicial = null;
                tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();

                foreach (DataRow row in tbFechaInicial.Rows)
                {
                    tbCal01.Text = row["DSPFCH"].ToString();
                    FechaCal = tbCal01.Text;
                    FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                    tbCal01.Text = FechaFmt.ToString();
                    FechaApli = long.Parse(FechaCal.ToString());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            comprador = MmsWin.Front.Utilerias.VarTem.tmpUSRCOM;
            cbCompradores.SelectedValue = comprador;
            marca = MmsWin.Front.Utilerias.VarTem.tmpUSRMAR;
            cbMarca.SelectedValue = marca;

        }

        protected void BindMarca()
        {
            try
            {
                cbMarca.DataSource = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();
                cbMarca.DisplayMember = "Value";
                cbMarca.ValueMember = "Key";
                marca = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void BindCompradores()
        {
            try
            {
                cbCompradores.DataSource = MmsWin.Negocio.Catalogos.Compradores.GetInstance().ObtenCompradors().ToList();
                cbCompradores.DisplayMember = "Value";
                cbCompradores.ValueMember = "Key";
                comprador = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void btCaptura_Click(object sender, EventArgs e)
        {
            CapBonifAnticipada i = new CapBonifAnticipada();
            i.Show();
        }

        private void tbCal01_TextChanged(object sender, EventArgs e)
        {

        }

        private void tbCal01_Click(object sender, EventArgs e)
        {
            mcCal01.Visible = true;
        }

        private void mcCal01_DateSelected(object sender, DateRangeEventArgs e)
        {
            string FechaCal;
            string FechaFmt;
            tbCal01.Text = mcCal01.SelectionEnd.ToShortDateString();
            FechaCal = tbCal01.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FechaApli = long.Parse(FechaFmt.ToString());
            mcCal01.Visible = false;

        }

    }
}
