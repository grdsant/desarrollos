﻿namespace MmsWin.Front.Bonificaciones
{
    partial class BonificaAnticipada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BonificaAnticipada));
            this.dgvDataGridView = new System.Windows.Forms.DataGridView();
            this.pbExcel = new System.Windows.Forms.PictureBox();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.cbCompradores = new System.Windows.Forms.ComboBox();
            this.gbMarca = new System.Windows.Forms.GroupBox();
            this.gbComprador = new System.Windows.Forms.GroupBox();
            this.tbCal01 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btCaptura = new System.Windows.Forms.Button();
            this.mcCal01 = new System.Windows.Forms.MonthCalendar();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbExcel)).BeginInit();
            this.gbMarca.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvDataGridView
            // 
            this.dgvDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDataGridView.Location = new System.Drawing.Point(3, 55);
            this.dgvDataGridView.Name = "dgvDataGridView";
            this.dgvDataGridView.Size = new System.Drawing.Size(1145, 451);
            this.dgvDataGridView.TabIndex = 0;
            // 
            // pbExcel
            // 
            this.pbExcel.Image = ((System.Drawing.Image)(resources.GetObject("pbExcel.Image")));
            this.pbExcel.Location = new System.Drawing.Point(3, 0);
            this.pbExcel.Name = "pbExcel";
            this.pbExcel.Size = new System.Drawing.Size(65, 47);
            this.pbExcel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbExcel.TabIndex = 10;
            this.pbExcel.TabStop = false;
            // 
            // cbMarca
            // 
            this.cbMarca.Location = new System.Drawing.Point(24, 13);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(74, 21);
            this.cbMarca.TabIndex = 2;
            // 
            // cbCompradores
            // 
            this.cbCompradores.FormattingEnabled = true;
            this.cbCompradores.Location = new System.Drawing.Point(218, 18);
            this.cbCompradores.Name = "cbCompradores";
            this.cbCompradores.Size = new System.Drawing.Size(168, 21);
            this.cbCompradores.TabIndex = 18;
            // 
            // gbMarca
            // 
            this.gbMarca.Controls.Add(this.cbMarca);
            this.gbMarca.Location = new System.Drawing.Point(71, 5);
            this.gbMarca.Name = "gbMarca";
            this.gbMarca.Size = new System.Drawing.Size(113, 40);
            this.gbMarca.TabIndex = 17;
            this.gbMarca.TabStop = false;
            this.gbMarca.Text = "Marca";
            // 
            // gbComprador
            // 
            this.gbComprador.Location = new System.Drawing.Point(200, 5);
            this.gbComprador.Name = "gbComprador";
            this.gbComprador.Size = new System.Drawing.Size(203, 40);
            this.gbComprador.TabIndex = 19;
            this.gbComprador.TabStop = false;
            this.gbComprador.Text = "Comprador";
            // 
            // tbCal01
            // 
            this.tbCal01.Location = new System.Drawing.Point(6, 13);
            this.tbCal01.Name = "tbCal01";
            this.tbCal01.ReadOnly = true;
            this.tbCal01.Size = new System.Drawing.Size(92, 20);
            this.tbCal01.TabIndex = 17;
            this.tbCal01.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbCal01.Click += new System.EventHandler(this.tbCal01_Click);
            this.tbCal01.TextChanged += new System.EventHandler(this.tbCal01_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbCal01);
            this.groupBox1.Location = new System.Drawing.Point(409, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(104, 40);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Historia";
            // 
            // btCaptura
            // 
            this.btCaptura.Location = new System.Drawing.Point(541, 11);
            this.btCaptura.Name = "btCaptura";
            this.btCaptura.Size = new System.Drawing.Size(75, 30);
            this.btCaptura.TabIndex = 21;
            this.btCaptura.Text = "Captura";
            this.btCaptura.UseVisualStyleBackColor = true;
            this.btCaptura.Click += new System.EventHandler(this.btCaptura_Click);
            // 
            // mcCal01
            // 
            this.mcCal01.BackColor = System.Drawing.Color.Gray;
            this.mcCal01.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.mcCal01.Location = new System.Drawing.Point(342, 57);
            this.mcCal01.Name = "mcCal01";
            this.mcCal01.TabIndex = 19;
            this.mcCal01.Visible = false;
            this.mcCal01.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcCal01_DateSelected);
            // 
            // BonificaAnticipada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1152, 518);
            this.Controls.Add(this.mcCal01);
            this.Controls.Add(this.dgvDataGridView);
            this.Controls.Add(this.btCaptura);
            this.Controls.Add(this.cbCompradores);
            this.Controls.Add(this.gbMarca);
            this.Controls.Add(this.gbComprador);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pbExcel);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BonificaAnticipada";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.BonificaAnticipada_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbExcel)).EndInit();
            this.gbMarca.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDataGridView;
        private System.Windows.Forms.PictureBox pbExcel;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.ComboBox cbCompradores;
        private System.Windows.Forms.GroupBox gbMarca;
        private System.Windows.Forms.GroupBox gbComprador;
        private System.Windows.Forms.TextBox tbCal01;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btCaptura;
        private System.Windows.Forms.MonthCalendar mcCal01;

    }
}