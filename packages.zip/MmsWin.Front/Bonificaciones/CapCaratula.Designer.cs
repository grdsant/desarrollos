﻿namespace MmsWin.Front.Bonificaciones
{
    partial class CapCaratula
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbFchBonifica = new System.Windows.Forms.Label();
            this.lbFchRecibo = new System.Windows.Forms.Label();
            this.lblFchCalificacion = new System.Windows.Forms.Label();
            this.lbClavePromocion = new System.Windows.Forms.Label();
            this.lbClaveOrigen = new System.Windows.Forms.Label();
            this.lbDescripcionProm = new System.Windows.Forms.Label();
            this.lbTipo950o955 = new System.Windows.Forms.Label();
            this.lbFechaEfectiva = new System.Windows.Forms.Label();
            this.lbFechaCaptura = new System.Windows.Forms.Label();
            this.lbHoraCaptura = new System.Windows.Forms.Label();
            this.lbUsuario = new System.Windows.Forms.Label();
            this.lbEstatus = new System.Windows.Forms.Label();
            this.tbFchBonifica = new System.Windows.Forms.TextBox();
            this.tbFchRecibo = new System.Windows.Forms.TextBox();
            this.tbFechaCalifica = new System.Windows.Forms.TextBox();
            this.tbClavePromo = new System.Windows.Forms.TextBox();
            this.tbClaveOrigen = new System.Windows.Forms.TextBox();
            this.tbDescripcionProm = new System.Windows.Forms.TextBox();
            this.tbTipo950o955 = new System.Windows.Forms.TextBox();
            this.tbFechaEfectiva = new System.Windows.Forms.TextBox();
            this.tbFechaCaptura = new System.Windows.Forms.TextBox();
            this.tbHoraCaptura = new System.Windows.Forms.TextBox();
            this.tbUsuario = new System.Windows.Forms.TextBox();
            this.tbEstatus = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbFchBonifica
            // 
            this.lbFchBonifica.AutoSize = true;
            this.lbFchBonifica.Location = new System.Drawing.Point(25, 20);
            this.lbFchBonifica.Name = "lbFchBonifica";
            this.lbFchBonifica.Size = new System.Drawing.Size(113, 13);
            this.lbFchBonifica.TabIndex = 0;
            this.lbFchBonifica.Text = "Fecha de Bonificacion";
            // 
            // lbFchRecibo
            // 
            this.lbFchRecibo.AutoSize = true;
            this.lbFchRecibo.Location = new System.Drawing.Point(25, 50);
            this.lbFchRecibo.Name = "lbFchRecibo";
            this.lbFchRecibo.Size = new System.Drawing.Size(89, 13);
            this.lbFchRecibo.TabIndex = 1;
            this.lbFchRecibo.Text = "Fecha de Recibo";
            // 
            // lblFchCalificacion
            // 
            this.lblFchCalificacion.AutoSize = true;
            this.lblFchCalificacion.Location = new System.Drawing.Point(25, 80);
            this.lblFchCalificacion.Name = "lblFchCalificacion";
            this.lblFchCalificacion.Size = new System.Drawing.Size(103, 13);
            this.lblFchCalificacion.TabIndex = 2;
            this.lblFchCalificacion.Text = "Fecha de Calificaion";
            // 
            // lbClavePromocion
            // 
            this.lbClavePromocion.AutoSize = true;
            this.lbClavePromocion.Location = new System.Drawing.Point(25, 110);
            this.lbClavePromocion.Name = "lbClavePromocion";
            this.lbClavePromocion.Size = new System.Drawing.Size(102, 13);
            this.lbClavePromocion.TabIndex = 3;
            this.lbClavePromocion.Text = "Clave de Promocion";
            // 
            // lbClaveOrigen
            // 
            this.lbClaveOrigen.AutoSize = true;
            this.lbClaveOrigen.Location = new System.Drawing.Point(25, 140);
            this.lbClaveOrigen.Name = "lbClaveOrigen";
            this.lbClaveOrigen.Size = new System.Drawing.Size(68, 13);
            this.lbClaveOrigen.TabIndex = 4;
            this.lbClaveOrigen.Text = "Clave Origen";
            // 
            // lbDescripcionProm
            // 
            this.lbDescripcionProm.AutoSize = true;
            this.lbDescripcionProm.Location = new System.Drawing.Point(25, 170);
            this.lbDescripcionProm.Name = "lbDescripcionProm";
            this.lbDescripcionProm.Size = new System.Drawing.Size(116, 13);
            this.lbDescripcionProm.TabIndex = 5;
            this.lbDescripcionProm.Text = "Descripcion Promocion";
            // 
            // lbTipo950o955
            // 
            this.lbTipo950o955.AutoSize = true;
            this.lbTipo950o955.Location = new System.Drawing.Point(25, 200);
            this.lbTipo950o955.Name = "lbTipo950o955";
            this.lbTipo950o955.Size = new System.Drawing.Size(79, 13);
            this.lbTipo950o955.TabIndex = 6;
            this.lbTipo950o955.Text = "Tipo 950 o 955";
            // 
            // lbFechaEfectiva
            // 
            this.lbFechaEfectiva.AutoSize = true;
            this.lbFechaEfectiva.Location = new System.Drawing.Point(25, 230);
            this.lbFechaEfectiva.Name = "lbFechaEfectiva";
            this.lbFechaEfectiva.Size = new System.Drawing.Size(79, 13);
            this.lbFechaEfectiva.TabIndex = 7;
            this.lbFechaEfectiva.Text = "Fecha Efectiva";
            // 
            // lbFechaCaptura
            // 
            this.lbFechaCaptura.AutoSize = true;
            this.lbFechaCaptura.Location = new System.Drawing.Point(25, 260);
            this.lbFechaCaptura.Name = "lbFechaCaptura";
            this.lbFechaCaptura.Size = new System.Drawing.Size(92, 13);
            this.lbFechaCaptura.TabIndex = 8;
            this.lbFechaCaptura.Text = "Fecha de Captura";
            // 
            // lbHoraCaptura
            // 
            this.lbHoraCaptura.AutoSize = true;
            this.lbHoraCaptura.Location = new System.Drawing.Point(25, 290);
            this.lbHoraCaptura.Name = "lbHoraCaptura";
            this.lbHoraCaptura.Size = new System.Drawing.Size(85, 13);
            this.lbHoraCaptura.TabIndex = 9;
            this.lbHoraCaptura.Text = "Hora de Captura";
            // 
            // lbUsuario
            // 
            this.lbUsuario.AutoSize = true;
            this.lbUsuario.Location = new System.Drawing.Point(25, 320);
            this.lbUsuario.Name = "lbUsuario";
            this.lbUsuario.Size = new System.Drawing.Size(43, 13);
            this.lbUsuario.TabIndex = 10;
            this.lbUsuario.Text = "Usuario";
            // 
            // lbEstatus
            // 
            this.lbEstatus.AutoSize = true;
            this.lbEstatus.Location = new System.Drawing.Point(25, 350);
            this.lbEstatus.Name = "lbEstatus";
            this.lbEstatus.Size = new System.Drawing.Size(42, 13);
            this.lbEstatus.TabIndex = 11;
            this.lbEstatus.Text = "Estatus";
            // 
            // tbFchBonifica
            // 
            this.tbFchBonifica.Location = new System.Drawing.Point(144, 20);
            this.tbFchBonifica.Name = "tbFchBonifica";
            this.tbFchBonifica.Size = new System.Drawing.Size(100, 20);
            this.tbFchBonifica.TabIndex = 12;
            // 
            // tbFchRecibo
            // 
            this.tbFchRecibo.Location = new System.Drawing.Point(144, 50);
            this.tbFchRecibo.Name = "tbFchRecibo";
            this.tbFchRecibo.Size = new System.Drawing.Size(100, 20);
            this.tbFchRecibo.TabIndex = 13;
            // 
            // tbFechaCalifica
            // 
            this.tbFechaCalifica.Location = new System.Drawing.Point(144, 80);
            this.tbFechaCalifica.Name = "tbFechaCalifica";
            this.tbFechaCalifica.Size = new System.Drawing.Size(100, 20);
            this.tbFechaCalifica.TabIndex = 14;
            // 
            // tbClavePromo
            // 
            this.tbClavePromo.Location = new System.Drawing.Point(144, 110);
            this.tbClavePromo.Name = "tbClavePromo";
            this.tbClavePromo.Size = new System.Drawing.Size(100, 20);
            this.tbClavePromo.TabIndex = 15;
            // 
            // tbClaveOrigen
            // 
            this.tbClaveOrigen.Location = new System.Drawing.Point(144, 140);
            this.tbClaveOrigen.Name = "tbClaveOrigen";
            this.tbClaveOrigen.Size = new System.Drawing.Size(100, 20);
            this.tbClaveOrigen.TabIndex = 16;
            // 
            // tbDescripcionProm
            // 
            this.tbDescripcionProm.Location = new System.Drawing.Point(144, 170);
            this.tbDescripcionProm.Name = "tbDescripcionProm";
            this.tbDescripcionProm.Size = new System.Drawing.Size(290, 20);
            this.tbDescripcionProm.TabIndex = 17;
            // 
            // tbTipo950o955
            // 
            this.tbTipo950o955.Location = new System.Drawing.Point(144, 200);
            this.tbTipo950o955.Name = "tbTipo950o955";
            this.tbTipo950o955.Size = new System.Drawing.Size(100, 20);
            this.tbTipo950o955.TabIndex = 18;
            // 
            // tbFechaEfectiva
            // 
            this.tbFechaEfectiva.Location = new System.Drawing.Point(144, 230);
            this.tbFechaEfectiva.Name = "tbFechaEfectiva";
            this.tbFechaEfectiva.Size = new System.Drawing.Size(100, 20);
            this.tbFechaEfectiva.TabIndex = 19;
            // 
            // tbFechaCaptura
            // 
            this.tbFechaCaptura.Location = new System.Drawing.Point(144, 260);
            this.tbFechaCaptura.Name = "tbFechaCaptura";
            this.tbFechaCaptura.Size = new System.Drawing.Size(100, 20);
            this.tbFechaCaptura.TabIndex = 20;
            // 
            // tbHoraCaptura
            // 
            this.tbHoraCaptura.Location = new System.Drawing.Point(144, 290);
            this.tbHoraCaptura.Name = "tbHoraCaptura";
            this.tbHoraCaptura.Size = new System.Drawing.Size(100, 20);
            this.tbHoraCaptura.TabIndex = 21;
            // 
            // tbUsuario
            // 
            this.tbUsuario.Location = new System.Drawing.Point(144, 320);
            this.tbUsuario.Name = "tbUsuario";
            this.tbUsuario.Size = new System.Drawing.Size(100, 20);
            this.tbUsuario.TabIndex = 22;
            // 
            // tbEstatus
            // 
            this.tbEstatus.Location = new System.Drawing.Point(144, 350);
            this.tbEstatus.Name = "tbEstatus";
            this.tbEstatus.Size = new System.Drawing.Size(100, 20);
            this.tbEstatus.TabIndex = 23;
            // 
            // CapCaratula
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(449, 392);
            this.Controls.Add(this.tbEstatus);
            this.Controls.Add(this.tbUsuario);
            this.Controls.Add(this.tbHoraCaptura);
            this.Controls.Add(this.tbFechaCaptura);
            this.Controls.Add(this.tbFechaEfectiva);
            this.Controls.Add(this.tbTipo950o955);
            this.Controls.Add(this.tbDescripcionProm);
            this.Controls.Add(this.tbClaveOrigen);
            this.Controls.Add(this.tbClavePromo);
            this.Controls.Add(this.tbFechaCalifica);
            this.Controls.Add(this.tbFchRecibo);
            this.Controls.Add(this.tbFchBonifica);
            this.Controls.Add(this.lbEstatus);
            this.Controls.Add(this.lbUsuario);
            this.Controls.Add(this.lbHoraCaptura);
            this.Controls.Add(this.lbFechaCaptura);
            this.Controls.Add(this.lbFechaEfectiva);
            this.Controls.Add(this.lbTipo950o955);
            this.Controls.Add(this.lbDescripcionProm);
            this.Controls.Add(this.lbClaveOrigen);
            this.Controls.Add(this.lbClavePromocion);
            this.Controls.Add(this.lblFchCalificacion);
            this.Controls.Add(this.lbFchRecibo);
            this.Controls.Add(this.lbFchBonifica);
            this.Name = "CapCaratula";
            this.Tag = "";
            this.Text = "Captura ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbFchBonifica;
        private System.Windows.Forms.Label lbFchRecibo;
        private System.Windows.Forms.Label lblFchCalificacion;
        private System.Windows.Forms.Label lbClavePromocion;
        private System.Windows.Forms.Label lbClaveOrigen;
        private System.Windows.Forms.Label lbDescripcionProm;
        private System.Windows.Forms.Label lbTipo950o955;
        private System.Windows.Forms.Label lbFechaEfectiva;
        private System.Windows.Forms.Label lbFechaCaptura;
        private System.Windows.Forms.Label lbHoraCaptura;
        private System.Windows.Forms.Label lbUsuario;
        private System.Windows.Forms.Label lbEstatus;
        private System.Windows.Forms.TextBox tbFchBonifica;
        private System.Windows.Forms.TextBox tbFchRecibo;
        private System.Windows.Forms.TextBox tbFechaCalifica;
        private System.Windows.Forms.TextBox tbClavePromo;
        private System.Windows.Forms.TextBox tbClaveOrigen;
        private System.Windows.Forms.TextBox tbDescripcionProm;
        private System.Windows.Forms.TextBox tbTipo950o955;
        private System.Windows.Forms.TextBox tbFechaEfectiva;
        private System.Windows.Forms.TextBox tbFechaCaptura;
        private System.Windows.Forms.TextBox tbHoraCaptura;
        private System.Windows.Forms.TextBox tbUsuario;
        private System.Windows.Forms.TextBox tbEstatus;
    }
}