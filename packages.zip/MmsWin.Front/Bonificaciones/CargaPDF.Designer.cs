﻿namespace MmsWin.Front.Bonificaciones
{
    partial class CargaPDF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbExaminarPDF = new System.Windows.Forms.Button();
            this.tbFuentePDF = new System.Windows.Forms.TextBox();
            this.lbNotaPDF = new System.Windows.Forms.Label();
            this.lbFormatoPDF = new System.Windows.Forms.Label();
            this.tbDestinoPDF = new System.Windows.Forms.TextBox();
            this.pbCargarPDF = new System.Windows.Forms.Button();
            this.lbNombrePrv = new System.Windows.Forms.Label();
            this.lbDescEstilo = new System.Windows.Forms.Label();
            this.lbNoNotaCredito = new System.Windows.Forms.Label();
            this.lbNotaCredito = new System.Windows.Forms.Label();
            this.gbDatos = new System.Windows.Forms.GroupBox();
            this.lbProvedor = new System.Windows.Forms.Label();
            this.lbEstilo = new System.Windows.Forms.Label();
            this.gbDatos.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbExaminarPDF
            // 
            this.pbExaminarPDF.Location = new System.Drawing.Point(506, 116);
            this.pbExaminarPDF.Name = "pbExaminarPDF";
            this.pbExaminarPDF.Size = new System.Drawing.Size(75, 23);
            this.pbExaminarPDF.TabIndex = 0;
            this.pbExaminarPDF.Text = "Examinar";
            this.pbExaminarPDF.UseVisualStyleBackColor = true;
            this.pbExaminarPDF.Click += new System.EventHandler(this.pbExaminarPDF_Click);
            // 
            // tbFuentePDF
            // 
            this.tbFuentePDF.Enabled = false;
            this.tbFuentePDF.Location = new System.Drawing.Point(12, 118);
            this.tbFuentePDF.Name = "tbFuentePDF";
            this.tbFuentePDF.Size = new System.Drawing.Size(488, 20);
            this.tbFuentePDF.TabIndex = 1;
            // 
            // lbNotaPDF
            // 
            this.lbNotaPDF.AutoSize = true;
            this.lbNotaPDF.Location = new System.Drawing.Point(12, 102);
            this.lbNotaPDF.Name = "lbNotaPDF";
            this.lbNotaPDF.Size = new System.Drawing.Size(111, 13);
            this.lbNotaPDF.TabIndex = 2;
            this.lbNotaPDF.Text = "Nota de Crédito (PDF)";
            // 
            // lbFormatoPDF
            // 
            this.lbFormatoPDF.AutoSize = true;
            this.lbFormatoPDF.Location = new System.Drawing.Point(12, 176);
            this.lbFormatoPDF.Name = "lbFormatoPDF";
            this.lbFormatoPDF.Size = new System.Drawing.Size(191, 13);
            this.lbFormatoPDF.TabIndex = 5;
            this.lbFormatoPDF.Text = "Formato de la Nota de Crédito a Cargar";
            // 
            // tbDestinoPDF
            // 
            this.tbDestinoPDF.Enabled = false;
            this.tbDestinoPDF.Location = new System.Drawing.Point(12, 192);
            this.tbDestinoPDF.Name = "tbDestinoPDF";
            this.tbDestinoPDF.Size = new System.Drawing.Size(488, 20);
            this.tbDestinoPDF.TabIndex = 4;
            this.tbDestinoPDF.Visible = false;
            // 
            // pbCargarPDF
            // 
            this.pbCargarPDF.Location = new System.Drawing.Point(506, 192);
            this.pbCargarPDF.Name = "pbCargarPDF";
            this.pbCargarPDF.Size = new System.Drawing.Size(75, 23);
            this.pbCargarPDF.TabIndex = 3;
            this.pbCargarPDF.Text = "Cargar";
            this.pbCargarPDF.UseVisualStyleBackColor = true;
            this.pbCargarPDF.Click += new System.EventHandler(this.pbCargarPDF_Click);
            // 
            // lbNombrePrv
            // 
            this.lbNombrePrv.AutoSize = true;
            this.lbNombrePrv.Location = new System.Drawing.Point(69, 47);
            this.lbNombrePrv.Name = "lbNombrePrv";
            this.lbNombrePrv.Size = new System.Drawing.Size(61, 13);
            this.lbNombrePrv.TabIndex = 7;
            this.lbNombrePrv.Text = "MMMMMM";
            // 
            // lbDescEstilo
            // 
            this.lbDescEstilo.AutoSize = true;
            this.lbDescEstilo.Location = new System.Drawing.Point(170, 48);
            this.lbDescEstilo.Name = "lbDescEstilo";
            this.lbDescEstilo.Size = new System.Drawing.Size(277, 13);
            this.lbDescEstilo.TabIndex = 9;
            this.lbDescEstilo.Text = "MMMMMMMMMMMMMMMMMMMMMMMMMMMMMM";
            // 
            // lbNoNotaCredito
            // 
            this.lbNoNotaCredito.AutoSize = true;
            this.lbNoNotaCredito.Location = new System.Drawing.Point(70, 23);
            this.lbNoNotaCredito.Name = "lbNoNotaCredito";
            this.lbNoNotaCredito.Size = new System.Drawing.Size(196, 13);
            this.lbNoNotaCredito.TabIndex = 12;
            this.lbNoNotaCredito.Text = "MMMMMMMMMMMMMMMMMMMMM";
            // 
            // lbNotaCredito
            // 
            this.lbNotaCredito.AutoSize = true;
            this.lbNotaCredito.Location = new System.Drawing.Point(13, 21);
            this.lbNotaCredito.Name = "lbNotaCredito";
            this.lbNotaCredito.Size = new System.Drawing.Size(30, 13);
            this.lbNotaCredito.TabIndex = 11;
            this.lbNotaCredito.Text = "Nota";
            // 
            // gbDatos
            // 
            this.gbDatos.Controls.Add(this.lbProvedor);
            this.gbDatos.Controls.Add(this.lbEstilo);
            this.gbDatos.Location = new System.Drawing.Point(11, 4);
            this.gbDatos.Name = "gbDatos";
            this.gbDatos.Size = new System.Drawing.Size(570, 71);
            this.gbDatos.TabIndex = 13;
            this.gbDatos.TabStop = false;
            // 
            // lbProvedor
            // 
            this.lbProvedor.AutoSize = true;
            this.lbProvedor.Location = new System.Drawing.Point(2, 43);
            this.lbProvedor.Name = "lbProvedor";
            this.lbProvedor.Size = new System.Drawing.Size(56, 13);
            this.lbProvedor.TabIndex = 14;
            this.lbProvedor.Text = "Proveedor";
            // 
            // lbEstilo
            // 
            this.lbEstilo.AutoSize = true;
            this.lbEstilo.Location = new System.Drawing.Point(123, 44);
            this.lbEstilo.Name = "lbEstilo";
            this.lbEstilo.Size = new System.Drawing.Size(32, 13);
            this.lbEstilo.TabIndex = 14;
            this.lbEstilo.Text = "Estilo";
            // 
            // CargaPDF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(593, 247);
            this.Controls.Add(this.lbNoNotaCredito);
            this.Controls.Add(this.lbNotaCredito);
            this.Controls.Add(this.lbDescEstilo);
            this.Controls.Add(this.lbNombrePrv);
            this.Controls.Add(this.lbFormatoPDF);
            this.Controls.Add(this.tbDestinoPDF);
            this.Controls.Add(this.pbCargarPDF);
            this.Controls.Add(this.lbNotaPDF);
            this.Controls.Add(this.tbFuentePDF);
            this.Controls.Add(this.pbExaminarPDF);
            this.Controls.Add(this.gbDatos);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CargaPDF";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Carga el documento de Nota de Crédito (PDF)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CargaPDF_FormClosing);
            this.Load += new System.EventHandler(this.CargaPDF_Load);
            this.gbDatos.ResumeLayout(false);
            this.gbDatos.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button pbExaminarPDF;
        private System.Windows.Forms.TextBox tbFuentePDF;
        private System.Windows.Forms.Label lbNotaPDF;
        private System.Windows.Forms.Label lbFormatoPDF;
        private System.Windows.Forms.TextBox tbDestinoPDF;
        private System.Windows.Forms.Button pbCargarPDF;
        private System.Windows.Forms.Label lbNombrePrv;
        private System.Windows.Forms.Label lbDescEstilo;
        private System.Windows.Forms.Label lbNoNotaCredito;
        private System.Windows.Forms.Label lbNotaCredito;
        private System.Windows.Forms.GroupBox gbDatos;
        private System.Windows.Forms.Label lbEstilo;
        private System.Windows.Forms.Label lbProvedor;
    }
}