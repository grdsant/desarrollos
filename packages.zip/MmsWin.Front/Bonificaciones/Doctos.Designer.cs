﻿namespace MmsWin.Front.Bonificaciones
{
    partial class Doctos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Doctos));
            this.pbExcel = new System.Windows.Forms.PictureBox();
            this.pgbProg = new System.Windows.Forms.ProgressBar();
            this.dgvDoctos = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.FotoTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.cosnsultaPDFTSM = new System.Windows.Forms.ToolStripMenuItem();
            this.cargaPDFTSM = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.EliminarTSM1 = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblDesde = new System.Windows.Forms.Label();
            this.lblHasta = new System.Windows.Forms.Label();
            this.tbCal01 = new System.Windows.Forms.TextBox();
            this.tbHasta = new System.Windows.Forms.TextBox();
            this.cbCompradores = new System.Windows.Forms.ComboBox();
            this.gbMarca = new System.Windows.Forms.GroupBox();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.gbComprador = new System.Windows.Forms.GroupBox();
            this.mcCal01 = new System.Windows.Forms.MonthCalendar();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbProveedor = new System.Windows.Forms.TextBox();
            this.Relleno = new System.Windows.Forms.TextBox();
            this.tbRelleno02 = new System.Windows.Forms.TextBox();
            this.mcC1 = new System.Windows.Forms.MonthCalendar();
            ((System.ComponentModel.ISupportInitialize)(this.pbExcel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoctos)).BeginInit();
            this.cmMenu.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gbMarca.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbExcel
            // 
            this.pbExcel.Image = ((System.Drawing.Image)(resources.GetObject("pbExcel.Image")));
            this.pbExcel.Location = new System.Drawing.Point(3, 0);
            this.pbExcel.Name = "pbExcel";
            this.pbExcel.Size = new System.Drawing.Size(65, 47);
            this.pbExcel.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbExcel.TabIndex = 8;
            this.pbExcel.TabStop = false;
            this.pbExcel.Click += new System.EventHandler(this.pbExcel_Click);
            // 
            // pgbProg
            // 
            this.pgbProg.Location = new System.Drawing.Point(12, 44);
            this.pgbProg.Name = "pgbProg";
            this.pgbProg.Size = new System.Drawing.Size(965, 10);
            this.pgbProg.TabIndex = 11;
            this.pgbProg.Visible = false;
            // 
            // dgvDoctos
            // 
            this.dgvDoctos.AllowUserToAddRows = false;
            this.dgvDoctos.AllowUserToDeleteRows = false;
            this.dgvDoctos.AllowUserToOrderColumns = true;
            this.dgvDoctos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDoctos.ContextMenuStrip = this.cmMenu;
            this.dgvDoctos.Location = new System.Drawing.Point(3, 65);
            this.dgvDoctos.Name = "dgvDoctos";
            this.dgvDoctos.Size = new System.Drawing.Size(975, 333);
            this.dgvDoctos.TabIndex = 12;
            this.dgvDoctos.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvDoctos_CellMouseDown);
            this.dgvDoctos.Sorted += new System.EventHandler(this.dgvDoctos_Sorted);
            this.dgvDoctos.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvDoctos_KeyUp);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FotoTSMI,
            this.cosnsultaPDFTSM,
            this.cargaPDFTSM,
            this.toolStripMenuItem2,
            this.EliminarTSM1});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(146, 114);
            // 
            // FotoTSMI
            // 
            this.FotoTSMI.Name = "FotoTSMI";
            this.FotoTSMI.Size = new System.Drawing.Size(145, 22);
            this.FotoTSMI.Text = "Foto";
            this.FotoTSMI.Click += new System.EventHandler(this.fotoToolStripMenuItem_Click);
            // 
            // cosnsultaPDFTSM
            // 
            this.cosnsultaPDFTSM.Name = "cosnsultaPDFTSM";
            this.cosnsultaPDFTSM.Size = new System.Drawing.Size(145, 22);
            this.cosnsultaPDFTSM.Text = "Consulta PDF";
            this.cosnsultaPDFTSM.Click += new System.EventHandler(this.cosnsultaPDFTSM_Click);
            // 
            // cargaPDFTSM
            // 
            this.cargaPDFTSM.Name = "cargaPDFTSM";
            this.cargaPDFTSM.Size = new System.Drawing.Size(145, 22);
            this.cargaPDFTSM.Text = "Carga PDF";
            this.cargaPDFTSM.Click += new System.EventHandler(this.cargaPDFTSM_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(145, 22);
            this.toolStripMenuItem2.Text = "____________";
            // 
            // EliminarTSM1
            // 
            this.EliminarTSM1.Name = "EliminarTSM1";
            this.EliminarTSM1.Size = new System.Drawing.Size(145, 22);
            this.EliminarTSM1.Text = "Eliminar";
            this.EliminarTSM1.Click += new System.EventHandler(this.EliminarTSM1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblDesde);
            this.groupBox1.Controls.Add(this.lblHasta);
            this.groupBox1.Controls.Add(this.tbCal01);
            this.groupBox1.Controls.Add(this.tbHasta);
            this.groupBox1.Location = new System.Drawing.Point(394, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(266, 40);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Rango";
            // 
            // lblDesde
            // 
            this.lblDesde.AutoSize = true;
            this.lblDesde.Location = new System.Drawing.Point(7, 17);
            this.lblDesde.Name = "lblDesde";
            this.lblDesde.Size = new System.Drawing.Size(38, 13);
            this.lblDesde.TabIndex = 44;
            this.lblDesde.Text = "Desde";
            // 
            // lblHasta
            // 
            this.lblHasta.AutoSize = true;
            this.lblHasta.Location = new System.Drawing.Point(135, 17);
            this.lblHasta.Name = "lblHasta";
            this.lblHasta.Size = new System.Drawing.Size(35, 13);
            this.lblHasta.TabIndex = 45;
            this.lblHasta.Text = "Hasta";
            // 
            // tbCal01
            // 
            this.tbCal01.Location = new System.Drawing.Point(54, 13);
            this.tbCal01.Name = "tbCal01";
            this.tbCal01.ReadOnly = true;
            this.tbCal01.Size = new System.Drawing.Size(69, 20);
            this.tbCal01.TabIndex = 18;
            this.tbCal01.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbCal01.Click += new System.EventHandler(this.tbCal01_Click);
            // 
            // tbHasta
            // 
            this.tbHasta.Location = new System.Drawing.Point(172, 13);
            this.tbHasta.Name = "tbHasta";
            this.tbHasta.ReadOnly = true;
            this.tbHasta.Size = new System.Drawing.Size(71, 20);
            this.tbHasta.TabIndex = 44;
            this.tbHasta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbHasta.Click += new System.EventHandler(this.tbHasta_Click);
            // 
            // cbCompradores
            // 
            this.cbCompradores.FormattingEnabled = true;
            this.cbCompradores.Location = new System.Drawing.Point(204, 15);
            this.cbCompradores.Name = "cbCompradores";
            this.cbCompradores.Size = new System.Drawing.Size(168, 21);
            this.cbCompradores.TabIndex = 14;
            this.cbCompradores.SelectedValueChanged += new System.EventHandler(this.cbCompradores_SelectedValueChanged);
            // 
            // gbMarca
            // 
            this.gbMarca.Controls.Add(this.cbMarca);
            this.gbMarca.Location = new System.Drawing.Point(69, 2);
            this.gbMarca.Name = "gbMarca";
            this.gbMarca.Size = new System.Drawing.Size(113, 40);
            this.gbMarca.TabIndex = 13;
            this.gbMarca.TabStop = false;
            this.gbMarca.Text = "Marca";
            // 
            // cbMarca
            // 
            this.cbMarca.Location = new System.Drawing.Point(24, 13);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(74, 21);
            this.cbMarca.TabIndex = 2;
            this.cbMarca.SelectedValueChanged += new System.EventHandler(this.cbMarca_SelectedValueChanged);
            // 
            // gbComprador
            // 
            this.gbComprador.Location = new System.Drawing.Point(186, 2);
            this.gbComprador.Name = "gbComprador";
            this.gbComprador.Size = new System.Drawing.Size(203, 40);
            this.gbComprador.TabIndex = 15;
            this.gbComprador.TabStop = false;
            this.gbComprador.Text = "Comprador";
            // 
            // mcCal01
            // 
            this.mcCal01.BackColor = System.Drawing.Color.Gray;
            this.mcCal01.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.mcCal01.Location = new System.Drawing.Point(502, 66);
            this.mcCal01.Name = "mcCal01";
            this.mcCal01.TabIndex = 18;
            this.mcCal01.Visible = false;
            this.mcCal01.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcCal01_DateSelected);
            this.mcCal01.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcCal01_KeyUp);
            this.mcCal01.Leave += new System.EventHandler(this.mcCal01_Leave);
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDescripcion.Location = new System.Drawing.Point(525, 44);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(250, 20);
            this.tbDescripcion.TabIndex = 41;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress);
            // 
            // tbEstilo
            // 
            this.tbEstilo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbEstilo.Location = new System.Drawing.Point(426, 44);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(98, 20);
            this.tbEstilo.TabIndex = 40;
            this.tbEstilo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbEstilo_KeyPress);
            // 
            // tbNombre
            // 
            this.tbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNombre.Location = new System.Drawing.Point(177, 44);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(248, 20);
            this.tbNombre.TabIndex = 39;
            this.tbNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNombre_KeyPress);
            // 
            // tbProveedor
            // 
            this.tbProveedor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbProveedor.Location = new System.Drawing.Point(125, 44);
            this.tbProveedor.Name = "tbProveedor";
            this.tbProveedor.Size = new System.Drawing.Size(51, 20);
            this.tbProveedor.TabIndex = 38;
            this.tbProveedor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbProveedor_KeyPress);
            // 
            // Relleno
            // 
            this.Relleno.Enabled = false;
            this.Relleno.Location = new System.Drawing.Point(4, 44);
            this.Relleno.Name = "Relleno";
            this.Relleno.Size = new System.Drawing.Size(120, 20);
            this.Relleno.TabIndex = 42;
            // 
            // tbRelleno02
            // 
            this.tbRelleno02.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tbRelleno02.Enabled = false;
            this.tbRelleno02.Location = new System.Drawing.Point(776, 44);
            this.tbRelleno02.Name = "tbRelleno02";
            this.tbRelleno02.Size = new System.Drawing.Size(202, 20);
            this.tbRelleno02.TabIndex = 43;
            // 
            // mcC1
            // 
            this.mcC1.BackColor = System.Drawing.Color.Gray;
            this.mcC1.ForeColor = System.Drawing.Color.Black;
            this.mcC1.Location = new System.Drawing.Point(368, 66);
            this.mcC1.Name = "mcC1";
            this.mcC1.TabIndex = 44;
            this.mcC1.Visible = false;
            this.mcC1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcC1_DateSelected);
            this.mcC1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcC1_KeyUp);
            this.mcC1.Leave += new System.EventHandler(this.mcC1_Leave);
            // 
            // Doctos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(983, 402);
            this.Controls.Add(this.mcC1);
            this.Controls.Add(this.tbRelleno02);
            this.Controls.Add(this.Relleno);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.tbEstilo);
            this.Controls.Add(this.tbNombre);
            this.Controls.Add(this.tbProveedor);
            this.Controls.Add(this.mcCal01);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbCompradores);
            this.Controls.Add(this.gbMarca);
            this.Controls.Add(this.gbComprador);
            this.Controls.Add(this.pgbProg);
            this.Controls.Add(this.pbExcel);
            this.Controls.Add(this.dgvDoctos);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Doctos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Doctos (Notas de Credito/Adendum/Excepciones)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Doctos_FormClosing);
            this.Load += new System.EventHandler(this.Doctos_Load);
            this.Resize += new System.EventHandler(this.Doctos_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.pbExcel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoctos)).EndInit();
            this.cmMenu.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbMarca.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbExcel;
        private System.Windows.Forms.ProgressBar pgbProg;
        private System.Windows.Forms.DataGridView dgvDoctos;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbCompradores;
        private System.Windows.Forms.GroupBox gbMarca;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.GroupBox gbComprador;
        private System.Windows.Forms.TextBox tbCal01;
        private System.Windows.Forms.MonthCalendar mcCal01;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem FotoTSMI;
        private System.Windows.Forms.ToolStripMenuItem EliminarTSM1;
        private System.Windows.Forms.ToolStripMenuItem cosnsultaPDFTSM;
        private System.Windows.Forms.ToolStripMenuItem cargaPDFTSM;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.TextBox tbProveedor;
        private System.Windows.Forms.TextBox Relleno;
        private System.Windows.Forms.TextBox tbRelleno02;
        private System.Windows.Forms.Label lblHasta;
        private System.Windows.Forms.TextBox tbHasta;
        private System.Windows.Forms.Label lblDesde;
        private System.Windows.Forms.MonthCalendar mcC1;
    }
}