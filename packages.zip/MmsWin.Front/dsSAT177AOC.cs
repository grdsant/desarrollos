﻿namespace MmsWin.Front {
    
    
    public partial class dsSAT177AOC {
        partial class SAT177AOCDataTable
        {
        }
    }
}

namespace MmsWin.Front.dsSAT177AOCTableAdapters {
    
    
    public partial class SAT177AOCTableAdapter {
    }
}
