﻿namespace MmsWin.Front.Utilerias
{
    partial class Fotos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Fotos));
            this.pbFoto = new System.Windows.Forms.PictureBox();
            this.tbProveedor = new System.Windows.Forms.TextBox();
            this.lbProveedor = new System.Windows.Forms.Label();
            this.lbEstilo = new System.Windows.Forms.Label();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.lbTemporada = new System.Windows.Forms.Label();
            this.tbTemporada = new System.Windows.Forms.TextBox();
            this.lbDesTemporada = new System.Windows.Forms.Label();
            this.lbDesEstilo = new System.Windows.Forms.Label();
            this.lbDesProveedor = new System.Windows.Forms.Label();
            this.gbCostoPrecio = new System.Windows.Forms.GroupBox();
            this.lbPrecioActual = new System.Windows.Forms.Label();
            this.lbPrecioOriginal = new System.Windows.Forms.Label();
            this.tbPrecioActual = new System.Windows.Forms.TextBox();
            this.tbPrecioOriginal = new System.Windows.Forms.TextBox();
            this.lbCostoActual = new System.Windows.Forms.Label();
            this.lbCostoOriginar = new System.Windows.Forms.Label();
            this.tbCostoActual = new System.Windows.Forms.TextBox();
            this.tbCostoOriginal = new System.Windows.Forms.TextBox();
            this.gbVtas8Semanas = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tbSem08 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbSem07 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tbSem06 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbSem05 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbSem04 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbSem03 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbSem02 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbSem01 = new System.Windows.Forms.TextBox();
            this.lbSemanaActual = new System.Windows.Forms.Label();
            this.tbSemAct = new System.Windows.Forms.TextBox();
            this.pnTitulo = new System.Windows.Forms.Panel();
            this.pbSalir = new System.Windows.Forms.PictureBox();
            this.dgvDataGridView = new System.Windows.Forms.DataGridView();
            this.lbtabacc = new System.Windows.Forms.Label();
            this.lbTransito = new System.Windows.Forms.Label();
            this.lbOnHand = new System.Windows.Forms.Label();
            this.tbOnHand = new System.Windows.Forms.TextBox();
            this.tbTransito = new System.Windows.Forms.TextBox();
            this.tbTablaAcc = new System.Windows.Forms.TextBox();
            this.lbPosDistro = new System.Windows.Forms.Label();
            this.tbPosDistro = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbFoto)).BeginInit();
            this.gbCostoPrecio.SuspendLayout();
            this.gbVtas8Semanas.SuspendLayout();
            this.pnTitulo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // pbFoto
            // 
            this.pbFoto.Location = new System.Drawing.Point(6, 46);
            this.pbFoto.Name = "pbFoto";
            this.pbFoto.Size = new System.Drawing.Size(515, 424);
            this.pbFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFoto.TabIndex = 0;
            this.pbFoto.TabStop = false;
            // 
            // tbProveedor
            // 
            this.tbProveedor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbProveedor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbProveedor.Enabled = false;
            this.tbProveedor.Location = new System.Drawing.Point(594, 46);
            this.tbProveedor.Name = "tbProveedor";
            this.tbProveedor.Size = new System.Drawing.Size(58, 13);
            this.tbProveedor.TabIndex = 1;
            // 
            // lbProveedor
            // 
            this.lbProveedor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbProveedor.AutoSize = true;
            this.lbProveedor.Enabled = false;
            this.lbProveedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbProveedor.Location = new System.Drawing.Point(522, 49);
            this.lbProveedor.Name = "lbProveedor";
            this.lbProveedor.Size = new System.Drawing.Size(65, 13);
            this.lbProveedor.TabIndex = 2;
            this.lbProveedor.Text = "Proveedor";
            // 
            // lbEstilo
            // 
            this.lbEstilo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbEstilo.AutoSize = true;
            this.lbEstilo.Enabled = false;
            this.lbEstilo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEstilo.Location = new System.Drawing.Point(522, 72);
            this.lbEstilo.Name = "lbEstilo";
            this.lbEstilo.Size = new System.Drawing.Size(38, 13);
            this.lbEstilo.TabIndex = 4;
            this.lbEstilo.Text = "Estilo";
            // 
            // tbEstilo
            // 
            this.tbEstilo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbEstilo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbEstilo.Enabled = false;
            this.tbEstilo.Location = new System.Drawing.Point(594, 69);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(58, 13);
            this.tbEstilo.TabIndex = 3;
            // 
            // lbTemporada
            // 
            this.lbTemporada.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbTemporada.AutoSize = true;
            this.lbTemporada.Enabled = false;
            this.lbTemporada.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTemporada.Location = new System.Drawing.Point(522, 97);
            this.lbTemporada.Name = "lbTemporada";
            this.lbTemporada.Size = new System.Drawing.Size(70, 13);
            this.lbTemporada.TabIndex = 6;
            this.lbTemporada.Text = "Temporada";
            // 
            // tbTemporada
            // 
            this.tbTemporada.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tbTemporada.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbTemporada.Enabled = false;
            this.tbTemporada.Location = new System.Drawing.Point(594, 94);
            this.tbTemporada.Name = "tbTemporada";
            this.tbTemporada.Size = new System.Drawing.Size(58, 13);
            this.tbTemporada.TabIndex = 5;
            // 
            // lbDesTemporada
            // 
            this.lbDesTemporada.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbDesTemporada.AutoSize = true;
            this.lbDesTemporada.Enabled = false;
            this.lbDesTemporada.Location = new System.Drawing.Point(659, 94);
            this.lbDesTemporada.Name = "lbDesTemporada";
            this.lbDesTemporada.Size = new System.Drawing.Size(16, 13);
            this.lbDesTemporada.TabIndex = 9;
            this.lbDesTemporada.Text = "...";
            // 
            // lbDesEstilo
            // 
            this.lbDesEstilo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbDesEstilo.AutoSize = true;
            this.lbDesEstilo.Enabled = false;
            this.lbDesEstilo.Location = new System.Drawing.Point(659, 69);
            this.lbDesEstilo.Name = "lbDesEstilo";
            this.lbDesEstilo.Size = new System.Drawing.Size(16, 13);
            this.lbDesEstilo.TabIndex = 8;
            this.lbDesEstilo.Text = "...";
            // 
            // lbDesProveedor
            // 
            this.lbDesProveedor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbDesProveedor.AutoSize = true;
            this.lbDesProveedor.Enabled = false;
            this.lbDesProveedor.Location = new System.Drawing.Point(659, 46);
            this.lbDesProveedor.Name = "lbDesProveedor";
            this.lbDesProveedor.Size = new System.Drawing.Size(16, 13);
            this.lbDesProveedor.TabIndex = 7;
            this.lbDesProveedor.Text = "...";
            // 
            // gbCostoPrecio
            // 
            this.gbCostoPrecio.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gbCostoPrecio.Controls.Add(this.lbPrecioActual);
            this.gbCostoPrecio.Controls.Add(this.lbPrecioOriginal);
            this.gbCostoPrecio.Controls.Add(this.tbPrecioActual);
            this.gbCostoPrecio.Controls.Add(this.tbPrecioOriginal);
            this.gbCostoPrecio.Controls.Add(this.lbCostoActual);
            this.gbCostoPrecio.Controls.Add(this.lbCostoOriginar);
            this.gbCostoPrecio.Controls.Add(this.tbCostoActual);
            this.gbCostoPrecio.Controls.Add(this.tbCostoOriginal);
            this.gbCostoPrecio.Enabled = false;
            this.gbCostoPrecio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbCostoPrecio.Location = new System.Drawing.Point(522, 122);
            this.gbCostoPrecio.Name = "gbCostoPrecio";
            this.gbCostoPrecio.Size = new System.Drawing.Size(459, 100);
            this.gbCostoPrecio.TabIndex = 10;
            this.gbCostoPrecio.TabStop = false;
            this.gbCostoPrecio.Text = "Costo y Precio";
            this.gbCostoPrecio.Paint += new System.Windows.Forms.PaintEventHandler(this.gbCostoPrecio_Paint);
            // 
            // lbPrecioActual
            // 
            this.lbPrecioActual.AutoSize = true;
            this.lbPrecioActual.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPrecioActual.Location = new System.Drawing.Point(200, 65);
            this.lbPrecioActual.Name = "lbPrecioActual";
            this.lbPrecioActual.Size = new System.Drawing.Size(83, 13);
            this.lbPrecioActual.TabIndex = 21;
            this.lbPrecioActual.Text = "Precio Actual";
            // 
            // lbPrecioOriginal
            // 
            this.lbPrecioOriginal.AutoSize = true;
            this.lbPrecioOriginal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPrecioOriginal.Location = new System.Drawing.Point(199, 32);
            this.lbPrecioOriginal.Name = "lbPrecioOriginal";
            this.lbPrecioOriginal.Size = new System.Drawing.Size(90, 13);
            this.lbPrecioOriginal.TabIndex = 19;
            this.lbPrecioOriginal.Text = "Precio Original";
            // 
            // tbPrecioActual
            // 
            this.tbPrecioActual.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbPrecioActual.Enabled = false;
            this.tbPrecioActual.Location = new System.Drawing.Point(297, 65);
            this.tbPrecioActual.Name = "tbPrecioActual";
            this.tbPrecioActual.Size = new System.Drawing.Size(58, 13);
            this.tbPrecioActual.TabIndex = 20;
            this.tbPrecioActual.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbPrecioOriginal
            // 
            this.tbPrecioOriginal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbPrecioOriginal.Enabled = false;
            this.tbPrecioOriginal.Location = new System.Drawing.Point(297, 32);
            this.tbPrecioOriginal.Name = "tbPrecioOriginal";
            this.tbPrecioOriginal.Size = new System.Drawing.Size(58, 13);
            this.tbPrecioOriginal.TabIndex = 18;
            this.tbPrecioOriginal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbCostoActual
            // 
            this.lbCostoActual.AutoSize = true;
            this.lbCostoActual.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCostoActual.Location = new System.Drawing.Point(7, 65);
            this.lbCostoActual.Name = "lbCostoActual";
            this.lbCostoActual.Size = new System.Drawing.Size(79, 13);
            this.lbCostoActual.TabIndex = 17;
            this.lbCostoActual.Text = "Costo Actual";
            // 
            // lbCostoOriginar
            // 
            this.lbCostoOriginar.AutoSize = true;
            this.lbCostoOriginar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCostoOriginar.Location = new System.Drawing.Point(6, 32);
            this.lbCostoOriginar.Name = "lbCostoOriginar";
            this.lbCostoOriginar.Size = new System.Drawing.Size(86, 13);
            this.lbCostoOriginar.TabIndex = 13;
            this.lbCostoOriginar.Text = "Costo Original";
            // 
            // tbCostoActual
            // 
            this.tbCostoActual.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbCostoActual.Enabled = false;
            this.tbCostoActual.Location = new System.Drawing.Point(104, 65);
            this.tbCostoActual.Name = "tbCostoActual";
            this.tbCostoActual.Size = new System.Drawing.Size(58, 13);
            this.tbCostoActual.TabIndex = 16;
            this.tbCostoActual.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbCostoOriginal
            // 
            this.tbCostoOriginal.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbCostoOriginal.Enabled = false;
            this.tbCostoOriginal.Location = new System.Drawing.Point(104, 32);
            this.tbCostoOriginal.Name = "tbCostoOriginal";
            this.tbCostoOriginal.Size = new System.Drawing.Size(58, 13);
            this.tbCostoOriginal.TabIndex = 12;
            this.tbCostoOriginal.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // gbVtas8Semanas
            // 
            this.gbVtas8Semanas.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gbVtas8Semanas.Controls.Add(this.label8);
            this.gbVtas8Semanas.Controls.Add(this.tbSem08);
            this.gbVtas8Semanas.Controls.Add(this.label7);
            this.gbVtas8Semanas.Controls.Add(this.tbSem07);
            this.gbVtas8Semanas.Controls.Add(this.label6);
            this.gbVtas8Semanas.Controls.Add(this.tbSem06);
            this.gbVtas8Semanas.Controls.Add(this.label5);
            this.gbVtas8Semanas.Controls.Add(this.tbSem05);
            this.gbVtas8Semanas.Controls.Add(this.label4);
            this.gbVtas8Semanas.Controls.Add(this.tbSem04);
            this.gbVtas8Semanas.Controls.Add(this.label3);
            this.gbVtas8Semanas.Controls.Add(this.tbSem03);
            this.gbVtas8Semanas.Controls.Add(this.label2);
            this.gbVtas8Semanas.Controls.Add(this.tbSem02);
            this.gbVtas8Semanas.Controls.Add(this.label1);
            this.gbVtas8Semanas.Controls.Add(this.tbSem01);
            this.gbVtas8Semanas.Controls.Add(this.lbSemanaActual);
            this.gbVtas8Semanas.Controls.Add(this.tbSemAct);
            this.gbVtas8Semanas.Enabled = false;
            this.gbVtas8Semanas.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.gbVtas8Semanas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbVtas8Semanas.Location = new System.Drawing.Point(522, 229);
            this.gbVtas8Semanas.Name = "gbVtas8Semanas";
            this.gbVtas8Semanas.Size = new System.Drawing.Size(178, 241);
            this.gbVtas8Semanas.TabIndex = 11;
            this.gbVtas8Semanas.TabStop = false;
            this.gbVtas8Semanas.Text = "Venta 8 Semanas";
            this.gbVtas8Semanas.Paint += new System.Windows.Forms.PaintEventHandler(this.gbVtas8Semanas_Paint);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Enabled = false;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(7, 209);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 13);
            this.label8.TabIndex = 35;
            this.label8.Text = "Semana 8";
            // 
            // tbSem08
            // 
            this.tbSem08.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSem08.Enabled = false;
            this.tbSem08.Location = new System.Drawing.Point(104, 209);
            this.tbSem08.Name = "tbSem08";
            this.tbSem08.Size = new System.Drawing.Size(62, 13);
            this.tbSem08.TabIndex = 34;
            this.tbSem08.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Enabled = false;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(7, 186);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 13);
            this.label7.TabIndex = 33;
            this.label7.Text = "Semana 7";
            // 
            // tbSem07
            // 
            this.tbSem07.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSem07.Enabled = false;
            this.tbSem07.Location = new System.Drawing.Point(104, 186);
            this.tbSem07.Name = "tbSem07";
            this.tbSem07.Size = new System.Drawing.Size(62, 13);
            this.tbSem07.TabIndex = 32;
            this.tbSem07.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Enabled = false;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(7, 163);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(63, 13);
            this.label6.TabIndex = 31;
            this.label6.Text = "Semana 6";
            // 
            // tbSem06
            // 
            this.tbSem06.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSem06.Enabled = false;
            this.tbSem06.Location = new System.Drawing.Point(104, 163);
            this.tbSem06.Name = "tbSem06";
            this.tbSem06.Size = new System.Drawing.Size(62, 13);
            this.tbSem06.TabIndex = 30;
            this.tbSem06.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Enabled = false;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(7, 140);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 13);
            this.label5.TabIndex = 29;
            this.label5.Text = "Semana 5";
            // 
            // tbSem05
            // 
            this.tbSem05.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSem05.Enabled = false;
            this.tbSem05.Location = new System.Drawing.Point(104, 140);
            this.tbSem05.Name = "tbSem05";
            this.tbSem05.Size = new System.Drawing.Size(62, 13);
            this.tbSem05.TabIndex = 28;
            this.tbSem05.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Enabled = false;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(7, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 13);
            this.label4.TabIndex = 27;
            this.label4.Text = "Semana 4";
            // 
            // tbSem04
            // 
            this.tbSem04.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSem04.Enabled = false;
            this.tbSem04.Location = new System.Drawing.Point(104, 117);
            this.tbSem04.Name = "tbSem04";
            this.tbSem04.Size = new System.Drawing.Size(62, 13);
            this.tbSem04.TabIndex = 26;
            this.tbSem04.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Enabled = false;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(7, 94);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "Semana 3";
            // 
            // tbSem03
            // 
            this.tbSem03.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSem03.Enabled = false;
            this.tbSem03.Location = new System.Drawing.Point(104, 94);
            this.tbSem03.Name = "tbSem03";
            this.tbSem03.Size = new System.Drawing.Size(62, 13);
            this.tbSem03.TabIndex = 24;
            this.tbSem03.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Enabled = false;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(7, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 23;
            this.label2.Text = "Semana 2";
            // 
            // tbSem02
            // 
            this.tbSem02.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSem02.Enabled = false;
            this.tbSem02.Location = new System.Drawing.Point(104, 71);
            this.tbSem02.Name = "tbSem02";
            this.tbSem02.Size = new System.Drawing.Size(62, 13);
            this.tbSem02.TabIndex = 22;
            this.tbSem02.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Enabled = false;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 21;
            this.label1.Text = "Semana 1";
            // 
            // tbSem01
            // 
            this.tbSem01.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSem01.Enabled = false;
            this.tbSem01.Location = new System.Drawing.Point(104, 48);
            this.tbSem01.Name = "tbSem01";
            this.tbSem01.Size = new System.Drawing.Size(62, 13);
            this.tbSem01.TabIndex = 20;
            this.tbSem01.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbSemanaActual
            // 
            this.lbSemanaActual.AutoSize = true;
            this.lbSemanaActual.Enabled = false;
            this.lbSemanaActual.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSemanaActual.Location = new System.Drawing.Point(7, 25);
            this.lbSemanaActual.Name = "lbSemanaActual";
            this.lbSemanaActual.Size = new System.Drawing.Size(92, 13);
            this.lbSemanaActual.TabIndex = 19;
            this.lbSemanaActual.Text = "Semana Actual";
            // 
            // tbSemAct
            // 
            this.tbSemAct.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbSemAct.Enabled = false;
            this.tbSemAct.Location = new System.Drawing.Point(104, 25);
            this.tbSemAct.Name = "tbSemAct";
            this.tbSemAct.Size = new System.Drawing.Size(62, 13);
            this.tbSemAct.TabIndex = 18;
            this.tbSemAct.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnTitulo
            // 
            this.pnTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pnTitulo.Controls.Add(this.pbSalir);
            this.pnTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnTitulo.Location = new System.Drawing.Point(0, 0);
            this.pnTitulo.Name = "pnTitulo";
            this.pnTitulo.Size = new System.Drawing.Size(993, 39);
            this.pnTitulo.TabIndex = 12;
            this.pnTitulo.Paint += new System.Windows.Forms.PaintEventHandler(this.pnTitulo_Paint);
            this.pnTitulo.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnTitulo_MouseDown);
            this.pnTitulo.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnTitulo_MouseMove);
            this.pnTitulo.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnTitulo_MouseUp);
            // 
            // pbSalir
            // 
            this.pbSalir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbSalir.BackColor = System.Drawing.Color.Maroon;
            this.pbSalir.Image = ((System.Drawing.Image)(resources.GetObject("pbSalir.Image")));
            this.pbSalir.Location = new System.Drawing.Point(960, 9);
            this.pbSalir.Name = "pbSalir";
            this.pbSalir.Size = new System.Drawing.Size(24, 23);
            this.pbSalir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSalir.TabIndex = 11;
            this.pbSalir.TabStop = false;
            this.pbSalir.Click += new System.EventHandler(this.pbSalir_Click);
            // 
            // dgvDataGridView
            // 
            this.dgvDataGridView.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dgvDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDataGridView.Location = new System.Drawing.Point(702, 289);
            this.dgvDataGridView.Name = "dgvDataGridView";
            this.dgvDataGridView.Size = new System.Drawing.Size(284, 179);
            this.dgvDataGridView.TabIndex = 13;
            // 
            // lbtabacc
            // 
            this.lbtabacc.AutoSize = true;
            this.lbtabacc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbtabacc.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lbtabacc.Location = new System.Drawing.Point(918, 225);
            this.lbtabacc.Name = "lbtabacc";
            this.lbtabacc.Size = new System.Drawing.Size(65, 13);
            this.lbtabacc.TabIndex = 22;
            this.lbtabacc.Text = "Tabla Acc";
            // 
            // lbTransito
            // 
            this.lbTransito.AutoSize = true;
            this.lbTransito.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTransito.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lbTransito.Location = new System.Drawing.Point(706, 254);
            this.lbTransito.Name = "lbTransito";
            this.lbTransito.Size = new System.Drawing.Size(53, 13);
            this.lbTransito.TabIndex = 23;
            this.lbTransito.Text = "Transito";
            // 
            // lbOnHand
            // 
            this.lbOnHand.AutoSize = true;
            this.lbOnHand.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOnHand.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lbOnHand.Location = new System.Drawing.Point(706, 229);
            this.lbOnHand.Name = "lbOnHand";
            this.lbOnHand.Size = new System.Drawing.Size(53, 13);
            this.lbOnHand.TabIndex = 24;
            this.lbOnHand.Text = "OnHand";
            // 
            // tbOnHand
            // 
            this.tbOnHand.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbOnHand.Enabled = false;
            this.tbOnHand.Location = new System.Drawing.Point(766, 229);
            this.tbOnHand.Name = "tbOnHand";
            this.tbOnHand.Size = new System.Drawing.Size(58, 13);
            this.tbOnHand.TabIndex = 22;
            this.tbOnHand.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTransito
            // 
            this.tbTransito.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbTransito.Enabled = false;
            this.tbTransito.Location = new System.Drawing.Point(769, 255);
            this.tbTransito.Name = "tbTransito";
            this.tbTransito.Size = new System.Drawing.Size(58, 13);
            this.tbTransito.TabIndex = 25;
            this.tbTransito.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTablaAcc
            // 
            this.tbTablaAcc.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbTablaAcc.Enabled = false;
            this.tbTablaAcc.Location = new System.Drawing.Point(927, 254);
            this.tbTablaAcc.Name = "tbTablaAcc";
            this.tbTablaAcc.Size = new System.Drawing.Size(44, 13);
            this.tbTablaAcc.TabIndex = 26;
            this.tbTablaAcc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbPosDistro
            // 
            this.lbPosDistro.AutoSize = true;
            this.lbPosDistro.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPosDistro.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbPosDistro.Location = new System.Drawing.Point(833, 229);
            this.lbPosDistro.Name = "lbPosDistro";
            this.lbPosDistro.Size = new System.Drawing.Size(65, 13);
            this.lbPosDistro.TabIndex = 22;
            this.lbPosDistro.Text = "Pos Distro";
            // 
            // tbPosDistro
            // 
            this.tbPosDistro.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tbPosDistro.Enabled = false;
            this.tbPosDistro.Location = new System.Drawing.Point(837, 255);
            this.tbPosDistro.Name = "tbPosDistro";
            this.tbPosDistro.Size = new System.Drawing.Size(58, 13);
            this.tbPosDistro.TabIndex = 23;
            this.tbPosDistro.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Fotos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(993, 480);
            this.Controls.Add(this.tbPosDistro);
            this.Controls.Add(this.tbTablaAcc);
            this.Controls.Add(this.lbPosDistro);
            this.Controls.Add(this.tbTransito);
            this.Controls.Add(this.tbOnHand);
            this.Controls.Add(this.lbOnHand);
            this.Controls.Add(this.lbTransito);
            this.Controls.Add(this.lbtabacc);
            this.Controls.Add(this.dgvDataGridView);
            this.Controls.Add(this.pnTitulo);
            this.Controls.Add(this.gbVtas8Semanas);
            this.Controls.Add(this.gbCostoPrecio);
            this.Controls.Add(this.lbDesTemporada);
            this.Controls.Add(this.lbDesEstilo);
            this.Controls.Add(this.lbDesProveedor);
            this.Controls.Add(this.lbTemporada);
            this.Controls.Add(this.tbTemporada);
            this.Controls.Add(this.lbEstilo);
            this.Controls.Add(this.tbEstilo);
            this.Controls.Add(this.lbProveedor);
            this.Controls.Add(this.tbProveedor);
            this.Controls.Add(this.pbFoto);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Fotos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Fotos";
            this.Load += new System.EventHandler(this.Fotos_Load);
            this.Resize += new System.EventHandler(this.Fotos_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.pbFoto)).EndInit();
            this.gbCostoPrecio.ResumeLayout(false);
            this.gbCostoPrecio.PerformLayout();
            this.gbVtas8Semanas.ResumeLayout(false);
            this.gbVtas8Semanas.PerformLayout();
            this.pnTitulo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbFoto;
        private System.Windows.Forms.TextBox tbProveedor;
        private System.Windows.Forms.Label lbProveedor;
        private System.Windows.Forms.Label lbEstilo;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.Label lbTemporada;
        private System.Windows.Forms.TextBox tbTemporada;
        private System.Windows.Forms.Label lbDesTemporada;
        private System.Windows.Forms.Label lbDesEstilo;
        private System.Windows.Forms.Label lbDesProveedor;
        private System.Windows.Forms.GroupBox gbCostoPrecio;
        private System.Windows.Forms.Label lbPrecioActual;
        private System.Windows.Forms.Label lbPrecioOriginal;
        private System.Windows.Forms.TextBox tbPrecioActual;
        private System.Windows.Forms.TextBox tbPrecioOriginal;
        private System.Windows.Forms.Label lbCostoActual;
        private System.Windows.Forms.Label lbCostoOriginar;
        private System.Windows.Forms.TextBox tbCostoActual;
        private System.Windows.Forms.TextBox tbCostoOriginal;
        private System.Windows.Forms.GroupBox gbVtas8Semanas;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tbSem08;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbSem07;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tbSem06;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbSem05;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbSem04;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbSem03;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbSem02;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbSem01;
        private System.Windows.Forms.Label lbSemanaActual;
        private System.Windows.Forms.TextBox tbSemAct;
        private System.Windows.Forms.Panel pnTitulo;
        private System.Windows.Forms.PictureBox pbSalir;
        private System.Windows.Forms.DataGridView dgvDataGridView;
        private System.Windows.Forms.Label lbtabacc;
        private System.Windows.Forms.Label lbTransito;
        private System.Windows.Forms.Label lbOnHand;
        private System.Windows.Forms.TextBox tbOnHand;
        private System.Windows.Forms.TextBox tbTransito;
        private System.Windows.Forms.TextBox tbTablaAcc;
        private System.Windows.Forms.Label lbPosDistro;
        private System.Windows.Forms.TextBox tbPosDistro;
    }
}