﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Utilerias
{
    public partial class Fotos : Form
    {
        public static string numMarca;
        public static string numPrv;
        public static string numSty;

        int dgvOffset;
        int dgvOffset2;
        private bool dragging = false;
        private Point dragCursorPoint;
        private Point dragFormPoint;

        public Fotos()
        {
            InitializeComponent();
            dgvOffset = this.Width - pbFoto.Width;
            dgvOffset2 = this.Height - pbFoto.Height;
        }

        private void Fotos_Load(object sender, EventArgs e)
        {
            string charPrv = numPrv.PadLeft(6, '0');
            string ext = ".jpg";
            string path = @"\\192.168.2.79\www\showroom\images3\";
            string foto = path + "F" + charPrv + numSty + ext + " ";
            pbFoto.ImageLocation = foto;

            int prv = Convert.ToInt16(charPrv);
            System.Data.DataTable dtInfoEstilo = null;
            dtInfoEstilo = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenInfoEstilos(prv, numSty);

            foreach (DataRow row in dtInfoEstilo.Rows)
            {
                tbProveedor.Text      = row["SASNUM"].ToString();
                lbDesProveedor.Text   = row["ASNAME"].ToString();
                tbEstilo.Text         = row["SSTYLQ"].ToString();
                lbDesEstilo.Text      = row["SSTYLE"].ToString();
                tbTemporada.Text      = row["SSEASN"].ToString();
                lbDesTemporada.Text   = row["SEADSC"].ToString();
                tbCostoOriginal.Text  = row["CSTINI"].ToString();
                tbCostoActual.Text    = row["CST"].ToString();
                tbPrecioOriginal.Text = row["PRCINI"].ToString();
                tbPrecioActual.Text   = row["PRC"].ToString();
                tbSemAct.Text         = row["CBWKCR"].ToString();
                tbSem01.Text          = row["CBWK01"].ToString();
                tbSem02.Text          = row["CBWK02"].ToString();
                tbSem03.Text          = row["CBWK03"].ToString();
                tbSem04.Text          = row["CBWK04"].ToString();
                tbSem05.Text          = row["CBWK05"].ToString();
                tbSem06.Text          = row["CBWK06"].ToString();
                tbSem07.Text          = row["CBWK07"].ToString();
                tbSem08.Text          = row["CBWK08"].ToString();
                tbOnHand.Text         = row["CSHAND"].ToString();
                tbTransito.Text       = row["CSINTQ"].ToString();
                tbTablaAcc.Text       = row["SATRB5"].ToString();
                tbOnHand.Text   = string.Format("{0:#,##0}", double.Parse(tbOnHand.Text));
                tbTransito.Text = string.Format("{0:#,##0}", double.Parse(tbTransito.Text));
            }
            dgvDataGridView.DataSource = null;
            System.Data.DataTable dtInfoFechasRebajas = null;
            dtInfoFechasRebajas = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechasRebajas(prv, numSty);
            dgvDataGridView.DataSource = dtInfoFechasRebajas;
            dgvDataGridView.RowHeadersVisible = false;

            this.dgvDataGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.LightSlateGray;
            this.dgvDataGridView.EnableHeadersVisualStyles = false;
            this.dgvDataGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvDataGridView.DefaultCellStyle.SelectionForeColor = Color.LightSlateGray;
            this.dgvDataGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvDataGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvDataGridView.RowsDefaultCellStyle.ForeColor = Color.LightSlateGray;

            dgvDataGridView.Columns["PLNCDT"].HeaderText = "Fecha Efectiva";
            dgvDataGridView.Columns["PLNAMT"].HeaderText = "Precio Nuevo";
            dgvDataGridView.Columns["PLNEVT"].HeaderText = "No. Evento";
            dgvDataGridView.Columns["PLNLVL"].HeaderText = "Nivel";
            dgvDataGridView.Columns["PLNSTR"].HeaderText = "Tienda";
            dgvDataGridView.Columns["PLNITM"].HeaderText = "Sku";
            dgvDataGridView.Columns["PLNCDT"].Width = 80;
            dgvDataGridView.Columns["PLNAMT"].Width = 60;
            dgvDataGridView.Columns["PLNEVT"].Width = 50;
            dgvDataGridView.Columns["PLNLVL"].Width = 35;
            dgvDataGridView.Columns["PLNSTR"].Width = 50;
            dgvDataGridView.Columns["PLNITM"].Width = 50;
            dgvDataGridView.Columns["PLNCDT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDataGridView.Columns["PLNAMT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvDataGridView.Columns["PLNEVT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDataGridView.Columns["PLNSTR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDataGridView.Columns["PLNLVL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDataGridView.Columns["PLNITM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvDataGridView.Columns["PLNCDT"].HeaderCell.Style.BackColor = Color.LightGray;
            dgvDataGridView.Columns["PLNAMT"].HeaderCell.Style.BackColor = Color.LightGray;
            dgvDataGridView.Columns["PLNEVT"].HeaderCell.Style.BackColor = Color.LightGray;
            dgvDataGridView.Columns["PLNLVL"].HeaderCell.Style.BackColor = Color.LightGray;
            dgvDataGridView.Columns["PLNSTR"].HeaderCell.Style.BackColor = Color.LightGray;
            dgvDataGridView.Columns["PLNITM"].HeaderCell.Style.BackColor = Color.LightGray;

            dgvDataGridView.Columns["PLNCDT"].DefaultCellStyle.Format = "20##-##-##";
            dgvDataGridView.Columns["PLNAMT"].DefaultCellStyle.Format = "#,###.00";
            dgvDataGridView.Columns["PLNEVT"].DefaultCellStyle.Format = "#####";

            System.Data.DataTable dtPosDistro = null;
            int marca = Convert.ToInt16(numMarca);
            dtPosDistro = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenPosDistro(marca, prv, numSty);
            if (dtPosDistro.Rows.Count > 0)
            {
                foreach (DataRow row in dtPosDistro.Rows)
                {
                    tbPosDistro.Text = string.Format("{0:n0}", double.Parse(row["PIEZAS"].ToString()));
                }
            }
        }

        private void Fotos_Resize(object sender, EventArgs e)
        {
            pbFoto.Width  = this.Width  - dgvOffset;
            pbFoto.Height = this.Height - dgvOffset2;
        }

        private void gbCostoPrecio_Paint(object sender, PaintEventArgs e)
        {
            GroupBox box = sender as GroupBox;
            DrawGroupBox(box, e.Graphics, Color.DarkSlateGray, Color.DarkSlateGray);
        }

        private void DrawGroupBox(GroupBox box, Graphics g, Color textColor, Color borderColor)
        {
            if (box != null)
            {
                Brush textBrush = new SolidBrush(textColor);
                Brush borderBrush = new SolidBrush(borderColor);
                Pen borderPen = new Pen(borderBrush);
                SizeF strSize = g.MeasureString(box.Text, box.Font);
                Rectangle rect = new Rectangle(box.ClientRectangle.X,
                                               box.ClientRectangle.Y + (int)(strSize.Height / 2),
                                               box.ClientRectangle.Width - 1,
                                               box.ClientRectangle.Height - (int)(strSize.Height / 2) - 1);

                // Clear text and border
                g.Clear(this.BackColor);

                // Draw text
                g.DrawString(box.Text, box.Font, textBrush, box.Padding.Left, 0);

                // Drawing Border
                //Left
                g.DrawLine(borderPen, rect.Location, new Point(rect.X, rect.Y + rect.Height));
                //Right
                g.DrawLine(borderPen, new Point(rect.X + rect.Width, rect.Y), new Point(rect.X + rect.Width, rect.Y + rect.Height));
                //Bottom
                g.DrawLine(borderPen, new Point(rect.X, rect.Y + rect.Height), new Point(rect.X + rect.Width, rect.Y + rect.Height));
                //Top1
                g.DrawLine(borderPen, new Point(rect.X, rect.Y), new Point(rect.X + box.Padding.Left, rect.Y));
                //Top2
                g.DrawLine(borderPen, new Point(rect.X + box.Padding.Left + (int)(strSize.Width), rect.Y), new Point(rect.X + rect.Width, rect.Y));
            }
        }

        private void gbVtas8Semanas_Paint(object sender, PaintEventArgs e)
        {
            GroupBox box = sender as GroupBox;
            DrawGroupBox(box, e.Graphics, Color.DarkSlateGray, Color.DarkSlateGray);
        }

        private void btAceptar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pnTitulo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnTitulo_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            dragCursorPoint = Cursor.Position;
            dragFormPoint = this.Location;
        }

        private void pnTitulo_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point dif = Point.Subtract(Cursor.Position, new Size(dragCursorPoint));
                this.Location = Point.Add(dragFormPoint, new Size(dif));
            }
        }

        private void pnTitulo_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void pbSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
