﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.Utilerias
{
    public partial class VarTem : Form
    {
        public static string tmpFchInicial { get; set; }
        public static string tmpUser   { get; set; }
        public static string tmpPass   { get; set; }

        public static string tmpUSRNOM { get; set; }
        public static string tmpUSRVIL { get; set; }
        public static string tmpUSRMAR { get; set; }
        public static string tmpUSRCOM { get; set; }
        public static string tmpDESC   { get; set; }

        public static string tmpUSRUSR { get; set; }
        public static string tmpUSRPER { get; set; }

        public static string tmpUPUPRF { get; set; }
        public static string tmpUPTEXT { get; set; }

        public static string tmpPERPER { get; set; }

        public static string tmpPrv            { get; set; }
        public static string tmpTienda         { get; set; }
        public static string tmpNom            { get; set; }
        public static string tmpSty            { get; set; }
        public static string tmpDes            { get; set; }
        public static string tmpMarca          { get; set; }
        public static string tmpComprador      { get; set; }
        public static string tmpTemporadaMms   { get; set; }
        public static string tmpCompDesc       { get; set; }
        public static string tmpTemporada      { get; set; }
        public static string tmpOrigen         { get; set; }
        public static string tmpReprogramacion { get; set; }
        public static string tmpExcepcion      { get; set; }
        public static string tmpFolio          { get; set; }

        public static string tmpFchBon     { get; set; }
        public static string tmpTpo        { get; set; }
        public static string tmpTmp        { get; set; }
        public static string tmpStr        { get; set; }
        public static string tmpFchRev     { get; set; }
        public static string tmpNotBon     { get; set; }
        public static string tmpNotCal     { get; set; }
        public static string tmpCal        { get; set; }

        public static string tmpNota       { get; set; }
        public static string tmpRutaPdf    { get; set; }
        public static string tmpPerfil     { get; set; }
        public static string tmpUsuario    { get; set; }

        public static string tmpAplicacion { get; set; }
        public static string tmpModulo     { get; set; }
        // Variables Temporales de Tablas Rentabilidad                                                  

        public static string tmpTblMar { get; set; }
        public static string tmpTblTbl { get; set; }

        // Usuario del Convenio                                                                         

        public static string tmpUsrConv { get; set; }
        public static Boolean simulador { get; set; }
        public static string tmpFchConv { get; set; }
        public static string tmpCalConv { get; set; }
        public static string tmpRentab  { get; set; }
        public static string tmpOrden   { get; set; }


        // Kardex
        public static string tmpAnio      { get; set; }
        public static string tmpSemana    { get; set; }
        public static string tmpTipo      { get; set; }
        public static string tmpFechaTipo { get; set; }

        // Usuario del Calificaciones                                                                   

        public static string tmpCalCalif { get; set; }

        // Usuario del Reprogramacion                                                                   

        public static string tmpFchReprog { get; set; }

        // Configuracion Actual                                                                         
        public static DataTable BkConfiguracion { get; set; }

        // Nota de Credito PDF                                                                          
        public static string tmpDestNcPDF { get; set; }

        // Variables de Nota de Credito
        public static string NotaFchRevision { get; set; }
        public static string NotaFchBonifica { get; set; }
        public static string NotaProveedor   { get; set; }
        public static string NotaNombre      { get; set; }
        public static string NotaEstilo      { get; set; }
        public static string NotaDescripcion { get; set; }


        // Variables Bonificaciones Anticipadas                                                         
        public static string tmpBonAntPrv     { get; set; }
        public static string tmpBonAntSty     { get; set; }

        public static string tmpBonAntFch     { get; set; }
        public static string tmpBonAntBdg     { get; set; }
        public static string tmpBonAntOrd     { get; set; }
        public static string ConvMarcaNo      { get; set; }
        public static DataTable BkFechaAmover { get; set; }

        // Variables Convenio                                                                           
        public static string tmpBonAntPza { get; set; }

        // Variables de Calificacion
        public static string tmpCalificacionAnt { get; set; }
        public static string tmpCalificacionFin { get; set; }
        public static string tmpOnHand          { get; set; }
        public static string tmpCtoActu         { get; set; }
        public static string tmpCtoTotal        { get; set; }
        public static string tmpCtoBoni         { get; set; }
        public static string tmpMarcaGrid       { get; set; }
        public static string tmpNoEventos       { get; set; }

        // Variables Calificacion Melody  
  
        //public static string parMarca;
        //public static string parComprador;
        public static string tmpPrvTda      { get; set; }
        public static string tmpStyTda      { get; set; }
        public static string parFchDesdeTda { get; set; }
        public static string parFchHastaTda { get; set; }
        public static string tmpTipoGlobal  { get; set; }
        //public static string parTemporadaGlobal;
        //public static string parTipoCalificacion;

        public static string parmarca            { get; set; }
        public static string parcomprador        { get; set; }
        public static string parFchDe            { get; set; }
        public static string parFchHas           { get; set; }
        public static string partipo             { get; set; }
        public static string partemporada        { get; set; }
        public static string parTipoCalificacion { get; set; }
        public static string parFchCalificacion  { get; set; }
        public static string parProveedor        { get; set; }
        public static string parNombre           { get; set; }
        public static string parEstilo           { get; set; }
        public static string parDescripcion      { get; set; }

        // Variables de Rebaja Diferenciada - - - - - - 
        public static string rbdFchBon    { get; set; }
        public static string rbdFchRev    { get; set; }
        public static string rbdTipoCal   { get; set; }
        public static string rbdTemporada { get; set; }
        public static string rbdTienda    { get; set; }
        public static string rbdProveedor { get; set; }
        public static string rbdEstilo    { get; set; }
        public static string rbdNota      { get; set; }

        // Variables de Rebaja Diferenciada Documentos 
        public static string rddFchBon    { get; set; }
        public static string rddFchRev    { get; set; }
        public static string rddTipoCal   { get; set; }
        public static string rddTemporada { get; set; }
        public static string rddTienda    { get; set; }
        public static string rddProveedor { get; set; }
        public static string rddEstilo    { get; set; }
        public static string rddNota      { get; set; }

        public VarTem()
        {
            InitializeComponent();
        }

        private void VarTem_Load(object sender, EventArgs e)
        {

        }
    }


}
