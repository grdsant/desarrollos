﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class DetalleTemporada : Form
    {
        #region Variables locales
        public static string marca        { get; set; }
        public static string grupo        { get; set; }
        public static string descripcion  { get; set; }
        public static string estatus      { get; set; }
        public static string tipo         { get; set; }
        #endregion

        int nr = 0;
        string ParUser;
        bool Carga;

        int dgvOffset;
        int dgvOffset2;

        Point mousedownpoint = Point.Empty;

        public System.Data.DataTable dtEstilos = null;

        public DetalleTemporada()
        {
            InitializeComponent();
            dgvOffset  = this.Width  - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }


        private void DetalleTemporada_Load(object sender, EventArgs e)
        {
            Carga = true;
            BindData();
          //  SetFontAndColors();
          //  rowStyle();

            // Seguridad...                                                                     
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("ConvenioMelody", "DetalleTemporada", ParUser);
        }

        // Carga Datos                                                                                    
        //
        protected void BindData()
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string proveedor   = tbProveedor.Text;
                string nombre      = tbNombre.Text;
                string estilo      = tbEstilo.Text;
                string descripcion = tbDescripcion.Text;

                string dp  = tbDP.Text;
                string sd  = tbSD.Text;
                string cl  = tbCL.Text;
                string sc  = tbSC.Text;
                string dpd = tbDPD.Text;
                string sdd = tbSDD.Text;
                string cld = tbCLD.Text;
                string scd = tbSCD.Text;

                string marca = MmsWin.Front.ConvenioMelody.DetalleTemporada.marca;
                string grupo = MmsWin.Front.ConvenioMelody.DetalleTemporada.grupo;
                string tipo  = MmsWin.Front.ConvenioMelody.DetalleTemporada.tipo;

                string usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                dtEstilos = MmsWin.Negocio.ConvenioMelody.DetalleEstilos.GetInstance().ObtenDetalleEstilos(marca, grupo, tipo, proveedor, nombre, estilo, descripcion, dp, sd, cl, sc, dpd, sdd, cld, scd, usuario);
            }
            catch { }

            if (dtEstilos != null)
            {
                if (dtEstilos.Rows.Count > 0)
                {
                    SetDoubleBuffered(dgvGridView);
                    dgvGridView.DataSource = null;

                    dgvGridView.DataSource = dtEstilos;

                    nr = dgvGridView.RowCount;
                    lbTitulo.Text = "Detalle nivel estilo / " + " " + (nr).ToString() + " Registro(s)";
                    SetFontAndColors();
                    rowStyle();

                    //// Seguridad...
                    //ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                    //Seguridad("Convenio", "Convenio", ParUser);
                    //dgvGridView.Visible = false;

                    //dgvGridView.Focus();
                    //dgvGridView.Select();
                }
            }
            this.Cursor = Cursors.Default;
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        // Atributos y caracteristicas                                                                    
        //
        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvGridView.Columns[1].Frozen = true;

            dgvGridView.Columns["ESTPRV"].HeaderText = "Proveedor";
            dgvGridView.Columns["ESTPRD"].HeaderText = "Nombre";
            dgvGridView.Columns["ESPSTY"].HeaderText = "Estilo";
            dgvGridView.Columns["ESPDES"].HeaderText = "Descripción";
            dgvGridView.Columns["ESTDP"].HeaderText  = "DP";
            dgvGridView.Columns["ESTSD"].HeaderText  = "SD";
            dgvGridView.Columns["ESTCL"].HeaderText  = "CL";
            dgvGridView.Columns["ESTSC"].HeaderText  = "SC";
            dgvGridView.Columns["ESTDPD"].HeaderText = "Departamento";
            dgvGridView.Columns["ESTSDD"].HeaderText = "Sub Depto";
            dgvGridView.Columns["ESTCLD"].HeaderText = "Clase";
            dgvGridView.Columns["ESTSCD"].HeaderText = "Sub Clase";
            dgvGridView.Columns["ESTSTS"].HeaderText = "Sts";
            dgvGridView.Columns["ESTUAL"].HeaderText = "Usuario";
            dgvGridView.Columns["ESTFAL"].HeaderText = "Fecha";
            dgvGridView.Columns["ESTHAL"].HeaderText = "Hora";

            dgvGridView.Columns["ESTPRV"].Width = 40;
            dgvGridView.Columns["ESTPRD"].Width = 180;
            dgvGridView.Columns["ESPSTY"].Width = 80;
            dgvGridView.Columns["ESPDES"].Width = 180;
            dgvGridView.Columns["ESTDP"].Width  = 40;
            dgvGridView.Columns["ESTSD"].Width  = 40;
            dgvGridView.Columns["ESTCL"].Width  = 40;
            dgvGridView.Columns["ESTSC"].Width  = 40;
            dgvGridView.Columns["ESTDPD"].Width = 100;
            dgvGridView.Columns["ESTSDD"].Width = 100;
            dgvGridView.Columns["ESTCLD"].Width = 100;
            dgvGridView.Columns["ESTSCD"].Width = 100;
            dgvGridView.Columns["ESTSTS"].Width = 40;
            dgvGridView.Columns["ESTUAL"].Width = 70;
            dgvGridView.Columns["ESTFAL"].Width = 80;
            dgvGridView.Columns["ESTHAL"].Width = 80;

            dgvGridView.Columns["ESTFAL"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns["ESTHAL"].DefaultCellStyle.Format = "##:##:##";

            dgvGridView.Columns["ESTPRV"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTPRD"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESPSTY"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESPDES"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTDP"].DefaultCellStyle.NullValue  = true;
            dgvGridView.Columns["ESTSD"].DefaultCellStyle.NullValue  = true;
            dgvGridView.Columns["ESTCL"].DefaultCellStyle.NullValue  = true;
            dgvGridView.Columns["ESTSC"].DefaultCellStyle.NullValue  = true;
            dgvGridView.Columns["ESTDPD"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTSDD"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTCLD"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTSCD"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTSTS"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTUAL"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTFAL"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTHAL"].DefaultCellStyle.NullValue = true;

            dgvGridView.Columns["ESTPRV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["ESTPRD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["ESPSTY"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["ESPDES"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["ESTDP"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["ESTSD"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["ESTCL"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["ESTSC"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["ESTDPD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["ESTSDD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["ESTCLD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["ESTSCD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["ESTSTS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["ESTUAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["ESTFAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["ESTHAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns["ESTPRV"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTPRD"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESPSTY"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESPDES"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTDP"].HeaderCell.Style.BackColor  = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTSD"].HeaderCell.Style.BackColor  = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTCL"].HeaderCell.Style.BackColor  = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTSC"].HeaderCell.Style.BackColor  = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTDPD"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTSDD"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTCLD"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTSCD"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTSTS"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTUAL"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTFAL"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTHAL"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);

            dgvGridView.Columns["ESTPRV"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTPRD"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESPSTY"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESPDES"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTDP"].HeaderCell.Style.ForeColor  = Color.WhiteSmoke;
            dgvGridView.Columns["ESTSD"].HeaderCell.Style.ForeColor  = Color.WhiteSmoke;
            dgvGridView.Columns["ESTCL"].HeaderCell.Style.ForeColor  = Color.WhiteSmoke;
            dgvGridView.Columns["ESTSC"].HeaderCell.Style.ForeColor  = Color.WhiteSmoke;
            dgvGridView.Columns["ESTDPD"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTSDD"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTCLD"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTSCD"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTSTS"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTUAL"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTFAL"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTHAL"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
        }
        // Estilo de Renglones                                                                            
        //
        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    //dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.LightGray;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }

        // Seguridad                                                                                 
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab    = row["SEGHAC"].ToString();
                string ValVis    = row["SEGVIC"].ToString();
                string tipo      = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                          
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvGridView.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvGridView.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            //if (tipo == "Menu")
            //{
            //    try
            //    {
            //        bool valorHab = false;
            //        if (ValHab == "1") { valorHab = true; }
            //        cmMenu.Items[Controles].Enabled = valorHab;
            //    }
            //    catch { }

            //    try
            //    {
            //        bool valorVis = false;
            //        if (ValVis == "1") { valorVis = true; }
            //        cmMenu.Items[Controles].Visible = valorVis;
            //    }
            //    catch { }
            //}
            //--------------------------------------
        }

        private void DetalleTemporada_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void DetalleTemporada_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedownpoint.IsEmpty)
                return;
            Form f = sender as Form;
            f.Location = new Point(f.Location.X + (e.X - mousedownpoint.X), f.Location.Y + (e.Y - mousedownpoint.Y));
        }

        private void DetalleTemporada_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

        private void btABC_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "DetCatTempABC").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de tablas de Despalzamiento esta abierta...");
                    }
                    else
                    {
                        MmsWin.Front.ConvenioMelody.DetCatTempABC.marca = "";
                        MmsWin.Front.ConvenioMelody.DetCatTempABC.grupo = "";
                        MmsWin.Front.ConvenioMelody.DetCatTempABC.descripcion = "";
                        MmsWin.Front.ConvenioMelody.DetCatTempABC.estatus = "";

                        MmsWin.Front.ConvenioMelody.DetCatTempABC.userAlta = "";
                        MmsWin.Front.ConvenioMelody.DetCatTempABC.fechaAlta = "";
                        MmsWin.Front.ConvenioMelody.DetCatTempABC.horaAlta = "";
                        MmsWin.Front.ConvenioMelody.DetCatTempABC.userCambio = "";
                        MmsWin.Front.ConvenioMelody.DetCatTempABC.fechaCambio = "";
                        MmsWin.Front.ConvenioMelody.DetCatTempABC.horaCambio = "";

                        DetCatTempABC i = new DetCatTempABC();
                        //i.MdiParent = this.MdiParent;
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void DetalleTemporada_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("ConvenioMelody", "DetalleTemporada", ParUser);
            }
        }
        // Carga Seguridad                                                                                
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            // Controles                                                                  
            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            string NomCol;
            Int32 NoCol = dgvGridView.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvGridView.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            //// Menu                                                                      
            //string NomMenu;
            //Int32 NoItems = cmMenu.Items.Count;
            //for (int i = 0; i < NoItems; i++)
            //{
            //    NomMenu = cmMenu.Items[i].Name.ToString();

            //    DataRow workRow = dtControles.NewRow();
            //    workRow["Aplicacion"] = Aplicacion;
            //    workRow["Modulo"] = Modulo;
            //    workRow["Control"] = NomMenu;
            //    workRow["Tipo"] = "Menu";
            //    workRow["Usuario"] = Usuario;
            //    dtControles.Rows.Add(workRow);
            //}

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void dgvGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cargaVariables();
        }

        private void cargaVariables()
        {
            try
            {
                // Guarda varibles de pantalla

                MmsWin.Front.ConvenioMelody.DetCatTempABC.marca = this.dgvGridView.CurrentRow.Cells["COMMAR"].Value.ToString();
                MmsWin.Front.ConvenioMelody.DetCatTempABC.grupo = this.dgvGridView.CurrentRow.Cells["COMTPP"].Value.ToString();
                MmsWin.Front.ConvenioMelody.DetCatTempABC.descripcion = this.dgvGridView.CurrentRow.Cells["COMDES"].Value.ToString();
                MmsWin.Front.ConvenioMelody.DetCatTempABC.estatus = this.dgvGridView.CurrentRow.Cells["COMSTS"].Value.ToString();

                MmsWin.Front.ConvenioMelody.DetCatTempABC.userAlta = this.dgvGridView.CurrentRow.Cells["COMUAL"].Value.ToString();

                string FechaCal = this.dgvGridView.CurrentRow.Cells["COMFAL"].Value.ToString();
                string FechaFmt = "20" + FechaCal.Substring(0, 2) + "/" + FechaCal.Substring(2, 2) + "/" + FechaCal.Substring(4, 2);
                MmsWin.Front.ConvenioMelody.DetCatTempABC.fechaAlta = FechaFmt;

                string HoraCal = this.dgvGridView.CurrentRow.Cells["COMHAL"].Value.ToString();
                string HoraFmt = HoraCal.Substring(0, 2) + ":" + HoraCal.Substring(2, 2) + ":" + HoraCal.Substring(4, 2);
                MmsWin.Front.ConvenioMelody.DetCatTempABC.horaAlta = HoraFmt;

                MmsWin.Front.ConvenioMelody.DetCatTempABC.userCambio = this.dgvGridView.CurrentRow.Cells["COMUCA"].Value.ToString();
                MmsWin.Front.ConvenioMelody.DetCatTempABC.fechaCambio = this.dgvGridView.CurrentRow.Cells["COMFCA"].Value.ToString();
                MmsWin.Front.ConvenioMelody.DetCatTempABC.horaCambio = this.dgvGridView.CurrentRow.Cells["COMHCA"].Value.ToString();

                dgvGridView.Columns["COMUAL"].HeaderText = "Usuario";
                dgvGridView.Columns["COMFAL"].HeaderText = "Fecha Alta";
                dgvGridView.Columns["COMHAL"].HeaderText = "Hora alta";
                dgvGridView.Columns["COMUCA"].HeaderText = "Usuario Cambio";
                dgvGridView.Columns["COMFCA"].HeaderText = "Fecha Cambio";
                dgvGridView.Columns["COMHCA"].HeaderText = "Hora Cambio";


            }
            catch { }
        }

        private void dgvGridView_SelectionChanged(object sender, EventArgs e)
        {
            cargaVariables();
        }

        private void ConsultarTSMI_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "DetCatTempABC").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de tablas de Despalzamiento esta abierta...");
                    }
                    else
                    {
                        DetCatTempABC i = new DetCatTempABC();
                        //i.MdiParent = this.MdiParent;
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void dgvGridView_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "DetCatTempABC").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de tablas de Despalzamiento esta abierta...");
                    }
                    else
                    {
                        DetCatTempABC i = new DetCatTempABC();
                        //i.MdiParent = this.MdiParent;
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbDescripcion.Focus();
            }
        }

        private void detalleTSMI_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "DetalleTemporada").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de detalle de Temporadas esta abierta...");
                    }
                    else
                    {
                        DetalleTemporada i = new DetalleTemporada();
                        //i.MdiParent = this.MdiParent;
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbSalir_Click(object sender, EventArgs e)
        {

        }

        private void pbSalir_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tbProveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbProveedor.Focus();
            }
        }

        private void tbNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbNombre.Focus();
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbEstilo.Focus();
            }
        }

        private void tbDescripcion_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbDescripcion.Focus();
            }
        }

        private void tbDP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbDP.Focus();
            }
        }

        private void tbSD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbSD.Focus();
            }
        }

        private void tbCL_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbCL.Focus();
            }
        }

        private void tbSC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbSC.Focus();
            }
        }

        private void tbDPD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbDPD.Focus();
            }
        }

        private void tbSDD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbSDD.Focus();
            }
        }

        private void tbCLD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbCLD.Focus();
            }
        }

        private void tbSCD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbSCD.Focus();
            }
        }

    }
}
