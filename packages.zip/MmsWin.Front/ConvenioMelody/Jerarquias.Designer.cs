﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class Jerarquias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Jerarquias));
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.AgregarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.tbSCD = new System.Windows.Forms.TextBox();
            this.tbCLD = new System.Windows.Forms.TextBox();
            this.tbSDD = new System.Windows.Forms.TextBox();
            this.tbSC = new System.Windows.Forms.TextBox();
            this.tbCL = new System.Windows.Forms.TextBox();
            this.tbSD = new System.Windows.Forms.TextBox();
            this.tbDP = new System.Windows.Forms.TextBox();
            this.btRelleno = new System.Windows.Forms.Button();
            this.tbDPD = new System.Windows.Forms.TextBox();
            this.lbJerarquias = new System.Windows.Forms.Label();
            this.pbSalir = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.cmMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel1.Controls.Add(this.dgvGridView);
            this.panel1.Controls.Add(this.tbSCD);
            this.panel1.Controls.Add(this.tbCLD);
            this.panel1.Controls.Add(this.tbSDD);
            this.panel1.Controls.Add(this.tbSC);
            this.panel1.Controls.Add(this.tbCL);
            this.panel1.Controls.Add(this.tbSD);
            this.panel1.Controls.Add(this.tbDP);
            this.panel1.Controls.Add(this.btRelleno);
            this.panel1.Controls.Add(this.tbDPD);
            this.panel1.Location = new System.Drawing.Point(0, 47);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(857, 407);
            this.panel1.TabIndex = 1;
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.ContextMenuStrip = this.cmMenu;
            this.dgvGridView.Location = new System.Drawing.Point(3, 21);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.Size = new System.Drawing.Size(851, 382);
            this.dgvGridView.TabIndex = 8;
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AgregarTSMI});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(172, 26);
            // 
            // AgregarTSMI
            // 
            this.AgregarTSMI.Name = "AgregarTSMI";
            this.AgregarTSMI.Size = new System.Drawing.Size(171, 22);
            this.AgregarTSMI.Text = "Agregar Jerarquias";
            this.AgregarTSMI.Click += new System.EventHandler(this.AgregarTSMI_Click);
            // 
            // tbSCD
            // 
            this.tbSCD.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbSCD.Location = new System.Drawing.Point(655, 1);
            this.tbSCD.Name = "tbSCD";
            this.tbSCD.Size = new System.Drawing.Size(150, 20);
            this.tbSCD.TabIndex = 7;
            this.tbSCD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSCD_KeyPress);
            // 
            // tbCLD
            // 
            this.tbCLD.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbCLD.Location = new System.Drawing.Point(505, 1);
            this.tbCLD.Name = "tbCLD";
            this.tbCLD.Size = new System.Drawing.Size(150, 20);
            this.tbCLD.TabIndex = 6;
            this.tbCLD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCLD_KeyPress);
            // 
            // tbSDD
            // 
            this.tbSDD.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbSDD.Location = new System.Drawing.Point(355, 1);
            this.tbSDD.Name = "tbSDD";
            this.tbSDD.Size = new System.Drawing.Size(150, 20);
            this.tbSDD.TabIndex = 5;
            this.tbSDD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSDD_KeyPress);
            // 
            // tbSC
            // 
            this.tbSC.Location = new System.Drawing.Point(165, 1);
            this.tbSC.Name = "tbSC";
            this.tbSC.Size = new System.Drawing.Size(40, 20);
            this.tbSC.TabIndex = 3;
            this.tbSC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSC_KeyPress);
            // 
            // tbCL
            // 
            this.tbCL.Location = new System.Drawing.Point(125, 1);
            this.tbCL.Name = "tbCL";
            this.tbCL.Size = new System.Drawing.Size(40, 20);
            this.tbCL.TabIndex = 2;
            this.tbCL.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCL_KeyPress);
            // 
            // tbSD
            // 
            this.tbSD.Location = new System.Drawing.Point(85, 1);
            this.tbSD.Name = "tbSD";
            this.tbSD.Size = new System.Drawing.Size(40, 20);
            this.tbSD.TabIndex = 1;
            this.tbSD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSD_KeyPress);
            // 
            // tbDP
            // 
            this.tbDP.Location = new System.Drawing.Point(45, 1);
            this.tbDP.Name = "tbDP";
            this.tbDP.Size = new System.Drawing.Size(40, 20);
            this.tbDP.TabIndex = 0;
            this.tbDP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDP_KeyPress);
            // 
            // btRelleno
            // 
            this.btRelleno.Location = new System.Drawing.Point(2, 0);
            this.btRelleno.Name = "btRelleno";
            this.btRelleno.Size = new System.Drawing.Size(44, 22);
            this.btRelleno.TabIndex = 11;
            this.btRelleno.UseVisualStyleBackColor = true;
            // 
            // tbDPD
            // 
            this.tbDPD.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDPD.Location = new System.Drawing.Point(205, 1);
            this.tbDPD.Name = "tbDPD";
            this.tbDPD.Size = new System.Drawing.Size(150, 20);
            this.tbDPD.TabIndex = 4;
            this.tbDPD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDPD_KeyPress);
            // 
            // lbJerarquias
            // 
            this.lbJerarquias.AutoSize = true;
            this.lbJerarquias.BackColor = System.Drawing.Color.Gray;
            this.lbJerarquias.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbJerarquias.ForeColor = System.Drawing.Color.Black;
            this.lbJerarquias.Location = new System.Drawing.Point(3, 5);
            this.lbJerarquias.Name = "lbJerarquias";
            this.lbJerarquias.Size = new System.Drawing.Size(93, 20);
            this.lbJerarquias.TabIndex = 4;
            this.lbJerarquias.Text = "Jerarquias";
            // 
            // pbSalir
            // 
            this.pbSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pbSalir.Image = ((System.Drawing.Image)(resources.GetObject("pbSalir.Image")));
            this.pbSalir.Location = new System.Drawing.Point(825, 12);
            this.pbSalir.Name = "pbSalir";
            this.pbSalir.Size = new System.Drawing.Size(22, 18);
            this.pbSalir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSalir.TabIndex = 8;
            this.pbSalir.TabStop = false;
            this.pbSalir.Click += new System.EventHandler(this.pbSalir_Click);
            // 
            // Jerarquias
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(860, 456);
            this.Controls.Add(this.pbSalir);
            this.Controls.Add(this.lbJerarquias);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Jerarquias";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Jerarquias";
            this.Load += new System.EventHandler(this.Jerarquias_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Jerarquias_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Jerarquias_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Jerarquias_MouseUp);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.cmMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbJerarquias;
        private System.Windows.Forms.PictureBox pbSalir;
        private System.Windows.Forms.TextBox tbSCD;
        private System.Windows.Forms.TextBox tbCLD;
        private System.Windows.Forms.TextBox tbSDD;
        private System.Windows.Forms.TextBox tbSC;
        private System.Windows.Forms.TextBox tbCL;
        private System.Windows.Forms.TextBox tbSD;
        private System.Windows.Forms.TextBox tbDP;
        private System.Windows.Forms.Button btRelleno;
        private System.Windows.Forms.TextBox tbDPD;
        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem AgregarTSMI;
    }
}