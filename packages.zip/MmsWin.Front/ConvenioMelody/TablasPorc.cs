﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class TablasPorc : Form
    {
        #region Variables locales
        public static string marca        { get; set; }
        public static string tabla        { get; set; }
        public static string secuencia    { get; set; }
        public static string del          { get; set; }
        public static string al           { get; set; }
        public static string porcentaje   { get; set; }
        public static string calificacion { get; set; }
        public static string estatus      { get; set; }
        #endregion

        int nr = 0;
        string ParUser;
        bool Carga;

        int dgvOffset;
        int dgvOffset2;

        Point mousedownpoint = Point.Empty;

        public TablasPorc()
        {
            InitializeComponent();
            dgvOffset  = this.Width  - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }

        private void pbSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TablasPorc_Load(object sender, EventArgs e)
        {
            Carga = true;
            BindData();

            // Seguridad...                                                                     
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("ConvenioMelody", "TablasPorc", ParUser);
        }

        // Carga Datos                                                                                    
        //
        protected void BindData()
        {
            if (Carga == true)
            {
                this.Cursor = Cursors.WaitCursor;
                nr = 0;
                dgvGridView.DataSource = null;
                System.Data.DataTable dtDatos = null;
                try
                {
                    string marca = tbMarca.Text;
                    string tabla = tbTabla.Text;

                    dtDatos = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenTablasPorc(marca, tabla);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                if (dtDatos.Rows.Count > 0)
                {
                    SetDoubleBuffered(dgvGridView);
                    dgvGridView.DataSource = null;
                    dgvGridView.DataSource = dtDatos;
                    nr = dgvGridView.RowCount;
                    this.Text = (nr).ToString() + " " + "Tablas  Rentabilidad";
                    SetFontAndColors();
                    rowStyle();
                }
                this.Cursor = Cursors.Default;
            }
        }
        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        // Atributos y caracteristicas                                                                    
        //
        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvGridView.Columns[2].Frozen = true;

            dgvGridView.Columns["DTBMAR"].HeaderText = "Marca";
            dgvGridView.Columns["DTBNTB"].HeaderText = "Tabla";
            dgvGridView.Columns["DTBSEC"].HeaderText = "Secuencia";
            dgvGridView.Columns["DTBDEL"].HeaderText = "del %";
            dgvGridView.Columns["DTBAL"].HeaderText  = "al %";
            dgvGridView.Columns["DTBPOR"].HeaderText = "% Aplicar";
            dgvGridView.Columns["DTBCAL"].HeaderText = "Calificación";
            dgvGridView.Columns["DTBSTS"].HeaderText = "Estatus";
            dgvGridView.Columns["DTBUAL"].HeaderText = "Usuario";
            dgvGridView.Columns["DTBFAL"].HeaderText = "Fecha Alta";
            dgvGridView.Columns["DTBHAL"].HeaderText = "Hora alta";
            dgvGridView.Columns["DTBUCA"].HeaderText = "Usuario Cambio";
            dgvGridView.Columns["DTBFCA"].HeaderText = "Fecha Cambio";
            dgvGridView.Columns["DTBHCA"].HeaderText = "Hora Cambio";

            dgvGridView.Columns["DTBMAR"].Width = 60;
            dgvGridView.Columns["DTBNTB"].Width = 60;
            dgvGridView.Columns["DTBSEC"].Width = 60;
            dgvGridView.Columns["DTBDEL"].Width = 70;
            dgvGridView.Columns["DTBAL"].Width  = 70;
            dgvGridView.Columns["DTBPOR"].Width = 70;
            dgvGridView.Columns["DTBCAL"].Width = 85;
            dgvGridView.Columns["DTBSTS"].Width = 60;
            dgvGridView.Columns["DTBUAL"].Width = 80;
            dgvGridView.Columns["DTBFAL"].Width = 80;
            dgvGridView.Columns["DTBHAL"].Width = 80;
            dgvGridView.Columns["DTBUCA"].Width = 80;
            dgvGridView.Columns["DTBFCA"].Width = 80;
            dgvGridView.Columns["DTBHCA"].Width = 80;

            dgvGridView.Columns["DTBMAR"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["DTBNTB"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["DTBSEC"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["DTBDEL"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["DTBAL"].DefaultCellStyle.NullValue  = true;
            dgvGridView.Columns["DTBPOR"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["DTBCAL"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["DTBSTS"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["DTBUAL"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["DTBFAL"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["DTBHAL"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["DTBUCA"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["DTBFCA"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["DTBHCA"].DefaultCellStyle.NullValue = true;

            dgvGridView.Columns["DTBMAR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["DTBNTB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["DTBSEC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["DTBDEL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["DTBAL"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["DTBPOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["DTBCAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["DTBSTS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["DTBUAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["DTBFAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["DTBHAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["DTBUCA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["DTBFCA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["DTBHCA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns["DTBFAL"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns["DTBFCA"].DefaultCellStyle.Format = "20##-##-##";

            dgvGridView.Columns["DTBHAL"].DefaultCellStyle.Format = "##:##:##";
            dgvGridView.Columns["DTBHCA"].DefaultCellStyle.Format = "##:##:##";

            dgvGridView.Columns["DTBDEL"].DefaultCellStyle.Format = "#0.0000";
            dgvGridView.Columns["DTBAL"].DefaultCellStyle.Format  = "#0.0000";
            dgvGridView.Columns["DTBPOR"].DefaultCellStyle.Format = "#0.0000";

            dgvGridView.Columns["DTBMAR"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["DTBNTB"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns["DTBSEC"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns["DTBDEL"].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns["DTBAL"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns["DTBPOR"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["DTBCAL"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns["DTBSTS"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns["DTBUAL"].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns["DTBFAL"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns["DTBHAL"].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns["DTBUCA"].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns["DTBFCA"].HeaderCell.Style.BackColor = Color.LightBlue;
            dgvGridView.Columns["DTBHCA"].HeaderCell.Style.BackColor = Color.LightBlue;
        }
        // Estilo de Renglones                                                                            
        //
        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }

                // Pagar
                if (Convert.ToString(rowp.Cells["DTBCAL"].Value) == "P a g a r") { rowp.Cells["DTBCAL"].Style.BackColor = Color.LightGreen; }
                // 10%
                if (Convert.ToString(rowp.Cells["DTBCAL"].Value) == "10%") { rowp.Cells["DTBCAL"].Style.BackColor = Color.Yellow; }
                // 15%
                if (Convert.ToString(rowp.Cells["DTBCAL"].Value) == "15%") { rowp.Cells["DTBCAL"].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(rowp.Cells["DTBCAL"].Value) == "20%") { rowp.Cells["DTBCAL"].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(rowp.Cells["DTBCAL"].Value) == "25%") { rowp.Cells["DTBCAL"].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(rowp.Cells["DTBCAL"].Value) == "30%") { rowp.Cells["DTBCAL"].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(rowp.Cells["DTBCAL"].Value) == "35%") { rowp.Cells["DTBCAL"].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(rowp.Cells["DTBCAL"].Value) == "40%") { rowp.Cells["DTBCAL"].Style.BackColor = Color.LightSalmon; }
                //Dev o 50%
                if (Convert.ToString(rowp.Cells["DTBCAL"].Value) == "50%") { rowp.Cells["DTBCAL"].Style.BackColor = Color.Red; rowp.Cells["DTBCAL"].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(rowp.Cells["DTBCAL"].Value) == "50%") { rowp.Cells["DTBCAL"].Style.BackColor = Color.Red; rowp.Cells["DTBCAL"].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(rowp.Cells["DTBCAL"].Value) == "Devolución") { rowp.Cells["DTBCAL"].Style.BackColor = Color.Red; rowp.Cells["DTBCAL"].Style.ForeColor = Color.White; }

            }
        }

        // Seguridad                                                                                 
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                          
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvGridView.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvGridView.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenu.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenu.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        private void TablasPorc_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void TablasPorc_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedownpoint.IsEmpty)
                return;
            Form f = sender as Form;
            f.Location = new Point(f.Location.X + (e.X - mousedownpoint.X), f.Location.Y + (e.Y - mousedownpoint.Y));
        }

        private void TablasPorc_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

        private void btABC_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "TablasPorcABC").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de tablas de Despalzamiento esta abierta...");
                    }
                    else
                    {
                        MmsWin.Front.ConvenioMelody.TablasPorcABC.marca        = "";
                        MmsWin.Front.ConvenioMelody.TablasPorcABC.tabla        = "";
                        MmsWin.Front.ConvenioMelody.TablasPorcABC.secuencia    = "";
                        MmsWin.Front.ConvenioMelody.TablasPorcABC.del          = "";
                        MmsWin.Front.ConvenioMelody.TablasPorcABC.al           = "";
                        MmsWin.Front.ConvenioMelody.TablasPorcABC.porcentaje   = "";
                        MmsWin.Front.ConvenioMelody.TablasPorcABC.calificacion = "";
                        MmsWin.Front.ConvenioMelody.TablasPorcABC.estatus      = "";

                        MmsWin.Front.ConvenioMelody.TablasPorcABC.userAlta    = "";
                        MmsWin.Front.ConvenioMelody.TablasPorcABC.fechaAlta   = "";
                        MmsWin.Front.ConvenioMelody.TablasPorcABC.horaAlta    = "";
                        MmsWin.Front.ConvenioMelody.TablasPorcABC.userCambio  = "";
                        MmsWin.Front.ConvenioMelody.TablasPorcABC.fechaCambio = "";
                        MmsWin.Front.ConvenioMelody.TablasPorcABC.horaCambio  = "";

                        TablasPorcABC i = new TablasPorcABC();
                        //i.MdiParent = this.MdiParent;
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void TablasPorc_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("ConvenioMelody", "TablasPorc", ParUser);
            }
        }
        // Carga Seguridad                                                                                
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            // Controles                                                                  
            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            string NomCol;
            Int32 NoCol = dgvGridView.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvGridView.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      
            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void dgvGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cargaVariables();
        }

        private void cargaVariables()
        {
            try
            {
                // Guarda varibles de pantalla

                MmsWin.Front.ConvenioMelody.TablasPorcABC.marca        = this.dgvGridView.CurrentRow.Cells["DTBMAR"].Value.ToString();
                MmsWin.Front.ConvenioMelody.TablasPorcABC.tabla        = this.dgvGridView.CurrentRow.Cells["DTBNTB"].Value.ToString();
                MmsWin.Front.ConvenioMelody.TablasPorcABC.secuencia    = this.dgvGridView.CurrentRow.Cells["DTBSEC"].Value.ToString();
                MmsWin.Front.ConvenioMelody.TablasPorcABC.del          = this.dgvGridView.CurrentRow.Cells["DTBDEL"].Value.ToString();
                MmsWin.Front.ConvenioMelody.TablasPorcABC.al           = this.dgvGridView.CurrentRow.Cells["DTBAL"].Value.ToString();
                MmsWin.Front.ConvenioMelody.TablasPorcABC.porcentaje   = this.dgvGridView.CurrentRow.Cells["DTBPOR"].Value.ToString();
                MmsWin.Front.ConvenioMelody.TablasPorcABC.calificacion = this.dgvGridView.CurrentRow.Cells["DTBCAL"].Value.ToString();
                MmsWin.Front.ConvenioMelody.TablasPorcABC.estatus      = this.dgvGridView.CurrentRow.Cells["DTBSTS"].Value.ToString();

                MmsWin.Front.ConvenioMelody.TablasPorcABC.userAlta    = this.dgvGridView.CurrentRow.Cells["DTBUAL"].Value.ToString();

                string FechaCal = this.dgvGridView.CurrentRow.Cells["DTBFAL"].Value.ToString();
                string FechaFmt =  "20" + FechaCal.Substring(0, 2) + "/" + FechaCal.Substring(2, 2) + "/"  + FechaCal.Substring(4, 2);
                MmsWin.Front.ConvenioMelody.TablasPorcABC.fechaAlta = FechaFmt;

                string HoraCal = this.dgvGridView.CurrentRow.Cells["DTBHAL"].Value.ToString();
                string HoraFmt = HoraCal.Substring(0, 2) + ":" + HoraCal.Substring(2, 2) + ":" + HoraCal.Substring(4, 2);
                MmsWin.Front.ConvenioMelody.TablasPorcABC.horaAlta = HoraFmt;

                MmsWin.Front.ConvenioMelody.TablasPorcABC.userCambio  = this.dgvGridView.CurrentRow.Cells["DTBUCA"].Value.ToString();
                MmsWin.Front.ConvenioMelody.TablasPorcABC.fechaCambio = this.dgvGridView.CurrentRow.Cells["DTBFCA"].Value.ToString();
                MmsWin.Front.ConvenioMelody.TablasPorcABC.horaCambio  = this.dgvGridView.CurrentRow.Cells["DTBHCA"].Value.ToString();

                dgvGridView.Columns["DTBUAL"].HeaderText = "Usuario";
                dgvGridView.Columns["DTBFAL"].HeaderText = "Fecha Alta";
                dgvGridView.Columns["DTBHAL"].HeaderText = "Hora alta";
                dgvGridView.Columns["DTBUCA"].HeaderText = "Usuario Cambio";
                dgvGridView.Columns["DTBFCA"].HeaderText = "Fecha Cambio";
                dgvGridView.Columns["DTBHCA"].HeaderText = "Hora Cambio";


            }
            catch { }
        }

        private void dgvGridView_SelectionChanged(object sender, EventArgs e)
        {
            cargaVariables();
        }

        private void ConsultarTSMI_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "TablasPorcABC").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de tablas de porcentaje esta abierta...");
                    }
                    else
                    {
                        TablasPorcABC i = new TablasPorcABC();
                        //i.MdiParent = this.MdiParent;
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void tbMarca_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                //FechaCal = tbDesde.Text;
                //FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                //FchDeN = long.Parse(FechaFmt.ToString());
                //FchDe = FechaFmt.ToString();

                BindData();
                //tbProveedor.Focus();
            }
        }

        private void tbTabla_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                //FechaCal = tbDesde.Text;
                //FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                //FchDeN = long.Parse(FechaFmt.ToString());
                //FchDe = FechaFmt.ToString();

                BindData();
                //tbProveedor.Focus();
            }
        }

        private void dgvGridView_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "TablasPorcABC").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de tablas de Porcentaje esta abierta...");
                    }
                    else
                    {
                        //TablasPorcABC i = new TablasPorcABC();
                        ////i.MdiParent = this.MdiParent;
                        //i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbSalir_Click_1(object sender, EventArgs e)
        {
            this.Close();

        }

    }
}
