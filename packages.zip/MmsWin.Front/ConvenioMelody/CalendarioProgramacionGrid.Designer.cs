﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class CalendarioProgramacionGrid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.cmMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.simuladorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calificarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gbMarca = new System.Windows.Forms.GroupBox();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.gbAnio = new System.Windows.Forms.GroupBox();
            this.cbAnio = new System.Windows.Forms.ComboBox();
            this.gbTemporada = new System.Windows.Forms.GroupBox();
            this.cbTemporada = new System.Windows.Forms.ComboBox();
            this.btC = new System.Windows.Forms.Button();
            this.btR = new System.Windows.Forms.Button();
            this.lbRecibo = new System.Windows.Forms.Label();
            this.btPreCalificacion = new System.Windows.Forms.Button();
            this.lbPreCalificacion = new System.Windows.Forms.Label();
            this.lcCalificacion = new System.Windows.Forms.Label();
            this.lbRebaja1 = new System.Windows.Forms.Label();
            this.btRebaja1 = new System.Windows.Forms.Button();
            this.lbRebaja2 = new System.Windows.Forms.Label();
            this.btRebaja2 = new System.Windows.Forms.Button();
            this.lbPrecalificacion2 = new System.Windows.Forms.Label();
            this.btPreCalificacion2 = new System.Windows.Forms.Button();
            this.lbRB3 = new System.Windows.Forms.Label();
            this.btRB3 = new System.Windows.Forms.Button();
            this.pbRegNew = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.cmMenuStrip.SuspendLayout();
            this.gbMarca.SuspendLayout();
            this.gbAnio.SuspendLayout();
            this.gbTemporada.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbRegNew)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.ColumnHeadersHeight = 30;
            this.dgvGridView.ContextMenuStrip = this.cmMenuStrip;
            this.dgvGridView.Location = new System.Drawing.Point(9, 55);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgvGridView.Size = new System.Drawing.Size(1027, 479);
            this.dgvGridView.TabIndex = 0;
            this.dgvGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellClick);
            this.dgvGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellDoubleClick);
            this.dgvGridView.CellMouseMove += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvGridView_CellMouseMove);
            this.dgvGridView.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dgvGridView_CellPainting);
            this.dgvGridView.CellParsing += new System.Windows.Forms.DataGridViewCellParsingEventHandler(this.dgvGridView_CellParsing);
            this.dgvGridView.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.dgvGridView_DataBindingComplete);
            this.dgvGridView.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgvGridView_EditingControlShowing);
            this.dgvGridView.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dgvGridView_RowPostPaint);
            this.dgvGridView.SelectionChanged += new System.EventHandler(this.dgvGridView_SelectionChanged);
            this.dgvGridView.Sorted += new System.EventHandler(this.dgvGridView_Sorted);
            this.dgvGridView.DoubleClick += new System.EventHandler(this.dgvGridView_DoubleClick);
            this.dgvGridView.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dgvGridView_KeyPress);
            this.dgvGridView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvGridView_KeyUp);
            // 
            // cmMenuStrip
            // 
            this.cmMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.simuladorToolStripMenuItem,
            this.calificarToolStripMenuItem});
            this.cmMenuStrip.Name = "cmMenuStrip";
            this.cmMenuStrip.Size = new System.Drawing.Size(129, 48);
            // 
            // simuladorToolStripMenuItem
            // 
            this.simuladorToolStripMenuItem.Name = "simuladorToolStripMenuItem";
            this.simuladorToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.simuladorToolStripMenuItem.Text = "Simulador";
            this.simuladorToolStripMenuItem.Click += new System.EventHandler(this.simuladorToolStripMenuItem_Click);
            // 
            // calificarToolStripMenuItem
            // 
            this.calificarToolStripMenuItem.Name = "calificarToolStripMenuItem";
            this.calificarToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.calificarToolStripMenuItem.Text = "Calificar";
            this.calificarToolStripMenuItem.Click += new System.EventHandler(this.calificarToolStripMenuItem_Click);
            // 
            // gbMarca
            // 
            this.gbMarca.Controls.Add(this.cbMarca);
            this.gbMarca.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbMarca.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.gbMarca.Location = new System.Drawing.Point(80, 2);
            this.gbMarca.Name = "gbMarca";
            this.gbMarca.Size = new System.Drawing.Size(85, 47);
            this.gbMarca.TabIndex = 24;
            this.gbMarca.TabStop = false;
            this.gbMarca.Text = "Marca";
            this.gbMarca.Paint += new System.Windows.Forms.PaintEventHandler(this.gbMarca_Paint);
            // 
            // cbMarca
            // 
            this.cbMarca.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.cbMarca.FormattingEnabled = true;
            this.cbMarca.Location = new System.Drawing.Point(5, 19);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(75, 21);
            this.cbMarca.TabIndex = 11;
            this.cbMarca.SelectedValueChanged += new System.EventHandler(this.cbMarca_SelectedValueChanged);
            // 
            // gbAnio
            // 
            this.gbAnio.Controls.Add(this.cbAnio);
            this.gbAnio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbAnio.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.gbAnio.Location = new System.Drawing.Point(12, 2);
            this.gbAnio.Name = "gbAnio";
            this.gbAnio.Size = new System.Drawing.Size(63, 47);
            this.gbAnio.TabIndex = 25;
            this.gbAnio.TabStop = false;
            this.gbAnio.Text = "Año";
            this.gbAnio.Paint += new System.Windows.Forms.PaintEventHandler(this.gbAnio_Paint);
            // 
            // cbAnio
            // 
            this.cbAnio.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.cbAnio.FormattingEnabled = true;
            this.cbAnio.Items.AddRange(new object[] {
            "2010",
            "2011",
            "2012",
            "2013",
            "2014",
            "2015",
            "2016",
            "2017",
            "2018",
            "2019",
            "2020",
            "2021",
            "2022",
            "2023",
            "2024",
            "2025",
            "2026",
            "2027"});
            this.cbAnio.Location = new System.Drawing.Point(5, 19);
            this.cbAnio.Name = "cbAnio";
            this.cbAnio.Size = new System.Drawing.Size(52, 21);
            this.cbAnio.TabIndex = 11;
            this.cbAnio.SelectedValueChanged += new System.EventHandler(this.cbAnio_SelectedValueChanged);
            // 
            // gbTemporada
            // 
            this.gbTemporada.Controls.Add(this.cbTemporada);
            this.gbTemporada.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbTemporada.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.gbTemporada.Location = new System.Drawing.Point(171, 2);
            this.gbTemporada.Name = "gbTemporada";
            this.gbTemporada.Size = new System.Drawing.Size(217, 47);
            this.gbTemporada.TabIndex = 25;
            this.gbTemporada.TabStop = false;
            this.gbTemporada.Text = "Temporada";
            this.gbTemporada.Paint += new System.Windows.Forms.PaintEventHandler(this.gbTemporada_Paint);
            // 
            // cbTemporada
            // 
            this.cbTemporada.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.cbTemporada.FormattingEnabled = true;
            this.cbTemporada.Location = new System.Drawing.Point(4, 19);
            this.cbTemporada.Name = "cbTemporada";
            this.cbTemporada.Size = new System.Drawing.Size(207, 21);
            this.cbTemporada.TabIndex = 11;
            this.cbTemporada.SelectedIndexChanged += new System.EventHandler(this.cbTemporada_SelectedIndexChanged);
            this.cbTemporada.SelectedValueChanged += new System.EventHandler(this.cbTemporada_SelectedValueChanged);
            // 
            // btC
            // 
            this.btC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btC.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btC.Location = new System.Drawing.Point(351, 538);
            this.btC.Name = "btC";
            this.btC.Size = new System.Drawing.Size(31, 23);
            this.btC.TabIndex = 26;
            this.btC.Text = "C";
            this.btC.UseVisualStyleBackColor = false;
            // 
            // btR
            // 
            this.btR.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btR.BackColor = System.Drawing.Color.SkyBlue;
            this.btR.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btR.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btR.Location = new System.Drawing.Point(14, 538);
            this.btR.Name = "btR";
            this.btR.Size = new System.Drawing.Size(31, 23);
            this.btR.TabIndex = 27;
            this.btR.Text = "R";
            this.btR.UseVisualStyleBackColor = false;
            // 
            // lbRecibo
            // 
            this.lbRecibo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbRecibo.AutoSize = true;
            this.lbRecibo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRecibo.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbRecibo.Location = new System.Drawing.Point(46, 543);
            this.lbRecibo.Name = "lbRecibo";
            this.lbRecibo.Size = new System.Drawing.Size(47, 13);
            this.lbRecibo.TabIndex = 28;
            this.lbRecibo.Text = "Recibo";
            // 
            // btPreCalificacion
            // 
            this.btPreCalificacion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btPreCalificacion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btPreCalificacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btPreCalificacion.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btPreCalificacion.Location = new System.Drawing.Point(94, 538);
            this.btPreCalificacion.Name = "btPreCalificacion";
            this.btPreCalificacion.Size = new System.Drawing.Size(31, 23);
            this.btPreCalificacion.TabIndex = 29;
            this.btPreCalificacion.Text = "P1";
            this.btPreCalificacion.UseVisualStyleBackColor = false;
            // 
            // lbPreCalificacion
            // 
            this.lbPreCalificacion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbPreCalificacion.AutoSize = true;
            this.lbPreCalificacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPreCalificacion.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbPreCalificacion.Location = new System.Drawing.Point(126, 543);
            this.lbPreCalificacion.Name = "lbPreCalificacion";
            this.lbPreCalificacion.Size = new System.Drawing.Size(92, 13);
            this.lbPreCalificacion.TabIndex = 30;
            this.lbPreCalificacion.Text = "PreCalificación";
            // 
            // lcCalificacion
            // 
            this.lcCalificacion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lcCalificacion.AutoSize = true;
            this.lcCalificacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lcCalificacion.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lcCalificacion.Location = new System.Drawing.Point(383, 543);
            this.lcCalificacion.Name = "lcCalificacion";
            this.lcCalificacion.Size = new System.Drawing.Size(94, 13);
            this.lcCalificacion.TabIndex = 31;
            this.lcCalificacion.Text = "CR Calificación";
            // 
            // lbRebaja1
            // 
            this.lbRebaja1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbRebaja1.AutoSize = true;
            this.lbRebaja1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRebaja1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbRebaja1.Location = new System.Drawing.Point(521, 543);
            this.lbRebaja1.Name = "lbRebaja1";
            this.lbRebaja1.Size = new System.Drawing.Size(32, 13);
            this.lbRebaja1.TabIndex = 33;
            this.lbRebaja1.Text = "RD2";
            // 
            // btRebaja1
            // 
            this.btRebaja1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btRebaja1.BackColor = System.Drawing.Color.Yellow;
            this.btRebaja1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btRebaja1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btRebaja1.Location = new System.Drawing.Point(479, 538);
            this.btRebaja1.Name = "btRebaja1";
            this.btRebaja1.Size = new System.Drawing.Size(40, 23);
            this.btRebaja1.TabIndex = 32;
            this.btRebaja1.Text = "RB1";
            this.btRebaja1.UseVisualStyleBackColor = false;
            // 
            // lbRebaja2
            // 
            this.lbRebaja2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbRebaja2.AutoSize = true;
            this.lbRebaja2.Cursor = System.Windows.Forms.Cursors.Default;
            this.lbRebaja2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRebaja2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbRebaja2.Location = new System.Drawing.Point(600, 543);
            this.lbRebaja2.Name = "lbRebaja2";
            this.lbRebaja2.Size = new System.Drawing.Size(32, 13);
            this.lbRebaja2.TabIndex = 35;
            this.lbRebaja2.Text = "RD3";
            // 
            // btRebaja2
            // 
            this.btRebaja2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btRebaja2.BackColor = System.Drawing.Color.Red;
            this.btRebaja2.Cursor = System.Windows.Forms.Cursors.Default;
            this.btRebaja2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btRebaja2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btRebaja2.Location = new System.Drawing.Point(556, 538);
            this.btRebaja2.Name = "btRebaja2";
            this.btRebaja2.Size = new System.Drawing.Size(39, 23);
            this.btRebaja2.TabIndex = 34;
            this.btRebaja2.Text = "RB2";
            this.btRebaja2.UseVisualStyleBackColor = false;
            // 
            // lbPrecalificacion2
            // 
            this.lbPrecalificacion2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbPrecalificacion2.AutoSize = true;
            this.lbPrecalificacion2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPrecalificacion2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbPrecalificacion2.Location = new System.Drawing.Point(251, 543);
            this.lbPrecalificacion2.Name = "lbPrecalificacion2";
            this.lbPrecalificacion2.Size = new System.Drawing.Size(99, 13);
            this.lbPrecalificacion2.TabIndex = 37;
            this.lbPrecalificacion2.Text = "PreCalificación2";
            // 
            // btPreCalificacion2
            // 
            this.btPreCalificacion2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btPreCalificacion2.BackColor = System.Drawing.Color.Maroon;
            this.btPreCalificacion2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btPreCalificacion2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btPreCalificacion2.Location = new System.Drawing.Point(219, 538);
            this.btPreCalificacion2.Name = "btPreCalificacion2";
            this.btPreCalificacion2.Size = new System.Drawing.Size(31, 23);
            this.btPreCalificacion2.TabIndex = 36;
            this.btPreCalificacion2.Text = "P2";
            this.btPreCalificacion2.UseVisualStyleBackColor = false;
            // 
            // lbRB3
            // 
            this.lbRB3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lbRB3.AutoSize = true;
            this.lbRB3.Cursor = System.Windows.Forms.Cursors.Default;
            this.lbRB3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRB3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbRB3.Location = new System.Drawing.Point(678, 543);
            this.lbRB3.Name = "lbRB3";
            this.lbRB3.Size = new System.Drawing.Size(32, 13);
            this.lbRB3.TabIndex = 41;
            this.lbRB3.Text = "RD4";
            // 
            // btRB3
            // 
            this.btRB3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btRB3.BackColor = System.Drawing.Color.Blue;
            this.btRB3.Cursor = System.Windows.Forms.Cursors.Default;
            this.btRB3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btRB3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btRB3.Location = new System.Drawing.Point(635, 538);
            this.btRB3.Name = "btRB3";
            this.btRB3.Size = new System.Drawing.Size(39, 23);
            this.btRB3.TabIndex = 40;
            this.btRB3.Text = "RB3";
            this.btRB3.UseVisualStyleBackColor = false;
            // 
            // pbRegNew
            // 
            this.pbRegNew.Image = global::MmsWin.Front.Properties.Resources.Plus_50px1;
            this.pbRegNew.Location = new System.Drawing.Point(751, 8);
            this.pbRegNew.Name = "pbRegNew";
            this.pbRegNew.Size = new System.Drawing.Size(45, 41);
            this.pbRegNew.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbRegNew.TabIndex = 39;
            this.pbRegNew.TabStop = false;
            this.pbRegNew.Click += new System.EventHandler(this.pbRegNew_Click);
            // 
            // CalendarioProgramacionGrid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1048, 561);
            this.Controls.Add(this.lbRB3);
            this.Controls.Add(this.btRB3);
            this.Controls.Add(this.pbRegNew);
            this.Controls.Add(this.lbPrecalificacion2);
            this.Controls.Add(this.btPreCalificacion2);
            this.Controls.Add(this.lbRebaja2);
            this.Controls.Add(this.btRebaja2);
            this.Controls.Add(this.lbRebaja1);
            this.Controls.Add(this.btRebaja1);
            this.Controls.Add(this.lcCalificacion);
            this.Controls.Add(this.lbPreCalificacion);
            this.Controls.Add(this.btPreCalificacion);
            this.Controls.Add(this.lbRecibo);
            this.Controls.Add(this.btR);
            this.Controls.Add(this.btC);
            this.Controls.Add(this.gbTemporada);
            this.Controls.Add(this.gbAnio);
            this.Controls.Add(this.gbMarca);
            this.Controls.Add(this.dgvGridView);
            this.DoubleBuffered = true;
            this.Name = "CalendarioProgramacionGrid";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calendario de Programacion";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CalendarioProgramacionGrid_FormClosing);
            this.Load += new System.EventHandler(this.CalendarioProgramacionGrid_Load);
            this.Resize += new System.EventHandler(this.CalendarioProgramacionGrid_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.cmMenuStrip.ResumeLayout(false);
            this.gbMarca.ResumeLayout(false);
            this.gbAnio.ResumeLayout(false);
            this.gbTemporada.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbRegNew)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.ContextMenuStrip cmMenuStrip;
        private System.Windows.Forms.GroupBox gbMarca;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.GroupBox gbAnio;
        private System.Windows.Forms.ComboBox cbAnio;
        private System.Windows.Forms.GroupBox gbTemporada;
        private System.Windows.Forms.ComboBox cbTemporada;
        private System.Windows.Forms.Button btC;
        private System.Windows.Forms.Button btR;
        private System.Windows.Forms.Label lbRecibo;
        private System.Windows.Forms.Button btPreCalificacion;
        private System.Windows.Forms.Label lbPreCalificacion;
        private System.Windows.Forms.Label lcCalificacion;
        private System.Windows.Forms.Label lbRebaja1;
        private System.Windows.Forms.Button btRebaja1;
        private System.Windows.Forms.Label lbRebaja2;
        private System.Windows.Forms.Button btRebaja2;
        private System.Windows.Forms.Label lbPrecalificacion2;
        private System.Windows.Forms.Button btPreCalificacion2;
        private System.Windows.Forms.ToolStripMenuItem simuladorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calificarToolStripMenuItem;
        private System.Windows.Forms.PictureBox pbRegNew;
        private System.Windows.Forms.Label lbRB3;
        private System.Windows.Forms.Button btRB3;
    }
}