﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using MmsWin.Front.Utilerias;
using System.Globalization;
using MmsWin.Front.Convenio;


namespace MmsWin.Front.ConvenioMelody
{
    public partial class ValidacionDiferenciado : Form
    {
        #region Variables
        // variables de la Ventana
        public static string parTemporada        { get; set; }
        public static string parTipoCalificacion { get; set; }
        public static string parFchCalificacion  { get; set; }
        public static string parFchInicial       { get; set; }

        public static string parFchDesde      { get; set; }
        public static string parFchHasta      { get; set; }

        public static string parProveedor     { get; set; }
        public static string parNombre        { get; set; }
        public static string parEstilo        { get; set; }
        public static string parDescripcion   { get; set; }

        public static string InventarioEstilo { get; set; }
        #endregion

        #region Grid
        // variables de la Ventana
        public static string gridMarca         { get; set; }
        public static string gridTienda        { get; set; }
        public static string gridFechaCalifica { get; set; }
        public static string gridTipoCalifica  { get; set; }
        public static string gridTemporada { get; set; }
        public static string gridTabla     { get; set; }
        public static string gridProveedor { get; set; }
        public static string gridEstilo    { get; set; }
        public static string gridOrden     { get; set; }
        #endregion

        int nr;
        bool ind;
        string FechaCal;
        string FechaFmt;
        bool Carga;
        String ParUser;
        string marca;
        string comprador;
        String FchDe;
        String FchHas;
        long FchDeN;
        long FchHasN;

        int dgvOffset;
        int dgvOffset2;

        public ValidacionDiferenciado()
        {
            InitializeComponent();

            dgvOffset  = this.Width  - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }

        private void ValidacionDiferenciado_Load(object sender, EventArgs e)
        {
            try
            {
                #region Variables
                // variables de la Ventana
                MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.parTemporada        = string.Empty;
                MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.parTipoCalificacion = string.Empty;
                MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.parFchCalificacion  = string.Empty;
                MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.parFchInicial  = string.Empty;
                MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.parProveedor   = string.Empty;
                MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.parNombre      = string.Empty;
                MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.parEstilo      = string.Empty;
                MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.parDescripcion = string.Empty;
                #endregion

                Carga = false;
                marca = "999";
                comprador = "999";

                ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;

                FchDe = "10/10/2000";
                FchHas = "10/10/2000";


                try
                {
                    System.Data.DataTable tbFechaInicial = null;
                    tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();

                    foreach (DataRow row in tbFechaInicial.Rows)
                    {
                        //tbDesde.Text = row["DSPFCH"].ToString();
                        //FechaCal = tbDesde.Text;
                        //FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                        //tbDesde.Text = FechaFmt.ToString();
                        //tbHasta.Text = FechaFmt.ToString();

                        //FechaCal = tbDesde.Text;
                        //FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                        //FchDeN = long.Parse(FechaFmt.ToString());
                        //FchDe = FechaFmt.ToString();

                        //FechaCal = tbHasta.Text;
                        //FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                        //FchHasN = long.Parse(FechaFmt.ToString());
                        //FchHas = FechaFmt.ToString();
                    }

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                // Carga de Marca
                try
                {
                    BindMarca();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                // Carga de Compradores
                try
                {
                    BindCompradores();
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                // Carga de Datos
                try
                {
                    Carga = true;
                    BinData();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            catch { }
        }

        private void BinData()
        {
            if (Carga == true)
            {

                nr = 0;
                System.Data.DataTable dtValidacion = null;
                try
                {
                    this.Cursor = Cursors.WaitCursor;

                    string tipo      = string.Empty;
                    string temporada = string.Empty;
                    string tabla     = string.Empty;

                    marca               = MmsWin.Front.Utilerias.VarTem.parmarca;               
                    comprador           = MmsWin.Front.Utilerias.VarTem.parcomprador;
                    FchDe               = MmsWin.Front.Utilerias.VarTem.parFchDe;
                    FchHas              = MmsWin.Front.Utilerias.VarTem.parFchHas; 
                    tipo                = MmsWin.Front.Utilerias.VarTem.partipo;
                    temporada           = MmsWin.Front.Utilerias.VarTem.partemporada;
                    parTipoCalificacion = MmsWin.Front.Utilerias.VarTem.parTipoCalificacion;
                    parFchCalificacion  = MmsWin.Front.Utilerias.VarTem.parFchCalificacion;
                    parProveedor        = MmsWin.Front.Utilerias.VarTem.parProveedor;
                    parNombre           = MmsWin.Front.Utilerias.VarTem.parNombre;
                    parEstilo           = MmsWin.Front.Utilerias.VarTem.parEstilo;
                    parDescripcion      = MmsWin.Front.Utilerias.VarTem.parDescripcion;

                    dtValidacion = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenValidacion(ParUser);
                    dgvGridView.DataSource = null;
                    if (dtValidacion.Rows.Count > 0)
                    {
                        SetDoubleBuffered(dgvGridView);
                        dgvGridView.DataSource = null;
                        dgvGridView.DataSource = dtValidacion;
                        nr = dgvGridView.RowCount;
                        this.Text = "Validación por Tienda/ " + " " + (nr-1).ToString() + " Registro(s)" +  " / Proveedor: " + parProveedor + " Estilo: " + parEstilo + " " + parDescripcion;
                        dgvGridView.DataSource = dtValidacion;
                        SetFontAndColors();
                        rowStyle();
                        dgvGridView.Focus();
                        dgvGridView.Select();
                    }

                    this.Cursor = Cursors.Default;
                }

                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        private void SetFontAndColors()
        {
            int i = 0;
            try
            {
                this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                this.dgvGridView.EnableHeadersVisualStyles = false;
                this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
                this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
                this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
                this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
                this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
                //this.dgvGridView.Columns["MDYSTY"].Frozen = true;
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                dgvGridView.Columns["RXTSTR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["RXTSTD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgvGridView.Columns["RXTPRV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgvGridView.Columns["RXTSTY"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgvGridView.Columns["RXTFEF"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgvGridView.Columns["RXTCSO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["RXTCSA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["RXTORI"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["RXTACT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["RXTPRE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["RXTMRG"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["RXTONH"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["RXTPOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgvGridView.Columns["RXTPRO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["RXTPCD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["RXTINS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["RXTAPL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["RXTSEL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["RXTXSE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                dgvGridView.Columns["RXTSTR"].Width = 45;
                dgvGridView.Columns["RXTSTD"].Width = 100;
                dgvGridView.Columns["RXTPRV"].Width = 50;
                dgvGridView.Columns["RXTSTY"].Width = 90;
                dgvGridView.Columns["RXTFEF"].Width = 80;
                dgvGridView.Columns["RXTCSO"].Width = 60;
                dgvGridView.Columns["RXTCSA"].Width = 60;
                dgvGridView.Columns["RXTORI"].Width = 60;
                dgvGridView.Columns["RXTACT"].Width = 60;
                dgvGridView.Columns["RXTPRE"].Width = 60;
                dgvGridView.Columns["RXTMRG"].Width = 50;
                dgvGridView.Columns["RXTONH"].Width = 50;
                dgvGridView.Columns["RXTPOR"].Width = 50;
                dgvGridView.Columns["RXTPRO"].Width = 90;
                dgvGridView.Columns["RXTPCD"].Width = 90;
                dgvGridView.Columns["RXTINS"].Width = 50;
                dgvGridView.Columns["RXTAPL"].Width = 50;
                dgvGridView.Columns["RXTSEL"].Width = 50;
                dgvGridView.Columns["RXTXSE"].Width = 50;

                dgvGridView.Columns["RXTSTR"].HeaderText = "Tienda";
                dgvGridView.Columns["RXTSTD"].HeaderText = "Nombre";
                dgvGridView.Columns["RXTPRV"].HeaderText = "Proveedor";
                dgvGridView.Columns["RXTSTY"].HeaderText = "Estilo";
                dgvGridView.Columns["RXTFEF"].HeaderText = "Fecha Efectiva";
                dgvGridView.Columns["RXTCSO"].HeaderText = "Costo Original";
                dgvGridView.Columns["RXTCSA"].HeaderText = "Costo Actual";
                dgvGridView.Columns["RXTORI"].HeaderText = "Precio Original";
                dgvGridView.Columns["RXTACT"].HeaderText = "Precio Actual";
                dgvGridView.Columns["RXTPRE"].HeaderText = "Precio Tienda";
                dgvGridView.Columns["RXTMRG"].HeaderText = "Margen";
                dgvGridView.Columns["RXTONH"].HeaderText = "On Hand";
                dgvGridView.Columns["RXTPOR"].HeaderText = "% X Aplicar";
                dgvGridView.Columns["RXTPRO"].HeaderText = "Importe Original";
                dgvGridView.Columns["RXTPCD"].HeaderText = "Importe Descuento";
                dgvGridView.Columns["RXTINS"].HeaderText = "INSBAL";
                dgvGridView.Columns["RXTAPL"].HeaderText = "Aplicado";
                dgvGridView.Columns["RXTSEL"].HeaderText = "Seleccionado";
                dgvGridView.Columns["RXTXSE"].HeaderText = "x Seleccionar";
          
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                dgvGridView.Columns["RXTFEF"].DefaultCellStyle.Format = "20##-##-##";
                dgvGridView.Columns["RXTCSO"].DefaultCellStyle.Format = "#,###.00";
                dgvGridView.Columns["RXTCSA"].DefaultCellStyle.Format = "#,###.00";
                dgvGridView.Columns["RXTORI"].DefaultCellStyle.Format = "#,###.00";
                dgvGridView.Columns["RXTACT"].DefaultCellStyle.Format = "#,###.00";
                dgvGridView.Columns["RXTPRE"].DefaultCellStyle.Format = "#,###.00";
                dgvGridView.Columns["RXTMRG"].DefaultCellStyle.Format = "#,###.00";
                dgvGridView.Columns["RXTONH"].DefaultCellStyle.Format = "#,###";
                dgvGridView.Columns["RXTPOR"].DefaultCellStyle.Format = "#,###.00";

                dgvGridView.Columns["RXTPRO"].DefaultCellStyle.Format = "#,###,###.00";
                dgvGridView.Columns["RXTPCD"].DefaultCellStyle.Format = "#,###,###.00";

                // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                dgvGridView.Columns["RXTSTR"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvGridView.Columns["RXTSTD"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvGridView.Columns["RXTPRV"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RXTSTY"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RXTFEF"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvGridView.Columns["RXTCSO"].HeaderCell.Style.BackColor = Color.LightGreen;
                dgvGridView.Columns["RXTCSA"].HeaderCell.Style.BackColor = Color.LightGreen;
                dgvGridView.Columns["RXTORI"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RXTACT"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RXTPRE"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
                dgvGridView.Columns["RXTMRG"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RXTONH"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RXTPOR"].HeaderCell.Style.BackColor = Color.LightGreen;

                dgvGridView.Columns["RXTPRO"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RXTPCD"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RXTINS"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvGridView.Columns["RXTAPL"].HeaderCell.Style.BackColor = Color.LightSalmon;

                dgvGridView.Columns["RXTSEL"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvGridView.Columns["RXTXSE"].HeaderCell.Style.BackColor = Color.LightSalmon;

                dgvGridView.Columns["RXTPRV"].Visible = false;
                dgvGridView.Columns["RXTSTY"].Visible = false;

                dgvGridView.Columns["RXTCSO"].Visible = false;
                dgvGridView.Columns["RXTCSA"].Visible = false;
                dgvGridView.Columns["RXTORI"].Visible = false;
                dgvGridView.Columns["RXTACT"].Visible = false;

                dgvGridView.Columns["RXTINS"].Visible = false;
                dgvGridView.Columns["RXTAPL"].Visible = false;
                dgvGridView.Columns["RXTSEL"].Visible = false;
                dgvGridView.Columns["RXTXSE"].Visible = false;
            }
            catch { }
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;

            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                lbCSTORIDAT.Text = this.dgvGridView.CurrentRow.Cells["RXTCSO"].Value.ToString();
                lbCSTACTDAT.Text = this.dgvGridView.CurrentRow.Cells["RXTCSA"].Value.ToString();
                lbPRCORIDAT.Text = this.dgvGridView.CurrentRow.Cells["RXTORI"].Value.ToString();
                lbPRCACTDAT.Text = this.dgvGridView.CurrentRow.Cells["RXTACT"].Value.ToString();

                dgvGridView.Select();

                Regs += 1;
                if (vez == "Si")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
                double margen = Convert.ToDouble(rowp.Cells["RXTMRG"].Value);
                if (margen < 0) { rowp.Cells["RXTMRG"].Style.ForeColor = Color.Red; }

                double porcentajeSel = Convert.ToDouble(rowp.Cells["RXTPOR"].Value);
                if (porcentajeSel > 00.00) { rowp.Cells["RXTPOR"].Style.ForeColor = Color.Blue; }
            }
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        protected void BindMarca()
        {
            //try
            //{
            //    cbMarca.DataSource = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();
            //    cbMarca.DisplayMember = "Value";
            //    cbMarca.ValueMember = "Key";
            //    marca = "30";
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
        }

        protected void BindCompradores()
        {
            //try
            //{
            //    cbComprador.DataSource = MmsWin.Negocio.Catalogos.Compradores.GetInstance().ObtenCompradors().ToList();
            //    cbComprador.DisplayMember = "Value";
            //    cbComprador.ValueMember = "Key";
            //    comprador = "999";
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
        } 

        private void ValidacionDiferenciado_Resize(object sender, EventArgs e)
        {
            dgvGridView.Width = this.Width - dgvOffset;
            dgvGridView.Height = this.Height - dgvOffset2;
        }

        private void dgvGridView_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                BinData();
                dgvGridView.Focus();
                dgvGridView.Select();
            }
        }

        private void dgvGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cargaVariables();
        }

        private void dgvGridView_SelectionChanged(object sender, EventArgs e)
        {
            cargaVariables();
        }

        private void cargaVariables() 
        {
            try
            {
                //MmsWin.Front.Utilerias.Fotos.numPrv  = this.dgvGridView.CurrentRow.Cells["MDYPRV"].Value.ToString();
                //MmsWin.Front.Utilerias.Fotos.numSty  = this.dgvGridView.CurrentRow.Cells["MDYSTY"].Value.ToString();
                //MmsWin.Front.Utilerias.VarTem.tmpPrv = this.dgvGridView.CurrentRow.Cells["MDYPRV"].Value.ToString();
                //MmsWin.Front.Utilerias.VarTem.tmpSty = this.dgvGridView.CurrentRow.Cells["MDYSTY"].Value.ToString();

                //MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridMarca         = this.dgvGridView.CurrentRow.Cells["MDYMAR"].Value.ToString();
                //MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridTienda        = this.dgvGridView.CurrentRow.Cells["MDYTDA"].Value.ToString();
                //MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridFechaCalifica = this.dgvGridView.CurrentRow.Cells["MDYFCH"].Value.ToString();
                //MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridTipoCalifica  = this.dgvGridView.CurrentRow.Cells["MDYTPO"].Value.ToString();
                //MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridTemporada     = this.dgvGridView.CurrentRow.Cells["MDYTMP"].Value.ToString();
                //MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridTabla         = this.dgvGridView.CurrentRow.Cells["MDYTAB"].Value.ToString();
                //MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridProveedor     = this.dgvGridView.CurrentRow.Cells["MDYPRV"].Value.ToString();
                //MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridEstilo        = this.dgvGridView.CurrentRow.Cells["MDYSTY"].Value.ToString();
                //MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridOrden         = this.dgvGridView.CurrentRow.Cells["MDYORD"].Value.ToString();
            }
            catch { };

             string fmtFch = string.Empty;
             string fmtHor = string.Empty;

            try
            {
                //fmtFch = this.dgvGridView.CurrentRow.Cells[5].Value.ToString();
                //MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.corrFecha = "20" + fmtFch.Substring(0, 2) + "-" + fmtFch.Substring(2, 2) + "-" + fmtFch.Substring(4, 2);

                //fmtHor = this.dgvGridView.CurrentRow.Cells[6].Value.ToString();
                //MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.corrHora = fmtHor.Substring(0, 2) + ":" + fmtHor.Substring(2, 2) + ":" + fmtHor.Substring(4, 2);
            }

            catch { };

            //try
            //{
            //    string validaContraloria = this.dgvGridView.CurrentRow.Cells["MDYCBT"].Value.ToString();
            //    if (validaContraloria == "1")
            //    {
            //        this.dgvGridView.CurrentRow.Cells["CHKCOMP"].ReadOnly = true;
            //        this.dgvGridView.CurrentRow.Cells["MDYOBC"].ReadOnly  = true;
            //        this.dgvGridView.CurrentRow.Cells["MDYOBT"].ReadOnly  = true;
            //    }
            //    else
            //    {
            //        this.dgvGridView.CurrentRow.Cells["CHKCOMP"].ReadOnly = false;
            //        this.dgvGridView.CurrentRow.Cells["MDYOBC"].ReadOnly  = false;
            //        this.dgvGridView.CurrentRow.Cells["MDYOBT"].ReadOnly  = false;
            //    }
            //}
            //catch { };
        }

        private void dgvGridView_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                SendKeys.Send("{UP}");
                SendKeys.Flush();
            }
        }

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            marca = " ";
            ComboBox cmbMarca = (ComboBox)sender;
            marca = cmbMarca.SelectedValue.ToString();
            BinData();
        }

        private void tbDesde_Click(object sender, EventArgs e)
        {
            //mcC1.Visible = true;
            //mcC1.Focus();
        }

        private void tbHasta_Click(object sender, EventArgs e)
        {
            //mcC2.Visible = true;
            //mcC2.Focus();
        }

        private void mcC1_DateSelected(object sender, DateRangeEventArgs e)
        {
            //tbDesde.Text = mcC1.SelectionEnd.ToShortDateString();
            //FechaCal = tbDesde.Text;
            //FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            //FchDeN = long.Parse(FechaFmt.ToString());
            //FchDe = FechaFmt.ToString();

            //mcC1.Visible = false;
            //if (FchDeN > 0 && FchHasN > 0)
            //{
            //    if (FchDeN > FchHasN)
            //    {
            //        tbDesde.Text = " "; FechaCal = " "; FechaFmt = " ";
            //        MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
            //    }
            //    else
            //    {
            //        BinData();
            //    }
            //}
        }

        private void mcC2_DateSelected(object sender, DateRangeEventArgs e)
        {
            //tbHasta.Text = mcC2.SelectionEnd.ToShortDateString();
            //FechaCal = tbHasta.Text;
            //FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            //FchHasN = long.Parse(FechaFmt.ToString());
            //FchHas = FechaFmt.ToString();

            //mcC2.Visible = false;
            //if (FchDeN > 0 && FchHasN > 0)
            //{
            //    if (FchDeN > FchHasN)
            //    {
            //        tbHasta.Text = " "; FechaCal = " "; FechaFmt = " ";
            //        MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
            //    }
            //    else
            //    {
            //        BinData();
            //    }
            //}
        }

        private void tbTipoCalificacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbTipoCalificacion.Focus();
            }
        }

        private void tbFchCalificacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbFchCalificacion.Focus();
            }
        }

        private void tbProveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbProveedor.Focus();
            }
        }

        private void tbNombre_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbNombre.Focus();
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbEstilo.Focus();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbDescripcion.Focus();
            }
        }

        private void dgvGridView_Sorted(object sender, EventArgs e)
        {
            rowStyle();
        }

        private void cbComprador_SelectedValueChanged(object sender, EventArgs e)
        {
            comprador = " ";
            nr = 0;
            ComboBox cmbComprador = (ComboBox)sender;
            comprador = cmbComprador.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpComprador = cmbComprador.SelectedValue.ToString();

            BinData();
        }

        private void mcC1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                //mcC1.Visible = false;
            }
        }

        private void mcC2_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                //mcC2.Visible = false;
            }
        }

        private void fotoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MuestraFoto();
        }

        private void MuestraFoto()
        {
            try
            {
                Fotos i = new Fotos();
                i.Show();
            }
            catch { }
            finally { }
        }

        private void dgvGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvGridView.Select();
            dgvGridView.Focus();
            Kardex();
        }

        private void Kardex()
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Kardex").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del Kardex ya esta abierta");
                    }
                    else
                    {
                        Kardex i = new Kardex();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void tbTabla_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbTipoCalificacion.Focus();
            }
        }

        private void tbTemporada_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbTipoCalificacion.Focus();
            }
        }

        private void dgvGridView_CellParsing(object sender, DataGridViewCellParsingEventArgs e)
        {
            int Row = e.RowIndex;
            int Col = e.ColumnIndex;
            string campo         = string.Empty;
            string checkBox      = string.Empty;
            string observaciones = string.Empty;
            string usuario       = string.Empty;
            string fechaUser     = string.Empty;
            string horaUser      = string.Empty;

            string marca     = MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridMarca         ;
            string tienda    = MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridTienda        ;
            string fecha     = MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridFechaCalifica ;
            string tipo      = MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridTipoCalifica  ;
            string temporada = MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridTemporada     ;
            string tabla     = MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridTabla         ;
            string proveedor = MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridProveedor     ;
            string estilo    = MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridEstilo        ;
            string orden     = MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridOrden         ;

            DateTime hoy = DateTime.Now;

            fechaUser = hoy.Date.ToString("yyMMdd");
            horaUser = DateTime.Now.ToString("HHmmss");
            usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;

            campo = this.dgvGridView.Rows[Row].Cells[Col].OwningColumn.Name;
            if (campo == "CHKCOMP" || campo == "MDYOBC")
            {
                if (campo == "MDYOBC")
                {
                    observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBC"].Value.ToString();
                    observaciones = Convert.ToString(e.Value);
                }
                if (campo == "CHKCOMP")
                {
                    string chk = Convert.ToString(e.Value);
                    if (chk == "False")
                    {
                        checkBox = "0";
                        this.dgvGridView.CurrentRow.Cells["MDYCBC"].Value = "0";
                        observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBC"].Value.ToString();
                    }
                    if (chk == "True")
                    {
                        checkBox = "1";
                        this.dgvGridView.CurrentRow.Cells["MDYCBC"].Value = "1";
                        observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBC"].Value.ToString();
                    }
                }
                else
                {
                    checkBox = this.dgvGridView.CurrentRow.Cells["MDYCBC"].Value.ToString();
                }
                MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateCheckBoxComprasTda(marca, fecha, tipo, temporada, tabla, tienda, proveedor, estilo,
                                                                                        orden, checkBox, observaciones, usuario, fechaUser, horaUser);
            }
            if (campo == "CHKCONTR" || campo == "MDYOBT")
            {
                if (campo == "MDYOBT")
                {
                    observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBT"].Value.ToString();
                    observaciones = Convert.ToString(e.Value);
                }
                if (campo == "CHKCONTR")
                {
                    string chk = Convert.ToString(e.Value);
                    if (chk == "False")
                    {
                        checkBox = "0";
                        this.dgvGridView.CurrentRow.Cells["MDYCBT"].Value = "0";
                        observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBT"].Value.ToString();
                    }
                    if (chk == "True")
                    {
                        checkBox = "1";
                        this.dgvGridView.CurrentRow.Cells["MDYCBT"].Value = "1";
                        observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBT"].Value.ToString();
                    }
                }
                else
                {
                    checkBox = this.dgvGridView.CurrentRow.Cells["MDYCBT"].Value.ToString();
                }
                MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateCheckBoxContraloriaTda(marca, fecha, tipo, temporada, tabla, tienda, proveedor, estilo,
                                                                                        orden, checkBox, observaciones, usuario, fechaUser, horaUser);
            }
        }

        private void rebajaDiferenciadaTlSMI_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "NotaDiferenciada").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La Ventana ya esta abierta...");
                    }
                    else
                    {
                        string FechaBon = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
                        if (FechaBon != null)
                        {
                            string calificaion = MmsWin.Front.ConvenioMelody.CalificacionGrid.gridCalificacion;
                            string convMarcaNo = MmsWin.Front.ConvenioMelody.CalificacionGrid.gridMarca;

                            string FechaBinificacion = FechaBon.Substring(8, 2) + FechaBon.Substring(3, 2) + FechaBon.Substring(0, 2);
                            string FechaAbierta = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenMarcaConfiguracion1(convMarcaNo);
                            if (FechaBinificacion == FechaAbierta)
                            {
                                MessageBox.Show("La nota de crédito se va a concentrar en la fecha :" + FechaBon);
                                RecuperaMovimientosDiferenciados();
                                NotaDiferenciada i = new NotaDiferenciada();
                                i.Show();
                            }
                            else
                            {
                                MessageBox.Show("La fecha " + FechaBon + " No esta abierta para captura de Notas de Credito");
                            }
                        }
                        else
                        {
                            MessageBox.Show("La ventana de Calificacion no esta abierta...");
                        }
                    }
                }
            }
            catch { }
            finally { }
        }

        private void RecuperaMovimientosDiferenciados()
        {
            System.Data.DataTable dtDiferenciados = new System.Data.DataTable("Diferenciados");
            dtDiferenciados.Columns.Add("ParTipo", typeof(String));
            dtDiferenciados.Columns.Add("ParTemporada", typeof(String));
            dtDiferenciados.Columns.Add("ParTienda", typeof(String));
            dtDiferenciados.Columns.Add("ParInventario", typeof(String));
            dtDiferenciados.Columns.Add("ParProveedor", typeof(String));
            dtDiferenciados.Columns.Add("ParEstilo", typeof(String));

            DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                DataRow workRow = dtDiferenciados.NewRow();
                workRow["ParTipo"]       = item.Cells["MDYTPO"].Value.ToString();
                workRow["ParTemporada"]  = item.Cells["MDYTMP"].Value.ToString();
                workRow["ParTienda"]     = item.Cells["MDYTDA"].Value.ToString();
                workRow["ParInventario"] = item.Cells["INVENTARIO"].Value.ToString();
                workRow["ParProveedor"]  = item.Cells["MDYPRV"].Value.ToString();
                workRow["ParEstilo"]     = item.Cells["MDYSTY"].Value.ToString();

                dtDiferenciados.Rows.Add(workRow);
            }

            int regs = dtDiferenciados.Rows.Count;
            if (regs == 0)
            {
                DataRow workRow = dtDiferenciados.NewRow();
                workRow["ParTipo"]       = MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridTipoCalifica;
                workRow["ParTemporada"]  = MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridTemporada;
                workRow["ParTienda"]     = MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridTienda;
                workRow["ParInventario"] = MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridTienda;
                workRow["ParProveedor"]  = MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridTienda;
                workRow["ParEstilo"]     = MmsWin.Front.ConvenioMelody.ValidacionDiferenciado.gridTienda;

                dtDiferenciados.Rows.Add(workRow);
            }


            MmsWin.Front.ConvenioMelody.NotaDiferenciada.dtDiferenciados = dtDiferenciados;
        }

        private void btExcel_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            System.Data.DataTable dtDowns = (System.Data.DataTable)(dgvGridView.DataSource);
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            int nc = dgvGridView.Columns.Count;

            for (int ii = 1; ii <= nc; ii++)
            {

                xlWorkSheet.Cells[1, ii] = dgvGridView.Columns[ii - 1].HeaderText;

            }

            System.Data.DataTable dtConvenio = (System.Data.DataTable)(dgvGridView.DataSource);
            int nr = dgvGridView.RowCount;
            this.pgbProg.Visible = true;

            pgbProg.Maximum = nr;
            pgbProg.Value = 0;
            int r = 0;
            int rt = 3;
            foreach (DataRow row in dtConvenio.Rows)
            {
                var gsArray = new[] 
                {         
                    row["RXTSTR"],  // 01
                    row["RXTSTD"],  // 02 
                    row["RXTPRV"],  // 03 
                    row["RXTSTY"],  // 04
                    row["RXTFEF"],  // 05
                    row["RXTCSO"],  // 06
                    row["RXTCSA"],  // 07
                    row["RXTORI"],  // 08
                    row["RXTACT"],  // 09
                    row["RXTPRE"],  // 10
                    row["RXTMRG"],  // 11
                    row["RXTONH"],  // 12
                    row["RXTPOR"],  // 13
                    row["RXTPRO"],  // 14
                    row["RXTPCD"],  // 15
                    row["RXTINS"],  // 16
                    row["RXTAPL"],  // 17
                    row["RXTSEL"],  // 18
                    row["RXTXSE"]   // 19
                };

                Range rng = xlWorkSheet.get_Range("A" + rt, "S" + rt);
                rng.Value = gsArray;

                pgbProg.Value += 1;

                this.Text = "Registros de validación / " + " " + (r += 1).ToString() + " Registro(s)";

                rt++;
            }
            xlWorkSheet.Columns[1].ColumnWidth = 5;
            xlWorkSheet.Columns[2].ColumnWidth = 25;
            xlWorkSheet.Columns[3].ColumnWidth = 10;
            xlWorkSheet.Columns[4].ColumnWidth = 10;
            xlWorkSheet.Columns[5].ColumnWidth = 5;
            xlWorkSheet.Columns[6].ColumnWidth = 5;
            xlWorkSheet.Columns[7].ColumnWidth = 5;
            xlWorkSheet.Columns[8].ColumnWidth = 5;
            xlWorkSheet.Columns[9].ColumnWidth = 5;
            xlWorkSheet.Columns[10].ColumnWidth = 5;
            xlWorkSheet.Columns[11].ColumnWidth = 5;
            xlWorkSheet.Columns[12].ColumnWidth = 10;
            xlWorkSheet.Columns[13].ColumnWidth = 10;
            xlWorkSheet.Columns[14].ColumnWidth = 5;
            xlWorkSheet.Columns[15].ColumnWidth = 5;
            xlWorkSheet.Columns[16].ColumnWidth = 5;
            xlWorkSheet.Columns[17].ColumnWidth = 5;
            xlWorkSheet.Columns[18].ColumnWidth = 5;

            var Rang0 = xlWorkSheet.get_Range("A1", "B1");
            Rang0.Interior.Color = Color.LightSalmon;
            Rang0.Font.Color = Color.White;
            Rang0.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang1 = xlWorkSheet.get_Range("C1", "D1");
            Rang1.Interior.Color = Color.LightSlateGray;
            Rang1.Font.Color = Color.White;
            Rang1.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang2 = xlWorkSheet.get_Range("E1", "E1");
            Rang2.Interior.Color = Color.LightGreen;
            Rang2.Font.Color = Color.White;
            Rang2.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang3 = xlWorkSheet.get_Range("F1", "G1");
            Rang3.Interior.Color = Color.LightSkyBlue;
            Rang3.Font.Color = Color.White;
            Rang3.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang04 = xlWorkSheet.get_Range("H1", "I1");
            Rang04.WrapText = true;
            Rang04.Font.Bold = true;
            Rang04.Interior.Color = Color.LightSlateGray;
            Rang04.Font.Color = Color.White;
            Rang04.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang04.Font.Underline = true;
            Rang04.HorizontalAlignment = HorizontalAlignment.Center;

            var Rang7 = xlWorkSheet.get_Range("J1", "K1");
            Rang7.Interior.Color = Color.LightSeaGreen;
            Rang7.Font.Color = Color.White;
            Rang7.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang05 = xlWorkSheet.get_Range("L1", "L1");
            Rang05.WrapText = true;
            Rang05.Font.Bold = true;
            Rang05.Interior.Color = Color.LightSkyBlue;
            Rang05.Font.Color = Color.White;
            Rang05.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang05.Font.Underline = true;
            Rang05.HorizontalAlignment = HorizontalAlignment.Center;

            var Rang06 = xlWorkSheet.get_Range("M1", "M1");
            Rang06.WrapText = true;
            Rang06.Font.Bold = true;
            Rang06.Interior.Color = Color.LightGreen;
            Rang06.Font.Color = Color.White;
            Rang06.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang06.Font.Underline = true;
            Rang06.HorizontalAlignment = HorizontalAlignment.Center;

            //var Rang07 = xlWorkSheet.get_Range("N1", "O1");
            //Rang07.WrapText = true;
            //Rang07.Font.Bold = true;
            //Rang07.Interior.Color = Color.LightGreen;
            //Rang07.Font.Color = Color.White;
            //Rang07.Borders.LineStyle = BorderStyle.FixedSingle;
            //Rang07.Font.Underline = true;
            //Rang07.HorizontalAlignment = HorizontalAlignment.Center;

            var Rang08 = xlWorkSheet.get_Range("N1", "O1");
            Rang08.WrapText = true;
            Rang08.Font.Bold = true;
            Rang08.Interior.Color = Color.LightSlateGray;
            Rang08.Font.Color = Color.White;
            Rang08.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang08.Font.Underline = true;
            Rang08.HorizontalAlignment = HorizontalAlignment.Center;

            var Rang09 = xlWorkSheet.get_Range("P1", "S1");
            Rang09.WrapText = true;
            Rang09.Font.Bold = true;
            Rang09.Interior.Color = Color.LightSalmon;
            Rang09.Font.Color = Color.White;
            Rang09.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang09.Font.Underline = true;
            Rang09.HorizontalAlignment = HorizontalAlignment.Center;

            String Rango = "A2" + ":" + "S" + rt;
            Excel.Range SourceRange = (Excel.Range)xlWorkSheet.get_Range("A2", "S" + rt);
            FormatAsTable(SourceRange, "Table1", "TableStyleMedium2");

            xlWorkSheet.Rows[2].Hidden = true;

            xlWorkSheet.Columns["F:O"].HorizontalAlignment   = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["P:S"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;

            xlWorkSheet.Columns["E"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["F:K"].NumberFormat = "###,###.00";
            xlWorkSheet.Columns["L"].NumberFormat = "###,###";
            xlWorkSheet.Columns["M:O"].NumberFormat = "###,###.00";

            var range = xlWorkSheet.get_Range("A3", "A3");
            range.Select();

            //xlApp.Range["A:A"].EntireColumn.Delete();
            //xlApp.Range["C:W"].EntireColumn.Delete();
            //xlApp.Range["F:K"].EntireColumn.Delete();
            //xlApp.Range["I:BH"].EntireColumn.Delete();
            //xlApp.Range["J:L"].EntireColumn.Delete();

            string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
            xlApp.ActiveWindow.Zoom = 80;
            xlWorkBook.SaveAs("C:\\Reportes\\Validacion" + Hoy + ".xlsx", Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            string comando = @"C:\\Reportes\\Validacion" + Hoy + ".xlsx";
            ExecuteCommand(comando);

            this.pgbProg.Visible = false;
            this.Cursor = Cursors.Default;
        }

        public void FormatAsTable(Excel.Range SourceRange, string TableName, string TableStyleName)
        {
            SourceRange.Worksheet.ListObjects.Add(XlListObjectSourceType.xlSrcRange,
            SourceRange, System.Type.Missing, XlYesNoGuess.xlYes, System.Type.Missing).Name =
                TableName;
            SourceRange.Select();
            SourceRange.Worksheet.ListObjects[TableName].TableStyle = TableStyleName;
            SourceRange.Worksheet.ListObjects[TableName].ShowAutoFilter = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowHeaders = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowTotals = false;
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        static void ExecuteCommand(string _Command)
        {
            //Indicamos que deseamos inicializar el proceso cmd.exe junto a un comando de arranque. 
            //(/C, le indicamos al proceso cmd que deseamos que cuando termine la tarea asignada se cierre el proceso).
            //Para mas informacion consulte la ayuda de la consola con cmd.exe /? 
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;
            //Inicializa el proceso
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            string result = proc.StandardOutput.ReadToEnd();
        }

        private void btMarcaChk_Click(object sender, EventArgs e)
        {

        }

        private void btQuitaChks_Click(object sender, EventArgs e)
        {

        }

        private void btPoneChks_Click(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
            foreach (DataGridViewRow rowp in Seleccionados)
            {
                if ((Convert.ToString((rowp.Cells[2].Value))) != "Total")
                {
                    dgvGridView.Select();
                    DataGridViewCheckBoxCell chk2 = (DataGridViewCheckBoxCell)rowp.Cells["CHKCOMP"];
                    dgvGridView.BeginEdit(true);
                    chk2.Value = 1;
                    dgvGridView.BeginEdit(false);

                    string checkBox  = "1";
                    string observaciones = string.Empty;
                    string usuario   = string.Empty;
                    string fechaUser = "0";
                    string horaUser  = "0";

                    string marca     = rowp.Cells["MDYMAR"].Value.ToString();
                    string tienda    = rowp.Cells["MDYTDA"].Value.ToString();
                    string fecha     = rowp.Cells["MDYFCH"].Value.ToString();
                    string tipo      = rowp.Cells["MDYTPO"].Value.ToString();
                    string temporada = rowp.Cells["MDYTMP"].Value.ToString();
                    string tabla     = rowp.Cells["MDYTAB"].Value.ToString();
                    string proveedor = rowp.Cells["MDYPRV"].Value.ToString();
                    string estilo    = rowp.Cells["MDYSTY"].Value.ToString();
                    string orden     = rowp.Cells["MDYORD"].Value.ToString();

                    MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateCheckBoxComprasTda(marca, fecha, tipo, temporada, tabla, tienda, proveedor, estilo,
                                                                                        orden, checkBox, observaciones, usuario, fechaUser, horaUser);
                    dgvGridView.Focus();
                    dgvGridView.Select();
                }

            }
        }

        private void btQuitaChk_Click(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
            foreach (DataGridViewRow rowp in Seleccionados)
            {

                if ((Convert.ToString((rowp.Cells[2].Value))) != "Total")
                {
                    DataGridViewCheckBoxCell chk2 = (DataGridViewCheckBoxCell)rowp.Cells["CHKCOMP"];
                    dgvGridView.BeginEdit(true);
                    chk2.Value = 0;
                    dgvGridView.BeginEdit(false);

                    string checkBox  = "0";
                    string observaciones = string.Empty;
                    string usuario   = string.Empty;
                    string fechaUser = "0";
                    string horaUser  = "0";

                    string marca     = rowp.Cells["MDYMAR"].Value.ToString();
                    string tienda    = rowp.Cells["MDYTDA"].Value.ToString();
                    string fecha     = rowp.Cells["MDYFCH"].Value.ToString();
                    string tipo      = rowp.Cells["MDYTPO"].Value.ToString();
                    string temporada = rowp.Cells["MDYTMP"].Value.ToString();
                    string tabla     = rowp.Cells["MDYTAB"].Value.ToString();
                    string proveedor = rowp.Cells["MDYPRV"].Value.ToString();
                    string estilo    = rowp.Cells["MDYSTY"].Value.ToString();
                    string orden     = rowp.Cells["MDYORD"].Value.ToString();

                    MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateCheckBoxComprasTda(marca, fecha, tipo, temporada, tabla, tienda, proveedor, estilo,
                                                                                        orden, checkBox, observaciones, usuario, fechaUser, horaUser);
                    dgvGridView.Focus();
                    dgvGridView.Select();
                }

            }
        }

    }
}
