﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class Administracion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pgbProg = new System.Windows.Forms.ProgressBar();
            this.dgvGridview = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.FotoTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.cosnsultaPDFTSM = new System.Windows.Forms.ToolStripMenuItem();
            this.cargaPDFTSM = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.EliminarTSM1 = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblDesde = new System.Windows.Forms.Label();
            this.lblHasta = new System.Windows.Forms.Label();
            this.tbCal01 = new System.Windows.Forms.TextBox();
            this.tbHasta = new System.Windows.Forms.TextBox();
            this.cbCompradores = new System.Windows.Forms.ComboBox();
            this.gbMarca = new System.Windows.Forms.GroupBox();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.gbComprador = new System.Windows.Forms.GroupBox();
            this.mcCal01 = new System.Windows.Forms.MonthCalendar();
            this.mcC1 = new System.Windows.Forms.MonthCalendar();
            this.tbTdaNombre = new System.Windows.Forms.TextBox();
            this.tbIdTda = new System.Windows.Forms.TextBox();
            this.tbTemporada = new System.Windows.Forms.TextBox();
            this.Relleno = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbProveedor = new System.Windows.Forms.TextBox();
            this.gbTipoConsulta = new System.Windows.Forms.GroupBox();
            this.cbTipoConsulta = new System.Windows.Forms.ComboBox();
            this.gbTemporada = new System.Windows.Forms.GroupBox();
            this.cbTemporada = new System.Windows.Forms.ComboBox();
            this.btExcel = new System.Windows.Forms.Button();
            this.rbNivelEstilo = new System.Windows.Forms.RadioButton();
            this.gbAdministracion = new System.Windows.Forms.GroupBox();
            this.cbAdministracion = new System.Windows.Forms.ComboBox();
            this.rbNivelTienda = new System.Windows.Forms.RadioButton();
            this.btResumen = new System.Windows.Forms.Button();
            this.Relleno02 = new System.Windows.Forms.TextBox();
            this.Relleno03 = new System.Windows.Forms.TextBox();
            this.tbTbporc = new System.Windows.Forms.TextBox();
            this.c_subClase = new System.Windows.Forms.TextBox();
            this.c_clase = new System.Windows.Forms.TextBox();
            this.c_subDepto = new System.Windows.Forms.TextBox();
            this.c_depto = new System.Windows.Forms.TextBox();
            this.Relleno04 = new System.Windows.Forms.TextBox();
            this.tbIdComp = new System.Windows.Forms.TextBox();
            this.tbDesComp = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridview)).BeginInit();
            this.cmMenu.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gbMarca.SuspendLayout();
            this.gbTipoConsulta.SuspendLayout();
            this.gbTemporada.SuspendLayout();
            this.gbAdministracion.SuspendLayout();
            this.SuspendLayout();
            // 
            // pgbProg
            // 
            this.pgbProg.Location = new System.Drawing.Point(4, 392);
            this.pgbProg.Name = "pgbProg";
            this.pgbProg.Size = new System.Drawing.Size(1223, 10);
            this.pgbProg.TabIndex = 11;
            this.pgbProg.Visible = false;
            // 
            // dgvGridview
            // 
            this.dgvGridview.AllowUserToAddRows = false;
            this.dgvGridview.AllowUserToDeleteRows = false;
            this.dgvGridview.AllowUserToOrderColumns = true;
            this.dgvGridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridview.ContextMenuStrip = this.cmMenu;
            this.dgvGridview.Location = new System.Drawing.Point(3, 92);
            this.dgvGridview.Name = "dgvGridview";
            this.dgvGridview.Size = new System.Drawing.Size(1224, 308);
            this.dgvGridview.TabIndex = 12;
            this.dgvGridview.CellMouseDown += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgvGridview_CellMouseDown);
            this.dgvGridview.Sorted += new System.EventHandler(this.dgvGridview_Sorted);
            this.dgvGridview.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvGridview_KeyUp);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FotoTSMI,
            this.cosnsultaPDFTSM,
            this.cargaPDFTSM,
            this.toolStripMenuItem2,
            this.EliminarTSM1});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(146, 114);
            // 
            // FotoTSMI
            // 
            this.FotoTSMI.Name = "FotoTSMI";
            this.FotoTSMI.Size = new System.Drawing.Size(145, 22);
            this.FotoTSMI.Text = "Foto";
            this.FotoTSMI.Click += new System.EventHandler(this.fotoToolStripMenuItem_Click);
            // 
            // cosnsultaPDFTSM
            // 
            this.cosnsultaPDFTSM.Name = "cosnsultaPDFTSM";
            this.cosnsultaPDFTSM.Size = new System.Drawing.Size(145, 22);
            this.cosnsultaPDFTSM.Text = "Consulta PDF";
            this.cosnsultaPDFTSM.Click += new System.EventHandler(this.cosnsultaPDFTSM_Click);
            // 
            // cargaPDFTSM
            // 
            this.cargaPDFTSM.Name = "cargaPDFTSM";
            this.cargaPDFTSM.Size = new System.Drawing.Size(145, 22);
            this.cargaPDFTSM.Text = "Carga PDF";
            this.cargaPDFTSM.Click += new System.EventHandler(this.cargaPDFTSM_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(145, 22);
            this.toolStripMenuItem2.Text = "____________";
            // 
            // EliminarTSM1
            // 
            this.EliminarTSM1.Name = "EliminarTSM1";
            this.EliminarTSM1.Size = new System.Drawing.Size(145, 22);
            this.EliminarTSM1.Text = "Eliminar";
            this.EliminarTSM1.Click += new System.EventHandler(this.EliminarTSM1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblDesde);
            this.groupBox1.Controls.Add(this.lblHasta);
            this.groupBox1.Controls.Add(this.tbCal01);
            this.groupBox1.Controls.Add(this.tbHasta);
            this.groupBox1.Location = new System.Drawing.Point(331, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(266, 40);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Rango";
            // 
            // lblDesde
            // 
            this.lblDesde.AutoSize = true;
            this.lblDesde.Location = new System.Drawing.Point(7, 17);
            this.lblDesde.Name = "lblDesde";
            this.lblDesde.Size = new System.Drawing.Size(38, 13);
            this.lblDesde.TabIndex = 44;
            this.lblDesde.Text = "Desde";
            // 
            // lblHasta
            // 
            this.lblHasta.AutoSize = true;
            this.lblHasta.Location = new System.Drawing.Point(135, 17);
            this.lblHasta.Name = "lblHasta";
            this.lblHasta.Size = new System.Drawing.Size(35, 13);
            this.lblHasta.TabIndex = 45;
            this.lblHasta.Text = "Hasta";
            // 
            // tbCal01
            // 
            this.tbCal01.Location = new System.Drawing.Point(54, 15);
            this.tbCal01.Name = "tbCal01";
            this.tbCal01.ReadOnly = true;
            this.tbCal01.Size = new System.Drawing.Size(69, 20);
            this.tbCal01.TabIndex = 18;
            this.tbCal01.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbCal01.Click += new System.EventHandler(this.tbCal01_Click);
            // 
            // tbHasta
            // 
            this.tbHasta.Location = new System.Drawing.Point(172, 15);
            this.tbHasta.Name = "tbHasta";
            this.tbHasta.ReadOnly = true;
            this.tbHasta.Size = new System.Drawing.Size(71, 20);
            this.tbHasta.TabIndex = 44;
            this.tbHasta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbHasta.Click += new System.EventHandler(this.tbHasta_Click);
            // 
            // cbCompradores
            // 
            this.cbCompradores.FormattingEnabled = true;
            this.cbCompradores.Location = new System.Drawing.Point(146, 15);
            this.cbCompradores.Name = "cbCompradores";
            this.cbCompradores.Size = new System.Drawing.Size(168, 21);
            this.cbCompradores.TabIndex = 14;
            this.cbCompradores.SelectedValueChanged += new System.EventHandler(this.cbCompradores_SelectedValueChanged);
            // 
            // gbMarca
            // 
            this.gbMarca.Controls.Add(this.cbMarca);
            this.gbMarca.Location = new System.Drawing.Point(5, 2);
            this.gbMarca.Name = "gbMarca";
            this.gbMarca.Size = new System.Drawing.Size(113, 40);
            this.gbMarca.TabIndex = 13;
            this.gbMarca.TabStop = false;
            this.gbMarca.Text = "Marca";
            // 
            // cbMarca
            // 
            this.cbMarca.Location = new System.Drawing.Point(24, 15);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(74, 21);
            this.cbMarca.TabIndex = 2;
            this.cbMarca.SelectedValueChanged += new System.EventHandler(this.cbMarca_SelectedValueChanged);
            // 
            // gbComprador
            // 
            this.gbComprador.Location = new System.Drawing.Point(123, 2);
            this.gbComprador.Name = "gbComprador";
            this.gbComprador.Size = new System.Drawing.Size(203, 40);
            this.gbComprador.TabIndex = 15;
            this.gbComprador.TabStop = false;
            this.gbComprador.Text = "Comprador";
            // 
            // mcCal01
            // 
            this.mcCal01.BackColor = System.Drawing.Color.Gray;
            this.mcCal01.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.mcCal01.Location = new System.Drawing.Point(405, 111);
            this.mcCal01.Name = "mcCal01";
            this.mcCal01.TabIndex = 18;
            this.mcCal01.Visible = false;
            this.mcCal01.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcCal01_DateSelected);
            this.mcCal01.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcCal01_KeyUp);
            this.mcCal01.Leave += new System.EventHandler(this.mcCal01_Leave);
            // 
            // mcC1
            // 
            this.mcC1.BackColor = System.Drawing.Color.Gray;
            this.mcC1.ForeColor = System.Drawing.Color.Black;
            this.mcC1.Location = new System.Drawing.Point(305, 113);
            this.mcC1.Name = "mcC1";
            this.mcC1.TabIndex = 44;
            this.mcC1.Visible = false;
            this.mcC1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcC1_DateSelected);
            this.mcC1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcC1_KeyUp);
            this.mcC1.Leave += new System.EventHandler(this.mcC1_Leave);
            // 
            // tbTdaNombre
            // 
            this.tbTdaNombre.Location = new System.Drawing.Point(354, 71);
            this.tbTdaNombre.Name = "tbTdaNombre";
            this.tbTdaNombre.Size = new System.Drawing.Size(150, 20);
            this.tbTdaNombre.TabIndex = 56;
            this.tbTdaNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTdaNombre_KeyPress);
            // 
            // tbIdTda
            // 
            this.tbIdTda.Location = new System.Drawing.Point(314, 71);
            this.tbIdTda.Name = "tbIdTda";
            this.tbIdTda.Size = new System.Drawing.Size(40, 20);
            this.tbIdTda.TabIndex = 55;
            this.tbIdTda.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbIdTda_KeyPress);
            // 
            // tbTemporada
            // 
            this.tbTemporada.Location = new System.Drawing.Point(235, 71);
            this.tbTemporada.Name = "tbTemporada";
            this.tbTemporada.Size = new System.Drawing.Size(40, 20);
            this.tbTemporada.TabIndex = 54;
            this.tbTemporada.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTemporada_KeyPress);
            // 
            // Relleno
            // 
            this.Relleno.Enabled = false;
            this.Relleno.Location = new System.Drawing.Point(4, 71);
            this.Relleno.Name = "Relleno";
            this.Relleno.Size = new System.Drawing.Size(41, 20);
            this.Relleno.TabIndex = 51;
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDescripcion.Location = new System.Drawing.Point(764, 71);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(150, 20);
            this.tbDescripcion.TabIndex = 50;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress_1);
            // 
            // tbEstilo
            // 
            this.tbEstilo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbEstilo.Location = new System.Drawing.Point(694, 71);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(70, 20);
            this.tbEstilo.TabIndex = 49;
            this.tbEstilo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbEstilo_KeyPress_1);
            // 
            // tbNombre
            // 
            this.tbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNombre.Location = new System.Drawing.Point(544, 71);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(150, 20);
            this.tbNombre.TabIndex = 48;
            this.tbNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNombre_KeyPress_1);
            // 
            // tbProveedor
            // 
            this.tbProveedor.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbProveedor.Location = new System.Drawing.Point(504, 71);
            this.tbProveedor.Name = "tbProveedor";
            this.tbProveedor.Size = new System.Drawing.Size(40, 20);
            this.tbProveedor.TabIndex = 47;
            this.tbProveedor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbProveedor_KeyPress_1);
            // 
            // gbTipoConsulta
            // 
            this.gbTipoConsulta.BackColor = System.Drawing.Color.Transparent;
            this.gbTipoConsulta.Controls.Add(this.cbTipoConsulta);
            this.gbTipoConsulta.Location = new System.Drawing.Point(738, 2);
            this.gbTipoConsulta.Name = "gbTipoConsulta";
            this.gbTipoConsulta.Size = new System.Drawing.Size(131, 40);
            this.gbTipoConsulta.TabIndex = 58;
            this.gbTipoConsulta.TabStop = false;
            this.gbTipoConsulta.Text = "Tipo de Calificación";
            // 
            // cbTipoConsulta
            // 
            this.cbTipoConsulta.BackColor = System.Drawing.Color.GhostWhite;
            this.cbTipoConsulta.FormattingEnabled = true;
            this.cbTipoConsulta.Items.AddRange(new object[] {
            "Todas",
            "Calificación",
            "PreCalificación",
            "Rebaja 01",
            "Rebaja 02",
            "Rebaja 03"});
            this.cbTipoConsulta.Location = new System.Drawing.Point(6, 15);
            this.cbTipoConsulta.Name = "cbTipoConsulta";
            this.cbTipoConsulta.Size = new System.Drawing.Size(119, 21);
            this.cbTipoConsulta.TabIndex = 24;
            this.cbTipoConsulta.SelectedIndexChanged += new System.EventHandler(this.cbTipoConsulta_SelectedIndexChanged);
            // 
            // gbTemporada
            // 
            this.gbTemporada.BackColor = System.Drawing.Color.Transparent;
            this.gbTemporada.Controls.Add(this.cbTemporada);
            this.gbTemporada.Location = new System.Drawing.Point(602, 2);
            this.gbTemporada.Name = "gbTemporada";
            this.gbTemporada.Size = new System.Drawing.Size(131, 40);
            this.gbTemporada.TabIndex = 57;
            this.gbTemporada.TabStop = false;
            this.gbTemporada.Text = "Temporada";
            // 
            // cbTemporada
            // 
            this.cbTemporada.BackColor = System.Drawing.Color.GhostWhite;
            this.cbTemporada.FormattingEnabled = true;
            this.cbTemporada.Location = new System.Drawing.Point(6, 15);
            this.cbTemporada.Name = "cbTemporada";
            this.cbTemporada.Size = new System.Drawing.Size(119, 21);
            this.cbTemporada.TabIndex = 24;
            this.cbTemporada.SelectedValueChanged += new System.EventHandler(this.cbTemporada_SelectedValueChanged);
            // 
            // btExcel
            // 
            this.btExcel.BackColor = System.Drawing.Color.White;
            this.btExcel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btExcel.Location = new System.Drawing.Point(1127, 11);
            this.btExcel.Name = "btExcel";
            this.btExcel.Size = new System.Drawing.Size(97, 23);
            this.btExcel.TabIndex = 59;
            this.btExcel.Text = "Exportar a Excel";
            this.btExcel.UseVisualStyleBackColor = false;
            this.btExcel.Click += new System.EventHandler(this.btExcel_Click);
            // 
            // rbNivelEstilo
            // 
            this.rbNivelEstilo.AutoSize = true;
            this.rbNivelEstilo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbNivelEstilo.ForeColor = System.Drawing.Color.Gray;
            this.rbNivelEstilo.Location = new System.Drawing.Point(1019, 8);
            this.rbNivelEstilo.Name = "rbNivelEstilo";
            this.rbNivelEstilo.Size = new System.Drawing.Size(89, 17);
            this.rbNivelEstilo.TabIndex = 60;
            this.rbNivelEstilo.TabStop = true;
            this.rbNivelEstilo.Text = "Nivel Estilo";
            this.rbNivelEstilo.UseVisualStyleBackColor = true;
            this.rbNivelEstilo.Click += new System.EventHandler(this.rbNivelEstilo_Click);
            // 
            // gbAdministracion
            // 
            this.gbAdministracion.BackColor = System.Drawing.Color.Transparent;
            this.gbAdministracion.Controls.Add(this.cbAdministracion);
            this.gbAdministracion.Location = new System.Drawing.Point(877, 2);
            this.gbAdministracion.Name = "gbAdministracion";
            this.gbAdministracion.Size = new System.Drawing.Size(131, 40);
            this.gbAdministracion.TabIndex = 61;
            this.gbAdministracion.TabStop = false;
            this.gbAdministracion.Text = "Tipo Consulta";
            // 
            // cbAdministracion
            // 
            this.cbAdministracion.BackColor = System.Drawing.Color.GhostWhite;
            this.cbAdministracion.FormattingEnabled = true;
            this.cbAdministracion.Items.AddRange(new object[] {
            "Todos",
            "Con Rebaja",
            "Sin Rebaja",
            ""});
            this.cbAdministracion.Location = new System.Drawing.Point(6, 14);
            this.cbAdministracion.Name = "cbAdministracion";
            this.cbAdministracion.Size = new System.Drawing.Size(119, 21);
            this.cbAdministracion.TabIndex = 24;
            this.cbAdministracion.SelectedIndexChanged += new System.EventHandler(this.cbAdministracion_SelectedIndexChanged);
            // 
            // rbNivelTienda
            // 
            this.rbNivelTienda.AutoSize = true;
            this.rbNivelTienda.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbNivelTienda.ForeColor = System.Drawing.Color.Gray;
            this.rbNivelTienda.Location = new System.Drawing.Point(1019, 25);
            this.rbNivelTienda.Name = "rbNivelTienda";
            this.rbNivelTienda.Size = new System.Drawing.Size(97, 17);
            this.rbNivelTienda.TabIndex = 74;
            this.rbNivelTienda.TabStop = true;
            this.rbNivelTienda.Text = "Nivel Tienda";
            this.rbNivelTienda.UseVisualStyleBackColor = true;
            this.rbNivelTienda.Click += new System.EventHandler(this.rbNivelTienda_Click);
            // 
            // btResumen
            // 
            this.btResumen.BackColor = System.Drawing.Color.WhiteSmoke;
            this.btResumen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btResumen.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btResumen.Location = new System.Drawing.Point(5, 45);
            this.btResumen.Name = "btResumen";
            this.btResumen.Size = new System.Drawing.Size(112, 23);
            this.btResumen.TabIndex = 75;
            this.btResumen.Text = "Resumen";
            this.btResumen.UseVisualStyleBackColor = false;
            this.btResumen.Click += new System.EventHandler(this.btResumen_Click);
            // 
            // Relleno02
            // 
            this.Relleno02.Enabled = false;
            this.Relleno02.Location = new System.Drawing.Point(45, 71);
            this.Relleno02.Name = "Relleno02";
            this.Relleno02.Size = new System.Drawing.Size(40, 20);
            this.Relleno02.TabIndex = 76;
            // 
            // Relleno03
            // 
            this.Relleno03.Enabled = false;
            this.Relleno03.Location = new System.Drawing.Point(85, 71);
            this.Relleno03.Name = "Relleno03";
            this.Relleno03.Size = new System.Drawing.Size(80, 20);
            this.Relleno03.TabIndex = 80;
            // 
            // tbTbporc
            // 
            this.tbTbporc.Location = new System.Drawing.Point(275, 71);
            this.tbTbporc.Name = "tbTbporc";
            this.tbTbporc.Size = new System.Drawing.Size(40, 20);
            this.tbTbporc.TabIndex = 78;
            this.tbTbporc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTbporc_KeyPress);
            // 
            // c_subClase
            // 
            this.c_subClase.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.c_subClase.Location = new System.Drawing.Point(1224, 71);
            this.c_subClase.Name = "c_subClase";
            this.c_subClase.Size = new System.Drawing.Size(40, 20);
            this.c_subClase.TabIndex = 82;
            this.c_subClase.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.c_subClase_KeyPress);
            // 
            // c_clase
            // 
            this.c_clase.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.c_clase.Location = new System.Drawing.Point(1184, 71);
            this.c_clase.Name = "c_clase";
            this.c_clase.Size = new System.Drawing.Size(40, 20);
            this.c_clase.TabIndex = 81;
            this.c_clase.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.c_clase_KeyPress);
            // 
            // c_subDepto
            // 
            this.c_subDepto.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.c_subDepto.Location = new System.Drawing.Point(1144, 71);
            this.c_subDepto.Name = "c_subDepto";
            this.c_subDepto.Size = new System.Drawing.Size(40, 20);
            this.c_subDepto.TabIndex = 80;
            this.c_subDepto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.c_subDepto_KeyPress);
            // 
            // c_depto
            // 
            this.c_depto.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.c_depto.Location = new System.Drawing.Point(1104, 71);
            this.c_depto.Name = "c_depto";
            this.c_depto.Size = new System.Drawing.Size(40, 20);
            this.c_depto.TabIndex = 79;
            this.c_depto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.c_depto_KeyPress);
            // 
            // Relleno04
            // 
            this.Relleno04.Enabled = false;
            this.Relleno04.Location = new System.Drawing.Point(165, 71);
            this.Relleno04.Name = "Relleno04";
            this.Relleno04.Size = new System.Drawing.Size(70, 20);
            this.Relleno04.TabIndex = 83;
            // 
            // tbIdComp
            // 
            this.tbIdComp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbIdComp.Enabled = false;
            this.tbIdComp.Location = new System.Drawing.Point(914, 71);
            this.tbIdComp.Name = "tbIdComp";
            this.tbIdComp.Size = new System.Drawing.Size(40, 20);
            this.tbIdComp.TabIndex = 84;
            this.tbIdComp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbIdComp_KeyPress);
            // 
            // tbDesComp
            // 
            this.tbDesComp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDesComp.Enabled = false;
            this.tbDesComp.Location = new System.Drawing.Point(954, 71);
            this.tbDesComp.Name = "tbDesComp";
            this.tbDesComp.Size = new System.Drawing.Size(150, 20);
            this.tbDesComp.TabIndex = 85;
            this.tbDesComp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDesComp_KeyPress);
            // 
            // Administracion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1228, 402);
            this.Controls.Add(this.tbDesComp);
            this.Controls.Add(this.tbIdComp);
            this.Controls.Add(this.Relleno04);
            this.Controls.Add(this.c_subClase);
            this.Controls.Add(this.c_clase);
            this.Controls.Add(this.c_subDepto);
            this.Controls.Add(this.c_depto);
            this.Controls.Add(this.tbTbporc);
            this.Controls.Add(this.Relleno03);
            this.Controls.Add(this.Relleno02);
            this.Controls.Add(this.btResumen);
            this.Controls.Add(this.rbNivelTienda);
            this.Controls.Add(this.gbAdministracion);
            this.Controls.Add(this.rbNivelEstilo);
            this.Controls.Add(this.btExcel);
            this.Controls.Add(this.gbTipoConsulta);
            this.Controls.Add(this.gbTemporada);
            this.Controls.Add(this.tbTdaNombre);
            this.Controls.Add(this.tbIdTda);
            this.Controls.Add(this.tbTemporada);
            this.Controls.Add(this.Relleno);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.tbEstilo);
            this.Controls.Add(this.tbNombre);
            this.Controls.Add(this.tbProveedor);
            this.Controls.Add(this.mcC1);
            this.Controls.Add(this.mcCal01);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cbCompradores);
            this.Controls.Add(this.gbMarca);
            this.Controls.Add(this.gbComprador);
            this.Controls.Add(this.pgbProg);
            this.Controls.Add(this.dgvGridview);
            this.Name = "Administracion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Administración y seguimiento a las Calificaciones";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Administracion_FormClosing);
            this.Load += new System.EventHandler(this.Administracion_Load);
            this.Resize += new System.EventHandler(this.Administracion_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridview)).EndInit();
            this.cmMenu.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbMarca.ResumeLayout(false);
            this.gbTipoConsulta.ResumeLayout(false);
            this.gbTemporada.ResumeLayout(false);
            this.gbAdministracion.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar pgbProg;
        private System.Windows.Forms.DataGridView dgvGridview;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbCompradores;
        private System.Windows.Forms.GroupBox gbMarca;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.GroupBox gbComprador;
        private System.Windows.Forms.TextBox tbCal01;
        private System.Windows.Forms.MonthCalendar mcCal01;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem FotoTSMI;
        private System.Windows.Forms.ToolStripMenuItem EliminarTSM1;
        private System.Windows.Forms.ToolStripMenuItem cosnsultaPDFTSM;
        private System.Windows.Forms.ToolStripMenuItem cargaPDFTSM;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.Label lblHasta;
        private System.Windows.Forms.TextBox tbHasta;
        private System.Windows.Forms.Label lblDesde;
        private System.Windows.Forms.MonthCalendar mcC1;
        private System.Windows.Forms.TextBox tbTdaNombre;
        private System.Windows.Forms.TextBox tbIdTda;
        private System.Windows.Forms.TextBox tbTemporada;
        private System.Windows.Forms.TextBox Relleno;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.TextBox tbProveedor;
        private System.Windows.Forms.GroupBox gbTipoConsulta;
        private System.Windows.Forms.ComboBox cbTipoConsulta;
        private System.Windows.Forms.GroupBox gbTemporada;
        private System.Windows.Forms.ComboBox cbTemporada;
        private System.Windows.Forms.Button btExcel;
        private System.Windows.Forms.RadioButton rbNivelEstilo;
        private System.Windows.Forms.GroupBox gbAdministracion;
        private System.Windows.Forms.ComboBox cbAdministracion;
        private System.Windows.Forms.RadioButton rbNivelTienda;
        private System.Windows.Forms.Button btResumen;
        private System.Windows.Forms.TextBox Relleno02;
        private System.Windows.Forms.TextBox Relleno03;
        private System.Windows.Forms.TextBox tbTbporc;
        private System.Windows.Forms.TextBox c_subClase;
        private System.Windows.Forms.TextBox c_clase;
        private System.Windows.Forms.TextBox c_subDepto;
        private System.Windows.Forms.TextBox c_depto;
        private System.Windows.Forms.TextBox Relleno04;
        private System.Windows.Forms.TextBox tbIdComp;
        private System.Windows.Forms.TextBox tbDesComp;
    }
}