﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class ResumenDiferenciado : Form
    {
        int nr;
        Point mousedownpoint = Point.Empty;

        public ResumenDiferenciado()
        {
            InitializeComponent();
        }

        private void pbSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
         
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

        private void pnlResumen_Paint(object sender, PaintEventArgs e)
        {
            Point mousedownpoint = Point.Empty;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Point mousedownpoint = Point.Empty;
        }

        private void ResumenDiferenciado_Load(object sender, EventArgs e)
        {
            Point mousedownpoint = Point.Empty;

            nr = 0;
            this.Cursor = Cursors.WaitCursor;
            System.Data.DataTable ResumenAdministracion = null;

            ResumenAdministracion = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenResumenAdministracion();

            if (ResumenAdministracion != null)
            {
                if (ResumenAdministracion.Rows.Count > 0)
                {
                foreach (DataRow row in ResumenAdministracion.Rows)
                    {
                        if (row["RSMLLA"].ToString() == "Estilos")
                        {
                            tbEstilos.Text = string.Format("{0:n0}", double.Parse(row["RSMCAL"].ToString()));                
                        }
                        if (row["RSMLLA"].ToString() == "Piezas")
                        {
                            tbPiezas.Text = string.Format("{0:n0}", double.Parse(row["RSMCAL"].ToString()));                           
                        }
                        if (row["RSMLLA"].ToString() == "Costos")
                        {
                            tbCostos.Text = string.Format("{0:n2}", double.Parse(row["RSMCAL"].ToString()));
                        }
                        if (row["RSMLLA"].ToString() == "Precios")
                        {
                            tbPrecios.Text = string.Format("{0:n2}", double.Parse(row["RSMCAL"].ToString()));
                        }
                    }
                }
            }
            this.Cursor = Cursors.Default;
            
        }

        private void pnlResumen_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void pnlResumen_MouseMove(object sender, MouseEventArgs e)
        {
           
        }

        private void pnlResumen_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

        private void ResumenDiferenciado_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void ResumenDiferenciado_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedownpoint.IsEmpty)
                return;
            Form f = sender as Form;
            f.Location = new Point(f.Location.X + (e.X - mousedownpoint.X), f.Location.Y + (e.Y - mousedownpoint.Y));
        }

        private void ResumenDiferenciado_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

        private void pbSalir_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
