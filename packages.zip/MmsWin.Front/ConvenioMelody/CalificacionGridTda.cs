﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using MmsWin.Front.Utilerias;
using System.Globalization;
using MmsWin.Front.Convenio;


namespace MmsWin.Front.ConvenioMelody
{
    public partial class CalificacionGridTda : Form
    {
        #region Variables
        // variables de la Ventana
        public static string parTemporada;
        public static string parTipoCalificacion;
        public static string parFchCalificacion;
        public static string parFchInicial;

        public static string parFchDesde;
        public static string parFchHasta;

        public static string parProveedor;
        public static string parNombre;
        public static string parEstilo;
        public static string parDescripcion;

        public static string InventarioEstilo;
        #endregion

        #region Grid
        // variables de la Ventana
        public static string gridMarca;
        public static string gridTienda;
        public static string gridFechaCalifica;
        public static string gridTipoCalifica;
        public static string gridTemporada;
        public static string gridTabla;
        public static string gridProveedor;
        public static string gridEstilo;
        public static string gridOrden;
        #endregion

        int nr;
        bool ind;           
        string FechaCal;
        string FechaFmt;
        bool Carga;
        String ParUser;
        string marca;
        string comprador;
        String FchDe;
        String FchHas;
        long FchDeN;
        long FchHasN;

        int dgvOffset;
        int dgvOffset2;

        public CalificacionGridTda()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }

        private void CalificacionGridTda_Load(object sender, EventArgs e)
        {
            try
            {
                #region Variables
                // variables de la Ventana
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.parTemporada = string.Empty;
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.parTipoCalificacion = string.Empty;
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.parFchCalificacion = string.Empty;
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.parFchInicial = string.Empty;
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.parProveedor = string.Empty;
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.parNombre = string.Empty;
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.parEstilo = string.Empty;
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.parDescripcion = string.Empty;
                #endregion

                Carga = false;
                marca = "999";
                comprador = "999";

                ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;

                FchDe = "10/10/2000";
                FchHas = "10/10/2000";
                tbDesde.Text = FchDe;
                tbHasta.Text = FchHas;

                try
                {
                    System.Data.DataTable tbFechaInicial = null;
                    tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();

                    foreach (DataRow row in tbFechaInicial.Rows)
                    {
                        tbDesde.Text = row["DSPFCH"].ToString();
                        FechaCal = tbDesde.Text;
                        FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                        tbDesde.Text = FechaFmt.ToString();
                        tbHasta.Text = FechaFmt.ToString();

                        FechaCal = tbDesde.Text;
                        FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                        FchDeN = long.Parse(FechaFmt.ToString());
                        FchDe = FechaFmt.ToString();

                        FechaCal = tbHasta.Text;
                        FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                        FchHasN = long.Parse(FechaFmt.ToString());
                        FchHas = FechaFmt.ToString();
                    }

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                // Carga de Marca
                try
                {
                    BindMarca();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                // Carga de Compradores
                try
                {
                    BindCompradores();
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                // Carga de Datos
                try
                {
                    Carga = true;
                    BinData();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            catch { }
        }

        private void BinData()
        {
            if (Carga == true)
            {
                EliminacheckBox();

                nr = 0;
                System.Data.DataTable dtCalificacionesTda = null;
                try
                {
                    this.Cursor = Cursors.WaitCursor;

                    string tipo      = string.Empty;
                    string temporada = string.Empty;
                    string tabla     = string.Empty;

                    marca               = MmsWin.Front.Utilerias.VarTem.parmarca;               
                    comprador           = MmsWin.Front.Utilerias.VarTem.parcomprador;
                    FchDe               = MmsWin.Front.Utilerias.VarTem.parFchDe;
                    FchHas              = MmsWin.Front.Utilerias.VarTem.parFchHas; 
                    tipo                = MmsWin.Front.Utilerias.VarTem.partipo;
                    temporada           = MmsWin.Front.Utilerias.VarTem.partemporada;
                    parTipoCalificacion = MmsWin.Front.Utilerias.VarTem.parTipoCalificacion;
                    parFchCalificacion  = MmsWin.Front.Utilerias.VarTem.parFchCalificacion;
                    parProveedor        = MmsWin.Front.Utilerias.VarTem.parProveedor;
                    parNombre           = MmsWin.Front.Utilerias.VarTem.parNombre;
                    parEstilo           = MmsWin.Front.Utilerias.VarTem.parEstilo;
                    parDescripcion      = MmsWin.Front.Utilerias.VarTem.parDescripcion; 

                    dtCalificacionesTda = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenCalificaionTda(marca, comprador, FchDe, FchHas, tipo, temporada, parTipoCalificacion, parFchCalificacion, parProveedor, parNombre, parEstilo, parDescripcion);
                    dgvGridView.DataSource = null;
                    if (dtCalificacionesTda.Rows.Count > 0)
                    {
                        SetDoubleBuffered(dgvGridView);
                        dgvGridView.DataSource = null;
                        dgvGridView.DataSource = dtCalificacionesTda;
                        nr = dgvGridView.RowCount;
                        this.Text = "Calificación por Tienda/ " + " " + (nr-1).ToString() + " Registro(s)" +  " / Proveedor: " + parProveedor + " Estilo: " + parEstilo + " " + parDescripcion;
                        dgvGridView.DataSource = dtCalificacionesTda;
                        CreaCheckBox();
                        SetFontAndColors();
                        rowStyleColores();
                        rowStyleSuma();
                        dgvGridView.Focus();
                        dgvGridView.Select();
                    }

                    this.Cursor = Cursors.Default;
                }

                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        private void SetFontAndColors()
        {
            int i = 0;
            try
            {
                this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                this.dgvGridView.EnableHeadersVisualStyles = false;
                this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
                this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
                this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
                this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
                this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
                this.dgvGridView.Columns["MDYSTY"].Frozen = true;
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                dgvGridView.Columns["MDYMAR"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYTDA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYTDD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgvGridView.Columns["MDYFCH"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleLeft;
                dgvGridView.Columns["MDYTPO"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleLeft;
                dgvGridView.Columns["MDYTMP"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYTAB"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYPRV"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleLeft;
                dgvGridView.Columns["MDYPRVD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgvGridView.Columns["MDYSTY"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleLeft;
                dgvGridView.Columns["MDYSTYD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgvGridView.Columns["MDYCMP"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleLeft;

                dgvGridView.Columns["MDYDEP"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYSDP"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYCLS"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYSCL"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYDEPD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgvGridView.Columns["MDYSDPD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgvGridView.Columns["MDYCLSD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                dgvGridView.Columns["MDYSCLD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

                dgvGridView.Columns["MDYPVT"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;

                dgvGridView.Columns["MDYSM01"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYSM01"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYSM02"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYSM03"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYSM04"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYSM05"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYSM06"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYSM07"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYSM08"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYSM09"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYSM10"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgvGridView.Columns["MDYDPA"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;

                dgvGridView.Columns["MDYCDP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYCOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYCFN"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                dgvGridView.Columns["MDYCST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYPRC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYMRG"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                dgvGridView.Columns["MDYDDV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                dgvGridView.Columns["SLTSM01"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["SLTSM02"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["SLTSM03"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["SLTSM04"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["SLTSM05"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["SLTSM06"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["SLTSM07"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["SLTSM08"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["SLTSM09"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["SLTSM10"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgvGridView.Columns["MDYORD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYFRB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYCRB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgvGridView.Columns["MDYVPZ"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYOHP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYONO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYTST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYPDI"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgvGridView.Columns["MDYCTT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYPZA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYCSB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgvGridView.Columns["MDYBDG"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                dgvGridView.Columns["MDYCSTI"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYPREI"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYMRGI"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                dgvGridView.Columns["MDYUCP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYFCP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYHCP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYRTB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgvGridView.Columns["MDYOBC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

                dgvGridView.Columns["MDYUCT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYFCT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYHCT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                dgvGridView.Columns["MDYOBT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

                dgvGridView.Columns["MDYUAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYFAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["MDYHAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                dgvGridView.Columns["MDYMTX"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYCLP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["MDYCLA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["INVENTARIO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                //dgvGridView.Columns["MDYUCA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                //dgvGridView.Columns["MDYFCA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                //dgvGridView.Columns["MDYHCA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                dgvGridView.Columns["MDYMAR"].Width  = 45;
                dgvGridView.Columns["MDYTDA"].Width  = 45;
                dgvGridView.Columns["MDYTDD"].Width  = 150;
                dgvGridView.Columns["MDYFCH"].Width  = 80;
                dgvGridView.Columns["MDYTPO"].Width  = 70;
                dgvGridView.Columns["MDYTMP"].Width  = 45;
                dgvGridView.Columns["MDYTAB"].Width  = 45;
                dgvGridView.Columns["MDYPRV"].Width  = 45;
                dgvGridView.Columns["MDYPRVD"].Width = 150;
                dgvGridView.Columns["MDYSTY"].Width  = 65;
                dgvGridView.Columns["MDYSTYD"].Width = 150;
                dgvGridView.Columns["MDYCMP"].Width  = 100;

                dgvGridView.Columns["MDYDEP"].Width  = 30;
                dgvGridView.Columns["MDYSDP"].Width  = 30;
                dgvGridView.Columns["MDYCLS"].Width  = 30;
                dgvGridView.Columns["MDYSCL"].Width  = 30;
                dgvGridView.Columns["MDYDEPD"].Width = 100;
                dgvGridView.Columns["MDYSDPD"].Width = 100;
                dgvGridView.Columns["MDYCLSD"].Width = 100;
                dgvGridView.Columns["MDYSCLD"].Width = 100;

                dgvGridView.Columns["MDYPVT"].Width  = 65;

                dgvGridView.Columns["MDYCDP"].Width = 75;
                dgvGridView.Columns["MDYCOR"].Width = 75;
                dgvGridView.Columns["MDYCFN"].Width = 75;
                dgvGridView.Columns["MDYRTB"].Width = 80;

                dgvGridView.Columns["MDYSM01"].Width = 50;
                dgvGridView.Columns["MDYSM01"].Width = 50;
                dgvGridView.Columns["MDYSM02"].Width = 50;
                dgvGridView.Columns["MDYSM03"].Width = 50;
                dgvGridView.Columns["MDYSM04"].Width = 50;
                dgvGridView.Columns["MDYSM05"].Width = 50;
                dgvGridView.Columns["MDYSM06"].Width = 50;
                dgvGridView.Columns["MDYSM07"].Width = 50;
                dgvGridView.Columns["MDYSM08"].Width = 50;
                dgvGridView.Columns["MDYSM09"].Width = 50;
                dgvGridView.Columns["MDYSM10"].Width = 50;

                dgvGridView.Columns["MDYDPA"].Width = 50;

                dgvGridView.Columns["MDYCST"].Width = 50;
                dgvGridView.Columns["MDYPRC"].Width = 50;
                dgvGridView.Columns["MDYMRG"].Width = 50;

                dgvGridView.Columns["MDYDDV"].Width = 50;

                dgvGridView.Columns["SLTSM01"].Width = 50;
                dgvGridView.Columns["SLTSM02"].Width = 50;
                dgvGridView.Columns["SLTSM03"].Width = 50;
                dgvGridView.Columns["SLTSM04"].Width = 50;
                dgvGridView.Columns["SLTSM05"].Width = 50;
                dgvGridView.Columns["SLTSM06"].Width = 50;
                dgvGridView.Columns["SLTSM07"].Width = 50;
                dgvGridView.Columns["SLTSM08"].Width = 50;
                dgvGridView.Columns["SLTSM09"].Width = 50;
                dgvGridView.Columns["SLTSM10"].Width = 50;

                dgvGridView.Columns["MDYORD"].Width = 60;
                dgvGridView.Columns["MDYFRB"].Width = 80;
                dgvGridView.Columns["MDYCRB"].Width = 60;

                dgvGridView.Columns["MDYVPZ"].Width = 60;
                dgvGridView.Columns["MDYOHP"].Width = 60;
                dgvGridView.Columns["MDYONO"].Width = 60;
                dgvGridView.Columns["MDYTST"].Width = 60;
                dgvGridView.Columns["MDYPDI"].Width = 60;

                dgvGridView.Columns["MDYCTT"].Width = 80;
                dgvGridView.Columns["MDYPZA"].Width = 60;
                dgvGridView.Columns["MDYCSB"].Width = 80;

                dgvGridView.Columns["MDYBDG"].Width = 60;

                dgvGridView.Columns["MDYCSTI"].Width = 60;
                dgvGridView.Columns["MDYPREI"].Width = 60;
                dgvGridView.Columns["MDYMRGI"].Width = 60;

                dgvGridView.Columns["MDYUCP"].Width = 60;
                dgvGridView.Columns["MDYFCP"].Width = 80;
                dgvGridView.Columns["MDYHCP"].Width = 60;

                dgvGridView.Columns["MDYOBC"].Width = 250;

                dgvGridView.Columns["MDYUCT"].Width = 60;
                dgvGridView.Columns["MDYFCT"].Width = 80;
                dgvGridView.Columns["MDYHCT"].Width = 60;

                dgvGridView.Columns["MDYOBT"].Width = 250;

                dgvGridView.Columns["MDYUAL"].Width = 60;
                dgvGridView.Columns["MDYFAL"].Width = 80;
                dgvGridView.Columns["MDYHAL"].Width = 60;

                dgvGridView.Columns["MDYMTX"].Width = 60;
                dgvGridView.Columns["MDYCLP"].Width = 60;
                dgvGridView.Columns["MDYCLA"].Width = 60;
                dgvGridView.Columns["INVENTARIO"].Width = 60;

                //dgvGridView.Columns["MDYUCA"].Width = 60;
                //dgvGridView.Columns["MDYFCA"].Width = 80;
                //dgvGridView.Columns["MDYHCA"].Width = 60;
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                //dgvGridView.Columns["MDYSM10"].Visible = false;
                //dgvGridView.Columns["SLTSM10"].Visible = false;
                //dgvGridView.Columns["MDYDPA"].Visible = false;
                //dgvGridView.Columns["MDYMAR"].Visible = false;
                //dgvGridView.Columns["MDYBDG"].Visible = false;

                dgvGridView.Columns["MDYCOM"].Visible = false;

                //dgvGridView.Columns["MDYUAL"].Visible = false;
                //dgvGridView.Columns["MDYFAL"].Visible = false;
                //dgvGridView.Columns["MDYHAL"].Visible = false;

                dgvGridView.Columns["MDYUCA"].Visible = false; 
                dgvGridView.Columns["MDYFCA"].Visible = false;
                dgvGridView.Columns["MDYHCA"].Visible = false;
                //dgvGridView.Columns["MDYCFN"].Visible = false;

                dgvGridView.Columns["MDYMAR"].HeaderText  = "Marca";
                dgvGridView.Columns["MDYTDA"].HeaderText  = "Tienda";
                dgvGridView.Columns["MDYTDD"].HeaderText  = "Nombre";
                dgvGridView.Columns["MDYFCH"].HeaderText  = "Fecha Calificación";
                dgvGridView.Columns["MDYTPO"].HeaderText  = "Tipo Calificación";
                dgvGridView.Columns["MDYTMP"].HeaderText  = "Temporada";
                dgvGridView.Columns["MDYTAB"].HeaderText  = "Tabla";
                dgvGridView.Columns["MDYPRV"].HeaderText  = "Proveedor";
                dgvGridView.Columns["MDYPRVD"].HeaderText = "Nombre";
                dgvGridView.Columns["MDYSTY"].HeaderText  = "Estilo";
                dgvGridView.Columns["MDYSTYD"].HeaderText = "Descripción";
                dgvGridView.Columns["MDYCMP"].HeaderText  = "Comprador";

                dgvGridView.Columns["MDYDEP"].HeaderText  = "DP";
                dgvGridView.Columns["MDYSDP"].HeaderText  = "SD";
                dgvGridView.Columns["MDYCLS"].HeaderText  = "CL";
                dgvGridView.Columns["MDYSCL"].HeaderText  = "SC";

                dgvGridView.Columns["MDYDEPD"].HeaderText = "Departamento";
                dgvGridView.Columns["MDYSDPD"].HeaderText = "Sub Departamento";
                dgvGridView.Columns["MDYCLSD"].HeaderText = "Clase";
                dgvGridView.Columns["MDYSCLD"].HeaderText = "Sub Clase";

                dgvGridView.Columns["MDYPVT"].HeaderText  = "   %    Venta";

                dgvGridView.Columns["MDYSM01"].HeaderText = "Venta Sem -1";
                dgvGridView.Columns["MDYSM02"].HeaderText = "Venta Sem -2";
                dgvGridView.Columns["MDYSM03"].HeaderText = "Venta Sem -3";
                dgvGridView.Columns["MDYSM04"].HeaderText = "Venta Sem -4";
                dgvGridView.Columns["MDYSM05"].HeaderText = "Venta Sem -5";
                dgvGridView.Columns["MDYSM06"].HeaderText = "Venta Sem -6";
                dgvGridView.Columns["MDYSM07"].HeaderText = "Venta Sem -7";
                dgvGridView.Columns["MDYSM08"].HeaderText = "Venta Sem -8";
                dgvGridView.Columns["MDYSM09"].HeaderText = "Venta Sem -9";
                dgvGridView.Columns["MDYSM10"].HeaderText = "Venta Sem-10";

                dgvGridView.Columns["MDYDPA"].HeaderText  = "DesPlaz Acumulado";

                dgvGridView.Columns["MDYCDP"].HeaderText  = "Calificaión";
                dgvGridView.Columns["MDYCOR"].HeaderText  = "Calificaión Original";
                dgvGridView.Columns["MDYCFN"].HeaderText  = "Calificaión En-Firme";
                dgvGridView.Columns["MDYRTB"].HeaderText = "Rentabilidad";

                dgvGridView.Columns["MDYCST"].HeaderText  = "Costo Actual";
                dgvGridView.Columns["MDYPRC"].HeaderText  = "Precio Actual";
                dgvGridView.Columns["MDYMRG"].HeaderText  = "Margen Actual";

                dgvGridView.Columns["MDYDDV"].HeaderText  = "Dias de Venta";

                dgvGridView.Columns["SLTSM01"].HeaderText = "Sell thru01";
                dgvGridView.Columns["SLTSM02"].HeaderText = "Sell thru02";
                dgvGridView.Columns["SLTSM03"].HeaderText = "Sell thru03";
                dgvGridView.Columns["SLTSM04"].HeaderText = "Sell thru04";
                dgvGridView.Columns["SLTSM05"].HeaderText = "Sell thru05";
                dgvGridView.Columns["SLTSM06"].HeaderText = "Sell thru06";
                dgvGridView.Columns["SLTSM07"].HeaderText = "Sell thru07";
                dgvGridView.Columns["SLTSM08"].HeaderText = "Sell thru08";
                dgvGridView.Columns["SLTSM09"].HeaderText = "Sell thru09";
                dgvGridView.Columns["SLTSM10"].HeaderText = "Sell thru10";

                dgvGridView.Columns["MDYORD"].HeaderText  = "No. Orden";
                dgvGridView.Columns["MDYFRB"].HeaderText  = "Fecha Recibo";
                dgvGridView.Columns["MDYCRB"].HeaderText  = "Piezas Recibidas";

                dgvGridView.Columns["MDYVPZ"].HeaderText  = "Piezas Vendidas";

                dgvGridView.Columns["MDYOHP"].HeaderText  = "On Hand";
                dgvGridView.Columns["MDYONO"].HeaderText  = "On Order";
                dgvGridView.Columns["MDYTST"].HeaderText  = "Transito";
                dgvGridView.Columns["MDYPDI"].HeaderText  = "Post Dist";

                dgvGridView.Columns["MDYCTT"].HeaderText  = "Costo Total";
                dgvGridView.Columns["MDYPZA"].HeaderText  = "Piezas Bonificar";
                dgvGridView.Columns["MDYCSB"].HeaderText  = "Costo Bonificación";

                dgvGridView.Columns["MDYBDG"].HeaderText  = "Bodega";

                dgvGridView.Columns["MDYCSTI"].HeaderText = "Costo Inicial";
                dgvGridView.Columns["MDYPREI"].HeaderText = "Precio Inicial";
                dgvGridView.Columns["MDYMRGI"].HeaderText = "Margen Inicial";

                dgvGridView.Columns["MDYUCP"].HeaderText  = "Usuario Compras";
                dgvGridView.Columns["MDYFCP"].HeaderText  = "Fecha Compras";
                dgvGridView.Columns["MDYHCP"].HeaderText  = "Hora Compras";

                dgvGridView.Columns["MDYOBC"].HeaderText  = "Onservaciones Compras";

                dgvGridView.Columns["MDYUCT"].HeaderText  = "Usuario Contraloria";
                dgvGridView.Columns["MDYFCT"].HeaderText  = "Fecha Contraloria";
                dgvGridView.Columns["MDYHCT"].HeaderText  = "Hora Contraloria";

                dgvGridView.Columns["MDYOBT"].HeaderText  = "Observaciones Contraloria";

                dgvGridView.Columns["MDYUAL"].HeaderText  = "Usuario Alta";
                dgvGridView.Columns["MDYFAL"].HeaderText  = "Fecha Alta";
                dgvGridView.Columns["MDYHAL"].HeaderText  = "Hora Alta";

                dgvGridView.Columns["MDYMTX"].HeaderText = "Matriz";
                dgvGridView.Columns["MDYCLP"].HeaderText = "Puntos" ;
                dgvGridView.Columns["MDYCLA"].HeaderText = "Calificaión Tienda";

                //dgvGridView.Columns["MDYUCA"].HeaderText  = "Usuario Cambio";
                //dgvGridView.Columns["MDYFCA"].HeaderText  = "Fecha Cambio";
                //dgvGridView.Columns["MDYHCA"].HeaderText  = "Hora Cambio";

                dgvGridView.Columns["MDYMAR"].Visible     = false;
                dgvGridView.Columns["MDYTDA"].HeaderText  = "Tienda";
                dgvGridView.Columns["MDYTDD"].HeaderText  = "Nombre";
                dgvGridView.Columns["MDYFCH"].Visible     = false;
                dgvGridView.Columns["MDYTPO"].Visible     = false;
                dgvGridView.Columns["MDYTMP"].Visible     = false;
                dgvGridView.Columns["MDYTAB"].Visible     = false;
                dgvGridView.Columns["MDYPRV"].Visible     = false;
                dgvGridView.Columns["MDYPRVD"].Visible    = false;
                dgvGridView.Columns["MDYSTY"].Visible     = false;
                dgvGridView.Columns["MDYSTYD"].Visible    = false;
                dgvGridView.Columns["MDYCMP"].Visible     = false;

                dgvGridView.Columns["MDYDEP"].Visible = false;
                dgvGridView.Columns["MDYSDP"].Visible = false;
                dgvGridView.Columns["MDYCLS"].Visible = false;
                dgvGridView.Columns["MDYSCL"].Visible = false;

                dgvGridView.Columns["MDYDEPD"].Visible = false;
                dgvGridView.Columns["MDYSDPD"].Visible = false;
                dgvGridView.Columns["MDYCLSD"].Visible = false;
                dgvGridView.Columns["MDYSCLD"].Visible = false;

                dgvGridView.Columns["MDYPVT"].HeaderText = "   %    Venta";

                //dgvGridView.Columns["MDYSM01"].Visible = false;
                dgvGridView.Columns["MDYSM02"].Visible = false;
                dgvGridView.Columns["MDYSM03"].Visible = false;
                dgvGridView.Columns["MDYSM04"].Visible = false;
                dgvGridView.Columns["MDYSM05"].Visible = false;
                dgvGridView.Columns["MDYSM06"].Visible = false;
                dgvGridView.Columns["MDYSM07"].Visible = false;
                dgvGridView.Columns["MDYSM08"].Visible = false;
                dgvGridView.Columns["MDYSM09"].Visible = false;
                dgvGridView.Columns["MDYSM10"].Visible = false;

                dgvGridView.Columns["MDYDPA"].Visible = false;

                dgvGridView.Columns["MDYCDP"].HeaderText = "Calificaión";
                dgvGridView.Columns["MDYCOR"].Visible = false;
                dgvGridView.Columns["MDYCFN"].Visible = false;

                //dgvGridView.Columns["MDYRTB"].Visible = false;
                dgvGridView.Columns["MDYRT2"].Visible = false;
                dgvGridView.Columns["MDYRT3"].Visible = false;
                dgvGridView.Columns["MDYRT4"].Visible = false;

                dgvGridView.Columns["MDYCST"].Visible = false;
                dgvGridView.Columns["MDYPRC"].Visible = false;
                dgvGridView.Columns["MDYMRG"].Visible = false;

                dgvGridView.Columns["MDYDDV"].HeaderText = "Dias de Venta";

                dgvGridView.Columns["SLTSM01"].Visible = false;
                dgvGridView.Columns["SLTSM02"].Visible = false;
                dgvGridView.Columns["SLTSM03"].Visible = false;
                dgvGridView.Columns["SLTSM04"].Visible = false;
                dgvGridView.Columns["SLTSM05"].Visible = false;
                dgvGridView.Columns["SLTSM06"].Visible = false;
                dgvGridView.Columns["SLTSM07"].Visible = false;
                dgvGridView.Columns["SLTSM08"].Visible = false;
                dgvGridView.Columns["SLTSM09"].Visible = false;
                dgvGridView.Columns["SLTSM10"].Visible = false;

                dgvGridView.Columns["MDYORD"].Visible = false;
                dgvGridView.Columns["MDYFRB"].HeaderText = "Fecha Recibo Tienda";
                dgvGridView.Columns["MDYCRB"].HeaderText = "Piezas Recibidas";

                dgvGridView.Columns["MDYVPZ"].HeaderText = "Piezas Vendidas";

                dgvGridView.Columns["MDYOHP"].HeaderText = "On Hand";
                dgvGridView.Columns["MDYONO"].HeaderText = "On Order";
                dgvGridView.Columns["MDYTST"].HeaderText = "Transito";
                dgvGridView.Columns["MDYPDI"].Visible = false;

                dgvGridView.Columns["MDYCTT"].Visible = false;
                dgvGridView.Columns["MDYPZA"].Visible = false;
                dgvGridView.Columns["MDYCSB"].Visible = false;

                dgvGridView.Columns["MDYBDG"].Visible = false;

                dgvGridView.Columns["MDYCSTI"].Visible = false;
                dgvGridView.Columns["MDYPREI"].Visible = false;
                dgvGridView.Columns["MDYMRGI"].Visible = false;

                dgvGridView.Columns["INVENTARIO"].HeaderText = "Inventario Actual";

                //dgvGridView.Columns["MDYUCP"].Visible = false;
                //dgvGridView.Columns["MDYFCP"].Visible = false;
                //dgvGridView.Columns["MDYHCP"].Visible = false;

                //dgvGridView.Columns["MDYOBC"].Visible = false;

                dgvGridView.Columns["MDYUCT"].Visible = false;
                dgvGridView.Columns["MDYFCT"].Visible = false;
                dgvGridView.Columns["MDYHCT"].Visible = false;

                dgvGridView.Columns["MDYOBT"].Visible = false;

                dgvGridView.Columns["MDYUAL"].Visible = false;
                dgvGridView.Columns["MDYFAL"].Visible = false;
                dgvGridView.Columns["MDYHAL"].Visible = false;           
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                dgvGridView.Columns["MDYMAR"].DefaultCellStyle.Format = "###";
                dgvGridView.Columns["MDYTDA"].DefaultCellStyle.Format = "###";
                dgvGridView.Columns["MDYTDD"].DefaultCellStyle.Format = "###";

                dgvGridView.Columns["MDYFCH"].DefaultCellStyle.Format = "20##-##-##";

                dgvGridView.Columns["MDYTAB"].DefaultCellStyle.Format = "###";
                dgvGridView.Columns["MDYPRV"].DefaultCellStyle.Format = "######";

                dgvGridView.Columns["MDYDEP"].DefaultCellStyle.Format = "###";
                dgvGridView.Columns["MDYSDP"].DefaultCellStyle.Format = "###";
                dgvGridView.Columns["MDYCLS"].DefaultCellStyle.Format = "###";
                dgvGridView.Columns["MDYSCL"].DefaultCellStyle.Format = "###";

                dgvGridView.Columns["MDYPVT"].DefaultCellStyle.Format = "##.00";
                dgvGridView.Columns["MDYRTB"].DefaultCellStyle.Format = "##.00";

                dgvGridView.Columns["MDYSM01"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYSM01"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYSM02"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYSM03"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYSM04"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYSM05"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYSM06"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYSM07"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYSM08"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYSM09"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYSM10"].DefaultCellStyle.Format = "###,###";

                dgvGridView.Columns["MDYDPA"].DefaultCellStyle.Format = "##.00";

                dgvGridView.Columns["MDYCST"].DefaultCellStyle.Format  = "###.00";
                dgvGridView.Columns["MDYPRC"].DefaultCellStyle.Format  = "###.00";
                dgvGridView.Columns["MDYMRG"].DefaultCellStyle.Format  = "###.00";

                dgvGridView.Columns["MDYDDV"].DefaultCellStyle.Format  = "###,###";

                dgvGridView.Columns["SLTSM01"].DefaultCellStyle.Format = "##.00";
                dgvGridView.Columns["SLTSM02"].DefaultCellStyle.Format = "##.00";
                dgvGridView.Columns["SLTSM03"].DefaultCellStyle.Format = "##.00";
                dgvGridView.Columns["SLTSM04"].DefaultCellStyle.Format = "##.00";
                dgvGridView.Columns["SLTSM05"].DefaultCellStyle.Format = "##.00";
                dgvGridView.Columns["SLTSM06"].DefaultCellStyle.Format = "##.00";
                dgvGridView.Columns["SLTSM07"].DefaultCellStyle.Format = "##.00";
                dgvGridView.Columns["SLTSM08"].DefaultCellStyle.Format = "##.00";
                dgvGridView.Columns["SLTSM09"].DefaultCellStyle.Format = "##.00";
                dgvGridView.Columns["SLTSM10"].DefaultCellStyle.Format = "##.00";

                dgvGridView.Columns["MDYORD"].DefaultCellStyle.Format = "##########";
                dgvGridView.Columns["MDYFRB"].DefaultCellStyle.Format = "20##-##-##";
                dgvGridView.Columns["MDYCRB"].DefaultCellStyle.Format = "#,###,###";

                dgvGridView.Columns["MDYVPZ"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYOHP"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYONO"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYTST"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYPDI"].DefaultCellStyle.Format = "###,###";

                dgvGridView.Columns["MDYCTT"].DefaultCellStyle.Format = "###,##0.00";
                dgvGridView.Columns["MDYPZA"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYCSB"].DefaultCellStyle.Format = "###,##0.00";

                dgvGridView.Columns["MDYCSTI"].DefaultCellStyle.Format = "##.00";
                dgvGridView.Columns["MDYPREI"].DefaultCellStyle.Format = "##.00";
                dgvGridView.Columns["MDYMRGI"].DefaultCellStyle.Format = "##.00";

                dgvGridView.Columns["MDYFCP"].DefaultCellStyle.Format = "20##-##-##";
                dgvGridView.Columns["MDYHCP"].DefaultCellStyle.Format = "##:##:##";

                dgvGridView.Columns["MDYFCT"].DefaultCellStyle.Format = "20##-##-##";
                dgvGridView.Columns["MDYHCT"].DefaultCellStyle.Format = "##:##:##";

                dgvGridView.Columns["MDYFAL"].DefaultCellStyle.Format = "20##-##-##";
                dgvGridView.Columns["MDYHAL"].DefaultCellStyle.Format = "##:##:##";

                dgvGridView.Columns["MDYMTX"].DefaultCellStyle.Format = "###,###";
                dgvGridView.Columns["MDYCLP"].DefaultCellStyle.Format = "###,###";

                dgvGridView.Columns["INVENTARIO"].DefaultCellStyle.Format = "###,###";

                //dgvGridView.Columns["MDYFCA"].DefaultCellStyle.Format = "20##-##-##";
                //dgvGridView.Columns["MDYHCA"].DefaultCellStyle.Format = "##:##:##";
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                dgvGridView.Columns["MDYMAR"].HeaderCell.Style.BackColor  = Color.LightSalmon;
                dgvGridView.Columns["MDYTDA"].HeaderCell.Style.BackColor  = Color.LightSalmon;
                dgvGridView.Columns["MDYTDD"].HeaderCell.Style.BackColor  = Color.LightSalmon;
                dgvGridView.Columns["MDYFCH"].HeaderCell.Style.BackColor  = Color.LightSalmon;
                dgvGridView.Columns["MDYTPO"].HeaderCell.Style.BackColor  = Color.LightSalmon;
                dgvGridView.Columns["MDYTMP"].HeaderCell.Style.BackColor  = Color.LightSalmon;
                dgvGridView.Columns["MDYTAB"].HeaderCell.Style.BackColor  = Color.LightSalmon;
                dgvGridView.Columns["MDYPRV"].HeaderCell.Style.BackColor  = Color.LightSalmon;
                dgvGridView.Columns["MDYPRVD"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvGridView.Columns["MDYSTY"].HeaderCell.Style.BackColor  = Color.LightSalmon;
                dgvGridView.Columns["MDYSTYD"].HeaderCell.Style.BackColor = Color.LightSalmon;
                dgvGridView.Columns["MDYCMP"].HeaderCell.Style.BackColor  = Color.LightSlateGray;

                dgvGridView.Columns["MDYDEP"].HeaderCell.Style.BackColor  = Color.LightGreen;
                dgvGridView.Columns["MDYSDP"].HeaderCell.Style.BackColor  = Color.LightGreen;
                dgvGridView.Columns["MDYCLS"].HeaderCell.Style.BackColor  = Color.LightGreen;
                dgvGridView.Columns["MDYSCL"].HeaderCell.Style.BackColor  = Color.LightGreen;
                dgvGridView.Columns["MDYDEPD"].HeaderCell.Style.BackColor = Color.LightGreen;
                dgvGridView.Columns["MDYSDPD"].HeaderCell.Style.BackColor = Color.LightGreen;
                dgvGridView.Columns["MDYCLSD"].HeaderCell.Style.BackColor = Color.LightGreen;
                dgvGridView.Columns["MDYSCLD"].HeaderCell.Style.BackColor = Color.LightGreen;

                dgvGridView.Columns["MDYPVT"].HeaderCell.Style.BackColor  = Color.LightSlateGray;
                dgvGridView.Columns["MDYRTB"].HeaderCell.Style.BackColor = Color.LightSlateGray;

                dgvGridView.Columns["MDYSM01"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYSM02"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYSM03"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYSM04"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYSM05"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYSM06"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYSM07"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYSM08"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYSM09"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYSM10"].HeaderCell.Style.BackColor = Color.LightSlateGray;

                dgvGridView.Columns["MDYDPA"].HeaderCell.Style.BackColor = Color.OrangeRed;

                dgvGridView.Columns["MDYCDP"].HeaderCell.Style.BackColor = Color.Blue;
                dgvGridView.Columns["MDYCOR"].HeaderCell.Style.BackColor = Color.Blue;
                dgvGridView.Columns["MDYCFN"].HeaderCell.Style.BackColor = Color.Blue;

                dgvGridView.Columns["MDYCST"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYPRC"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYMRG"].HeaderCell.Style.BackColor = Color.LightSlateGray;

                dgvGridView.Columns["MDYDDV"].HeaderCell.Style.BackColor = Color.Blue;

                dgvGridView.Columns["SLTSM01"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvGridView.Columns["SLTSM02"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvGridView.Columns["SLTSM03"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvGridView.Columns["SLTSM04"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvGridView.Columns["SLTSM05"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvGridView.Columns["SLTSM06"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvGridView.Columns["SLTSM07"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvGridView.Columns["SLTSM08"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvGridView.Columns["SLTSM09"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
                dgvGridView.Columns["SLTSM10"].HeaderCell.Style.BackColor = Color.LightSeaGreen;

                dgvGridView.Columns["MDYORD"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYFRB"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYCRB"].HeaderCell.Style.BackColor = Color.LightSlateGray;

                dgvGridView.Columns["MDYVPZ"].HeaderCell.Style.BackColor = Color.LightSlateGray;

                dgvGridView.Columns["MDYOHP"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYONO"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYTST"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYPDI"].HeaderCell.Style.BackColor = Color.LightSlateGray;

                dgvGridView.Columns["MDYCTT"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYPZA"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["MDYCSB"].HeaderCell.Style.BackColor = Color.LightSlateGray;

                dgvGridView.Columns["MDYBDG"].HeaderCell.Style.BackColor = Color.LightPink;

                dgvGridView.Columns["MDYCSTI"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
                dgvGridView.Columns["MDYPREI"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
                dgvGridView.Columns["MDYMRGI"].HeaderCell.Style.BackColor = Color.LightSkyBlue;

                dgvGridView.Columns["MDYUCP"].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
                dgvGridView.Columns["MDYUCP"].HeaderCell.Style.ForeColor = Color.White;
                dgvGridView.Columns["MDYFCP"].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
                dgvGridView.Columns["MDYFCP"].HeaderCell.Style.ForeColor = Color.White;
                dgvGridView.Columns["MDYHCP"].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
                dgvGridView.Columns["MDYHCP"].HeaderCell.Style.ForeColor = Color.White;
                dgvGridView.Columns["MDYOBC"].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
                dgvGridView.Columns["MDYOBC"].HeaderCell.Style.ForeColor = Color.White;

                dgvGridView.Columns["MDYUCT"].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
                dgvGridView.Columns["MDYUCT"].HeaderCell.Style.ForeColor = Color.White;
                dgvGridView.Columns["MDYFCT"].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
                dgvGridView.Columns["MDYFCT"].HeaderCell.Style.ForeColor = Color.White;
                dgvGridView.Columns["MDYHCT"].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
                dgvGridView.Columns["MDYHCT"].HeaderCell.Style.ForeColor = Color.White;
                dgvGridView.Columns["MDYOBT"].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
                dgvGridView.Columns["MDYOBT"].HeaderCell.Style.ForeColor = Color.White;

                dgvGridView.Columns["MDYUAL"].HeaderCell.Style.BackColor = Color.LightCoral;
                dgvGridView.Columns["MDYFAL"].HeaderCell.Style.BackColor = Color.LightCoral;
                dgvGridView.Columns["MDYHAL"].HeaderCell.Style.BackColor = Color.LightCoral;

                dgvGridView.Columns["MDYMTX"].HeaderCell.Style.BackColor = Color.Red;
                dgvGridView.Columns["MDYCLP"].HeaderCell.Style.BackColor = Color.Red;
                dgvGridView.Columns["MDYCLA"].HeaderCell.Style.BackColor = Color.Red;
                dgvGridView.Columns["INVENTARIO"].HeaderCell.Style.BackColor = Color.Blue;

                //dgvGridView.Columns["MDYUCA"].HeaderCell.Style.BackColor = Color.LightPink;
                //dgvGridView.Columns["MDYFCA"].HeaderCell.Style.BackColor = Color.LightPink;
                //dgvGridView.Columns["MDYHCA"].HeaderCell.Style.BackColor = Color.LightPink;

                //dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                //dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
                //dgvGridView.EnableHeadersVisualStyles = false;

                //dgvGridView.Columns["DSPFRV"].DisplayIndex = 8;

                dgvGridView.Columns["CHKCOMP"].DisplayIndex = 64;
                //dgvGridView.Columns["CHKCOMP"].Visible = false;
                dgvGridView.Columns["MDYCBC"].Visible = false;

                dgvGridView.Columns["CHKCONTR"].DisplayIndex = 76;
                //dgvGridView.Columns["CHKCONTR"].Visible = false;

                dgvGridView.Columns["MDYUCP"].Visible = false;
                dgvGridView.Columns["MDYFCP"].Visible = false;
                dgvGridView.Columns["MDYHCP"].Visible = false;

                dgvGridView.Columns["CHKCOMP"].Visible = false;
                dgvGridView.Columns["MDYOBC"].Visible = false;
                dgvGridView.Columns["MDYOBT"].Visible = false;

                dgvGridView.Columns["MDYCRB"].Visible = false;
                dgvGridView.Columns["MDYFRB"].Visible = false;
                dgvGridView.Columns["MDYOBT"].Visible = false;

                dgvGridView.Columns["MDYUAL"].Visible = false;
                dgvGridView.Columns["MDYFAL"].Visible = false;
                dgvGridView.Columns["MDYHAL"].Visible = false;

                dgvGridView.Columns["MDYMTX"].Visible = false;
                dgvGridView.Columns["MDYCLP"].Visible = false;
                dgvGridView.Columns["MDYCLA"].Visible = false;

                dgvGridView.Columns["MDYCBT"].Visible = false;

                dgvGridView.Columns["MDYUCT"].Visible = false;
                dgvGridView.Columns["MDYFCT"].Visible = false;
                dgvGridView.Columns["MDYHCT"].Visible = false;
                dgvGridView.Columns["MDYOBT"].Visible = false;
                dgvGridView.Columns["CHKCONTR"].Visible = false;
                dgvGridView.Columns["MDYDDV"].Visible = false;
            }
            catch { }
        }

        private void rowStyleSuma()
        {
            int Regs = 0;

            int tot11 = 0;
            int tot12 = 0;
            int tot13 = 0;
            int tot14 = 0;
            int tot15 = 0;
            int tot16 = 0;
            int tot17 = 0;

            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                dgvGridView.Select();

                Regs += 1;

                if ((Convert.ToString((rowp.Cells[2].Value))) == "Total")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.FromArgb(0, 0, 192);
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.ForeColor = Color.White;

                    // Suma Recibos                                        
                    rowp.Cells[23].Value = 0;
                    tot11 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[23].Value));
                    rowp.Cells[23].Value = tot11;
                    // Suma piezas Vendidas                                  
                    rowp.Cells[24].Value = 0;
                    tot12 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[24].Value));
                    rowp.Cells[24].Value = tot12;
                    // Suma MDYOHP                                       
                    rowp.Cells[33].Value = 0;
                    tot13 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[33].Value));
                    rowp.Cells[33].Value = tot13;
                    // Suma MDYTST                                       
                    rowp.Cells[34].Value = 0;
                    tot14 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[34].Value));
                    rowp.Cells[34].Value = tot14;
                    // Suma MDYONO                                       
                    rowp.Cells[35].Value = 0;
                    tot15 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[35].Value));
                    rowp.Cells[35].Value = tot15;
                    // Suma Puntos                                       
                    rowp.Cells[86].Value = 0;
                    tot16 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[86].Value));
                    rowp.Cells[86].Value = tot16;

                    // Suma Inventario Actual                                       
                    rowp.Cells[88].Value = 0;
                    tot17 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[88].Value));
                    rowp.Cells[88].Value = tot17;

                    MmsWin.Front.ConvenioMelody.CalificacionGridTda.InventarioEstilo = Convert.ToString(tot17);
                }

            }
        }

        private void rowStyleColores()
        {
            string vez = "si";
            int Regs = 0;

            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                dgvGridView.Select();

                DataGridViewCheckBoxCell chk1 = (DataGridViewCheckBoxCell)rowp.Cells["CHKCOMP"];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(rowp.Cells["MDYCBC"].Value) == "1") { chk1.Value = 1; }

                DataGridViewCheckBoxCell chk2 = (DataGridViewCheckBoxCell)rowp.Cells["CHKCONTR"];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(rowp.Cells["MDYCBT"].Value) == "1") { chk2.Value = 1; dgvGridView.BeginEdit(false); }

                // PreCalificado
                if (Convert.ToString(rowp.Cells["MDYTPO"].Value) == "PreCalificación") { rowp.Cells["MDYTPO"].Style.ForeColor = Color.Red; }
                // Calificado
                if (Convert.ToString(rowp.Cells["MDYTPO"].Value) == "Calificación") { rowp.Cells["MDYTPO"].Style.ForeColor = Color.Blue; }
                // Pagar
                if (Convert.ToString(rowp.Cells["MDYCDP"].Value) == "P a g a r") { rowp.Cells["MDYCDP"].Style.BackColor = Color.LightGreen; }
                // 10%
                if (Convert.ToString(rowp.Cells["MDYCDP"].Value) == "10%") { rowp.Cells["MDYCDP"].Style.BackColor = Color.Yellow; }
                // 15%
                if (Convert.ToString(rowp.Cells["MDYCDP"].Value) == "15%") { rowp.Cells["MDYCDP"].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(rowp.Cells["MDYCDP"].Value) == "20%") { rowp.Cells["MDYCDP"].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(rowp.Cells["MDYCDP"].Value) == "25%") { rowp.Cells["MDYCDP"].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(rowp.Cells["MDYCDP"].Value) == "30%") { rowp.Cells["MDYCDP"].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(rowp.Cells["MDYCDP"].Value) == "35%") { rowp.Cells["MDYCDP"].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(rowp.Cells["MDYCDP"].Value) == "40%") { rowp.Cells["MDYCDP"].Style.BackColor = Color.LightSalmon; }
                //Dev o 50%
                if (Convert.ToString(rowp.Cells["MDYCDP"].Value) == "50%") { rowp.Cells["MDYCDP"].Style.BackColor = Color.Red; rowp.Cells["MDYCDP"].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(rowp.Cells["MDYCDP"].Value) == "50%") { rowp.Cells["MDYCDP"].Style.BackColor = Color.Red; rowp.Cells["MDYCDP"].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(rowp.Cells["MDYCDP"].Value) == "Devolución") { rowp.Cells["MDYCDP"].Style.BackColor = Color.Red; rowp.Cells["MDYCDP"].Style.ForeColor = Color.White; }

                try
                {
                    if (
                        (Convert.ToInt16(rowp.Cells["MDYTST"].Value) > 0) &&
                        (Convert.ToInt16(rowp.Cells["MDYOHP"].Value) == 0) &&
                        (Convert.ToInt16(rowp.Cells["MDYVPZ"].Value) == 0)
                       )
                    {
                        rowp.Cells["MDYCDP"].Value = "No Aplica";
                        rowp.Cells["MDYCDP"].Style.BackColor = Color.Cyan;
                    }
                }
                catch { }

                Regs += 1;
                if (vez == "Si")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }

            }
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        protected void BindMarca()
        {
            //try
            //{
            //    cbMarca.DataSource = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();
            //    cbMarca.DisplayMember = "Value";
            //    cbMarca.ValueMember = "Key";
            //    marca = "30";
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
        }

        protected void BindCompradores()
        {
            //try
            //{
            //    cbComprador.DataSource = MmsWin.Negocio.Catalogos.Compradores.GetInstance().ObtenCompradors().ToList();
            //    cbComprador.DisplayMember = "Value";
            //    cbComprador.ValueMember = "Key";
            //    comprador = "999";
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
        } 

        private void CalificacionGridTda_Resize(object sender, EventArgs e)
        {
            dgvGridView.Width = this.Width - dgvOffset;
            dgvGridView.Height = this.Height - dgvOffset2;
        }

        private void dgvGridView_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                BinData();
                dgvGridView.Focus();
                dgvGridView.Select();
            }
        }

        private void dgvGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cargaVariables();
        }

        private void dgvGridView_SelectionChanged(object sender, EventArgs e)
        {
            cargaVariables();
        }

        private void cargaVariables() 
        {
            try
            {
                MmsWin.Front.Utilerias.Fotos.numPrv  = this.dgvGridView.CurrentRow.Cells["MDYPRV"].Value.ToString();
                MmsWin.Front.Utilerias.Fotos.numSty  = this.dgvGridView.CurrentRow.Cells["MDYSTY"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpPrv = this.dgvGridView.CurrentRow.Cells["MDYPRV"].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpSty = this.dgvGridView.CurrentRow.Cells["MDYSTY"].Value.ToString();

                MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridMarca         = this.dgvGridView.CurrentRow.Cells["MDYMAR"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTienda        = this.dgvGridView.CurrentRow.Cells["MDYTDA"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridFechaCalifica = this.dgvGridView.CurrentRow.Cells["MDYFCH"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTipoCalifica  = this.dgvGridView.CurrentRow.Cells["MDYTPO"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTemporada     = this.dgvGridView.CurrentRow.Cells["MDYTMP"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTabla         = this.dgvGridView.CurrentRow.Cells["MDYTAB"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridProveedor     = this.dgvGridView.CurrentRow.Cells["MDYPRV"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridEstilo        = this.dgvGridView.CurrentRow.Cells["MDYSTY"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridOrden         = this.dgvGridView.CurrentRow.Cells["MDYORD"].Value.ToString();
            }
            catch { };

             string fmtFch = string.Empty;
             string fmtHor = string.Empty;

            try
            {
                //fmtFch = this.dgvGridView.CurrentRow.Cells[5].Value.ToString();
                //MmsWin.Front.ConvenioMelody.CalificacionGridTda.corrFecha = "20" + fmtFch.Substring(0, 2) + "-" + fmtFch.Substring(2, 2) + "-" + fmtFch.Substring(4, 2);

                //fmtHor = this.dgvGridView.CurrentRow.Cells[6].Value.ToString();
                //MmsWin.Front.ConvenioMelody.CalificacionGridTda.corrHora = fmtHor.Substring(0, 2) + ":" + fmtHor.Substring(2, 2) + ":" + fmtHor.Substring(4, 2);
            }

            catch { };

            try
            {
                string validaContraloria = this.dgvGridView.CurrentRow.Cells["MDYCBT"].Value.ToString();
                if (validaContraloria == "1")
                {
                    this.dgvGridView.CurrentRow.Cells["CHKCOMP"].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells["MDYOBC"].ReadOnly  = true;
                    this.dgvGridView.CurrentRow.Cells["MDYOBT"].ReadOnly  = true;
                }
                else
                {
                    this.dgvGridView.CurrentRow.Cells["CHKCOMP"].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells["MDYOBC"].ReadOnly  = false;
                    this.dgvGridView.CurrentRow.Cells["MDYOBT"].ReadOnly  = false;
                }
            }
            catch { };
        }

        private void dgvGridView_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                SendKeys.Send("{UP}");
                SendKeys.Flush();
            }
        }

        //private void dgvGridView_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        //{
        //    if (e.RowIndex == -1 && e.ColumnIndex >= 0)
        //    {
        //        DataGridView dgvObj = (DataGridView)sender;
        //        String col = dgvObj.Columns[e.ColumnIndex].Name.ToLower();
        //        //if (col == "nombre" || col == "otro2")
        //        //{
        //            e.PaintBackground(e.CellBounds, true);
        //            e.Graphics.TranslateTransform(e.CellBounds.Left, e.CellBounds.Bottom);
        //            e.Graphics.RotateTransform(270);
        //            e.Graphics.DrawString(e.FormattedValue.ToString(), e.CellStyle.Font, Brushes.Black, 1, 2);
        //            e.Graphics.ResetTransform();
        //            e.Handled = true;
        //        //}
        //    }
        //}

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            marca = " ";
            ComboBox cmbMarca = (ComboBox)sender;
            marca = cmbMarca.SelectedValue.ToString();
            BinData();
        }

        private void tbDesde_Click(object sender, EventArgs e)
        {
            mcC1.Visible = true;
            mcC1.Focus();
        }

        private void tbHasta_Click(object sender, EventArgs e)
        {
            mcC2.Visible = true;
            mcC2.Focus();
        }

        private void mcC1_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbDesde.Text = mcC1.SelectionEnd.ToShortDateString();
            FechaCal = tbDesde.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchDeN = long.Parse(FechaFmt.ToString());
            FchDe = FechaFmt.ToString();

            mcC1.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbDesde.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    BinData();
                }
            }
        }

        private void mcC2_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbHasta.Text = mcC2.SelectionEnd.ToShortDateString();
            FechaCal = tbHasta.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchHasN = long.Parse(FechaFmt.ToString());
            FchHas = FechaFmt.ToString();

            mcC2.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbHasta.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    BinData();
                }
            }
        }

        private void tbTipoCalificacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbTipoCalificacion.Focus();
            }
        }

        private void tbFchCalificacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbFchCalificacion.Focus();
            }
        }

        private void tbProveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbProveedor.Focus();
            }
        }

        private void tbNombre_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbNombre.Focus();
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbEstilo.Focus();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbDescripcion.Focus();
            }
        }

        private void dgvGridView_Sorted(object sender, EventArgs e)
        {
          //  rowStyle();
          rowStyleColores();
        }

        private void cbComprador_SelectedValueChanged(object sender, EventArgs e)
        {
            comprador = " ";
            nr = 0;
            ComboBox cmbComprador = (ComboBox)sender;
            comprador = cmbComprador.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpComprador = cmbComprador.SelectedValue.ToString();

            BinData();
        }

        private void mcC1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcC1.Visible = false;
            }
        }

        private void mcC2_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcC2.Visible = false;
            }
        }

        private void fotoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MuestraFoto();
        }

        private void MuestraFoto()
        {
            try
            {
                Fotos i = new Fotos();
                i.Show();
            }
            catch { }
            finally { }
        }

        private void dgvGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvGridView.Select();
            dgvGridView.Focus();
            Kardex();
        }

        private void Kardex()
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Kardex").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del Kardex ya esta abierta");
                    }
                    else
                    {
                        Kardex i = new Kardex();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void tbTabla_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbTipoCalificacion.Focus();
            }
        }

        private void tbTemporada_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbTipoCalificacion.Focus();
            }
        }

        private void EliminacheckBox()
        {
            try
            {
                dgvGridView.Columns.Remove("CHKCOMP");
                dgvGridView.Columns.Remove("CHKCONTR");
            }
            catch { }
        }

        private void CreaCheckBox()
        {
            DataGridViewCheckBoxColumn Compras = new DataGridViewCheckBoxColumn();

            dgvGridView.Columns.Add(Compras);
            dgvGridView.Columns[89].Name = "CHKCOMP";
            dgvGridView.Columns[89].HeaderText = "Revisado Comprador";
            dgvGridView.Columns[89].Width = 70;
            dgvGridView.Columns[89].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
            dgvGridView.Columns[89].HeaderCell.Style.ForeColor = Color.White;


            DataGridViewCheckBoxColumn Contraloria = new DataGridViewCheckBoxColumn();

            dgvGridView.Columns.Add(Contraloria);
            dgvGridView.Columns[90].Name = "CHKCONTR";
            dgvGridView.Columns[90].HeaderText = "Revisado Contraloria";
            dgvGridView.Columns[90].Width = 68;
            dgvGridView.Columns[90].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
            dgvGridView.Columns[90].HeaderCell.Style.ForeColor = Color.White;
        }

        private void dgvGridView_CellParsing(object sender, DataGridViewCellParsingEventArgs e)
        {
            int Row = e.RowIndex;
            int Col = e.ColumnIndex;
            string campo         = string.Empty;
            string checkBox      = string.Empty;
            string observaciones = string.Empty;
            string usuario       = string.Empty;
            string fechaUser     = string.Empty;
            string horaUser      = string.Empty;

            string marca     = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridMarca         ;
            string tienda    = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTienda        ;
            string fecha     = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridFechaCalifica ;
            string tipo      = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTipoCalifica  ;
            string temporada = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTemporada     ;
            string tabla     = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTabla         ;
            string proveedor = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridProveedor     ;
            string estilo    = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridEstilo        ;
            string orden     = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridOrden         ;

            DateTime hoy = DateTime.Now;

            fechaUser = hoy.Date.ToString("yyMMdd");
            horaUser = DateTime.Now.ToString("HHmmss");
            usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;

            campo = this.dgvGridView.Rows[Row].Cells[Col].OwningColumn.Name;
            if (campo == "CHKCOMP" || campo == "MDYOBC")
            {
                if (campo == "MDYOBC")
                {
                    observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBC"].Value.ToString();
                    observaciones = Convert.ToString(e.Value);
                }
                if (campo == "CHKCOMP")
                {
                    string chk = Convert.ToString(e.Value);
                    if (chk == "False")
                    {
                        checkBox = "0";
                        this.dgvGridView.CurrentRow.Cells["MDYCBC"].Value = "0";
                        observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBC"].Value.ToString();
                    }
                    if (chk == "True")
                    {
                        checkBox = "1";
                        this.dgvGridView.CurrentRow.Cells["MDYCBC"].Value = "1";
                        observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBC"].Value.ToString();
                    }
                }
                else
                {
                    checkBox = this.dgvGridView.CurrentRow.Cells["MDYCBC"].Value.ToString();
                }
                MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateCheckBoxComprasTda(marca, fecha, tipo, temporada, tabla, tienda, proveedor, estilo,
                                                                                        orden, checkBox, observaciones, usuario, fechaUser, horaUser);
            }
            if (campo == "CHKCONTR" || campo == "MDYOBT")
            {
                if (campo == "MDYOBT")
                {
                    observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBT"].Value.ToString();
                    observaciones = Convert.ToString(e.Value);
                }
                if (campo == "CHKCONTR")
                {
                    string chk = Convert.ToString(e.Value);
                    if (chk == "False")
                    {
                        checkBox = "0";
                        this.dgvGridView.CurrentRow.Cells["MDYCBT"].Value = "0";
                        observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBT"].Value.ToString();
                    }
                    if (chk == "True")
                    {
                        checkBox = "1";
                        this.dgvGridView.CurrentRow.Cells["MDYCBT"].Value = "1";
                        observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBT"].Value.ToString();
                    }
                }
                else
                {
                    checkBox = this.dgvGridView.CurrentRow.Cells["MDYCBT"].Value.ToString();
                }
                MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateCheckBoxContraloriaTda(marca, fecha, tipo, temporada, tabla, tienda, proveedor, estilo,
                                                                                        orden, checkBox, observaciones, usuario, fechaUser, horaUser);
            }
        }

        private void rebajaDiferenciadaTlSMI_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "NotaDiferenciada").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La Ventana ya esta abierta...");
                    }
                    else
                    {
                        string FechaBon = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
                        if (FechaBon != null)
                        {
                            string calificaion = MmsWin.Front.ConvenioMelody.CalificacionGrid.gridCalificacion;
                            string convMarcaNo = MmsWin.Front.ConvenioMelody.CalificacionGrid.gridMarca;

                            string FechaBinificacion = FechaBon.Substring(8, 2) + FechaBon.Substring(3, 2) + FechaBon.Substring(0, 2);
                            string FechaAbierta = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenMarcaConfiguracion1(convMarcaNo);
                            if (FechaBinificacion == FechaAbierta)
                            {
                                MessageBox.Show("La nota de crédito se va a concentrar en la fecha :" + FechaBon);
                                RecuperaMovimientosDiferenciados();
                                NotaDiferenciada i = new NotaDiferenciada();
                                i.Show();
                            }
                            else
                            {
                                MessageBox.Show("La fecha " + FechaBon + " No esta abierta para captura de Notas de Credito");
                            }
                        }
                        else
                        {
                            MessageBox.Show("La ventana de Calificacion no esta abierta...");
                        }
                    }
                }
            }
            catch { }
            finally { }
        }

        private void RecuperaMovimientosDiferenciados()
        {
            System.Data.DataTable dtDiferenciados = new System.Data.DataTable("Diferenciados");
            dtDiferenciados.Columns.Add("ParTipo", typeof(String));
            dtDiferenciados.Columns.Add("ParTemporada", typeof(String));
            dtDiferenciados.Columns.Add("ParTienda", typeof(String));
            dtDiferenciados.Columns.Add("ParInventario", typeof(String));
            dtDiferenciados.Columns.Add("ParProveedor", typeof(String));
            dtDiferenciados.Columns.Add("ParEstilo", typeof(String));

            DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                DataRow workRow = dtDiferenciados.NewRow();
                workRow["ParTipo"]       = item.Cells["MDYTPO"].Value.ToString();
                workRow["ParTemporada"]  = item.Cells["MDYTMP"].Value.ToString();
                workRow["ParTienda"]     = item.Cells["MDYTDA"].Value.ToString();
                workRow["ParInventario"] = item.Cells["INVENTARIO"].Value.ToString();
                workRow["ParProveedor"]  = item.Cells["MDYPRV"].Value.ToString();
                workRow["ParEstilo"]     = item.Cells["MDYSTY"].Value.ToString();

                dtDiferenciados.Rows.Add(workRow);
            }

            int regs = dtDiferenciados.Rows.Count;
            if (regs == 0)
            {
                DataRow workRow = dtDiferenciados.NewRow();
                workRow["ParTipo"]       = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTipoCalifica;
                workRow["ParTemporada"]  = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTemporada;
                workRow["ParTienda"]     = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTienda;
                workRow["ParInventario"] = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTienda;
                workRow["ParProveedor"]  = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTienda;
                workRow["ParEstilo"]     = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTienda;

                dtDiferenciados.Rows.Add(workRow);
            }


            MmsWin.Front.ConvenioMelody.NotaDiferenciada.dtDiferenciados = dtDiferenciados;
        }

        private void btExcel_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            System.Data.DataTable dtDowns = (System.Data.DataTable)(dgvGridView.DataSource);
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            int nc = dgvGridView.Columns.Count;

            for (int ii = 1; ii <= nc; ii++)
            {

                xlWorkSheet.Cells[1, ii] = dgvGridView.Columns[ii - 1].HeaderText;

            }

            System.Data.DataTable dtConvenio = (System.Data.DataTable)(dgvGridView.DataSource);
            int nr = dgvGridView.RowCount;
            this.pgbProg.Visible = true;

            pgbProg.Maximum = nr;
            pgbProg.Value = 0;
            int r = 0;
            int rt = 3;
            foreach (DataRow row in dtConvenio.Rows)
            {
                var gsArray = new[] 
                {         
                    row["MDYMAR"],  // 01
                    row["MDYTDA"],  // 02 //--
                    row["MDYTDD"],  // 03 //--
                    row["MDYTMP"],  // 04
                    row["MDYTAB"],  // 05
                    row["MDYTPO"],  // 06
                    row["MDYFCH"],  // 07
                    row["MDYPRV"],  // 08
                    row["MDYPRVD"], // 09
                    row["MDYSTY"],  // 10
                    row["MDYSTYD"], // 11
                    row["MDYCOM"],  // 12
                    row["MDYCMP"],  // 13
                    row["MDYDEP"],  // 14
                    row["MDYSDP"],  // 15
                    row["MDYCLS"],  // 16
                    row["MDYSCL"],  // 17
                    row["MDYDEPD"], // 18
                    row["MDYSDPD"], // 19
                    row["MDYCLSD"], // 20
                    row["MDYSCLD"], // 21

                    row["MDYORD"],  // 22
                    row["MDYFRB"],  // 23
                    row["MDYCRB"],  // 24
                    row["MDYVPZ"],  // 25 //--
                    row["MDYPVT"],  // 26 //--

                    row["MDYCDP"],  // 27
                    row["MDYCOR"],  // 28
                    row["MDYCFN"],  // 29
                    
                    row["MDYRTB"],  // 30 
                    row["MDYRT2"],  // 31 
                    row["MDYRT3"],  // 32 
                    row["MDYRT4"],  // 33 

                    row["MDYOHP"],  // 34 //--
                    row["MDYTST"],  // 35 //--
                    row["MDYONO"],  // 36 //--
                    row["MDYPDI"],  // 37

                    row["MDYDDV"],  // 38

                    row["MDYCTT"],  // 39
                    row["MDYPZA"],  // 40
                    row["MDYCSB"],  // 41                    
                    
                    row["MDYSM01"], // 42
                    row["MDYSM02"], // 43
                    row["MDYSM03"], // 44
                    row["MDYSM04"], // 45
                    row["MDYSM05"], // 46
                    row["MDYSM06"], // 47
                    row["MDYSM07"], // 48
                    row["MDYSM08"], // 49
                    row["MDYSM09"], // 50
                    row["MDYSM10"], // 51

                    row["MDYDPA"],  // 52
                    row["MDYCSTI"], // 53
                    row["MDYPREI"], // 54
                    row["MDYMRGI"], // 55
                    row["MDYCST"],  // 56
                    row["MDYPRC"],  // 57
                    row["MDYMRG"],  // 58
                    row["SLTSM01"], // 59 
                    row["SLTSM02"], // 60
                    row["SLTSM03"], // 61
                    row["SLTSM04"], // 62
                    row["SLTSM05"], // 63 
                    row["SLTSM06"], // 64
                    row["SLTSM07"], // 65
                    row["SLTSM08"], // 66
                    row["SLTSM09"], // 67
                    row["SLTSM10"], // 68 

                    row["MDYBDG"],  // 69

                    row["MDYOBC"],  // 70
                    row["MDYCBC"],  // 71
                    row["MDYUCP"],  // 72
                    row["MDYFCP"],  // 73
                    row["MDYHCP"],  // 74 

                    row["MDYOBT"],  // 75
                    row["MDYCBT"],  // 76
                    row["MDYUCT"],  // 77
                    row["MDYFCT"],  // 78
                    row["MDYHCT"],  // 79 
                
                    row["MDYUAL"],  // 80
                    row["MDYFAL"],  // 81 
                    row["MDYHAL"],  // 82
                    row["MDYUCA"],  // 83
                    row["MDYFCA"],  // 84
                    row["MDYHCA"],  // 85 
                    row["MDYMTX"],  // 86
                    row["MDYCLP"],  // 87 
                    row["MDYCLA"],   // 88 
                    row["INVENTARIO"]   // 89 

                };

                Range rng = xlWorkSheet.get_Range("A" + rt, "CK" + rt);
                rng.Value = gsArray;

                pgbProg.Value += 1;

                this.Text = "Convenio / " + " " + (r += 1).ToString() + " Registro(s)";

                // Pagar
                if (row["MDYCDP"].ToString() == "P a g a r") { xlWorkSheet.Cells[rt, 27].Cells.Interior.Color = Color.LightGreen; xlWorkSheet.Cells[rt, 27].Cells.Font.Color = Color.Black; }
                // 15%
                if (row["MDYCDP"].ToString() == "15%") { xlWorkSheet.Cells[rt, 27].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 27].Cells.Font.Color = Color.Black; }
                // 20% 
                if (row["MDYCDP"].ToString() == "20%") { xlWorkSheet.Cells[rt, 27].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 27].Cells.Font.Color = Color.Black; }
                // 25%
                if (row["MDYCDP"].ToString() == "25%") { xlWorkSheet.Cells[rt, 27].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 27].Cells.Font.Color = Color.Black; }
                // 30%
                if (row["MDYCDP"].ToString() == "30%") { xlWorkSheet.Cells[rt, 27].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 27].Cells.Font.Color = Color.Black; }
                // 35% 
                if (row["MDYCDP"].ToString() == "35%") { xlWorkSheet.Cells[rt, 27].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 27].Cells.Font.Color = Color.Black; }
                // 40%
                if (row["MDYCDP"].ToString() == "40%") { xlWorkSheet.Cells[rt, 27].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 27].Cells.Font.Color = Color.White; }
                // Dev ó 40%
                if (row["MDYCDP"].ToString() == "40%") { xlWorkSheet.Cells[rt, 27].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 27].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["MDYCDP"].ToString() == "50%") { xlWorkSheet.Cells[rt, 27].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 27].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["MDYCDP"].ToString() == "50%") { xlWorkSheet.Cells[rt, 27].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 27].Cells.Font.Color = Color.White; }
                // Devolucion
                if (row["MDYCDP"].ToString() == "Devolución") { xlWorkSheet.Cells[rt, 27].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 27].Cells.Font.Color = Color.White; }

                // Pagar
                if (row["MDYCOR"].ToString() == "P a g a r") { xlWorkSheet.Cells[rt, 28].Cells.Interior.Color = Color.LightGreen; xlWorkSheet.Cells[rt, 28].Cells.Font.Color = Color.Black; }
                // 15%
                if (row["MDYCOR"].ToString() == "15%") { xlWorkSheet.Cells[rt, 28].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 28].Cells.Font.Color = Color.Black; }
                // 20%
                if (row["MDYCOR"].ToString() == "20%") { xlWorkSheet.Cells[rt, 28].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 28].Cells.Font.Color = Color.Black; }
                // 25%
                if (row["MDYCOR"].ToString() == "25%") { xlWorkSheet.Cells[rt, 28].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 28].Cells.Font.Color = Color.Black; }
                // 30%
                if (row["MDYCOR"].ToString() == "30%") { xlWorkSheet.Cells[rt, 28].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 28].Cells.Font.Color = Color.Black; }
                // 35%
                if (row["MDYCOR"].ToString() == "35%") { xlWorkSheet.Cells[rt, 28].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 28].Cells.Font.Color = Color.Black; }
                // 40%
                if (row["MDYCOR"].ToString() == "40%") { xlWorkSheet.Cells[rt, 28].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 28].Cells.Font.Color = Color.White; }
                // Dev ó 40%
                if (row["MDYCOR"].ToString() == "40%") { xlWorkSheet.Cells[rt, 28].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 28].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["MDYCOR"].ToString() == "50%") { xlWorkSheet.Cells[rt, 28].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 28].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["MDYCOR"].ToString() == "50%") { xlWorkSheet.Cells[rt, 28].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 28].Cells.Font.Color = Color.White; }
                // Devolucion
                if (row["MDYCOR"].ToString() == "Devolución") { xlWorkSheet.Cells[rt, 28].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 28].Cells.Font.Color = Color.White; }


                // Pagar
                if (row["MDYCFN"].ToString() == "P a g a r") { xlWorkSheet.Cells[rt, 29].Cells.Interior.Color = Color.LightGreen; xlWorkSheet.Cells[rt, 29].Cells.Font.Color = Color.Black; }
                // 15%
                if (row["MDYCFN"].ToString() == "15%") { xlWorkSheet.Cells[rt, 29].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 29].Cells.Font.Color = Color.Black; }
                // 20%
                if (row["MDYCFN"].ToString() == "20%") { xlWorkSheet.Cells[rt, 29].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 29].Cells.Font.Color = Color.Black; }
                // 25%
                if (row["MDYCFN"].ToString() == "25%") { xlWorkSheet.Cells[rt, 29].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 29].Cells.Font.Color = Color.Black; }
                // 30%
                if (row["MDYCFN"].ToString() == "30%") { xlWorkSheet.Cells[rt, 29].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 29].Cells.Font.Color = Color.Black; }
                // 35%
                if (row["MDYCFN"].ToString() == "35%") { xlWorkSheet.Cells[rt, 29].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 29].Cells.Font.Color = Color.Black; }
                // 40%
                if (row["MDYCFN"].ToString() == "40%") { xlWorkSheet.Cells[rt, 29].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 29].Cells.Font.Color = Color.Black; }
                // Dev ó 40%
                if (row["MDYCFN"].ToString() == "40%") { xlWorkSheet.Cells[rt, 29].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 29].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["MDYCFN"].ToString() == "50%") { xlWorkSheet.Cells[rt, 29].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 29].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["MDYCFN"].ToString() == "50%") { xlWorkSheet.Cells[rt, 29].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 29].Cells.Font.Color = Color.White; }
                // Devolucion
                if (row["MDYCFN"].ToString() == "Devolución") { xlWorkSheet.Cells[rt, 29].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 29].Cells.Font.Color = Color.White; }
                rt++;
            }
            xlWorkSheet.Columns[1].ColumnWidth = 2;
            xlWorkSheet.Columns[2].ColumnWidth = 2;
            xlWorkSheet.Columns[3].ColumnWidth = 25;
            xlWorkSheet.Columns[4].ColumnWidth = 2;
            xlWorkSheet.Columns[5].ColumnWidth = 2;
            xlWorkSheet.Columns[6].ColumnWidth = 2;
            xlWorkSheet.Columns[7].ColumnWidth = 2;
            xlWorkSheet.Columns[8].ColumnWidth = 2;
            xlWorkSheet.Columns[9].ColumnWidth = 25;
            xlWorkSheet.Columns[10].ColumnWidth = 2;
            xlWorkSheet.Columns[11].ColumnWidth = 25;
            xlWorkSheet.Columns[12].ColumnWidth = 2;
            xlWorkSheet.Columns[13].ColumnWidth = 20;
            xlWorkSheet.Columns[14].ColumnWidth = 2;
            xlWorkSheet.Columns[15].ColumnWidth = 2;
            xlWorkSheet.Columns[16].ColumnWidth = 2;
            xlWorkSheet.Columns[17].ColumnWidth = 2;
            xlWorkSheet.Columns[18].ColumnWidth = 21;
            xlWorkSheet.Columns[19].ColumnWidth = 21;
            xlWorkSheet.Columns[20].ColumnWidth = 21;
            xlWorkSheet.Columns[21].ColumnWidth = 21;
            xlWorkSheet.Columns[22].ColumnWidth = 4;
            xlWorkSheet.Columns[23].ColumnWidth = 4;
            xlWorkSheet.Columns[24].ColumnWidth = 4;
            xlWorkSheet.Columns[25].ColumnWidth = 4;
            xlWorkSheet.Columns[26].ColumnWidth = 4;
            xlWorkSheet.Columns[27].ColumnWidth = 4;
            xlWorkSheet.Columns[28].ColumnWidth = 4;
            xlWorkSheet.Columns[29].ColumnWidth = 4;
            xlWorkSheet.Columns[30].ColumnWidth = 4;
            xlWorkSheet.Columns[31].ColumnWidth = 4;
            xlWorkSheet.Columns[32].ColumnWidth = 4;
            xlWorkSheet.Columns[33].ColumnWidth = 4;
            xlWorkSheet.Columns[34].ColumnWidth = 4;
            xlWorkSheet.Columns[35].ColumnWidth = 4;
            xlWorkSheet.Columns[36].ColumnWidth = 4;
            xlWorkSheet.Columns[37].ColumnWidth = 4;
            xlWorkSheet.Columns[38].ColumnWidth = 4;
            xlWorkSheet.Columns[39].ColumnWidth = 4;
            xlWorkSheet.Columns[40].ColumnWidth = 4;
            xlWorkSheet.Columns[41].ColumnWidth = 4;
            xlWorkSheet.Columns[42].ColumnWidth = 4;
            xlWorkSheet.Columns[43].ColumnWidth = 4;
            xlWorkSheet.Columns[44].ColumnWidth = 4;
            xlWorkSheet.Columns[45].ColumnWidth = 4;
            xlWorkSheet.Columns[46].ColumnWidth = 4;
            xlWorkSheet.Columns[47].ColumnWidth = 4;
            xlWorkSheet.Columns[48].ColumnWidth = 4;
            xlWorkSheet.Columns[49].ColumnWidth = 4;
            xlWorkSheet.Columns[50].ColumnWidth = 4;
            xlWorkSheet.Columns[51].ColumnWidth = 4;
            xlWorkSheet.Columns[52].ColumnWidth = 4;
            xlWorkSheet.Columns[53].ColumnWidth = 4;
            xlWorkSheet.Columns[54].ColumnWidth = 4;
            xlWorkSheet.Columns[55].ColumnWidth = 4;
            xlWorkSheet.Columns[56].ColumnWidth = 4;
            xlWorkSheet.Columns[57].ColumnWidth = 4;
            xlWorkSheet.Columns[58].ColumnWidth = 4;
            xlWorkSheet.Columns[60].ColumnWidth = 4;
            xlWorkSheet.Columns[61].ColumnWidth = 4;
            xlWorkSheet.Columns[62].ColumnWidth = 4;
            xlWorkSheet.Columns[63].ColumnWidth = 4;
            xlWorkSheet.Columns[64].ColumnWidth = 4;
            xlWorkSheet.Columns[65].ColumnWidth = 4;
            xlWorkSheet.Columns[66].ColumnWidth = 4;
            xlWorkSheet.Columns[67].ColumnWidth = 4;
            xlWorkSheet.Columns[68].ColumnWidth = 4;
            xlWorkSheet.Columns[69].ColumnWidth = 4;
            xlWorkSheet.Columns[70].ColumnWidth = 50;
            xlWorkSheet.Columns[71].ColumnWidth = 4;
            xlWorkSheet.Columns[72].ColumnWidth = 4;
            xlWorkSheet.Columns[73].ColumnWidth = 4;
            xlWorkSheet.Columns[74].ColumnWidth = 4;
            xlWorkSheet.Columns[75].ColumnWidth = 50;
            xlWorkSheet.Columns[76].ColumnWidth = 4;
            xlWorkSheet.Columns[77].ColumnWidth = 4;
            xlWorkSheet.Columns[78].ColumnWidth = 4;
            xlWorkSheet.Columns[79].ColumnWidth = 4;
            xlWorkSheet.Columns[80].ColumnWidth = 4;
            xlWorkSheet.Columns[81].ColumnWidth = 4;
            xlWorkSheet.Columns[82].ColumnWidth = 4;

            var Rang0 = xlWorkSheet.get_Range("A1", "C1");
            Rang0.Interior.Color = Color.LightSkyBlue;
            Rang0.Font.Color = Color.White;
            Rang0.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang1 = xlWorkSheet.get_Range("D1", "K1");
            Rang1.Interior.Color = Color.LightCoral;
            Rang1.Font.Color = Color.White;
            Rang1.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang2 = xlWorkSheet.get_Range("L1", "U1");
            Rang2.Interior.Color = Color.LightSlateGray;
            Rang2.Font.Color = Color.White;
            Rang2.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang3 = xlWorkSheet.get_Range("V1", "X1");
            Rang3.Interior.Color = Color.Blue;
            Rang3.Font.Color = Color.White;
            Rang3.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang4 = xlWorkSheet.get_Range("Y1", "Z1");
            Rang4.Interior.Color = Color.Green;
            Rang4.Font.Color = Color.White;
            Rang4.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang5 = xlWorkSheet.get_Range("AA1", "AC1");
            Rang5.Interior.Color = Color.Blue;
            Rang5.Font.Color = Color.White;
            Rang5.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang6 = xlWorkSheet.get_Range("AD1", "AG1");
            Rang6.Interior.Color = Color.FromArgb(255, 255, 192);
            //Rang6.Font.Color = Color.White;
            Rang6.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang7 = xlWorkSheet.get_Range("AH1", "AK1");
            Rang7.Interior.Color = Color.LightCoral;
            Rang7.Font.Color = Color.White;
            Rang7.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang8 = xlWorkSheet.get_Range("AL1", "AL1");
            Rang8.Interior.Color = Color.LightSkyBlue;
            Rang8.Font.Color = Color.White;
            Rang8.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang9 = xlWorkSheet.get_Range("AM1", "AO1");
            Rang9.Interior.Color = Color.LightSlateGray;
            Rang9.Font.Color = Color.White;
            Rang9.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang10 = xlWorkSheet.get_Range("AP1", "AY1");
            Rang10.Interior.Color = Color.LightSkyBlue;
            Rang10.Font.Color = Color.White;
            Rang10.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang11 = xlWorkSheet.get_Range("BA1", "BC1");
            Rang11.Interior.Color = Color.LightSeaGreen;
            Rang11.Font.Color = Color.White;
            Rang11.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang12 = xlWorkSheet.get_Range("BD1", "BF1");
            Rang12.Interior.Color = Color.LightSlateGray;
            Rang12.Font.Color = Color.White;
            Rang12.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang12A = xlWorkSheet.get_Range("BG1", "BP1");
            Rang12A.Interior.Color = Color.LightSeaGreen;
            Rang12A.Font.Color = Color.White;
            Rang12A.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang13 = xlWorkSheet.get_Range("BR1", "BV1");
            Rang13.Interior.Color = Color.FromArgb(0, 192, 0);
            Rang13.Font.Color = Color.White;
            Rang13.Borders.LineStyle = BorderStyle.FixedSingle;

            var Rang14 = xlWorkSheet.get_Range("BW1", "CA1");
            Rang14.WrapText = true;
            Rang14.Font.Bold = true;
            Rang14.Interior.Color = Color.FromArgb(0, 0, 192);
            Rang14.Font.Color = Color.White;
            Rang14.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang14.Font.Underline = true;
            Rang14.HorizontalAlignment = HorizontalAlignment.Center;

            var Rang15 = xlWorkSheet.get_Range("CB1", "CD1");
            Rang15.WrapText = true;
            Rang15.Font.Bold = true;
            Rang15.Interior.Color = Color.LightSlateGray;
            Rang15.Font.Color = Color.White;
            Rang15.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang15.Font.Underline = true;
            Rang15.HorizontalAlignment = HorizontalAlignment.Center;

            var Rang16 = xlWorkSheet.get_Range("CE1", "CG1");
            Rang16.WrapText = true;
            Rang16.Font.Bold = true;
            Rang16.Interior.Color = Color.LightSkyBlue;
            Rang16.Font.Color = Color.White;
            Rang16.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang16.Font.Underline = true;
            Rang16.HorizontalAlignment = HorizontalAlignment.Center;

            var Rang17 = xlWorkSheet.get_Range("CH1", "CJ1");
            Rang17.WrapText = true;
            Rang17.Font.Bold = true;
            Rang17.Interior.Color = Color.LightCoral;
            Rang17.Font.Color = Color.White;
            Rang17.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang17.Font.Underline = true;
            Rang17.HorizontalAlignment = HorizontalAlignment.Center;

            var Rang18 = xlWorkSheet.get_Range("CK1", "CK1");
            Rang18.WrapText = true;
            Rang18.Font.Bold = true;
            Rang18.Interior.Color = Color.LightSlateGray;
            Rang18.Font.Color = Color.White;
            Rang18.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang18.Font.Underline = true;
            Rang18.HorizontalAlignment = HorizontalAlignment.Center;

            //var Rang15 = xlWorkSheet.get_Range("BU1", "BY1");
            //Rang15.WrapText = true;
            //Rang15.Font.Bold = true;
            //Rang15.Interior.Color = Color.FromArgb(0, 0, 192);
            //Rang15.Font.Color = Color.White;
            //Rang15.Borders.LineStyle = BorderStyle.FixedSingle;
            //Rang15.Font.Underline = true;
            //Rang15.HorizontalAlignment = HorizontalAlignment.Center;

            String Rango = "A2" + ":" + "CK" + rt;
            Excel.Range SourceRange = (Excel.Range)xlWorkSheet.get_Range("A2", "CK" + rt);
            FormatAsTable(SourceRange, "Table1", "TableStyleMedium2");

            xlWorkSheet.Rows[2].Hidden = true;

            xlWorkSheet.Columns["A"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["B"].HorizontalAlignment     = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["C"].HorizontalAlignment     = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["D:G"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["H"].HorizontalAlignment     = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["I"].HorizontalAlignment     = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["J"].HorizontalAlignment     = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["K"].HorizontalAlignment     = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["L:M"].HorizontalAlignment   = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["N:Q"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["R:U"].HorizontalAlignment   = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["V:W"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["X:Z"].HorizontalAlignment   = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["AA:AG"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AH:BQ"].HorizontalAlignment = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["BR"].HorizontalAlignment    = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["BS:BV"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["BW"].HorizontalAlignment    = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["BX:CA"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["CB:CD"].HorizontalAlignment = XlHAlign.xlHAlignCenter;

            xlWorkSheet.Columns["G"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["W"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["X"].NumberFormat = "###,###";
            xlWorkSheet.Columns["Y"].NumberFormat = "###,###";
            xlWorkSheet.Columns["Z"].NumberFormat = "##.00";
            xlWorkSheet.Columns["AD:AG"].NumberFormat = "###.00";
            xlWorkSheet.Columns["AH:AK"].NumberFormat = "###,###";
            xlWorkSheet.Columns["AK:AK"].NumberFormat = "###,###.00";
            xlWorkSheet.Columns["AL:AL"].NumberFormat = "###,###";
            xlWorkSheet.Columns["AM:AM"].NumberFormat = "###,###.00";
            xlWorkSheet.Columns["AN:AW"].NumberFormat = "###,###";
            xlWorkSheet.Columns["AY:BN"].NumberFormat = "###.00";
            xlWorkSheet.Columns["BU"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["BV"].NumberFormat = "##-##-##";
            xlWorkSheet.Columns["BZ"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["CA"].NumberFormat = "##-##-##";

            var range = xlWorkSheet.get_Range("A3", "A3");
            range.Select();

            //xlApp.Range["Q"].Select();

            xlApp.Range["A:A"].EntireColumn.Delete();
            xlApp.Range["C:W"].EntireColumn.Delete();
            xlApp.Range["F:K"].EntireColumn.Delete();
            xlApp.Range["I:BH"].EntireColumn.Delete();
            xlApp.Range["J:L"].EntireColumn.Delete();

            string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
            xlApp.ActiveWindow.Zoom = 80;
            xlWorkBook.SaveAs("C:\\Reportes\\Convenio" + Hoy + ".xlsx", Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            string comando = @"C:\\Reportes\\Convenio" + Hoy + ".xlsx";
            ExecuteCommand(comando);

            this.pgbProg.Visible = false;
            this.Cursor = Cursors.Default;
        }

        public void FormatAsTable(Excel.Range SourceRange, string TableName, string TableStyleName)
        {
            SourceRange.Worksheet.ListObjects.Add(XlListObjectSourceType.xlSrcRange,
            SourceRange, System.Type.Missing, XlYesNoGuess.xlYes, System.Type.Missing).Name =
                TableName;
            SourceRange.Select();
            SourceRange.Worksheet.ListObjects[TableName].TableStyle = TableStyleName;
            SourceRange.Worksheet.ListObjects[TableName].ShowAutoFilter = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowHeaders = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowTotals = false;
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        static void ExecuteCommand(string _Command)
        {
            //Indicamos que deseamos inicializar el proceso cmd.exe junto a un comando de arranque. 
            //(/C, le indicamos al proceso cmd que deseamos que cuando termine la tarea asignada se cierre el proceso).
            //Para mas informacion consulte la ayuda de la consola con cmd.exe /? 
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;
            //Inicializa el proceso
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            string result = proc.StandardOutput.ReadToEnd();
        }

        private void btMarcaChk_Click(object sender, EventArgs e)
        {

        }

        private void btQuitaChks_Click(object sender, EventArgs e)
        {

        }

        private void btPoneChks_Click(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
            foreach (DataGridViewRow rowp in Seleccionados)
            {
                if ((Convert.ToString((rowp.Cells[2].Value))) != "Total")
                {
                    dgvGridView.Select();
                    DataGridViewCheckBoxCell chk2 = (DataGridViewCheckBoxCell)rowp.Cells["CHKCOMP"];
                    dgvGridView.BeginEdit(true);
                    chk2.Value = 1;
                    dgvGridView.BeginEdit(false);

                    string checkBox  = "1";
                    string observaciones = string.Empty;
                    string usuario   = string.Empty;
                    string fechaUser = "0";
                    string horaUser  = "0";

                    string marca     = rowp.Cells["MDYMAR"].Value.ToString();
                    string tienda    = rowp.Cells["MDYTDA"].Value.ToString();
                    string fecha     = rowp.Cells["MDYFCH"].Value.ToString();
                    string tipo      = rowp.Cells["MDYTPO"].Value.ToString();
                    string temporada = rowp.Cells["MDYTMP"].Value.ToString();
                    string tabla     = rowp.Cells["MDYTAB"].Value.ToString();
                    string proveedor = rowp.Cells["MDYPRV"].Value.ToString();
                    string estilo    = rowp.Cells["MDYSTY"].Value.ToString();
                    string orden     = rowp.Cells["MDYORD"].Value.ToString();

                    MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateCheckBoxComprasTda(marca, fecha, tipo, temporada, tabla, tienda, proveedor, estilo,
                                                                                        orden, checkBox, observaciones, usuario, fechaUser, horaUser);
                    dgvGridView.Focus();
                    dgvGridView.Select();
                }

            }
        }

        private void btQuitaChk_Click(object sender, EventArgs e)
        {
            DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
            foreach (DataGridViewRow rowp in Seleccionados)
            {

                if ((Convert.ToString((rowp.Cells[2].Value))) != "Total")
                {
                    DataGridViewCheckBoxCell chk2 = (DataGridViewCheckBoxCell)rowp.Cells["CHKCOMP"];
                    dgvGridView.BeginEdit(true);
                    chk2.Value = 0;
                    dgvGridView.BeginEdit(false);

                    string checkBox  = "0";
                    string observaciones = string.Empty;
                    string usuario   = string.Empty;
                    string fechaUser = "0";
                    string horaUser  = "0";

                    string marca     = rowp.Cells["MDYMAR"].Value.ToString();
                    string tienda    = rowp.Cells["MDYTDA"].Value.ToString();
                    string fecha     = rowp.Cells["MDYFCH"].Value.ToString();
                    string tipo      = rowp.Cells["MDYTPO"].Value.ToString();
                    string temporada = rowp.Cells["MDYTMP"].Value.ToString();
                    string tabla     = rowp.Cells["MDYTAB"].Value.ToString();
                    string proveedor = rowp.Cells["MDYPRV"].Value.ToString();
                    string estilo    = rowp.Cells["MDYSTY"].Value.ToString();
                    string orden     = rowp.Cells["MDYORD"].Value.ToString();

                    MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateCheckBoxComprasTda(marca, fecha, tipo, temporada, tabla, tienda, proveedor, estilo,
                                                                                        orden, checkBox, observaciones, usuario, fechaUser, horaUser);
                    dgvGridView.Focus();
                    dgvGridView.Select();
                }

            }
        }

    }
}
