﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class MasivoDiferenciado : Form
    {

        #region Conexion
        public static string srv_Doctos = ConfigurationManager.ConnectionStrings["srvDoctos"].ToString();
        #endregion

        #region Variables
        // variables de la Ventana

        public static string ParFchBon;

        public static string parOrigen;

        public static string parMarca;
        public static string parComprador;
        public static string parCalificacion;
        public static string parTemporada;
        public static string parTipoCalificacion;
        public static string parFchCalificacion;

        public static string parFchInicial;

        public static string parFchDesde;
        public static string parFchHasta;

        public static string parProveedor;
        public static string parNombre;
        public static string parEstilo;
        public static string parDescripcion;

        public static string parCstActual;
        public static string parPrcActual;
        public static string parMrgActual;

        public static string parCstNuevo;
        public static string parPrcNuevo;
        public static string parMrgNuevo;

        public static string parCstFinal;
        public static string parPrcFinal;
        public static string parMrgFinal;

        public static string parPorCal;


        public static string romperForeach = "No";
        public static string siHuboRebaja  = "No";

        #endregion

        public int    marca       { get; set; }
        public string noMarca     { get; set; }
        public string ordenCompra { get; set; }
        public string temporada   { get; set; }
        public string comprador   { get; set; }
        public int    noEvento    { get; set; }

        String FchDe;
        String FchHas;

        Point mousedownpoint = Point.Empty;

        public static DataTable dtDiferenciados { get; set; }

        string ParUser;
        public MasivoDiferenciado()
        {
            InitializeComponent();
        }

        private void Nota_Load(object sender, EventArgs e)
        {
            // Carga Datos del DatagridView
            tbReferencia.Text = "DIFERENCIADOS";

           mtbCosto.Text  = MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parCstActual;
           mtbPrecio.Text = MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parPrcActual;
           mtbMargen.Text = MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parMrgActual;

           mtbCostoNuevo.Text  = MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parCstNuevo;
           mtbPrecioNuevo.Text = MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parPrcNuevo;
           mtbMargenNuevo.Text = MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parMrgNuevo;

           mtbPorc.Text        = MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parPorCal;
            

            //tbFchCal.Text = MmsWin.Front.Utilerias.VarTem.NotaFchRevision;
            //tbFchApl.Text = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
            //tbProvee.Text = MmsWin.Front.Utilerias.VarTem.NotaProveedor;
            //tbNombre.Text = MmsWin.Front.Utilerias.VarTem.NotaNombre;
            //tbEstilo.Text = MmsWin.Front.Utilerias.VarTem.NotaEstilo;
            //tbDescripcion.Text = MmsWin.Front.Utilerias.VarTem.NotaDescripcion;

            tbReferencia.Text = " ";
            tbReferencia.Focus();

            // Seguridad...
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("ConvenioMelody", "Nota", ParUser);
        }

        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }

        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
        }

        private void btnCambiar_Click(object sender, EventArgs e)
        {
            // Habilita nota de Crédito
            tbReferencia.Enabled = false;
            //mtbSubTotal.Enabled = true;
            //mtbSubTotal.Focus();
        }

        #region Calculo
        //private void CalculoSubtotal()
        //{
        //    string ParTipo      = string.Empty;
        //    string ParTemporada = string.Empty;
        //    string ParTienda    = string.Empty;

        //    this.Cursor = Cursors.WaitCursor;
        //    // Recalculo . . . . .mo
        //    System.Data.DataTable dtCalculoNota = null;

        //    //string ParFchBon = tbFchApl.Text;
        //    //ParFchBon = ParFchBon.Substring(8, 2) + ParFchBon.Substring(3, 2) + ParFchBon.Substring(0, 2);
        //    //string ParFchRev = tbFchCal.Text;
        //    //ParFchRev = ParFchRev.Substring(8, 2) + ParFchRev.Substring(3, 2) + ParFchRev.Substring(0, 2);
        //    //string ParProveedor = tbProvee.Text;
        //    //string PartbEstilo  = tbEstilo.Text;
        //    //string ParUsuario   = MmsWin.Front.Utilerias.VarTem.tmpUser;
        //    //string ParNotCal    = tbReferencia.Text;
        //    //string ParSubtot    = mtbSubTotal.Text;
        //    mtbPorc.Text   = mtbPorc.Text.Replace("%", "");
        //    string ParPorc = string.Format("{0:n4}", double.Parse(mtbPorc.Text));
        //    //ParSubtot = ParSubtot.Replace(".", "");
        //    //ParSubtot = ParSubtot.Replace(",", "");
        //    ParPorc   = ParPorc.Replace(".", "");
        //    ParPorc   = ParPorc.Replace(",", "");
        //    string TipMov = "BON";
        //    string TipCal = "NOR";

        //    foreach (DataRow row in dtDiferenciados.Rows)
        //    {
        //        ParTipo      = row["ParTipo"].ToString();
        //        ParTemporada = row["ParTemporada"].ToString();
        //        ParTienda    = row["ParTienda"].ToString();

        //        //dtCalculoNota = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenCalculoNotasDiferenciada(ParFchBon, ParFchRev, ParTipo, ParTemporada, ParTienda, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, TipMov, TipCal, ParPorc);
        //    }
        //    //if (dtCalculoNota.Rows.Count > 0)
        //    //{
        //        //foreach (DataRow row in dtCalculoNota.Rows)
        //        //{
        //            //mtbSubTotal.Text = string.Format("{0:n2}", double.Parse(row["NOTSUB"].ToString()));
        //            //mtbIva.Text      = string.Format("{0:n2}", double.Parse(row["NOTIVA"].ToString()));
        //            //mtbTotal.Text    = string.Format("{0:n2}", double.Parse(row["NOTTOT"].ToString()));

        //            //mtbCosto.Text  = string.Format("{0:n4}", double.Parse(row["NOTCST"].ToString()));
        //            //mtbPrecio.Text = string.Format("{0:n3}", double.Parse(row["NOTPRC"].ToString()));
        //            //mtbMargen.Text = string.Format("{0:n3}", double.Parse(row["NOTMRG"].ToString()));

        //            //mtbCostoNuevo.Text  = string.Format("{0:n4}", double.Parse(row["NOTCST1"].ToString()));
        //            //mtbPrecioNuevo.Text = string.Format("{0:n3}", double.Parse(row["NOTPRC1"].ToString()));
        //            //mtbMargenNuevo.Text = string.Format("{0:n3}", double.Parse(row["NOTMRG1"].ToString()));

        //            //mtbCostoFinal.Text  = string.Format("{0:n4}", double.Parse(row["NOTCST2"].ToString()));
        //            //mtbPrecioFinal.Text = string.Format("{0:n3}", double.Parse(row["NOTPRC2"].ToString()));
        //            //mtbMargenFinal.Text = string.Format("{0:n3}", double.Parse(row["NOTMRG2"].ToString()));

        //            ////mtbNOTONH.Text  = string.Format("{0:n0}", double.Parse(row["NOTONH"].ToString()));
        //            //mtbNOTTAB.Text  = string.Format("{0:n0}", row["NOTTAB"].ToString());
        //            //mtbNOTTABF.Text = string.Format("{0:n0}", row["NOTTABF"].ToString());

        //            //mtbNOTCSTD.Text = string.Format("{0:n4}", double.Parse(row["NOTCSTD"].ToString()));
        //            //mtbNOTPZA1.Text = string.Format("{0:n0}", double.Parse(row["NOTPZA1"].ToString()));
        //            //mtbNOTIMP1.Text = string.Format("{0:n2}", double.Parse(row["NOTIMP1"].ToString()));

        //            //mtbNOTDCF2.Text = string.Format("{0:n4}", double.Parse(row["NOTDCF2"].ToString()));
        //            //mtbNOTIDC2.Text = string.Format("{0:n4}", double.Parse(row["NOTIDC2"].ToString()));
        //            //mtbNOTIMF2.Text = string.Format("{0:n4}", double.Parse(row["NOTIMF2"].ToString()));

        //            //try
        //            //{
        //            //    mtbPorc.Text = string.Format("{0:n4}", double.Parse(row["NOTCAP"].ToString()));
        //            //}
        //            //catch { mtbPorc.Text = "0"; }
        //        //}
        //    //}
        //    this.Cursor = Cursors.Default;
        //    //mtbSubTotal.Enabled = false;
        //}
        #endregion

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            //System.Data.DataTable dtGuardaNota = null;

                string tipo             = string.Empty;
                string temporada        = string.Empty;
                string comprador        = string.Empty;
                string tipoCalificacion = string.Empty;
                string tabla            = string.Empty;
                string fchCalificacion  = string.Empty;
                string proveedor        = string.Empty;
                string estilo           = string.Empty;
                string calificacion     = string.Empty;
                string nombre           = string.Empty;
                string descripcion      = string.Empty;

                comprador = parComprador;
                FchDe     = parFchDesde;
                FchHas    = parFchHasta;
                temporada = parTemporada;
                tipoCalificacion = parTipoCalificacion;
                fchCalificacion  = parFchCalificacion;
                proveedor    = parProveedor;
                nombre       = parNombre;
                estilo       = parEstilo;
                descripcion  = parDescripcion;
                calificacion = parCalificacion;

                dtDiferenciados = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenCalificaionTdaXcalificacion(parMarca, comprador, FchDe, FchHas, temporada, tipoCalificacion, parFchCalificacion, parProveedor, parNombre, parEstilo, parDescripcion, parCalificacion, parOrigen);

                GuardarNota();
        }

        private void GuardarNota()
        {
            string ParTipo      = string.Empty;
            string ParTemporada = string.Empty;
            string ParTienda    = string.Empty;
            string ParFchRev    = string.Empty;
            string ParProveedor = string.Empty;
            string PartbEstilo  = string.Empty;

            string TpoMov = "RBD";
            string TpoCal = "NOR";

                // Recalculo . . . . .
                   System.Data.DataTable dtGuardaNota = null;

                //string ParFchBon = tbFchApl.Text;
                //ParFchBon = ParFchBon.Substring(8, 2) + ParFchBon.Substring(3, 2) + ParFchBon.Substring(0, 2);
                //string ParFchRev = tbFchCal.Text;
                //ParFchRev = ParFchRev.Substring(8, 2) + ParFchRev.Substring(3, 2) + ParFchRev.Substring(0, 2);

                //string ParProveedor = tbProvee.Text;
                //string PartbEstilo = tbEstilo.Text;
                string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                string ParNotCal  = tbReferencia.Text;
                //string ParSubtot = mtbSubTotal.Text;
                string ParSubtot  = string.Empty;
                string ParPorc    = mtbPorc.Text;


                //ParSubtot = ParSubtot.Replace(".", "");
                //ParSubtot = ParSubtot.Replace(",", "");
                ParPorc = ParPorc.Replace(".", "");
                String RutaPdf = MmsWin.Front.Utilerias.VarTem.tmpDestNcPDF;

                foreach (DataRow row1 in dtDiferenciados.Rows)
                {
                    if (row1["MDYTDD"].ToString() != "Total")
                    {
                        ParTipo      = row1["MDYTPO"].ToString();
                        ParTemporada = row1["MDYTMP"].ToString();
                        ParTienda    = row1["MDYTDA"].ToString();
                        ParFchRev    = row1["MDYFCH"].ToString();
                        ParProveedor = row1["MDYPRV"].ToString();
                        PartbEstilo  = row1["MDYSTY"].ToString();

                        string varInd1 = "0";
                        string varInd2 = "0";

                        siHuboRebaja  = "No";
                        dtGuardaNota = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().GuardaNotaDiferenciada(ParFchBon, ParFchRev, ParTipo, ParTemporada, ParTienda, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, ParPorc, varInd1, varInd2, TpoMov, TpoCal, RutaPdf);

                        if (dtGuardaNota.Rows.Count > 0)
                        {
                            foreach (DataRow row in dtGuardaNota.Rows)
                            {

                                varInd1 = row["NOTIN1"].ToString();
                                varInd2 = row["NOTIN2"].ToString();

                                if (varInd1 == "1" && varInd2 == "0")
                                {
                                    siHuboRebaja = "Si";
                                }
                                else
                                {
                                    if (varInd2 == "1")
                                    {
                                        string message = "Ya existe La Rebaja, Haz Click en (Si) para remplazar ";
                                        string caption = "Aviso";
                                        MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                                        DialogResult result;
                                        result = MessageBox.Show(message, caption, buttons);
                                        if (result == System.Windows.Forms.DialogResult.Yes)
                                        {
                                            varInd1 = "2";
                                            varInd2 = "2";
                                            RutaPdf = MmsWin.Front.Utilerias.VarTem.tmpRutaPdf;
                                            MmsWin.Negocio.Utilerias.Utilerias.GetInstance().GuardaNotaDiferenciada(ParFchBon, ParFchRev, ParTipo, ParTemporada, ParTienda, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, ParPorc, varInd1, varInd2, TpoMov, TpoCal, RutaPdf);
                                            MessageBox.Show("Se actualizo la Rebaja exitosamente");
                                            this.Close();
                                        }
                                        else
                                        {
                                            romperForeach = "Si";
                                            break;
                                        }
                                    }
                                }

                            }

                            if (romperForeach == "Si")
                            {
                                break;
                            }
                        }
                    }
                }
                if (siHuboRebaja == "Si")
                {
                    MessageBox.Show("Se guardó la Reabaja exitosamente");
                    this.Close();
                }
        }

        private void mtbSubTotal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                // Habilita nota de Crédito

                //if (mtbSubTotal.Text == "0")
                //{
                //    mtbIva.Text = "0";
                //    mtbTotal.Text = "0";
                //    mtbNOTCSTD.Text = "0";
                //    mtbNOTPZA1.Text = "0";
                //    mtbNOTIMP1.Text = "0";
                //    mtbNOTDCF2.Text = "0";
                //    mtbNOTIDC2.Text = "0";
                //    mtbNOTIMF2.Text = "0";
                //}
                //mtbSubTotal.Enabled = false;
                mtbPorc.Enabled = true;
                mtbPorc.Focus();

                // Recalculo . . . . .

                //        mtbSubTotal.Enabled = false;
                //        mtbNotaCred.Focus();
            }
        }

        private void mtbPorc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (mtbPorc.Text != "  ")
                {
                    //mtbPorc.Text = string.Format("{0:p4}", double.Parse(mtbPorc.Text));

                    mtbPorc.Enabled = false;
                    tbReferencia.Enabled = true;
                    tbReferencia.Focus();


                    if (tbReferencia.Text != " ")
                    {

                        //if (mtbSubTotal.Text != "0")
                        //{
                        //    CalculoSubtotal();
                        //}

                        //if (mtbSubTotal.Text == "0")
                        //{
                            //mtbIva.Text = "0";
                            //mtbTotal.Text = "0";
                            //mtbNOTCSTD.Text = "0";
                            //mtbNOTPZA1.Text = "0";
                            //mtbNOTIMP1.Text = "0";
                            //mtbNOTDCF2.Text = "0";
                            //mtbNOTIDC2.Text = "0";
                            //mtbNOTIMF2.Text = "0";

                            mtbCostoNuevo.Text = mtbCosto.Text;
                            mtbPrecioNuevo.Text = mtbPrecio.Text;
                            mtbMargenNuevo.Text = mtbMargen.Text;

                            mtbCostoFinal.Text = mtbCosto.Text;
                            mtbPrecioFinal.Text = mtbPrecio.Text;
                            mtbMargenFinal.Text = mtbMargen.Text;
                        //}

                    }
                    else
                    {
                        MessageBox.Show("No debe quedar en blanco el número de Nota de Crédito...");
                    }

                }
            }

        }

        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.gbNota.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void Nota_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("ConvenioMelody", "Nota", ParUser);
            }
        }

        private void pbExaminarPDF_Click(object sender, EventArgs e)
        {
            //OpenFileDialog buscar = new OpenFileDialog();
            //if (buscar.ShowDialog() == DialogResult.OK)
            //{
            //    tbFuentePDF.Text = buscar.FileName;
            //    string[] path = buscar.FileName.Split('\\');
            //    int contador = path.Count();
            //    string nombre = path[contador - 1];

            //    string[] nomExt = nombre.Split('.');
            //    contador = nomExt.Count();
            //    string nomSinExt = nomExt[0];
            //    string ext = nomExt[contador - 1];

            //    if (ext == "PDF" || ext == "pdf")
            //    {
            //        string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
            //        string newDest = tbReferencia.Text + "_" +
            //                         tbProvee.Text + "_" +
            //                         tbEstilo.Text + "_" +
            //                         Hoy +
            //                         ".PDF";

            //        string pathDest = @"\\" + srv_Doctos + @"\Notas_Credito_Proveedor\"; 

            //        //string pathDest = @"\\172.16.50.25\Notas_Credito_Proveedor\";
                    
            //        tbDestinoPDF.Text = pathDest + newDest;
            //    }
            //    else
            //    {
            //        MessageBox.Show("Este documento no es tipo PDF");
            //        tbFuentePDF.Text = "";
            //    }
            //}
        }

        private void pbCargarPDF_Click(object sender, EventArgs e)
        {

            //string comando = "copy " + '\u0022' + tbFuentePDF.Text + '\u0022' + ' ' + tbDestinoPDF.Text;


            //string message = "Esta seguro de cargar esta Nota de Crédito";
            //string caption = "Confirmación";
            //MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            //DialogResult result;
            //result = MessageBox.Show(message, caption, buttons);
            //if (result == System.Windows.Forms.DialogResult.Yes)
            //{
            //    MmsWin.Front.Utilerias.VarTem.tmpDestNcPDF = tbDestinoPDF.Text;

            //    String rutaPdf = MmsWin.Front.Utilerias.VarTem.tmpDestNcPDF;
            //    if (rutaPdf != "")
            //    {
            //        tbFuentePDF.BackColor = Color.GreenYellow;
            //        string borra = "del " + rutaPdf;
            //        System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + borra);
            //        procStartInfo.RedirectStandardOutput = true;
            //        procStartInfo.UseShellExecute = false;
            //        procStartInfo.CreateNoWindow = false;
            //        System.Diagnostics.Process proc = new System.Diagnostics.Process();
            //        proc.StartInfo = procStartInfo;
            //        proc.Start();
            //    }
            //    // Copia Archivo PDF
            //    ExecuteCommand(comando);
            //    //tbFuentePDF.BackColor = Color.Green;

            //    //this.Close();

            //}

        }

        static void ExecuteCommand(string _Command)
        {
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            procStartInfo.CreateNoWindow = false;
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            string result = proc.StandardOutput.ReadToEnd();
            if (result == "        1 archivo(s) copiado(s).\r\n")
            {

            }

            MessageBox.Show(result);
        }

        private void tbReferencia_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (tbReferencia.Text != " ")
                {
                    //CalculoSubtotal();
                }
                else
                {
                    MessageBox.Show("No debe quedar en blanco la Referencia...");
                }
            }
        }

        private void MasivoDiferenciado_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void MasivoDiferenciado_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedownpoint.IsEmpty)
                return;
            Form f = sender as Form;
            f.Location = new Point(f.Location.X + (e.X - mousedownpoint.X), f.Location.Y + (e.Y - mousedownpoint.Y));
        }

        private void MasivoDiferenciado_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

    }
}
