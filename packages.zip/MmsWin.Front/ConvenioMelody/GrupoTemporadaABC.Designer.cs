﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class GrupoTemporadaABC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel01 = new System.Windows.Forms.Panel();
            this.lbDescEstilo = new System.Windows.Forms.Label();
            this.tbDescEstilo = new System.Windows.Forms.TextBox();
            this.lbEstilo = new System.Windows.Forms.Label();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.lbNombre = new System.Windows.Forms.Label();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.lbProveedor = new System.Windows.Forms.Label();
            this.tbProveedor = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbDescSC = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbDescCL = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbDescSD = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbDescDP = new System.Windows.Forms.TextBox();
            this.lbSC = new System.Windows.Forms.Label();
            this.tbSC = new System.Windows.Forms.TextBox();
            this.lbCL = new System.Windows.Forms.Label();
            this.tbCL = new System.Windows.Forms.TextBox();
            this.lbSD = new System.Windows.Forms.Label();
            this.tbSD = new System.Windows.Forms.TextBox();
            this.lbDP = new System.Windows.Forms.Label();
            this.tbDP = new System.Windows.Forms.TextBox();
            this.lbDescTmpMms = new System.Windows.Forms.Label();
            this.tbDescMms = new System.Windows.Forms.TextBox();
            this.lbTmpMms = new System.Windows.Forms.Label();
            this.tbTmpMms = new System.Windows.Forms.TextBox();
            this.lbDescTipo = new System.Windows.Forms.Label();
            this.tbDescTipo = new System.Windows.Forms.TextBox();
            this.lbTipo = new System.Windows.Forms.Label();
            this.tbTipo = new System.Windows.Forms.TextBox();
            this.lbUserCambio = new System.Windows.Forms.Label();
            this.lbUserAlta = new System.Windows.Forms.Label();
            this.lbAyudaSts = new System.Windows.Forms.Label();
            this.lbAyudaSecuencia = new System.Windows.Forms.Label();
            this.lbAyudaTabla = new System.Windows.Forms.Label();
            this.lbAyudaMarca = new System.Windows.Forms.Label();
            this.lbMsjSts = new System.Windows.Forms.Label();
            this.lbMsjDescripcion = new System.Windows.Forms.Label();
            this.lbMsjTemporada = new System.Windows.Forms.Label();
            this.lbMsjMarca = new System.Windows.Forms.Label();
            this.lbSecuencia = new System.Windows.Forms.Label();
            this.lbRenglon = new System.Windows.Forms.Label();
            this.lbGpo = new System.Windows.Forms.Label();
            this.lbMarca = new System.Windows.Forms.Label();
            this.btElimiar = new System.Windows.Forms.Button();
            this.btCambio = new System.Windows.Forms.Button();
            this.btAlta = new System.Windows.Forms.Button();
            this.btCancelar = new System.Windows.Forms.Button();
            this.lbHora = new System.Windows.Forms.Label();
            this.lbFecha = new System.Windows.Forms.Label();
            this.lbUsuario = new System.Windows.Forms.Label();
            this.tbHoraCambio = new System.Windows.Forms.TextBox();
            this.tbFechaCambio = new System.Windows.Forms.TextBox();
            this.tbHoraAlta = new System.Windows.Forms.TextBox();
            this.tbFechaAlta = new System.Windows.Forms.TextBox();
            this.tbUserCambio = new System.Windows.Forms.TextBox();
            this.tbUserAlta = new System.Windows.Forms.TextBox();
            this.tbSecuencia = new System.Windows.Forms.TextBox();
            this.tbRenglon = new System.Windows.Forms.TextBox();
            this.tbTemporada = new System.Windows.Forms.TextBox();
            this.tbMarca = new System.Windows.Forms.TextBox();
            this.lbTitulo = new System.Windows.Forms.Label();
            this.panel01.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel01
            // 
            this.panel01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel01.Controls.Add(this.lbDescEstilo);
            this.panel01.Controls.Add(this.tbDescEstilo);
            this.panel01.Controls.Add(this.lbEstilo);
            this.panel01.Controls.Add(this.tbEstilo);
            this.panel01.Controls.Add(this.lbNombre);
            this.panel01.Controls.Add(this.tbNombre);
            this.panel01.Controls.Add(this.lbProveedor);
            this.panel01.Controls.Add(this.tbProveedor);
            this.panel01.Controls.Add(this.label1);
            this.panel01.Controls.Add(this.tbDescSC);
            this.panel01.Controls.Add(this.label2);
            this.panel01.Controls.Add(this.tbDescCL);
            this.panel01.Controls.Add(this.label3);
            this.panel01.Controls.Add(this.tbDescSD);
            this.panel01.Controls.Add(this.label4);
            this.panel01.Controls.Add(this.tbDescDP);
            this.panel01.Controls.Add(this.lbSC);
            this.panel01.Controls.Add(this.tbSC);
            this.panel01.Controls.Add(this.lbCL);
            this.panel01.Controls.Add(this.tbCL);
            this.panel01.Controls.Add(this.lbSD);
            this.panel01.Controls.Add(this.tbSD);
            this.panel01.Controls.Add(this.lbDP);
            this.panel01.Controls.Add(this.tbDP);
            this.panel01.Controls.Add(this.lbDescTmpMms);
            this.panel01.Controls.Add(this.tbDescMms);
            this.panel01.Controls.Add(this.lbTmpMms);
            this.panel01.Controls.Add(this.tbTmpMms);
            this.panel01.Controls.Add(this.lbDescTipo);
            this.panel01.Controls.Add(this.tbDescTipo);
            this.panel01.Controls.Add(this.lbTipo);
            this.panel01.Controls.Add(this.tbTipo);
            this.panel01.Controls.Add(this.lbUserCambio);
            this.panel01.Controls.Add(this.lbUserAlta);
            this.panel01.Controls.Add(this.lbAyudaSts);
            this.panel01.Controls.Add(this.lbAyudaSecuencia);
            this.panel01.Controls.Add(this.lbAyudaTabla);
            this.panel01.Controls.Add(this.lbAyudaMarca);
            this.panel01.Controls.Add(this.lbMsjSts);
            this.panel01.Controls.Add(this.lbMsjDescripcion);
            this.panel01.Controls.Add(this.lbMsjTemporada);
            this.panel01.Controls.Add(this.lbMsjMarca);
            this.panel01.Controls.Add(this.lbSecuencia);
            this.panel01.Controls.Add(this.lbRenglon);
            this.panel01.Controls.Add(this.lbGpo);
            this.panel01.Controls.Add(this.lbMarca);
            this.panel01.Controls.Add(this.btElimiar);
            this.panel01.Controls.Add(this.btCambio);
            this.panel01.Controls.Add(this.btAlta);
            this.panel01.Controls.Add(this.btCancelar);
            this.panel01.Controls.Add(this.lbHora);
            this.panel01.Controls.Add(this.lbFecha);
            this.panel01.Controls.Add(this.lbUsuario);
            this.panel01.Controls.Add(this.tbHoraCambio);
            this.panel01.Controls.Add(this.tbFechaCambio);
            this.panel01.Controls.Add(this.tbHoraAlta);
            this.panel01.Controls.Add(this.tbFechaAlta);
            this.panel01.Controls.Add(this.tbUserCambio);
            this.panel01.Controls.Add(this.tbUserAlta);
            this.panel01.Controls.Add(this.tbSecuencia);
            this.panel01.Controls.Add(this.tbRenglon);
            this.panel01.Controls.Add(this.tbTemporada);
            this.panel01.Controls.Add(this.tbMarca);
            this.panel01.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel01.Location = new System.Drawing.Point(0, 46);
            this.panel01.Name = "panel01";
            this.panel01.Size = new System.Drawing.Size(442, 671);
            this.panel01.TabIndex = 10;
            // 
            // lbDescEstilo
            // 
            this.lbDescEstilo.AutoSize = true;
            this.lbDescEstilo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDescEstilo.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbDescEstilo.Location = new System.Drawing.Point(9, 516);
            this.lbDescEstilo.Name = "lbDescEstilo";
            this.lbDescEstilo.Size = new System.Drawing.Size(74, 13);
            this.lbDescEstilo.TabIndex = 81;
            this.lbDescEstilo.Text = "Descripción";
            // 
            // tbDescEstilo
            // 
            this.tbDescEstilo.Location = new System.Drawing.Point(111, 509);
            this.tbDescEstilo.Name = "tbDescEstilo";
            this.tbDescEstilo.Size = new System.Drawing.Size(143, 20);
            this.tbDescEstilo.TabIndex = 80;
            this.tbDescEstilo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbEstilo
            // 
            this.lbEstilo.AutoSize = true;
            this.lbEstilo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEstilo.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbEstilo.Location = new System.Drawing.Point(9, 490);
            this.lbEstilo.Name = "lbEstilo";
            this.lbEstilo.Size = new System.Drawing.Size(38, 13);
            this.lbEstilo.TabIndex = 79;
            this.lbEstilo.Text = "Estilo";
            // 
            // tbEstilo
            // 
            this.tbEstilo.Location = new System.Drawing.Point(111, 483);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(143, 20);
            this.tbEstilo.TabIndex = 78;
            this.tbEstilo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbNombre
            // 
            this.lbNombre.AutoSize = true;
            this.lbNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNombre.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbNombre.Location = new System.Drawing.Point(9, 464);
            this.lbNombre.Name = "lbNombre";
            this.lbNombre.Size = new System.Drawing.Size(50, 13);
            this.lbNombre.TabIndex = 77;
            this.lbNombre.Text = "Nombre";
            // 
            // tbNombre
            // 
            this.tbNombre.Location = new System.Drawing.Point(111, 457);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(143, 20);
            this.tbNombre.TabIndex = 76;
            this.tbNombre.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbProveedor
            // 
            this.lbProveedor.AutoSize = true;
            this.lbProveedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbProveedor.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbProveedor.Location = new System.Drawing.Point(9, 438);
            this.lbProveedor.Name = "lbProveedor";
            this.lbProveedor.Size = new System.Drawing.Size(65, 13);
            this.lbProveedor.TabIndex = 75;
            this.lbProveedor.Text = "Proveedor";
            // 
            // tbProveedor
            // 
            this.tbProveedor.Location = new System.Drawing.Point(111, 431);
            this.tbProveedor.Name = "tbProveedor";
            this.tbProveedor.Size = new System.Drawing.Size(143, 20);
            this.tbProveedor.TabIndex = 74;
            this.tbProveedor.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(9, 412);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 13);
            this.label1.TabIndex = 73;
            this.label1.Text = "Sub Clase";
            // 
            // tbDescSC
            // 
            this.tbDescSC.Location = new System.Drawing.Point(111, 405);
            this.tbDescSC.Name = "tbDescSC";
            this.tbDescSC.Size = new System.Drawing.Size(143, 20);
            this.tbDescSC.TabIndex = 72;
            this.tbDescSC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label2.Location = new System.Drawing.Point(9, 386);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 71;
            this.label2.Text = "Clase";
            // 
            // tbDescCL
            // 
            this.tbDescCL.Location = new System.Drawing.Point(111, 379);
            this.tbDescCL.Name = "tbDescCL";
            this.tbDescCL.Size = new System.Drawing.Size(143, 20);
            this.tbDescCL.TabIndex = 70;
            this.tbDescCL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label3.Location = new System.Drawing.Point(9, 360);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 69;
            this.label3.Text = "Sub Depto";
            // 
            // tbDescSD
            // 
            this.tbDescSD.Location = new System.Drawing.Point(111, 353);
            this.tbDescSD.Name = "tbDescSD";
            this.tbDescSD.Size = new System.Drawing.Size(143, 20);
            this.tbDescSD.TabIndex = 68;
            this.tbDescSD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label4.Location = new System.Drawing.Point(9, 334);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 67;
            this.label4.Text = "Depto";
            // 
            // tbDescDP
            // 
            this.tbDescDP.Location = new System.Drawing.Point(111, 327);
            this.tbDescDP.Name = "tbDescDP";
            this.tbDescDP.Size = new System.Drawing.Size(143, 20);
            this.tbDescDP.TabIndex = 66;
            this.tbDescDP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbSC
            // 
            this.lbSC.AutoSize = true;
            this.lbSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSC.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbSC.Location = new System.Drawing.Point(9, 308);
            this.lbSC.Name = "lbSC";
            this.lbSC.Size = new System.Drawing.Size(64, 13);
            this.lbSC.TabIndex = 65;
            this.lbSC.Text = "Sub Clase";
            // 
            // tbSC
            // 
            this.tbSC.Location = new System.Drawing.Point(111, 301);
            this.tbSC.Name = "tbSC";
            this.tbSC.Size = new System.Drawing.Size(143, 20);
            this.tbSC.TabIndex = 64;
            this.tbSC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbCL
            // 
            this.lbCL.AutoSize = true;
            this.lbCL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCL.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbCL.Location = new System.Drawing.Point(9, 282);
            this.lbCL.Name = "lbCL";
            this.lbCL.Size = new System.Drawing.Size(38, 13);
            this.lbCL.TabIndex = 63;
            this.lbCL.Text = "Clase";
            // 
            // tbCL
            // 
            this.tbCL.Location = new System.Drawing.Point(111, 275);
            this.tbCL.Name = "tbCL";
            this.tbCL.Size = new System.Drawing.Size(143, 20);
            this.tbCL.TabIndex = 62;
            this.tbCL.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbSD
            // 
            this.lbSD.AutoSize = true;
            this.lbSD.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSD.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbSD.Location = new System.Drawing.Point(9, 256);
            this.lbSD.Name = "lbSD";
            this.lbSD.Size = new System.Drawing.Size(67, 13);
            this.lbSD.TabIndex = 61;
            this.lbSD.Text = "Sub Depto";
            // 
            // tbSD
            // 
            this.tbSD.Location = new System.Drawing.Point(111, 249);
            this.tbSD.Name = "tbSD";
            this.tbSD.Size = new System.Drawing.Size(143, 20);
            this.tbSD.TabIndex = 60;
            this.tbSD.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbDP
            // 
            this.lbDP.AutoSize = true;
            this.lbDP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDP.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbDP.Location = new System.Drawing.Point(9, 230);
            this.lbDP.Name = "lbDP";
            this.lbDP.Size = new System.Drawing.Size(41, 13);
            this.lbDP.TabIndex = 59;
            this.lbDP.Text = "Depto";
            // 
            // tbDP
            // 
            this.tbDP.Location = new System.Drawing.Point(111, 223);
            this.tbDP.Name = "tbDP";
            this.tbDP.Size = new System.Drawing.Size(143, 20);
            this.tbDP.TabIndex = 58;
            this.tbDP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbDescTmpMms
            // 
            this.lbDescTmpMms.AutoSize = true;
            this.lbDescTmpMms.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDescTmpMms.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbDescTmpMms.Location = new System.Drawing.Point(5, 204);
            this.lbDescTmpMms.Name = "lbDescTmpMms";
            this.lbDescTmpMms.Size = new System.Drawing.Size(102, 13);
            this.lbDescTmpMms.TabIndex = 57;
            this.lbDescTmpMms.Text = "Descripción mms";
            // 
            // tbDescMms
            // 
            this.tbDescMms.Location = new System.Drawing.Point(111, 197);
            this.tbDescMms.Name = "tbDescMms";
            this.tbDescMms.Size = new System.Drawing.Size(143, 20);
            this.tbDescMms.TabIndex = 56;
            this.tbDescMms.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbTmpMms
            // 
            this.lbTmpMms.AutoSize = true;
            this.lbTmpMms.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTmpMms.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbTmpMms.Location = new System.Drawing.Point(7, 178);
            this.lbTmpMms.Name = "lbTmpMms";
            this.lbTmpMms.Size = new System.Drawing.Size(98, 13);
            this.lbTmpMms.TabIndex = 55;
            this.lbTmpMms.Text = "Temporada mms";
            // 
            // tbTmpMms
            // 
            this.tbTmpMms.Location = new System.Drawing.Point(111, 171);
            this.tbTmpMms.Name = "tbTmpMms";
            this.tbTmpMms.Size = new System.Drawing.Size(143, 20);
            this.tbTmpMms.TabIndex = 54;
            this.tbTmpMms.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbDescTipo
            // 
            this.lbDescTipo.AutoSize = true;
            this.lbDescTipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDescTipo.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbDescTipo.Location = new System.Drawing.Point(9, 152);
            this.lbDescTipo.Name = "lbDescTipo";
            this.lbDescTipo.Size = new System.Drawing.Size(74, 13);
            this.lbDescTipo.TabIndex = 53;
            this.lbDescTipo.Text = "Descripción";
            // 
            // tbDescTipo
            // 
            this.tbDescTipo.Location = new System.Drawing.Point(111, 145);
            this.tbDescTipo.Name = "tbDescTipo";
            this.tbDescTipo.Size = new System.Drawing.Size(143, 20);
            this.tbDescTipo.TabIndex = 52;
            this.tbDescTipo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbTipo
            // 
            this.lbTipo.AutoSize = true;
            this.lbTipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTipo.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbTipo.Location = new System.Drawing.Point(9, 126);
            this.lbTipo.Name = "lbTipo";
            this.lbTipo.Size = new System.Drawing.Size(32, 13);
            this.lbTipo.TabIndex = 51;
            this.lbTipo.Text = "Tipo";
            // 
            // tbTipo
            // 
            this.tbTipo.Location = new System.Drawing.Point(111, 119);
            this.tbTipo.Name = "tbTipo";
            this.tbTipo.Size = new System.Drawing.Size(143, 20);
            this.tbTipo.TabIndex = 50;
            this.tbTipo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbUserCambio
            // 
            this.lbUserCambio.AutoSize = true;
            this.lbUserCambio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUserCambio.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbUserCambio.Location = new System.Drawing.Point(229, 544);
            this.lbUserCambio.Name = "lbUserCambio";
            this.lbUserCambio.Size = new System.Drawing.Size(48, 13);
            this.lbUserCambio.TabIndex = 49;
            this.lbUserCambio.Text = "Cambio";
            // 
            // lbUserAlta
            // 
            this.lbUserAlta.AutoSize = true;
            this.lbUserAlta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUserAlta.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbUserAlta.Location = new System.Drawing.Point(118, 544);
            this.lbUserAlta.Name = "lbUserAlta";
            this.lbUserAlta.Size = new System.Drawing.Size(29, 13);
            this.lbUserAlta.TabIndex = 48;
            this.lbUserAlta.Text = "Alta";
            // 
            // lbAyudaSts
            // 
            this.lbAyudaSts.AutoSize = true;
            this.lbAyudaSts.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbAyudaSts.Location = new System.Drawing.Point(283, 100);
            this.lbAyudaSts.Name = "lbAyudaSts";
            this.lbAyudaSts.Size = new System.Drawing.Size(148, 13);
            this.lbAyudaSts.TabIndex = 47;
            this.lbAyudaSts.Text = "A = Activo ,  D = Desactivado";
            // 
            // lbAyudaSecuencia
            // 
            this.lbAyudaSecuencia.AutoSize = true;
            this.lbAyudaSecuencia.Location = new System.Drawing.Point(282, 73);
            this.lbAyudaSecuencia.Name = "lbAyudaSecuencia";
            this.lbAyudaSecuencia.Size = new System.Drawing.Size(0, 13);
            this.lbAyudaSecuencia.TabIndex = 42;
            // 
            // lbAyudaTabla
            // 
            this.lbAyudaTabla.AutoSize = true;
            this.lbAyudaTabla.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbAyudaTabla.Location = new System.Drawing.Point(283, 47);
            this.lbAyudaTabla.Name = "lbAyudaTabla";
            this.lbAyudaTabla.Size = new System.Drawing.Size(62, 13);
            this.lbAyudaTabla.TabIndex = 41;
            this.lbAyudaTabla.Text = "del 1 al 999";
            // 
            // lbAyudaMarca
            // 
            this.lbAyudaMarca.AutoSize = true;
            this.lbAyudaMarca.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbAyudaMarca.Location = new System.Drawing.Point(283, 21);
            this.lbAyudaMarca.Name = "lbAyudaMarca";
            this.lbAyudaMarca.Size = new System.Drawing.Size(156, 13);
            this.lbAyudaMarca.TabIndex = 40;
            this.lbAyudaMarca.Text = "10 Meody, 30 Milano, 60 Kaltex";
            // 
            // lbMsjSts
            // 
            this.lbMsjSts.AutoSize = true;
            this.lbMsjSts.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbMsjSts.Location = new System.Drawing.Point(254, 100);
            this.lbMsjSts.Name = "lbMsjSts";
            this.lbMsjSts.Size = new System.Drawing.Size(28, 13);
            this.lbMsjSts.TabIndex = 39;
            this.lbMsjSts.Text = "error";
            this.lbMsjSts.Visible = false;
            // 
            // lbMsjDescripcion
            // 
            this.lbMsjDescripcion.AutoSize = true;
            this.lbMsjDescripcion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbMsjDescripcion.Location = new System.Drawing.Point(254, 73);
            this.lbMsjDescripcion.Name = "lbMsjDescripcion";
            this.lbMsjDescripcion.Size = new System.Drawing.Size(28, 13);
            this.lbMsjDescripcion.TabIndex = 34;
            this.lbMsjDescripcion.Text = "error";
            this.lbMsjDescripcion.Visible = false;
            // 
            // lbMsjTemporada
            // 
            this.lbMsjTemporada.AutoSize = true;
            this.lbMsjTemporada.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbMsjTemporada.Location = new System.Drawing.Point(254, 47);
            this.lbMsjTemporada.Name = "lbMsjTemporada";
            this.lbMsjTemporada.Size = new System.Drawing.Size(28, 13);
            this.lbMsjTemporada.TabIndex = 33;
            this.lbMsjTemporada.Text = "error";
            this.lbMsjTemporada.Visible = false;
            // 
            // lbMsjMarca
            // 
            this.lbMsjMarca.AutoSize = true;
            this.lbMsjMarca.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbMsjMarca.Location = new System.Drawing.Point(254, 20);
            this.lbMsjMarca.Name = "lbMsjMarca";
            this.lbMsjMarca.Size = new System.Drawing.Size(28, 13);
            this.lbMsjMarca.TabIndex = 32;
            this.lbMsjMarca.Text = "error";
            this.lbMsjMarca.Visible = false;
            // 
            // lbSecuencia
            // 
            this.lbSecuencia.AutoSize = true;
            this.lbSecuencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSecuencia.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbSecuencia.Location = new System.Drawing.Point(9, 100);
            this.lbSecuencia.Name = "lbSecuencia";
            this.lbSecuencia.Size = new System.Drawing.Size(67, 13);
            this.lbSecuencia.TabIndex = 31;
            this.lbSecuencia.Text = "Secuencia";
            // 
            // lbRenglon
            // 
            this.lbRenglon.AutoSize = true;
            this.lbRenglon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRenglon.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbRenglon.Location = new System.Drawing.Point(9, 73);
            this.lbRenglon.Name = "lbRenglon";
            this.lbRenglon.Size = new System.Drawing.Size(54, 13);
            this.lbRenglon.TabIndex = 26;
            this.lbRenglon.Text = "Renglon";
            // 
            // lbGpo
            // 
            this.lbGpo.AutoSize = true;
            this.lbGpo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbGpo.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbGpo.Location = new System.Drawing.Point(9, 47);
            this.lbGpo.Name = "lbGpo";
            this.lbGpo.Size = new System.Drawing.Size(41, 13);
            this.lbGpo.TabIndex = 25;
            this.lbGpo.Text = "Grupo";
            // 
            // lbMarca
            // 
            this.lbMarca.AutoSize = true;
            this.lbMarca.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMarca.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbMarca.Location = new System.Drawing.Point(9, 21);
            this.lbMarca.Name = "lbMarca";
            this.lbMarca.Size = new System.Drawing.Size(42, 13);
            this.lbMarca.TabIndex = 24;
            this.lbMarca.Text = "Marca";
            // 
            // btElimiar
            // 
            this.btElimiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btElimiar.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btElimiar.Image = global::MmsWin.Front.Properties.Resources.Waste_32px;
            this.btElimiar.Location = new System.Drawing.Point(333, 617);
            this.btElimiar.Name = "btElimiar";
            this.btElimiar.Size = new System.Drawing.Size(100, 39);
            this.btElimiar.TabIndex = 20;
            this.btElimiar.Text = "   Eliminar";
            this.btElimiar.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btElimiar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btElimiar.UseVisualStyleBackColor = true;
            this.btElimiar.Click += new System.EventHandler(this.btElimiar_Click);
            // 
            // btCambio
            // 
            this.btCambio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCambio.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btCambio.Image = global::MmsWin.Front.Properties.Resources.Change_32px;
            this.btCambio.Location = new System.Drawing.Point(227, 617);
            this.btCambio.Name = "btCambio";
            this.btCambio.Size = new System.Drawing.Size(100, 39);
            this.btCambio.TabIndex = 19;
            this.btCambio.Text = "  Cambio";
            this.btCambio.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btCambio.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btCambio.UseVisualStyleBackColor = true;
            this.btCambio.Click += new System.EventHandler(this.btCambio_Click);
            // 
            // btAlta
            // 
            this.btAlta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAlta.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btAlta.Image = global::MmsWin.Front.Properties.Resources.Save_32px;
            this.btAlta.Location = new System.Drawing.Point(121, 617);
            this.btAlta.Name = "btAlta";
            this.btAlta.Size = new System.Drawing.Size(100, 39);
            this.btAlta.TabIndex = 18;
            this.btAlta.Text = "     Alta";
            this.btAlta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btAlta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btAlta.UseCompatibleTextRendering = true;
            this.btAlta.UseVisualStyleBackColor = true;
            this.btAlta.Click += new System.EventHandler(this.btAlta_Click);
            // 
            // btCancelar
            // 
            this.btCancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCancelar.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btCancelar.Image = global::MmsWin.Front.Properties.Resources.Back_Arrow_32px;
            this.btCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btCancelar.Location = new System.Drawing.Point(15, 617);
            this.btCancelar.Name = "btCancelar";
            this.btCancelar.Size = new System.Drawing.Size(100, 39);
            this.btCancelar.TabIndex = 17;
            this.btCancelar.Text = "   Salir";
            this.btCancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btCancelar.UseVisualStyleBackColor = true;
            this.btCancelar.Click += new System.EventHandler(this.btCancelar_Click);
            // 
            // lbHora
            // 
            this.lbHora.AutoSize = true;
            this.lbHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHora.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbHora.Location = new System.Drawing.Point(78, 594);
            this.lbHora.Name = "lbHora";
            this.lbHora.Size = new System.Drawing.Size(34, 13);
            this.lbHora.TabIndex = 16;
            this.lbHora.Text = "Hora";
            // 
            // lbFecha
            // 
            this.lbFecha.AutoSize = true;
            this.lbFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFecha.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbFecha.Location = new System.Drawing.Point(78, 568);
            this.lbFecha.Name = "lbFecha";
            this.lbFecha.Size = new System.Drawing.Size(42, 13);
            this.lbFecha.TabIndex = 15;
            this.lbFecha.Text = "Fecha";
            // 
            // lbUsuario
            // 
            this.lbUsuario.AutoSize = true;
            this.lbUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUsuario.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbUsuario.Location = new System.Drawing.Point(330, 544);
            this.lbUsuario.Name = "lbUsuario";
            this.lbUsuario.Size = new System.Drawing.Size(50, 13);
            this.lbUsuario.TabIndex = 14;
            this.lbUsuario.Text = "Usuario";
            // 
            // tbHoraCambio
            // 
            this.tbHoraCambio.BackColor = System.Drawing.SystemColors.Control;
            this.tbHoraCambio.Enabled = false;
            this.tbHoraCambio.Location = new System.Drawing.Point(229, 587);
            this.tbHoraCambio.Name = "tbHoraCambio";
            this.tbHoraCambio.Size = new System.Drawing.Size(100, 20);
            this.tbHoraCambio.TabIndex = 13;
            // 
            // tbFechaCambio
            // 
            this.tbFechaCambio.BackColor = System.Drawing.SystemColors.Control;
            this.tbFechaCambio.Enabled = false;
            this.tbFechaCambio.Location = new System.Drawing.Point(229, 561);
            this.tbFechaCambio.Name = "tbFechaCambio";
            this.tbFechaCambio.Size = new System.Drawing.Size(100, 20);
            this.tbFechaCambio.TabIndex = 12;
            // 
            // tbHoraAlta
            // 
            this.tbHoraAlta.BackColor = System.Drawing.SystemColors.Control;
            this.tbHoraAlta.Enabled = false;
            this.tbHoraAlta.Location = new System.Drawing.Point(121, 587);
            this.tbHoraAlta.Name = "tbHoraAlta";
            this.tbHoraAlta.Size = new System.Drawing.Size(100, 20);
            this.tbHoraAlta.TabIndex = 11;
            // 
            // tbFechaAlta
            // 
            this.tbFechaAlta.BackColor = System.Drawing.SystemColors.Control;
            this.tbFechaAlta.Enabled = false;
            this.tbFechaAlta.Location = new System.Drawing.Point(121, 561);
            this.tbFechaAlta.Name = "tbFechaAlta";
            this.tbFechaAlta.Size = new System.Drawing.Size(100, 20);
            this.tbFechaAlta.TabIndex = 10;
            // 
            // tbUserCambio
            // 
            this.tbUserCambio.BackColor = System.Drawing.SystemColors.Control;
            this.tbUserCambio.Enabled = false;
            this.tbUserCambio.Location = new System.Drawing.Point(333, 587);
            this.tbUserCambio.Name = "tbUserCambio";
            this.tbUserCambio.Size = new System.Drawing.Size(100, 20);
            this.tbUserCambio.TabIndex = 9;
            // 
            // tbUserAlta
            // 
            this.tbUserAlta.BackColor = System.Drawing.SystemColors.Control;
            this.tbUserAlta.Enabled = false;
            this.tbUserAlta.Location = new System.Drawing.Point(333, 561);
            this.tbUserAlta.Name = "tbUserAlta";
            this.tbUserAlta.Size = new System.Drawing.Size(100, 20);
            this.tbUserAlta.TabIndex = 8;
            // 
            // tbSecuencia
            // 
            this.tbSecuencia.Location = new System.Drawing.Point(111, 93);
            this.tbSecuencia.Name = "tbSecuencia";
            this.tbSecuencia.Size = new System.Drawing.Size(143, 20);
            this.tbSecuencia.TabIndex = 7;
            this.tbSecuencia.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbRenglon
            // 
            this.tbRenglon.Location = new System.Drawing.Point(111, 66);
            this.tbRenglon.Name = "tbRenglon";
            this.tbRenglon.Size = new System.Drawing.Size(143, 20);
            this.tbRenglon.TabIndex = 2;
            this.tbRenglon.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTemporada
            // 
            this.tbTemporada.Location = new System.Drawing.Point(111, 40);
            this.tbTemporada.Name = "tbTemporada";
            this.tbTemporada.Size = new System.Drawing.Size(143, 20);
            this.tbTemporada.TabIndex = 1;
            this.tbTemporada.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbMarca
            // 
            this.tbMarca.Location = new System.Drawing.Point(111, 14);
            this.tbMarca.Name = "tbMarca";
            this.tbMarca.Size = new System.Drawing.Size(143, 20);
            this.tbMarca.TabIndex = 0;
            this.tbMarca.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbTitulo
            // 
            this.lbTitulo.AutoSize = true;
            this.lbTitulo.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbTitulo.Location = new System.Drawing.Point(8, 8);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(166, 21);
            this.lbTitulo.TabIndex = 32;
            this.lbTitulo.Text = "Mantenimiento grupos";
            // 
            // GrupoTemporadaABC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(442, 717);
            this.Controls.Add(this.lbTitulo);
            this.Controls.Add(this.panel01);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "GrupoTemporadaABC";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GrupoTemporadaABC";
            this.Load += new System.EventHandler(this.GrupoTemporadaABC_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.GrupoTemporadaABC_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.GrupoTemporadaABC_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.GrupoTemporadaABC_MouseUp);
            this.panel01.ResumeLayout(false);
            this.panel01.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel01;
        private System.Windows.Forms.Label lbSecuencia;
        private System.Windows.Forms.Label lbRenglon;
        private System.Windows.Forms.Label lbGpo;
        private System.Windows.Forms.Label lbMarca;
        private System.Windows.Forms.Button btElimiar;
        private System.Windows.Forms.Button btCambio;
        private System.Windows.Forms.Button btAlta;
        private System.Windows.Forms.Button btCancelar;
        private System.Windows.Forms.Label lbHora;
        private System.Windows.Forms.Label lbFecha;
        private System.Windows.Forms.Label lbUsuario;
        private System.Windows.Forms.TextBox tbHoraCambio;
        private System.Windows.Forms.TextBox tbFechaCambio;
        private System.Windows.Forms.TextBox tbHoraAlta;
        private System.Windows.Forms.TextBox tbFechaAlta;
        private System.Windows.Forms.TextBox tbUserCambio;
        private System.Windows.Forms.TextBox tbUserAlta;
        private System.Windows.Forms.TextBox tbSecuencia;
        private System.Windows.Forms.TextBox tbRenglon;
        private System.Windows.Forms.TextBox tbTemporada;
        private System.Windows.Forms.TextBox tbMarca;
        private System.Windows.Forms.Label lbTitulo;
        private System.Windows.Forms.Label lbAyudaSts;
        private System.Windows.Forms.Label lbAyudaSecuencia;
        private System.Windows.Forms.Label lbAyudaTabla;
        private System.Windows.Forms.Label lbAyudaMarca;
        private System.Windows.Forms.Label lbMsjSts;
        private System.Windows.Forms.Label lbMsjDescripcion;
        private System.Windows.Forms.Label lbMsjTemporada;
        private System.Windows.Forms.Label lbMsjMarca;
        private System.Windows.Forms.Label lbUserCambio;
        private System.Windows.Forms.Label lbUserAlta;
        private System.Windows.Forms.Label lbTipo;
        private System.Windows.Forms.TextBox tbTipo;
        private System.Windows.Forms.Label lbDescEstilo;
        private System.Windows.Forms.TextBox tbDescEstilo;
        private System.Windows.Forms.Label lbEstilo;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.Label lbNombre;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.Label lbProveedor;
        private System.Windows.Forms.TextBox tbProveedor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbDescSC;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbDescCL;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbDescSD;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbDescDP;
        private System.Windows.Forms.Label lbSC;
        private System.Windows.Forms.TextBox tbSC;
        private System.Windows.Forms.Label lbCL;
        private System.Windows.Forms.TextBox tbCL;
        private System.Windows.Forms.Label lbSD;
        private System.Windows.Forms.TextBox tbSD;
        private System.Windows.Forms.Label lbDP;
        private System.Windows.Forms.TextBox tbDP;
        private System.Windows.Forms.Label lbDescTmpMms;
        private System.Windows.Forms.TextBox tbDescMms;
        private System.Windows.Forms.Label lbTmpMms;
        private System.Windows.Forms.TextBox tbTmpMms;
        private System.Windows.Forms.Label lbDescTipo;
        private System.Windows.Forms.TextBox tbDescTipo;
    }
}