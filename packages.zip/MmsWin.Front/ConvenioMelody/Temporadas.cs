﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class Temporadas : Form
    {
        public static DataTable TemporadasMms { get; set; }

        Point mousedownpoint = Point.Empty;
        int nr;

       public System.Data.DataTable dtTemporadas = null;

        public Temporadas()
        {
            InitializeComponent();
        }

        private void pbSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Temporadas_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void Temporadas_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedownpoint.IsEmpty)
                return;
            Form f = sender as Form;
            f.Location = new Point(f.Location.X + (e.X - mousedownpoint.X), f.Location.Y + (e.Y - mousedownpoint.Y));
        }

        private void Temporadas_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

        private void Temporadas_Load(object sender, EventArgs e)
        {
            BindTemporadas(); 
            SetFontAndColors();
            rowStyle();
        }

        protected  void BindTemporadas()
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string temporada   = tbTemporada.Text;
                string descripcion = tbDescripcion.Text;
                dtTemporadas = MmsWin.Negocio.Catalogos.TemporadaMms.GetInstance().ObtenTemporadasMmsSEA(temporada, descripcion);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (dtTemporadas != null)
            {
                if (dtTemporadas.Rows.Count > 0)
                {
                    SetDoubleBuffered(dgvGridView);
                    dgvGridView.DataSource = null;

                    dgvGridView.DataSource = dtTemporadas;

                    nr = dgvGridView.RowCount;
                    lbTemporadas.Text = "Temporadas / " + (nr).ToString() + " Registro(s)";
                    //SetFontAndColors();
                    //rowStyle();

                    //// Seguridad...
                    //ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                    //Seguridad("Convenio", "Convenio", ParUser);
                    //dgvGridView.Visible = false;

                    //dgvGridView.Focus();
                    //dgvGridView.Select();
                }
            }
            this.Cursor = Cursors.Default;
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        // Atributos y caracteristicas                                                                    
        //
        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.WhiteSmoke;
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 10);
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new Font(dgvGridView.ColumnHeadersDefaultCellStyle.Font, FontStyle.Bold);

            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Olive;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.WhiteSmoke;
            this.dgvGridView.RowsDefaultCellStyle.BackColor = Color.Gray;
            this.dgvGridView.RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty;
            this.dgvGridView.RowHeadersDefaultCellStyle.BackColor = Color.Gray;
            this.dgvGridView.Columns[1].Frozen = true;

            dgvGridView.Columns["SEANUM"].HeaderText = "Temporada";
            dgvGridView.Columns["SEADSC"].HeaderText = "Decripción";

            dgvGridView.Columns["SEANUM"].Width = 100;
            dgvGridView.Columns["SEADSC"].Width = 600;

            dgvGridView.Columns["SEANUM"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["SEADSC"].DefaultCellStyle.NullValue = true;

            dgvGridView.Columns["SEANUM"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["SEADSC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            dgvGridView.Columns["SEANUM"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["SEADSC"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["SEANUM"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["SEADSC"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
        }

        // Estilo de Renglones                                                                            
        //
        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    //dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.LightGray;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }

        private void tbTemporada_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindTemporadas();
                tbTemporada.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindTemporadas();
                tbDescripcion.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void AgregarTSMI_Click(object sender, EventArgs e)
        {
            string message = "Esta seguro de agregar esta(s) temporada(s)?";
            string caption = "Confirmación";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                try
                {
                    string MoverFecha = string.Empty;

                    System.Data.DataTable dtTemporadas = new System.Data.DataTable("Temporadas");

                    dtTemporadas.Columns.Add("marca", typeof(String));
                    dtTemporadas.Columns.Add("grupo", typeof(String));
                    dtTemporadas.Columns.Add("tipo", typeof(String));
                    dtTemporadas.Columns.Add("tempMms", typeof(String));

                    DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
                    foreach (DataGridViewRow item in Seleccionados)
                    {
                        DataRow workRow = dtTemporadas.NewRow();

                        workRow["marca"] = MmsWin.Front.ConvenioMelody.GrupoTemporada.marca;
                        workRow["grupo"] = MmsWin.Front.ConvenioMelody.GrupoTemporada.grupo;
                        workRow["tipo"] = "TMP";
                        workRow["tempMms"] = item.Cells["SEANUM"].Value.ToString();

                        dtTemporadas.Rows.Add(workRow);
                    }

                    MmsWin.Front.ConvenioMelody.Temporadas.TemporadasMms = dtTemporadas;

                    if (dtTemporadas.Rows.Count > 0)
                    {
                        string usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        string mensaje = MmsWin.Negocio.ConvenioMelody.Grupos.GetInstance().AgregarGrupos(dtTemporadas, usuario);
                        MessageBox.Show(mensaje);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Debe seleccionar la(s) temporada(s)...");
                    }
                }
                catch { }
                finally { }
            }
        }
    }
}
