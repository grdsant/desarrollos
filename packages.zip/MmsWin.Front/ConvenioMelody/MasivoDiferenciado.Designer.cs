﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class MasivoDiferenciado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mtbCosto = new System.Windows.Forms.MaskedTextBox();
            this.mtbPrecio = new System.Windows.Forms.MaskedTextBox();
            this.mtbMargen = new System.Windows.Forms.MaskedTextBox();
            this.lblCosto = new System.Windows.Forms.Label();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.lbReferencia = new System.Windows.Forms.Label();
            this.lblMargen = new System.Windows.Forms.Label();
            this.gbNota = new System.Windows.Forms.GroupBox();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.lbTablaDeAccFinal = new System.Windows.Forms.Label();
            this.mtbNOTTABF = new System.Windows.Forms.MaskedTextBox();
            this.lbTablaDeAccNueva = new System.Windows.Forms.Label();
            this.mtbNOTTAB1 = new System.Windows.Forms.MaskedTextBox();
            this.lbTablaDeAccActual = new System.Windows.Forms.Label();
            this.mtbNOTTAB = new System.Windows.Forms.MaskedTextBox();
            this.lbTablaDeAccion = new System.Windows.Forms.Label();
            this.lbFinal = new System.Windows.Forms.Label();
            this.lbNuevo = new System.Windows.Forms.Label();
            this.lbActual = new System.Windows.Forms.Label();
            this.mtbMargenFinal = new System.Windows.Forms.MaskedTextBox();
            this.mtbPrecioFinal = new System.Windows.Forms.MaskedTextBox();
            this.mtbCostoFinal = new System.Windows.Forms.MaskedTextBox();
            this.mtbMargenNuevo = new System.Windows.Forms.MaskedTextBox();
            this.mtbPrecioNuevo = new System.Windows.Forms.MaskedTextBox();
            this.mtbCostoNuevo = new System.Windows.Forms.MaskedTextBox();
            this.mtbPorc = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbReferencia = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.gbNota.SuspendLayout();
            this.SuspendLayout();
            // 
            // mtbCosto
            // 
            this.mtbCosto.Enabled = false;
            this.mtbCosto.Location = new System.Drawing.Point(114, 122);
            this.mtbCosto.Name = "mtbCosto";
            this.mtbCosto.Size = new System.Drawing.Size(60, 20);
            this.mtbCosto.TabIndex = 10;
            this.mtbCosto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPrecio
            // 
            this.mtbPrecio.Enabled = false;
            this.mtbPrecio.Location = new System.Drawing.Point(114, 144);
            this.mtbPrecio.Name = "mtbPrecio";
            this.mtbPrecio.Size = new System.Drawing.Size(60, 20);
            this.mtbPrecio.TabIndex = 11;
            this.mtbPrecio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbMargen
            // 
            this.mtbMargen.Enabled = false;
            this.mtbMargen.Location = new System.Drawing.Point(114, 166);
            this.mtbMargen.Name = "mtbMargen";
            this.mtbMargen.Size = new System.Drawing.Size(60, 20);
            this.mtbMargen.TabIndex = 12;
            this.mtbMargen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblCosto
            // 
            this.lblCosto.AutoSize = true;
            this.lblCosto.BackColor = System.Drawing.Color.Silver;
            this.lblCosto.Location = new System.Drawing.Point(27, 125);
            this.lblCosto.Name = "lblCosto";
            this.lblCosto.Size = new System.Drawing.Size(85, 13);
            this.lblCosto.TabIndex = 23;
            this.lblCosto.Text = "Costo                 ";
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.BackColor = System.Drawing.Color.Silver;
            this.lblPrecio.Location = new System.Drawing.Point(27, 147);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(85, 13);
            this.lblPrecio.TabIndex = 24;
            this.lblPrecio.Text = "Precio                ";
            // 
            // lbReferencia
            // 
            this.lbReferencia.AutoSize = true;
            this.lbReferencia.BackColor = System.Drawing.Color.Silver;
            this.lbReferencia.Location = new System.Drawing.Point(48, 41);
            this.lbReferencia.Name = "lbReferencia";
            this.lbReferencia.Size = new System.Drawing.Size(62, 13);
            this.lbReferencia.TabIndex = 19;
            this.lbReferencia.Text = "Referencia ";
            // 
            // lblMargen
            // 
            this.lblMargen.AutoSize = true;
            this.lblMargen.BackColor = System.Drawing.Color.Silver;
            this.lblMargen.Location = new System.Drawing.Point(27, 169);
            this.lblMargen.Name = "lblMargen";
            this.lblMargen.Size = new System.Drawing.Size(85, 13);
            this.lblMargen.TabIndex = 25;
            this.lblMargen.Text = "Margen              ";
            // 
            // gbNota
            // 
            this.gbNota.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gbNota.Controls.Add(this.btnGuardar);
            this.gbNota.Controls.Add(this.btnCancelar);
            this.gbNota.Controls.Add(this.lbTablaDeAccFinal);
            this.gbNota.Controls.Add(this.mtbNOTTABF);
            this.gbNota.Controls.Add(this.lbTablaDeAccNueva);
            this.gbNota.Controls.Add(this.mtbNOTTAB1);
            this.gbNota.Controls.Add(this.lbTablaDeAccActual);
            this.gbNota.Controls.Add(this.mtbNOTTAB);
            this.gbNota.Controls.Add(this.lbTablaDeAccion);
            this.gbNota.Controls.Add(this.lbFinal);
            this.gbNota.Controls.Add(this.lbNuevo);
            this.gbNota.Controls.Add(this.lbActual);
            this.gbNota.Controls.Add(this.mtbMargenFinal);
            this.gbNota.Controls.Add(this.mtbPrecioFinal);
            this.gbNota.Controls.Add(this.mtbCostoFinal);
            this.gbNota.Controls.Add(this.mtbMargenNuevo);
            this.gbNota.Controls.Add(this.mtbPrecioNuevo);
            this.gbNota.Controls.Add(this.mtbCostoNuevo);
            this.gbNota.Controls.Add(this.mtbPorc);
            this.gbNota.Controls.Add(this.label7);
            this.gbNota.Controls.Add(this.tbReferencia);
            this.gbNota.Controls.Add(this.lblMargen);
            this.gbNota.Controls.Add(this.lbReferencia);
            this.gbNota.Controls.Add(this.lblPrecio);
            this.gbNota.Controls.Add(this.lblCosto);
            this.gbNota.Controls.Add(this.mtbMargen);
            this.gbNota.Controls.Add(this.mtbPrecio);
            this.gbNota.Controls.Add(this.mtbCosto);
            this.gbNota.Controls.Add(this.panel1);
            this.gbNota.Controls.Add(this.panel2);
            this.gbNota.Controls.Add(this.panel3);
            this.gbNota.Location = new System.Drawing.Point(15, 15);
            this.gbNota.Name = "gbNota";
            this.gbNota.Size = new System.Drawing.Size(324, 314);
            this.gbNota.TabIndex = 0;
            this.gbNota.TabStop = false;
            this.gbNota.Text = "Identificación de la Rebaja";
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.Gray;
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGuardar.Location = new System.Drawing.Point(186, 277);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 3;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.Gray;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCancelar.Location = new System.Drawing.Point(51, 277);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 1;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // lbTablaDeAccFinal
            // 
            this.lbTablaDeAccFinal.AutoSize = true;
            this.lbTablaDeAccFinal.BackColor = System.Drawing.Color.Silver;
            this.lbTablaDeAccFinal.Location = new System.Drawing.Point(230, 214);
            this.lbTablaDeAccFinal.Name = "lbTablaDeAccFinal";
            this.lbTablaDeAccFinal.Size = new System.Drawing.Size(38, 13);
            this.lbTablaDeAccFinal.TabIndex = 49;
            this.lbTablaDeAccFinal.Text = "Final   ";
            this.lbTablaDeAccFinal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mtbNOTTABF
            // 
            this.mtbNOTTABF.Location = new System.Drawing.Point(230, 229);
            this.mtbNOTTABF.Name = "mtbNOTTABF";
            this.mtbNOTTABF.Size = new System.Drawing.Size(38, 20);
            this.mtbNOTTABF.TabIndex = 48;
            this.mtbNOTTABF.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbTablaDeAccNueva
            // 
            this.lbTablaDeAccNueva.AutoSize = true;
            this.lbTablaDeAccNueva.BackColor = System.Drawing.Color.Silver;
            this.lbTablaDeAccNueva.Location = new System.Drawing.Point(187, 214);
            this.lbTablaDeAccNueva.Name = "lbTablaDeAccNueva";
            this.lbTablaDeAccNueva.Size = new System.Drawing.Size(39, 13);
            this.lbTablaDeAccNueva.TabIndex = 47;
            this.lbTablaDeAccNueva.Text = "Nueva";
            this.lbTablaDeAccNueva.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mtbNOTTAB1
            // 
            this.mtbNOTTAB1.Enabled = false;
            this.mtbNOTTAB1.Location = new System.Drawing.Point(187, 229);
            this.mtbNOTTAB1.Name = "mtbNOTTAB1";
            this.mtbNOTTAB1.Size = new System.Drawing.Size(38, 20);
            this.mtbNOTTAB1.TabIndex = 46;
            this.mtbNOTTAB1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbTablaDeAccActual
            // 
            this.lbTablaDeAccActual.AutoSize = true;
            this.lbTablaDeAccActual.BackColor = System.Drawing.Color.Silver;
            this.lbTablaDeAccActual.Location = new System.Drawing.Point(145, 214);
            this.lbTablaDeAccActual.Name = "lbTablaDeAccActual";
            this.lbTablaDeAccActual.Size = new System.Drawing.Size(37, 13);
            this.lbTablaDeAccActual.TabIndex = 45;
            this.lbTablaDeAccActual.Text = "Actual";
            this.lbTablaDeAccActual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mtbNOTTAB
            // 
            this.mtbNOTTAB.Enabled = false;
            this.mtbNOTTAB.Location = new System.Drawing.Point(145, 229);
            this.mtbNOTTAB.Name = "mtbNOTTAB";
            this.mtbNOTTAB.Size = new System.Drawing.Size(38, 20);
            this.mtbNOTTAB.TabIndex = 44;
            this.mtbNOTTAB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbTablaDeAccion
            // 
            this.lbTablaDeAccion.AutoSize = true;
            this.lbTablaDeAccion.BackColor = System.Drawing.Color.Silver;
            this.lbTablaDeAccion.Location = new System.Drawing.Point(41, 229);
            this.lbTablaDeAccion.Name = "lbTablaDeAccion";
            this.lbTablaDeAccion.Size = new System.Drawing.Size(70, 13);
            this.lbTablaDeAccion.TabIndex = 43;
            this.lbTablaDeAccion.Text = "Tabla Acción";
            // 
            // lbFinal
            // 
            this.lbFinal.AutoSize = true;
            this.lbFinal.BackColor = System.Drawing.Color.Silver;
            this.lbFinal.Location = new System.Drawing.Point(243, 105);
            this.lbFinal.Name = "lbFinal";
            this.lbFinal.Size = new System.Drawing.Size(56, 13);
            this.lbFinal.TabIndex = 37;
            this.lbFinal.Text = "Final         ";
            // 
            // lbNuevo
            // 
            this.lbNuevo.AutoSize = true;
            this.lbNuevo.BackColor = System.Drawing.Color.Silver;
            this.lbNuevo.Location = new System.Drawing.Point(179, 105);
            this.lbNuevo.Name = "lbNuevo";
            this.lbNuevo.Size = new System.Drawing.Size(57, 13);
            this.lbNuevo.TabIndex = 36;
            this.lbNuevo.Text = "Nuevo      ";
            // 
            // lbActual
            // 
            this.lbActual.AutoSize = true;
            this.lbActual.BackColor = System.Drawing.Color.Silver;
            this.lbActual.Location = new System.Drawing.Point(116, 105);
            this.lbActual.Name = "lbActual";
            this.lbActual.Size = new System.Drawing.Size(58, 13);
            this.lbActual.TabIndex = 35;
            this.lbActual.Text = "Actual       ";
            this.lbActual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mtbMargenFinal
            // 
            this.mtbMargenFinal.Location = new System.Drawing.Point(242, 164);
            this.mtbMargenFinal.Name = "mtbMargenFinal";
            this.mtbMargenFinal.Size = new System.Drawing.Size(60, 20);
            this.mtbMargenFinal.TabIndex = 34;
            this.mtbMargenFinal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPrecioFinal
            // 
            this.mtbPrecioFinal.Location = new System.Drawing.Point(242, 142);
            this.mtbPrecioFinal.Name = "mtbPrecioFinal";
            this.mtbPrecioFinal.Size = new System.Drawing.Size(60, 20);
            this.mtbPrecioFinal.TabIndex = 33;
            this.mtbPrecioFinal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbCostoFinal
            // 
            this.mtbCostoFinal.Location = new System.Drawing.Point(242, 120);
            this.mtbCostoFinal.Name = "mtbCostoFinal";
            this.mtbCostoFinal.Size = new System.Drawing.Size(60, 20);
            this.mtbCostoFinal.TabIndex = 32;
            this.mtbCostoFinal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbMargenNuevo
            // 
            this.mtbMargenNuevo.Enabled = false;
            this.mtbMargenNuevo.Location = new System.Drawing.Point(178, 165);
            this.mtbMargenNuevo.Name = "mtbMargenNuevo";
            this.mtbMargenNuevo.Size = new System.Drawing.Size(60, 20);
            this.mtbMargenNuevo.TabIndex = 31;
            this.mtbMargenNuevo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPrecioNuevo
            // 
            this.mtbPrecioNuevo.Enabled = false;
            this.mtbPrecioNuevo.Location = new System.Drawing.Point(178, 143);
            this.mtbPrecioNuevo.Name = "mtbPrecioNuevo";
            this.mtbPrecioNuevo.Size = new System.Drawing.Size(60, 20);
            this.mtbPrecioNuevo.TabIndex = 30;
            this.mtbPrecioNuevo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbCostoNuevo
            // 
            this.mtbCostoNuevo.Enabled = false;
            this.mtbCostoNuevo.Location = new System.Drawing.Point(178, 121);
            this.mtbCostoNuevo.Name = "mtbCostoNuevo";
            this.mtbCostoNuevo.Size = new System.Drawing.Size(60, 20);
            this.mtbCostoNuevo.TabIndex = 29;
            this.mtbCostoNuevo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPorc
            // 
            this.mtbPorc.BackColor = System.Drawing.Color.White;
            this.mtbPorc.Location = new System.Drawing.Point(159, 64);
            this.mtbPorc.Name = "mtbPorc";
            this.mtbPorc.Size = new System.Drawing.Size(100, 20);
            this.mtbPorc.TabIndex = 1;
            this.mtbPorc.Text = "0";
            this.mtbPorc.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.mtbPorc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mtbPorc_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Silver;
            this.label7.Location = new System.Drawing.Point(48, 71);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "%  x Aplicar";
            // 
            // tbReferencia
            // 
            this.tbReferencia.BackColor = System.Drawing.Color.White;
            this.tbReferencia.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbReferencia.Location = new System.Drawing.Point(159, 34);
            this.tbReferencia.Name = "tbReferencia";
            this.tbReferencia.Size = new System.Drawing.Size(100, 20);
            this.tbReferencia.TabIndex = 0;
            this.tbReferencia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbReferencia_KeyPress);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Location = new System.Drawing.Point(14, 27);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(295, 66);
            this.panel1.TabIndex = 50;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.Location = new System.Drawing.Point(14, 96);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(294, 100);
            this.panel2.TabIndex = 51;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Silver;
            this.panel3.Location = new System.Drawing.Point(14, 201);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(294, 60);
            this.panel3.TabIndex = 52;
            // 
            // MasivoDiferenciado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(354, 346);
            this.Controls.Add(this.gbNota);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "MasivoDiferenciado";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Selección Masiva";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Nota_FormClosing);
            this.Load += new System.EventHandler(this.Nota_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MasivoDiferenciado_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MasivoDiferenciado_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.MasivoDiferenciado_MouseUp);
            this.gbNota.ResumeLayout(false);
            this.gbNota.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mtbCosto;
        private System.Windows.Forms.MaskedTextBox mtbPrecio;
        private System.Windows.Forms.MaskedTextBox mtbMargen;
        private System.Windows.Forms.Label lblCosto;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Label lbReferencia;
        private System.Windows.Forms.Label lblMargen;
        private System.Windows.Forms.GroupBox gbNota;
        private System.Windows.Forms.TextBox tbReferencia;
        private System.Windows.Forms.MaskedTextBox mtbPorc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbFinal;
        private System.Windows.Forms.Label lbNuevo;
        private System.Windows.Forms.Label lbActual;
        private System.Windows.Forms.MaskedTextBox mtbMargenFinal;
        private System.Windows.Forms.MaskedTextBox mtbPrecioFinal;
        private System.Windows.Forms.MaskedTextBox mtbCostoFinal;
        private System.Windows.Forms.MaskedTextBox mtbMargenNuevo;
        private System.Windows.Forms.MaskedTextBox mtbPrecioNuevo;
        private System.Windows.Forms.MaskedTextBox mtbCostoNuevo;
        private System.Windows.Forms.Label lbTablaDeAccActual;
        private System.Windows.Forms.MaskedTextBox mtbNOTTAB;
        private System.Windows.Forms.Label lbTablaDeAccion;
        private System.Windows.Forms.Label lbTablaDeAccFinal;
        private System.Windows.Forms.MaskedTextBox mtbNOTTABF;
        private System.Windows.Forms.Label lbTablaDeAccNueva;
        private System.Windows.Forms.MaskedTextBox mtbNOTTAB1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
    }
}