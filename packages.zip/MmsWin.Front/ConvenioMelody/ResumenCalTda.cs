﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using MmsWin.Front.Convenio;
using System.Windows.Forms;
using MmsWin.Front.Utilerias;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class ResumenCalTda : Form
    {
        #region Variables
        // variables de la Ventana
        public static string parCalificacion;
        public static string parCalificacionOriginal;

        public static string parTemporada;
        public static string parTipoCalificacion;
        public static string parFchCalificacion;
        public static string parFchInicial;
        public static string parProveedor;
        public static string parNombre;
        public static string varlocNombre;
        public static string parEstilo;
        public static string parDescripcion;
        public static string varLocDescripcion;

        public static string varlocCosto;
        public static string varlocPrecio;
        public static string varlocMargen;
        #endregion

        #region Grid
        // variables de la Ventana
        public static string gridMarca;
        public static string gridFechaCalifica;
        public static string gridTipoCalifica;
        public static string gridTemporada;
        public static string gridTabla;
        public static string gridProveedor;
        public static string gridEstilo;
        public static string gridOrden;
        #endregion

        int nr;
        bool Carga;
        String ParUser;
        string marca;
        string comprador;

        int dgvOffset;
        int dgvOffset2;

        Point mousedownpoint = Point.Empty;

        String FchDe;
        String FchHas;

        string Seleccion = string.Empty;


        public static string romperForeach = "No";
        public static string siHuboRebaja  = "No";
        public static string parMarca;
        public static string parFchDesde;
        public static string parFchHasta;
        public static string ParFchBon;
        public static string parOrigen;
        public static DataTable dtDiferenciados { get; set; }
        public static string parComprador;

        public ResumenCalTda()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }

        private void ResumenCalTda_Load(object sender, EventArgs e)
        {
            try
            {
                colorCalOriginal();

                parProveedor = MmsWin.Front.Utilerias.VarTem.parProveedor;
                parEstilo = MmsWin.Front.Utilerias.VarTem.parEstilo;
                #region foto
                string charPrv = parProveedor.PadLeft(6, '0');
                string ext = ".jpg";
                string path = @"\\192.168.2.79\www\showroom\images3\";
                string foto = path + "F" + charPrv + parEstilo + ext + " ";
                pbFoto.ImageLocation = foto;
                #endregion

                #region Variables
                // variables de la Ventana
                MmsWin.Front.ConvenioMelody.ResumenCalTda.parTemporada = string.Empty;
                MmsWin.Front.ConvenioMelody.ResumenCalTda.parTipoCalificacion = string.Empty;
                MmsWin.Front.ConvenioMelody.ResumenCalTda.parFchCalificacion = string.Empty;
                MmsWin.Front.ConvenioMelody.ResumenCalTda.parFchInicial = string.Empty;
                MmsWin.Front.ConvenioMelody.ResumenCalTda.parProveedor = string.Empty;
                MmsWin.Front.ConvenioMelody.ResumenCalTda.parNombre = string.Empty;
                MmsWin.Front.ConvenioMelody.ResumenCalTda.parEstilo = string.Empty;
                MmsWin.Front.ConvenioMelody.ResumenCalTda.parDescripcion = string.Empty;
                #endregion

                Carga = false;
                marca = "999";
                comprador = "999";

                ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;

                try
                {
                    System.Data.DataTable tbFechaInicial = null;
                    tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                try
                {
                    Carga = true;
                    BinData();
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            catch { }
        }

        private void BinData()
        {
            if (Carga == true)
            {
                EliminacheckBox();
                nr = 0;
                System.Data.DataTable dtCalificacionesTda = null;
                try
                {
                    this.Cursor = Cursors.WaitCursor;

                    string tipo      = string.Empty;
                    string temporada = string.Empty;
                    string tabla     = string.Empty;

                    string FchDe = string.Empty;
                    string FchHas = string.Empty;
                    marca               = MmsWin.Front.Utilerias.VarTem.parmarca;
                    comprador           = MmsWin.Front.Utilerias.VarTem.parcomprador;
                    FchDe               = MmsWin.Front.Utilerias.VarTem.parFchDe;
                    FchHas              = MmsWin.Front.Utilerias.VarTem.parFchHas;
                    tipo                = MmsWin.Front.Utilerias.VarTem.partipo;
                    temporada           = MmsWin.Front.Utilerias.VarTem.partemporada;
                    parTipoCalificacion = MmsWin.Front.Utilerias.VarTem.parTipoCalificacion;
                    parFchCalificacion  = MmsWin.Front.Utilerias.VarTem.parFchCalificacion;
                    parProveedor        = MmsWin.Front.Utilerias.VarTem.parProveedor;
                    parNombre           = MmsWin.Front.Utilerias.VarTem.parNombre;
                    parEstilo           = MmsWin.Front.Utilerias.VarTem.parEstilo;
                    parDescripcion      = MmsWin.Front.Utilerias.VarTem.parDescripcion;

                    string tipoconsulta = MmsWin.Front.ConvenioMelody.CalificacionGrid.parTipoConsulta;
                    if (tipoconsulta == "GlobalTda")
                    {
                        parProveedor = string.Empty;
                        parEstilo    = string.Empty;
                    }

                    //string usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                    dtCalificacionesTda = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenResumenTda(marca, comprador, FchDe, FchHas, tipo, temporada, parTipoCalificacion, parFchCalificacion, parProveedor, parNombre, parEstilo, parDescripcion);
                    dgvGridView.DataSource = null;
                    if (dtCalificacionesTda.Rows.Count > 0)
                    {
                        SetDoubleBuffered(dgvGridView);
                        dgvGridView.DataSource = null;
                        dgvGridView.DataSource = dtCalificacionesTda;
                        nr = dgvGridView.RowCount;
                        this.Text = "Resumen Estilo Tienda/ " + " " + (nr-1).ToString() + " Registro(s)" + " / Proveedor: " + parProveedor + " Estilo: " + parEstilo + " " + parDescripcion;

                        lbIdProveedor.Text  = MmsWin.Front.Utilerias.VarTem.parProveedor;
                        lbDesProveedor.Text = varlocNombre;
                        lbIdEstilo.Text     = MmsWin.Front.Utilerias.VarTem.parEstilo;
                        lbDesEstilo.Text    = varLocDescripcion;

                        lbCosto.Text  = varlocCosto;
                        lbPrecio.Text = varlocPrecio;
                        lbMargen.Text = varlocMargen;

                        dgvGridView.DataSource = dtCalificacionesTda;
                        CreaCheckBox();
                        SetFontAndColors();
                        rowStyle();
                        dgvGridView.Focus();
                        dgvGridView.Select();
                        dgvGridView.CurrentCell = dgvGridView.Rows[0].Cells[1];
                        //this.dgvGridView.Sort(this.dgvGridView.Columns[0],
                        //ListSortDirection.Ascending);
                    }

                    this.Cursor = Cursors.Default;
                }

                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        private void SetFontAndColors()
        {
            int i = 0;
            try
            {
                this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
                this.dgvGridView.ColumnHeadersDefaultCellStyle.BackColor = Color.White;
                this.dgvGridView.EnableHeadersVisualStyles           = false;
                this.dgvGridView.DefaultCellStyle.Font               = new System.Drawing.Font("Verdana", 8);
                this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
                this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
                this.dgvGridView.CellBorderStyle                     = DataGridViewCellBorderStyle.Single;
                this.dgvGridView.RowsDefaultCellStyle.ForeColor      = Color.Black;
                //this.dgvGridView.RowHeadersVisible                   = false;
                //this.dgvGridView.Columns[""].Frozen = true;
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                dgvGridView.Columns["CALIFICACION"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["TIENDAS"].DefaultCellStyle.Alignment      = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["INVENTARIO"].DefaultCellStyle.Alignment   = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["PORCENTAJE"].DefaultCellStyle.Alignment   = DataGridViewContentAlignment.MiddleRight;

                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                dgvGridView.Columns["CALIFICACION"].Width = 100;
                dgvGridView.Columns["TIENDAS"].Width      = 60;
                dgvGridView.Columns["INVENTARIO"].Width   = 60;
                dgvGridView.Columns["PORCENTAJE"].Width   = 60;

                dgvGridView.Columns["CALIFICACION"].HeaderText = "Calificación";
                dgvGridView.Columns["TIENDAS"].HeaderText      = "Tiendas Calificadas";
                dgvGridView.Columns["INVENTARIO"].HeaderText   = "Inventario";
                dgvGridView.Columns["PORCENTAJE"].HeaderText   = "     % ";
                dgvGridView.Columns["COSTO"].HeaderText  = "Costo Actual";
                dgvGridView.Columns["PRECIO"].HeaderText = "Precio Nuevo";
                dgvGridView.Columns["MARGEN"].HeaderText = "Margen Nuevo";
                dgvGridView.Columns["PREMAN"].HeaderText = "Precio Final";
                //dgvGridView.Columns[9].HeaderText = "Acción";
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                dgvGridView.Columns["TIENDAS"].DefaultCellStyle.Format    = "###,##0";
                dgvGridView.Columns["INVENTARIO"].DefaultCellStyle.Format = "#,###,##0";
                dgvGridView.Columns["PORCENTAJE"].DefaultCellStyle.Format = "#,##0.00%";
                dgvGridView.Columns["PREMAN"].DefaultCellStyle.Format     = "#,##0.00";
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                dgvGridView.Columns["CALIFICACION"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["CALIFICACION"].HeaderCell.Style.ForeColor = Color.White;
                dgvGridView.Columns["TIENDAS"].HeaderCell.Style.BackColor      = Color.LightSlateGray;
                dgvGridView.Columns["TIENDAS"].HeaderCell.Style.ForeColor      = Color.White;
                dgvGridView.Columns["INVENTARIO"].HeaderCell.Style.BackColor   = Color.LightSlateGray;
                dgvGridView.Columns["INVENTARIO"].HeaderCell.Style.ForeColor   = Color.White;
                dgvGridView.Columns["PORCENTAJE"].HeaderCell.Style.BackColor   = Color.LightSlateGray;
                dgvGridView.Columns["PORCENTAJE"].HeaderCell.Style.ForeColor   = Color.White;
                //dgvGridView.Columns[9].HeaderCell.Style.BackColor = Color.LightSlateGray;
                //dgvGridView.Columns[9].HeaderCell.Style.ForeColor = Color.White;

                dgvGridView.Columns["COMPRAS"].Visible = false;
            }
            catch { }
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                dgvGridView.Select();

                // Pagar
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "P a g a r") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.LightGreen; }
                // 10%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "10%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.Yellow; }
                // 15%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "15%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "20%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "25%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "30%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "35%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "40%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.LightSalmon; }
                //Dev o 50%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "50%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.Red; rowp.Cells["CALIFICACION"].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "50%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.Red; rowp.Cells["CALIFICACION"].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "Devolución") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.Red; rowp.Cells["CALIFICACION"].Style.ForeColor = Color.White; }

                Regs += 1;
                //if (vez == "Si")
                //{
                dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.White;
                    //vez = "No";
                //}
                //else
                //{
                //    vez = "Si";
                //}

                if ((Convert.ToString((rowp.Cells[0].Value))) == "Total")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.SlateGray;
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.ForeColor = Color.White;  
            
                    // Totales por columna
                    // Suma Tiendas   
                    dgvGridView.Rows[Regs - 1].Cells[1].Value = "0";
                    int tot11 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[1].Value));
                    rowp.Cells[1].Value = tot11;
                    // Suma Inventario           
                    dgvGridView.Rows[Regs - 1].Cells[2].Value = "0";   
                    int tot12 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[2].Value));
                    rowp.Cells[2].Value = tot12;
                    // Suma Porcentaje        
                    dgvGridView.Rows[Regs - 1].Cells[3].Value = "0";
                    int tot31 = dgvGridView.Rows.Cast<DataGridViewRow>().Sum(t => Convert.ToInt32(t.Cells[3].Value));
                    if (tot31 == 0 )
                    {
                        tot31 = 1;
                    }
                    rowp.Cells[3].Value = tot31;
                }
                string Calificacion = dgvGridView.Rows[Regs - 1].Cells["CALIFICACION"].Value.ToString();
                if (Calificacion != "" && Calificacion != "P a g a r" && Calificacion != "Total" && Calificacion != "Devolución" && Calificacion != "0%")
                {
                    double por          = 0;
                    double costoActual  = 0;
                    double precioActual = 0;
                    double prcSinIva    = 0;
                    double cstEntrePrcSinIva = 0;

                    double costoNuevo  = 0;
                    double precioNuevo = 0;
                    double margenNuevo = 0;

                    costoActual  = Convert.ToDouble(lbCosto.Text);
                    precioActual = Convert.ToDouble(lbPrecio.Text);

                    string porcentaje = dgvGridView.Rows[Regs - 1].Cells["CALIFICACION"].Value.ToString();
                    porcentaje = porcentaje.Replace("%", "");
                    por = Convert.ToDouble(porcentaje);
                    por = por / 100;
                    costoNuevo = (1 - por) * costoActual;
                    costoNuevo = Math.Truncate(costoNuevo * 10000) / 10000;
                    dgvGridView.Rows[Regs - 1].Cells["COSTO"].Value = costoActual;
                    // - - - - - - - - - - - - - - - - - - - - - -
                    decimal Wprc;
                    decimal Wprc2;
                    //precioNuevo = (1 - por) * precioActual;
                    decimal cantidad = (decimal)(precioActual - (precioActual * por));
                    if (cantidad <= 20)
                    {
                        //  .99
                    }
                    else if (cantidad <= 50)
                    {
                        Wprc = cantidad / 5;
                        Wprc2 = Math.Truncate(Wprc);
                        cantidad = (decimal)((Wprc2 * 5) + (decimal)4.99);
                    }
                    else if (cantidad > 50)
                    {
                        Wprc = cantidad / 10;
                        Wprc2 = Math.Truncate(Wprc);
                        cantidad = (Wprc2 * 10) + (decimal)9.99;
                    }
                    precioNuevo = (double)cantidad;

                    precioNuevo = Math.Truncate(precioNuevo * 10000) / 10000;
                    dgvGridView.Rows[Regs - 1].Cells["PRECIO"].Value = precioNuevo;
                    // - - - - - - - - - - - - - - - - - - - - - -

                    prcSinIva = precioNuevo / 1.16;
                    cstEntrePrcSinIva = costoActual / prcSinIva;

                    margenNuevo = (1 - cstEntrePrcSinIva) * 100;
                    margenNuevo = Math.Truncate(margenNuevo * 10000) / 10000;
                    dgvGridView.Rows[Regs - 1].Cells["MARGEN"].Value = margenNuevo;

                    dgvGridView.Columns["MARGEN"].DefaultCellStyle.Format = "##,###.00";
                }  
            }
        }

        private void colorCalOriginal()
        {
            if (parCalificacionOriginal == "")
            {
                btCalOri.Text = parCalificacion;
            }
            else
            {
                btCalOri.Text = parCalificacionOriginal;
            }

            if (btCalOri.Text == "P a g a r")  { btCalOri.BackColor = Color.LightGreen;  } // Pagar
            if (btCalOri.Text == "10%")        { btCalOri.BackColor = Color.Yellow;      } // 10%
            if (btCalOri.Text == "15%")        { btCalOri.BackColor = Color.Yellow;      } // 15%
            if (btCalOri.Text == "20%")        { btCalOri.BackColor = Color.Yellow;      } // 20%
            if (btCalOri.Text == "25%")        { btCalOri.BackColor = Color.Yellow;      } // 25%
            if (btCalOri.Text == "30%")        { btCalOri.BackColor = Color.LightSalmon; } // 30%
            if (btCalOri.Text == "35%")        { btCalOri.BackColor = Color.LightSalmon; } // 35%
            if (btCalOri.Text == "40%")        { btCalOri.BackColor = Color.LightSalmon; } // 40%
            if (btCalOri.Text == "50%")        { btCalOri.BackColor = Color.Red; btCalOri.ForeColor = Color.White; } //Dev o 50%
            if (btCalOri.Text == "50%")        { btCalOri.BackColor = Color.Red; btCalOri.ForeColor = Color.White; } //Dev o 50%
            if (btCalOri.Text == "Devolución") { btCalOri.BackColor = Color.Red; btCalOri.ForeColor = Color.White; } // Devolucion
            if (btCalOri.Text == "Devolucion") { btCalOri.BackColor = Color.Red; btCalOri.ForeColor = Color.White; } // Devolucion
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        private void ResumenCalTda_Resize(object sender, EventArgs e)
        {
            dgvGridView.Width = this.Width - dgvOffset;
            dgvGridView.Height = this.Height - dgvOffset2;
        }

        private void dgvGridView_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                BinData();
                dgvGridView.Focus();
                dgvGridView.Select();
            }
        }

        private void dgvGridView_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                SendKeys.Send("{UP}");
                SendKeys.Flush();
            }
        }

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            marca = " ";
            ComboBox cmbMarca = (ComboBox)sender;
            marca = cmbMarca.SelectedValue.ToString();
            BinData();
        }

        private void tbTipoCalificacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void tbFchCalificacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void tbProveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void tbNombre_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void dgvGridView_Sorted(object sender, EventArgs e)
        {
            rowStyle();
        }

        private void cbComprador_SelectedValueChanged(object sender, EventArgs e)
        {
            comprador = " ";
            nr = 0;
            ComboBox cmbComprador = (ComboBox)sender;
            comprador = cmbComprador.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpComprador = cmbComprador.SelectedValue.ToString();

            BinData();
        }

        private void fotoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MuestraFoto();
        }

        private void MuestraFoto()
        {
            try
            {
                Fotos i = new Fotos();
                i.Show();
            }
            catch { }
            finally { }
        }

        private void dgvGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvGridView.Select();
            dgvGridView.Focus();
            Kardex();
        }

        private void Kardex()
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Kardex").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del Kardex ya esta abierta");
                    }
                    else
                    {
                        Kardex i = new Kardex();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void tbTabla_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbTipoCalificacion.Focus();
            }
        }

        private void tbTemporada_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbTipoCalificacion.Focus();
            }
        }

        private void dgvGridView_CellParsing(object sender, DataGridViewCellParsingEventArgs e)
        {
            int Row = e.RowIndex;
            int Col = e.ColumnIndex;
            string campo         = string.Empty;
            string checkBox      = string.Empty;
            string observaciones = string.Empty;
            string usuario       = string.Empty;
            string fechaUser     = string.Empty;
            string horaUser      = string.Empty;

            string marca     = MmsWin.Front.ConvenioMelody.ResumenCalTda.gridMarca         ;
            string fecha     = MmsWin.Front.ConvenioMelody.ResumenCalTda.gridFechaCalifica ;
            string tipo      = MmsWin.Front.ConvenioMelody.ResumenCalTda.gridTipoCalifica  ;
            string temporada = MmsWin.Front.ConvenioMelody.ResumenCalTda.gridTemporada     ;
            string tabla     = MmsWin.Front.ConvenioMelody.ResumenCalTda.gridTabla         ;
            string proveedor = MmsWin.Front.ConvenioMelody.ResumenCalTda.gridProveedor     ;
            string estilo    = MmsWin.Front.ConvenioMelody.ResumenCalTda.gridEstilo        ;
            string orden     = MmsWin.Front.ConvenioMelody.ResumenCalTda.gridOrden         ;

            DateTime hoy = DateTime.Now;

            fechaUser = hoy.Date.ToString("yyMMdd");
            horaUser = DateTime.Now.ToString("HHmmss");
            usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;

            campo = this.dgvGridView.Rows[Row].Cells[Col].OwningColumn.Name;
            if (campo == "CHKCOMP")
            {
                observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBC"].Value.ToString();
                Boolean chk = Convert.ToBoolean((this.dgvGridView.CurrentRow.Cells["CHKCOMP"].Value));
                if (chk == true)
                {
                    checkBox = "0";
                }
                else
                {
                    checkBox = "1";
                }
                MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateCheckBoxCompras(marca, fecha, tipo, temporada, tabla, proveedor, estilo,
                                                                                        orden, checkBox, observaciones, usuario, fechaUser, horaUser);
            }
            if (campo == "CHKCONTR")
            {
                observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBT"].Value.ToString();
                Boolean chk = Convert.ToBoolean((this.dgvGridView.CurrentRow.Cells["CHKCONTR"].Value));
                if (chk == true)
                {
                    checkBox = "0";
                }
                else
                {
                    checkBox = "1";
                }
                MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateCheckBoxContraloria(marca, fecha, tipo, temporada, tabla, proveedor, estilo,
                                                                                        orden, checkBox, observaciones, usuario, fechaUser, horaUser);
            }

        }

        private void dgvGridView_Sorted_1(object sender, EventArgs e)
        {
            rowStyle();
        }

        private void btMarcaChk_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                if ((Convert.ToString((rowp.Cells[0].Value))) != "Total")
                {
                    DataGridViewCheckBoxCell chk2 = (DataGridViewCheckBoxCell)rowp.Cells["COMPRAS"];
                    dgvGridView.BeginEdit(true);
                    chk2.Value = 1;
                    dgvGridView.BeginEdit(false);
                }
            }
        }

        private void btQuitaChks_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                if ((Convert.ToString((rowp.Cells[0].Value))) != "Total")
                {
                    DataGridViewCheckBoxCell chk2 = (DataGridViewCheckBoxCell)rowp.Cells["COMPRAS"];
                    dgvGridView.BeginEdit(true);
                    chk2.Value = 0;
                    dgvGridView.BeginEdit(false);
                }
            }
        }

        private void EliminacheckBox()
        {
            try
            {
                dgvGridView.Columns.Remove("COMPRAS");
            }
            catch { }
            try
            {
                dgvGridView.Columns.Remove("COSTO");
            }
            catch { }
            try
            {
                dgvGridView.Columns.Remove("PRECIO");
            }
            catch { }
            try
            {
                dgvGridView.Columns.Remove("MARGEN");
            }
            catch { }
            try
            {
                dgvGridView.Columns.Remove("PREMAN");
            }
            catch { }
        }

        private void CreaCheckBox()
        {
            DataGridViewColumn Costo = new DataGridViewTextBoxColumn();
            Costo.DataPropertyName = "Costo";
            Costo.Name = "Costo";
            dgvGridView.Columns.Add(Costo);
            dgvGridView.Columns["COSTO"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns["COSTO"].HeaderCell.Style.ForeColor = Color.White;
            dgvGridView.Columns["COSTO"].Width = 60;
            dgvGridView.Columns["COSTO"].DefaultCellStyle.Format = "#,###.00";
            dgvGridView.Columns["COSTO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            DataGridViewColumn Precio = new DataGridViewTextBoxColumn();
            Precio.DataPropertyName = "Precio";
            Precio.Name = "Precio";
            dgvGridView.Columns.Add(Precio);
            dgvGridView.Columns["PRECIO"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns["PRECIO"].HeaderCell.Style.ForeColor = Color.White;
            dgvGridView.Columns["PRECIO"].Width = 60;
            dgvGridView.Columns["PRECIO"].DefaultCellStyle.Format = "#,###.00";
            dgvGridView.Columns["PRECIO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            DataGridViewColumn Margen = new DataGridViewTextBoxColumn();
            Margen.DataPropertyName = "Margen";
            Margen.Name = "Margen";
            dgvGridView.Columns.Add(Margen);
            dgvGridView.Columns["MARGEN"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns["MARGEN"].HeaderCell.Style.ForeColor = Color.White;
            dgvGridView.Columns["MARGEN"].Width = 60;
            dgvGridView.Columns["MARGEN"].DefaultCellStyle.Format = "#,###.00";
            dgvGridView.Columns["MARGEN"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            DataGridViewColumn PreMan = new DataGridViewTextBoxColumn();
            PreMan.DataPropertyName = "PREMAN";
            PreMan.Name = "PREMAN";
            dgvGridView.Columns.Add(PreMan);
            dgvGridView.Columns["PREMAN"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns["PREMAN"].HeaderCell.Style.ForeColor = Color.White;
            dgvGridView.Columns["PREMAN"].Width = 60;
            dgvGridView.Columns["PREMAN"].DefaultCellStyle.Format = "#,###.00";
            dgvGridView.Columns["PREMAN"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            DataGridViewCheckBoxColumn Compras = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(Compras);
            dgvGridView.Columns[8].Name = "COMPRAS";
            dgvGridView.Columns[8].HeaderText = "Revisado Comprador";
            dgvGridView.Columns[8].Width = 65;
            dgvGridView.Columns[8].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[8].HeaderCell.Style.ForeColor = Color.White;

            //DataGridViewButtonColumn buttons = new DataGridViewButtonColumn();
            //{
            //    buttons.HeaderText = "Accion";
            //    buttons.Text       = "Aplicar";
            //    buttons.UseColumnTextForButtonValue = true;
            //    buttons.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            //    buttons.FlatStyle    = FlatStyle.Standard;
            //    buttons.CellTemplate.Style.BackColor = Color.Honeydew;
            //    buttons.DisplayIndex = 9;
            //}
            //dgvGridView.Columns.Add(buttons);


        }

        private void detalleCalNivEstTSMI_Click(object sender, EventArgs e)
        {
            if (parEstilo != "")
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "CalificacionGridTdaMasivo").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana del Convenio Melody ya esta abierta");
                    }
                    else
                    {
                        CalificacionGridTdaMasivo i = new CalificacionGridTdaMasivo();
                        i.Show();
                    }
                }
            }
            else
            {
                MessageBox.Show("No hay Estilo Seleccionado...");
            }
        }

        private void dgvGridView_SelectionChanged(object sender, EventArgs e)
        {
            cargaVariables();
        }

        private void cargaVariables()
        {
            try
            {
                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parCstActual = string.Empty;
                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parPrcActual = string.Empty;
                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parMrgActual = string.Empty;

                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parCstNuevo = string.Empty;
                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parPrcNuevo = string.Empty;
                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parMrgNuevo = string.Empty;

                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parPrcFinal = string.Empty;
                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parPorCal   = string.Empty;

                MmsWin.Front.ConvenioMelody.ResumenGlobal.parCalificacion             = this.dgvGridView.CurrentRow.Cells["CALIFICACION"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parCalificacion = this.dgvGridView.CurrentRow.Cells["CALIFICACION"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parOrigen       = "Global";

                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parCalificacion = this.dgvGridView.CurrentRow.Cells["CALIFICACION"].Value.ToString();
                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parOrigen = "Global";

                MmsWin.Front.ConvenioMelody.ResumenCalTda.parCalificacion = this.dgvGridView.CurrentRow.Cells["CALIFICACION"].Value.ToString();
                MmsWin.Front.ConvenioMelody.ResumenCalTda.parOrigen = "Global";

                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parCstActual = lbCosto.Text;
                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parPrcActual = lbPrecio.Text;    
                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parMrgActual = lbMargen.Text;

                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parCstNuevo = this.dgvGridView.CurrentRow.Cells["COSTO"].Value.ToString();
                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parPrcNuevo = this.dgvGridView.CurrentRow.Cells["PRECIO"].Value.ToString();
                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parMrgNuevo = this.dgvGridView.CurrentRow.Cells["MARGEN"].Value.ToString();

                try
                {
                    MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parPrcFinal = this.dgvGridView.CurrentRow.Cells["PREMAN"].Value.ToString();
                }
                catch { }

                double por = 0;
                string porcentaje = this.dgvGridView.CurrentRow.Cells["CALIFICACION"].Value.ToString();
                porcentaje = porcentaje.Replace("%", "");
                por = Convert.ToDouble(porcentaje);
                por = por / 100;
                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parPorCal = Convert.ToString(por);
            }
            catch { }
        }

        private void pbSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ResumenCalTda_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void ResumenCalTda_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedownpoint.IsEmpty)
                return;
            Form f = sender as Form;
            f.Location = new Point(f.Location.X + (e.X - mousedownpoint.X), f.Location.Y + (e.Y - mousedownpoint.Y));
        }

        private void ResumenCalTda_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

        private void pbSalir_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pbFoto_Click(object sender, EventArgs e)
        {
            MuestraFoto();
        }

        private void rebajaDiferenciadaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (parEstilo != "")
            {

                try
                {
                    Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                                  "MasivoDiferenciado").SingleOrDefault<Form>();
                    {
                        if (existe != null)
                        {
                            MessageBox.Show("La Ventana ya esta abierta...");
                        }
                        else
                        {
                            string FechaBon = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
                            if (FechaBon != null)
                            {
                                string calificaion = MmsWin.Front.ConvenioMelody.CalificacionGrid.gridCalificacion;
                                string convMarcaNo = MmsWin.Front.ConvenioMelody.CalificacionGrid.gridMarca;

                                string FechaBinificacion = FechaBon.Substring(8, 2) + FechaBon.Substring(3, 2) + FechaBon.Substring(0, 2);
                                string FechaAbierta      = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenMarcaConfiguracion1(convMarcaNo);
                                if (FechaBinificacion == FechaAbierta)
                                {
                                    MessageBox.Show("La Rebaja se va a concentrar en la fecha :" + FechaBon);
                                    RecuperaMovimientosDiferenciados();
                                    MmsWin.Front.ConvenioMelody.MasivoDiferenciado.ParFchBon = FechaBinificacion;
                                    MasivoDiferenciado i = new MasivoDiferenciado();
                                    i.Show();
                                }
                                else
                                {
                                    MessageBox.Show("La fecha " + FechaBon + " No esta abierta para captura de Notas de Credito");
                                }
                            }
                            else
                            {
                                MessageBox.Show("La ventana de Calificacion no esta abierta...");
                            }
                        }
                    }
                }
                catch { }
                finally { }
            }
            else
            {
                MessageBox.Show("No Hay Estilo Seleccionado...");
            }
        }

        private void RecuperaMovimientosDiferenciados()
        {
            System.Data.DataTable dtDiferenciados = new System.Data.DataTable("Diferenciados");
            dtDiferenciados.Columns.Add("ParTipo", typeof(String));
            dtDiferenciados.Columns.Add("ParTemporada", typeof(String));
            dtDiferenciados.Columns.Add("ParTienda", typeof(String));

            DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                DataRow workRow = dtDiferenciados.NewRow();
                workRow["ParTipo"] = item.Cells["MDYTPO"].Value.ToString();
                workRow["ParTemporada"] = item.Cells["MDYTMP"].Value.ToString();
                workRow["ParTienda"] = item.Cells["MDYTDA"].Value.ToString();

                dtDiferenciados.Rows.Add(workRow);
            }

            int regs = dtDiferenciados.Rows.Count;
            if (regs == 0)
            {
                DataRow workRow = dtDiferenciados.NewRow();
                workRow["ParTipo"] = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTipoCalifica;
                workRow["ParTemporada"] = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTemporada;
                workRow["ParTienda"] = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTienda;

                dtDiferenciados.Rows.Add(workRow);
            }


            MmsWin.Front.ConvenioMelody.NotaDiferenciada.dtDiferenciados = dtDiferenciados;
        }

        private void dgvGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Seleccion = string.Empty;
            Seleccion = this.dgvGridView.CurrentRow.Cells["CALIFICACION"].Value.ToString();
            if (Seleccion != "Total" && Seleccion != "P a g a r" && Seleccion != "")
            {
                cargaVariables();
            }
            else
            {
                Seleccion = string.Empty;
                MessageBox.Show("Error en la selección. Este registro no es valido");
            }
        }

        private void btAplicar_Click(object sender, EventArgs e)
        {
            if (Seleccion != "")
            {
                string FechaBon = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
                string FechaBinificacion = FechaBon.Substring(8, 2) + FechaBon.Substring(3, 2) + FechaBon.Substring(0, 2);
                ParFchBon = FechaBinificacion;

                DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
                foreach (DataGridViewRow rowp in Seleccionados)
                {
                    string message = "Se va a concentrar la rebaja diferenciada en la fecha: " + FechaBon;
                    string caption = "Confirmar";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result;
                    result = MessageBox.Show(message, caption, buttons);
                    if (result == System.Windows.Forms.DialogResult.Yes)
                    {
                        string tipo      = string.Empty;
                        string temporada = string.Empty;
                        string comprador = string.Empty;
                        string tipoCalificacion = string.Empty;
                        string tabla     = string.Empty;
                        string fchCalificacion = string.Empty;
                        string proveedor    = string.Empty;
                        string estilo       = string.Empty;
                        string calificacion = string.Empty;
                        string nombre       = string.Empty;
                        string descripcion  = string.Empty;

                        comprador = parComprador;
                        FchDe     = parFchDesde;
                        FchHas    = parFchHasta;
                        temporada = parTemporada;
                        tipoCalificacion = parTipoCalificacion;
                        fchCalificacion  = parFchCalificacion;
                        proveedor    = parProveedor;
                        nombre       = parNombre;
                        estilo       = parEstilo;
                        descripcion  = parDescripcion;
                        calificacion = parCalificacion;

                        dtDiferenciados = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenCalificaionTdaXcalificacion(parMarca, comprador, FchDe, FchHas, temporada, tipoCalificacion, parFchCalificacion, parProveedor, parNombre, parEstilo, parDescripcion, parCalificacion, parOrigen);

                        GuardarNota();
                    }
                    else
                    {
                        MessageBox.Show("El proceso fue cancelado por el Usuario.");
                    }
                }
            }
            else
            {
                MessageBox.Show("No hay Registro seleccionado...");
            }
        }

        private void GuardarNota()
        {
            string ParTipo = string.Empty;
            string ParTemporada = string.Empty;
            string ParTienda = string.Empty;
            string ParFchRev = string.Empty;
            string ParProveedor = string.Empty;
            string PartbEstilo = string.Empty;

            string TpoMov = "RBD";
            string TpoCal = "NOR";

            System.Data.DataTable dtGuardaNota = null;

            string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
            string ParNotCal = "DIFERENCIADO";

            string ParSubtot = string.Empty;
            string ParPorc = "0";

            ParPorc = ParPorc.Replace(".", "");
            String RutaPdf = MmsWin.Front.Utilerias.VarTem.tmpDestNcPDF;

            foreach (DataRow row1 in dtDiferenciados.Rows)
            {
                if (row1["MDYTDD"].ToString() != "Total")
                {
                    ParTipo      = row1["MDYTPO"].ToString();
                    ParTemporada = row1["MDYTMP"].ToString();
                    ParTienda    = row1["MDYTDA"].ToString();
                    ParFchRev    = row1["MDYFCH"].ToString();
                    ParProveedor = row1["MDYPRV"].ToString();
                    PartbEstilo  = row1["MDYSTY"].ToString();

                    string varInd1 = "0";
                    string varInd2 = "0";

                    siHuboRebaja = "No";
                    dtGuardaNota = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().GuardaNotaDiferenciada(ParFchBon, ParFchRev, ParTipo, ParTemporada, ParTienda, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, ParPorc, varInd1, varInd2, TpoMov, TpoCal, RutaPdf);

                    if (dtGuardaNota.Rows.Count > 0)
                    {
                        foreach (DataRow row in dtGuardaNota.Rows)
                        {

                            varInd1 = row["NOTIN1"].ToString();
                            varInd2 = row["NOTIN2"].ToString();

                            if (varInd1 == "1" && varInd2 == "0")
                            {
                                siHuboRebaja = "Si";
                            }
                            else
                            {
                                if (varInd2 == "1")
                                {
                                    string message = "Ya existe La Rebaja, Haz Click en (Si) para remplazar ";
                                    string caption = "Aviso";
                                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                                    DialogResult result;
                                    result = MessageBox.Show(message, caption, buttons);
                                    if (result == System.Windows.Forms.DialogResult.Yes)
                                    {
                                        varInd1 = "2";
                                        varInd2 = "2";
                                        RutaPdf = MmsWin.Front.Utilerias.VarTem.tmpRutaPdf;
                                        MmsWin.Negocio.Utilerias.Utilerias.GetInstance().GuardaNotaDiferenciada(ParFchBon, ParFchRev, ParTipo, ParTemporada, ParTienda, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, ParPorc, varInd1, varInd2, TpoMov, TpoCal, RutaPdf);
                                        MessageBox.Show("Se actualizo la Rebaja exitosamente");
                                        this.Close();
                                    }
                                    else
                                    {
                                        romperForeach = "Si";
                                        break;
                                    }
                                }
                            }

                        }

                        if (romperForeach == "Si")
                        {
                            break;
                        }
                    }
                }
            }
            if (siHuboRebaja == "Si")
            {
                MessageBox.Show("Se guardó la Reabaja exitosamente");
                //this.Close();
            }
        }
    }
}
