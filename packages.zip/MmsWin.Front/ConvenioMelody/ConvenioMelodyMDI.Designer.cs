﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class ConvenioMelodyMDI
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConvenioMelodyMDI));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolBarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusBarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.windowsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.cascadeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tileVerticalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tileHorizontalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.closeAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.arrangeIconsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.contentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.indexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.TemporadasTSB = new System.Windows.Forms.ToolStripButton();
            this.tsbTablaCalificacion = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.CalendarioDeProgTSB = new System.Windows.Forms.ToolStripButton();
            this.ConsultaCalificacionesTSB = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.RebajaDiferenciadaTSB = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.DocDiferenciadosTSB = new System.Windows.Forms.ToolStripButton();
            this.tss1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsddbReportes = new System.Windows.Forms.ToolStripDropDownButton();
            this.tsmiReprogramaciones = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiCambioCalificacion = new System.Windows.Forms.ToolStripMenuItem();
            this.pbReprogramaciones = new System.Windows.Forms.ToolStripButton();
            this.pbAdministracion = new System.Windows.Forms.ToolStripButton();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip.SuspendLayout();
            this.toolStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenu,
            this.viewMenu,
            this.toolsMenu,
            this.windowsMenu,
            this.helpMenu});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.MdiWindowListItem = this.windowsMenu;
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(1181, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // fileMenu
            // 
            this.fileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.toolStripSeparator3,
            this.toolStripSeparator4,
            this.printPreviewToolStripMenuItem,
            this.toolStripSeparator5,
            this.exitToolStripMenuItem});
            this.fileMenu.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.fileMenu.Name = "fileMenu";
            this.fileMenu.Size = new System.Drawing.Size(60, 20);
            this.fileMenu.Text = "&Archivo";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.newToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.newToolStripMenuItem.Text = "&Evento de Calificación";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(231, 6);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(231, 6);
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("printPreviewToolStripMenuItem.Image")));
            this.printPreviewToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.printPreviewToolStripMenuItem.Text = "Consulta de Calificaciones";
            this.printPreviewToolStripMenuItem.Click += new System.EventHandler(this.printPreviewToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(231, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(234, 22);
            this.exitToolStripMenuItem.Text = "&Salir";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolsStripMenuItem_Click);
            // 
            // viewMenu
            // 
            this.viewMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolBarToolStripMenuItem,
            this.statusBarToolStripMenuItem});
            this.viewMenu.Name = "viewMenu";
            this.viewMenu.Size = new System.Drawing.Size(35, 20);
            this.viewMenu.Text = "&Ver";
            // 
            // toolBarToolStripMenuItem
            // 
            this.toolBarToolStripMenuItem.Checked = true;
            this.toolBarToolStripMenuItem.CheckOnClick = true;
            this.toolBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.toolBarToolStripMenuItem.Name = "toolBarToolStripMenuItem";
            this.toolBarToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.toolBarToolStripMenuItem.Text = "&Barra de herramientas";
            this.toolBarToolStripMenuItem.Click += new System.EventHandler(this.ToolBarToolStripMenuItem_Click);
            // 
            // statusBarToolStripMenuItem
            // 
            this.statusBarToolStripMenuItem.Checked = true;
            this.statusBarToolStripMenuItem.CheckOnClick = true;
            this.statusBarToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.statusBarToolStripMenuItem.Name = "statusBarToolStripMenuItem";
            this.statusBarToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.statusBarToolStripMenuItem.Text = "&Barra de estado";
            this.statusBarToolStripMenuItem.Click += new System.EventHandler(this.StatusBarToolStripMenuItem_Click);
            // 
            // toolsMenu
            // 
            this.toolsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem});
            this.toolsMenu.Name = "toolsMenu";
            this.toolsMenu.Size = new System.Drawing.Size(90, 20);
            this.toolsMenu.Text = "&Herramientas";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.optionsToolStripMenuItem.Text = "&Opciones";
            // 
            // windowsMenu
            // 
            this.windowsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cascadeToolStripMenuItem,
            this.tileVerticalToolStripMenuItem,
            this.tileHorizontalToolStripMenuItem,
            this.closeAllToolStripMenuItem,
            this.arrangeIconsToolStripMenuItem});
            this.windowsMenu.Name = "windowsMenu";
            this.windowsMenu.Size = new System.Drawing.Size(66, 20);
            this.windowsMenu.Text = "&Ventanas";
            // 
            // cascadeToolStripMenuItem
            // 
            this.cascadeToolStripMenuItem.Name = "cascadeToolStripMenuItem";
            this.cascadeToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.cascadeToolStripMenuItem.Text = "&Cascada";
            this.cascadeToolStripMenuItem.Click += new System.EventHandler(this.CascadeToolStripMenuItem_Click);
            // 
            // tileVerticalToolStripMenuItem
            // 
            this.tileVerticalToolStripMenuItem.Name = "tileVerticalToolStripMenuItem";
            this.tileVerticalToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.tileVerticalToolStripMenuItem.Text = "Mosaico &vertical";
            this.tileVerticalToolStripMenuItem.Click += new System.EventHandler(this.TileVerticalToolStripMenuItem_Click);
            // 
            // tileHorizontalToolStripMenuItem
            // 
            this.tileHorizontalToolStripMenuItem.Name = "tileHorizontalToolStripMenuItem";
            this.tileHorizontalToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.tileHorizontalToolStripMenuItem.Text = "Mosaico &horizontal";
            this.tileHorizontalToolStripMenuItem.Click += new System.EventHandler(this.TileHorizontalToolStripMenuItem_Click);
            // 
            // closeAllToolStripMenuItem
            // 
            this.closeAllToolStripMenuItem.Name = "closeAllToolStripMenuItem";
            this.closeAllToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.closeAllToolStripMenuItem.Text = "C&errar todo";
            this.closeAllToolStripMenuItem.Click += new System.EventHandler(this.CloseAllToolStripMenuItem_Click);
            // 
            // arrangeIconsToolStripMenuItem
            // 
            this.arrangeIconsToolStripMenuItem.Name = "arrangeIconsToolStripMenuItem";
            this.arrangeIconsToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.arrangeIconsToolStripMenuItem.Text = "&Organizar iconos";
            this.arrangeIconsToolStripMenuItem.Click += new System.EventHandler(this.ArrangeIconsToolStripMenuItem_Click);
            // 
            // helpMenu
            // 
            this.helpMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contentsToolStripMenuItem,
            this.indexToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.toolStripSeparator8,
            this.aboutToolStripMenuItem});
            this.helpMenu.Name = "helpMenu";
            this.helpMenu.Size = new System.Drawing.Size(53, 20);
            this.helpMenu.Text = "Ay&uda";
            // 
            // contentsToolStripMenuItem
            // 
            this.contentsToolStripMenuItem.Name = "contentsToolStripMenuItem";
            this.contentsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F1)));
            this.contentsToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.contentsToolStripMenuItem.Text = "&Contenido";
            // 
            // indexToolStripMenuItem
            // 
            this.indexToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("indexToolStripMenuItem.Image")));
            this.indexToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.indexToolStripMenuItem.Name = "indexToolStripMenuItem";
            this.indexToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.indexToolStripMenuItem.Text = "&Índice";
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("searchToolStripMenuItem.Image")));
            this.searchToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.searchToolStripMenuItem.Text = "&Buscar";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(173, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.aboutToolStripMenuItem.Text = "&Acerca de... ...";
            // 
            // toolStrip
            // 
            this.toolStrip.ImageScalingSize = new System.Drawing.Size(23, 23);
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.TemporadasTSB,
            this.tsbTablaCalificacion,
            this.toolStripSeparator2,
            this.CalendarioDeProgTSB,
            this.ConsultaCalificacionesTSB,
            this.toolStripSeparator1,
            this.RebajaDiferenciadaTSB,
            this.toolStripSeparator6,
            this.DocDiferenciadosTSB,
            this.tss1,
            this.tsddbReportes,
            this.pbReprogramaciones,
            this.pbAdministracion});
            this.toolStrip.Location = new System.Drawing.Point(0, 24);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(1181, 39);
            this.toolStrip.TabIndex = 1;
            this.toolStrip.Text = "ToolStrip";
            // 
            // TemporadasTSB
            // 
            this.TemporadasTSB.Image = global::MmsWin.Front.Properties.Resources.Temporadas05;
            this.TemporadasTSB.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.TemporadasTSB.Name = "TemporadasTSB";
            this.TemporadasTSB.Size = new System.Drawing.Size(72, 36);
            this.TemporadasTSB.Text = "Grupos";
            this.TemporadasTSB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TemporadasTSB.Click += new System.EventHandler(this.TemporadasTSB_Click);
            // 
            // tsbTablaCalificacion
            // 
            this.tsbTablaCalificacion.Image = global::MmsWin.Front.Properties.Resources.discount_64_64;
            this.tsbTablaCalificacion.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbTablaCalificacion.Name = "tsbTablaCalificacion";
            this.tsbTablaCalificacion.Size = new System.Drawing.Size(152, 36);
            this.tsbTablaCalificacion.Text = "Tablas de Rentabilidad";
            this.tsbTablaCalificacion.Click += new System.EventHandler(this.tsbTablaCalificacion_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 39);
            // 
            // CalendarioDeProgTSB
            // 
            this.CalendarioDeProgTSB.Image = global::MmsWin.Front.Properties.Resources.calendar_64_64;
            this.CalendarioDeProgTSB.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.CalendarioDeProgTSB.Name = "CalendarioDeProgTSB";
            this.CalendarioDeProgTSB.Size = new System.Drawing.Size(183, 36);
            this.CalendarioDeProgTSB.Text = "Calendario de Calificaciones";
            this.CalendarioDeProgTSB.Click += new System.EventHandler(this.CalendarioDeProgTSB_Click);
            // 
            // ConsultaCalificacionesTSB
            // 
            this.ConsultaCalificacionesTSB.Image = ((System.Drawing.Image)(resources.GetObject("ConsultaCalificacionesTSB.Image")));
            this.ConsultaCalificacionesTSB.ImageTransparentColor = System.Drawing.Color.Black;
            this.ConsultaCalificacionesTSB.Name = "ConsultaCalificacionesTSB";
            this.ConsultaCalificacionesTSB.Size = new System.Drawing.Size(173, 36);
            this.ConsultaCalificacionesTSB.Text = "Consulta de Calificaciones";
            this.ConsultaCalificacionesTSB.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ConsultaCalificacionesTSB.Click += new System.EventHandler(this.ConsultaCalificacionesTSB_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 39);
            // 
            // RebajaDiferenciadaTSB
            // 
            this.RebajaDiferenciadaTSB.Image = global::MmsWin.Front.Properties.Resources.Etiq_031;
            this.RebajaDiferenciadaTSB.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.RebajaDiferenciadaTSB.Name = "RebajaDiferenciadaTSB";
            this.RebajaDiferenciadaTSB.Size = new System.Drawing.Size(138, 36);
            this.RebajaDiferenciadaTSB.Text = "Rebaja Diferenciada";
            this.RebajaDiferenciadaTSB.Click += new System.EventHandler(this.RebajaDiferenciadaTSB_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 39);
            // 
            // DocDiferenciadosTSB
            // 
            this.DocDiferenciadosTSB.Image = global::MmsWin.Front.Properties.Resources.Documentos;
            this.DocDiferenciadosTSB.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.DocDiferenciadosTSB.Name = "DocDiferenciadosTSB";
            this.DocDiferenciadosTSB.Size = new System.Drawing.Size(102, 36);
            this.DocDiferenciadosTSB.Text = "Documentos";
            this.DocDiferenciadosTSB.Click += new System.EventHandler(this.DocDiferenciadosTSB_Click);
            // 
            // tss1
            // 
            this.tss1.Name = "tss1";
            this.tss1.Size = new System.Drawing.Size(6, 39);
            // 
            // tsddbReportes
            // 
            this.tsddbReportes.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiReprogramaciones,
            this.tsmiCambioCalificacion});
            this.tsddbReportes.Image = global::MmsWin.Front.Properties.Resources.contract_32x32;
            this.tsddbReportes.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsddbReportes.Name = "tsddbReportes";
            this.tsddbReportes.Size = new System.Drawing.Size(89, 36);
            this.tsddbReportes.Text = "Reportes";
            this.tsddbReportes.Click += new System.EventHandler(this.toolStripDropDownButton1_Click);
            // 
            // tsmiReprogramaciones
            // 
            this.tsmiReprogramaciones.Name = "tsmiReprogramaciones";
            this.tsmiReprogramaciones.Size = new System.Drawing.Size(260, 22);
            this.tsmiReprogramaciones.Text = "Excepciones reprogramación";
            this.tsmiReprogramaciones.Click += new System.EventHandler(this.TSMI_Click);
            // 
            // tsmiCambioCalificacion
            // 
            this.tsmiCambioCalificacion.Name = "tsmiCambioCalificacion";
            this.tsmiCambioCalificacion.Size = new System.Drawing.Size(260, 22);
            this.tsmiCambioCalificacion.Text = "Excepciones cambio de calificación";
            this.tsmiCambioCalificacion.Click += new System.EventHandler(this.TSMI_Click);
            // 
            // pbReprogramaciones
            // 
            this.pbReprogramaciones.AutoSize = false;
            this.pbReprogramaciones.Image = global::MmsWin.Front.Properties.Resources.calendar_32x32;
            this.pbReprogramaciones.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pbReprogramaciones.Name = "pbReprogramaciones";
            this.pbReprogramaciones.Size = new System.Drawing.Size(170, 36);
            this.pbReprogramaciones.Text = "Reprogramaciones";
            this.pbReprogramaciones.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.pbReprogramaciones.ToolTipText = "Histórico de Reprogramaciones";
            this.pbReprogramaciones.Click += new System.EventHandler(this.pbReprogramaciones_Click);
            // 
            // pbAdministracion
            // 
            this.pbAdministracion.Image = ((System.Drawing.Image)(resources.GetObject("pbAdministracion.Image")));
            this.pbAdministracion.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pbAdministracion.Name = "pbAdministracion";
            this.pbAdministracion.Size = new System.Drawing.Size(115, 27);
            this.pbAdministracion.Text = "Administración";
            this.pbAdministracion.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.pbAdministracion.Click += new System.EventHandler(this.pbAdministracion_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 551);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1181, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(42, 17);
            this.toolStripStatusLabel.Text = "Estado";
            // 
            // ConvenioMelodyMDI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1181, 573);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.toolStrip);
            this.Controls.Add(this.menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "ConvenioMelodyMDI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Convenio";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ConvenioMelodyMDI_FormClosing);
            this.Load += new System.EventHandler(this.ConvenioMelodyMDI_Load);
            this.Enter += new System.EventHandler(this.ConvenioMelodyMDI_Enter);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ConvenioMelodyMDI_KeyUp);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileHorizontalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileMenu;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewMenu;
        private System.Windows.Forms.ToolStripMenuItem toolBarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem statusBarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolsMenu;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem windowsMenu;
        private System.Windows.Forms.ToolStripMenuItem cascadeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tileVerticalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem closeAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem arrangeIconsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpMenu;
        private System.Windows.Forms.ToolStripMenuItem contentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem indexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton ConsultaCalificacionesTSB;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripButton TemporadasTSB;
        private System.Windows.Forms.ToolStripButton CalendarioDeProgTSB;
        private System.Windows.Forms.ToolStripButton tsbTablaCalificacion;
        private System.Windows.Forms.ToolStripSeparator tss1;
        private System.Windows.Forms.ToolStripDropDownButton tsddbReportes;
        private System.Windows.Forms.ToolStripMenuItem tsmiReprogramaciones;
        private System.Windows.Forms.ToolStripMenuItem tsmiCambioCalificacion;
        private System.Windows.Forms.ToolStripButton RebajaDiferenciadaTSB;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton DocDiferenciadosTSB;
        private System.Windows.Forms.ToolStripButton pbReprogramaciones;
        private System.Windows.Forms.ToolStripButton pbAdministracion;
    }
}



