﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class CalificacionGrid
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.cmMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tsmiExcepciones = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiReprogramaciones = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiBonificacionPorDevolucion = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiDevolucionBonificacion = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiCambioCalificacion = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmOtros = new System.Windows.Forms.ToolStripMenuItem();
            this.kardexTlSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.notaDeCréditoTlSM = new System.Windows.Forms.ToolStripMenuItem();
            this.devoluciónTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.TlSMI_Div = new System.Windows.Forms.ToolStripMenuItem();
            this.convAntTlSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.tbProveedor = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbFill = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.gbOrigen = new System.Windows.Forms.GroupBox();
            this.cbOrigen = new System.Windows.Forms.ComboBox();
            this.gbMarca = new System.Windows.Forms.GroupBox();
            this.cbMarca = new System.Windows.Forms.ComboBox();
            this.gbComprador = new System.Windows.Forms.GroupBox();
            this.cbComprador = new System.Windows.Forms.ComboBox();
            this.gbRangoFechas = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbHasta = new System.Windows.Forms.TextBox();
            this.tbDesde = new System.Windows.Forms.TextBox();
            this.gbTemporada = new System.Windows.Forms.GroupBox();
            this.cbTemporada = new System.Windows.Forms.ComboBox();
            this.mcC2 = new System.Windows.Forms.MonthCalendar();
            this.mcC1 = new System.Windows.Forms.MonthCalendar();
            this.cbTipoConsulta = new System.Windows.Forms.ComboBox();
            this.gbTipoConsulta = new System.Windows.Forms.GroupBox();
            this.tbTemporada = new System.Windows.Forms.TextBox();
            this.tbTipoCalificacion = new System.Windows.Forms.TextBox();
            this.tbFchCalificacion = new System.Windows.Forms.TextBox();
            this.tbTabla = new System.Windows.Forms.TextBox();
            this.btResumenGlobal = new System.Windows.Forms.Button();
            this.btResumenXtienda = new System.Windows.Forms.Button();
            this.btCalificacionXtienda = new System.Windows.Forms.Button();
            this.btExcel = new System.Windows.Forms.Button();
            this.pgbProg = new System.Windows.Forms.ProgressBar();
            this.btRsmTda = new System.Windows.Forms.Button();
            this.btRsmGral = new System.Windows.Forms.Button();
            this.btRsmxDepto = new System.Windows.Forms.Button();
            this.btRsmPrv = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.cmMenuStrip.SuspendLayout();
            this.gbOrigen.SuspendLayout();
            this.gbMarca.SuspendLayout();
            this.gbComprador.SuspendLayout();
            this.gbRangoFechas.SuspendLayout();
            this.gbTemporada.SuspendLayout();
            this.gbTipoConsulta.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.ContextMenuStrip = this.cmMenuStrip;
            this.dgvGridView.Location = new System.Drawing.Point(9, 81);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.Size = new System.Drawing.Size(1015, 475);
            this.dgvGridView.TabIndex = 0;
            this.dgvGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellClick);
            this.dgvGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellDoubleClick);
            this.dgvGridView.CellParsing += new System.Windows.Forms.DataGridViewCellParsingEventHandler(this.dgvGridView_CellParsing);
            this.dgvGridView.SelectionChanged += new System.EventHandler(this.dgvGridView_SelectionChanged);
            this.dgvGridView.Sorted += new System.EventHandler(this.dgvGridView_Sorted);
            this.dgvGridView.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dgvGridView_KeyPress);
            this.dgvGridView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvGridView_KeyUp);
            // 
            // cmMenuStrip
            // 
            this.cmMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiExcepciones,
            this.tsmiReprogramaciones,
            this.tsmiBonificacionPorDevolucion,
            this.tsmiDevolucionBonificacion,
            this.tsmiCambioCalificacion,
            this.tsmOtros,
            this.kardexTlSMI,
            this.notaDeCréditoTlSM,
            this.devoluciónTSMI,
            this.TlSMI_Div,
            this.convAntTlSMI});
            this.cmMenuStrip.Name = "cmMenuStrip";
            this.cmMenuStrip.Size = new System.Drawing.Size(225, 246);
            // 
            // tsmiExcepciones
            // 
            this.tsmiExcepciones.BackColor = System.Drawing.Color.Gray;
            this.tsmiExcepciones.ForeColor = System.Drawing.Color.White;
            this.tsmiExcepciones.Name = "tsmiExcepciones";
            this.tsmiExcepciones.Size = new System.Drawing.Size(224, 22);
            this.tsmiExcepciones.Text = "EXCEPCIONES";
            // 
            // tsmiReprogramaciones
            // 
            this.tsmiReprogramaciones.Name = "tsmiReprogramaciones";
            this.tsmiReprogramaciones.Size = new System.Drawing.Size(224, 22);
            this.tsmiReprogramaciones.Text = "Reprogramaciones";
            this.tsmiReprogramaciones.Click += new System.EventHandler(this.tsmiReprogramaciones_Click);
            // 
            // tsmiBonificacionPorDevolucion
            // 
            this.tsmiBonificacionPorDevolucion.Name = "tsmiBonificacionPorDevolucion";
            this.tsmiBonificacionPorDevolucion.Size = new System.Drawing.Size(224, 22);
            this.tsmiBonificacionPorDevolucion.Text = "Bonificación por devolución";
            this.tsmiBonificacionPorDevolucion.Click += new System.EventHandler(this.tsmiBonificacionPorDevolucion_Click);
            // 
            // tsmiDevolucionBonificacion
            // 
            this.tsmiDevolucionBonificacion.Name = "tsmiDevolucionBonificacion";
            this.tsmiDevolucionBonificacion.Size = new System.Drawing.Size(224, 22);
            this.tsmiDevolucionBonificacion.Text = "Devolución por bonificación";
            this.tsmiDevolucionBonificacion.Click += new System.EventHandler(this.tsmiDevolucionBonificacion_Click);
            // 
            // tsmiCambioCalificacion
            // 
            this.tsmiCambioCalificacion.Name = "tsmiCambioCalificacion";
            this.tsmiCambioCalificacion.Size = new System.Drawing.Size(224, 22);
            this.tsmiCambioCalificacion.Text = "Cambio de calificación";
            this.tsmiCambioCalificacion.Click += new System.EventHandler(this.tsmiCambioCalificacion_Click);
            // 
            // tsmOtros
            // 
            this.tsmOtros.BackColor = System.Drawing.Color.Gray;
            this.tsmOtros.ForeColor = System.Drawing.Color.White;
            this.tsmOtros.Name = "tsmOtros";
            this.tsmOtros.Size = new System.Drawing.Size(224, 22);
            this.tsmOtros.Text = "OTROS";
            // 
            // kardexTlSMI
            // 
            this.kardexTlSMI.Name = "kardexTlSMI";
            this.kardexTlSMI.Size = new System.Drawing.Size(224, 22);
            this.kardexTlSMI.Text = "Kardex";
            this.kardexTlSMI.Click += new System.EventHandler(this.kardexTlSMI_Click);
            // 
            // notaDeCréditoTlSM
            // 
            this.notaDeCréditoTlSM.Name = "notaDeCréditoTlSM";
            this.notaDeCréditoTlSM.Size = new System.Drawing.Size(224, 22);
            this.notaDeCréditoTlSM.Text = "Rebaja Global (NC)";
            this.notaDeCréditoTlSM.Click += new System.EventHandler(this.notaDeCréditoTlSM_Click);
            // 
            // devoluciónTSMI
            // 
            this.devoluciónTSMI.Name = "devoluciónTSMI";
            this.devoluciónTSMI.Size = new System.Drawing.Size(224, 22);
            this.devoluciónTSMI.Text = "Devolución";
            // 
            // TlSMI_Div
            // 
            this.TlSMI_Div.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.TlSMI_Div.ForeColor = System.Drawing.SystemColors.Control;
            this.TlSMI_Div.Name = "TlSMI_Div";
            this.TlSMI_Div.Size = new System.Drawing.Size(224, 22);
            this.TlSMI_Div.Text = "ESPECIALES";
            // 
            // convAntTlSMI
            // 
            this.convAntTlSMI.Name = "convAntTlSMI";
            this.convAntTlSMI.Size = new System.Drawing.Size(224, 22);
            this.convAntTlSMI.Text = "Convenio Anterior";
            this.convAntTlSMI.Click += new System.EventHandler(this.convAntTlSMI_Click);
            // 
            // tbProveedor
            // 
            this.tbProveedor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbProveedor.Location = new System.Drawing.Point(291, 60);
            this.tbProveedor.Name = "tbProveedor";
            this.tbProveedor.Size = new System.Drawing.Size(45, 20);
            this.tbProveedor.TabIndex = 1;
            this.tbProveedor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbProveedor_KeyPress);
            // 
            // tbNombre
            // 
            this.tbNombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbNombre.Location = new System.Drawing.Point(336, 60);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(150, 20);
            this.tbNombre.TabIndex = 2;
            this.tbNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNombre_KeyPress_1);
            // 
            // tbFill
            // 
            this.tbFill.BackColor = System.Drawing.Color.LightGray;
            this.tbFill.Enabled = false;
            this.tbFill.Location = new System.Drawing.Point(10, 60);
            this.tbFill.Name = "tbFill";
            this.tbFill.Size = new System.Drawing.Size(40, 20);
            this.tbFill.TabIndex = 3;
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbDescripcion.Location = new System.Drawing.Point(551, 60);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(150, 20);
            this.tbDescripcion.TabIndex = 5;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress);
            // 
            // tbEstilo
            // 
            this.tbEstilo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbEstilo.Location = new System.Drawing.Point(486, 60);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(65, 20);
            this.tbEstilo.TabIndex = 4;
            this.tbEstilo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbEstilo_KeyPress);
            // 
            // gbOrigen
            // 
            this.gbOrigen.BackColor = System.Drawing.Color.Transparent;
            this.gbOrigen.Controls.Add(this.cbOrigen);
            this.gbOrigen.Location = new System.Drawing.Point(750, 3);
            this.gbOrigen.Name = "gbOrigen";
            this.gbOrigen.Size = new System.Drawing.Size(70, 47);
            this.gbOrigen.TabIndex = 28;
            this.gbOrigen.TabStop = false;
            this.gbOrigen.Text = "Origen";
            this.gbOrigen.Visible = false;
            // 
            // cbOrigen
            // 
            this.cbOrigen.BackColor = System.Drawing.Color.GhostWhite;
            this.cbOrigen.FormattingEnabled = true;
            this.cbOrigen.Location = new System.Drawing.Point(3, 18);
            this.cbOrigen.Name = "cbOrigen";
            this.cbOrigen.Size = new System.Drawing.Size(63, 21);
            this.cbOrigen.TabIndex = 23;
            this.cbOrigen.Visible = false;
            // 
            // gbMarca
            // 
            this.gbMarca.Controls.Add(this.cbMarca);
            this.gbMarca.Location = new System.Drawing.Point(8, 2);
            this.gbMarca.Name = "gbMarca";
            this.gbMarca.Size = new System.Drawing.Size(68, 47);
            this.gbMarca.TabIndex = 24;
            this.gbMarca.TabStop = false;
            this.gbMarca.Text = "Marca";
            // 
            // cbMarca
            // 
            this.cbMarca.FormattingEnabled = true;
            this.cbMarca.Location = new System.Drawing.Point(5, 19);
            this.cbMarca.Name = "cbMarca";
            this.cbMarca.Size = new System.Drawing.Size(58, 21);
            this.cbMarca.TabIndex = 11;
            this.cbMarca.SelectedValueChanged += new System.EventHandler(this.cbMarca_SelectedValueChanged);
            // 
            // gbComprador
            // 
            this.gbComprador.Controls.Add(this.cbComprador);
            this.gbComprador.Location = new System.Drawing.Point(79, 2);
            this.gbComprador.Name = "gbComprador";
            this.gbComprador.Size = new System.Drawing.Size(140, 47);
            this.gbComprador.TabIndex = 25;
            this.gbComprador.TabStop = false;
            this.gbComprador.Text = "Compradore";
            // 
            // cbComprador
            // 
            this.cbComprador.FormattingEnabled = true;
            this.cbComprador.Location = new System.Drawing.Point(5, 19);
            this.cbComprador.Name = "cbComprador";
            this.cbComprador.Size = new System.Drawing.Size(128, 21);
            this.cbComprador.TabIndex = 4;
            this.cbComprador.SelectedValueChanged += new System.EventHandler(this.cbComprador_SelectedValueChanged);
            // 
            // gbRangoFechas
            // 
            this.gbRangoFechas.Controls.Add(this.label1);
            this.gbRangoFechas.Controls.Add(this.label2);
            this.gbRangoFechas.Controls.Add(this.tbHasta);
            this.gbRangoFechas.Controls.Add(this.tbDesde);
            this.gbRangoFechas.Location = new System.Drawing.Point(221, 2);
            this.gbRangoFechas.Name = "gbRangoFechas";
            this.gbRangoFechas.Size = new System.Drawing.Size(247, 47);
            this.gbRangoFechas.TabIndex = 26;
            this.gbRangoFechas.TabStop = false;
            this.gbRangoFechas.Text = "Rango";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(130, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 38;
            this.label1.Text = "Hasta";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 37;
            this.label2.Text = "Desde";
            // 
            // tbHasta
            // 
            this.tbHasta.Location = new System.Drawing.Point(167, 19);
            this.tbHasta.Name = "tbHasta";
            this.tbHasta.ReadOnly = true;
            this.tbHasta.Size = new System.Drawing.Size(74, 20);
            this.tbHasta.TabIndex = 36;
            this.tbHasta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbHasta.Click += new System.EventHandler(this.tbHasta_Click);
            // 
            // tbDesde
            // 
            this.tbDesde.Location = new System.Drawing.Point(50, 19);
            this.tbDesde.Name = "tbDesde";
            this.tbDesde.ReadOnly = true;
            this.tbDesde.Size = new System.Drawing.Size(76, 20);
            this.tbDesde.TabIndex = 35;
            this.tbDesde.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbDesde.Click += new System.EventHandler(this.tbDesde_Click);
            // 
            // gbTemporada
            // 
            this.gbTemporada.BackColor = System.Drawing.Color.Transparent;
            this.gbTemporada.Controls.Add(this.cbTemporada);
            this.gbTemporada.Location = new System.Drawing.Point(474, 2);
            this.gbTemporada.Name = "gbTemporada";
            this.gbTemporada.Size = new System.Drawing.Size(131, 47);
            this.gbTemporada.TabIndex = 27;
            this.gbTemporada.TabStop = false;
            this.gbTemporada.Text = "Temporada";
            // 
            // cbTemporada
            // 
            this.cbTemporada.BackColor = System.Drawing.Color.GhostWhite;
            this.cbTemporada.FormattingEnabled = true;
            this.cbTemporada.Location = new System.Drawing.Point(6, 19);
            this.cbTemporada.Name = "cbTemporada";
            this.cbTemporada.Size = new System.Drawing.Size(119, 21);
            this.cbTemporada.TabIndex = 24;
            this.cbTemporada.SelectedIndexChanged += new System.EventHandler(this.cbTemporada_SelectedIndexChanged);
            // 
            // mcC2
            // 
            this.mcC2.BackColor = System.Drawing.Color.Gray;
            this.mcC2.ForeColor = System.Drawing.Color.Black;
            this.mcC2.Location = new System.Drawing.Point(374, 81);
            this.mcC2.Name = "mcC2";
            this.mcC2.TabIndex = 45;
            this.mcC2.Visible = false;
            this.mcC2.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcC2_DateSelected);
            this.mcC2.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcC2_KeyUp);
            // 
            // mcC1
            // 
            this.mcC1.BackColor = System.Drawing.Color.Gray;
            this.mcC1.ForeColor = System.Drawing.Color.Black;
            this.mcC1.Location = new System.Drawing.Point(88, 81);
            this.mcC1.Name = "mcC1";
            this.mcC1.TabIndex = 44;
            this.mcC1.Visible = false;
            this.mcC1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcC1_DateSelected);
            this.mcC1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcC1_KeyUp);
            // 
            // cbTipoConsulta
            // 
            this.cbTipoConsulta.BackColor = System.Drawing.Color.GhostWhite;
            this.cbTipoConsulta.FormattingEnabled = true;
            this.cbTipoConsulta.Items.AddRange(new object[] {
            "Todas",
            "Calificación",
            "PreCalificación",
            "Rebaja 01",
            "Rebaja 02",
            "Rebaja 03",
            "Rebaja 04"});
            this.cbTipoConsulta.Location = new System.Drawing.Point(6, 19);
            this.cbTipoConsulta.Name = "cbTipoConsulta";
            this.cbTipoConsulta.Size = new System.Drawing.Size(119, 21);
            this.cbTipoConsulta.TabIndex = 24;
            this.cbTipoConsulta.SelectedIndexChanged += new System.EventHandler(this.cbTipoConsulta_SelectedIndexChanged);
            // 
            // gbTipoConsulta
            // 
            this.gbTipoConsulta.BackColor = System.Drawing.Color.Transparent;
            this.gbTipoConsulta.Controls.Add(this.cbTipoConsulta);
            this.gbTipoConsulta.Location = new System.Drawing.Point(611, 2);
            this.gbTipoConsulta.Name = "gbTipoConsulta";
            this.gbTipoConsulta.Size = new System.Drawing.Size(131, 47);
            this.gbTipoConsulta.TabIndex = 28;
            this.gbTipoConsulta.TabStop = false;
            this.gbTipoConsulta.Text = "Tipo de Calificación";
            // 
            // tbTemporada
            // 
            this.tbTemporada.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbTemporada.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbTemporada.Location = new System.Drawing.Point(50, 60);
            this.tbTemporada.Name = "tbTemporada";
            this.tbTemporada.Size = new System.Drawing.Size(45, 20);
            this.tbTemporada.TabIndex = 46;
            this.tbTemporada.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTemporada_KeyPress);
            // 
            // tbTipoCalificacion
            // 
            this.tbTipoCalificacion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbTipoCalificacion.Location = new System.Drawing.Point(140, 60);
            this.tbTipoCalificacion.Name = "tbTipoCalificacion";
            this.tbTipoCalificacion.Size = new System.Drawing.Size(71, 20);
            this.tbTipoCalificacion.TabIndex = 47;
            this.tbTipoCalificacion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTipoCalificacion_KeyPress);
            // 
            // tbFchCalificacion
            // 
            this.tbFchCalificacion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFchCalificacion.Location = new System.Drawing.Point(211, 60);
            this.tbFchCalificacion.Name = "tbFchCalificacion";
            this.tbFchCalificacion.Size = new System.Drawing.Size(80, 20);
            this.tbFchCalificacion.TabIndex = 48;
            this.tbFchCalificacion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbFchCalificacion_KeyPress);
            // 
            // tbTabla
            // 
            this.tbTabla.BackColor = System.Drawing.Color.LightGray;
            this.tbTabla.Enabled = false;
            this.tbTabla.Location = new System.Drawing.Point(95, 60);
            this.tbTabla.Name = "tbTabla";
            this.tbTabla.Size = new System.Drawing.Size(45, 20);
            this.tbTabla.TabIndex = 49;
            this.tbTabla.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTabla_KeyPress);
            // 
            // btResumenGlobal
            // 
            this.btResumenGlobal.BackColor = System.Drawing.Color.White;
            this.btResumenGlobal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btResumenGlobal.Location = new System.Drawing.Point(826, 29);
            this.btResumenGlobal.Name = "btResumenGlobal";
            this.btResumenGlobal.Size = new System.Drawing.Size(97, 23);
            this.btResumenGlobal.TabIndex = 50;
            this.btResumenGlobal.Text = "Resumen Estilos";
            this.btResumenGlobal.UseVisualStyleBackColor = false;
            this.btResumenGlobal.Click += new System.EventHandler(this.btResumenGlobal_Click);
            // 
            // btResumenXtienda
            // 
            this.btResumenXtienda.BackColor = System.Drawing.Color.White;
            this.btResumenXtienda.ForeColor = System.Drawing.Color.Green;
            this.btResumenXtienda.Location = new System.Drawing.Point(826, 58);
            this.btResumenXtienda.Name = "btResumenXtienda";
            this.btResumenXtienda.Size = new System.Drawing.Size(97, 23);
            this.btResumenXtienda.TabIndex = 51;
            this.btResumenXtienda.Text = "Res. Estilo Tdas";
            this.btResumenXtienda.UseVisualStyleBackColor = false;
            this.btResumenXtienda.Click += new System.EventHandler(this.btResumenXtienda_Click);
            // 
            // btCalificacionXtienda
            // 
            this.btCalificacionXtienda.BackColor = System.Drawing.Color.White;
            this.btCalificacionXtienda.ForeColor = System.Drawing.Color.Red;
            this.btCalificacionXtienda.Location = new System.Drawing.Point(710, 58);
            this.btCalificacionXtienda.Name = "btCalificacionXtienda";
            this.btCalificacionXtienda.Size = new System.Drawing.Size(109, 23);
            this.btCalificacionXtienda.TabIndex = 52;
            this.btCalificacionXtienda.Text = "Cal.  Estilo-Tienda ";
            this.btCalificacionXtienda.UseVisualStyleBackColor = false;
            this.btCalificacionXtienda.Click += new System.EventHandler(this.btCalificacionXtienda_Click);
            // 
            // btExcel
            // 
            this.btExcel.BackColor = System.Drawing.Color.White;
            this.btExcel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btExcel.Location = new System.Drawing.Point(826, 2);
            this.btExcel.Name = "btExcel";
            this.btExcel.Size = new System.Drawing.Size(97, 23);
            this.btExcel.TabIndex = 53;
            this.btExcel.Text = "Exportar a Excel";
            this.btExcel.UseVisualStyleBackColor = false;
            this.btExcel.Click += new System.EventHandler(this.btExcel_Click);
            // 
            // pgbProg
            // 
            this.pgbProg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pgbProg.Location = new System.Drawing.Point(10, 546);
            this.pgbProg.Name = "pgbProg";
            this.pgbProg.Size = new System.Drawing.Size(1013, 10);
            this.pgbProg.TabIndex = 54;
            this.pgbProg.Visible = false;
            // 
            // btRsmTda
            // 
            this.btRsmTda.BackColor = System.Drawing.Color.White;
            this.btRsmTda.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btRsmTda.ForeColor = System.Drawing.Color.Navy;
            this.btRsmTda.Location = new System.Drawing.Point(1030, 12);
            this.btRsmTda.Name = "btRsmTda";
            this.btRsmTda.Size = new System.Drawing.Size(88, 56);
            this.btRsmTda.TabIndex = 55;
            this.btRsmTda.Text = "   Resumen     Global   Nivel Tienda";
            this.btRsmTda.UseVisualStyleBackColor = false;
            this.btRsmTda.Visible = false;
            this.btRsmTda.Click += new System.EventHandler(this.btRsmTda_Click);
            // 
            // btRsmGral
            // 
            this.btRsmGral.BackColor = System.Drawing.Color.White;
            this.btRsmGral.ForeColor = System.Drawing.Color.Teal;
            this.btRsmGral.Location = new System.Drawing.Point(927, 2);
            this.btRsmGral.Name = "btRsmGral";
            this.btRsmGral.Size = new System.Drawing.Size(97, 23);
            this.btRsmGral.TabIndex = 58;
            this.btRsmGral.Text = "Resumen Gral";
            this.btRsmGral.UseVisualStyleBackColor = false;
            this.btRsmGral.Visible = false;
            // 
            // btRsmxDepto
            // 
            this.btRsmxDepto.BackColor = System.Drawing.Color.White;
            this.btRsmxDepto.ForeColor = System.Drawing.Color.Teal;
            this.btRsmxDepto.Location = new System.Drawing.Point(927, 58);
            this.btRsmxDepto.Name = "btRsmxDepto";
            this.btRsmxDepto.Size = new System.Drawing.Size(97, 23);
            this.btRsmxDepto.TabIndex = 57;
            this.btRsmxDepto.Text = "Resumen Depto";
            this.btRsmxDepto.UseVisualStyleBackColor = false;
            this.btRsmxDepto.Visible = false;
            // 
            // btRsmPrv
            // 
            this.btRsmPrv.BackColor = System.Drawing.Color.White;
            this.btRsmPrv.ForeColor = System.Drawing.Color.Teal;
            this.btRsmPrv.Location = new System.Drawing.Point(927, 29);
            this.btRsmPrv.Name = "btRsmPrv";
            this.btRsmPrv.Size = new System.Drawing.Size(97, 23);
            this.btRsmPrv.TabIndex = 56;
            this.btRsmPrv.Text = "Resumen Prov.";
            this.btRsmPrv.UseVisualStyleBackColor = false;
            this.btRsmPrv.Visible = false;
            // 
            // CalificacionGrid
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1031, 561);
            this.Controls.Add(this.gbOrigen);
            this.Controls.Add(this.btRsmGral);
            this.Controls.Add(this.btRsmxDepto);
            this.Controls.Add(this.btRsmPrv);
            this.Controls.Add(this.btRsmTda);
            this.Controls.Add(this.pgbProg);
            this.Controls.Add(this.btExcel);
            this.Controls.Add(this.btCalificacionXtienda);
            this.Controls.Add(this.btResumenXtienda);
            this.Controls.Add(this.btResumenGlobal);
            this.Controls.Add(this.tbTabla);
            this.Controls.Add(this.tbFchCalificacion);
            this.Controls.Add(this.tbTipoCalificacion);
            this.Controls.Add(this.tbTemporada);
            this.Controls.Add(this.gbTipoConsulta);
            this.Controls.Add(this.mcC2);
            this.Controls.Add(this.mcC1);
            this.Controls.Add(this.gbMarca);
            this.Controls.Add(this.gbComprador);
            this.Controls.Add(this.gbRangoFechas);
            this.Controls.Add(this.gbTemporada);
            this.Controls.Add(this.tbDescripcion);
            this.Controls.Add(this.tbEstilo);
            this.Controls.Add(this.tbFill);
            this.Controls.Add(this.tbNombre);
            this.Controls.Add(this.tbProveedor);
            this.Controls.Add(this.dgvGridView);
            this.Name = "CalificacionGrid";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calificaciones";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CalificacionGrid_FormClosing);
            this.Load += new System.EventHandler(this.CalificacionGrid_Load);
            this.Resize += new System.EventHandler(this.CalificacionGrid_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.cmMenuStrip.ResumeLayout(false);
            this.gbOrigen.ResumeLayout(false);
            this.gbMarca.ResumeLayout(false);
            this.gbComprador.ResumeLayout(false);
            this.gbRangoFechas.ResumeLayout(false);
            this.gbRangoFechas.PerformLayout();
            this.gbTemporada.ResumeLayout(false);
            this.gbTipoConsulta.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.TextBox tbProveedor;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.TextBox tbFill;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.ContextMenuStrip cmMenuStrip;
        private System.Windows.Forms.GroupBox gbOrigen;
        private System.Windows.Forms.ComboBox cbOrigen;
        private System.Windows.Forms.GroupBox gbMarca;
        private System.Windows.Forms.ComboBox cbMarca;
        private System.Windows.Forms.GroupBox gbComprador;
        private System.Windows.Forms.ComboBox cbComprador;
        private System.Windows.Forms.GroupBox gbRangoFechas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbHasta;
        private System.Windows.Forms.TextBox tbDesde;
        private System.Windows.Forms.GroupBox gbTemporada;
        private System.Windows.Forms.ComboBox cbTemporada;
        private System.Windows.Forms.MonthCalendar mcC2;
        private System.Windows.Forms.MonthCalendar mcC1;
        private System.Windows.Forms.ComboBox cbTipoConsulta;
        private System.Windows.Forms.GroupBox gbTipoConsulta;
        private System.Windows.Forms.TextBox tbTemporada;
        private System.Windows.Forms.TextBox tbTipoCalificacion;
        private System.Windows.Forms.TextBox tbFchCalificacion;
        private System.Windows.Forms.TextBox tbTabla;
        private System.Windows.Forms.Button btResumenGlobal;
        private System.Windows.Forms.Button btResumenXtienda;
        private System.Windows.Forms.Button btCalificacionXtienda;
        private System.Windows.Forms.ToolStripMenuItem kardexTlSMI;
        private System.Windows.Forms.Button btExcel;
        private System.Windows.Forms.ProgressBar pgbProg;
        private System.Windows.Forms.ToolStripMenuItem notaDeCréditoTlSM;
        private System.Windows.Forms.ToolStripMenuItem devoluciónTSMI;
        private System.Windows.Forms.ToolStripMenuItem tsmOtros;
        private System.Windows.Forms.ToolStripMenuItem tsmiExcepciones;
        private System.Windows.Forms.ToolStripMenuItem tsmiReprogramaciones;
        private System.Windows.Forms.ToolStripMenuItem tsmiBonificacionPorDevolucion;
        private System.Windows.Forms.ToolStripMenuItem tsmiDevolucionBonificacion;
        private System.Windows.Forms.ToolStripMenuItem tsmiCambioCalificacion;
        private System.Windows.Forms.Button btRsmTda;
        private System.Windows.Forms.Button btRsmGral;
        private System.Windows.Forms.Button btRsmxDepto;
        private System.Windows.Forms.Button btRsmPrv;
        private System.Windows.Forms.ToolStripMenuItem TlSMI_Div;
        private System.Windows.Forms.ToolStripMenuItem convAntTlSMI;
    }
}