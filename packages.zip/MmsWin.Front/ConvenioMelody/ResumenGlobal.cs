﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using MmsWin.Front.Convenio;
using System.Windows.Forms;
using MmsWin.Front.Utilerias;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class ResumenGlobal : Form
    {
        #region Variables
        // variables de la Ventana
        public static string parTemporada;
        public static string parTipoCalificacion;
        public static string parFchCalificacion;
        public static string parFchInicial;
        public static string parProveedor;
        public static string parNombre;
        public static string parEstilo;
        public static string parDescripcion;
        public static string parCalificacion;

        #endregion
        Point mousedownpoint = Point.Empty;
        #region Grid
        // variables de la Ventana
        public static string gridMarca;
        public static string gridFechaCalifica;
        public static string gridTipoCalifica;
        public static string gridTemporada;
        public static string gridTabla;
        public static string gridProveedor;
        public static string gridEstilo;
        public static string gridOrden;
        #endregion

        int nr;
        bool Carga;
        String ParUser;
        string marca;
        string comprador;

        int dgvOffset;
        int dgvOffset2;

        public ResumenGlobal()
        {
            InitializeComponent();
            dgvOffset  = this.Width  - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }

        private void ResumenGlobal_Load(object sender, EventArgs e)
        {
            try
            {
                #region Variables
                // variables de la Ventana
                MmsWin.Front.ConvenioMelody.ResumenGlobal.parTemporada = string.Empty;
                MmsWin.Front.ConvenioMelody.ResumenGlobal.parTipoCalificacion = string.Empty;
                MmsWin.Front.ConvenioMelody.ResumenGlobal.parFchCalificacion = string.Empty;
                MmsWin.Front.ConvenioMelody.ResumenGlobal.parFchInicial = string.Empty;
                MmsWin.Front.ConvenioMelody.ResumenGlobal.parProveedor = string.Empty;
                MmsWin.Front.ConvenioMelody.ResumenGlobal.parNombre = string.Empty;
                MmsWin.Front.ConvenioMelody.ResumenGlobal.parEstilo = string.Empty;
                MmsWin.Front.ConvenioMelody.ResumenGlobal.parDescripcion = string.Empty;
                MmsWin.Front.ConvenioMelody.ResumenGlobal.parCalificacion = string.Empty;
                #endregion

                Point mousedownpoint = Point.Empty;

                Carga = false;
                marca = "999";
                comprador = "999";

                ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;

                try
                {
                    System.Data.DataTable tbFechaInicial = null;
                    tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                try
                {
                    Carga = true;
                    BinData();
                }
                catch (Exception ex)
                {
                    throw ex;
                }

            }
            catch { }
        }

        private void BinData()
        {
            if (Carga == true)
            {
                EliminacheckBox();
                nr = 0;
                System.Data.DataTable dtResumenGlobal = null;
                try
                {
                    this.Cursor = Cursors.WaitCursor;

                    string tipo      = string.Empty;
                    string temporada = string.Empty;
                    string tabla     = string.Empty;

                    //temporada           = tbTemporada.Text;
                    //tabla               = tbTabla.Text;
                    //parTipoCalificacion = tbTipoCalificacion.Text;
                    //parFchCalificacion  = tbFchCalificacion.Text;
                    //parProveedor        = tbProveedor.Text;
                    //parNombre           = tbNombre.Text;
                    //parEstilo           = tbEstilo.Text;
                    //parDescripcion      = tbDescripcion.Text;

                    marca               = MmsWin.Front.Utilerias.VarTem.tmpMarca;
                    comprador           = MmsWin.Front.Utilerias.VarTem.tmpComprador;
                    parTipoCalificacion = MmsWin.Front.Utilerias.VarTem.tmpTipoGlobal;
                    temporada           = MmsWin.Front.Utilerias.VarTem.partemporada;
                    parProveedor        = MmsWin.Front.Utilerias.VarTem.tmpPrvTda;
                    parEstilo           = MmsWin.Front.Utilerias.VarTem.tmpStyTda;

                    string FchDe  = MmsWin.Front.Utilerias.VarTem.parFchDesdeTda;
                    string FchHas = MmsWin.Front.Utilerias.VarTem.parFchHastaTda;

                    dtResumenGlobal = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenResumenGlobal(marca, comprador, FchDe, FchHas, tipo, temporada, parTipoCalificacion, parFchCalificacion, parProveedor, parNombre, parEstilo, parDescripcion);
                    dgvGridView.DataSource = null;
                    if (dtResumenGlobal.Rows.Count > 0)
                    {
                        SetDoubleBuffered(dgvGridView);
                        dgvGridView.DataSource = null;
                        dgvGridView.DataSource = dtResumenGlobal;
                        nr = dgvGridView.RowCount;
                        this.Text = "Resumen Global por Estilos/ " + " " + (nr-1).ToString() + " Registro(s)";
                        dgvGridView.DataSource = dtResumenGlobal;
                        CreaCheckBox();
                        SetFontAndColors();
                        rowStyle();
                        dgvGridView.Focus();
                        dgvGridView.Select();
                        dgvGridView.CurrentCell = dgvGridView.Rows[0].Cells[7];
                        //this.dgvGridView.Sort(this.dgvGridView.Columns[0],
                        //ListSortDirection.Ascending);
                    }

                    this.Cursor = Cursors.Default;
                }

                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        private void SetFontAndColors()
        {
            int i = 0;
            try
            {
                this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                this.dgvGridView.EnableHeadersVisualStyles = false;
                this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
                this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
                this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
                this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
                this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
                this.dgvGridView.RowHeadersVisible = false;
                //this.dgvGridView.Columns["MDYSTY"].Frozen = true;
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                dgvGridView.Columns["CALIFICACION"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["ESTILOS"].DefaultCellStyle.Alignment      = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["RECIBO"].DefaultCellStyle.Alignment       = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["COSTO_RECIBO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["INVENTARIO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["COSTO_INVENTARIO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["BONIFICACION"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["PORCENTAJE"].DefaultCellStyle.Alignment   = DataGridViewContentAlignment.MiddleCenter;

                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                dgvGridView.Columns["CALIFICACION"].Width = 100;
                dgvGridView.Columns["ESTILOS"].Width      = 60;
                dgvGridView.Columns["RECIBO"].Width       = 60;
                dgvGridView.Columns["COSTO_RECIBO"].Width = 100;
                dgvGridView.Columns["INVENTARIO"].Width   = 60;
                dgvGridView.Columns["COSTO_INVENTARIO"].Width = 100;
                dgvGridView.Columns["BONIFICACION"].Width = 100;
                dgvGridView.Columns["PORCENTAJE"].Width   = 80;

                dgvGridView.Columns["CALIFICACION"].HeaderText = "Calificación";
                dgvGridView.Columns["ESTILOS"].HeaderText = "Estilos Calificados";
                dgvGridView.Columns["RECIBO"].HeaderText = "Recibo";
                dgvGridView.Columns["COSTO_RECIBO"].HeaderText = "Costo Recibo";
                dgvGridView.Columns["INVENTARIO"].HeaderText   = "Inventario";
                dgvGridView.Columns["COSTO_INVENTARIO"].HeaderText = "Costo Inventario";
                dgvGridView.Columns["BONIFICACION"].HeaderText = "Bonificación";
                dgvGridView.Columns["PORCENTAJE"].HeaderText   = "         % ";
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                dgvGridView.Columns["ESTILOS"].DefaultCellStyle.Format      = "###,##0";
                dgvGridView.Columns["RECIBO"].DefaultCellStyle.Format       = "#,###,##0";
                dgvGridView.Columns["COSTO_RECIBO"].DefaultCellStyle.Format = "#,###,###.#0";
                dgvGridView.Columns["INVENTARIO"].DefaultCellStyle.Format   = "#,###,##0";
                dgvGridView.Columns["COSTO_INVENTARIO"].DefaultCellStyle.Format = "#,###,###.#0";
                dgvGridView.Columns["BONIFICACION"].DefaultCellStyle.Format = "#,###,###.#0";
                dgvGridView.Columns["PORCENTAJE"].DefaultCellStyle.Format = "#,#00.00%";
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                dgvGridView.Columns["CALIFICACION"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["CALIFICACION"].HeaderCell.Style.ForeColor = Color.White;
                dgvGridView.Columns["ESTILOS"].HeaderCell.Style.BackColor      = Color.LightSlateGray;
                dgvGridView.Columns["ESTILOS"].HeaderCell.Style.ForeColor      = Color.White;
                dgvGridView.Columns["RECIBO"].HeaderCell.Style.BackColor       = Color.LightSlateGray;
                dgvGridView.Columns["RECIBO"].HeaderCell.Style.ForeColor       = Color.White;
                dgvGridView.Columns["COSTO_RECIBO"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["COSTO_RECIBO"].HeaderCell.Style.ForeColor = Color.White;
                dgvGridView.Columns["INVENTARIO"].HeaderCell.Style.BackColor   = Color.LightSlateGray;
                dgvGridView.Columns["INVENTARIO"].HeaderCell.Style.ForeColor   = Color.White;
                dgvGridView.Columns["COSTO_INVENTARIO"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["COSTO_INVENTARIO"].HeaderCell.Style.ForeColor = Color.White;
                dgvGridView.Columns["BONIFICACION"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["BONIFICACION"].HeaderCell.Style.ForeColor = Color.White;
                dgvGridView.Columns["PORCENTAJE"].HeaderCell.Style.BackColor   = Color.LightSlateGray;
                dgvGridView.Columns["PORCENTAJE"].HeaderCell.Style.ForeColor   = Color.White;

                dgvGridView.Columns["COMPRAS"].Visible = false;
            }
            catch { }
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                dgvGridView.Select();

                // Pagar
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "P a g a r") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.LightGreen; }
                // 10%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "10%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.Yellow; }
                // 15%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "15%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "20%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "25%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "30%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "35%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "40%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.LightSalmon; }
                //Dev o 50%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "50%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.Red; rowp.Cells["CALIFICACION"].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "50%") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.Red; rowp.Cells["CALIFICACION"].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(rowp.Cells["CALIFICACION"].Value) == "Devolución") { rowp.Cells["CALIFICACION"].Style.BackColor = Color.Red; rowp.Cells["CALIFICACION"].Style.ForeColor = Color.White; }

                Regs += 1;
                if (vez == "Si")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }

                if ((Convert.ToString((rowp.Cells[0].Value))) == "Total")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.LightSlateGray;
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.ForeColor = Color.White;  
            
                    // Totales por columna
                    // Suma Tiendas            
                    dgvGridView.Rows[Regs - 1].Cells[1].Value = "0";        
                    int tot11 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[1].Value));
                    rowp.Cells[1].Value = tot11;

                    // Suma Costo Recibo                    
                    dgvGridView.Rows[Regs - 1].Cells[2].Value = "0";
                    int tot12 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[2].Value));
                    rowp.Cells[2].Value = tot12;
                    
                    // Suma Inventario        
                    dgvGridView.Rows[Regs - 1].Cells[3].Value = "0";           
                    int tot31 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[3].Value));
                    rowp.Cells[3].Value = tot31;

                    // Suma Costo Inventario                    
                    dgvGridView.Rows[Regs - 1].Cells[4].Value = "0";
                    int tot13 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[4].Value));
                    rowp.Cells[4].Value = tot13;

                    // Suma Bonificacion                    
                    dgvGridView.Rows[Regs - 1].Cells[5].Value = "0";
                    int tot14 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[5].Value));
                    rowp.Cells[5].Value = tot14;

                    // Suma Porcentaje        
                    dgvGridView.Rows[Regs - 1].Cells[6].Value = "0";
                    int tot33 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[6].Value));
                    rowp.Cells[6].Value = tot33;
                }
            }
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        private void ResumenGlobal_Resize(object sender, EventArgs e)
        {
            dgvGridView.Width = this.Width - dgvOffset;
            dgvGridView.Height = this.Height - dgvOffset2;
        }

        private void dgvGridView_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                BinData();
                dgvGridView.Focus();
                dgvGridView.Select();
            }
        }

        private void dgvGridView_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                SendKeys.Send("{UP}");
                SendKeys.Flush();
            }
        }

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            marca = " ";
            ComboBox cmbMarca = (ComboBox)sender;
            marca = cmbMarca.SelectedValue.ToString();
            BinData();
        }

        private void tbTipoCalificacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void tbFchCalificacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void tbProveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void tbNombre_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void dgvGridView_Sorted(object sender, EventArgs e)
        {
            rowStyle();
        }

        private void cbComprador_SelectedValueChanged(object sender, EventArgs e)
        {
            comprador = " ";
            nr = 0;
            ComboBox cmbComprador = (ComboBox)sender;
            comprador = cmbComprador.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpComprador = cmbComprador.SelectedValue.ToString();

            BinData();
        }

        private void fotoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MuestraFoto();
        }

        private void MuestraFoto()
        {
            try
            {
                Fotos i = new Fotos();
                i.Show();
            }
            catch { }
            finally { }
        }

        private void dgvGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvGridView.Select();
            dgvGridView.Focus();
            Kardex();
        }

        private void Kardex()
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Kardex").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del Kardex ya esta abierta");
                    }
                    else
                    {
                        Kardex i = new Kardex();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void tbTabla_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbTipoCalificacion.Focus();
            }
        }

        private void tbTemporada_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbTipoCalificacion.Focus();
            }
        }

        private void dgvGridView_CellParsing(object sender, DataGridViewCellParsingEventArgs e)
        {
            int Row = e.RowIndex;
            int Col = e.ColumnIndex;
            string campo         = string.Empty;
            string checkBox      = string.Empty;
            string observaciones = string.Empty;
            string usuario       = string.Empty;
            string fechaUser     = string.Empty;
            string horaUser      = string.Empty;

            string marca     = MmsWin.Front.ConvenioMelody.ResumenGlobal.gridMarca         ;
            string fecha     = MmsWin.Front.ConvenioMelody.ResumenGlobal.gridFechaCalifica ;
            string tipo      = MmsWin.Front.ConvenioMelody.ResumenGlobal.gridTipoCalifica  ;
            string temporada = MmsWin.Front.ConvenioMelody.ResumenGlobal.gridTemporada     ;
            string tabla     = MmsWin.Front.ConvenioMelody.ResumenGlobal.gridTabla         ;
            string proveedor = MmsWin.Front.ConvenioMelody.ResumenGlobal.gridProveedor     ;
            string estilo    = MmsWin.Front.ConvenioMelody.ResumenGlobal.gridEstilo        ;
            string orden     = MmsWin.Front.ConvenioMelody.ResumenGlobal.gridOrden         ;

            DateTime hoy = DateTime.Now;

            fechaUser = hoy.Date.ToString("yyMMdd");
            horaUser = DateTime.Now.ToString("HHmmss");
            usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;

            campo = this.dgvGridView.Rows[Row].Cells[Col].OwningColumn.Name;
            if (campo == "CHKCOMP")
            {
                observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBC"].Value.ToString();
                Boolean chk = Convert.ToBoolean((this.dgvGridView.CurrentRow.Cells["CHKCOMP"].Value));
                if (chk == true)
                {
                    checkBox = "0";
                }
                else
                {
                    checkBox = "1";
                }
                MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateCheckBoxCompras(marca, fecha, tipo, temporada, tabla, proveedor, estilo,
                                                                                        orden, checkBox, observaciones, usuario, fechaUser, horaUser);
            }
            if (campo == "CHKCONTR")
            {
                observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBT"].Value.ToString();
                Boolean chk = Convert.ToBoolean((this.dgvGridView.CurrentRow.Cells["CHKCONTR"].Value));
                if (chk == true)
                {
                    checkBox = "0";
                }
                else
                {
                    checkBox = "1";
                }
                MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateCheckBoxContraloria(marca, fecha, tipo, temporada, tabla, proveedor, estilo,
                                                                                        orden, checkBox, observaciones, usuario, fechaUser, horaUser);
            }
        }

        private void dgvGridView_Sorted_1(object sender, EventArgs e)
        {
            rowStyle();
        }

        private void detalleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "CalificacionGridTda").SingleOrDefault<Form>();
            {
                if (existe != null)
                {
                    MessageBox.Show("Las ventana del Convenio Melody ya esta abierta");
                }
                else
                {
                    MmsWin.Front.Utilerias.VarTem.parProveedor = string.Empty;
                    MmsWin.Front.Utilerias.VarTem.parEstilo = string.Empty;

                    MmsWin.Front.Utilerias.VarTem.tmpPrv = string.Empty;
                    MmsWin.Front.Utilerias.VarTem.tmpSty = string.Empty;

                    MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parProveedor   = string.Empty;
                    MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parNombre      = string.Empty;
                    MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parEstilo      = string.Empty;
                    MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parDescripcion = string.Empty;

                    CalificacionGridTdaMasivo i = new CalificacionGridTdaMasivo();
                    i.Show();
                }
            }
        }

        private void dgvGridView_SelectionChanged(object sender, EventArgs e)
        {
            cargaVariables();
        }

        private void cargaVariables()
        {
            try
            {
                MmsWin.Front.ConvenioMelody.ResumenGlobal.parCalificacion = this.dgvGridView.CurrentRow.Cells["CALIFICACION"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parCalificacion = this.dgvGridView.CurrentRow.Cells["CALIFICACION"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parOrigen = "";
            }
            catch { }
        }

        private void EliminacheckBox()
        {
            try
            {
                dgvGridView.Columns.Remove("COMPRAS");
            }
            catch { }
        }

        private void CreaCheckBox()
        {
            DataGridViewCheckBoxColumn Compras = new DataGridViewCheckBoxColumn();

            dgvGridView.Columns.Add(Compras);
            dgvGridView.Columns[8].Name = "COMPRAS";
            dgvGridView.Columns[8].HeaderText = "Revisado Comprador";
            dgvGridView.Columns[8].Width = 70;
            dgvGridView.Columns[8].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
            dgvGridView.Columns[8].HeaderCell.Style.ForeColor = Color.White;
        }

        private void btMarcaChk_Click(object sender, EventArgs e)
        {

            
        }

        private void btQuitaChks_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                if ((Convert.ToString((rowp.Cells[0].Value))) != "Total")
                {
                    DataGridViewCheckBoxCell chk2 = (DataGridViewCheckBoxCell)rowp.Cells["COMPRAS"];
                    dgvGridView.BeginEdit(true);
                    chk2.Value = 0;
                    dgvGridView.BeginEdit(false);
                }
            }
        }

        private void btPoneChks_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                if ((Convert.ToString((rowp.Cells[0].Value))) != "Total")
                {
                    DataGridViewCheckBoxCell chk2 = (DataGridViewCheckBoxCell)rowp.Cells["COMPRAS"];
                    dgvGridView.BeginEdit(true);
                    chk2.Value = 1;
                    dgvGridView.BeginEdit(false);
                }
            }
        }

        private void btQuitaChk_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                if ((Convert.ToString((rowp.Cells[0].Value))) != "Total")
                {
                    DataGridViewCheckBoxCell chk2 = (DataGridViewCheckBoxCell)rowp.Cells["COMPRAS"];
                    dgvGridView.BeginEdit(true);
                    chk2.Value = 0;
                    dgvGridView.BeginEdit(false);
                }
            }
        }

        private void ResumenGlobal_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void ResumenGlobal_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedownpoint.IsEmpty)
                return;
            Form f = sender as Form;
            f.Location = new Point(f.Location.X + (e.X - mousedownpoint.X), f.Location.Y + (e.Y - mousedownpoint.Y));
        }

        private void ResumenGlobal_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

        private void pbSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        #region Ocultar
        //private void rebajaDiferenciadaTSMI_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
        //                      "MasivoDiferenciado").SingleOrDefault<Form>();
        //        {
        //            if (existe != null)
        //            {
        //                MessageBox.Show("La Ventana ya esta abierta...");
        //            }
        //            else
        //            {
        //                string FechaBon = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
        //                if (FechaBon != null)
        //                {
        //                    string calificaion = MmsWin.Front.ConvenioMelody.CalificacionGrid.gridCalificacion;
        //                    string convMarcaNo = MmsWin.Front.ConvenioMelody.CalificacionGrid.gridMarca;

        //                    string FechaBinificacion = FechaBon.Substring(8, 2) + FechaBon.Substring(3, 2) + FechaBon.Substring(0, 2);
        //                    string FechaAbierta = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenMarcaConfiguracion1(convMarcaNo);
        //                    if (FechaBinificacion == FechaAbierta)
        //                    {
        //                        MessageBox.Show("La nota de crédito se va a concentrar en la fecha :" + FechaBon);
        //                        RecuperaMovimientosDiferenciados();
        //                        MasivoDiferenciado i = new MasivoDiferenciado();
        //                        i.Show();
        //                    }
        //                    else
        //                    {
        //                        MessageBox.Show("La fecha " + FechaBon + " No esta abierta para captura de Notas de Credito");
        //                    }
        //                }
        //                else
        //                {
        //                    MessageBox.Show("La ventana de Calificacion no esta abierta...");
        //                }
        //            }
        //        }
        //    }
        //    catch { }
        //    finally { }
        //}
        #endregion

        private void RecuperaMovimientosDiferenciados()
        {
            System.Data.DataTable dtDiferenciados = new System.Data.DataTable("Diferenciados");
            dtDiferenciados.Columns.Add("ParTipo", typeof(String));
            dtDiferenciados.Columns.Add("ParTemporada", typeof(String));
            dtDiferenciados.Columns.Add("ParTienda", typeof(String));

            DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                DataRow workRow = dtDiferenciados.NewRow();
                workRow["ParTipo"] = item.Cells["MDYTPO"].Value.ToString();
                workRow["ParTemporada"] = item.Cells["MDYTMP"].Value.ToString();
                workRow["ParTienda"] = item.Cells["MDYTDA"].Value.ToString();

                dtDiferenciados.Rows.Add(workRow);
            }

            int regs = dtDiferenciados.Rows.Count;
            if (regs == 0)
            {
                DataRow workRow = dtDiferenciados.NewRow();
                workRow["ParTipo"] = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTipoCalifica;
                workRow["ParTemporada"] = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTemporada;
                workRow["ParTienda"] = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTienda;

                dtDiferenciados.Rows.Add(workRow);
            }


            MmsWin.Front.ConvenioMelody.NotaDiferenciada.dtDiferenciados = dtDiferenciados;
        }

    }
}
