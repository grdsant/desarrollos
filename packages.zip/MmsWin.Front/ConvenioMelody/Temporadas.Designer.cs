﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class Temporadas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Temporadas));
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbTemporada = new System.Windows.Forms.TextBox();
            this.btRelleno = new System.Windows.Forms.Button();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.AgregarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.lbTemporadas = new System.Windows.Forms.Label();
            this.pbSalir = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.cmMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel1.Controls.Add(this.tbTemporada);
            this.panel1.Controls.Add(this.btRelleno);
            this.panel1.Controls.Add(this.tbDescripcion);
            this.panel1.Controls.Add(this.dgvGridView);
            this.panel1.Location = new System.Drawing.Point(0, 33);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(728, 316);
            this.panel1.TabIndex = 0;
            // 
            // tbTemporada
            // 
            this.tbTemporada.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbTemporada.Location = new System.Drawing.Point(45, 1);
            this.tbTemporada.Name = "tbTemporada";
            this.tbTemporada.Size = new System.Drawing.Size(100, 20);
            this.tbTemporada.TabIndex = 0;
            this.tbTemporada.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTemporada_KeyPress);
            // 
            // btRelleno
            // 
            this.btRelleno.Location = new System.Drawing.Point(2, 0);
            this.btRelleno.Name = "btRelleno";
            this.btRelleno.Size = new System.Drawing.Size(44, 22);
            this.btRelleno.TabIndex = 8;
            this.btRelleno.UseVisualStyleBackColor = true;
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.Location = new System.Drawing.Point(145, 1);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(580, 20);
            this.tbDescripcion.TabIndex = 1;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress);
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.ContextMenuStrip = this.cmMenu;
            this.dgvGridView.Location = new System.Drawing.Point(3, 22);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.Size = new System.Drawing.Size(723, 289);
            this.dgvGridView.TabIndex = 1;
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AgregarTSMI});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(165, 26);
            // 
            // AgregarTSMI
            // 
            this.AgregarTSMI.Name = "AgregarTSMI";
            this.AgregarTSMI.Size = new System.Drawing.Size(164, 22);
            this.AgregarTSMI.Text = "Agregar al Grupo";
            this.AgregarTSMI.Click += new System.EventHandler(this.AgregarTSMI_Click);
            // 
            // lbTemporadas
            // 
            this.lbTemporadas.AutoSize = true;
            this.lbTemporadas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTemporadas.ForeColor = System.Drawing.Color.Black;
            this.lbTemporadas.Location = new System.Drawing.Point(4, 5);
            this.lbTemporadas.Name = "lbTemporadas";
            this.lbTemporadas.Size = new System.Drawing.Size(108, 20);
            this.lbTemporadas.TabIndex = 5;
            this.lbTemporadas.Text = "Temporadas";
            // 
            // pbSalir
            // 
            this.pbSalir.Image = ((System.Drawing.Image)(resources.GetObject("pbSalir.Image")));
            this.pbSalir.Location = new System.Drawing.Point(701, 7);
            this.pbSalir.Name = "pbSalir";
            this.pbSalir.Size = new System.Drawing.Size(22, 18);
            this.pbSalir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSalir.TabIndex = 8;
            this.pbSalir.TabStop = false;
            this.pbSalir.Click += new System.EventHandler(this.pbSalir_Click);
            // 
            // Temporadas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(729, 350);
            this.Controls.Add(this.pbSalir);
            this.Controls.Add(this.lbTemporadas);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Temporadas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Temporadas";
            this.Load += new System.EventHandler(this.Temporadas_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Temporadas_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Temporadas_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Temporadas_MouseUp);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.cmMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbTemporadas;
        private System.Windows.Forms.PictureBox pbSalir;
        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.TextBox tbTemporada;
        private System.Windows.Forms.Button btRelleno;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem AgregarTSMI;
    }
}