﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class NotaDiferenciada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mtbCosto = new System.Windows.Forms.MaskedTextBox();
            this.mtbPrecio = new System.Windows.Forms.MaskedTextBox();
            this.mtbMargen = new System.Windows.Forms.MaskedTextBox();
            this.lblSubTot = new System.Windows.Forms.Label();
            this.lblIva = new System.Windows.Forms.Label();
            this.mtbTotal = new System.Windows.Forms.MaskedTextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.mtbSubTotal = new System.Windows.Forms.MaskedTextBox();
            this.lblCosto = new System.Windows.Forms.Label();
            this.lblPrecio = new System.Windows.Forms.Label();
            this.lbReferencia = new System.Windows.Forms.Label();
            this.mtbIva = new System.Windows.Forms.MaskedTextBox();
            this.lblMargen = new System.Windows.Forms.Label();
            this.gbNota = new System.Windows.Forms.GroupBox();
            this.cbPorcentajes = new System.Windows.Forms.ComboBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbMargenRebajado = new System.Windows.Forms.Label();
            this.lbPecioPromedio = new System.Windows.Forms.Label();
            this.lbPorcentajeRebajado = new System.Windows.Forms.Label();
            this.mtbNOTIMF2 = new System.Windows.Forms.MaskedTextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.mtbNOTIDC2 = new System.Windows.Forms.MaskedTextBox();
            this.lbImpDiferenciaCosto = new System.Windows.Forms.Label();
            this.mtbNOTDCF2 = new System.Windows.Forms.MaskedTextBox();
            this.lbDifCostoFinal = new System.Windows.Forms.Label();
            this.mtbNOTIMP1 = new System.Windows.Forms.MaskedTextBox();
            this.lbImpOnHand = new System.Windows.Forms.Label();
            this.mtbNOTPZA1 = new System.Windows.Forms.MaskedTextBox();
            this.lbPzaOnHand = new System.Windows.Forms.Label();
            this.mtbNOTCSTD = new System.Windows.Forms.MaskedTextBox();
            this.lbDifCosto = new System.Windows.Forms.Label();
            this.lbTablaDeAccFinal = new System.Windows.Forms.Label();
            this.mtbNOTTABF = new System.Windows.Forms.MaskedTextBox();
            this.lbTablaDeAccNueva = new System.Windows.Forms.Label();
            this.mtbNOTTAB1 = new System.Windows.Forms.MaskedTextBox();
            this.lbTablaDeAccActual = new System.Windows.Forms.Label();
            this.mtbNOTTAB = new System.Windows.Forms.MaskedTextBox();
            this.lbTablaDeAccion = new System.Windows.Forms.Label();
            this.mtbNOTONH = new System.Windows.Forms.MaskedTextBox();
            this.lbOnHand = new System.Windows.Forms.Label();
            this.lbNotaPDF = new System.Windows.Forms.Label();
            this.tbFuentePDF = new System.Windows.Forms.TextBox();
            this.pbExaminarPDF = new System.Windows.Forms.Button();
            this.lbFinal = new System.Windows.Forms.Label();
            this.lbNuevo = new System.Windows.Forms.Label();
            this.lbActual = new System.Windows.Forms.Label();
            this.mtbMargenFinal = new System.Windows.Forms.MaskedTextBox();
            this.mtbPrecioFinal = new System.Windows.Forms.MaskedTextBox();
            this.mtbCostoFinal = new System.Windows.Forms.MaskedTextBox();
            this.mtbMargenNuevo = new System.Windows.Forms.MaskedTextBox();
            this.mtbPrecioNuevo = new System.Windows.Forms.MaskedTextBox();
            this.mtbCostoNuevo = new System.Windows.Forms.MaskedTextBox();
            this.mtbPorc = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbFchCal = new System.Windows.Forms.TextBox();
            this.tbFchApl = new System.Windows.Forms.TextBox();
            this.tbProvee = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tbReferencia = new System.Windows.Forms.TextBox();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnCambiar = new System.Windows.Forms.Button();
            this.lbFormatoPDF = new System.Windows.Forms.Label();
            this.tbDestinoPDF = new System.Windows.Forms.TextBox();
            this.pbCargarPDF = new System.Windows.Forms.Button();
            this.gbNota.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // mtbCosto
            // 
            this.mtbCosto.Enabled = false;
            this.mtbCosto.Location = new System.Drawing.Point(124, 290);
            this.mtbCosto.Name = "mtbCosto";
            this.mtbCosto.Size = new System.Drawing.Size(60, 20);
            this.mtbCosto.TabIndex = 10;
            this.mtbCosto.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPrecio
            // 
            this.mtbPrecio.Enabled = false;
            this.mtbPrecio.Location = new System.Drawing.Point(124, 312);
            this.mtbPrecio.Name = "mtbPrecio";
            this.mtbPrecio.Size = new System.Drawing.Size(60, 20);
            this.mtbPrecio.TabIndex = 11;
            this.mtbPrecio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbMargen
            // 
            this.mtbMargen.Enabled = false;
            this.mtbMargen.Location = new System.Drawing.Point(124, 334);
            this.mtbMargen.Name = "mtbMargen";
            this.mtbMargen.Size = new System.Drawing.Size(60, 20);
            this.mtbMargen.TabIndex = 12;
            this.mtbMargen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblSubTot
            // 
            this.lblSubTot.AutoSize = true;
            this.lblSubTot.BackColor = System.Drawing.Color.LightGreen;
            this.lblSubTot.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSubTot.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblSubTot.Location = new System.Drawing.Point(7, 183);
            this.lblSubTot.Name = "lblSubTot";
            this.lblSubTot.Size = new System.Drawing.Size(106, 13);
            this.lblSubTot.TabIndex = 20;
            this.lblSubTot.Text = "Sub Total           ";
            // 
            // lblIva
            // 
            this.lblIva.AutoSize = true;
            this.lblIva.BackColor = System.Drawing.Color.LightSlateGray;
            this.lblIva.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIva.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblIva.Location = new System.Drawing.Point(7, 205);
            this.lblIva.Name = "lblIva";
            this.lblIva.Size = new System.Drawing.Size(109, 13);
            this.lblIva.TabIndex = 21;
            this.lblIva.Text = "Iva                     ";
            // 
            // mtbTotal
            // 
            this.mtbTotal.Enabled = false;
            this.mtbTotal.Location = new System.Drawing.Point(124, 223);
            this.mtbTotal.Name = "mtbTotal";
            this.mtbTotal.Size = new System.Drawing.Size(100, 20);
            this.mtbTotal.TabIndex = 9;
            this.mtbTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.BackColor = System.Drawing.Color.LightSlateGray;
            this.lblTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblTotal.Location = new System.Drawing.Point(7, 227);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(108, 13);
            this.lblTotal.TabIndex = 22;
            this.lblTotal.Text = "Total                  ";
            // 
            // mtbSubTotal
            // 
            this.mtbSubTotal.BackColor = System.Drawing.Color.LightGreen;
            this.mtbSubTotal.Enabled = false;
            this.mtbSubTotal.Location = new System.Drawing.Point(124, 179);
            this.mtbSubTotal.Name = "mtbSubTotal";
            this.mtbSubTotal.Size = new System.Drawing.Size(100, 20);
            this.mtbSubTotal.TabIndex = 2;
            this.mtbSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtbSubTotal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mtbSubTotal_KeyPress);
            // 
            // lblCosto
            // 
            this.lblCosto.AutoSize = true;
            this.lblCosto.BackColor = System.Drawing.Color.LightSlateGray;
            this.lblCosto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCosto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblCosto.Location = new System.Drawing.Point(7, 295);
            this.lblCosto.Name = "lblCosto";
            this.lblCosto.Size = new System.Drawing.Size(107, 13);
            this.lblCosto.TabIndex = 23;
            this.lblCosto.Text = "Costo                 ";
            // 
            // lblPrecio
            // 
            this.lblPrecio.AutoSize = true;
            this.lblPrecio.BackColor = System.Drawing.Color.LightSlateGray;
            this.lblPrecio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrecio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblPrecio.Location = new System.Drawing.Point(7, 317);
            this.lblPrecio.Name = "lblPrecio";
            this.lblPrecio.Size = new System.Drawing.Size(107, 13);
            this.lblPrecio.TabIndex = 24;
            this.lblPrecio.Text = "Precio                ";
            // 
            // lbReferencia
            // 
            this.lbReferencia.AutoSize = true;
            this.lbReferencia.BackColor = System.Drawing.Color.LightGreen;
            this.lbReferencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbReferencia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbReferencia.Location = new System.Drawing.Point(7, 161);
            this.lbReferencia.Name = "lbReferencia";
            this.lbReferencia.Size = new System.Drawing.Size(73, 13);
            this.lbReferencia.TabIndex = 19;
            this.lbReferencia.Text = "Referencia ";
            // 
            // mtbIva
            // 
            this.mtbIva.Enabled = false;
            this.mtbIva.Location = new System.Drawing.Point(124, 201);
            this.mtbIva.Name = "mtbIva";
            this.mtbIva.Size = new System.Drawing.Size(100, 20);
            this.mtbIva.TabIndex = 8;
            this.mtbIva.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblMargen
            // 
            this.lblMargen.AutoSize = true;
            this.lblMargen.BackColor = System.Drawing.Color.LightSlateGray;
            this.lblMargen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMargen.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblMargen.Location = new System.Drawing.Point(7, 339);
            this.lblMargen.Name = "lblMargen";
            this.lblMargen.Size = new System.Drawing.Size(105, 13);
            this.lblMargen.TabIndex = 25;
            this.lblMargen.Text = "Margen              ";
            // 
            // gbNota
            // 
            this.gbNota.Controls.Add(this.cbPorcentajes);
            this.gbNota.Controls.Add(this.panel1);
            this.gbNota.Controls.Add(this.mtbNOTIMF2);
            this.gbNota.Controls.Add(this.label19);
            this.gbNota.Controls.Add(this.mtbNOTIDC2);
            this.gbNota.Controls.Add(this.lbImpDiferenciaCosto);
            this.gbNota.Controls.Add(this.mtbNOTDCF2);
            this.gbNota.Controls.Add(this.lbDifCostoFinal);
            this.gbNota.Controls.Add(this.mtbNOTIMP1);
            this.gbNota.Controls.Add(this.lbImpOnHand);
            this.gbNota.Controls.Add(this.mtbNOTPZA1);
            this.gbNota.Controls.Add(this.lbPzaOnHand);
            this.gbNota.Controls.Add(this.mtbNOTCSTD);
            this.gbNota.Controls.Add(this.lbDifCosto);
            this.gbNota.Controls.Add(this.lbTablaDeAccFinal);
            this.gbNota.Controls.Add(this.mtbNOTTABF);
            this.gbNota.Controls.Add(this.lbTablaDeAccNueva);
            this.gbNota.Controls.Add(this.mtbNOTTAB1);
            this.gbNota.Controls.Add(this.lbTablaDeAccActual);
            this.gbNota.Controls.Add(this.mtbNOTTAB);
            this.gbNota.Controls.Add(this.lbTablaDeAccion);
            this.gbNota.Controls.Add(this.mtbNOTONH);
            this.gbNota.Controls.Add(this.lbOnHand);
            this.gbNota.Controls.Add(this.lbNotaPDF);
            this.gbNota.Controls.Add(this.tbFuentePDF);
            this.gbNota.Controls.Add(this.pbExaminarPDF);
            this.gbNota.Controls.Add(this.lbFinal);
            this.gbNota.Controls.Add(this.lbNuevo);
            this.gbNota.Controls.Add(this.lbActual);
            this.gbNota.Controls.Add(this.mtbMargenFinal);
            this.gbNota.Controls.Add(this.mtbPrecioFinal);
            this.gbNota.Controls.Add(this.mtbCostoFinal);
            this.gbNota.Controls.Add(this.mtbMargenNuevo);
            this.gbNota.Controls.Add(this.mtbPrecioNuevo);
            this.gbNota.Controls.Add(this.mtbCostoNuevo);
            this.gbNota.Controls.Add(this.mtbPorc);
            this.gbNota.Controls.Add(this.label7);
            this.gbNota.Controls.Add(this.tbDescripcion);
            this.gbNota.Controls.Add(this.tbEstilo);
            this.gbNota.Controls.Add(this.tbNombre);
            this.gbNota.Controls.Add(this.label6);
            this.gbNota.Controls.Add(this.label5);
            this.gbNota.Controls.Add(this.label4);
            this.gbNota.Controls.Add(this.tbFchCal);
            this.gbNota.Controls.Add(this.tbFchApl);
            this.gbNota.Controls.Add(this.tbProvee);
            this.gbNota.Controls.Add(this.label3);
            this.gbNota.Controls.Add(this.label2);
            this.gbNota.Controls.Add(this.label1);
            this.gbNota.Controls.Add(this.tbReferencia);
            this.gbNota.Controls.Add(this.lblMargen);
            this.gbNota.Controls.Add(this.mtbIva);
            this.gbNota.Controls.Add(this.lbReferencia);
            this.gbNota.Controls.Add(this.lblPrecio);
            this.gbNota.Controls.Add(this.lblCosto);
            this.gbNota.Controls.Add(this.mtbSubTotal);
            this.gbNota.Controls.Add(this.lblTotal);
            this.gbNota.Controls.Add(this.mtbTotal);
            this.gbNota.Controls.Add(this.lblIva);
            this.gbNota.Controls.Add(this.lblSubTot);
            this.gbNota.Controls.Add(this.mtbMargen);
            this.gbNota.Controls.Add(this.mtbPrecio);
            this.gbNota.Controls.Add(this.mtbCosto);
            this.gbNota.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbNota.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gbNota.Location = new System.Drawing.Point(30, 12);
            this.gbNota.Name = "gbNota";
            this.gbNota.Size = new System.Drawing.Size(397, 404);
            this.gbNota.TabIndex = 0;
            this.gbNota.TabStop = false;
            this.gbNota.Text = "Nota de Crédito";
            // 
            // cbPorcentajes
            // 
            this.cbPorcentajes.BackColor = System.Drawing.Color.Silver;
            this.cbPorcentajes.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPorcentajes.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.cbPorcentajes.FormattingEnabled = true;
            this.cbPorcentajes.Items.AddRange(new object[] {
            "  %",
            "10 %",
            "15 %",
            "20 %",
            "25 %",
            "30 %",
            "35 %",
            "40 %",
            "50 %",
            "60 %",
            "70 %"});
            this.cbPorcentajes.Location = new System.Drawing.Point(230, 244);
            this.cbPorcentajes.Name = "cbPorcentajes";
            this.cbPorcentajes.Size = new System.Drawing.Size(59, 24);
            this.cbPorcentajes.TabIndex = 63;
            this.cbPorcentajes.SelectedIndexChanged += new System.EventHandler(this.cbPorcentajes_SelectedIndexChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel1.Controls.Add(this.lbMargenRebajado);
            this.panel1.Controls.Add(this.lbPecioPromedio);
            this.panel1.Controls.Add(this.lbPorcentajeRebajado);
            this.panel1.Location = new System.Drawing.Point(229, 161);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(161, 79);
            this.panel1.TabIndex = 62;
            // 
            // lbMargenRebajado
            // 
            this.lbMargenRebajado.AutoSize = true;
            this.lbMargenRebajado.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lbMargenRebajado.Font = new System.Drawing.Font("Consolas", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMargenRebajado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbMargenRebajado.Location = new System.Drawing.Point(4, 18);
            this.lbMargenRebajado.Name = "lbMargenRebajado";
            this.lbMargenRebajado.Size = new System.Drawing.Size(79, 43);
            this.lbMargenRebajado.TabIndex = 1;
            this.lbMargenRebajado.Text = "XXX";
            this.lbMargenRebajado.Click += new System.EventHandler(this.lbMargenRebajado_Click);
            // 
            // lbPecioPromedio
            // 
            this.lbPecioPromedio.AutoSize = true;
            this.lbPecioPromedio.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPecioPromedio.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lbPecioPromedio.Location = new System.Drawing.Point(4, 53);
            this.lbPecioPromedio.Name = "lbPecioPromedio";
            this.lbPecioPromedio.Size = new System.Drawing.Size(60, 32);
            this.lbPecioPromedio.TabIndex = 2;
            this.lbPecioPromedio.Text = "xxx";
            // 
            // lbPorcentajeRebajado
            // 
            this.lbPorcentajeRebajado.AutoSize = true;
            this.lbPorcentajeRebajado.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPorcentajeRebajado.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lbPorcentajeRebajado.Location = new System.Drawing.Point(4, -7);
            this.lbPorcentajeRebajado.Name = "lbPorcentajeRebajado";
            this.lbPorcentajeRebajado.Size = new System.Drawing.Size(60, 32);
            this.lbPorcentajeRebajado.TabIndex = 0;
            this.lbPorcentajeRebajado.Text = "xxx";
            // 
            // mtbNOTIMF2
            // 
            this.mtbNOTIMF2.Enabled = false;
            this.mtbNOTIMF2.Location = new System.Drawing.Point(333, 432);
            this.mtbNOTIMF2.Name = "mtbNOTIMF2";
            this.mtbNOTIMF2.Size = new System.Drawing.Size(60, 20);
            this.mtbNOTIMF2.TabIndex = 61;
            this.mtbNOTIMF2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtbNOTIMF2.Visible = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.LightSlateGray;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label19.Location = new System.Drawing.Point(261, 438);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(83, 13);
            this.label19.TabIndex = 60;
            this.label19.Text = "Imp Mrg Final";
            this.label19.Visible = false;
            // 
            // mtbNOTIDC2
            // 
            this.mtbNOTIDC2.Enabled = false;
            this.mtbNOTIDC2.Location = new System.Drawing.Point(198, 433);
            this.mtbNOTIDC2.Name = "mtbNOTIDC2";
            this.mtbNOTIDC2.Size = new System.Drawing.Size(60, 20);
            this.mtbNOTIDC2.TabIndex = 59;
            this.mtbNOTIDC2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtbNOTIDC2.Visible = false;
            // 
            // lbImpDiferenciaCosto
            // 
            this.lbImpDiferenciaCosto.AutoSize = true;
            this.lbImpDiferenciaCosto.BackColor = System.Drawing.Color.LightSlateGray;
            this.lbImpDiferenciaCosto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbImpDiferenciaCosto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbImpDiferenciaCosto.Location = new System.Drawing.Point(125, 438);
            this.lbImpDiferenciaCosto.Name = "lbImpDiferenciaCosto";
            this.lbImpDiferenciaCosto.Size = new System.Drawing.Size(85, 13);
            this.lbImpDiferenciaCosto.TabIndex = 58;
            this.lbImpDiferenciaCosto.Text = "Imp Dif Cst    ";
            this.lbImpDiferenciaCosto.Visible = false;
            // 
            // mtbNOTDCF2
            // 
            this.mtbNOTDCF2.Enabled = false;
            this.mtbNOTDCF2.Location = new System.Drawing.Point(62, 433);
            this.mtbNOTDCF2.Name = "mtbNOTDCF2";
            this.mtbNOTDCF2.Size = new System.Drawing.Size(60, 20);
            this.mtbNOTDCF2.TabIndex = 57;
            this.mtbNOTDCF2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtbNOTDCF2.Visible = false;
            // 
            // lbDifCostoFinal
            // 
            this.lbDifCostoFinal.AutoSize = true;
            this.lbDifCostoFinal.BackColor = System.Drawing.Color.LightSlateGray;
            this.lbDifCostoFinal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDifCostoFinal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbDifCostoFinal.Location = new System.Drawing.Point(7, 438);
            this.lbDifCostoFinal.Name = "lbDifCostoFinal";
            this.lbDifCostoFinal.Size = new System.Drawing.Size(56, 13);
            this.lbDifCostoFinal.TabIndex = 56;
            this.lbDifCostoFinal.Text = "Dif Cst F";
            this.lbDifCostoFinal.Visible = false;
            // 
            // mtbNOTIMP1
            // 
            this.mtbNOTIMP1.Enabled = false;
            this.mtbNOTIMP1.Location = new System.Drawing.Point(333, 404);
            this.mtbNOTIMP1.Name = "mtbNOTIMP1";
            this.mtbNOTIMP1.Size = new System.Drawing.Size(60, 20);
            this.mtbNOTIMP1.TabIndex = 55;
            this.mtbNOTIMP1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtbNOTIMP1.Visible = false;
            // 
            // lbImpOnHand
            // 
            this.lbImpOnHand.AutoSize = true;
            this.lbImpOnHand.BackColor = System.Drawing.Color.LightSlateGray;
            this.lbImpOnHand.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbImpOnHand.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbImpOnHand.Location = new System.Drawing.Point(261, 410);
            this.lbImpOnHand.Name = "lbImpOnHand";
            this.lbImpOnHand.Size = new System.Drawing.Size(81, 13);
            this.lbImpOnHand.TabIndex = 54;
            this.lbImpOnHand.Text = "Imp On Hand";
            this.lbImpOnHand.Visible = false;
            // 
            // mtbNOTPZA1
            // 
            this.mtbNOTPZA1.Enabled = false;
            this.mtbNOTPZA1.Location = new System.Drawing.Point(198, 405);
            this.mtbNOTPZA1.Name = "mtbNOTPZA1";
            this.mtbNOTPZA1.Size = new System.Drawing.Size(60, 20);
            this.mtbNOTPZA1.TabIndex = 53;
            this.mtbNOTPZA1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtbNOTPZA1.Visible = false;
            // 
            // lbPzaOnHand
            // 
            this.lbPzaOnHand.AutoSize = true;
            this.lbPzaOnHand.BackColor = System.Drawing.Color.LightSlateGray;
            this.lbPzaOnHand.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPzaOnHand.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbPzaOnHand.Location = new System.Drawing.Point(125, 410);
            this.lbPzaOnHand.Name = "lbPzaOnHand";
            this.lbPzaOnHand.Size = new System.Drawing.Size(82, 13);
            this.lbPzaOnHand.TabIndex = 52;
            this.lbPzaOnHand.Text = "Pza On Hand";
            this.lbPzaOnHand.Visible = false;
            // 
            // mtbNOTCSTD
            // 
            this.mtbNOTCSTD.Enabled = false;
            this.mtbNOTCSTD.Location = new System.Drawing.Point(62, 405);
            this.mtbNOTCSTD.Name = "mtbNOTCSTD";
            this.mtbNOTCSTD.Size = new System.Drawing.Size(60, 20);
            this.mtbNOTCSTD.TabIndex = 51;
            this.mtbNOTCSTD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtbNOTCSTD.Visible = false;
            // 
            // lbDifCosto
            // 
            this.lbDifCosto.AutoSize = true;
            this.lbDifCosto.BackColor = System.Drawing.Color.LightSlateGray;
            this.lbDifCosto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDifCosto.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbDifCosto.Location = new System.Drawing.Point(7, 410);
            this.lbDifCosto.Name = "lbDifCosto";
            this.lbDifCosto.Size = new System.Drawing.Size(57, 13);
            this.lbDifCosto.TabIndex = 50;
            this.lbDifCosto.Text = "Dif Cst   ";
            this.lbDifCosto.Visible = false;
            // 
            // lbTablaDeAccFinal
            // 
            this.lbTablaDeAccFinal.AutoSize = true;
            this.lbTablaDeAccFinal.BackColor = System.Drawing.Color.LightSlateGray;
            this.lbTablaDeAccFinal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTablaDeAccFinal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbTablaDeAccFinal.Location = new System.Drawing.Point(284, 358);
            this.lbTablaDeAccFinal.Name = "lbTablaDeAccFinal";
            this.lbTablaDeAccFinal.Size = new System.Drawing.Size(46, 13);
            this.lbTablaDeAccFinal.TabIndex = 49;
            this.lbTablaDeAccFinal.Text = "Final   ";
            this.lbTablaDeAccFinal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mtbNOTTABF
            // 
            this.mtbNOTTABF.Enabled = false;
            this.mtbNOTTABF.Location = new System.Drawing.Point(284, 373);
            this.mtbNOTTABF.Name = "mtbNOTTABF";
            this.mtbNOTTABF.Size = new System.Drawing.Size(38, 20);
            this.mtbNOTTABF.TabIndex = 48;
            this.mtbNOTTABF.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbTablaDeAccNueva
            // 
            this.lbTablaDeAccNueva.AutoSize = true;
            this.lbTablaDeAccNueva.BackColor = System.Drawing.Color.LightSlateGray;
            this.lbTablaDeAccNueva.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTablaDeAccNueva.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbTablaDeAccNueva.Location = new System.Drawing.Point(241, 358);
            this.lbTablaDeAccNueva.Name = "lbTablaDeAccNueva";
            this.lbTablaDeAccNueva.Size = new System.Drawing.Size(44, 13);
            this.lbTablaDeAccNueva.TabIndex = 47;
            this.lbTablaDeAccNueva.Text = "Nueva";
            this.lbTablaDeAccNueva.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mtbNOTTAB1
            // 
            this.mtbNOTTAB1.Enabled = false;
            this.mtbNOTTAB1.Location = new System.Drawing.Point(241, 373);
            this.mtbNOTTAB1.Name = "mtbNOTTAB1";
            this.mtbNOTTAB1.Size = new System.Drawing.Size(38, 20);
            this.mtbNOTTAB1.TabIndex = 46;
            this.mtbNOTTAB1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbTablaDeAccActual
            // 
            this.lbTablaDeAccActual.AutoSize = true;
            this.lbTablaDeAccActual.BackColor = System.Drawing.Color.LightSlateGray;
            this.lbTablaDeAccActual.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTablaDeAccActual.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbTablaDeAccActual.Location = new System.Drawing.Point(199, 358);
            this.lbTablaDeAccActual.Name = "lbTablaDeAccActual";
            this.lbTablaDeAccActual.Size = new System.Drawing.Size(43, 13);
            this.lbTablaDeAccActual.TabIndex = 45;
            this.lbTablaDeAccActual.Text = "Actual";
            this.lbTablaDeAccActual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mtbNOTTAB
            // 
            this.mtbNOTTAB.Enabled = false;
            this.mtbNOTTAB.Location = new System.Drawing.Point(199, 373);
            this.mtbNOTTAB.Name = "mtbNOTTAB";
            this.mtbNOTTAB.Size = new System.Drawing.Size(38, 20);
            this.mtbNOTTAB.TabIndex = 44;
            this.mtbNOTTAB.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbTablaDeAccion
            // 
            this.lbTablaDeAccion.AutoSize = true;
            this.lbTablaDeAccion.BackColor = System.Drawing.Color.LightSlateGray;
            this.lbTablaDeAccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTablaDeAccion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbTablaDeAccion.Location = new System.Drawing.Point(135, 377);
            this.lbTablaDeAccion.Name = "lbTablaDeAccion";
            this.lbTablaDeAccion.Size = new System.Drawing.Size(65, 13);
            this.lbTablaDeAccion.TabIndex = 43;
            this.lbTablaDeAccion.Text = "Tabla Acc";
            // 
            // mtbNOTONH
            // 
            this.mtbNOTONH.Enabled = false;
            this.mtbNOTONH.Location = new System.Drawing.Point(62, 373);
            this.mtbNOTONH.Name = "mtbNOTONH";
            this.mtbNOTONH.Size = new System.Drawing.Size(60, 20);
            this.mtbNOTONH.TabIndex = 42;
            this.mtbNOTONH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtbNOTONH.Visible = false;
            // 
            // lbOnHand
            // 
            this.lbOnHand.AutoSize = true;
            this.lbOnHand.BackColor = System.Drawing.Color.LightSlateGray;
            this.lbOnHand.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOnHand.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbOnHand.Location = new System.Drawing.Point(7, 376);
            this.lbOnHand.Name = "lbOnHand";
            this.lbOnHand.Size = new System.Drawing.Size(57, 13);
            this.lbOnHand.TabIndex = 41;
            this.lbOnHand.Text = "On Hand";
            this.lbOnHand.Visible = false;
            // 
            // lbNotaPDF
            // 
            this.lbNotaPDF.AutoSize = true;
            this.lbNotaPDF.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNotaPDF.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbNotaPDF.Location = new System.Drawing.Point(13, 462);
            this.lbNotaPDF.Name = "lbNotaPDF";
            this.lbNotaPDF.Size = new System.Drawing.Size(132, 13);
            this.lbNotaPDF.TabIndex = 40;
            this.lbNotaPDF.Text = "Nota de Crédito (PDF)";
            this.lbNotaPDF.Visible = false;
            // 
            // tbFuentePDF
            // 
            this.tbFuentePDF.Enabled = false;
            this.tbFuentePDF.Location = new System.Drawing.Point(14, 477);
            this.tbFuentePDF.Name = "tbFuentePDF";
            this.tbFuentePDF.Size = new System.Drawing.Size(315, 20);
            this.tbFuentePDF.TabIndex = 39;
            this.tbFuentePDF.Visible = false;
            // 
            // pbExaminarPDF
            // 
            this.pbExaminarPDF.Location = new System.Drawing.Point(330, 475);
            this.pbExaminarPDF.Name = "pbExaminarPDF";
            this.pbExaminarPDF.Size = new System.Drawing.Size(56, 23);
            this.pbExaminarPDF.TabIndex = 38;
            this.pbExaminarPDF.Text = "Examinar";
            this.pbExaminarPDF.UseVisualStyleBackColor = true;
            this.pbExaminarPDF.Visible = false;
            this.pbExaminarPDF.Click += new System.EventHandler(this.pbExaminarPDF_Click);
            // 
            // lbFinal
            // 
            this.lbFinal.AutoSize = true;
            this.lbFinal.BackColor = System.Drawing.Color.LightSlateGray;
            this.lbFinal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFinal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbFinal.Location = new System.Drawing.Point(253, 273);
            this.lbFinal.Name = "lbFinal";
            this.lbFinal.Size = new System.Drawing.Size(70, 13);
            this.lbFinal.TabIndex = 37;
            this.lbFinal.Text = "Final         ";
            // 
            // lbNuevo
            // 
            this.lbNuevo.AutoSize = true;
            this.lbNuevo.BackColor = System.Drawing.Color.LightSlateGray;
            this.lbNuevo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNuevo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbNuevo.Location = new System.Drawing.Point(189, 273);
            this.lbNuevo.Name = "lbNuevo";
            this.lbNuevo.Size = new System.Drawing.Size(68, 13);
            this.lbNuevo.TabIndex = 36;
            this.lbNuevo.Text = "Nuevo      ";
            // 
            // lbActual
            // 
            this.lbActual.AutoSize = true;
            this.lbActual.BackColor = System.Drawing.Color.LightSlateGray;
            this.lbActual.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbActual.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbActual.Location = new System.Drawing.Point(126, 273);
            this.lbActual.Name = "lbActual";
            this.lbActual.Size = new System.Drawing.Size(71, 13);
            this.lbActual.TabIndex = 35;
            this.lbActual.Text = "Actual       ";
            this.lbActual.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mtbMargenFinal
            // 
            this.mtbMargenFinal.Enabled = false;
            this.mtbMargenFinal.Location = new System.Drawing.Point(252, 332);
            this.mtbMargenFinal.Name = "mtbMargenFinal";
            this.mtbMargenFinal.Size = new System.Drawing.Size(60, 20);
            this.mtbMargenFinal.TabIndex = 34;
            this.mtbMargenFinal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPrecioFinal
            // 
            this.mtbPrecioFinal.Enabled = false;
            this.mtbPrecioFinal.Location = new System.Drawing.Point(252, 310);
            this.mtbPrecioFinal.Name = "mtbPrecioFinal";
            this.mtbPrecioFinal.Size = new System.Drawing.Size(60, 20);
            this.mtbPrecioFinal.TabIndex = 33;
            this.mtbPrecioFinal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbCostoFinal
            // 
            this.mtbCostoFinal.Enabled = false;
            this.mtbCostoFinal.Location = new System.Drawing.Point(252, 288);
            this.mtbCostoFinal.Name = "mtbCostoFinal";
            this.mtbCostoFinal.Size = new System.Drawing.Size(60, 20);
            this.mtbCostoFinal.TabIndex = 32;
            this.mtbCostoFinal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbMargenNuevo
            // 
            this.mtbMargenNuevo.Enabled = false;
            this.mtbMargenNuevo.Location = new System.Drawing.Point(188, 333);
            this.mtbMargenNuevo.Name = "mtbMargenNuevo";
            this.mtbMargenNuevo.Size = new System.Drawing.Size(60, 20);
            this.mtbMargenNuevo.TabIndex = 31;
            this.mtbMargenNuevo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPrecioNuevo
            // 
            this.mtbPrecioNuevo.Enabled = false;
            this.mtbPrecioNuevo.Location = new System.Drawing.Point(188, 311);
            this.mtbPrecioNuevo.Name = "mtbPrecioNuevo";
            this.mtbPrecioNuevo.Size = new System.Drawing.Size(60, 20);
            this.mtbPrecioNuevo.TabIndex = 30;
            this.mtbPrecioNuevo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbCostoNuevo
            // 
            this.mtbCostoNuevo.Enabled = false;
            this.mtbCostoNuevo.Location = new System.Drawing.Point(188, 289);
            this.mtbCostoNuevo.Name = "mtbCostoNuevo";
            this.mtbCostoNuevo.Size = new System.Drawing.Size(60, 20);
            this.mtbCostoNuevo.TabIndex = 29;
            this.mtbCostoNuevo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // mtbPorc
            // 
            this.mtbPorc.BackColor = System.Drawing.Color.LightGreen;
            this.mtbPorc.Enabled = false;
            this.mtbPorc.Location = new System.Drawing.Point(124, 245);
            this.mtbPorc.Name = "mtbPorc";
            this.mtbPorc.Size = new System.Drawing.Size(100, 20);
            this.mtbPorc.TabIndex = 1;
            this.mtbPorc.Text = "0";
            this.mtbPorc.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.mtbPorc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.mtbPorc_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.LightGreen;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label7.Location = new System.Drawing.Point(7, 252);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "%  x Aplicar";
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDescripcion.Enabled = false;
            this.tbDescripcion.Location = new System.Drawing.Point(124, 135);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(264, 20);
            this.tbDescripcion.TabIndex = 5;
            // 
            // tbEstilo
            // 
            this.tbEstilo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbEstilo.Enabled = false;
            this.tbEstilo.Location = new System.Drawing.Point(124, 113);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(100, 20);
            this.tbEstilo.TabIndex = 4;
            // 
            // tbNombre
            // 
            this.tbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNombre.Enabled = false;
            this.tbNombre.Location = new System.Drawing.Point(124, 91);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(264, 20);
            this.tbNombre.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.LightSlateGray;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label6.Location = new System.Drawing.Point(7, 139);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "Descripción";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.LightSlateGray;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label5.Location = new System.Drawing.Point(7, 117);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Estilo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.LightSlateGray;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(7, 95);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Nombre";
            // 
            // tbFchCal
            // 
            this.tbFchCal.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbFchCal.Enabled = false;
            this.tbFchCal.Location = new System.Drawing.Point(124, 25);
            this.tbFchCal.Name = "tbFchCal";
            this.tbFchCal.Size = new System.Drawing.Size(100, 20);
            this.tbFchCal.TabIndex = 2;
            // 
            // tbFchApl
            // 
            this.tbFchApl.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbFchApl.Enabled = false;
            this.tbFchApl.Location = new System.Drawing.Point(124, 47);
            this.tbFchApl.Name = "tbFchApl";
            this.tbFchApl.Size = new System.Drawing.Size(100, 20);
            this.tbFchApl.TabIndex = 1;
            // 
            // tbProvee
            // 
            this.tbProvee.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbProvee.Enabled = false;
            this.tbProvee.Location = new System.Drawing.Point(124, 69);
            this.tbProvee.Name = "tbProvee";
            this.tbProvee.Size = new System.Drawing.Size(100, 20);
            this.tbProvee.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.LightSlateGray;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(7, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "Proveedor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.LightSlateGray;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(7, 51);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "Fecha Bonificacion  ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.LightSlateGray;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(7, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "Fecha Revisión";
            // 
            // tbReferencia
            // 
            this.tbReferencia.BackColor = System.Drawing.Color.LightGreen;
            this.tbReferencia.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbReferencia.Enabled = false;
            this.tbReferencia.Location = new System.Drawing.Point(124, 157);
            this.tbReferencia.Name = "tbReferencia";
            this.tbReferencia.Size = new System.Drawing.Size(100, 20);
            this.tbReferencia.TabIndex = 0;
            this.tbReferencia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbReferencia_KeyPress);
            // 
            // btnCancelar
            // 
            this.btnCancelar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancelar.Location = new System.Drawing.Point(64, 431);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(75, 23);
            this.btnCancelar.TabIndex = 1;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnGuardar.Location = new System.Drawing.Point(309, 431);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(75, 23);
            this.btnGuardar.TabIndex = 3;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnCambiar
            // 
            this.btnCambiar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCambiar.Location = new System.Drawing.Point(188, 431);
            this.btnCambiar.Name = "btnCambiar";
            this.btnCambiar.Size = new System.Drawing.Size(75, 23);
            this.btnCambiar.TabIndex = 2;
            this.btnCambiar.Text = "Cambiar";
            this.btnCambiar.UseVisualStyleBackColor = true;
            this.btnCambiar.Click += new System.EventHandler(this.btnCambiar_Click);
            // 
            // lbFormatoPDF
            // 
            this.lbFormatoPDF.AutoSize = true;
            this.lbFormatoPDF.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFormatoPDF.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbFormatoPDF.Location = new System.Drawing.Point(42, 512);
            this.lbFormatoPDF.Name = "lbFormatoPDF";
            this.lbFormatoPDF.Size = new System.Drawing.Size(229, 13);
            this.lbFormatoPDF.TabIndex = 11;
            this.lbFormatoPDF.Text = "Formato de la Nota de Crédito a Cargar";
            this.lbFormatoPDF.Visible = false;
            // 
            // tbDestinoPDF
            // 
            this.tbDestinoPDF.Enabled = false;
            this.tbDestinoPDF.Location = new System.Drawing.Point(43, 527);
            this.tbDestinoPDF.Name = "tbDestinoPDF";
            this.tbDestinoPDF.Size = new System.Drawing.Size(315, 20);
            this.tbDestinoPDF.TabIndex = 10;
            this.tbDestinoPDF.Visible = false;
            // 
            // pbCargarPDF
            // 
            this.pbCargarPDF.Location = new System.Drawing.Point(359, 525);
            this.pbCargarPDF.Name = "pbCargarPDF";
            this.pbCargarPDF.Size = new System.Drawing.Size(58, 23);
            this.pbCargarPDF.TabIndex = 9;
            this.pbCargarPDF.Text = "Cargar";
            this.pbCargarPDF.UseVisualStyleBackColor = true;
            this.pbCargarPDF.Visible = false;
            this.pbCargarPDF.Click += new System.EventHandler(this.pbCargarPDF_Click);
            // 
            // NotaDiferenciada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSlateGray;
            this.ClientSize = new System.Drawing.Size(453, 469);
            this.Controls.Add(this.lbFormatoPDF);
            this.Controls.Add(this.tbDestinoPDF);
            this.Controls.Add(this.pbCargarPDF);
            this.Controls.Add(this.btnCambiar);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.gbNota);
            this.MaximizeBox = false;
            this.Name = "NotaDiferenciada";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Captura de Referencia Diferenciada";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Nota_FormClosing);
            this.Load += new System.EventHandler(this.Nota_Load);
            this.gbNota.ResumeLayout(false);
            this.gbNota.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mtbCosto;
        private System.Windows.Forms.MaskedTextBox mtbPrecio;
        private System.Windows.Forms.MaskedTextBox mtbMargen;
        private System.Windows.Forms.Label lblSubTot;
        private System.Windows.Forms.Label lblIva;
        private System.Windows.Forms.MaskedTextBox mtbTotal;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.MaskedTextBox mtbSubTotal;
        private System.Windows.Forms.Label lblCosto;
        private System.Windows.Forms.Label lblPrecio;
        private System.Windows.Forms.Label lbReferencia;
        private System.Windows.Forms.MaskedTextBox mtbIva;
        private System.Windows.Forms.Label lblMargen;
        private System.Windows.Forms.GroupBox gbNota;
        private System.Windows.Forms.TextBox tbReferencia;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.TextBox tbFchCal;
        private System.Windows.Forms.TextBox tbFchApl;
        private System.Windows.Forms.TextBox tbProvee;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnCambiar;
        private System.Windows.Forms.MaskedTextBox mtbPorc;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbFinal;
        private System.Windows.Forms.Label lbNuevo;
        private System.Windows.Forms.Label lbActual;
        private System.Windows.Forms.MaskedTextBox mtbMargenFinal;
        private System.Windows.Forms.MaskedTextBox mtbPrecioFinal;
        private System.Windows.Forms.MaskedTextBox mtbCostoFinal;
        private System.Windows.Forms.MaskedTextBox mtbMargenNuevo;
        private System.Windows.Forms.MaskedTextBox mtbPrecioNuevo;
        private System.Windows.Forms.MaskedTextBox mtbCostoNuevo;
        private System.Windows.Forms.Label lbNotaPDF;
        private System.Windows.Forms.TextBox tbFuentePDF;
        private System.Windows.Forms.Button pbExaminarPDF;
        private System.Windows.Forms.Label lbFormatoPDF;
        private System.Windows.Forms.TextBox tbDestinoPDF;
        private System.Windows.Forms.Button pbCargarPDF;
        private System.Windows.Forms.Label lbTablaDeAccActual;
        private System.Windows.Forms.MaskedTextBox mtbNOTTAB;
        private System.Windows.Forms.Label lbTablaDeAccion;
        private System.Windows.Forms.MaskedTextBox mtbNOTONH;
        private System.Windows.Forms.Label lbOnHand;
        private System.Windows.Forms.MaskedTextBox mtbNOTIMF2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.MaskedTextBox mtbNOTIDC2;
        private System.Windows.Forms.Label lbImpDiferenciaCosto;
        private System.Windows.Forms.MaskedTextBox mtbNOTDCF2;
        private System.Windows.Forms.Label lbDifCostoFinal;
        private System.Windows.Forms.MaskedTextBox mtbNOTIMP1;
        private System.Windows.Forms.Label lbImpOnHand;
        private System.Windows.Forms.MaskedTextBox mtbNOTPZA1;
        private System.Windows.Forms.Label lbPzaOnHand;
        private System.Windows.Forms.MaskedTextBox mtbNOTCSTD;
        private System.Windows.Forms.Label lbDifCosto;
        private System.Windows.Forms.Label lbTablaDeAccFinal;
        private System.Windows.Forms.MaskedTextBox mtbNOTTABF;
        private System.Windows.Forms.Label lbTablaDeAccNueva;
        private System.Windows.Forms.MaskedTextBox mtbNOTTAB1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbPorcentajeRebajado;
        private System.Windows.Forms.Label lbMargenRebajado;
        private System.Windows.Forms.ComboBox cbPorcentajes;
        private System.Windows.Forms.Label lbPecioPromedio;
    }
}