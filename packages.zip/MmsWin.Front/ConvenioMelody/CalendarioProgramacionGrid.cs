﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class CalendarioProgramacionGrid : Form
    {
        #region Variables
        // variables de la Ventana
        public static string calAnio;
        public static string calTemporada;
        public static string calTablaPorc;
        public static string calTablaPorc2;
        public static string calMarca;
        public static string calRenglon;
        public static string calColumna;
        public static string corrUsuario;
        public static string calClaveCel;
        public static string calRentOdesplaz;
        #endregion

        String ParUser;
        bool repintado = true;
        string marca;
        bool Carga;
        string temporadaCombo = "Todas";
        string anio;
        int nr;
        int dgvOffset;
        int dgvOffset2;
        string temporada;

        public CalendarioProgramacionGrid()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }

        private void CalendarioProgramacionGrid_Load(object sender, EventArgs e)
        {
            Carga = false;
            marca = "999";
            ToolTip Tooltip1 = new ToolTip();
            Tooltip1.SetToolTip(this.pbRegNew, "Renglon Nuevo");

        #region Variables
            // variables de la Ventana
            MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calAnio      = string.Empty;
            MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calTemporada = string.Empty;
            MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calTablaPorc = string.Empty;
            MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calMarca     = string.Empty;
            MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calRenglon   = string.Empty;
            MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calColumna   = string.Empty;
            MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.corrUsuario  = string.Empty;
            MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calRentOdesplaz = string.Empty;
            
        #endregion

            // Carga de Temporadas
            try
            {
                BindTemporadas();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            // Carga de Marca
            try
            {
                BindMarca();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, this.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            // Carga Marca segun usuario
            marca = MmsWin.Front.Utilerias.VarTem.tmpUSRMAR;
            cbMarca.SelectedValue = marca;
            marca = cbMarca.SelectedValue.ToString();
            if (marca == "999")
            {
                this.Controls["gbMarca"].Enabled = true;
            }

            // Carga Año Actual
            DateTime fechaActual = DateTime.Today;
            cbAnio.SelectedItem =  Convert.ToString(fechaActual.Year);

            //temporadaCombo = "Todas";
            cbTemporada.SelectedItem = "Todas";

            // Carga de Datos
            try
            {
                Carga = true;
                //BinData();
                // Seguridad... x las Columnas nuevas
                ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                Seguridad("CalendarioCalificacion", "CalendarioCalificacion", ParUser);
                marca = cbMarca.SelectedValue.ToString();
                if (marca == "999")
                {
                    this.Controls["gbMarca"].Enabled = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //toolTipGridView();

        }

        private void CargaMarca()
        {
            //cbAnio.Items.Add("2000");
        }

        private void BinData()
        {
            if (Carga == true)
            {
                this.Cursor = Cursors.WaitCursor;
                dgvGridView.DataSource = null;
                System.Data.DataTable dtCalendarioProgramacionGrid = null;

                String usuario = MmsWin.Front.Utilerias.VarTem.tmpUsrConv;

                dtCalendarioProgramacionGrid = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenCalendarioProgramacionGrid1(marca, (anio.Substring(2, 2)), temporadaCombo, usuario);
                if (dtCalendarioProgramacionGrid.Rows.Count > 0)
                {
                    SetDoubleBuffered(dgvGridView);
                    dgvGridView.DataSource = null;
                    dgvGridView.DataSource = dtCalendarioProgramacionGrid;
                    nr = dgvGridView.RowCount;
                    this.Text = "Calendario de Calificaciones / " + " " + (nr).ToString() + " Registro(s)";
                    dgvGridView.DataSource = dtCalendarioProgramacionGrid;
                    SetFontAndColors();
                    rowStyle();
                    dgvGridView.Focus();
                    // Seguridad... x las Columnas nuevas
                    ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                    Seguridad("CalendarioCalificacion", "CalendarioCalificacion", ParUser);
                    if (marca != "999")
                    {
                    }
                    else
                    {
                        marca = MmsWin.Front.Utilerias.VarTem.tmpUSRMAR;
                    }

                    if (marca == "999")
                    {
                        this.Controls["gbMarca"].Enabled = true;
                    }
                    try
                    {
                        this.dgvGridView.CurrentCell = this.dgvGridView[2, 0];
                    }
                    catch { }
                }
                this.Cursor = Cursors.Default;
            }

        }
        // Seguridad                                                                                
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab    = row["SEGHAC"].ToString();
                string ValVis    = row["SEGVIC"].ToString();
                string tipo      = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                         
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvGridView.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvGridView.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenuStrip.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenuStrip.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        public string MonthName(int month)
        {
            DateTimeFormatInfo dtinfo = new CultureInfo("es-ES", false).DateTimeFormat;
            return dtinfo.GetMonthName(month);
        }

        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvGridView.ColumnHeadersHeight = 60;
            //   this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
            dgvGridView.RowHeadersVisible = false;
            this.dgvGridView.Columns["CPRSEQ"].Frozen = true;

            dgvGridView.Columns["CPRMAR"].Visible = false;
            dgvGridView.Columns["CPRANO"].Visible = false;
            //dgvGridView.Columns["CPRSED"].Visible = false;
            dgvGridView.Columns["CPRREN"].Visible = false;

            //dgvGridView.Columns[60].Visible = false;
            dgvGridView.Columns["CPRUAL"].Visible = false;
            dgvGridView.Columns["CPRFAL"].Visible = false;
            dgvGridView.Columns["CPRHAL"].Visible = false;
            dgvGridView.Columns["CPRUCA"].Visible = false;
            dgvGridView.Columns["CPRFCA"].Visible = false;
            dgvGridView.Columns["CPRHCA"].Visible = false;

            dgvGridView.Columns["CPRMAR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRANO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CPRTXT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CPRSEA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRTAB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns["CPRTB2"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            
            dgvGridView.Columns["CPRSED"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["CPRREN"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRSEQ"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS01"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS02"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS03"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS04"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS05"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS06"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS07"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS08"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS09"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS10"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS11"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS12"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS13"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS14"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS15"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS16"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS17"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS18"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS19"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS20"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS21"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS22"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS23"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS24"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS25"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS26"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS27"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS28"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS29"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS30"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS31"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS32"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS33"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS34"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS35"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS36"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS37"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS38"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS39"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS40"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS41"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS42"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS43"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS44"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS45"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS46"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS47"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS48"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS49"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS50"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS51"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS52"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRS53"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns["CPRX01"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX02"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX03"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX04"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX05"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX06"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX07"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX08"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX09"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX10"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX11"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX12"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX13"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX14"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX15"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX16"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX17"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX18"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX19"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX20"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX21"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX22"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX23"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX24"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX25"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns["CPRX26"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX27"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX28"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX29"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX30"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX31"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX32"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX33"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX34"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX35"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX36"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX37"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX38"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX39"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX40"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX41"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX42"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX43"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX44"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX45"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX46"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX47"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX48"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX48"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX50"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX51"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX52"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRX53"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns["CPRUAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["CPRFAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns["CPRMAR"].Width = 50;
            dgvGridView.Columns["CPRANO"].Width = 50;
            dgvGridView.Columns["CPRTXT"].Width = 110;
            dgvGridView.Columns["CPRSEA"].Width = 35;
            dgvGridView.Columns["CPRTAB"].Width = 30;
            dgvGridView.Columns["CPRTB2"].Width = 30;
            
            dgvGridView.Columns["CPRSED"].Width = 115;
            dgvGridView.Columns["CPRREN"].Width = 25;
            dgvGridView.Columns["CPRSEQ"].Width = 45;
            dgvGridView.Columns["CPRS01"].Width = 25;
            dgvGridView.Columns["CPRS02"].Width = 25;
            dgvGridView.Columns["CPRS03"].Width = 25;
            dgvGridView.Columns["CPRS04"].Width = 25;
            dgvGridView.Columns["CPRS05"].Width = 25;
            dgvGridView.Columns["CPRS06"].Width = 25;
            dgvGridView.Columns["CPRS07"].Width = 25;
            dgvGridView.Columns["CPRS08"].Width = 25;
            dgvGridView.Columns["CPRS09"].Width = 25;
            dgvGridView.Columns["CPRS10"].Width = 25;
            dgvGridView.Columns["CPRS11"].Width = 25;
            dgvGridView.Columns["CPRS12"].Width = 25;
            dgvGridView.Columns["CPRS13"].Width = 25;
            dgvGridView.Columns["CPRS14"].Width = 25;
            dgvGridView.Columns["CPRS15"].Width = 25;
            dgvGridView.Columns["CPRS16"].Width = 25;
            dgvGridView.Columns["CPRS17"].Width = 25;
            dgvGridView.Columns["CPRS18"].Width = 25;
            dgvGridView.Columns["CPRS19"].Width = 25;
            dgvGridView.Columns["CPRS20"].Width = 25;
            dgvGridView.Columns["CPRS21"].Width = 25;
            dgvGridView.Columns["CPRS22"].Width = 25;
            dgvGridView.Columns["CPRS23"].Width = 25;
            dgvGridView.Columns["CPRS24"].Width = 25;
            dgvGridView.Columns["CPRS25"].Width = 25;
            dgvGridView.Columns["CPRS26"].Width = 25;
            dgvGridView.Columns["CPRS27"].Width = 25;
            dgvGridView.Columns["CPRS28"].Width = 25;
            dgvGridView.Columns["CPRS29"].Width = 25;
            dgvGridView.Columns["CPRS30"].Width = 25;
            dgvGridView.Columns["CPRS31"].Width = 25;
            dgvGridView.Columns["CPRS32"].Width = 25;
            dgvGridView.Columns["CPRS33"].Width = 25;
            dgvGridView.Columns["CPRS34"].Width = 25;
            dgvGridView.Columns["CPRS35"].Width = 25;
            dgvGridView.Columns["CPRS36"].Width = 25;
            dgvGridView.Columns["CPRS37"].Width = 25;
            dgvGridView.Columns["CPRS38"].Width = 25;
            dgvGridView.Columns["CPRS39"].Width = 25;
            dgvGridView.Columns["CPRS40"].Width = 25;
            dgvGridView.Columns["CPRS41"].Width = 25;
            dgvGridView.Columns["CPRS42"].Width = 25;
            dgvGridView.Columns["CPRS43"].Width = 25;
            dgvGridView.Columns["CPRS44"].Width = 25;
            dgvGridView.Columns["CPRS45"].Width = 25;
            dgvGridView.Columns["CPRS46"].Width = 25;
            dgvGridView.Columns["CPRS47"].Width = 25;
            dgvGridView.Columns["CPRS48"].Width = 25;
            dgvGridView.Columns["CPRS49"].Width = 25;
            dgvGridView.Columns["CPRS50"].Width = 25;
            dgvGridView.Columns["CPRS51"].Width = 25;
            dgvGridView.Columns["CPRS52"].Width = 25;
            dgvGridView.Columns["CPRS53"].Width = 25;

            dgvGridView.Columns["CPRX01"].Width = 25;
            dgvGridView.Columns["CPRX02"].Width = 25;
            dgvGridView.Columns["CPRX03"].Width = 25;
            dgvGridView.Columns["CPRX04"].Width = 25;
            dgvGridView.Columns["CPRX05"].Width = 25;
            dgvGridView.Columns["CPRX06"].Width = 25;
            dgvGridView.Columns["CPRX07"].Width = 25;
            dgvGridView.Columns["CPRX08"].Width = 25;
            dgvGridView.Columns["CPRX09"].Width = 25;
            dgvGridView.Columns["CPRX10"].Width = 25;
            dgvGridView.Columns["CPRX11"].Width = 25;
            dgvGridView.Columns["CPRX12"].Width = 25;
            dgvGridView.Columns["CPRX13"].Width = 25;
            dgvGridView.Columns["CPRX14"].Width = 25;
            dgvGridView.Columns["CPRX15"].Width = 25;
            dgvGridView.Columns["CPRX16"].Width = 25;
            dgvGridView.Columns["CPRX17"].Width = 25;
            dgvGridView.Columns["CPRX18"].Width = 25;
            dgvGridView.Columns["CPRX19"].Width = 25;
            dgvGridView.Columns["CPRX20"].Width = 25;
            dgvGridView.Columns["CPRX21"].Width = 25;
            dgvGridView.Columns["CPRX22"].Width = 25;
            dgvGridView.Columns["CPRX23"].Width = 25;
            dgvGridView.Columns["CPRX24"].Width = 25;
            dgvGridView.Columns["CPRX25"].Width = 25;

            dgvGridView.Columns["CPRX26"].Width = 25;
            dgvGridView.Columns["CPRX27"].Width = 25;
            dgvGridView.Columns["CPRX28"].Width = 25;
            dgvGridView.Columns["CPRX29"].Width = 25;
            dgvGridView.Columns["CPRX30"].Width = 25;
            dgvGridView.Columns["CPRX31"].Width = 25;
            dgvGridView.Columns["CPRX32"].Width = 25;
            dgvGridView.Columns["CPRX33"].Width = 25;
            dgvGridView.Columns["CPRX34"].Width = 25;
            dgvGridView.Columns["CPRX35"].Width = 25;
            dgvGridView.Columns["CPRX36"].Width = 25;
            dgvGridView.Columns["CPRX37"].Width = 25;
            dgvGridView.Columns["CPRX38"].Width = 25;
            dgvGridView.Columns["CPRX39"].Width = 25;
            dgvGridView.Columns["CPRX40"].Width = 25;
            dgvGridView.Columns["CPRX41"].Width = 25;
            dgvGridView.Columns["CPRX42"].Width = 25;
            dgvGridView.Columns["CPRX43"].Width = 25;
            dgvGridView.Columns["CPRX44"].Width = 25;
            dgvGridView.Columns["CPRX45"].Width = 25;
            dgvGridView.Columns["CPRX46"].Width = 25;
            dgvGridView.Columns["CPRX47"].Width = 25;
            dgvGridView.Columns["CPRX48"].Width = 25;
            dgvGridView.Columns["CPRX49"].Width = 25;
            dgvGridView.Columns["CPRX50"].Width = 25;
            dgvGridView.Columns["CPRX51"].Width = 25;
            dgvGridView.Columns["CPRX52"].Width = 25;
            dgvGridView.Columns["CPRX53"].Width = 25;

            dgvGridView.Columns["CPRUAL"].Width = 80;
            dgvGridView.Columns["CPRFAL"].Width = 80;
            dgvGridView.Columns["CPRHAL"].Width = 80;
            dgvGridView.Columns["CPRUCA"].Width = 80;
            dgvGridView.Columns["CPRFCA"].Width = 80;
            dgvGridView.Columns["CPRHCA"].Width = 80;

            dgvGridView.Columns["CPRTAB"].DefaultCellStyle.Format = "###";
            dgvGridView.Columns["CPRTB2"].DefaultCellStyle.Format = "###";

            dgvGridView.Columns["CPRMAR"].HeaderText = "Marca";
            dgvGridView.Columns["CPRANO"].HeaderText = "Año/Mes";
            dgvGridView.Columns["CPRTXT"].HeaderText = "Referencia";
            dgvGridView.Columns["CPRSEA"].HeaderText = "Tmporada";
            dgvGridView.Columns["CPRTAB"].HeaderText = "Tabla  %";
            dgvGridView.Columns["CPRTB2"].HeaderText = "Tabla Tienda %";
            dgvGridView.Columns["CPRSED"].HeaderText = "Descripción";
            dgvGridView.Columns["CPRREN"].HeaderText = "Renglon";
            dgvGridView.Columns["CPRSEQ"].HeaderText = "Secuencia";

            CultureInfo cultureInfo   = Thread.CurrentThread.CurrentCulture;
            TextInfo textInfo = cultureInfo.TextInfo;
            
            DateTime fecha = Convert.ToDateTime("01/01/2017");

            // cabecero de Mese del Año
            for (int i = 0; i <= 365; i++)
            {

                fecha = fecha.AddDays(i);
            
                string NombreMes = textInfo.ToTitleCase( (MonthName(fecha.Month)).ToString()); // .ToUpper();

                int NoSemana = System.Globalization.CultureInfo.CurrentUICulture.Calendar.GetWeekOfYear(fecha, CalendarWeekRule.FirstFullWeek, fecha.DayOfWeek);

                dgvGridView.Columns[NoSemana + 8 ].HeaderText = NombreMes;

                if (NombreMes == "Enero")      { dgvGridView.Columns[NoSemana + 8].HeaderCell.Style.BackColor = Color.LightGreen;}
                if (NombreMes == "Febrero")    { dgvGridView.Columns[NoSemana + 8].HeaderCell.Style.BackColor = Color.LightSeaGreen; }
                if (NombreMes == "Marzo")      { dgvGridView.Columns[NoSemana + 8].HeaderCell.Style.BackColor = Color.LightSlateGray; }
                if (NombreMes == "Abril")      { dgvGridView.Columns[NoSemana + 8].HeaderCell.Style.BackColor = Color.LightCoral; }
                if (NombreMes == "Mayo")       { dgvGridView.Columns[NoSemana + 8].HeaderCell.Style.BackColor = Color.LightSlateGray; }
                if (NombreMes == "Junio")      { dgvGridView.Columns[NoSemana + 8].HeaderCell.Style.BackColor = Color.LightSkyBlue; }
                if (NombreMes == "Julio")      { dgvGridView.Columns[NoSemana + 8].HeaderCell.Style.BackColor = Color.LightSalmon; }
                if (NombreMes == "Agosto")     { dgvGridView.Columns[NoSemana + 8].HeaderCell.Style.BackColor = Color.LightSlateGray; }
                if (NombreMes == "Septiembre") { dgvGridView.Columns[NoSemana + 8].HeaderCell.Style.BackColor = Color.LightGreen; }
                if (NombreMes == "Octubre")    { dgvGridView.Columns[NoSemana + 8].HeaderCell.Style.BackColor = Color.LightSkyBlue; }
                if (NombreMes == "Noviembre")  { dgvGridView.Columns[NoSemana + 8].HeaderCell.Style.BackColor = Color.LightGreen; }
                if (NombreMes == "Diciembre")  { dgvGridView.Columns[NoSemana + 8].HeaderCell.Style.BackColor = Color.LightSalmon; }
            }

            fecha = Convert.ToDateTime("01/01/2018");
            // cabecero de Mese del Año
            for (int i = 365; i <= 730; i++)
            {
                fecha = fecha.AddDays(1);

                string NombreMes = textInfo.ToTitleCase((MonthName(fecha.Month)).ToString()); 

                int NoSemana = System.Globalization.CultureInfo.CurrentUICulture.Calendar.GetWeekOfYear(fecha, CalendarWeekRule.FirstFullWeek, fecha.DayOfWeek);

                dgvGridView.Columns[NoSemana + 61].HeaderText = NombreMes;

                if (NombreMes == "Enero")      { dgvGridView.Columns[NoSemana + 61].HeaderCell.Style.BackColor = Color.LightGreen; }
                if (NombreMes == "Febrero")    { dgvGridView.Columns[NoSemana + 61].HeaderCell.Style.BackColor = Color.LightSeaGreen; }
                if (NombreMes == "Marzo")      { dgvGridView.Columns[NoSemana + 61].HeaderCell.Style.BackColor = Color.LightSlateGray; }
                if (NombreMes == "Abril")      { dgvGridView.Columns[NoSemana + 61].HeaderCell.Style.BackColor = Color.LightCoral; }
                if (NombreMes == "Mayo")       { dgvGridView.Columns[NoSemana + 61].HeaderCell.Style.BackColor = Color.LightSlateGray; }
                if (NombreMes == "Junio")      { dgvGridView.Columns[NoSemana + 61].HeaderCell.Style.BackColor = Color.LightSkyBlue; }
                if (NombreMes == "Julio")      { dgvGridView.Columns[NoSemana + 61].HeaderCell.Style.BackColor = Color.LightSalmon; }
                if (NombreMes == "Agosto")     { dgvGridView.Columns[NoSemana + 61].HeaderCell.Style.BackColor = Color.LightSlateGray; }
                if (NombreMes == "Septiembre") { dgvGridView.Columns[NoSemana + 61].HeaderCell.Style.BackColor = Color.LightGreen; }
                if (NombreMes == "Octubre")    { dgvGridView.Columns[NoSemana + 61].HeaderCell.Style.BackColor = Color.LightSkyBlue; }
                if (NombreMes == "Noviembre")  { dgvGridView.Columns[NoSemana + 61].HeaderCell.Style.BackColor = Color.LightGreen; }
                if (NombreMes == "Diciembre")  { dgvGridView.Columns[NoSemana + 61].HeaderCell.Style.BackColor = Color.LightSalmon; }
            }

            //dgvGridView.Columns["CPRUAL"].HeaderText = " Usuario";
            dgvGridView.Columns["CPRFAL"].HeaderText = " Fecha";
            dgvGridView.Columns["CPRHAL"].HeaderText = " Hora";
            dgvGridView.Columns["CPRUCA"].HeaderText = " Usuario";
            dgvGridView.Columns["CPRFCA"].HeaderText = " Fecha";
            dgvGridView.Columns["CPRHCA"].HeaderText = " Hora";

            dgvGridView.Columns["CPRMAR"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns["CPRANO"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns["CPRTXT"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns["CPRSEA"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns["CPRTAB"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns["CPRTB2"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns["CPRSED"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns["CPRREN"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns["CPRSEQ"].HeaderCell.Style.BackColor = Color.LightSlateGray;

            dgvGridView.Columns["CPRUAL"].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
            dgvGridView.Columns["CPRUAL"].HeaderCell.Style.ForeColor = Color.White;

            dgvGridView.Columns["CPRFAL"].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
            dgvGridView.Columns["CPRFAL"].HeaderCell.Style.ForeColor = Color.White;

            dgvGridView.Columns["CPRHAL"].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
            dgvGridView.Columns["CPRHAL"].HeaderCell.Style.ForeColor = Color.White;

            dgvGridView.Columns["CPRUCA"].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
            dgvGridView.Columns["CPRUCA"].HeaderCell.Style.ForeColor = Color.White;

            dgvGridView.Columns["CPRFCA"].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
            dgvGridView.Columns["CPRFCA"].HeaderCell.Style.ForeColor = Color.White;

            dgvGridView.Columns["CPRHCA"].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
            dgvGridView.Columns["CPRHCA"].HeaderCell.Style.ForeColor = Color.White;

            dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            dgvGridView.EnableHeadersVisualStyles = false;

            foreach (DataGridViewRow row in dgvGridView.Rows)
            {
                //row.Cells[6].Style.ForeColor = Color.DarkBlue;
            }
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                Regs += 1;

                this.dgvGridView.Rows[Regs - 1].Cells["CPRS01"].Style.BackColor = Color.IndianRed;
                this.dgvGridView.Rows[Regs - 1].Cells["CPRS02"].Style.BackColor = Color.IndianRed;
                this.dgvGridView.Rows[Regs - 1].Cells["CPRS03"].Style.BackColor = Color.IndianRed;
                this.dgvGridView.Rows[Regs - 1].Cells["CPRS04"].Style.BackColor = Color.IndianRed;
                this.dgvGridView.Rows[Regs - 1].Cells["CPRS05"].Style.BackColor = Color.IndianRed;
                this.dgvGridView.Rows[Regs - 1].Cells["CPRS06"].Style.BackColor = Color.IndianRed;

                this.dgvGridView.Rows[Regs - 1].Cells["CPRS13"].Style.BackColor = Color.LightBlue;
                this.dgvGridView.Rows[Regs - 1].Cells["CPRS14"].Style.BackColor = Color.LightBlue;

                this.dgvGridView.Rows[Regs - 1].Cells["CPRS19"].Style.BackColor = Color.LightBlue;
                this.dgvGridView.Rows[Regs - 1].Cells["CPRS20"].Style.BackColor = Color.LightBlue;

                this.dgvGridView.Rows[Regs - 1].Cells["CPRS31"].Style.BackColor = Color.IndianRed;
                this.dgvGridView.Rows[Regs - 1].Cells["CPRS32"].Style.BackColor = Color.IndianRed;
                this.dgvGridView.Rows[Regs - 1].Cells["CPRS33"].Style.BackColor = Color.IndianRed;
                this.dgvGridView.Rows[Regs - 1].Cells["CPRS34"].Style.BackColor = Color.IndianRed;
                this.dgvGridView.Rows[Regs - 1].Cells["CPRS35"].Style.BackColor = Color.IndianRed;

                this.dgvGridView.Rows[Regs - 1].Cells["CPRS47"].Style.BackColor = Color.LightBlue;

                this.dgvGridView.Rows[Regs - 1].Cells["CPRS53"].Style.BackColor = Color.LightSlateGray;

                    //dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                   
                    string color = Convert.ToString(this.dgvGridView.Rows[Regs - 1].Cells[2].Value);

                    //if (color == "") { this.dgvGridView.Rows[Regs - 1].Cells[2].Style.BackColor = Color.LightSalmon; }
                    if (color == "ENERO")      { this.dgvGridView.Rows[Regs - 1].Cells[2].Style.BackColor = Color.LightGreen;     this.dgvGridView.Rows[Regs - 1].Cells[2].Style.ForeColor = Color.White; }
                    if (color == "FEBRERO")    { this.dgvGridView.Rows[Regs - 1].Cells[2].Style.BackColor = Color.LightSeaGreen;  this.dgvGridView.Rows[Regs - 1].Cells[2].Style.ForeColor = Color.White; }
                    if (color == "MARZO")      { this.dgvGridView.Rows[Regs - 1].Cells[2].Style.BackColor = Color.LightSlateGray; this.dgvGridView.Rows[Regs - 1].Cells[2].Style.ForeColor = Color.White; }
                    if (color == "ABRIL")      { this.dgvGridView.Rows[Regs - 1].Cells[2].Style.BackColor = Color.LightCoral;     this.dgvGridView.Rows[Regs - 1].Cells[2].Style.ForeColor = Color.White; }
                    if (color == "MAYO")       { this.dgvGridView.Rows[Regs - 1].Cells[2].Style.BackColor = Color.LightSlateGray; this.dgvGridView.Rows[Regs - 1].Cells[2].Style.ForeColor = Color.White; }
                    if (color == "JUNIO")      { this.dgvGridView.Rows[Regs - 1].Cells[2].Style.BackColor = Color.LightSkyBlue;   this.dgvGridView.Rows[Regs - 1].Cells[2].Style.ForeColor = Color.White; }
                    if (color == "JULIO")      { this.dgvGridView.Rows[Regs - 1].Cells[2].Style.BackColor = Color.LightSalmon;    this.dgvGridView.Rows[Regs - 1].Cells[2].Style.ForeColor = Color.White; }
                    if (color == "AGOSTO")     { this.dgvGridView.Rows[Regs - 1].Cells[2].Style.BackColor = Color.LightSlateGray; this.dgvGridView.Rows[Regs - 1].Cells[2].Style.ForeColor = Color.White; }
                    if (color == "SEPTIEMBRE") { this.dgvGridView.Rows[Regs - 1].Cells[2].Style.BackColor = Color.LightGreen;     this.dgvGridView.Rows[Regs - 1].Cells[2].Style.ForeColor = Color.White; }
                    if (color == "OCTUBRE")    { this.dgvGridView.Rows[Regs - 1].Cells[2].Style.BackColor = Color.LightSkyBlue;   this.dgvGridView.Rows[Regs - 1].Cells[2].Style.ForeColor = Color.White; }
                    if (color == "NOVIEMBRE")  { this.dgvGridView.Rows[Regs - 1].Cells[2].Style.BackColor = Color.LightGreen;     this.dgvGridView.Rows[Regs - 1].Cells[2].Style.ForeColor = Color.White; }
                    if (color == "DICIEMBRE")  { this.dgvGridView.Rows[Regs - 1].Cells[2].Style.BackColor = Color.LightSalmon;    this.dgvGridView.Rows[Regs - 1].Cells[2].Style.ForeColor = Color.White; }
                    
                    for (int i = 1; i <= 106; i++)
                     {
                         string celda = Convert.ToString(this.dgvGridView.Rows[Regs - 1].Cells[i].Value);

                         if (celda == "R")   { this.dgvGridView.Rows[Regs - 1].Cells[i].Style.BackColor = Color.LightSkyBlue; }
                         if (celda == "P1")  { this.dgvGridView.Rows[Regs - 1].Cells[i].Style.BackColor = Color.LightSalmon; }
                         if (celda == "C")   { this.dgvGridView.Rows[Regs - 1].Cells[i].Style.BackColor = Color.LightGreen; }
                         if (celda == "RB1") { this.dgvGridView.Rows[Regs - 1].Cells[i].Style.BackColor = Color.Yellow; dgvGridView.Columns[i].Width = 31; }
                         if (celda == "RB2") { this.dgvGridView.Rows[Regs - 1].Cells[i].Style.BackColor = Color.Red; this.dgvGridView.Rows[Regs - 1].Cells[i].Style.ForeColor = Color.White; dgvGridView.Columns[i].Width = 31; }
                         if (celda == "RB3") { this.dgvGridView.Rows[Regs - 1].Cells[i].Style.BackColor = Color.Blue; this.dgvGridView.Rows[Regs - 1].Cells[i].Style.ForeColor = Color.White; dgvGridView.Columns[i].Width = 31; }
                         if (celda == "RB4") { this.dgvGridView.Rows[Regs - 1].Cells[i].Style.BackColor = Color.Green; this.dgvGridView.Rows[Regs - 1].Cells[i].Style.ForeColor = Color.White; dgvGridView.Columns[i].Width = 31; }
                         if (celda == "RB5") { this.dgvGridView.Rows[Regs - 1].Cells[i].Style.BackColor = Color.Green; this.dgvGridView.Rows[Regs - 1].Cells[i].Style.ForeColor = Color.White; dgvGridView.Columns[i].Width = 31; }
                         if (celda == "P2")  { this.dgvGridView.Rows[Regs - 1].Cells[i].Style.BackColor = Color.SaddleBrown; }
                         if (celda == "OTO") { this.dgvGridView.Rows[Regs - 1].Cells[i].Style.BackColor = Color.LightSkyBlue; dgvGridView.Columns[i].Width = 31; }
                         if (celda == "INV") { this.dgvGridView.Rows[Regs - 1].Cells[i].Style.BackColor = Color.LightSalmon; }
                         if (celda == "GRD") { this.dgvGridView.Rows[Regs - 1].Cells[i].Style.BackColor = Color.LightGreen; }
                         if (celda == "PRI") { this.dgvGridView.Rows[Regs - 1].Cells[i].Style.BackColor = Color.LightGreen; dgvGridView.Columns[i].Width = 31; }
                         if (celda == "TT")  { this.dgvGridView.Rows[Regs - 1].Cells[i].Style.BackColor = Color.Yellow; }
                         if (celda == "VER") { this.dgvGridView.Rows[Regs - 1].Cells[i].Style.BackColor = Color.Red; dgvGridView.Columns[i].Width = 31; }
                    }

                    //this.dgvGridView.Rows[Regs - 1].Cells[5].Style.BackColor = Color.Orange;
            }
        }

        private void toolTipGridView()
        {
            int Regs = 0;
            string fechaMms = string.Empty;

            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                Regs += 1;
                for (int i = 1; i <= 85; i++)
                {
                    fechaMms = "Semana " + (i - 7);

                    //Semana MMs 
                    //string anio   = tbAnio.Text;
                    //string semana = tbSemana.Text;
                    if (i - 7 > 0)
                    {
                        string Mensaje = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenFechaMmsNegocio(anio.Substring(2, 2), i - 7, out fechaMms);
                    }
                    this.dgvGridView.Rows[Regs - 1].Cells[i].ToolTipText = fechaMms;
                }
            }
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        protected void BindMarca()
        {
            try
            {
                cbMarca.DataSource = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();
                cbMarca.DisplayMember = "Value";
                cbMarca.ValueMember = "Key";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void BindTemporadas()
        {
            try
            {
                cbTemporada.DataSource = MmsWin.Negocio.Catalogos.TemporadaMms.GetInstance().ObtenTemporadaMms().ToList();
                cbTemporada.DisplayMember = "Value";
                cbTemporada.ValueMember = "Key";
                temporada = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void CalendarioProgramacionGrid_Resize(object sender, EventArgs e)
        {
            dgvGridView.Width = this.Width - dgvOffset;
            dgvGridView.Height = this.Height - dgvOffset2;
        }

        private void cambiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //MmsWin.Front.ConvenioMelody.ConvenioMelodyABC i = new MmsWin.Front.ConvenioMelody.ConvenioMelodyABC();
            //i.MdiParent = ConvenioMelodyMDI.ActiveForm; 
            //i.Show();
        }

        private void dgvGridView_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                BinData();
                dgvGridView.Focus();
                dgvGridView.Select();
            }
        }

        private void dgvGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int Row = e.RowIndex;
            int Col = e.ColumnIndex;

            //Form2 form2 = new Form2();

            // //add handler to catch when child form is closed    
            // form2.FormClosed += new FormClosedEventHandler(form2_FormClosed);
            // form2.ShowDialog();

            //private void form2_FormClosed(object sender, FormClosedEventArgs e)           {              
            // //when child form is closed, this code is executed   
            //// Bind the Grid view       
            // PopulateControls

            //MmsWin.Front.ConvenioMelody.CalificacionGrid RecargaGrid = new MmsWin.Front.ConvenioMelody.CalificacionGrid();
            //RecargaGrid.FormClosed += new FormClosedEventHandler(RecargaGrid_FormClosed);
            //RecargaGrid.ShowDialog();
            //RecargaGrid.Refresh();
            ////RecargaGrid.Show();

            calClaveCel = this.dgvGridView.CurrentRow.Cells[Col].Value.ToString();
            // Genera evento de calificaciones
            if (calClaveCel == "P1" || calClaveCel == "C")
            {
                MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calClaveCel = this.dgvGridView.CurrentRow.Cells[Col].Value.ToString();
            }
                Col = Col - 8;

                MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calColumna = Convert.ToString(Col);

                cargaVariables();

                string fechaMms = string.Empty;
                //int Row = e.RowIndex;
                //int Col = e.ColumnIndex;

                if (Col - 7 > 0 && Row > 0)
                {
                    string Mensaje = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenFechaMmsNegocio(anio.Substring(2, 2), Col - 7, out fechaMms);
                    this.dgvGridView.Rows[Row].Cells[Col].ToolTipText = fechaMms;
                }


        }

        private void RecargaGrid_FormClosed(object sender, FormClosedEventArgs e)
        {
            //when child form is closed, this code is executed   
            // Bind the Grid view       
            BinData();
           
        }

        private void RecargaGrid_FormLoad(object sender, FormClosedEventArgs e)
        {
            BinData();
        }

        private void dgvGridView_SelectionChanged(object sender, EventArgs e)
        {
            cargaVariables();
            //rowStyle();
            //SendKeys.Send("{ENTER}");
            SendKeys.Flush();

        }

        private void cargaVariables() 
        {
            try
            {
                MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calAnio         = this.dgvGridView.CurrentRow.Cells["CPRANO"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calMarca        = this.dgvGridView.CurrentRow.Cells["CPRMAR"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calTemporada    = this.dgvGridView.CurrentRow.Cells["CPRSEA"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calTablaPorc    = this.dgvGridView.CurrentRow.Cells["CPRTAB"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calTablaPorc2    = this.dgvGridView.CurrentRow.Cells["CPRTB2"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calRentOdesplaz = this.dgvGridView.CurrentRow.Cells["CPRSED"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calRenglon      = this.dgvGridView.CurrentRow.Cells["CPRREN"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.corrUsuario     = MmsWin.Front.Utilerias.VarTem.tmpUser; 

            }
            catch { };
        }

        private void dgvGridView_DoubleClick(object sender, EventArgs e)
        {
            //MmsWin.Front.ConvenioMelody.ConvenioMelodyABC i = new MmsWin.Front.ConvenioMelody.ConvenioMelodyABC();
            //i.MdiParent = ConvenioMelodyMDI.ActiveForm;
            //i.Show();
        }

        private void dgvGridView_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                SendKeys.Send("{UP}");
                SendKeys.Flush();
                //MmsWin.Front.ConvenioMelody.ConvenioMelodyABC i = new MmsWin.Front.ConvenioMelody.ConvenioMelodyABC();
                //i.MdiParent = ConvenioMelodyMDI.ActiveForm;
                //i.Show();
            }

        }

        private void tbLista_TextChanged(object sender, EventArgs e)
        {
            //BinData();
            //tbLista.Focus();
        }

        private void dgvGridView_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            //if (repintado == true)
            //{
            //    if (e.RowIndex == -1 && e.ColumnIndex >= 0)
            //    {
            //        DataGridView dgvObj = (DataGridView)sender;
            //        String col = dgvObj.Columns[e.ColumnIndex].Name.ToLower();
            //        if (col == "cprmar" || col == "cpram" || col == "cprsem" || col == "cprual" || col == "cprfal"
            //            || col == "cprhal" || col == "cpruca" || col == "cprfca" || col == "cprhca" || col == "cpramd" || col == "cprtxt")
            //        { }
            //        else
            //        {
            //            e.PaintBackground(e.CellBounds, true);
            //            e.Graphics.TranslateTransform(e.CellBounds.Left, e.CellBounds.Bottom);
            //            e.Graphics.RotateTransform(270);
            //            e.Graphics.DrawString(e.FormattedValue.ToString(), e.CellStyle.Font, Brushes.Black, 0, 3);
            //            e.Graphics.ResetTransform();
            //            e.Handled = true;
            //        }
            //    }
            //    //rowStyle();
            //    ////toolTipGridView();
            //    //repintado = false;
            //}
        }

        private void dgvGridView_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            dgvGridView.Rows[0].Frozen = true;
        }

        private void dgvGridView_CellParsing(object sender, DataGridViewCellParsingEventArgs e)
        {
            string temporada = string.Empty;
            string tablaPorc = string.Empty;
            string tablaPorc2 = string.Empty;
            string rentOdespl = string.Empty;
            string mensaje = string.Empty;
            string usuario = string.Empty;
            string anio = string.Empty;
            string columna = string.Empty;
            string estatus = "A";
            string celda = string.Empty;
            int Row = e.RowIndex;
            int Col = e.ColumnIndex;

            string claveCel = Convert.ToString(e.Value);
            claveCel = claveCel.Replace(" ", "");

            temporada = Convert.ToString(e.Value);
            if (Col == 3)
            {
                claveCel = string.Empty;
            }

            if (Col > 8)
            {
                temporada = this.dgvGridView.Rows[Row].Cells[3].Value.ToString();
                tablaPorc = this.dgvGridView.Rows[Row].Cells[4].Value.ToString();
                tablaPorc2 = this.dgvGridView.Rows[Row].Cells[5].Value.ToString();
                rentOdespl = this.dgvGridView.Rows[Row].Cells[6].Value.ToString();
            }

            string anioMes = this.dgvGridView.Rows[Row].Cells[1].Value.ToString();
            anio = (anioMes.Substring(0, 2));
            string semana = this.dgvGridView.Rows[Row].Cells[7].Value.ToString();
            columna = Convert.ToString(Col);
            string marca = this.dgvGridView.Rows[Row].Cells[0].Value.ToString();

            if (claveCel != "")
            {
                this.dgvGridView.Rows[Row].Cells[Col].Style.BackColor = Color.Orange;
            }
            celda = this.dgvGridView.Rows[Row].Cells[Col].OwningColumn.Name;
            usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
            // Actualización de Temporada
            if (Col == 2 || Col == 3 || Col == 4 || Col == 5 || Col == 6 || Col == 7 || Col == 8)                
            {
                mensaje = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateTemporadas(temporada, anio, semana, columna, marca, usuario, celda);
                SetFontAndColors();
                rowStyle();
                //toolTipGridView();
            }
            else
            {
                // Genera evento de calificaciones
                if (claveCel == "R" || claveCel == "P1" || claveCel == "C" || claveCel == "RB1" || claveCel == "RB2" || claveCel == "RB3" || claveCel == "RB4" || claveCel == "RB5" || claveCel == "P2" || claveCel == "" || claveCel == "RENTABILIDAD" || claveCel == "DESPLAZAMIENTO")
                {
                    mensaje = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().EventoCalificacion1(temporada, tablaPorc, tablaPorc2, anio, semana, columna, marca, claveCel, estatus, usuario, rentOdespl);
                    //SetFontAndColors();
                    //rowStyle();
                }
                else
                {
                    MessageBox.Show("la clave no es valida...");
                }
            }
        }

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            marca = " ";
            ComboBox cmbMarca = (ComboBox)sender;
            marca = cmbMarca.SelectedValue.ToString();
            BinData();
            //repintado = true;
        }

        private void cbAnio_SelectedValueChanged(object sender, EventArgs e)
        {
            anio = " ";
            ComboBox cbAnio = (ComboBox)sender;
            anio = cbAnio.SelectedItem.ToString();
            BinData();
            //repintado = true;
        }

        private void dgvGridView_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (dgvGridView.CurrentCell.ColumnIndex  >= 1 || dgvGridView.CurrentCell.ColumnIndex >= 1)
            {
                if (e.Control is TextBox)
                {
                    ((TextBox)(e.Control)).CharacterCasing = CharacterCasing.Upper;
                }
            }
        }

        private void dgvGridView_Sorted(object sender, EventArgs e)
        {
            SetFontAndColors();
            rowStyle();
            //toolTipGridView();
        }

        private void cbTemporada_SelectedValueChanged(object sender, EventArgs e)
        {
            //temporadaCombo = " ";
            //ComboBox cbTemporada = (ComboBox)sender;
            //temporadaCombo = cbTemporada.SelectedItem.ToString();
            //BinData();
            //repintado = true;

            temporadaCombo = " ";
            nr = 0;
            ComboBox cbTemporada = (ComboBox)sender;
            temporadaCombo = cbTemporada.SelectedValue.ToString();
            if (temporadaCombo == "[999, Todos]")
            {
                temporadaCombo = "";
            }
            MmsWin.Front.Utilerias.VarTem.tmpTemporadaMms = cbTemporada.SelectedValue.ToString();

            BinData();
        }

        private void simuladorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string anio      = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calAnio;
            string temporada = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calTemporada;
            string tablaPorc = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calTablaPorc;
            
            string marca     = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calMarca;
            string renglon   = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calRenglon;
            string columna   = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calColumna;
            string usuario   = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.corrUsuario;
            string tipoCal   = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calClaveCel;
            string rentOdesplaz = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calRentOdesplaz;

            string calificacion = string.Empty;
            if (tipoCal == "P1") { calificacion = "PreCalificación"; }
            if (tipoCal == "C") { calificacion = "Calificación"; }
            if (tipoCal == "RB1") { calificacion = "Rebaja 01"; }
            if (tipoCal == "RB2") { calificacion = "Rebaja 02"; }
            if (tipoCal == "RB3") { calificacion = "Rebaja 03"; }
            if (tipoCal == "RB4") { calificacion = "Rebaja 04"; }

            if (tipoCal != "" && calificacion != "")
            {
                string message = "Se va a calificar la semana  " + columna + "  en modo de simulacion";
                string caption = "Confirmación";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;
                result = MessageBox.Show(message, caption, buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)
                {
                    string mensaje = string.Empty;
                    this.Cursor = Cursors.WaitCursor;
                    mensaje = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().EjecutaSimulaciones(anio, temporada, marca, renglon, columna, usuario, calificacion, rentOdesplaz);
                    this.Cursor = Cursors.Default;
                    MessageBox.Show("Simulacion Terminada...");
                }
            }
            else
            {
                MessageBox.Show("No es posible continar con parametros incompletos");
            }
        }

        private void dgvGridView_CellMouseMove(object sender, DataGridViewCellMouseEventArgs e)
        {
            string fechaMms = string.Empty;
            int Row = e.RowIndex;
            int Col = e.ColumnIndex;

            if (Col - 8 > 0 && Row > 0)
            {
                string Mensaje = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenFechaMmsNegocio(anio.Substring(2, 2), Col - 8, out fechaMms);
                this.dgvGridView.Rows[Row].Cells[Col].ToolTipText = fechaMms;
            }
            this.Cursor = Cursors.Default;
        }

        private void dgvGridView_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
          //rowStyle();
          //repintado = false;
        }

        private void calificarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string anio      = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calAnio;
            string temporada = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calTemporada;
            string tablaPorc = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calTablaPorc;
            string tablaPorc2 = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calTablaPorc2;

            string marca   = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calMarca;
            string renglon = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calRenglon;
            string columna = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calColumna;
            string usuario = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.corrUsuario;
            string tipoCal = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calClaveCel;
            string rentOdesplaz = MmsWin.Front.ConvenioMelody.CalendarioProgramacionGrid.calRentOdesplaz;

            string calificacion = string.Empty;
            if (tipoCal == "P1") { calificacion = "PreCalificación"; }
            if (tipoCal == "C") { calificacion = "Calificación"; }
            if (tipoCal == "RB1") { calificacion = "Rebaja 01"; }
            if (tipoCal == "RB2") { calificacion = "Rebaja 02"; }
            if (tipoCal == "RB3") { calificacion = "Rebaja 03"; }
            if (tipoCal == "RB4") { calificacion = "Rebaja 04"; }

            if (tipoCal != "" && calificacion != "")
            {
                string message = "Se va a calificar la semana  " + columna + "  en modo de Calificacion";
                string caption = "Confirmación";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;
                result = MessageBox.Show(message, caption, buttons);
                if (result == System.Windows.Forms.DialogResult.Yes)   
                {
                    string mensaje = string.Empty;
                    this.Cursor = Cursors.WaitCursor;
                    mensaje = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().EjecutaSimulaciones(anio, temporada, marca, renglon, columna, usuario, calificacion, rentOdesplaz);
                    this.Cursor = Cursors.Default;
                    MessageBox.Show("Calificación Terminada...");
                }
            }
            else
            {
                MessageBox.Show("No es posible continar con parametros incompletos");
            }
        }

        private void dgvGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int Row = e.RowIndex;
            int Col = e.ColumnIndex;

            MmsWin.Front.ConvenioMelody.CalificacionGrid RecargaGrid = new MmsWin.Front.ConvenioMelody.CalificacionGrid();
            RecargaGrid.Refresh();
            //RecargaGrid.Show();
        }

        private void CalendarioProgramacionGrid_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Carga Seguridad  
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("CalendarioCalificacion", "CalendarioCalificacion", ParUser);
            }
        }
        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            //
            string NomCol;
            Int32 NoCol = dgvGridView.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvGridView.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      

            string NomMenu;
            Int32 NoItems = cmMenuStrip.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenuStrip.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void pbRegNew_Click(object sender, EventArgs e)
        {


           //string message = "Se va a generar un reglon Nuevo";
           // string caption = "Confirmación";
           // MessageBoxButtons buttons = MessageBoxButtons.YesNo;
           // DialogResult result;
           // result = MessageBox.Show(message, caption, buttons);
           // if (result == System.Windows.Forms.DialogResult.Yes)
           // {
                string mensaje = string.Empty;
                this.Cursor = Cursors.WaitCursor;
                mensaje = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().InsertRenglonNuevo(marca, anio);
                this.Cursor = Cursors.Default;
            //}
        }

        private void gbAnio_Paint(object sender, PaintEventArgs e)
        {
            GroupBox box = sender as GroupBox;
            DrawGroupBox(box, e.Graphics, Color.DarkSlateGray, Color.Red);
        }

        private void DrawGroupBox(GroupBox box, Graphics g, Color textColor, Color borderColor)
        {
            if (box != null)
            {
                Brush textBrush = new SolidBrush(textColor);
                Brush borderBrush = new SolidBrush(borderColor);
                Pen borderPen = new Pen(borderBrush);
                SizeF strSize = g.MeasureString(box.Text, box.Font);
                Rectangle rect = new Rectangle(box.ClientRectangle.X,
                                               box.ClientRectangle.Y + (int)(strSize.Height / 2),
                                               box.ClientRectangle.Width - 1,
                                               box.ClientRectangle.Height - (int)(strSize.Height / 2) - 1);

                // Clear text and border
                g.Clear(this.BackColor);

                // Draw text
                g.DrawString(box.Text, box.Font, textBrush, box.Padding.Left, 0);

                // Drawing Border
                //Left
                g.DrawLine(borderPen, rect.Location, new Point(rect.X, rect.Y + rect.Height));
                //Right
                g.DrawLine(borderPen, new Point(rect.X + rect.Width, rect.Y), new Point(rect.X + rect.Width, rect.Y + rect.Height));
                //Bottom
                g.DrawLine(borderPen, new Point(rect.X, rect.Y + rect.Height), new Point(rect.X + rect.Width, rect.Y + rect.Height));
                //Top1
                g.DrawLine(borderPen, new Point(rect.X, rect.Y), new Point(rect.X + box.Padding.Left, rect.Y));
                //Top2
                g.DrawLine(borderPen, new Point(rect.X + box.Padding.Left + (int)(strSize.Width), rect.Y), new Point(rect.X + rect.Width, rect.Y));
            }
        }

        private void gbMarca_Paint(object sender, PaintEventArgs e)
        {
            GroupBox box = sender as GroupBox;
            DrawGroupBox(box, e.Graphics, Color.DarkSlateGray, Color.Red);
        }

        private void gbTemporada_Paint(object sender, PaintEventArgs e)
        {
            GroupBox box = sender as GroupBox;
            DrawGroupBox(box, e.Graphics, Color.DarkSlateGray, Color.Red);
        }

        private void cbTemporada_SelectedIndexChanged(object sender, EventArgs e)
        {
            //temporadaCombo = " ";
            //ComboBox cbTemporada = (ComboBox)sender;
            //temporadaCombo = cbTemporada.SelectedItem.ToString();
            //BinData();
            //repintado = true;
        }
    }
}
