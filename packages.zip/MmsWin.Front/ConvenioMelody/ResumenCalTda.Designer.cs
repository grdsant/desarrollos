﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class ResumenCalTda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ResumenCalTda));
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.cmMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.detalleCalNivEstTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.rebajaDiferenciadaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnTitulo = new System.Windows.Forms.Panel();
            this.btCalOri = new System.Windows.Forms.Button();
            this.lbMargen = new System.Windows.Forms.Label();
            this.lbPrecio = new System.Windows.Forms.Label();
            this.btQuitaChks = new System.Windows.Forms.Button();
            this.lbCosto = new System.Windows.Forms.Label();
            this.btMarcaChk = new System.Windows.Forms.Button();
            this.lblbMargen = new System.Windows.Forms.Label();
            this.lblbPrecio = new System.Windows.Forms.Label();
            this.lblbCosto = new System.Windows.Forms.Label();
            this.lbIdEstilo = new System.Windows.Forms.Label();
            this.lbIdProveedor = new System.Windows.Forms.Label();
            this.lbDesEstilo = new System.Windows.Forms.Label();
            this.lbDesProveedor = new System.Windows.Forms.Label();
            this.lbEstilo = new System.Windows.Forms.Label();
            this.lbProveedor = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btAplicar = new System.Windows.Forms.Button();
            this.lbTitulo = new System.Windows.Forms.Label();
            this.pbFoto = new System.Windows.Forms.PictureBox();
            this.pbSalir = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pnlFooter = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.cmMenuStrip.SuspendLayout();
            this.pnTitulo.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbFoto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.BackgroundColor = System.Drawing.Color.Silver;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.ContextMenuStrip = this.cmMenuStrip;
            this.dgvGridView.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.dgvGridView.Location = new System.Drawing.Point(12, 115);
            this.dgvGridView.MultiSelect = false;
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvGridView.Size = new System.Drawing.Size(627, 228);
            this.dgvGridView.TabIndex = 0;
            this.dgvGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellClick);
            this.dgvGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellDoubleClick);
            this.dgvGridView.CellParsing += new System.Windows.Forms.DataGridViewCellParsingEventHandler(this.dgvGridView_CellParsing);
            this.dgvGridView.SelectionChanged += new System.EventHandler(this.dgvGridView_SelectionChanged);
            this.dgvGridView.Sorted += new System.EventHandler(this.dgvGridView_Sorted_1);
            this.dgvGridView.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dgvGridView_KeyPress);
            this.dgvGridView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvGridView_KeyUp);
            // 
            // cmMenuStrip
            // 
            this.cmMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.detalleCalNivEstTSMI,
            this.rebajaDiferenciadaToolStripMenuItem});
            this.cmMenuStrip.Name = "cmMenuStrip";
            this.cmMenuStrip.Size = new System.Drawing.Size(272, 48);
            // 
            // detalleCalNivEstTSMI
            // 
            this.detalleCalNivEstTSMI.Name = "detalleCalNivEstTSMI";
            this.detalleCalNivEstTSMI.Size = new System.Drawing.Size(271, 22);
            this.detalleCalNivEstTSMI.Text = "Detalle de Calificaciones (Nivel Estilo)";
            this.detalleCalNivEstTSMI.Click += new System.EventHandler(this.detalleCalNivEstTSMI_Click);
            // 
            // rebajaDiferenciadaToolStripMenuItem
            // 
            this.rebajaDiferenciadaToolStripMenuItem.Name = "rebajaDiferenciadaToolStripMenuItem";
            this.rebajaDiferenciadaToolStripMenuItem.Size = new System.Drawing.Size(271, 22);
            this.rebajaDiferenciadaToolStripMenuItem.Text = "Rebaja Diferenciada";
            this.rebajaDiferenciadaToolStripMenuItem.Visible = false;
            this.rebajaDiferenciadaToolStripMenuItem.Click += new System.EventHandler(this.rebajaDiferenciadaToolStripMenuItem_Click);
            // 
            // pnTitulo
            // 
            this.pnTitulo.BackColor = System.Drawing.Color.DarkGray;
            this.pnTitulo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnTitulo.Controls.Add(this.btCalOri);
            this.pnTitulo.Controls.Add(this.lbMargen);
            this.pnTitulo.Controls.Add(this.lbPrecio);
            this.pnTitulo.Controls.Add(this.btQuitaChks);
            this.pnTitulo.Controls.Add(this.lbCosto);
            this.pnTitulo.Controls.Add(this.btMarcaChk);
            this.pnTitulo.Controls.Add(this.lblbMargen);
            this.pnTitulo.Controls.Add(this.lblbPrecio);
            this.pnTitulo.Controls.Add(this.lblbCosto);
            this.pnTitulo.Controls.Add(this.lbIdEstilo);
            this.pnTitulo.Controls.Add(this.lbIdProveedor);
            this.pnTitulo.Controls.Add(this.lbDesEstilo);
            this.pnTitulo.Controls.Add(this.lbDesProveedor);
            this.pnTitulo.Controls.Add(this.lbEstilo);
            this.pnTitulo.Controls.Add(this.lbProveedor);
            this.pnTitulo.Controls.Add(this.panel1);
            this.pnTitulo.Location = new System.Drawing.Point(11, 33);
            this.pnTitulo.Name = "pnTitulo";
            this.pnTitulo.Size = new System.Drawing.Size(527, 82);
            this.pnTitulo.TabIndex = 9;
            // 
            // btCalOri
            // 
            this.btCalOri.Location = new System.Drawing.Point(430, 3);
            this.btCalOri.Name = "btCalOri";
            this.btCalOri.Size = new System.Drawing.Size(90, 48);
            this.btCalOri.TabIndex = 0;
            this.btCalOri.Text = "Cal. Original";
            this.btCalOri.UseVisualStyleBackColor = true;
            // 
            // lbMargen
            // 
            this.lbMargen.AutoSize = true;
            this.lbMargen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbMargen.ForeColor = System.Drawing.Color.Black;
            this.lbMargen.Location = new System.Drawing.Point(422, 60);
            this.lbMargen.Name = "lbMargen";
            this.lbMargen.Size = new System.Drawing.Size(43, 13);
            this.lbMargen.TabIndex = 25;
            this.lbMargen.Text = "Margen";
            // 
            // lbPrecio
            // 
            this.lbPrecio.AutoSize = true;
            this.lbPrecio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbPrecio.ForeColor = System.Drawing.Color.Black;
            this.lbPrecio.Location = new System.Drawing.Point(329, 60);
            this.lbPrecio.Name = "lbPrecio";
            this.lbPrecio.Size = new System.Drawing.Size(37, 13);
            this.lbPrecio.TabIndex = 24;
            this.lbPrecio.Text = "Precio";
            // 
            // btQuitaChks
            // 
            this.btQuitaChks.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btQuitaChks.BackColor = System.Drawing.Color.Silver;
            this.btQuitaChks.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btQuitaChks.Image = global::MmsWin.Front.Properties.Resources.Unchecked_Checkbox_24px;
            this.btQuitaChks.Location = new System.Drawing.Point(292, 10);
            this.btQuitaChks.Name = "btQuitaChks";
            this.btQuitaChks.Size = new System.Drawing.Size(82, 35);
            this.btQuitaChks.TabIndex = 4;
            this.btQuitaChks.Text = "Quitar Checks";
            this.btQuitaChks.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btQuitaChks.UseVisualStyleBackColor = false;
            this.btQuitaChks.Visible = false;
            this.btQuitaChks.Click += new System.EventHandler(this.btQuitaChks_Click);
            // 
            // lbCosto
            // 
            this.lbCosto.AutoSize = true;
            this.lbCosto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbCosto.ForeColor = System.Drawing.Color.Black;
            this.lbCosto.Location = new System.Drawing.Point(236, 60);
            this.lbCosto.Name = "lbCosto";
            this.lbCosto.Size = new System.Drawing.Size(34, 13);
            this.lbCosto.TabIndex = 20;
            this.lbCosto.Text = "Costo";
            // 
            // btMarcaChk
            // 
            this.btMarcaChk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btMarcaChk.BackColor = System.Drawing.Color.Silver;
            this.btMarcaChk.ForeColor = System.Drawing.Color.Green;
            this.btMarcaChk.Image = global::MmsWin.Front.Properties.Resources.CheckedNo_Checkbox_24px;
            this.btMarcaChk.Location = new System.Drawing.Point(218, 10);
            this.btMarcaChk.Name = "btMarcaChk";
            this.btMarcaChk.Size = new System.Drawing.Size(75, 35);
            this.btMarcaChk.TabIndex = 3;
            this.btMarcaChk.Text = "Poner Checks";
            this.btMarcaChk.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btMarcaChk.UseVisualStyleBackColor = false;
            this.btMarcaChk.Visible = false;
            this.btMarcaChk.Click += new System.EventHandler(this.btMarcaChk_Click);
            // 
            // lblbMargen
            // 
            this.lblbMargen.AutoSize = true;
            this.lblbMargen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblbMargen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbMargen.ForeColor = System.Drawing.Color.Black;
            this.lblbMargen.Location = new System.Drawing.Point(373, 60);
            this.lblbMargen.Name = "lblbMargen";
            this.lblbMargen.Size = new System.Drawing.Size(49, 13);
            this.lblbMargen.TabIndex = 23;
            this.lblbMargen.Text = "Margen";
            // 
            // lblbPrecio
            // 
            this.lblbPrecio.AutoSize = true;
            this.lblbPrecio.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblbPrecio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbPrecio.ForeColor = System.Drawing.Color.Black;
            this.lblbPrecio.Location = new System.Drawing.Point(286, 60);
            this.lblbPrecio.Name = "lblbPrecio";
            this.lblbPrecio.Size = new System.Drawing.Size(43, 13);
            this.lblbPrecio.TabIndex = 22;
            this.lblbPrecio.Text = "Precio";
            // 
            // lblbCosto
            // 
            this.lblbCosto.AutoSize = true;
            this.lblbCosto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lblbCosto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblbCosto.ForeColor = System.Drawing.Color.Black;
            this.lblbCosto.Location = new System.Drawing.Point(196, 60);
            this.lblbCosto.Name = "lblbCosto";
            this.lblbCosto.Size = new System.Drawing.Size(39, 13);
            this.lblbCosto.TabIndex = 21;
            this.lblbCosto.Text = "Costo";
            // 
            // lbIdEstilo
            // 
            this.lbIdEstilo.AutoSize = true;
            this.lbIdEstilo.BackColor = System.Drawing.Color.DarkGray;
            this.lbIdEstilo.ForeColor = System.Drawing.Color.White;
            this.lbIdEstilo.Location = new System.Drawing.Point(93, 31);
            this.lbIdEstilo.Name = "lbIdEstilo";
            this.lbIdEstilo.Size = new System.Drawing.Size(16, 13);
            this.lbIdEstilo.TabIndex = 14;
            this.lbIdEstilo.Text = "Id";
            // 
            // lbIdProveedor
            // 
            this.lbIdProveedor.AutoSize = true;
            this.lbIdProveedor.BackColor = System.Drawing.Color.DarkGray;
            this.lbIdProveedor.ForeColor = System.Drawing.Color.White;
            this.lbIdProveedor.Location = new System.Drawing.Point(93, 8);
            this.lbIdProveedor.Name = "lbIdProveedor";
            this.lbIdProveedor.Size = new System.Drawing.Size(16, 13);
            this.lbIdProveedor.TabIndex = 13;
            this.lbIdProveedor.Text = "Id";
            // 
            // lbDesEstilo
            // 
            this.lbDesEstilo.AutoSize = true;
            this.lbDesEstilo.BackColor = System.Drawing.Color.DarkGray;
            this.lbDesEstilo.ForeColor = System.Drawing.Color.White;
            this.lbDesEstilo.Location = new System.Drawing.Point(177, 31);
            this.lbDesEstilo.Name = "lbDesEstilo";
            this.lbDesEstilo.Size = new System.Drawing.Size(26, 13);
            this.lbDesEstilo.TabIndex = 12;
            this.lbDesEstilo.Text = "Des";
            // 
            // lbDesProveedor
            // 
            this.lbDesProveedor.AutoSize = true;
            this.lbDesProveedor.BackColor = System.Drawing.Color.DarkGray;
            this.lbDesProveedor.ForeColor = System.Drawing.Color.White;
            this.lbDesProveedor.Location = new System.Drawing.Point(177, 8);
            this.lbDesProveedor.Name = "lbDesProveedor";
            this.lbDesProveedor.Size = new System.Drawing.Size(26, 13);
            this.lbDesProveedor.TabIndex = 11;
            this.lbDesProveedor.Text = "Des";
            // 
            // lbEstilo
            // 
            this.lbEstilo.AutoSize = true;
            this.lbEstilo.BackColor = System.Drawing.Color.DarkGray;
            this.lbEstilo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEstilo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbEstilo.Location = new System.Drawing.Point(21, 31);
            this.lbEstilo.Name = "lbEstilo";
            this.lbEstilo.Size = new System.Drawing.Size(38, 13);
            this.lbEstilo.TabIndex = 10;
            this.lbEstilo.Text = "Estilo";
            // 
            // lbProveedor
            // 
            this.lbProveedor.AutoSize = true;
            this.lbProveedor.BackColor = System.Drawing.Color.DarkGray;
            this.lbProveedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbProveedor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbProveedor.Location = new System.Drawing.Point(21, 8);
            this.lbProveedor.Name = "lbProveedor";
            this.lbProveedor.Size = new System.Drawing.Size(65, 13);
            this.lbProveedor.TabIndex = 9;
            this.lbProveedor.Text = "Proveedor";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel1.Controls.Add(this.btAplicar);
            this.panel1.Location = new System.Drawing.Point(0, 54);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(522, 29);
            this.panel1.TabIndex = 26;
            // 
            // btAplicar
            // 
            this.btAplicar.BackColor = System.Drawing.Color.White;
            this.btAplicar.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAplicar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btAplicar.Location = new System.Drawing.Point(3, 1);
            this.btAplicar.Name = "btAplicar";
            this.btAplicar.Size = new System.Drawing.Size(103, 24);
            this.btAplicar.TabIndex = 1;
            this.btAplicar.Text = "A p l i c a r";
            this.btAplicar.UseVisualStyleBackColor = false;
            this.btAplicar.Click += new System.EventHandler(this.btAplicar_Click);
            // 
            // lbTitulo
            // 
            this.lbTitulo.AutoSize = true;
            this.lbTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbTitulo.Location = new System.Drawing.Point(13, 8);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(197, 16);
            this.lbTitulo.TabIndex = 28;
            this.lbTitulo.Text = "Resumen de  estilo / tienda";
            // 
            // pbFoto
            // 
            this.pbFoto.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pbFoto.Location = new System.Drawing.Point(539, 32);
            this.pbFoto.Name = "pbFoto";
            this.pbFoto.Size = new System.Drawing.Size(100, 82);
            this.pbFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbFoto.TabIndex = 27;
            this.pbFoto.TabStop = false;
            this.pbFoto.Click += new System.EventHandler(this.pbFoto_Click);
            // 
            // pbSalir
            // 
            this.pbSalir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbSalir.BackColor = System.Drawing.Color.Gray;
            this.pbSalir.Image = ((System.Drawing.Image)(resources.GetObject("pbSalir.Image")));
            this.pbSalir.Location = new System.Drawing.Point(617, 6);
            this.pbSalir.Name = "pbSalir";
            this.pbSalir.Size = new System.Drawing.Size(24, 21);
            this.pbSalir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSalir.TabIndex = 10;
            this.pbSalir.TabStop = false;
            this.pbSalir.Click += new System.EventHandler(this.pbSalir_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(435, 354);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 34;
            this.label1.Text = "Margen";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(342, 354);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 13);
            this.label2.TabIndex = 33;
            this.label2.Text = "Precio";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(249, 354);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 29;
            this.label3.Text = "Costo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(386, 354);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 32;
            this.label4.Text = "Margen";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(299, 354);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(43, 13);
            this.label5.TabIndex = 31;
            this.label5.Text = "Precio";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(209, 354);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 13);
            this.label6.TabIndex = 30;
            this.label6.Text = "Costo";
            // 
            // pnlFooter
            // 
            this.pnlFooter.BackColor = System.Drawing.Color.DarkGray;
            this.pnlFooter.Location = new System.Drawing.Point(11, 373);
            this.pnlFooter.Name = "pnlFooter";
            this.pnlFooter.Size = new System.Drawing.Size(629, 28);
            this.pnlFooter.TabIndex = 35;
            // 
            // ResumenCalTda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(649, 407);
            this.Controls.Add(this.pnlFooter);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbTitulo);
            this.Controls.Add(this.pbFoto);
            this.Controls.Add(this.pbSalir);
            this.Controls.Add(this.dgvGridView);
            this.Controls.Add(this.pnTitulo);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ResumenCalTda";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Resumen Estilo Tienda";
            this.Load += new System.EventHandler(this.ResumenCalTda_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ResumenCalTda_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ResumenCalTda_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ResumenCalTda_MouseUp);
            this.Resize += new System.EventHandler(this.ResumenCalTda_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.cmMenuStrip.ResumeLayout(false);
            this.pnTitulo.ResumeLayout(false);
            this.pnTitulo.PerformLayout();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbFoto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion
        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.ContextMenuStrip cmMenuStrip;
        private System.Windows.Forms.Button btQuitaChks;
        private System.Windows.Forms.Button btMarcaChk;
        private System.Windows.Forms.ToolStripMenuItem detalleCalNivEstTSMI;
        private System.Windows.Forms.Panel pnTitulo;
        private System.Windows.Forms.Label lbIdEstilo;
        private System.Windows.Forms.Label lbIdProveedor;
        private System.Windows.Forms.Label lbDesEstilo;
        private System.Windows.Forms.Label lbDesProveedor;
        private System.Windows.Forms.Label lbEstilo;
        private System.Windows.Forms.Label lbProveedor;
        private System.Windows.Forms.Label lbMargen;
        private System.Windows.Forms.Label lbPrecio;
        private System.Windows.Forms.Label lbCosto;
        private System.Windows.Forms.Label lblbMargen;
        private System.Windows.Forms.Label lblbPrecio;
        private System.Windows.Forms.Label lblbCosto;
        private System.Windows.Forms.PictureBox pbSalir;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pbFoto;
        private System.Windows.Forms.ToolStripMenuItem rebajaDiferenciadaToolStripMenuItem;
        private System.Windows.Forms.Label lbTitulo;
        private System.Windows.Forms.Button btCalOri;
        private System.Windows.Forms.Button btAplicar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel pnlFooter;
    }
}