﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class DetalleTemporadaABC : Form
    {
        #region Variables locales
        public static string marca        { get; set; }
        public static string temporada    { get; set; }
        public static string descripcion  { get; set; }
        public static string estatus      { get; set; }

        public static string userAlta    { get; set; }
        public static string fechaAlta   { get; set; }
        public static string horaAlta    { get; set; }
        public static string userCambio  { get; set; }
        public static string fechaCambio { get; set; }
        public static string horaCambio  { get; set; }
        #endregion

        Point mousedownpoint = Point.Empty;

        public DetalleTemporadaABC()
        {
            InitializeComponent();
        }

        private void DetalleTemporadaABC_Load(object sender, EventArgs e)
        {
            tbMarca.Text        = marca;
            tbTemporada.Text    = temporada;
            tbDescripcion.Text  = descripcion;
            tbSts.Text          = estatus;

            tbUserAlta.Text  = userAlta;
            tbFechaAlta.Text = fechaAlta;
            tbHoraAlta.Text  = horaAlta;

            tbUserCambio.Text  = userCambio;
            tbFechaCambio.Text = fechaCambio;
            tbHoraCambio.Text  = horaCambio;
        }

        private void DetalleTemporadaABC_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void DetalleTemporadaABC_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedownpoint.IsEmpty)
                return;
            Form f = sender as Form;
            f.Location = new Point(f.Location.X + (e.X - mousedownpoint.X), f.Location.Y + (e.Y - mousedownpoint.Y));
        }

        private void DetalleTemporadaABC_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btAlta_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            DateTime fecha   = Convert.ToDateTime(DateTime.Now.ToShortDateString());
            tbFechaAlta.Text = Convert.ToString(fecha.ToString("yyyy-MM-dd"));

            DateTime hora   = DateTime.Now;
            tbHoraAlta.Text = (hora.ToString("HH:mm:ss", CultureInfo.InvariantCulture));

            tbUserAlta.Text = MmsWin.Front.Utilerias.VarTem.tmpUser;

            string marca        = tbMarca.Text;
            string temporada    = tbTemporada.Text;
            string descripcion  = tbDescripcion.Text;
            string estatus      = tbSts.Text;

            string fechaAlta    = tbFechaAlta.Text;
            string horaAlta     = tbHoraAlta.Text;
            string userAlta     = tbUserAlta.Text;

            string fechaCambio  = string.Empty;
            string horaCambio   = string.Empty;
            string userCambio   = string.Empty;

            string stMensaje    = string.Empty;

            stMensaje = validacion(marca, temporada, descripcion, estatus);

            if (stMensaje == "Correcto")
            {
                string fchfmtAlta = string.Empty;
                string horfmtAlta = string.Empty;

                string fchfmtCambio = string.Empty;
                string horfmtCambio = string.Empty;

                try
                {
                    fchfmtAlta = fechaAlta.Substring(2, 2) + fechaAlta.Substring(5, 2) + fechaAlta.Substring(8, 2);
                    horfmtAlta = horaAlta.Substring(0, 2) + horaAlta.Substring(3, 2) + horaAlta.Substring(6, 2);
                }
                catch { };

                try
                {
                    fchfmtCambio = fechaCambio.Substring(2, 2) + fechaCambio.Substring(5, 2) + fechaCambio.Substring(8, 2);
                    horfmtCambio = horaCambio.Substring(0, 2) + horaCambio.Substring(3, 2) + horaCambio.Substring(6, 2);
                }
                catch { };
                stMensaje = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().InsertDetalleGrupoTemporadaPropia(marca, temporada, descripcion, estatus, userAlta, fchfmtAlta, horfmtAlta, userCambio, fchfmtCambio, horfmtCambio);
                MessageBox.Show(stMensaje);
                if (stMensaje == "Se guardo el registro exitosamente...")
                {
                    this.Close();
                }
            }

        }

        private void btCambio_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            DateTime fecha     = Convert.ToDateTime(DateTime.Now.ToShortDateString());
            tbFechaCambio.Text = Convert.ToString(fecha.ToString("yyyy-MM-dd"));

            DateTime hora     = DateTime.Now;
            tbHoraCambio.Text = (hora.ToString("HH:mm:ss", CultureInfo.InvariantCulture));

            tbUserCambio.Text = MmsWin.Front.Utilerias.VarTem.tmpUser;

            string marca        = tbMarca.Text;
            string temporada    = tbTemporada.Text;
            string descripcion  = tbDescripcion.Text;
            string estatus      = tbSts.Text;

            string fechaAlta = tbFechaAlta.Text;
            string horaAlta  = tbHoraAlta.Text;
            string userAlta  = tbUserAlta.Text;

            string fechaCambio = tbFechaCambio.Text;
            string horaCambio  = tbHoraCambio.Text;
            string userCambio  = tbUserCambio.Text;

            string stMensaje = string.Empty;

            stMensaje = validacion(marca, temporada, descripcion, estatus);

            if (stMensaje == "Correcto")
            {
                string fchfmtAlta = string.Empty;
                string horfmtAlta = string.Empty;

                string fchfmtCambio = string.Empty;
                string horfmtCambio = string.Empty;

                try
                {
                    fchfmtAlta = fechaAlta.Substring(2, 2) + fechaAlta.Substring(5, 2) + fechaAlta.Substring(8, 2);
                    horfmtAlta = horaAlta.Substring(0, 2) + horaAlta.Substring(3, 2) + horaAlta.Substring(6, 2);
                }
                catch { };

                try
                {
                    fchfmtCambio = fechaCambio.Substring(2, 2) + fechaCambio.Substring(5, 2) + fechaCambio.Substring(8, 2);
                    horfmtCambio = horaCambio.Substring(0, 2) + horaCambio.Substring(3, 2) + horaCambio.Substring(6, 2);
                }
                catch { };
                stMensaje = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateDetalleGrupoTemporadaPropia(marca, temporada, descripcion, estatus, userAlta, fchfmtAlta, horfmtAlta, userCambio, fchfmtCambio, horfmtCambio);
                MessageBox.Show(stMensaje);
                if (stMensaje == "Se actualizó el registro exitosamente...")
                {
                    this.Close();
                }
            }
        }

        private void btElimiar_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            string message = "Esta seguro de eliminar este registro?";
            string caption = "Confirmación";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                eliminaRegistro();
            }
            else
            {
                MessageBox.Show("Proceso cancelado por el usuario");
            }
            this.Cursor = Cursors.Default;
        }

        private void eliminaRegistro()
        {
            string stMensaje = string.Empty;
            stMensaje = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().DeleteDetalleGrupoTemporadaPropia(marca, temporada, descripcion);
            if (stMensaje == "Se Elimino el registro exitosamente...")
            {
                MessageBox.Show(stMensaje);
                this.Close();
            }
        }

        private string validacion(string marca, string temporada, string descripcion, string estatus)
        {
            string mensaje = string.Empty;
            int    tempNum  = 0;

            mensaje = "Correcto";

            lbMsjMarca.Visible       = false;
            lbMsjTemporada.Visible   = false;
            lbMsjDescripcion.Visible = false;
            lbMsjSts.Visible         = false;

            // Valida Marca
            if (marca == "10" || marca == "30" || marca == "60")
            { }
            else
            {
                tbMarca.Focus();
                lbMsjMarca.Visible = true;
                mensaje = "Error";
            }
            // Valida Tabla
            try
            {
                tempNum = Convert.ToInt16(temporada);
            }
            catch
            {
                tbTemporada.Focus(); lbMsjTemporada.Visible = true; mensaje = "Error";
            }

            if (tempNum <= 0 || tempNum >= 1000)           
            {
                tbTemporada.Focus(); lbMsjTemporada.Visible = true; mensaje = "Error";
            }

            // valida ESTATUS
            if (estatus == "A" || estatus == "D")
            { }
            else
            {
                tbSts.Focus(); lbMsjSts.Visible = true; mensaje = "Error";
            }

            this.Cursor = Cursors.Default;
            return mensaje;
        }
    }
}
