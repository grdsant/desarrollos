﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using MmsWin.Front.Utilerias;
using System.Reflection;
using MmsWin.Front.Convenio;
using System.Diagnostics;
using MmsWin.Front.Bonificaciones;
using System.Threading;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class RebajaDiferenciada : Form
    {
        public static int Row;
        public static int Col;

        int nr;
        string ParUser;
        String marca;
        bool Carga;
        String comprador;
        string listaComprador;
        string FechaCal;
        string FechaFmt;
        public static string ParFechaBon;
        bool recalculo;

        String FchDe;
        String FchHas;
        long FchDeN;
        long FchHasN;

        long fechaHis;
        int dgvOffset;
        int pgbOffset;
        int dgvOffset2;

        string ParProveedor;
        string PartbNombre;
        string PartbEstilo;
        string ParDescripcion;
        string transito;
        string onHand;

        public RebajaDiferenciada()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
            pgbOffset = this.Width - pgbProg.Width;
        }

        private void RebajaDiferenciada_Load(object sender, EventArgs e)
        {
            ToolTip tooltip = new ToolTip();
            tooltip.SetToolTip(this.tbProveedor, "Proveedor");
            tooltip.SetToolTip(this.tbEstilo, "Estilo");
            tooltip.SetToolTip(this.tbNombre, "Nombre");
            tooltip.SetToolTip(this.tbDescripcion, "Descripción");

            ToolTip Tooltip1 = new ToolTip();
            Tooltip1.SetToolTip(this.pbBonAnticipada, "Bonificacion Acticipada");
            ToolTip Tooltip2 = new ToolTip();

            ToolTip Tooltip3 = new ToolTip();
            Tooltip1.SetToolTip(this.pbOmisionXTemp, "Omision de estilos por Temporada");
            ToolTip Tooltip4 = new ToolTip();
            ToolTip Tooltip5 = new ToolTip();
            Tooltip1.SetToolTip(this.btCheckBox, "Actualiza Check Box");

            Carga = false;
            marca = "999";
            comprador = "999";
            fechaHis = 0;

            FchDe = "10/10/2000";
            FchHas = "10/10/2000";
            tbDesde.Text = FchDe;
            tbHasta.Text = FchHas;

            // Carga de Marca
            try
            {
                BindMarca();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            // Carga de Compradores
            try
            {
                BindCompradores();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            try
            {
                System.Data.DataTable tbFechaInicial = null;
                tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();

                foreach (DataRow row in tbFechaInicial.Rows)
                {
                    tbDesde.Text = row["DSPFCH"].ToString();
                    FechaCal = tbDesde.Text;
                    FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                    tbDesde.Text = FechaFmt.ToString();
                    tbHasta.Text = FechaFmt.ToString();

                    FechaCal = tbDesde.Text;
                    FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                    FchDeN = long.Parse(FechaFmt.ToString());
                    FchDe = FechaFmt.ToString();

                    FechaCal = tbHasta.Text;
                    FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                    FchHasN = long.Parse(FechaFmt.ToString());
                    FchHas = FechaFmt.ToString();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            comprador = MmsWin.Front.Utilerias.VarTem.tmpUSRCOM;
            cbCompradores.SelectedValue = comprador;
            marca = MmsWin.Front.Utilerias.VarTem.tmpUSRMAR;
            cbMarca.SelectedValue = marca;


            // Fecha Abierta para Bonificacion
            string varFchBon = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenMarcaConfiguracion1(marca);
            varFchBon = varFchBon.Substring(4, 2) + "/" + varFchBon.Substring(2, 2) + "/" + "20" + varFchBon.Substring(0, 2);
            MmsWin.Front.Utilerias.VarTem.NotaFchBonifica = varFchBon;

            // Carga de Datos
            try
            {
                //BindBonifica();
                Carga = true;

                // Seguridad... x las Columnas nuevas
                ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                Seguridad("RebajaDiferenciada", "RebajaDiferenciada", ParUser);
            }
            catch { }
        }
        // Seguridad                                                                                
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                         
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvGridView.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvGridView.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenu.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenu.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        protected void BindBonifica()
        {
            if (Carga == true)
            {
                recalculo = false;
                nr = 0;
                this.Cursor = Cursors.WaitCursor;
                EliminacheckBox();
                dgvGridView.DataSource = null;
                System.Data.DataTable RebajaDiferenciada = null;
                try
                {
                    FechaCal = tbDesde.Text;
                    FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                    fechaHis = long.Parse(FechaFmt.ToString());

                    ParProveedor = tbProveedor.Text;
                    PartbNombre = tbNombre.Text;
                    PartbEstilo = tbEstilo.Text;
                    ParDescripcion = tbDescripcion.Text;

                    listaComprador = MmsWin.Front.Utilerias.VarTem.tmpDESC;
                    if (listaComprador != "")
                    {
                        comprador = listaComprador;
                    }

                    RebajaDiferenciada = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenRebajasDiferenciadas(marca, comprador, FchDe, FchHas, ParProveedor, PartbNombre, PartbEstilo, ParDescripcion);

                    listaComprador = MmsWin.Front.Utilerias.VarTem.tmpDESC;
                }
                catch 
                {    }

                if (RebajaDiferenciada != null)
                {
                    if (RebajaDiferenciada.Rows.Count > 0)
                    {
                        SetDoubleBuffered(dgvGridView);
                        dgvGridView.DataSource = RebajaDiferenciada;
                        nr = dgvGridView.RowCount;
                        this.Text = "RebajaDiferenciada / " + " " + (nr).ToString() + " Registro(s)";
                        CreaCheckBox();
                        SetFontAndColors();
                        rowStyle();

                        this.dgvGridView.Columns[21].DefaultCellStyle.ForeColor = Color.FromArgb(0, 192, 0);
                        this.dgvGridView.Columns[22].DefaultCellStyle.ForeColor = Color.FromArgb(0, 192, 0);

                        
                        // Seguridad... x las Columnas nuevas
                        ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        Seguridad("RebajaDiferenciada", "RebajaDiferenciada", ParUser);

                        CheckApli();
                        CheckBsts();

                        recalculo = true;
                    }
                  }

                this.Cursor = Cursors.Default;
            }
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        protected void BindMarca()
        {
            try
            {
                cbMarca.DataSource = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();
                cbMarca.DisplayMember = "Value";
                cbMarca.ValueMember = "Key";
                marca = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void BindCompradores()
        {
            try
            {
                cbCompradores.DataSource = MmsWin.Negocio.Catalogos.Compradores.GetInstance().ObtenCompradors().ToList();
                cbCompradores.DisplayMember = "Value";
                cbCompradores.ValueMember = "Key";
                comprador = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        } 

        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
     //       this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvGridView.Columns["RBDSTY"].Frozen = true;
            //this.dgvGridView.Columns[21].DefaultCellStyle.ForeColor = Color.Green;
            this.dgvGridView.Columns["RBDNOT"].DefaultCellStyle.ForeColor = Color.Green;

            dgvGridView.Columns["RBDFBO"].HeaderText = "Fecha Rebaja";
            dgvGridView.Columns["RBDTPO"].HeaderText = "Tipo";
            dgvGridView.Columns["RBDTMP"].HeaderText = "Temporada";
            dgvGridView.Columns["RBDSTR"].HeaderText = "Id.Tienda";
            dgvGridView.Columns["RBDNAM"].HeaderText = "Nombre Tienda";
            dgvGridView.Columns["RBDPRV"].HeaderText = "Proveedor";
            dgvGridView.Columns["RBDPRN"].HeaderText = "Nombre";
            dgvGridView.Columns["RBDSTY"].HeaderText = "Estilo";
            dgvGridView.Columns["RBDDES"].HeaderText = "Descripción";
            dgvGridView.Columns["RBDDCP"].HeaderText = "Comprador";
            dgvGridView.Columns["RBDFCM"].HeaderText = "Fecha Compra";
            dgvGridView.Columns["RBDFRE"].HeaderText = "Fecha Revisión";
            dgvGridView.Columns["RBDPZA"].HeaderText = "Piezas Recibidas";
            dgvGridView.Columns["RBDVTA"].HeaderText = "Venta";
            dgvGridView.Columns["RBDONH"].HeaderText = "OnHand";
            dgvGridView.Columns["RBDPVT"].HeaderText = "% Ventas";
            dgvGridView.Columns["RBDCAL"].HeaderText = "Calificación";
            dgvGridView.Columns["RBDTAB"].HeaderText = "Tabla Accion";
            dgvGridView.Columns["RBDNOT"].HeaderText = "Referencia";
            dgvGridView.Columns["RBDSUB"].HeaderText = "Sub_Tot";
            dgvGridView.Columns["RBDIVA"].HeaderText = "Iva";
            dgvGridView.Columns["RBDTOT"].HeaderText = "Total";
            dgvGridView.Columns["RBDPBO"].HeaderText = "% Rebaja";
            dgvGridView.Columns["RBDCST"].HeaderText = "Costo Actual";
            dgvGridView.Columns["RBDPRC"].HeaderText = "Precio Actual";
            dgvGridView.Columns["RBDMRG"].HeaderText = "Margen Actual";
            dgvGridView.Columns["RBDCST1"].HeaderText = "Costo Nuevo";
            dgvGridView.Columns["RBDPRC1"].HeaderText = "Precio Nuevo";
            dgvGridView.Columns["RBDMRG1"].HeaderText = "Margen Nuevo";
            dgvGridView.Columns["RBDCST2"].HeaderText = "Costo Final";
            dgvGridView.Columns["RBDPRC2"].HeaderText = "Precio Final";
            dgvGridView.Columns["RBDMRG2"].HeaderText = "Margen Final";
            dgvGridView.Columns["RBDCMP"].HeaderText = "Observaciones";
            dgvGridView.Columns["RBDTAB2"].HeaderText = "Tbl Accion2";
            dgvGridView.Columns["RBDCSTD"].HeaderText = "Diferecia Consto";
            dgvGridView.Columns["RBDPZA1"].HeaderText = "OnHand Actual";
            dgvGridView.Columns["RBDIMP1"].HeaderText = "Imp.OnHand X.dif.Costo";
            dgvGridView.Columns["RBDPRO"].HeaderText = "Promoción";

            dgvGridView.Columns["RBDDCF2"].HeaderText = "Diferecia Consto Final";
            dgvGridView.Columns["RBDIDC2"].HeaderText = "Imp OH Dif Cst Final";
            dgvGridView.Columns["RBDIMF2"].HeaderText = "Importe Margen Final";

            dgvGridView.Columns["RBDTABF"].HeaderText = "Tab Acc Final";
            dgvGridView.Columns["RBDMAR"].HeaderText = "Marca";
            dgvGridView.Columns["RBDCID"].HeaderText = "Id Comprador";
            dgvGridView.Columns["RBDBDG"].HeaderText = "Bodega";
            dgvGridView.Columns["RBDCK1"].HeaderText = "Compras";
            dgvGridView.Columns["RBDCK2"].HeaderText = "Control";
            dgvGridView.Columns["RBDNMR"].HeaderText = "Marca Id";
            dgvGridView.Columns["RBDFCHA"].HeaderText = "Fecha";
            dgvGridView.Columns["RBDHORA"].HeaderText = "Hora";
            dgvGridView.Columns["RBDUSR"].HeaderText = "Usuario";
            dgvGridView.Columns["RBDERR"].HeaderText = "Error";

            dgvGridView.Columns["RBDCLF"].HeaderText = "Correo";
            dgvGridView.Columns["RBDCXO"].HeaderText = "Califica x Omisión";
            dgvGridView.Columns["RBDIDE"].HeaderText = "Identif Estilos";
            dgvGridView.Columns["RBDRCS"].HeaderText = "Costo Nuevo";
            dgvGridView.Columns["RBDRPR"].HeaderText = "Precio Nuevo";
            dgvGridView.Columns["RBDDEV"].HeaderText = "Devolición";
            dgvGridView.Columns["RBDCFA"].HeaderText = "Factura";
            dgvGridView.Columns["RBDPOL"].HeaderText = "Póliza";

            dgvGridView.Columns["RBDCK3"].HeaderText = "Correo";
            dgvGridView.Columns["RBDCK4"].HeaderText = "Calificacion x Omisión";
            dgvGridView.Columns["RBDCK5"].HeaderText = "Identif Aplicado";
            dgvGridView.Columns["RBDCK6"].HeaderText = "Costo Aplicado";
            dgvGridView.Columns["RBDCK7"].HeaderText = "Precio Aplicado";
            dgvGridView.Columns["RBDCK8"].HeaderText = "Dev Aplicada";
            dgvGridView.Columns["RBDCK9"].HeaderText = "Factura";
            dgvGridView.Columns["RBDCK10"].HeaderText = "Póliza";
            dgvGridView.Columns["RBDNCS"].HeaderText = "Sts PDF";

            dgvGridView.Columns[0].Width = 80;
            dgvGridView.Columns[1].Width = 80;
            dgvGridView.Columns[2].Width = 40;
            dgvGridView.Columns[3].Width = 40;
            dgvGridView.Columns[4].Width = 130;
            dgvGridView.Columns[5].Width = 45;
            dgvGridView.Columns[6].Width = 200;
            dgvGridView.Columns[7].Width = 65;
            dgvGridView.Columns[8].Width = 200;
            dgvGridView.Columns[9].Width = 130;
            dgvGridView.Columns[10].Width = 80;
            dgvGridView.Columns[11].Width = 80;
            dgvGridView.Columns[12].Width = 60;
            dgvGridView.Columns[13].Width = 60;
            dgvGridView.Columns[14].Width = 60;
            dgvGridView.Columns[15].Width = 60;
            dgvGridView.Columns[16].Width = 80;
            dgvGridView.Columns[17].Width = 60;
            dgvGridView.Columns[18].Width = 80;
            dgvGridView.Columns[19].Width = 85;
            dgvGridView.Columns[20].Width = 85;
            dgvGridView.Columns[21].Width = 85;
            dgvGridView.Columns[22].Width = 55;
            dgvGridView.Columns[23].Width = 65;
            dgvGridView.Columns[24].Width = 65;
            dgvGridView.Columns[25].Width = 50;
            dgvGridView.Columns[26].Width = 65;
            dgvGridView.Columns[27].Width = 65;
            dgvGridView.Columns[28].Width = 50;
            dgvGridView.Columns[29].Width = 73;
            dgvGridView.Columns[30].Width = 70;
            dgvGridView.Columns[31].Width = 70;
            dgvGridView.Columns[32].Width = 200;
            dgvGridView.Columns[33].Width = 50;
            dgvGridView.Columns[34].Width = 60;
            dgvGridView.Columns[35].Width = 70;
            dgvGridView.Columns[36].Width = 80;
            dgvGridView.Columns[37].Width = 90;

            dgvGridView.Columns[38].Width = 80;
            dgvGridView.Columns[39].Width = 80;
            dgvGridView.Columns[40].Width = 80;

            dgvGridView.Columns[41].Width = 50;
            dgvGridView.Columns[42].Width = 60;
            dgvGridView.Columns[43].Width = 60;
            dgvGridView.Columns[44].Width = 60;
            dgvGridView.Columns[45].Width = 60;
            dgvGridView.Columns[46].Width = 60;
            dgvGridView.Columns[47].Width = 60;
            dgvGridView.Columns[48].Width = 60;
            dgvGridView.Columns[49].Width = 60;
            dgvGridView.Columns[50].Width = 60;
            dgvGridView.Columns[51].Width = 80;
            dgvGridView.Columns[52].Width = 60;
            dgvGridView.Columns[53].Width = 60;
            dgvGridView.Columns[54].Width = 60;
            dgvGridView.Columns[55].Width = 60;
            dgvGridView.Columns[56].Width = 60;
            dgvGridView.Columns[57].Width = 60;
            dgvGridView.Columns[58].Width = 60;
            dgvGridView.Columns[59].Width = 60;
            dgvGridView.Columns[60].Width = 60;
            dgvGridView.Columns[61].Width = 60;
            dgvGridView.Columns[62].Width = 60;
            dgvGridView.Columns[63].Width = 60;
            dgvGridView.Columns[64].Width = 60;
            dgvGridView.Columns[65].Width = 60;
            dgvGridView.Columns[66].Width = 60;
            dgvGridView.Columns[67].Width = 60;
            dgvGridView.Columns[68].Width = 60;

            dgvGridView.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[10].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[11].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[12].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[13].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[14].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[15].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[16].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[17].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[18].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[19].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[20].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[21].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[22].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[23].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[24].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[25].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[26].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[27].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[28].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[29].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[30].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[31].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[32].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns[33].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[34].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[35].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[36].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[37].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgvGridView.Columns[38].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[39].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns[40].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            dgvGridView.Columns[41].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[42].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[43].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[44].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[45].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[46].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[47].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[48].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[49].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[50].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[51].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[52].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[53].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[54].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[55].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[56].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[57].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[58].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[59].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[60].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[61].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[62].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[63].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[64].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[65].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[66].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[67].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns[68].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns[0].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns[10].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns[11].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns[12].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[13].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[14].DefaultCellStyle.Format = "###,###";
            dgvGridView.Columns[15].DefaultCellStyle.Format = "#0.00";
            dgvGridView.Columns[16].DefaultCellStyle.Format = "##.##";
            dgvGridView.Columns[17].DefaultCellStyle.Format = "##.##";
            dgvGridView.Columns[19].DefaultCellStyle.Format = "###,###.00";
            dgvGridView.Columns[20].DefaultCellStyle.Format = "###,###.00";
            dgvGridView.Columns[21].DefaultCellStyle.Format = "###,###.00";
            dgvGridView.Columns[22].DefaultCellStyle.Format = ".00%";
            dgvGridView.Columns[23].DefaultCellStyle.Format = "00.0000";
            dgvGridView.Columns[24].DefaultCellStyle.Format = "00.000";
            dgvGridView.Columns[25].DefaultCellStyle.Format = "#0.000";
            dgvGridView.Columns[26].DefaultCellStyle.Format = "00.0000";
            dgvGridView.Columns[27].DefaultCellStyle.Format = "00.000";
            dgvGridView.Columns[28].DefaultCellStyle.Format = "#0.000";
            dgvGridView.Columns[29].DefaultCellStyle.Format = "00.0000";
            dgvGridView.Columns[30].DefaultCellStyle.Format = "00.000";
            dgvGridView.Columns[31].DefaultCellStyle.Format = "#0.000";
            dgvGridView.Columns[32].DefaultCellStyle.Format = "#,###.##";
            dgvGridView.Columns[33].DefaultCellStyle.Format = "#,###.##";
            dgvGridView.Columns[34].DefaultCellStyle.Format = "#0.0000";
            dgvGridView.Columns[35].DefaultCellStyle.Format = "#,###,###";
            dgvGridView.Columns[36].DefaultCellStyle.Format = "#,###,###.0000";
            dgvGridView.Columns[37].DefaultCellStyle.Format = "#,###,###.00";

            dgvGridView.Columns[38].DefaultCellStyle.Format = "###,##0.0000";
            dgvGridView.Columns[39].DefaultCellStyle.Format = "#,###,###.0000";
            dgvGridView.Columns[40].DefaultCellStyle.Format = "#,###,###.0000";

            dgvGridView.Columns[41].DefaultCellStyle.Format = "#,###";
            dgvGridView.Columns[42].DefaultCellStyle.Format = "#,###";
            dgvGridView.Columns[43].DefaultCellStyle.Format = "#,###";
            dgvGridView.Columns[44].DefaultCellStyle.Format = "#,###";

            dgvGridView.Columns[0].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[1].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[2].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[3].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[4].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[5].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[6].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[7].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[8].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[9].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[10].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[11].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[12].HeaderCell.Style.BackColor = Color.LightSteelBlue;
            dgvGridView.Columns[13].HeaderCell.Style.BackColor = Color.LightSteelBlue;
            dgvGridView.Columns[14].HeaderCell.Style.BackColor = Color.LightSteelBlue;
            dgvGridView.Columns[15].HeaderCell.Style.BackColor = Color.LightSteelBlue;
            dgvGridView.Columns[16].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[17].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[18].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[19].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[20].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[21].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[22].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[23].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
            dgvGridView.Columns[24].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
            dgvGridView.Columns[25].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
            dgvGridView.Columns[26].HeaderCell.Style.BackColor = Color.FromArgb(192, 0, 0);
            dgvGridView.Columns[27].HeaderCell.Style.BackColor = Color.FromArgb(192, 0, 0);
            dgvGridView.Columns[28].HeaderCell.Style.BackColor = Color.FromArgb(192, 0, 0);
            dgvGridView.Columns[29].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
            dgvGridView.Columns[30].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
            dgvGridView.Columns[31].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
            dgvGridView.Columns[32].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[33].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[34].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[35].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[36].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns[37].HeaderCell.Style.BackColor = Color.LightSkyBlue;

            dgvGridView.Columns[38].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[39].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns[40].HeaderCell.Style.BackColor = Color.LightSlateGray;

            dgvGridView.Columns[41].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[42].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[43].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[44].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[45].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[46].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[47].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[48].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[49].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[50].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[51].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns[52].HeaderCell.Style.BackColor = Color.Red;
            dgvGridView.Columns[53].HeaderCell.Style.BackColor = Color.Red;
            dgvGridView.Columns[54].HeaderCell.Style.BackColor = Color.Red;
            dgvGridView.Columns[55].HeaderCell.Style.BackColor = Color.Red;
            dgvGridView.Columns[56].HeaderCell.Style.BackColor = Color.Red;
            dgvGridView.Columns[57].HeaderCell.Style.BackColor = Color.Red;
            dgvGridView.Columns[58].HeaderCell.Style.BackColor = Color.Red;
            dgvGridView.Columns[59].HeaderCell.Style.BackColor = Color.Red;
            dgvGridView.Columns[60].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[61].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[62].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[63].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[64].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[65].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[66].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[67].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns[68].HeaderCell.Style.BackColor = Color.LightSalmon;

            dgvGridView.Columns[37].Visible = false;
            dgvGridView.Columns[68].Visible = false;

            dgvGridView.Columns["RBDCLF"].Visible = false;
            dgvGridView.Columns["RBDCXO"].Visible = false;
            dgvGridView.Columns["RBDIDE"].Visible = false;
            dgvGridView.Columns["RBDRCS"].Visible = false;
            dgvGridView.Columns["RBDRPR"].Visible = false;
            dgvGridView.Columns["RBDDEV"].Visible = false;
            dgvGridView.Columns["RBDCFA"].Visible = false;
            dgvGridView.Columns["RBDPOL"].Visible = false;

            dgvGridView.Columns["RBDCK3"].Visible  = false;
            dgvGridView.Columns["RBDCK4"].Visible  = false;
            dgvGridView.Columns["RBDCK5"].Visible  = false;
            dgvGridView.Columns["RBDCK6"].Visible  = false;
            dgvGridView.Columns["RBDCK7"].Visible  = false;
            dgvGridView.Columns["RBDCK8"].Visible  = false;
            dgvGridView.Columns["RBDCK9"].Visible  = false;
            dgvGridView.Columns["RBDCK10"].Visible = false;

            dgvGridView.Columns["RBDNMR"].Visible = false;
            dgvGridView.Columns["RBDMAR"].Visible = false;
            dgvGridView.Columns["RBDCID"].Visible = false;
            dgvGridView.Columns["RBDBDG"].Visible = false;
            dgvGridView.Columns["RBDCK1"].Visible = false;
            dgvGridView.Columns["RBDCK2"].Visible = false;

            dgvGridView.Columns["RBDCK2"].Visible = false;
            //dgvGridView.Columns["CONTRALORIA"].Visible = false;

            dgvGridView.Columns["RBDSUB"].Visible = false;
            dgvGridView.Columns["RBDIVA"].Visible = false;
            dgvGridView.Columns["RBDTOT"].Visible = false;

            // Si funciona
            //DataGridViewCellStyle style = new DataGridViewCellStyle();
            //style.Font = new System.Drawing.Font(dgvGridView.Font, FontStyle.Bold);
            //dgvGridView.Columns[14].DefaultCellStyle = style;
            //dgvGridView.Columns[14].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private void rowStyle()
        {
            //string vez = "si";
            //int Regs = 0;
            //foreach (DataGridViewRow rowp in dgvGridView.Rows)
            //{
            //    int kia = rowp.Index;
            //    Regs += 1;
            //    if (vez == "Si")
            //    {
            //        dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
            //        vez = "No";
            //    }
            //    else
            //    {
            //        vez = "Si";
            //    }

            //}

            foreach (DataGridViewRow row in dgvGridView.Rows)
            {
                // Pagar
                if (Convert.ToString(row.Cells["RBDCAL"].Value).Trim() == "P a g a r") { row.Cells["RBDCAL"].Style.BackColor = Color.LightGreen; }
                // 15%
                if (Convert.ToString(row.Cells["RBDCAL"].Value).Trim() == "15%") { row.Cells["RBDCAL"].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(row.Cells["RBDCAL"].Value).Trim() == "20%") { row.Cells["RBDCAL"].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(row.Cells["RBDCAL"].Value).Trim() == "25%") { row.Cells["RBDCAL"].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(row.Cells["RBDCAL"].Value).Trim() == "30%") { row.Cells["RBDCAL"].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(row.Cells["RBDCAL"].Value).Trim() == "35%") { row.Cells["RBDCAL"].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(row.Cells["RBDCAL"].Value).Trim() == "40%") { row.Cells["RBDCAL"].Style.BackColor = Color.LightSalmon; }
                // Dev ó 40%
                if (Convert.ToString(row.Cells["RBDCAL"].Value).Trim() == "40%") { row.Cells["RBDCAL"].Style.BackColor = Color.Red; row.Cells["RBDCAL"].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(row.Cells["RBDCAL"].Value).Trim() == "50%") { row.Cells["RBDCAL"].Style.BackColor = Color.Red; row.Cells["RBDCAL"].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(row.Cells["RBDCAL"].Value).Trim() == "50%") { row.Cells["RBDCAL"].Style.BackColor = Color.Red; row.Cells["RBDCAL"].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(row.Cells["RBDCAL"].Value).Trim() == "Devolución") { row.Cells["RBDCAL"].Style.BackColor = Color.Red; row.Cells["RBDCAL"].Style.ForeColor = Color.White; }

                if (Convert.ToString(row.Cells[68].Value) == "1") { row.Cells[18].Style.ForeColor = Color.Green; }
                if (Convert.ToString(row.Cells[68].Value) == "") { row.Cells[18].Style.ForeColor = Color.Red; }
                if (Convert.ToString(row.Cells[68].Value) == " ") { row.Cells[18].Style.ForeColor = Color.Red; }

                dgvGridView.Select();
                DataGridViewCheckBoxCell chk1 = (DataGridViewCheckBoxCell)row.Cells[69];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[52].Value) == "1") { chk1.Value = 1; }

                dgvGridView.Select();
                DataGridViewCheckBoxCell chk2 = (DataGridViewCheckBoxCell)row.Cells[70];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[53].Value) == "1") { chk2.Value = 1; }

                dgvGridView.Select();
                DataGridViewCheckBoxCell chk3 = (DataGridViewCheckBoxCell)row.Cells[71];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[54].Value) == "1") { chk3.Value = 1; }

                dgvGridView.Select();
                DataGridViewCheckBoxCell chk4 = (DataGridViewCheckBoxCell)row.Cells[72];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[55].Value) == "1") { chk4.Value = 1; }

                dgvGridView.Select();
                DataGridViewCheckBoxCell chk5 = (DataGridViewCheckBoxCell)row.Cells[73];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[56].Value) == "1") { chk5.Value = 1; }

                dgvGridView.Select();
                DataGridViewCheckBoxCell chk6 = (DataGridViewCheckBoxCell)row.Cells[74];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[57].Value) == "1") { chk6.Value = 1; }

                dgvGridView.Select();
                DataGridViewCheckBoxCell chk7 = (DataGridViewCheckBoxCell)row.Cells[75];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[58].Value) == "1") { chk7.Value = 1; }

                dgvGridView.Select();
                DataGridViewCheckBoxCell chk8 = (DataGridViewCheckBoxCell)row.Cells[76];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[59].Value) == "1") { chk8.Value = 1; }

                // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

                dgvGridView.Select();
                DataGridViewCheckBoxCell chk9 = (DataGridViewCheckBoxCell)row.Cells[77];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[60].Value) == "1") { chk9.Value = 1; }

                dgvGridView.Select();
                DataGridViewCheckBoxCell chk10 = (DataGridViewCheckBoxCell)row.Cells[78];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[61].Value) == "1") { chk10.Value = 1; }                
                
                dgvGridView.Select();
                DataGridViewCheckBoxCell chk11 = (DataGridViewCheckBoxCell)row.Cells[79];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[62].Value) == "1") { chk11.Value = 1; }
                
                dgvGridView.Select();
                DataGridViewCheckBoxCell chk12 = (DataGridViewCheckBoxCell)row.Cells[80];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[63].Value) == "1") { chk12.Value = 1; }
                
                dgvGridView.Select();
                DataGridViewCheckBoxCell chk13 = (DataGridViewCheckBoxCell)row.Cells[81];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[64].Value) == "1") { chk13.Value = 1; }
                
                dgvGridView.Select();
                DataGridViewCheckBoxCell chk14 = (DataGridViewCheckBoxCell)row.Cells[82];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[65].Value) == "1") { chk14.Value = 1; }
                
                dgvGridView.Select();
                DataGridViewCheckBoxCell chk15 = (DataGridViewCheckBoxCell)row.Cells[83];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[66].Value) == "1") { chk15.Value = 1; }   
                
                dgvGridView.Select();
                DataGridViewCheckBoxCell chk16 = (DataGridViewCheckBoxCell)row.Cells[84];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[67].Value) == "1") { chk16.Value = 1; }
                
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

                dgvGridView.Select();
                DataGridViewCheckBoxCell chk17 = (DataGridViewCheckBoxCell)row.Cells[85];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[45].Value) == "1") { chk17.Value = 1; }

                dgvGridView.Select();
                DataGridViewCheckBoxCell chk18 = (DataGridViewCheckBoxCell)row.Cells[86];
                dgvGridView.BeginEdit(true);
                if (Convert.ToString(row.Cells[46].Value) == "1") { chk18.Value = 1; }

                row.Cells[22].Style.ForeColor = Color.DarkRed;
                row.Cells[25].Style.ForeColor = Color.DarkBlue;
                row.Cells[27].Style.ForeColor = Color.DarkBlue;
                row.Cells[31].Style.ForeColor = Color.DarkBlue;

                dgvGridView.EndEdit();
            }

        }

        private void RebajaDiferenciada_Resize(object sender, EventArgs e)
        {
            dgvGridView.Width = this.Width - dgvOffset;
            dgvGridView.Height = this.Height - dgvOffset2;
            pgbProg.Width = this.Width - pgbOffset;
        }

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            marca = " ";
            ComboBox cmb = (ComboBox)sender;
            marca = cmb.SelectedValue.ToString();

            BindBonifica();
        }

        private void cbCompradores_SelectedIndexChanged(object sender, EventArgs e)
        {
            comprador = " ";
            ComboBox cmbComprador = (ComboBox)sender;
            comprador = cmbComprador.SelectedValue.ToString();

            BindBonifica();
        }

        private void fotoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MuestraFoto();
        }

        private void MuestraFoto()
        {
            try
            {
              Fotos i = new Fotos();
              i.Show();
            }
            catch { }
            finally { }
        }

        private void dgvGridView_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                var hti = dgvGridView.HitTest(e.X, e.Y);
                int Row = e.RowIndex;
                int Col = e.ColumnIndex;
               // MmsWin.Front.
                MmsWin.Front.Utilerias.Fotos.numPrv = this.dgvGridView.CurrentRow.Cells[5].Value.ToString();
                MmsWin.Front.Utilerias.Fotos.numSty = this.dgvGridView.CurrentRow.Cells[7].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.rbdFchBon    = this.dgvGridView.CurrentRow.Cells[0].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.rbdTipoCal   = this.dgvGridView.CurrentRow.Cells[1].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.rbdTemporada = this.dgvGridView.CurrentRow.Cells[2].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.rbdTienda    = this.dgvGridView.CurrentRow.Cells[3].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.rbdProveedor = this.dgvGridView.CurrentRow.Cells[5].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.rbdEstilo    = this.dgvGridView.CurrentRow.Cells[7].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.rbdFchRev    = this.dgvGridView.CurrentRow.Cells[11].Value.ToString();

                //if (this.dgvGridView.CurrentRow.Cells[18].Value.ToString() != "Mas de 1")
                //{
                    MmsWin.Front.Utilerias.VarTem.rbdNota = this.dgvGridView.CurrentRow.Cells[18].Value.ToString();
                //}

                cmMenu.Visible = true;

                string validaContraloria = this.dgvGridView.CurrentRow.Cells[46].Value.ToString();
                string bandera;
                if (validaContraloria == "0")
                {
                    bandera = "1";
                }
                else
                {
                    bandera = "0";
                }
                    string Controles = "eliminarTSM1";
                    string ValHab = bandera;
                    string ValVis = bandera;
                    string tipo = "Menu";
                    AplicaSeguridad(Controles, ValHab, ValVis, tipo);
                    Controles = "ActualizarTSMI";
                    ValHab = bandera;
                    ValVis = bandera;
                    tipo = "Menu";
                    AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }

        private void CreaCheckBox()
        {
            DataGridViewCheckBoxColumn CosrreoE = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(CosrreoE);
            dgvGridView.Columns[69].Name = "CORREOE";
            dgvGridView.Columns[69].HeaderText = "Correo Electronico";
            dgvGridView.Columns[69].Width = 55;
            dgvGridView.Columns[69].HeaderCell.Style.BackColor = Color.FromArgb(192, 0, 0);
            dgvGridView.Columns[69].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn CalxOmi = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(CalxOmi);
            dgvGridView.Columns[70].Name = "CALXOMI";
            dgvGridView.Columns[70].HeaderText = "Calificaion xOmision";
            dgvGridView.Columns[70].Width = 55;
            dgvGridView.Columns[70].HeaderCell.Style.BackColor = Color.FromArgb(192, 0, 0);
            dgvGridView.Columns[70].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn Identif = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(Identif);
            dgvGridView.Columns[71].Name = "IDENTIF";
            dgvGridView.Columns[71].HeaderText = "Identificador Estilos";
            dgvGridView.Columns[71].Width = 55;
            dgvGridView.Columns[71].HeaderCell.Style.BackColor = Color.FromArgb(192, 0, 0);
            dgvGridView.Columns[71].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn Costo = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(Costo);
            dgvGridView.Columns[72].Name = "COSTO";
            dgvGridView.Columns[72].HeaderText = "Costo";
            dgvGridView.Columns[72].Width = 55;
            dgvGridView.Columns[72].HeaderCell.Style.BackColor = Color.FromArgb(192, 0, 0);
            dgvGridView.Columns[72].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn Precio = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(Precio);
            dgvGridView.Columns[73].Name = "PRECIO";
            dgvGridView.Columns[73].HeaderText = "Precio";
            dgvGridView.Columns[73].Width = 55;
            dgvGridView.Columns[73].HeaderCell.Style.BackColor = Color.FromArgb(192, 0, 0);
            dgvGridView.Columns[73].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn Devol = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(Devol);
            dgvGridView.Columns[74].Name = "DEVOL";
            dgvGridView.Columns[74].HeaderText = "Devolucion";
            dgvGridView.Columns[74].Width = 55;
            dgvGridView.Columns[74].HeaderCell.Style.BackColor = Color.FromArgb(192, 0, 0);
            dgvGridView.Columns[74].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn FactEmit = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(FactEmit);
            dgvGridView.Columns[75].Name = "FACTEMIT";
            dgvGridView.Columns[75].HeaderText = "Factura Emitida";
            dgvGridView.Columns[75].Width = 55;
            dgvGridView.Columns[75].HeaderCell.Style.BackColor = Color.FromArgb(192, 0, 0);
            dgvGridView.Columns[75].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn Poliza = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(Poliza);
            dgvGridView.Columns[76].Name = "POLIZA";
            dgvGridView.Columns[76].HeaderText = "Poliza Contable";
            dgvGridView.Columns[76].Width = 55;
            dgvGridView.Columns[76].HeaderCell.Style.BackColor = Color.FromArgb(192, 0, 0);
            dgvGridView.Columns[76].HeaderCell.Style.ForeColor = Color.White;
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
            DataGridViewCheckBoxColumn stCosrreoE = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(stCosrreoE);
            dgvGridView.Columns[77].Name = "STSCOR";
            dgvGridView.Columns[77].HeaderText = "Estatus CorreoE";
            dgvGridView.Columns[77].Width = 55;
            dgvGridView.Columns[77].HeaderCell.Style.BackColor = Color.Green;
            dgvGridView.Columns[77].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn stCalxOmi = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(stCalxOmi);
            dgvGridView.Columns[78].Name = "STSCXO";
            dgvGridView.Columns[78].HeaderText = "Estatus CalxOmision";
            dgvGridView.Columns[78].Width = 55;
            dgvGridView.Columns[78].HeaderCell.Style.BackColor = Color.Green;
            dgvGridView.Columns[78].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn stIdentif = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(stIdentif);
            dgvGridView.Columns[79].Name = "STSIDE";
            dgvGridView.Columns[79].HeaderText = "Estatus IdentEstilos";
            dgvGridView.Columns[79].Width = 55;
            dgvGridView.Columns[79].HeaderCell.Style.BackColor = Color.Green;
            dgvGridView.Columns[79].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn stCosto = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(stCosto);
            dgvGridView.Columns[80].Name = "STSCST";
            dgvGridView.Columns[80].HeaderText = "Estatus Costo";
            dgvGridView.Columns[80].Width = 55;
            dgvGridView.Columns[80].HeaderCell.Style.BackColor = Color.Green;
            dgvGridView.Columns[80].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn stPrecio = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(stPrecio);
            dgvGridView.Columns[81].Name = "STSPRC";
            dgvGridView.Columns[81].HeaderText = "Estatus Precio";
            dgvGridView.Columns[81].Width = 55;
            dgvGridView.Columns[81].HeaderCell.Style.BackColor = Color.Green;
            dgvGridView.Columns[81].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn stDevol = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(stDevol);
            dgvGridView.Columns[82].Name = "STSDEV";
            dgvGridView.Columns[82].HeaderText = "Estatus Devolucion";
            dgvGridView.Columns[82].Width = 55;
            dgvGridView.Columns[82].HeaderCell.Style.BackColor = Color.Green;
            dgvGridView.Columns[82].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn stFactEmit = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(stFactEmit);
            dgvGridView.Columns[83].Name = "STSFEM";
            dgvGridView.Columns[83].HeaderText = "Estatus FactEmitida";
            dgvGridView.Columns[83].Width = 55;
            dgvGridView.Columns[83].HeaderCell.Style.BackColor = Color.Green;
            dgvGridView.Columns[83].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn stPoliza = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(stPoliza);
            dgvGridView.Columns[84].Name = "STSPOL";
            dgvGridView.Columns[84].HeaderText = "Estatus Poliza";
            dgvGridView.Columns[84].Width = 55;
            dgvGridView.Columns[84].HeaderCell.Style.BackColor = Color.Green;
            dgvGridView.Columns[84].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn Compras = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(Compras);
            dgvGridView.Columns[85].Name = "COMPRAS";
            dgvGridView.Columns[85].HeaderText = "Compras";
            dgvGridView.Columns[85].Width = 55;
            dgvGridView.Columns[85].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
            dgvGridView.Columns[85].HeaderCell.Style.ForeColor = Color.White;

            DataGridViewCheckBoxColumn Contraloria = new DataGridViewCheckBoxColumn();
            dgvGridView.Columns.Add(Contraloria);
            dgvGridView.Columns[86].Name = "CONTRALORIA";
            dgvGridView.Columns[86].HeaderText = "Control";
            dgvGridView.Columns[86].Width = 55;
            dgvGridView.Columns[86].HeaderCell.Style.BackColor = Color.FromArgb(0, 0, 192);
            dgvGridView.Columns[86].HeaderCell.Style.ForeColor = Color.White;
        }

        private void documentoPDFToolStripMenuItem_Click(object sender, EventArgs e)
        {
         //   MuestraPDF();
            try
            {
                string ParFchBon    = MmsWin.Front.Utilerias.VarTem.rbdFchBon;
                string ParFchRev    = MmsWin.Front.Utilerias.VarTem.rbdFchRev;
                string ParTipoCal   = MmsWin.Front.Utilerias.VarTem.rbdTipoCal;
                string ParTemporada = MmsWin.Front.Utilerias.VarTem.rbdTemporada;
                string ParTienda    = MmsWin.Front.Utilerias.VarTem.rbdTienda;
                string ParProveedor = MmsWin.Front.Utilerias.VarTem.rbdProveedor;
                string ParEstilo    = MmsWin.Front.Utilerias.VarTem.rbdEstilo;

                string ParNota      = MmsWin.Front.Utilerias.VarTem.rbdNota;

                System.Data.DataTable dtRutaPDF = null;
                dtRutaPDF = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenRutaPDFRebajasDiferenciadas(ParFchBon, ParFchRev, ParTipoCal, ParTemporada, ParTienda, ParProveedor, ParEstilo, ParNota);
                foreach (DataRow row in dtRutaPDF.Rows)
                {
                    string ruta = row["NOTRUT"].ToString();

                    string notaPDF = ruta;
                    Process.Start(notaPDF);
                }
            }
            catch { MessageBox.Show("No hay PDF Cargado"); }
        }

        private void MuestraPDF()
        {
            try
            {
                System.Diagnostics.Process p = new System.Diagnostics.Process();
                string ext = ".pdf";
                string path = @"C:\Reportes\PDF\";
                string pdf = path + "cfdi_nc_NC440" + ext;
                p.StartInfo.FileName = pdf;
                p.Start();
            }
            catch
            {
                MessageBox.Show("No hay nota de crédito asignada.");
            }
        }

        private void EliminacheckBox()
        {
            try
            {
                dgvGridView.Columns.Remove("CORREOE");
                dgvGridView.Columns.Remove("CALXOMI");
                dgvGridView.Columns.Remove("IDENTIF");
                dgvGridView.Columns.Remove("COSTO");
                dgvGridView.Columns.Remove("PRECIO");
                dgvGridView.Columns.Remove("DEVOL");
                dgvGridView.Columns.Remove("FACTEMIT");
                dgvGridView.Columns.Remove("POLIZA");

                dgvGridView.Columns.Remove("STSCOR");
                dgvGridView.Columns.Remove("STSCXO");
                dgvGridView.Columns.Remove("STSIDE");
                dgvGridView.Columns.Remove("STSCST");
                dgvGridView.Columns.Remove("STSPRC");
                dgvGridView.Columns.Remove("STSDEV");
                dgvGridView.Columns.Remove("STSFEM");
                dgvGridView.Columns.Remove("STSPOL");

                dgvGridView.Columns.Remove("COMPRAS");
                dgvGridView.Columns.Remove("CONTRALORIA");
            }
            catch { }
        }

        private void dgvGridView_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                BindBonifica();
            }
        }

        private void ExpExcel()
        {
            this.Cursor = Cursors.WaitCursor;

            System.Data.DataTable dtDowns = (System.Data.DataTable)(dgvGridView.DataSource);
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            int nc = dgvGridView.Columns.Count;


            for (int ii = 1; ii <= nc; ii++)
            {
                xlWorkSheet.Cells[1, ii] = dgvGridView.Columns[ii - 1].HeaderText;
            }


            System.Data.DataTable dtConvenio = (System.Data.DataTable)(dgvGridView.DataSource);
            int nr = dgvGridView.RowCount;
            this.pgbProg.Visible = true;

            pgbProg.Maximum = nr;
            pgbProg.Value = 0;
            int r = 0; 
            int rt = 3; 
            foreach (DataRow row in dtDowns.Rows)
            {
                var gsArray = new[]       {
                                                    row["RBDFBO"],  // Fecha de Bonificacion
                                                    row["RBDTPO"],  // Tipo
                                                    row["RBDTMP"],  // Temporada
                                                    row["RBDSTR"],  // Tienda
                                                    row["RBDNAM"],  // Nombre
                                                    row["RBDPRV"],  // Proveedor
                                                    row["RBDPRN"],  // Nombre
                                                    row["RBDSTY"],  // Estilo 
                                                    row["RBDDES"],  // Descripcion
                                                    row["RBDDCP"],  // Comprador
                                                    row["RBDFCM"],  // Fecha de Compra
                                                    row["RBDFRE"],  // Fecha Revision
                                                    row["RBDPZA"],  // Piezas
                                                    row["RBDVTA"],  // Venta
                                                    row["RBDONH"],  // on hand
                                                    row["RBDPVT"],  // % de Venta
                                                    row["RBDCAL"],  // Calificacion
                                                    row["RBDTAB"],  // Tabla de Accion
                                                    row["RBDNOT"],  // Nota de Credito
                                                    row["RBDSUB"],  // Suptotal
                                                    row["RBDIVA"],  // IVA
                                                    row["RBDTOT"],  // Total
                                                    row["RBDPBO"],  // % Bonificacion
                                                    row["RBDCST"],  // Costo Actual
                                                    row["RBDPRC"],  // Precio Actual
                                                    row["RBDMRG"],  // Margen Actual
                                                    row["RBDCST1"], // Costo Nuevo
                                                    row["RBDPRC1"], // Precio Nuevo
                                                    row["RBDMRG1"], // Margen Nuevo
                                                    row["RBDCST2"], // Costo Final
                                                    row["RBDPRC2"], // Precio Final
                                                    row["RBDMRG2"], // Margen Final
                                                    row["RBDCMP"],  // Compras Observaciones
                                                    row["RBDTAB2"], // Tabla de Acccion 2 
                                                    row["RBDCSTD"], // Diferencia en costo
                                                    row["RBDPZA1"], // Piezas On Hand
                                                    row["RBDIMP1"], // Importe On Hand
                                                    row["RBDPRO"],  // Promocion

                                                    row["RBDDCF2"], // Dif Cst Final 
                                                    row["RBDIDC2"], // Imp OH Dif Cst
                                                    row["RBDIMF2"], // Imp Mrg Final

                                                    row["RBDTABF"], // Tabla de Accion Final
                                                    row["RBDMAR"],  // Marca
                                                    row["RBDCID"],  // Comprador
                                                    row["RBDBDG"],  // Bodega
                                                    row["RBDCK1"],  // Compras
                                                    row["RBDCK2"],  // Contraloria
                                                    row["RBDNMR"],  // Marca
                                                    row["RBDFCHA"], // Fecha
                                                    row["RBDHORA"], // Hora
                                                    row["RBDUSR"],  // Usuario
                                                    row["RBDERR"],  // Estatus Folio
                                                    row["RBDCLF"],  // Correo electronico
                                                    row["RBDCXO"],  // Calificacion por Omision
                                                    row["RBDIDE"],  // Identificacion de Estilos
                                                    row["RBDRCS"],  // Rebaja de Costos
                                                    row["RBDRPR"],  // Rebaja de Precios
                                                    row["RBDDEV"],  // Devoluciones
                                                    row["RBDCFA"],  // Carga de Facturas
                                                    row["RBDPOL"],  // Poliza Contable
                                                    row["RBDCK3"],  // Sts correo
                                                    row["RBDCK4"],  // Sts Calificacion por Omision
                                                    row["RBDCK5"],  // Sts identificacion de Estilos
                                                    row["RBDCK6"],  // Sts Costos
                                                    row["RBDCK7"],  // Sts Precios
                                                    row["RBDCK8"],  // Sts Devoluciones
                                                    row["RBDCK9"],  // Sts Facturas
                                                    row["RBDCK10"], //Sts Polizas
                                                    row["RBDNCS"]   // Marca

                                                   };

                Range rng = xlWorkSheet.get_Range("A" + rt, "BM" + rt);
                rng.Value = gsArray;

                pgbProg.Value += 1;

                this.Text = "RebajaDiferenciada / " + " " + (r += 1).ToString() + " Registro(s)";

                // Pagar
                if (row["RBDCAL"].ToString() == " P a g a r") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.LightGreen; }
                // 15%
                if (row["RBDCAL"].ToString() == " 15%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.Yellow; }
                // 20%
                if (row["RBDCAL"].ToString() == " 20%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.Yellow; }
                // 25%
                if (row["RBDCAL"].ToString() == " 25%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.Yellow; }
                // 30%
                if (row["RBDCAL"].ToString() == " 30%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.LightSalmon; }
                // 35%
                if (row["RBDCAL"].ToString() == " 35%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.LightSalmon; }
                // 40%
                if (row["RBDCAL"].ToString() == " 40%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.LightSalmon; }
                // Dev ó 40%
                if (row["RBDCAL"].ToString() == " 40%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 13].Cells.Font.Color = Color.White; }
                // Dev ó 50%
                if (row["RBDCAL"].ToString() == " 50%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 13].Cells.Font.Color = Color.White; }
                //Dev o 50%
                if (row["RBDCAL"].ToString() == " 50%") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 13].Cells.Font.Color = Color.White; }
                // Devolucion
                if (row["RBDCAL"].ToString() == "Devolucion") { xlWorkSheet.Cells[rt, 17].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 13].Cells.Font.Color = Color.White; }
                rt++;
            }
            xlWorkSheet.Columns[1].ColumnWidth = 6;
            xlWorkSheet.Columns[6].ColumnWidth = 3;
            xlWorkSheet.Columns[7].ColumnWidth = 25;
            xlWorkSheet.Columns[8].ColumnWidth = 6;
            xlWorkSheet.Columns[9].ColumnWidth = 25;
            xlWorkSheet.Columns[10].ColumnWidth = 15;
            xlWorkSheet.Columns[11].ColumnWidth = 6;
            xlWorkSheet.Columns[12].ColumnWidth = 6;
            xlWorkSheet.Columns[13].ColumnWidth = 5;
            xlWorkSheet.Columns[14].ColumnWidth = 5;
            xlWorkSheet.Columns[15].ColumnWidth = 5;
            xlWorkSheet.Columns[16].ColumnWidth = 5;
            xlWorkSheet.Columns[17].ColumnWidth = 5;
            xlWorkSheet.Columns[18].ColumnWidth = 5;
            xlWorkSheet.Columns[19].ColumnWidth = 12;
            xlWorkSheet.Columns[20].ColumnWidth = 5;
            xlWorkSheet.Columns[21].ColumnWidth = 4;
            xlWorkSheet.Columns[22].ColumnWidth = 4;
            xlWorkSheet.Columns[23].ColumnWidth = 4;
            xlWorkSheet.Columns[24].ColumnWidth = 4;
            xlWorkSheet.Columns[25].ColumnWidth = 4;
            xlWorkSheet.Columns[26].ColumnWidth = 4;
            xlWorkSheet.Columns[27].ColumnWidth = 4;
            xlWorkSheet.Columns[28].ColumnWidth = 4;
            xlWorkSheet.Columns[29].ColumnWidth = 4;
            xlWorkSheet.Columns[30].ColumnWidth = 4;
            xlWorkSheet.Columns[31].ColumnWidth = 4;
            xlWorkSheet.Columns[32].ColumnWidth = 10;
            xlWorkSheet.Columns[33].ColumnWidth = 50;
            xlWorkSheet.Columns[34].ColumnWidth = 10;
            xlWorkSheet.Columns[35].ColumnWidth = 10;
            xlWorkSheet.Columns[36].ColumnWidth = 10;
            xlWorkSheet.Columns[37].ColumnWidth = 10;
            xlWorkSheet.Columns[38].ColumnWidth = 10;
            xlWorkSheet.Columns[39].ColumnWidth = 10;
            xlWorkSheet.Columns[40].ColumnWidth = 10;
            xlWorkSheet.Columns[41].ColumnWidth = 10;
            xlWorkSheet.Columns[42].ColumnWidth = 10;
            xlWorkSheet.Columns[43].ColumnWidth = 10;
            xlWorkSheet.Columns[44].ColumnWidth = 10;
            xlWorkSheet.Columns[45].ColumnWidth = 10;
            xlWorkSheet.Columns[46].ColumnWidth = 10;
            xlWorkSheet.Columns[47].ColumnWidth = 10;
            xlWorkSheet.Columns[48].ColumnWidth = 10;
            xlWorkSheet.Columns[49].ColumnWidth = 10;
            xlWorkSheet.Columns[46].ColumnWidth = 10;
            xlWorkSheet.Columns[47].ColumnWidth = 10;
            xlWorkSheet.Columns[48].ColumnWidth = 50;
            xlWorkSheet.Columns[49].ColumnWidth = 10;
            xlWorkSheet.Columns[54].ColumnWidth = 10;
            xlWorkSheet.Columns[55].ColumnWidth = 10;
            xlWorkSheet.Columns[56].ColumnWidth = 10;
            xlWorkSheet.Columns[57].ColumnWidth = 10;
            xlWorkSheet.Columns[58].ColumnWidth = 10;
            xlWorkSheet.Columns[59].ColumnWidth = 10;
            xlWorkSheet.Columns[60].ColumnWidth = 10;
            xlWorkSheet.Columns[61].ColumnWidth = 10;
            xlWorkSheet.Columns[62].ColumnWidth = 10;
            xlWorkSheet.Columns[63].ColumnWidth = 10;
            xlWorkSheet.Columns[64].ColumnWidth = 10;
            xlWorkSheet.Columns[65].ColumnWidth = 10;
            xlWorkSheet.Columns[66].ColumnWidth = 10;
            xlWorkSheet.Columns[67].ColumnWidth = 10;
            xlWorkSheet.Columns[68].ColumnWidth = 10;
            xlWorkSheet.Columns[69].ColumnWidth = 10;
            xlWorkSheet.Columns[70].ColumnWidth = 10;

            xlWorkSheet.Cells[1, 1].Cells.Interior.Color = Color.LightSalmon;

            var Rang1 = xlWorkSheet.get_Range("B1", "C1");
            Rang1.Interior.Color = Color.LightGreen;

            var Rang2 = xlWorkSheet.get_Range("D1", "E1");
            Rang2.Interior.Color = Color.LightSkyBlue;

            xlWorkSheet.Cells[1, 10].Cells.Interior.Color = Color.LightSalmon;

            var Rang3 = xlWorkSheet.get_Range("G1", "H1");
            Rang3.Interior.Color = Color.LightGreen;

            xlWorkSheet.Cells[1, 13].Cells.Interior.Color = Color.LightSteelBlue;
            xlWorkSheet.Cells[1, 14].Cells.Interior.Color = Color.LightSteelBlue;
            xlWorkSheet.Cells[1, 15].Cells.Interior.Color = Color.LightSteelBlue;
            xlWorkSheet.Cells[1, 16].Cells.Interior.Color = Color.LightSteelBlue;


            var Rang4 = xlWorkSheet.get_Range("M1", "N1");
            Rang4.Interior.Color = Color.LightCoral;

            xlWorkSheet.Cells[1, 19].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 20].Cells.Interior.Color = Color.LightSlateGray;
            xlWorkSheet.Cells[1, 21].Cells.Interior.Color = Color.LightSlateGray;
            xlWorkSheet.Cells[1, 22].Cells.Interior.Color = Color.LightSlateGray;

            xlWorkSheet.Cells[1, 23].Cells.Interior.Color = Color.LightSalmon;

            xlWorkSheet.Cells[1, 24].Cells.Interior.Color = Color.FromArgb(0, 192, 0); 
            xlWorkSheet.Cells[1, 25].Cells.Interior.Color = Color.FromArgb(0, 192, 0);
            xlWorkSheet.Cells[1, 26].Cells.Interior.Color = Color.FromArgb(0, 192, 0); 

            xlWorkSheet.Cells[1, 27].Cells.Interior.Color = Color.Red;
            xlWorkSheet.Cells[1, 28].Cells.Interior.Color = Color.Red;
            xlWorkSheet.Cells[1, 29].Cells.Interior.Color = Color.Red;

            xlWorkSheet.Cells[1, 30].Cells.Interior.Color = Color.FromArgb(0, 0, 192);
            xlWorkSheet.Cells[1, 31].Cells.Interior.Color = Color.FromArgb(0, 0, 192);
            xlWorkSheet.Cells[1, 32].Cells.Interior.Color = Color.FromArgb(0, 0, 192);            

            xlWorkSheet.Cells[1, 33].Cells.Interior.Color = Color.LightCoral;
            xlWorkSheet.Cells[1, 34].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 35].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 36].Cells.Interior.Color = Color.LightSeaGreen;
            xlWorkSheet.Cells[1, 37].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 38].Cells.Interior.Color = Color.LightSkyBlue;

            var Rang5 = xlWorkSheet.get_Range("AC1", "AC1");
            Rang5.Interior.Color = Color.LightSalmon;

            var Rang6 = xlWorkSheet.get_Range("AE1", "AG1");
            Rang6.Interior.Color = Color.LightSkyBlue;

            var Rang7 = xlWorkSheet.get_Range("AI1", "AK1");
            Rang7.Interior.Color = Color.LightSlateGray;

            var Rang10 = xlWorkSheet.get_Range("AL1", "AL1");
            Rang10.Interior.Color = Color.LightSalmon;

            var Rang11 = xlWorkSheet.get_Range("AM1", "AM1");
            Rang11.Interior.Color = Color.LightGreen;

            var Rang12 = xlWorkSheet.get_Range("AN1", "AR1");
            Rang12.Interior.Color = Color.LightSeaGreen;

            var Rang13 = xlWorkSheet.get_Range("AS1", "AV1");
            Rang13.Interior.Color = Color.LightSeaGreen;

            var Rang14 = xlWorkSheet.get_Range("AW1", "BD1");
            Rang14.Interior.Color = Color.Red;

            var Rang15 = xlWorkSheet.get_Range("BE1", "BM1");
            Rang15.Interior.Color = Color.Green;

            xlWorkSheet.Cells[1, 46].Cells.Interior.Color = Color.Green;
            xlWorkSheet.Cells[1, 47].Cells.Interior.Color = Color.Blue;

            var Rang8 = xlWorkSheet.get_Range("A1", "BM1");
            Rang8.WrapText = true;
            Rang8.Font.Bold = true;
            Rang8.Font.Color = Color.White;
            Rang8.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang8.Font.Underline = true;
            Rang8.HorizontalAlignment = HorizontalAlignment.Center;

            String Rango = "A2" + ":" + "BM" + rt;
            Excel.Range SourceRange = (Excel.Range)xlWorkSheet.get_Range("A2", "BM" + rt); // or whatever range you want here
            FormatAsTable(SourceRange, "Table1", "TableStyleMedium2");

            xlWorkSheet.Rows[6].Hidden = true;

            xlWorkSheet.Columns["A"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["C"].HorizontalAlignment     = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["D"].HorizontalAlignment     = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["F"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["G"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["H"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["M"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["N"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["O"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["S"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["V"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["Y"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["Z"].HorizontalAlignment     = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["AA"].HorizontalAlignment    = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["AB"].HorizontalAlignment    = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AD"].HorizontalAlignment    = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AE"].HorizontalAlignment    = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["AF"].HorizontalAlignment    = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["AJ"].HorizontalAlignment    = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AL"].HorizontalAlignment    = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AM"].HorizontalAlignment    = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AN"].HorizontalAlignment    = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AO"].HorizontalAlignment    = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AP:AU"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AW:BM"].HorizontalAlignment = XlHAlign.xlHAlignCenter;

            xlWorkSheet.Columns["A"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["G"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["H"].NumberFormat = "20##-##-##";
            xlWorkSheet.Columns["I:K"].NumberFormat = "#,##0";
            xlWorkSheet.Columns["P:R"].NumberFormat = "#,##0.00";
            xlWorkSheet.Columns["T:AB"].NumberFormat = "#,###.00";
            xlWorkSheet.Columns["AE:Ak"].NumberFormat = "#,##0.00";
            xlWorkSheet.Columns["AF"].NumberFormat = "#,##0";
            xlWorkSheet.Columns["AG"].NumberFormat = "#,##0.00";

            var range = xlWorkSheet.get_Range("A3", "A3");
            range.Select();

            string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
            xlApp.ActiveWindow.Zoom = 80;
            xlWorkBook.SaveAs("C:\\Reportes\\RebajaDiferenciada" + Hoy + ".xlsx", Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            string comando = @"C:\\Reportes\\RebajaDiferenciada" + Hoy + ".xlsx";
            ExecuteCommand(comando);

            this.pgbProg.Visible = false;

            this.Cursor = Cursors.Default;
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        static void ExecuteCommand(string _Command)
        {
            //Indicamos que deseamos inicializar el proceso cmd.exe junto a un comando de arranque. 
            //(/C, le indicamos al proceso cmd que deseamos que cuando termine la tarea asignada se cierre el proceso).
            //Para mas informacion consulte la ayuda de la consola con cmd.exe /? 
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;
            //Inicializa el proceso
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            string result = proc.StandardOutput.ReadToEnd();
            //Muestra en pantalla la salida del Comando
            // Console.WriteLine(result);
        }
        
        public void FormatAsTable(Excel.Range SourceRange, string TableName, string TableStyleName)
        {
            SourceRange.Worksheet.ListObjects.Add(XlListObjectSourceType.xlSrcRange,
            SourceRange, System.Type.Missing, XlYesNoGuess.xlYes, System.Type.Missing).Name =
                TableName;
            SourceRange.Select();
            SourceRange.Worksheet.ListObjects[TableName].TableStyle = TableStyleName;
            SourceRange.Worksheet.ListObjects[TableName].ShowAutoFilter = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowHeaders = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowTotals = false;
        }

        private void pbExcel_Click(object sender, EventArgs e)
        {
            ExpExcel(); 
        }

        private void eliminarTSM1_Click(object sender, EventArgs e)
        {
           string message = "Corfirmar la Eliminacion del Registro";
           string caption = "Advertencia...";
           MessageBoxButtons buttons = MessageBoxButtons.YesNo;
           DialogResult result;
           result = MessageBox.Show(message, caption, buttons);
           if (result == System.Windows.Forms.DialogResult.Yes)
           {
               string ParFchBon    = MmsWin.Front.Utilerias.VarTem.rbdFchBon;
               string ParFchRev    = MmsWin.Front.Utilerias.VarTem.rbdFchRev;
               string ParTipoCal   = MmsWin.Front.Utilerias.VarTem.rbdTipoCal;
               string ParTemporada = MmsWin.Front.Utilerias.VarTem.rbdTemporada;
               string ParTienda    = MmsWin.Front.Utilerias.VarTem.rbdTienda;
               string ParProveedor = MmsWin.Front.Utilerias.VarTem.rbdProveedor;
               string ParEstilo    = MmsWin.Front.Utilerias.VarTem.rbdEstilo;
               MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().EliminaRebajasDiferenciadas(ParFchBon, ParFchRev, ParTipoCal, ParTemporada, ParTienda, ParProveedor, ParEstilo);

               BindBonifica();
           }
        }

        private void RebajaDiferenciada_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Carga Seguridad  
          string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
          if (Nivel == "ADMINISTRADOR")
          {
              CargaSeguridad("RebajaDiferenciada", "RebajaDiferenciada", ParUser);
          }
        }
        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            //
            string NomCol;
            Int32 NoCol = dgvGridView.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvGridView.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      
            //
            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void dgvGridView_Sorted(object sender, EventArgs e)
        {
            SetFontAndColors();
            rowStyle();
        }

        private void pbBonAnticipada_Click(object sender, EventArgs e)
        {
            try
            {
                //BonificaAnticipada i = new BonificaAnticipada();
                //i.Show();
            }
            catch { }
            finally { }
        }

        private void pbOmisionXTemp_Click(object sender, EventArgs e)
        {
            try
            {
                //OmisionDeEstilos i = new OmisionDeEstilos();
                //i.Show();
            }
            catch { }
            finally { }
        }

        private void ActualizarTSMI_Click(object sender, EventArgs e)
        {
            ActualizarRebajaDiferenciada();
        }

        private void ActualizarRebajaDiferenciada()
        {
            System.Data.DataTable dtRebajaDiferenciada = new System.Data.DataTable("RebajaDiferenciada");
            dtRebajaDiferenciada.Columns.Add("FechaBon",      typeof(String));

            dtRebajaDiferenciada.Columns.Add("TipoCal",       typeof(String));
            dtRebajaDiferenciada.Columns.Add("Temporada",     typeof(String));
            dtRebajaDiferenciada.Columns.Add("Tienda",        typeof(String));
            dtRebajaDiferenciada.Columns.Add("NomTda",        typeof(String));

            dtRebajaDiferenciada.Columns.Add("FechaRev",      typeof(String));
            dtRebajaDiferenciada.Columns.Add("Proveedor",     typeof(String));
            dtRebajaDiferenciada.Columns.Add("Estilo",        typeof(String));

            dtRebajaDiferenciada.Columns.Add("NotaCred",      typeof(String));
            dtRebajaDiferenciada.Columns.Add("SubTotal",      typeof(String));
            dtRebajaDiferenciada.Columns.Add("Iva",           typeof(String));
            dtRebajaDiferenciada.Columns.Add("Total",         typeof(String));
            dtRebajaDiferenciada.Columns.Add("PorcBon",       typeof(String));
            dtRebajaDiferenciada.Columns.Add("CostoAct",      typeof(String));
            dtRebajaDiferenciada.Columns.Add("PrecioAct",     typeof(String));
            dtRebajaDiferenciada.Columns.Add("MargenAct",     typeof(String));
            dtRebajaDiferenciada.Columns.Add("CostoNuev",     typeof(String));
            dtRebajaDiferenciada.Columns.Add("PrecioNuev",    typeof(String));
            dtRebajaDiferenciada.Columns.Add("MargenNuev",    typeof(String));
            dtRebajaDiferenciada.Columns.Add("CostiFinal",    typeof(String));
            dtRebajaDiferenciada.Columns.Add("PrecioFinal",   typeof(String));
            dtRebajaDiferenciada.Columns.Add("MargenFinal",   typeof(String));
            dtRebajaDiferenciada.Columns.Add("Observaciones", typeof(String));
            dtRebajaDiferenciada.Columns.Add("TablaAccion2",  typeof(String));
            dtRebajaDiferenciada.Columns.Add("TablaAccion",   typeof(String));

            dtRebajaDiferenciada.Columns.Add("Correo",        typeof(String));
            dtRebajaDiferenciada.Columns.Add("CalxOmi",       typeof(String));
            dtRebajaDiferenciada.Columns.Add("Identif",       typeof(String));
            dtRebajaDiferenciada.Columns.Add("Costo",         typeof(String));
            dtRebajaDiferenciada.Columns.Add("Precio",        typeof(String));
            dtRebajaDiferenciada.Columns.Add("Devolucion",    typeof(String));
            dtRebajaDiferenciada.Columns.Add("FactEmit",      typeof(String));
            dtRebajaDiferenciada.Columns.Add("Poliza",        typeof(String));

            dtRebajaDiferenciada.Columns.Add("stCorreo",      typeof(String));
            dtRebajaDiferenciada.Columns.Add("stCalxOmi",     typeof(String));
            dtRebajaDiferenciada.Columns.Add("stIdentif",     typeof(String));
            dtRebajaDiferenciada.Columns.Add("stCosto",       typeof(String));
            dtRebajaDiferenciada.Columns.Add("stPrecio",      typeof(String));
            dtRebajaDiferenciada.Columns.Add("stDevolucion",  typeof(String));
            dtRebajaDiferenciada.Columns.Add("stFactEmit",    typeof(String));
            dtRebajaDiferenciada.Columns.Add("stPoliza",      typeof(String));

            dtRebajaDiferenciada.Columns.Add("Compras",       typeof(String));
            dtRebajaDiferenciada.Columns.Add("Contraloria",   typeof(String));

            dtRebajaDiferenciada.Columns.Add("DifCostoFinal", typeof(String));
            dtRebajaDiferenciada.Columns.Add("ImporteOnHand", typeof(String));
            dtRebajaDiferenciada.Columns.Add("ImporteMargen", typeof(String));

            DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                DataRow workRow      = dtRebajaDiferenciada.NewRow();
                workRow["FechaBon"]      = item.Cells["RBDFBO"].Value.ToString();

                workRow["TipoCal"]       = item.Cells["RBDTPO"].Value.ToString();
                workRow["Temporada"]     = item.Cells["RBDTMP"].Value.ToString();
                workRow["Tienda"]        = item.Cells["RBDSTR"].Value.ToString();
                workRow["NomTda"]        = item.Cells["RBDNAM"].Value.ToString();

                workRow["FechaRev"]      = item.Cells["RBDFRE"].Value.ToString();
                workRow["Proveedor"]     = item.Cells["RBDPRV"].Value.ToString();
                workRow["Estilo"]        = item.Cells["RBDSTY"].Value.ToString();

                workRow["NotaCred"]      = item.Cells["RBDNOT"].Value.ToString();
                workRow["SubTotal"]      = item.Cells["RBDSUB"].Value.ToString();
                workRow["Iva"]           = item.Cells["RBDIVA"].Value.ToString();
                workRow["Total"]         = item.Cells["RBDTOT"].Value.ToString();
                workRow["PorcBon"]       = item.Cells["RBDPBO"].Value.ToString();
                workRow["CostoAct"]      = item.Cells["RBDCST"].Value.ToString();
                workRow["PrecioAct"]     = item.Cells["RBDPRC"].Value.ToString();
                workRow["MargenAct"]     = item.Cells["RBDMRG"].Value.ToString();
                workRow["CostoNuev"]     = item.Cells["RBDCST1"].Value.ToString();
                workRow["PrecioNuev"]    = item.Cells["RBDPRC1"].Value.ToString();
                workRow["MargenNuev"]    = item.Cells["RBDMRG1"].Value.ToString();
                workRow["CostiFinal"]    = item.Cells["RBDCST2"].Value.ToString();
                workRow["PrecioFinal"]   = item.Cells["RBDPRC2"].Value.ToString();
                workRow["MargenFinal"]   = item.Cells["RBDMRG2"].Value.ToString();
                workRow["Observaciones"] = item.Cells["RBDCMP"].Value.ToString();
                workRow["TablaAccion2"]  = item.Cells["RBDTAB2"].Value.ToString();
                workRow["TablaAccion"]   = item.Cells["RBDCSTD"].Value.ToString();

                workRow["Correo"]        = item.Cells["RBDCLF"].Value.ToString();
                workRow["CalxOmi"]       = item.Cells["RBDCXO"].Value.ToString();
                workRow["Identif"]       = item.Cells["RBDIDE"].Value.ToString();
                workRow["Costo"]         = item.Cells["RBDRCS"].Value.ToString();
                workRow["Precio"]        = item.Cells["RBDRPR"].Value.ToString();
                workRow["Devolucion"]    = item.Cells["RBDDEV"].Value.ToString();
                workRow["FactEmit"]      = item.Cells["RBDCFA"].Value.ToString();
                workRow["Poliza"]        = item.Cells["RBDPOL"].Value.ToString();

                workRow["stCorreo"]      = item.Cells["RBDCK3"].Value.ToString();
                workRow["stCalxOmi"]     = item.Cells["RBDCK4"].Value.ToString();
                workRow["stIdentif"]     = item.Cells["RBDCK5"].Value.ToString();
                workRow["stCosto"]       = item.Cells["RBDCK6"].Value.ToString();
                workRow["stPrecio"]      = item.Cells["RBDCK7"].Value.ToString();
                workRow["stDevolucion"]  = item.Cells["RBDCK8"].Value.ToString();
                workRow["stFactEmit"]    = item.Cells["RBDCK9"].Value.ToString();
                workRow["stPoliza"]      = item.Cells["RBDCK10"].Value.ToString();

                workRow["Compras"]       = item.Cells["RBDCK1"].Value.ToString();
                workRow["Contraloria"]   = item.Cells["RBDCK2"].Value.ToString();

                workRow["DifCostoFinal"] = item.Cells["RBDDCF2"].Value.ToString();
                workRow["ImporteOnHand"] = item.Cells["RBDIDC2"].Value.ToString();
                workRow["ImporteMargen"] = item.Cells["RBDIMF2"].Value.ToString();

                dtRebajaDiferenciada.Rows.Add(workRow);
            }
            
            MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateRebajasDiferenciadas(dtRebajaDiferenciada);

            BindBonifica();
            MessageBox.Show("Actualizacion completa...");
            BindBonifica();
        }

        private void btCheckBox_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            System.Data.DataTable dtCheckBox = new System.Data.DataTable("RebajaDiferenciada");
            dtCheckBox.Columns.Add("FechaBon",   typeof(String));

            dtCheckBox.Columns.Add("TipoCal",    typeof(String));
            dtCheckBox.Columns.Add("Temporada",  typeof(String));
            dtCheckBox.Columns.Add("Tienda",     typeof(String));
            dtCheckBox.Columns.Add("NomTda",     typeof(String));

            dtCheckBox.Columns.Add("FechaRev",   typeof(String));
            dtCheckBox.Columns.Add("Proveedor",  typeof(String));
            dtCheckBox.Columns.Add("Estilo",     typeof(String));

            dtCheckBox.Columns.Add("Correo",     typeof(String));
            dtCheckBox.Columns.Add("Cor1",       typeof(String));
            dtCheckBox.Columns.Add("CalxOmi",    typeof(String));
            dtCheckBox.Columns.Add("Cal1",       typeof(String));
            dtCheckBox.Columns.Add("Identif",    typeof(String));
            dtCheckBox.Columns.Add("Ide1",       typeof(String));
            dtCheckBox.Columns.Add("Costo",      typeof(String));
            dtCheckBox.Columns.Add("Cos1",       typeof(String));
            dtCheckBox.Columns.Add("Precio",     typeof(String));
            dtCheckBox.Columns.Add("Pre1",       typeof(String));
            dtCheckBox.Columns.Add("Devolucion", typeof(String));
            dtCheckBox.Columns.Add("Dev1",       typeof(String));
            dtCheckBox.Columns.Add("FactEmit",   typeof(String));
            dtCheckBox.Columns.Add("Fac1",       typeof(String));
            dtCheckBox.Columns.Add("Poliza1",    typeof(String));
            dtCheckBox.Columns.Add("Pol1",       typeof(String));

            dtCheckBox.Columns.Add("stCorreo",   typeof(String));
            dtCheckBox.Columns.Add("stCor1",     typeof(String));
            dtCheckBox.Columns.Add("stCalxOmi",  typeof(String));
            dtCheckBox.Columns.Add("stCal1",     typeof(String));
            dtCheckBox.Columns.Add("stIdentif",  typeof(String));
            dtCheckBox.Columns.Add("stIde1",     typeof(String));
            dtCheckBox.Columns.Add("stCosto",    typeof(String));
            dtCheckBox.Columns.Add("stCos1",     typeof(String));
            dtCheckBox.Columns.Add("stPrecio",   typeof(String));
            dtCheckBox.Columns.Add("stPre1",     typeof(String));
            dtCheckBox.Columns.Add("stDevolucion", typeof(String));
            dtCheckBox.Columns.Add("stDev1",     typeof(String));
            dtCheckBox.Columns.Add("stFactEmit", typeof(String));
            dtCheckBox.Columns.Add("stFac1",     typeof(String));
            dtCheckBox.Columns.Add("stPoliza1",  typeof(String));
            dtCheckBox.Columns.Add("stPol1",     typeof(String));

            dtCheckBox.Columns.Add("Compras",    typeof(String));
            dtCheckBox.Columns.Add("Com1",       typeof(String));
            dtCheckBox.Columns.Add("Contraloria", typeof(String));
            dtCheckBox.Columns.Add("Con1",       typeof(String));

            int RegChkBox = 0;

            foreach (DataGridViewRow item in dgvGridView.Rows)
            {
                {
                    if ((item.Cells[65].Value != null) || (item.Cells[66].Value != null) || (item.Cells[67].Value != null) ||
                        (item.Cells[68].Value != null) || (item.Cells[69].Value != null) || (item.Cells[70].Value != null) ||
                        (item.Cells[71].Value != null) || (item.Cells[72].Value != null) || (item.Cells[73].Value != null) ||
                        (item.Cells[74].Value != null) || (item.Cells[75].Value != null) || (item.Cells[76].Value != null) ||
                        (item.Cells[77].Value != null) || (item.Cells[78].Value != null) || (item.Cells[79].Value != null) ||
                        (item.Cells[80].Value != null) || (item.Cells[81].Value != null) || (item.Cells[82].Value != null) ||
                        (item.Cells[83].Value != null) || (item.Cells[84].Value != null) || (item.Cells[85].Value != null) ||
                        (item.Cells[86].Value != null))
                        
                      {
                          DataRow workRow = dtCheckBox.NewRow();
                          workRow["FechaBon"]  = item.Cells["RBDFBO"].Value.ToString();
                          workRow["TipoCal"]   = item.Cells["RBDTPO"].Value.ToString();
                          workRow["Temporada"] = item.Cells["RBDTMP"].Value.ToString();
                          workRow["Tienda"]    = item.Cells["RBDSTR"].Value.ToString();
                          workRow["NomTda"]    = item.Cells["RBDNAM"].Value.ToString();
                          workRow["FechaRev"]  = item.Cells["RBDFRE"].Value.ToString();
                          workRow["Proveedor"] = item.Cells["RBDPRV"].Value.ToString();
                          workRow["Estilo"]    = item.Cells["RBDSTY"].Value.ToString();
                          try

                          {
                              workRow["Cor1"] = "0";
                              try { if ((Boolean)item.Cells["CORREOE"].Value == true)
                                  { workRow["Correo"] = "1"; workRow["Cor1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                                  { workRow["Correo"] = "0"; workRow["Cor1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }

                              workRow["Cal1"] = "0";
                              try { if ((Boolean)item.Cells["CALXOMI"].Value == true)
                                  { workRow["CalxOmi"] = "1"; workRow["Cal1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                                  { workRow["CalxOmi"] = "0"; workRow["Cal1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }

                              workRow["Ide1"] = "0";
                              try { if ((Boolean)item.Cells["IDENTIF"].Value == true)
                                  { workRow["Identif"] = "1"; workRow["Ide1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                                  { workRow["Identif"] = "0"; workRow["Ide1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }

                              workRow["Cos1"] = "0";
                              try { if ((Boolean)item.Cells["COSTO"].Value == true)
                                  { workRow["Costo"] = "1"; workRow["Cos1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                                  { workRow["Costo"] = "0"; workRow["Cos1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }

                              workRow["Pre1"] = "0";
                              try { if ((Boolean)item.Cells["PRECIO"].Value == true)
                                  { workRow["Precio"] = "1"; workRow["Pre1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                                  { workRow["Precio"] = "0"; workRow["Pre1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }

                              workRow["Dev1"] = "0";
                              try { if ((Boolean)item.Cells["DEVOL"].Value == true)
                                  { workRow["Devolucion"] = "1"; workRow["Dev1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                                  { workRow["Devolucion"] = "0"; workRow["Dev1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }

                              workRow["Fac1"] = "0";
                              try { if ((Boolean)item.Cells["FACTEMIT"].Value == true)
                                  { workRow["FactEmit"] = "1"; workRow["Fac1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                                  { workRow["FactEmit"] = "0"; workRow["Fac1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }

                              workRow["Pol1"] = "0";
                              try { if ((Boolean)item.Cells["POLIZA"].Value == true)
                                  { workRow["Poliza1"] = "1"; workRow["Pol1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                                  { workRow["Poliza1"] = "0"; workRow["Pol1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }
                              //- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                              workRow["stCor1"] = "0";
                              try { if ((Boolean)item.Cells["STSCOR"].Value == true)
                              { workRow["stCorreo"] = "1"; workRow["stCor1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                              { workRow["stCorreo"] = "0"; workRow["stCor1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }

                              workRow["stCal1"] = "0";
                              try { if ((Boolean)item.Cells["STSCXO"].Value == true)
                              { workRow["stCalxOmi"] = "1"; workRow["stCal1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                              { workRow["stCalxOmi"] = "0"; workRow["stCal1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }

                              workRow["stIde1"] = "0";
                              try { if ((Boolean)item.Cells["STSIDE"].Value == true)
                              { workRow["stIdentif"] = "1"; workRow["stIde1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                              { workRow["stIdentif"] = "0"; workRow["stIde1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }

                              workRow["stCos1"] = "0";
                              try { if ((Boolean)item.Cells["STSCST"].Value == true)
                              { workRow["stCosto"] = "1"; workRow["stCos1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                              { workRow["stCosto"] = "0"; workRow["stCos1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }

                              workRow["stPre1"] = "0";
                              try { if ((Boolean)item.Cells["STSPRC"].Value == true)
                              { workRow["stPrecio"] = "1"; workRow["stPre1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                              { workRow["stPrecio"] = "0"; workRow["stPre1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }

                              workRow["stDev1"] = "0";
                              try { if ((Boolean)item.Cells["STSDEV"].Value == true)
                              { workRow["stDevolucion"] = "1"; workRow["stDev1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                              { workRow["stDevolucion"] = "0"; workRow["stDev1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }

                              workRow["stFac1"] = "0";
                              try { if ((Boolean)item.Cells["STSFEM"].Value == true)
                              { workRow["stFactEmit"] = "1"; workRow["stFac1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                              { workRow["stFactEmit"] = "0"; workRow["stFac1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }
                              
                              workRow["stPol1"] = "0";
                              try { if ((Boolean)item.Cells["STSPOL"].Value == true)
                                  { workRow["stPoliza1"] = "1"; workRow["stPol1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                                  { workRow["stPoliza1"] = "0"; workRow["stPol1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }

                              workRow["Com1"] = "0";
                              try { if ((Boolean)item.Cells["COMPRAS"].Value == true)
                                  { workRow["Compras"] = "1"; workRow["Com1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                                  { workRow["Compras"] = "0"; workRow["Com1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }

                              workRow["Con1"] = "0";
                              try { if ((Boolean)item.Cells["CONTRALORIA"].Value == true)
                                  { workRow["Contraloria"] = "1"; workRow["Con1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; }
                                  else
                                  { workRow["Contraloria"] = "0"; workRow["Con1"] = "1"; dtCheckBox.Rows.Add(workRow); RegChkBox++; } } catch { }
                          }
                          catch {  }
                      }

                }

            }

            if (RegChkBox > 0)
               {
                   MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateCheckBoxRebajasDiferenciadas(dtCheckBox);
                   BindBonifica();
                   dgvGridView.Focus();
                   SendKeys.Send("{END}");
                   SendKeys.Flush();
                   MessageBox.Show("Actualizacion completa...");
               }
          this.Cursor = Cursors.Default;
         }

        private void chbCheckApli_CheckStateChanged(object sender, EventArgs e)
        {
            CheckApli();
        }

        private void chbCheckBsts_CheckStateChanged(object sender, EventArgs e)
        {
            CheckBsts();
        }

        private void CheckApli()
        {
            if (chbCheckApli.Checked)
            {
                try
                {
                    dgvGridView.Columns[69].Visible = true;
                    dgvGridView.Columns[70].Visible = true;
                    dgvGridView.Columns[71].Visible = true;
                    dgvGridView.Columns[72].Visible = true;
                    dgvGridView.Columns[73].Visible = true;
                    dgvGridView.Columns[74].Visible = true;
                    dgvGridView.Columns[75].Visible = true;
                    dgvGridView.Columns[76].Visible = true;
                }
                catch { }
                dgvGridView.Focus();
                dgvGridView.Select();
                SendKeys.Send("{END}");
                SendKeys.Flush();
            }
            else
            {
                try
                {
                    dgvGridView.Columns[69].Visible = false;
                    dgvGridView.Columns[70].Visible = false;
                    dgvGridView.Columns[71].Visible = false;
                    dgvGridView.Columns[72].Visible = false;
                    dgvGridView.Columns[73].Visible = false;
                    dgvGridView.Columns[74].Visible = false;
                    dgvGridView.Columns[75].Visible = false;
                    dgvGridView.Columns[76].Visible = false;
                }
                catch { }
                dgvGridView.Focus();
                dgvGridView.Select();
                SendKeys.Send("{END}");
                SendKeys.Flush();
            }
        }

        private void CheckBsts()
        {
            if (chbCheckBsts.Checked)
            {
                try
                {
                    dgvGridView.Columns[48].Visible = true;
                    dgvGridView.Columns[49].Visible = true;
                    dgvGridView.Columns[50].Visible = true;
                    dgvGridView.Columns[51].Visible = true;

                    dgvGridView.Columns[77].Visible = true;
                    dgvGridView.Columns[78].Visible = true;
                    dgvGridView.Columns[79].Visible = true;
                    dgvGridView.Columns[80].Visible = true;
                    dgvGridView.Columns[81].Visible = true;
                    dgvGridView.Columns[82].Visible = true;
                    dgvGridView.Columns[83].Visible = true;
                    dgvGridView.Columns[84].Visible = true;
                }
                catch { }
                dgvGridView.Focus();
                SendKeys.Send("{END}");
                SendKeys.Flush();
            }
            else
            {
                try
                {
                    dgvGridView.Columns[48].Visible = false;
                    dgvGridView.Columns[49].Visible = false;
                    dgvGridView.Columns[50].Visible = false;
                    dgvGridView.Columns[51].Visible = false;

                    dgvGridView.Columns[77].Visible = false;
                    dgvGridView.Columns[78].Visible = false;
                    dgvGridView.Columns[79].Visible = false;
                    dgvGridView.Columns[80].Visible = false;
                    dgvGridView.Columns[81].Visible = false;
                    dgvGridView.Columns[82].Visible = false;
                    dgvGridView.Columns[83].Visible = false;
                    dgvGridView.Columns[84].Visible = false;
                }
                catch { }
                dgvGridView.Focus();
                SendKeys.Send("{END}");
                SendKeys.Flush();
            }
        }

        private void dgvGridView_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {

                SendKeys.Send("{UP}");

                SendKeys.Flush();

                try
                {
                    MmsWin.Front.Utilerias.Fotos.numPrv = this.dgvGridView.CurrentRow.Cells[5].Value.ToString();
                    MmsWin.Front.Utilerias.Fotos.numSty = this.dgvGridView.CurrentRow.Cells[7].Value.ToString();

                    MmsWin.Front.Utilerias.VarTem.tmpPrv = this.dgvGridView.CurrentRow.Cells[5].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpNom = this.dgvGridView.CurrentRow.Cells[6].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpSty = this.dgvGridView.CurrentRow.Cells[7].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpDes = this.dgvGridView.CurrentRow.Cells[8].Value.ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpCompDesc = this.dgvGridView.CurrentRow.Cells[9].Value.ToString();

                    MmsWin.Front.Utilerias.VarTem.tmpFchRev = this.dgvGridView.CurrentRow.Cells[11].Value.ToString();

                    Kardex();
                }
                catch { }
            }
        }
        
        private void Kardex()
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Kardex").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del Kardex ya esta abierta");
                    }
                    else
                    {
                        Kardex i = new Kardex();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void btRecalculo_Click(object sender, EventArgs e)
        {
            string message = "Esta seguro de recalcular esta fecha?";
            string caption = "Confirmación";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                string ParFchBon = tbDesde.Text;
                ParFchBon = ParFchBon.Substring(8, 2) + ParFchBon.Substring(3, 2) + ParFchBon.Substring(0, 2);
                //MmsWin.Negocio.RebajaDiferenciada.RebajaDiferenciada.GetInstance().EjecutaRecalculo(ParFchBon);
                Carga = true;
                BindBonifica();
            }
        }

        private void mcC1_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbDesde.Text = mcC1.SelectionEnd.ToShortDateString();
            FechaCal = tbDesde.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchDeN = long.Parse(FechaFmt.ToString());
            FchDe = FechaFmt.ToString();

            mcC1.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbDesde.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    BindBonifica(); ;
                }
            }
        }

        private void mcC1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcC1.Visible = false;
            }
        }

        private void mcC1_Leave(object sender, EventArgs e)
        {
            mcC1.Visible = false;
        }

        private void mcC2_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbHasta.Text = mcC2.SelectionEnd.ToShortDateString();
            FechaCal = tbHasta.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchHasN = long.Parse(FechaFmt.ToString());
            FchHas = FechaFmt.ToString();

            mcC2.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbHasta.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    BindBonifica();
                }
            }
        }

        private void mcC2_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcC2.Visible = false;
            }
        }

        private void mcC2_Leave(object sender, EventArgs e)
        {
            mcC2.Visible = false;
        }

        private void tbDesde_Click(object sender, EventArgs e)
        {
            mcC1.Visible = true;
            mcC1.Focus();
        }

        private void tbHasta_Click(object sender, EventArgs e)
        {
            mcC2.Visible = true;
            mcC2.Focus();
        }

        private void tbProveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbDesde.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindBonifica();
                tbProveedor.Focus();
            }
        }

        private void tbNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbDesde.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindBonifica();
                tbNombre.Focus();
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbDesde.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindBonifica();
                tbEstilo.Focus();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbDesde.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindBonifica();
                tbDescripcion.Focus();
            }
        }

        private void dgvGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvGridView.Select();
            dgvGridView.Focus();
            Kardex();
        }

        private void dgvGridView_CellParsing_1(object sender, DataGridViewCellParsingEventArgs e)
        {

            Row = e.RowIndex;
            Col = e.ColumnIndex;
            double subTotal = 0;
            double porcentaje = 0;
            this.dgvGridView.Rows[Row].Cells[Col].Style.BackColor = Color.Orange;
            string validaContraloria = this.dgvGridView.CurrentRow.Cells[46].Value.ToString();
            if (validaContraloria == "1" && this.dgvGridView.Columns[e.ColumnIndex].Name != "CONTRALORIA")
            {
                MessageBox.Show("No esta permitido actualizar o modificar");
            }

            if (this.dgvGridView.Columns[e.ColumnIndex].Name == "RBDSUB")
            {
                if (e != null)
                {
                    if (e.Value != null)
                    {
                        subTotal = Convert.ToDouble(e.Value);
                        RecalculoTotal(Row, Col, subTotal);
                        porcentaje = Convert.ToDouble(dgvGridView.Rows[Row].Cells[22].Value);
                        RecalculoBonificacion(Row, Col, porcentaje, subTotal);
                    }
                }
            }

            if (this.dgvGridView.Columns[e.ColumnIndex].Name == "RBDPBO")
            {
                if (e != null)
                {
                    if (e.Value != null)
                    {
                        porcentaje = Convert.ToDouble(e.Value);
                        RecalculoBonificacion(Row, Col, porcentaje, 0);
                    }
                    
                    
                }
            }

            if (this.dgvGridView.Columns[e.ColumnIndex].Name == "RBDCST2")
            {
                if (e != null)
                {
                    if (e.Value != null)
                    {
                        double CostosFinal = Convert.ToDouble(e.Value);
                        double precioFinal = Convert.ToDouble(dgvGridView.Rows[Row].Cells[30].Value);
                        RecalculoCostoFinal(Row, Col, CostosFinal, precioFinal);
                    }
                }
            }
            if (this.dgvGridView.Columns[e.ColumnIndex].Name == "RBDPRC2")
            {
                if (e != null)
                {
                    if (e.Value != null)
                    {
                        double CostosFinal = Convert.ToDouble(dgvGridView.Rows[Row].Cells[29].Value);
                        double precioFinal = Convert.ToDouble(e.Value);
                        RecalculoCostoFinal(Row, Col, CostosFinal, precioFinal);
                    }
                }
            }
        }

        private void dgvGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                MmsWin.Front.Utilerias.Fotos.numPrv  = this.dgvGridView.CurrentRow.Cells[5].Value.ToString();
                MmsWin.Front.Utilerias.Fotos.numSty  = this.dgvGridView.CurrentRow.Cells[7].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpPrv = this.dgvGridView.CurrentRow.Cells[5].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.tmpSty = this.dgvGridView.CurrentRow.Cells[7].Value.ToString();

                MmsWin.Front.Utilerias.VarTem.rbdFchBon    = this.dgvGridView.CurrentRow.Cells[0].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.rbdTipoCal   = this.dgvGridView.CurrentRow.Cells[1].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.rbdTemporada = this.dgvGridView.CurrentRow.Cells[2].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.rbdTienda    = this.dgvGridView.CurrentRow.Cells[3].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.rbdProveedor = this.dgvGridView.CurrentRow.Cells[5].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.rbdEstilo    = this.dgvGridView.CurrentRow.Cells[7].Value.ToString();
                MmsWin.Front.Utilerias.VarTem.rbdFchRev    = this.dgvGridView.CurrentRow.Cells[11].Value.ToString();


                //if (this.dgvGridView.CurrentRow.Cells[18].Value.ToString() != "Mas de 1")
                //{
                MmsWin.Front.Utilerias.VarTem.rbdNota = this.dgvGridView.CurrentRow.Cells[18].Value.ToString();
                //}
            }
            catch { }
        }

        private void TSMImoverFecha_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "MoverFechas").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del proceso de Envio de Correo esta abierta");
                    }
                    else
                    {
                        string MoverFecha = string.Empty;

                        System.Data.DataTable dtMoverFecha = new System.Data.DataTable("MoverFechas");

                        dtMoverFecha.Columns.Add("FechaBon", typeof(String));
                        dtMoverFecha.Columns.Add("FechaRev", typeof(String));
                        dtMoverFecha.Columns.Add("Proveedor", typeof(String));
                        dtMoverFecha.Columns.Add("Estilo", typeof(String));

                        DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
                        foreach (DataGridViewRow item in Seleccionados)
                        {
                            DataRow workRow = dtMoverFecha.NewRow();
                            workRow["FechaBon"] = item.Cells[0].Value.ToString();
                            workRow["FechaRev"] = item.Cells[11].Value.ToString();
                            workRow["Proveedor"] = item.Cells[5].Value.ToString();
                            workRow["Estilo"] = item.Cells[7].Value.ToString();

                            dtMoverFecha.Rows.Add(workRow);
                        }

                        MmsWin.Front.Utilerias.VarTem.BkFechaAmover = dtMoverFecha;

                        if (dtMoverFecha.Rows.Count > 0)
                        {
                            MtdoMoverFecha();
                        }
                        else 
                        {
                            MessageBox.Show("Debe seleccionar los estilos a mover...");
                        }
                    }
                }
            }
            catch { }
            finally { }
        }

        private void MtdoMoverFecha()
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "MoverFecha").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana de Mover Fecha ya esta abierta");
                    }
                    else
                    {
                    }
                }
            }
            catch { }
            finally { }
        }

        private void RecalculoTotal(int Row, int Col, double subTotal)
        {
            try
            {
                this.dgvGridView.Rows[Row].Cells[19].Style.BackColor = Color.Orange;
                this.dgvGridView.Rows[Row].Cells[20].Style.BackColor = Color.Orange;
                this.dgvGridView.Rows[Row].Cells[21].Style.BackColor = Color.Orange;

                double iva = subTotal * .16;
                dgvGridView.Rows[Row].Cells[20].Value = Convert.ToString(iva);
                dgvGridView.Rows[Row].Cells[21].Value = Convert.ToString(iva + subTotal);
            }
            catch
            {
                MessageBox.Show("Cantidad incorrecta...");
            }
        }

        private void RecalculoBonificacion(int Row, int Col, double porcentaje, double subTotal)
        {
            if (Convert.ToDouble(porcentaje) > 0)
            {
                try
                {
                    if (subTotal == 0)
                    {
                        subTotal = Convert.ToDouble(dgvGridView.Rows[Row].Cells[15].Value);
                    }
                    this.dgvGridView.Rows[Row].Cells[22].Style.BackColor = Color.Orange;
                    this.dgvGridView.Rows[Row].Cells[26].Style.BackColor = Color.Orange;
                    this.dgvGridView.Rows[Row].Cells[27].Style.BackColor = Color.Orange;
                    this.dgvGridView.Rows[Row].Cells[28].Style.BackColor = Color.Orange;

                    string ParPrv = dgvGridView.Rows[Row].Cells[5].Value.ToString();
                    string ParSty = dgvGridView.Rows[Row].Cells[7].Value.ToString();

                    double por = porcentaje;
                    System.Data.DataTable tbPrcCst = null;
                    double costoActual = 0;
                    double precioActual = 0;
                    double prcSinIva = 0;
                    double cstEntrePrcSinIva = 0;

                    double DifCostoFinal = 0;
                    double ImpOHCostoFinal = 0;
                    double ImpMargenFinal = 0;

                    // Recupera Precio y Costos
                    tbPrcCst = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenPrcCst(ParPrv, ParSty);
                    try
                    {
                        if (tbPrcCst.Rows.Count > 0)
                        {
                            foreach (DataRow row in tbPrcCst.Rows)
                            {
                                costoActual = Convert.ToDouble(row["CST"].ToString());
                                precioActual = Convert.ToDouble(row["PRC"].ToString());
                                this.dgvGridView.Rows[Row].Cells[23].Value = costoActual;
                                this.dgvGridView.Rows[Row].Cells[23].Style.BackColor = Color.Orange;
                                this.dgvGridView.Rows[Row].Cells[24].Value = precioActual;
                                this.dgvGridView.Rows[Row].Cells[24].Style.BackColor = Color.Orange;
                                prcSinIva = precioActual / 1.16;
                                cstEntrePrcSinIva = costoActual / prcSinIva;
                                this.dgvGridView.Rows[Row].Cells[25].Value = Convert.ToString((1 - cstEntrePrcSinIva) * 100);  // Margen Nuevo
                                this.dgvGridView.Rows[Row].Cells[25].Style.BackColor = Color.Orange;
                            }
                        }
                    }
                    catch { }

                    costoActual = Convert.ToDouble(dgvGridView.Rows[Row].Cells[23].Value);
                    precioActual = Convert.ToDouble(dgvGridView.Rows[Row].Cells[24].Value);
                    double costoNuevo = (1 - por) * costoActual;
                    double precioNuevo = precioActual;

                    string tablaAccion = dgvGridView.Rows[Row].Cells[17].Value.ToString();
                    // if (tablaAccion != "07")
                    // {
                    // Costo Nuevo y Precio nuevo                                                                          
                    this.dgvGridView.Rows[Row].Cells[26].Value = Convert.ToString(costoNuevo);

                    decimal  Wprc;
                    decimal Wprc2;
                    decimal cantidad = (decimal)( precioNuevo - (precioNuevo * por));
                    if (cantidad <= 20)
                    {
                        //  .99
                    }
                    else if (cantidad <= 50)
                    {
                        Wprc = cantidad / 5;
                        Wprc2 = Math.Truncate(Wprc);
                        cantidad = (decimal)((Wprc2 * 5) + (decimal)4.99);
                    }
                    else if (cantidad > 50)
                    {
                        Wprc = cantidad / 10;
                        Wprc2 = Math.Truncate(Wprc);
                        cantidad = (Wprc2 * 10) + (decimal)9.99;
                    }
                    precioNuevo = (double)cantidad;
                    // }

                    this.dgvGridView.Rows[Row].Cells[27].Value = Convert.ToString(precioNuevo);

                    prcSinIva = precioNuevo / 1.16;
                    cstEntrePrcSinIva = costoNuevo / prcSinIva;
                    this.dgvGridView.Rows[Row].Cells[28].Value = Convert.ToString((1 - cstEntrePrcSinIva) * 100);  // Margen Nuevo

                    // Costo Final y Precio final     
                    transito = string.Empty;
                    onHand = string.Empty;
                    double OnHandTransito = Convert.ToInt32(MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenOnHandTransito1(ParPrv, ParSty, out onHand, out transito));
                    this.dgvGridView.Rows[Row].Cells[35].Value = OnHandTransito;
                    this.dgvGridView.Rows[Row].Cells[35].Style.BackColor = Color.Orange;
                    double diferenciaCosto1 = costoActual - costoNuevo;
                    this.dgvGridView.Rows[Row].Cells[34].Value = diferenciaCosto1;
                    this.dgvGridView.Rows[Row].Cells[34].Style.BackColor = Color.Orange;
                    double OnHandActualXdiferenciaCosto = OnHandTransito * diferenciaCosto1;
                    this.dgvGridView.Rows[Row].Cells[36].Value = OnHandActualXdiferenciaCosto;
                    this.dgvGridView.Rows[Row].Cells[36].Style.BackColor = Color.Orange;
                    double importeNota = Convert.ToDouble(dgvGridView.Rows[Row].Cells[19].Value.ToString());
                    double difNotaOnHand = importeNota - OnHandActualXdiferenciaCosto;
                    if (difNotaOnHand < 0)
                    {
                        difNotaOnHand = difNotaOnHand * -1;
                    }
                    double costoXpieza = difNotaOnHand / OnHandTransito;
                    costoXpieza = Math.Truncate(costoXpieza * 10000) / 10000;

                    double costoFinal;

                    if ((importeNota - OnHandActualXdiferenciaCosto) < 0)
                    {
                        costoFinal = costoNuevo + costoXpieza;
                    }
                    else
                    {
                        costoFinal = costoNuevo - costoXpieza;
                    }
                    // Si el costo es menor a cero debe ser 0.01                                                           
                    string tablaDeAccion = Convert.ToString(this.dgvGridView.Rows[Row].Cells[17].Value.ToString());
                    if (costoFinal < 0 && tablaAccion == "01")
                    {
                        costoFinal = 0.01;
                    }

                    if (tablaAccion == "07")
                    {
                        this.dgvGridView.Rows[Row].Cells[41].Value = "07";
                        this.dgvGridView.Rows[Row].Cells[41].Style.BackColor = Color.Orange;
                    }

                    this.dgvGridView.Rows[Row].Cells[29].Value = costoFinal;
                    this.dgvGridView.Rows[Row].Cells[29].Style.BackColor = Color.Orange;
                    this.dgvGridView.Rows[Row].Cells[30].Value = precioNuevo;
                    this.dgvGridView.Rows[Row].Cells[30].Style.BackColor = Color.Orange;

                    double precioFinal = Convert.ToDouble(dgvGridView.Rows[Row].Cells[30].Value);
                    prcSinIva = precioFinal / 1.16;
                    cstEntrePrcSinIva = costoFinal / prcSinIva;
                    this.dgvGridView.Rows[Row].Cells[31].Value = Convert.ToString((1 - cstEntrePrcSinIva) * 100);
                    this.dgvGridView.Rows[Row].Cells[31].Style.BackColor = Color.Orange;

                    DifCostoFinal = costoActual - costoFinal;
                    DifCostoFinal = Math.Truncate(DifCostoFinal * 10000) / 10000;
                    ImpOHCostoFinal = DifCostoFinal * OnHandTransito;
                    ImpOHCostoFinal = Math.Truncate(ImpOHCostoFinal * 10000) / 10000;
                    ImpMargenFinal = subTotal - ImpOHCostoFinal;

                    this.dgvGridView.Rows[Row].Cells[38].Value = Convert.ToString(DifCostoFinal);
                    this.dgvGridView.Rows[Row].Cells[38].Style.BackColor = Color.Orange;
                    this.dgvGridView.Rows[Row].Cells[39].Value = Convert.ToString(ImpOHCostoFinal);
                    this.dgvGridView.Rows[Row].Cells[39].Style.BackColor = Color.Orange;
                    this.dgvGridView.Rows[Row].Cells[40].Value = Convert.ToString(ImpMargenFinal);
                    this.dgvGridView.Rows[Row].Cells[40].Style.BackColor = Color.Orange;
                }
                catch
                {
                    MessageBox.Show("Porcentaje incorrecto...");
                }

            }
            else
            {
                this.dgvGridView.Rows[Row].Cells[26].Value = this.dgvGridView.Rows[Row].Cells[19].Value;
                this.dgvGridView.Rows[Row].Cells[26].Style.BackColor = Color.Orange;
                this.dgvGridView.Rows[Row].Cells[27].Value = this.dgvGridView.Rows[Row].Cells[20].Value;
                this.dgvGridView.Rows[Row].Cells[27].Style.BackColor = Color.Orange;
                this.dgvGridView.Rows[Row].Cells[28].Value = this.dgvGridView.Rows[Row].Cells[21].Value;
                this.dgvGridView.Rows[Row].Cells[28].Style.BackColor = Color.Orange;
                this.dgvGridView.Rows[Row].Cells[29].Value = this.dgvGridView.Rows[Row].Cells[19].Value;
                this.dgvGridView.Rows[Row].Cells[29].Style.BackColor = Color.Orange;
                this.dgvGridView.Rows[Row].Cells[30].Value = this.dgvGridView.Rows[Row].Cells[20].Value;
                this.dgvGridView.Rows[Row].Cells[30].Style.BackColor = Color.Orange;
                this.dgvGridView.Rows[Row].Cells[31].Value = this.dgvGridView.Rows[Row].Cells[21].Value;
                this.dgvGridView.Rows[Row].Cells[31].Style.BackColor = Color.Orange;

                this.dgvGridView.Rows[Row].Cells[33].Value = this.dgvGridView.Rows[Row].Cells[13].Value;
                this.dgvGridView.Rows[Row].Cells[33].Style.BackColor = Color.Orange;
                //this.dgvGridView.Rows[Row].Cells[37].Value = this.dgvGridView.Rows[Row].Cells[13].Value; //Tabla de Accion
                //this.dgvGridView.Rows[Row].Cells[37].Style.BackColor = Color.Orange;                           //Tabla de Accion 

                this.dgvGridView.Rows[Row].Cells[34].Value = 0;
                this.dgvGridView.Rows[Row].Cells[34].Style.BackColor = Color.Orange;
                this.dgvGridView.Rows[Row].Cells[35].Value = 0;
                this.dgvGridView.Rows[Row].Cells[35].Style.BackColor = Color.Orange;
                this.dgvGridView.Rows[Row].Cells[36].Value = 0;
                this.dgvGridView.Rows[Row].Cells[36].Style.BackColor = Color.Orange;
                this.dgvGridView.Rows[Row].Cells[37].Value = 0;
                this.dgvGridView.Rows[Row].Cells[37].Style.BackColor = Color.Orange;
                this.dgvGridView.Rows[Row].Cells[38].Value = 0;
                this.dgvGridView.Rows[Row].Cells[38].Style.BackColor = Color.Orange;
                this.dgvGridView.Rows[Row].Cells[39].Value = 0;
                this.dgvGridView.Rows[Row].Cells[39].Style.BackColor = Color.Orange;
                this.dgvGridView.Rows[Row].Cells[40].Value = 0;
                this.dgvGridView.Rows[Row].Cells[40].Style.BackColor = Color.Orange;
            }
        }

        private void dgvGridView_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                dgvGridView.Select();
                dgvGridView.Focus();
                string validaContraloria = this.dgvGridView.CurrentRow.Cells[46].Value.ToString();
                string bandera;
                if (validaContraloria == "0")
                {
                    bandera = "1";
                }
                else
                {
                    bandera = "0";
                }
                string Controles = "eliminarTSM1";
                string ValHab = bandera;
                string ValVis = bandera;
                string tipo = "Menu";
                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
                Controles = "ActualizarTSMI";
                ValHab = bandera;
                ValVis = bandera;
                tipo = "Menu";
                AplicaSeguridad(Controles, ValHab, ValVis, tipo);

                    validaContraloria =  this.dgvGridView.CurrentRow.Cells[46].Value.ToString();
                if (validaContraloria == "1")
                {
                    this.dgvGridView.CurrentRow.Cells[17].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[18].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[19].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[20].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[21].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[22].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[23].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[24].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[25].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[26].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[27].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[28].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[29].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[30].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[31].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[32].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[33].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[34].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[35].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[36].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[37].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[38].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[39].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[40].ReadOnly = true;
                    this.dgvGridView.CurrentRow.Cells[41].ReadOnly = true;

                }
                else
                {
                    this.dgvGridView.CurrentRow.Cells[17].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[18].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[19].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[20].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[21].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[22].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[23].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[24].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[25].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[26].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[27].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[28].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[29].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[30].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[31].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[32].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[33].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[34].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[35].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[36].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[37].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[38].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[39].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[40].ReadOnly = false;
                    this.dgvGridView.CurrentRow.Cells[41].ReadOnly = false;
                }
            }
            catch { }
        }

        private void dgvGridView_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            try
            { }
            catch { }
        }

        private void RecalculoCostoFinal(int Row, int Col, double costoFinal, double precioFinal)
        {
            double DifCostoFinal = 0;
            double ImpOHCostoFinal = 0;
            double ImpMargenFinal = 0;
            double subTotal = 0;
            double costoActual = 0;

            this.dgvGridView.Rows[Row].Cells[29].Style.BackColor = Color.Orange;
            this.dgvGridView.Rows[Row].Cells[30].Style.BackColor = Color.Orange;

            string ParPrv = dgvGridView.Rows[Row].Cells[5].Value.ToString();
            string ParSty = dgvGridView.Rows[Row].Cells[7].Value.ToString();

            // Costo Final y Precio final     
            transito = string.Empty;
            onHand   = string.Empty;
            Int32 OnHandTransito = Convert.ToInt32(MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenOnHandTransito1(ParPrv, ParSty, out onHand, out transito));
            this.dgvGridView.Rows[Row].Cells[35].Value = OnHandTransito;
            this.dgvGridView.Rows[Row].Cells[35].Style.BackColor = Color.Orange;

                   subTotal    = Convert.ToDouble(dgvGridView.Rows[Row].Cells[19].Value);
                   costoActual = Convert.ToDouble(dgvGridView.Rows[Row].Cells[23].Value);
            double costoNuevo  = Convert.ToDouble(dgvGridView.Rows[Row].Cells[26].Value);

            double diferenciaCosto1 = costoActual - costoNuevo;
            this.dgvGridView.Rows[Row].Cells[34].Value = diferenciaCosto1;
            this.dgvGridView.Rows[Row].Cells[34].Style.BackColor = Color.Orange;
            double OnHandActualXdiferenciaCosto = OnHandTransito * diferenciaCosto1;
            this.dgvGridView.Rows[Row].Cells[36].Value = OnHandActualXdiferenciaCosto;
            this.dgvGridView.Rows[Row].Cells[36].Style.BackColor = Color.Orange;

            //double precioFinal = Convert.ToDouble(dgvGridView.Rows[Row].Cells[26].Value);
            double prcSinIva = precioFinal / 1.16;
            double cstEntrePrcSinIva = costoFinal / prcSinIva;
            this.dgvGridView.Rows[Row].Cells[31].Value = Convert.ToString((1 - cstEntrePrcSinIva) * 100);
            this.dgvGridView.Rows[Row].Cells[31].Style.BackColor = Color.Orange;

            DifCostoFinal = costoActual - costoFinal;
            DifCostoFinal = Math.Truncate(DifCostoFinal * 10000) / 10000;
            ImpOHCostoFinal = DifCostoFinal * OnHandTransito;
            ImpOHCostoFinal = Math.Truncate(ImpOHCostoFinal * 10000) / 10000;
            ImpMargenFinal = subTotal - ImpOHCostoFinal;

            this.dgvGridView.Rows[Row].Cells[38].Value = Convert.ToString(DifCostoFinal);
            this.dgvGridView.Rows[Row].Cells[38].Style.BackColor = Color.Orange;
            this.dgvGridView.Rows[Row].Cells[39].Value = Convert.ToString(ImpOHCostoFinal);
            this.dgvGridView.Rows[Row].Cells[39].Style.BackColor = Color.Orange;
            this.dgvGridView.Rows[Row].Cells[40].Value = Convert.ToString(ImpMargenFinal);
            this.dgvGridView.Rows[Row].Cells[40].Style.BackColor = Color.Orange;
        }
    }
}
