﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class ValidacionDiferenciado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.cmMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.fotoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rebajaDiferenciadaTlSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.btExcel = new System.Windows.Forms.Button();
            this.pgbProg = new System.Windows.Forms.ProgressBar();
            this.lbCSTORI = new System.Windows.Forms.Label();
            this.lbCSTORIDAT = new System.Windows.Forms.Label();
            this.lbCSTACTDAT = new System.Windows.Forms.Label();
            this.lbCostoActual = new System.Windows.Forms.Label();
            this.lbPRCACTDAT = new System.Windows.Forms.Label();
            this.lbPrecioActual = new System.Windows.Forms.Label();
            this.lbPRCORIDAT = new System.Windows.Forms.Label();
            this.lbPRCORI = new System.Windows.Forms.Label();
            this.pnlCostos = new System.Windows.Forms.Panel();
            this.pnlPrecios = new System.Windows.Forms.Panel();
            this.pnlLargo = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.cmMenuStrip.SuspendLayout();
            this.pnlCostos.SuspendLayout();
            this.pnlPrecios.SuspendLayout();
            this.pnlLargo.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.ContextMenuStrip = this.cmMenuStrip;
            this.dgvGridView.Location = new System.Drawing.Point(9, 46);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.Size = new System.Drawing.Size(675, 435);
            this.dgvGridView.TabIndex = 0;
            this.dgvGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellClick);
            this.dgvGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellDoubleClick);
            this.dgvGridView.CellParsing += new System.Windows.Forms.DataGridViewCellParsingEventHandler(this.dgvGridView_CellParsing);
            this.dgvGridView.SelectionChanged += new System.EventHandler(this.dgvGridView_SelectionChanged);
            this.dgvGridView.Sorted += new System.EventHandler(this.dgvGridView_Sorted);
            this.dgvGridView.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dgvGridView_KeyPress);
            this.dgvGridView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvGridView_KeyUp);
            // 
            // cmMenuStrip
            // 
            this.cmMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fotoToolStripMenuItem,
            this.rebajaDiferenciadaTlSMI});
            this.cmMenuStrip.Name = "cmMenuStrip";
            this.cmMenuStrip.Size = new System.Drawing.Size(179, 48);
            // 
            // fotoToolStripMenuItem
            // 
            this.fotoToolStripMenuItem.Name = "fotoToolStripMenuItem";
            this.fotoToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.fotoToolStripMenuItem.Text = "Foto";
            this.fotoToolStripMenuItem.Click += new System.EventHandler(this.fotoToolStripMenuItem_Click);
            // 
            // rebajaDiferenciadaTlSMI
            // 
            this.rebajaDiferenciadaTlSMI.Name = "rebajaDiferenciadaTlSMI";
            this.rebajaDiferenciadaTlSMI.Size = new System.Drawing.Size(178, 22);
            this.rebajaDiferenciadaTlSMI.Text = "Rebaja Diferenciada";
            this.rebajaDiferenciadaTlSMI.Click += new System.EventHandler(this.rebajaDiferenciadaTlSMI_Click);
            // 
            // btExcel
            // 
            this.btExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btExcel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btExcel.Image = global::MmsWin.Front.Properties.Resources.Microsoft_Excel_24px;
            this.btExcel.Location = new System.Drawing.Point(566, 8);
            this.btExcel.Name = "btExcel";
            this.btExcel.Size = new System.Drawing.Size(117, 31);
            this.btExcel.TabIndex = 54;
            this.btExcel.Text = "Exportar a Excel";
            this.btExcel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btExcel.UseVisualStyleBackColor = false;
            this.btExcel.Click += new System.EventHandler(this.btExcel_Click);
            // 
            // pgbProg
            // 
            this.pgbProg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pgbProg.Location = new System.Drawing.Point(11, 470);
            this.pgbProg.Name = "pgbProg";
            this.pgbProg.Size = new System.Drawing.Size(671, 10);
            this.pgbProg.TabIndex = 55;
            this.pgbProg.Visible = false;
            // 
            // lbCSTORI
            // 
            this.lbCSTORI.AutoSize = true;
            this.lbCSTORI.BackColor = System.Drawing.Color.SteelBlue;
            this.lbCSTORI.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCSTORI.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbCSTORI.Location = new System.Drawing.Point(9, 3);
            this.lbCSTORI.Name = "lbCSTORI";
            this.lbCSTORI.Size = new System.Drawing.Size(55, 13);
            this.lbCSTORI.TabIndex = 56;
            this.lbCSTORI.Text = "CST Ori.";
            // 
            // lbCSTORIDAT
            // 
            this.lbCSTORIDAT.AutoSize = true;
            this.lbCSTORIDAT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbCSTORIDAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCSTORIDAT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbCSTORIDAT.Location = new System.Drawing.Point(16, 20);
            this.lbCSTORIDAT.Name = "lbCSTORIDAT";
            this.lbCSTORIDAT.Size = new System.Drawing.Size(43, 16);
            this.lbCSTORIDAT.TabIndex = 57;
            this.lbCSTORIDAT.Text = "xxxxx";
            // 
            // lbCSTACTDAT
            // 
            this.lbCSTACTDAT.AutoSize = true;
            this.lbCSTACTDAT.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbCSTACTDAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCSTACTDAT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbCSTACTDAT.Location = new System.Drawing.Point(82, 20);
            this.lbCSTACTDAT.Name = "lbCSTACTDAT";
            this.lbCSTACTDAT.Size = new System.Drawing.Size(43, 16);
            this.lbCSTACTDAT.TabIndex = 59;
            this.lbCSTACTDAT.Text = "xxxxx";
            // 
            // lbCostoActual
            // 
            this.lbCostoActual.AutoSize = true;
            this.lbCostoActual.BackColor = System.Drawing.Color.SteelBlue;
            this.lbCostoActual.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCostoActual.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbCostoActual.Location = new System.Drawing.Point(87, 3);
            this.lbCostoActual.Name = "lbCostoActual";
            this.lbCostoActual.Size = new System.Drawing.Size(58, 13);
            this.lbCostoActual.TabIndex = 58;
            this.lbCostoActual.Text = "CST Act.";
            // 
            // lbPRCACTDAT
            // 
            this.lbPRCACTDAT.AutoSize = true;
            this.lbPRCACTDAT.BackColor = System.Drawing.Color.Silver;
            this.lbPRCACTDAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPRCACTDAT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbPRCACTDAT.Location = new System.Drawing.Point(93, 20);
            this.lbPRCACTDAT.Name = "lbPRCACTDAT";
            this.lbPRCACTDAT.Size = new System.Drawing.Size(43, 16);
            this.lbPRCACTDAT.TabIndex = 63;
            this.lbPRCACTDAT.Text = "xxxxx";
            // 
            // lbPrecioActual
            // 
            this.lbPrecioActual.AutoSize = true;
            this.lbPrecioActual.BackColor = System.Drawing.Color.SteelBlue;
            this.lbPrecioActual.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPrecioActual.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbPrecioActual.Location = new System.Drawing.Point(239, 3);
            this.lbPrecioActual.Name = "lbPrecioActual";
            this.lbPrecioActual.Size = new System.Drawing.Size(59, 13);
            this.lbPrecioActual.TabIndex = 62;
            this.lbPrecioActual.Text = "PRC Act.";
            // 
            // lbPRCORIDAT
            // 
            this.lbPRCORIDAT.AutoSize = true;
            this.lbPRCORIDAT.BackColor = System.Drawing.Color.Silver;
            this.lbPRCORIDAT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPRCORIDAT.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbPRCORIDAT.Location = new System.Drawing.Point(15, 20);
            this.lbPRCORIDAT.Name = "lbPRCORIDAT";
            this.lbPRCORIDAT.Size = new System.Drawing.Size(43, 16);
            this.lbPRCORIDAT.TabIndex = 61;
            this.lbPRCORIDAT.Text = "xxxxx";
            // 
            // lbPRCORI
            // 
            this.lbPRCORI.AutoSize = true;
            this.lbPRCORI.BackColor = System.Drawing.Color.SteelBlue;
            this.lbPRCORI.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPRCORI.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbPRCORI.Location = new System.Drawing.Point(166, 3);
            this.lbPRCORI.Name = "lbPRCORI";
            this.lbPRCORI.Size = new System.Drawing.Size(56, 13);
            this.lbPRCORI.TabIndex = 60;
            this.lbPRCORI.Text = "PRC Ori.";
            // 
            // pnlCostos
            // 
            this.pnlCostos.BackColor = System.Drawing.Color.Silver;
            this.pnlCostos.Controls.Add(this.lbPRCACTDAT);
            this.pnlCostos.Controls.Add(this.lbPRCORIDAT);
            this.pnlCostos.Location = new System.Drawing.Point(168, 4);
            this.pnlCostos.Name = "pnlCostos";
            this.pnlCostos.Size = new System.Drawing.Size(146, 37);
            this.pnlCostos.TabIndex = 64;
            // 
            // pnlPrecios
            // 
            this.pnlPrecios.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pnlPrecios.Controls.Add(this.lbCSTACTDAT);
            this.pnlPrecios.Controls.Add(this.lbCSTORIDAT);
            this.pnlPrecios.Location = new System.Drawing.Point(11, 4);
            this.pnlPrecios.Name = "pnlPrecios";
            this.pnlPrecios.Size = new System.Drawing.Size(157, 37);
            this.pnlPrecios.TabIndex = 65;
            // 
            // pnlLargo
            // 
            this.pnlLargo.BackColor = System.Drawing.Color.SteelBlue;
            this.pnlLargo.Controls.Add(this.lbPrecioActual);
            this.pnlLargo.Controls.Add(this.lbCSTORI);
            this.pnlLargo.Controls.Add(this.lbCostoActual);
            this.pnlLargo.Controls.Add(this.lbPRCORI);
            this.pnlLargo.Location = new System.Drawing.Point(12, 4);
            this.pnlLargo.Name = "pnlLargo";
            this.pnlLargo.Size = new System.Drawing.Size(301, 20);
            this.pnlLargo.TabIndex = 66;
            // 
            // ValidacionDiferenciado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(691, 485);
            this.Controls.Add(this.pnlLargo);
            this.Controls.Add(this.pgbProg);
            this.Controls.Add(this.btExcel);
            this.Controls.Add(this.dgvGridView);
            this.Controls.Add(this.pnlPrecios);
            this.Controls.Add(this.pnlCostos);
            this.DoubleBuffered = true;
            this.MinimizeBox = false;
            this.Name = "ValidacionDiferenciado";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Validación de Tiendas";
            this.Load += new System.EventHandler(this.ValidacionDiferenciado_Load);
            this.Resize += new System.EventHandler(this.ValidacionDiferenciado_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.cmMenuStrip.ResumeLayout(false);
            this.pnlCostos.ResumeLayout(false);
            this.pnlCostos.PerformLayout();
            this.pnlPrecios.ResumeLayout(false);
            this.pnlPrecios.PerformLayout();
            this.pnlLargo.ResumeLayout(false);
            this.pnlLargo.PerformLayout();
            this.ResumeLayout(false);

        }
        #endregion
        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.ContextMenuStrip cmMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem fotoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rebajaDiferenciadaTlSMI;
        private System.Windows.Forms.Button btExcel;
        private System.Windows.Forms.ProgressBar pgbProg;
        private System.Windows.Forms.Label lbCSTORI;
        private System.Windows.Forms.Label lbCSTORIDAT;
        private System.Windows.Forms.Label lbCSTACTDAT;
        private System.Windows.Forms.Label lbCostoActual;
        private System.Windows.Forms.Label lbPRCACTDAT;
        private System.Windows.Forms.Label lbPrecioActual;
        private System.Windows.Forms.Label lbPRCORIDAT;
        private System.Windows.Forms.Label lbPRCORI;
        private System.Windows.Forms.Panel pnlCostos;
        private System.Windows.Forms.Panel pnlPrecios;
        private System.Windows.Forms.Panel pnlLargo;
    }
}