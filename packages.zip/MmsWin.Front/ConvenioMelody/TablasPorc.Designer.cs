﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class TablasPorc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TablasPorc));
            this.panel01 = new System.Windows.Forms.Panel();
            this.btRelleno = new System.Windows.Forms.Button();
            this.btABC = new System.Windows.Forms.Button();
            this.tbTabla = new System.Windows.Forms.TextBox();
            this.tbMarca = new System.Windows.Forms.TextBox();
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ConsultarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.lbTitulo = new System.Windows.Forms.Label();
            this.pbSalir = new System.Windows.Forms.PictureBox();
            this.panel01.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.cmMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).BeginInit();
            this.SuspendLayout();
            // 
            // panel01
            // 
            this.panel01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel01.Controls.Add(this.btRelleno);
            this.panel01.Controls.Add(this.btABC);
            this.panel01.Controls.Add(this.tbTabla);
            this.panel01.Controls.Add(this.tbMarca);
            this.panel01.Controls.Add(this.dgvGridView);
            this.panel01.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel01.Location = new System.Drawing.Point(0, 40);
            this.panel01.Name = "panel01";
            this.panel01.Size = new System.Drawing.Size(607, 334);
            this.panel01.TabIndex = 11;
            // 
            // btRelleno
            // 
            this.btRelleno.Location = new System.Drawing.Point(11, 5);
            this.btRelleno.Name = "btRelleno";
            this.btRelleno.Size = new System.Drawing.Size(45, 22);
            this.btRelleno.TabIndex = 4;
            this.btRelleno.UseVisualStyleBackColor = true;
            // 
            // btABC
            // 
            this.btABC.ForeColor = System.Drawing.Color.Black;
            this.btABC.Location = new System.Drawing.Point(550, 4);
            this.btABC.Name = "btABC";
            this.btABC.Size = new System.Drawing.Size(48, 23);
            this.btABC.TabIndex = 3;
            this.btABC.Text = "Nuevo";
            this.btABC.UseVisualStyleBackColor = true;
            this.btABC.Click += new System.EventHandler(this.btABC_Click);
            // 
            // tbTabla
            // 
            this.tbTabla.Location = new System.Drawing.Point(113, 6);
            this.tbTabla.Name = "tbTabla";
            this.tbTabla.Size = new System.Drawing.Size(61, 20);
            this.tbTabla.TabIndex = 2;
            this.tbTabla.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTabla_KeyPress);
            // 
            // tbMarca
            // 
            this.tbMarca.Location = new System.Drawing.Point(55, 6);
            this.tbMarca.Name = "tbMarca";
            this.tbMarca.Size = new System.Drawing.Size(62, 20);
            this.tbMarca.TabIndex = 1;
            this.tbMarca.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbMarca_KeyPress);
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.ContextMenuStrip = this.cmMenu;
            this.dgvGridView.Location = new System.Drawing.Point(12, 27);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.ReadOnly = true;
            this.dgvGridView.Size = new System.Drawing.Size(585, 301);
            this.dgvGridView.TabIndex = 0;
            this.dgvGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellClick);
            this.dgvGridView.SelectionChanged += new System.EventHandler(this.dgvGridView_SelectionChanged);
            this.dgvGridView.DoubleClick += new System.EventHandler(this.dgvGridView_DoubleClick);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ConsultarTSMI});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(122, 26);
            // 
            // ConsultarTSMI
            // 
            this.ConsultarTSMI.Name = "ConsultarTSMI";
            this.ConsultarTSMI.Size = new System.Drawing.Size(121, 22);
            this.ConsultarTSMI.Text = "Consulta";
            this.ConsultarTSMI.Click += new System.EventHandler(this.ConsultarTSMI_Click);
            // 
            // lbTitulo
            // 
            this.lbTitulo.AutoSize = true;
            this.lbTitulo.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbTitulo.Location = new System.Drawing.Point(9, 7);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(282, 21);
            this.lbTitulo.TabIndex = 33;
            this.lbTitulo.Text = "Tablas de calificaciones por porcentaje";
            // 
            // pbSalir
            // 
            this.pbSalir.Image = ((System.Drawing.Image)(resources.GetObject("pbSalir.Image")));
            this.pbSalir.Location = new System.Drawing.Point(576, 7);
            this.pbSalir.Name = "pbSalir";
            this.pbSalir.Size = new System.Drawing.Size(22, 18);
            this.pbSalir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSalir.TabIndex = 35;
            this.pbSalir.TabStop = false;
            this.pbSalir.Click += new System.EventHandler(this.pbSalir_Click_1);
            // 
            // TablasPorc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(607, 374);
            this.Controls.Add(this.pbSalir);
            this.Controls.Add(this.lbTitulo);
            this.Controls.Add(this.panel01);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TablasPorc";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TablasPorc";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TablasPorc_FormClosing);
            this.Load += new System.EventHandler(this.TablasPorc_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.TablasPorc_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.TablasPorc_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.TablasPorc_MouseUp);
            this.panel01.ResumeLayout(false);
            this.panel01.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.cmMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel01;
        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.TextBox tbTabla;
        private System.Windows.Forms.TextBox tbMarca;
        private System.Windows.Forms.Label lbTitulo;
        private System.Windows.Forms.Button btABC;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem ConsultarTSMI;
        private System.Windows.Forms.Button btRelleno;
        private System.Windows.Forms.PictureBox pbSalir;
    }
}