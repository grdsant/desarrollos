﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class ConvenioMelodyABC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbLista = new System.Windows.Forms.TextBox();
            this.lbAnio = new System.Windows.Forms.Label();
            this.lbSemana = new System.Windows.Forms.Label();
            this.tbSemana = new System.Windows.Forms.TextBox();
            this.lbTipo = new System.Windows.Forms.Label();
            this.tbTipo = new System.Windows.Forms.TextBox();
            this.lbEstatus = new System.Windows.Forms.Label();
            this.tbEstatus = new System.Windows.Forms.TextBox();
            this.lbUsuario = new System.Windows.Forms.Label();
            this.tbUsuario = new System.Windows.Forms.TextBox();
            this.lbFecha = new System.Windows.Forms.Label();
            this.tbFecha = new System.Windows.Forms.TextBox();
            this.lbHora = new System.Windows.Forms.Label();
            this.tbHora = new System.Windows.Forms.TextBox();
            this.btTitulo = new System.Windows.Forms.Button();
            this.btEliminar = new System.Windows.Forms.Button();
            this.btActualizar = new System.Windows.Forms.Button();
            this.btAceptar = new System.Windows.Forms.Button();
            this.btCancelar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tbLista
            // 
            this.tbLista.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbLista.Location = new System.Drawing.Point(77, 41);
            this.tbLista.Name = "tbLista";
            this.tbLista.Size = new System.Drawing.Size(38, 20);
            this.tbLista.TabIndex = 0;
            this.tbLista.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tbLista_KeyUp);
            // 
            // lbAnio
            // 
            this.lbAnio.AutoSize = true;
            this.lbAnio.Location = new System.Drawing.Point(25, 48);
            this.lbAnio.Name = "lbAnio";
            this.lbAnio.Size = new System.Drawing.Size(26, 13);
            this.lbAnio.TabIndex = 1;
            this.lbAnio.Text = "Año";
            // 
            // lbSemana
            // 
            this.lbSemana.AutoSize = true;
            this.lbSemana.Location = new System.Drawing.Point(25, 76);
            this.lbSemana.Name = "lbSemana";
            this.lbSemana.Size = new System.Drawing.Size(46, 13);
            this.lbSemana.TabIndex = 3;
            this.lbSemana.Text = "Semana";
            // 
            // tbSemana
            // 
            this.tbSemana.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.tbSemana.Location = new System.Drawing.Point(77, 69);
            this.tbSemana.Name = "tbSemana";
            this.tbSemana.Size = new System.Drawing.Size(38, 20);
            this.tbSemana.TabIndex = 2;
            // 
            // lbTipo
            // 
            this.lbTipo.AutoSize = true;
            this.lbTipo.Location = new System.Drawing.Point(25, 104);
            this.lbTipo.Name = "lbTipo";
            this.lbTipo.Size = new System.Drawing.Size(28, 13);
            this.lbTipo.TabIndex = 5;
            this.lbTipo.Text = "Tipo";
            // 
            // tbTipo
            // 
            this.tbTipo.Location = new System.Drawing.Point(77, 97);
            this.tbTipo.Name = "tbTipo";
            this.tbTipo.Size = new System.Drawing.Size(38, 20);
            this.tbTipo.TabIndex = 4;
            // 
            // lbEstatus
            // 
            this.lbEstatus.AutoSize = true;
            this.lbEstatus.Location = new System.Drawing.Point(25, 132);
            this.lbEstatus.Name = "lbEstatus";
            this.lbEstatus.Size = new System.Drawing.Size(42, 13);
            this.lbEstatus.TabIndex = 7;
            this.lbEstatus.Text = "Estatus";
            // 
            // tbEstatus
            // 
            this.tbEstatus.Location = new System.Drawing.Point(77, 125);
            this.tbEstatus.Name = "tbEstatus";
            this.tbEstatus.Size = new System.Drawing.Size(38, 20);
            this.tbEstatus.TabIndex = 6;
            // 
            // lbUsuario
            // 
            this.lbUsuario.AutoSize = true;
            this.lbUsuario.Location = new System.Drawing.Point(25, 160);
            this.lbUsuario.Name = "lbUsuario";
            this.lbUsuario.Size = new System.Drawing.Size(43, 13);
            this.lbUsuario.TabIndex = 9;
            this.lbUsuario.Text = "Usuario";
            // 
            // tbUsuario
            // 
            this.tbUsuario.Enabled = false;
            this.tbUsuario.Location = new System.Drawing.Point(77, 153);
            this.tbUsuario.Name = "tbUsuario";
            this.tbUsuario.Size = new System.Drawing.Size(89, 20);
            this.tbUsuario.TabIndex = 8;
            // 
            // lbFecha
            // 
            this.lbFecha.AutoSize = true;
            this.lbFecha.Location = new System.Drawing.Point(25, 188);
            this.lbFecha.Name = "lbFecha";
            this.lbFecha.Size = new System.Drawing.Size(37, 13);
            this.lbFecha.TabIndex = 11;
            this.lbFecha.Text = "Fecha";
            // 
            // tbFecha
            // 
            this.tbFecha.Enabled = false;
            this.tbFecha.Location = new System.Drawing.Point(77, 181);
            this.tbFecha.Name = "tbFecha";
            this.tbFecha.Size = new System.Drawing.Size(89, 20);
            this.tbFecha.TabIndex = 10;
            this.tbFecha.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbHora
            // 
            this.lbHora.AutoSize = true;
            this.lbHora.Location = new System.Drawing.Point(25, 216);
            this.lbHora.Name = "lbHora";
            this.lbHora.Size = new System.Drawing.Size(30, 13);
            this.lbHora.TabIndex = 13;
            this.lbHora.Text = "Hora";
            // 
            // tbHora
            // 
            this.tbHora.Enabled = false;
            this.tbHora.Location = new System.Drawing.Point(77, 209);
            this.tbHora.Name = "tbHora";
            this.tbHora.Size = new System.Drawing.Size(89, 20);
            this.tbHora.TabIndex = 12;
            this.tbHora.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btTitulo
            // 
            this.btTitulo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.btTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTitulo.ForeColor = System.Drawing.Color.White;
            this.btTitulo.Location = new System.Drawing.Point(0, 0);
            this.btTitulo.Name = "btTitulo";
            this.btTitulo.Size = new System.Drawing.Size(347, 30);
            this.btTitulo.TabIndex = 16;
            this.btTitulo.Text = "Mantenimiento a Eventos";
            this.btTitulo.UseVisualStyleBackColor = false;
            // 
            // btEliminar
            // 
            this.btEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btEliminar.Location = new System.Drawing.Point(257, 248);
            this.btEliminar.Name = "btEliminar";
            this.btEliminar.Size = new System.Drawing.Size(61, 32);
            this.btEliminar.TabIndex = 18;
            this.btEliminar.Text = "Eliminar";
            this.btEliminar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btEliminar.UseVisualStyleBackColor = true;
            this.btEliminar.Click += new System.EventHandler(this.btEliminar_Click);
            // 
            // btActualizar
            // 
            this.btActualizar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btActualizar.Location = new System.Drawing.Point(179, 248);
            this.btActualizar.Name = "btActualizar";
            this.btActualizar.Size = new System.Drawing.Size(61, 32);
            this.btActualizar.TabIndex = 17;
            this.btActualizar.Text = "Actualizar";
            this.btActualizar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btActualizar.UseVisualStyleBackColor = true;
            this.btActualizar.Click += new System.EventHandler(this.btActualizar_Click);
            // 
            // btAceptar
            // 
            this.btAceptar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btAceptar.Location = new System.Drawing.Point(105, 248);
            this.btAceptar.Name = "btAceptar";
            this.btAceptar.Size = new System.Drawing.Size(61, 32);
            this.btAceptar.TabIndex = 15;
            this.btAceptar.Text = "Guardar";
            this.btAceptar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btAceptar.UseVisualStyleBackColor = true;
            this.btAceptar.Click += new System.EventHandler(this.btAceptar_Click);
            // 
            // btCancelar
            // 
            this.btCancelar.Location = new System.Drawing.Point(28, 248);
            this.btCancelar.Name = "btCancelar";
            this.btCancelar.Size = new System.Drawing.Size(61, 32);
            this.btCancelar.TabIndex = 14;
            this.btCancelar.Text = "Cancelar";
            this.btCancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btCancelar.UseVisualStyleBackColor = true;
            this.btCancelar.Click += new System.EventHandler(this.btCancelar_Click);
            // 
            // ConvenioMelodyABC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(347, 292);
            this.Controls.Add(this.btEliminar);
            this.Controls.Add(this.btActualizar);
            this.Controls.Add(this.btTitulo);
            this.Controls.Add(this.btAceptar);
            this.Controls.Add(this.btCancelar);
            this.Controls.Add(this.lbHora);
            this.Controls.Add(this.tbHora);
            this.Controls.Add(this.lbFecha);
            this.Controls.Add(this.tbFecha);
            this.Controls.Add(this.lbUsuario);
            this.Controls.Add(this.tbUsuario);
            this.Controls.Add(this.lbEstatus);
            this.Controls.Add(this.tbEstatus);
            this.Controls.Add(this.lbTipo);
            this.Controls.Add(this.tbTipo);
            this.Controls.Add(this.lbSemana);
            this.Controls.Add(this.tbSemana);
            this.Controls.Add(this.lbAnio);
            this.Controls.Add(this.tbLista);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ConvenioMelodyABC";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.ConvenioMelodyABC_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ConvenioMelodyABC_KeyUp);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbLista;
        private System.Windows.Forms.Label lbAnio;
        private System.Windows.Forms.Label lbSemana;
        private System.Windows.Forms.TextBox tbSemana;
        private System.Windows.Forms.Label lbTipo;
        private System.Windows.Forms.TextBox tbTipo;
        private System.Windows.Forms.Label lbEstatus;
        private System.Windows.Forms.TextBox tbEstatus;
        private System.Windows.Forms.Label lbUsuario;
        private System.Windows.Forms.TextBox tbUsuario;
        private System.Windows.Forms.Label lbFecha;
        private System.Windows.Forms.TextBox tbFecha;
        private System.Windows.Forms.Label lbHora;
        private System.Windows.Forms.TextBox tbHora;
        private System.Windows.Forms.Button btCancelar;
        private System.Windows.Forms.Button btAceptar;
        private System.Windows.Forms.Button btTitulo;
        private System.Windows.Forms.Button btActualizar;
        private System.Windows.Forms.Button btEliminar;
    }
}