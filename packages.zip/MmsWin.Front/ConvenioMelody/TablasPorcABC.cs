﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class TablasPorcABC : Form
    {
        #region Variables locales
        public static string marca        { get; set; }
        public static string tabla        { get; set; }
        public static string secuencia    { get; set; }
        public static string del          { get; set; }
        public static string al           { get; set; }
        public static string porcentaje   { get; set; }
        public static string calificacion { get; set; }
        public static string estatus      { get; set; }

        public static string userAlta    { get; set; }
        public static string fechaAlta   { get; set; }
        public static string horaAlta    { get; set; }
        public static string userCambio  { get; set; }
        public static string fechaCambio { get; set; }
        public static string horaCambio  { get; set; }
        #endregion

        Point mousedownpoint = Point.Empty;

        public TablasPorcABC()
        {
            InitializeComponent();
        }

        private void TablasPorcABC_Load(object sender, EventArgs e)
        {
            tbMarca.Text        = marca;
            tbTabla.Text        = tabla;
            tbSecuencia.Text    = secuencia;
            tbDelR.Text         = del;
            tbAlR.Text          = al;
            tbPorc.Text         = porcentaje;
            tbCalificacion.Text = calificacion;
            tbSts.Text          = estatus;

            tbUserAlta.Text  = userAlta;
            tbFechaAlta.Text = fechaAlta;
            tbHoraAlta.Text  = horaAlta;

            tbUserCambio.Text  = userCambio;
            tbFechaCambio.Text = fechaCambio;
            tbHoraCambio.Text  = horaCambio;
        }

        private void TablasPorcABC_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void TablasPorcABC_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedownpoint.IsEmpty)
                return;
            Form f = sender as Form;
            f.Location = new Point(f.Location.X + (e.X - mousedownpoint.X), f.Location.Y + (e.Y - mousedownpoint.Y));
        }

        private void TablasPorcABC_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btAlta_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            DateTime fecha   = Convert.ToDateTime(DateTime.Now.ToShortDateString());
            tbFechaAlta.Text = Convert.ToString(fecha.ToString("yyyy-MM-dd"));

            DateTime hora   = DateTime.Now;
            tbHoraAlta.Text = (hora.ToString("HH:mm:ss", CultureInfo.InvariantCulture));

            tbUserAlta.Text = MmsWin.Front.Utilerias.VarTem.tmpUser;

            string marca        = tbMarca.Text;
            string tabla        = tbTabla.Text;
            string secuencia    = tbSecuencia.Text;
            string delr         = tbDelR.Text;
            string alr          = tbAlR.Text;
            string porcentaje   = tbPorc.Text;
            string calificacion = tbCalificacion.Text;
            string estatus      = tbSts.Text;

            string fechaAlta    = tbFechaAlta.Text;
            string horaAlta     = tbHoraAlta.Text;
            string userAlta     = tbUserAlta.Text;

            string fechaCambio  = string.Empty;
            string horaCambio   = string.Empty;
            string userCambio   = string.Empty;

            string stMensaje    = string.Empty;

            stMensaje = validacion(marca, tabla, secuencia, delr, alr, porcentaje, calificacion, estatus);

            if (stMensaje == "Correcto")
            {
                string fchfmtAlta = string.Empty;
                string horfmtAlta = string.Empty;

                string fchfmtCambio = string.Empty;
                string horfmtCambio = string.Empty;

                try
                {
                    fchfmtAlta = fechaAlta.Substring(2, 2) + fechaAlta.Substring(5, 2) + fechaAlta.Substring(8, 2);
                    horfmtAlta = horaAlta.Substring(0, 2) + horaAlta.Substring(3, 2) + horaAlta.Substring(6, 2);
                }
                catch { };

                try
                {
                    fchfmtCambio = fechaCambio.Substring(2, 2) + fechaCambio.Substring(5, 2) + fechaCambio.Substring(8, 2);
                    horfmtCambio = horaCambio.Substring(0, 2) + horaCambio.Substring(3, 2) + horaCambio.Substring(6, 2);
                }
                catch { };
                stMensaje = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().InsertTablasporc(marca, tabla, secuencia, delr, alr, porcentaje, calificacion, estatus, userAlta, fchfmtAlta, horfmtAlta, userCambio, fchfmtCambio, horfmtCambio);
                MessageBox.Show(stMensaje);
                if (stMensaje == "Se guardo el registro exitosamente...")
                {
                    this.Close();
                }
            }

        }

        private void btCambio_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            DateTime fecha     = Convert.ToDateTime(DateTime.Now.ToShortDateString());
            tbFechaCambio.Text = Convert.ToString(fecha.ToString("yyyy-MM-dd"));

            DateTime hora     = DateTime.Now;
            tbHoraCambio.Text = (hora.ToString("HH:mm:ss", CultureInfo.InvariantCulture));

            tbUserCambio.Text = MmsWin.Front.Utilerias.VarTem.tmpUser;

            string marca        = tbMarca.Text;
            string tabla        = tbTabla.Text;
            string secuencia    = tbSecuencia.Text;
            string delr         = tbDelR.Text;
            string alr          = tbAlR.Text;
            string porcentaje   = tbPorc.Text;
            string calificacion = tbCalificacion.Text;
            string estatus      = tbSts.Text;

            string fechaAlta = tbFechaAlta.Text;
            string horaAlta  = tbHoraAlta.Text;
            string userAlta  = tbUserAlta.Text;

            string fechaCambio = tbFechaCambio.Text;
            string horaCambio  = tbHoraCambio.Text;
            string userCambio  = tbUserCambio.Text;

            string stMensaje = string.Empty;

            stMensaje = validacion(marca, tabla, secuencia, delr, alr, porcentaje, calificacion, estatus);

            if (stMensaje == "Correcto")
            {
                string fchfmtAlta = string.Empty;
                string horfmtAlta = string.Empty;

                string fchfmtCambio = string.Empty;
                string horfmtCambio = string.Empty;

                try
                {
                    fchfmtAlta = fechaAlta.Substring(2, 2) + fechaAlta.Substring(5, 2) + fechaAlta.Substring(8, 2);
                    horfmtAlta = horaAlta.Substring(0, 2) + horaAlta.Substring(3, 2) + horaAlta.Substring(6, 2);
                }
                catch { };

                try
                {
                    fchfmtCambio = fechaCambio.Substring(2, 2) + fechaCambio.Substring(5, 2) + fechaCambio.Substring(8, 2);
                    horfmtCambio = horaCambio.Substring(0, 2) + horaCambio.Substring(3, 2) + horaCambio.Substring(6, 2);
                }
                catch { };
                stMensaje = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateTablasporc(marca, tabla, secuencia, delr, alr, porcentaje, calificacion, estatus, userAlta, fchfmtAlta, horfmtAlta, userCambio, fchfmtCambio, horfmtCambio);
                MessageBox.Show(stMensaje);
                if (stMensaje == "Se actualizó el registro exitosamente...")
                {
                    this.Close();
                }
            }
        }

        private void btElimiar_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;
            string message = "Esta seguro de eliminar este registro?";
            string caption = "Confirmación";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                eliminaRegistro();
            }
            else
            {
                MessageBox.Show("Proceso cancelado por el usuario");
            }
            this.Cursor = Cursors.Default;
        }

        private void eliminaRegistro()
        {
            string stMensaje = string.Empty;
            stMensaje = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().DeleteTablasporc(marca, tabla, secuencia);
            if (stMensaje == "Se Elimino el registro exitosamente...")
            {
                this.Close();
            }
        }

        private string validacion(string marca, string tabla, string secuencia, string delr, string alr, string porcentaje, string calificacion, string estatus)
        {
            string mensaje = string.Empty;
            int    tabNum  = 0;
            int    SecNum  = 0;
            double deNum   = .0000;
            double alNum   = .0000;
            double porcNum = .0000;

            mensaje = "Correcto";

            lbMsjMarca.Visible      = false;
            lbMsjTabla.Visible      = false;
            lbMsjSecuencia.Visible  = false;
            lbMsjDel.Visible        = false;
            lbMsjAl.Visible         = false;
            lbMsjPorcentaje.Visible = false;
            lbMsjCal.Visible        = false;
            lbMsjSts.Visible        = false;

            // Valida Marca
            if (marca == "10" || marca == "30" || marca == "60")
            { }
            else
            {
                tbMarca.Focus();
                lbMsjMarca.Visible = true;
                mensaje = "Error";
            }
            // Valida Tabla
            try
            {
                tabNum = Convert.ToInt16(tabla);
            }
            catch
            {
                tbTabla.Focus(); lbMsjTabla.Visible = true; mensaje = "Error";
            }

            if (tabNum <= 0 || tabNum >= 1000)           
            {
                tbTabla.Focus(); lbMsjTabla.Visible = true; mensaje = "Error";
            }
            // valida SECUENCIA
            try
            {
                SecNum = Convert.ToInt16(secuencia);
            }
            catch
            {
                tbSecuencia.Focus(); lbMsjSecuencia.Visible = true; mensaje = "Error";
            }
            if (SecNum <= 0 || SecNum >= 1000)
            {
                tbSecuencia.Focus(); lbMsjSecuencia.Visible = true; mensaje = "Error";
            }
            // valida DEL
            try
            {
                deNum = Convert.ToDouble(delr);
            }
            catch
            {
                tbDelR.Focus(); lbMsjDel.Visible = true; mensaje = "Error";
            }

            //if (deNum < .0001 || deNum >= 9999.9999)
            //{
            //    tbDelR.Focus(); lbMsjDel.Visible = true; mensaje = "Error";
            //}
            // valida AL
            try
            {
                alNum = Convert.ToDouble(alr);
            }
            catch
            {
                tbAlR.Focus(); lbMsjAl.Visible = true; mensaje = "Error";
            }

            if (alNum < .0001 || alNum >= 9999.9999) 
            {
                tbAlR.Focus(); lbMsjAl.Visible = true; mensaje = "Error";
            }
            // valida PORCENTAJE
            try
            {
                porcNum = Convert.ToDouble(porcentaje);
            }
            catch
            {
                tbPorc.Focus(); lbMsjPorcentaje.Visible = true; mensaje = "Error";
            }

            //if (porcNum < 0.0001 || porcNum >= 1.0000) 
            //{
            //    tbPorc.Focus(); lbMsjPorcentaje.Visible = true; mensaje = "Error";
            //}
            // valida CALIFICACION
            if (calificacion != "")
            { }
            else
            {
                tbCalificacion.Focus(); lbMsjCal.Visible = true; mensaje = "Error";
            }
            // valida ESTATUS
            if (estatus == "A" || estatus == "D")
            { }
            else
            {
                tbSts.Focus(); lbMsjSts.Visible = true; mensaje = "Error";
            }

            this.Cursor = Cursors.Default;
            return mensaje;
        }
    }
}
