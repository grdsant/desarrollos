﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using MmsWin.Front.Utilerias;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using MmsWin.Front.ConvenioMelody;
using MmsWin.Front.Bonificaciones; 

namespace MmsWin.Front.ConvenioMelody
{
    public partial class Administracion : Form
    {

        int nr;
        string ParUser;
        string usuario;
        String marca;
        string tipoCalificacion = " ";
        string tipoConsulta = " ";
        bool Carga;
        string niveltienda;
        String FchDe;
        String FchHas;
        long FchDeN;
        long FchHasN;
        String comprador;
        string temporada;
        string FechaCal;
        string FechaFmt;
        long FechaApli;

        string proveedor;
        string estilo;
        string depto;
        string subDepto;
        string clase;
        string subClase;

        int dgvOffset;
        int pgbOffset;
        int dgvOffset2;

        public static string ParTienda;
        public static string parProveedor;
        public static string parEstilo;
        public static string ParProveedor;
        public static string PartbNombre;
        public static string PartbEstilo;
        public static string ParDescripcion;

        public Administracion()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvGridview.Width;
            dgvOffset2 = this.Height - dgvGridview.Height;
            pgbOffset  = this.Width  - pgbProg.Width;
        }

        private void Administracion_Load(object sender, EventArgs e)
        {
            ToolTip tooltip = new ToolTip();
            tooltip.SetToolTip(this.tbProveedor, "Proveedor");
            tooltip.SetToolTip(this.tbEstilo, "Estilo");
            tooltip.SetToolTip(this.tbNombre, "Nombre");
            tooltip.SetToolTip(this.tbDescripcion, "Descripción");

            Carga = false;
            marca = "999";
            comprador = "999";
            tbCal01.Text = "0000000000";
            tbHasta.Text = "0000000000";
            FchDe = "10/10/2000";
            FchHas = "10/10/2000";
            tbCal01.Text = FchDe;
            tbHasta.Text = FchHas;

            // Carga de Marca
            try
            {
                BindMarca();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            // Carga de Compradores
            try
            {
                BindCompradores();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            // Carga de Temporadas
            try
            {
                BindTemporadas();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            try
            {
                System.Data.DataTable tbFechaInicial = null;
                tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();

                foreach (DataRow row in tbFechaInicial.Rows)
                {
                    tbCal01.Text = row["DSPFCH"].ToString();

                    FechaCal = tbCal01.Text;
                    FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                    tbCal01.Text = FechaFmt.ToString();

                    tbHasta.Text = row["DSPFCH"].ToString();
                    FechaCal = tbHasta.Text;
                    FechaFmt = FechaCal.Substring(4, 2) + "/" + FechaCal.Substring(2, 2) + "/" + "20" + FechaCal.Substring(0, 2);
                    tbHasta.Text = FechaFmt.ToString();

                    FechaCal = tbCal01.Text;
                    FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                    FchDeN = long.Parse(FechaFmt.ToString());
                    FchDe = FechaFmt.ToString();

                    FechaCal = tbHasta.Text;
                    FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                    FchHasN = long.Parse(FechaFmt.ToString());
                    FchHas = FechaFmt.ToString();

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


            comprador = MmsWin.Front.Utilerias.VarTem.tmpUSRCOM;
            cbCompradores.SelectedValue = comprador;
            marca     = MmsWin.Front.Utilerias.VarTem.tmpUSRMAR;
            cbMarca.SelectedValue = marca;

            cbTipoConsulta.SelectedIndex   = 0;
            cbAdministracion.SelectedIndex = 0;
            rbNivelEstilo.Checked = true;

            // Carga de Datos

            nivelEstilo();

            try
            {
                ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                Carga = true;
                BindAdministracion();

                // Seguridad...

                Seguridad("ConvenioMelody", "Administracion", ParUser);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        // Seguridad                                                                                
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                         
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvGridview.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvGridview.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenu.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenu.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        protected void BindAdministracion()
        {
            if (Carga == true)
            {
                nr = 0;
                this.Cursor = Cursors.WaitCursor;
                dgvGridview.DataSource = null;
                System.Data.DataTable Administracion = null;
                try
                {
                    ParTienda      = tbIdTda.Text;
                    ParProveedor   = tbProveedor.Text;
                    PartbNombre    = tbNombre.Text;
                    PartbEstilo    = tbEstilo.Text;
                    ParDescripcion = tbDescripcion.Text;

                    string Fechainicio = FchDe;
                    string FechaFinal = FchHas;

                    if (rbNivelEstilo.Checked) { niveltienda = "0"; } else { niveltienda = "1"; }

                    depto     = c_depto.Text;
                    subDepto  = c_subDepto.Text;
                    clase     = c_clase.Text;
                    subClase  = c_subClase.Text;
                    usuario   = ParUser;
                    proveedor = tbProveedor.Text;
                    estilo    = tbEstilo.Text;

                    Administracion = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenAdministracion(marca, comprador, Fechainicio, FechaFinal, temporada, tipoCalificacion, tipoConsulta, niveltienda, proveedor, estilo, depto, subDepto, clase, subClase, usuario);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                if (Administracion != null)
                {
                    if (Administracion.Rows.Count > 0)
                    {
                        dgvGridview.DataSource = Administracion;
                        SetFontAndColors();
                        rowStyle();
                        SetDoubleBuffered(dgvGridview);

                        nr = dgvGridview.RowCount;
                        this.Text = "Administracion (Diferenciados) / " + " " + (nr).ToString() + " Registro(s)";

                        // Seguridad...
                        ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        Seguridad("ConvenioMelody", "Administracion", ParUser);
                    }
                }
                this.Cursor = Cursors.Default;
            }
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        protected void BindMarca()
        {
            try
            {
                cbMarca.DataSource = MmsWin.Negocio.Catalogos.Marca.GetInstance().ObtenMarca().ToList();
                cbMarca.DisplayMember = "Value";
                cbMarca.ValueMember = "Key";
                marca = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void BindCompradores()
        {
            try
            {
                cbCompradores.DataSource = MmsWin.Negocio.Catalogos.Compradores.GetInstance().ObtenCompradors().ToList();
                cbCompradores.DisplayMember = "Value";
                cbCompradores.ValueMember = "Key";
                comprador = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void BindTemporadas()
        {
            try
            {
                cbTemporada.DataSource = MmsWin.Negocio.Catalogos.TemporadaMms.GetInstance().ObtenTemporadaMms().ToList();
                cbTemporada.DisplayMember = "Value";
                cbTemporada.ValueMember = "Key";
                temporada = "999";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void SetFontAndColors()
        {
            this.dgvGridview.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvGridview.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridview.EnableHeadersVisualStyles = false;
            this.dgvGridview.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridview.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvGridview.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridview.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridview.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvGridview.Columns["ADMTAB"].Frozen = true;

            dgvGridview.Columns["ADMMAR"].HeaderText  = "Marca";
            dgvGridview.Columns["ADMFCH"].HeaderText  = "Fecha";
            dgvGridview.Columns["ADMTPO"].HeaderText  = "Tipo";
            dgvGridview.Columns["ADMTMP"].HeaderText  = "Temporada";
            dgvGridview.Columns["ADMTAB"].HeaderText  = "Tabla %";
            dgvGridview.Columns["ADMTDA"].HeaderText  = "Tienda";
            dgvGridview.Columns["ADMTDD"].HeaderText  = "Descripción";
            dgvGridview.Columns["ADMPRV"].HeaderText  = "Proveedor";
            dgvGridview.Columns["ADMPRD"].HeaderText  = "Descripción";
            dgvGridview.Columns["ADMSTY"].HeaderText  = "Estilo";
            dgvGridview.Columns["ADMSTD"].HeaderText  = "Descripción";
            dgvGridview.Columns["ADMIDC"].HeaderText  = "Id.Comprador";
            dgvGridview.Columns["ADMNCP"].HeaderText  = "Nombre";
            dgvGridview.Columns["ADMDP"].HeaderText   = "DP";
            dgvGridview.Columns["ADMSD"].HeaderText   = "SD";
            dgvGridview.Columns["ADMCL"].HeaderText   = "CL";
            dgvGridview.Columns["ADMSC"].HeaderText   = "SC";
            dgvGridview.Columns["ADMDPD"].HeaderText  = "Departamento";
            dgvGridview.Columns["ADMSDD"].HeaderText  = "Sub-Depto";
            dgvGridview.Columns["ADMCLD"].HeaderText  = "Clase";
            dgvGridview.Columns["ADMSCD"].HeaderText  = "Sub-Clase";
            dgvGridview.Columns["ADMORD"].HeaderText  = "Orden";
            dgvGridview.Columns["ADMFRB"].HeaderText  = "Fecha Recibo";
            dgvGridview.Columns["ADMCRB"].HeaderText  = "Cantidad Recibo";
            dgvGridview.Columns["ADMVPZ"].HeaderText  = "Venta Piezas";
            dgvGridview.Columns["ADMPVT"].HeaderText  = " %  Vendido";
            dgvGridview.Columns["ADMONH"].HeaderText  = "On Hand";
            dgvGridview.Columns["ADMONO"].HeaderText  = "On Order";
            dgvGridview.Columns["ADMRTB"].HeaderText  = "% Rent. 1";
            dgvGridview.Columns["ADMCDP"].HeaderText  = "Califi cación";
            dgvGridview.Columns["ADMCOR"].HeaderText  = "Calif. Origina";
            dgvGridview.Columns["ADMCFN"].HeaderText  = "Calif. Final";
            dgvGridview.Columns["ADMTAC"].HeaderText  = "Tabla Acción";
            dgvGridview.Columns["ADMCSTC"].HeaderText = "Costo Cal";
            dgvGridview.Columns["ADMPRCC"].HeaderText = "Precio Cal";
            dgvGridview.Columns["ADMMRGC"].HeaderText = "Margen Cal";
            dgvGridview.Columns["ADMMTX"].HeaderText  = "Matriz";
            dgvGridview.Columns["ADMCLP"].HeaderText  = "Cal. Puntos";
            dgvGridview.Columns["ADMCLA"].HeaderText  = "Cal. Allocation";
            dgvGridview.Columns["ADMFBO"].HeaderText  = "Fecha Bonificación";
            dgvGridview.Columns["ADMOHB"].HeaderText  = "On Hand Bon";
            dgvGridview.Columns["ADMTBO"].HeaderText  = "Tabla Acc Bon";
            dgvGridview.Columns["ADMCSTA"].HeaderText = "Costo Actual";
            dgvGridview.Columns["ADMPRCA"].HeaderText = "Precio Actual";
            dgvGridview.Columns["ADMMRGA"].HeaderText = "Margen Actual";
            dgvGridview.Columns["ADMCSTF"].HeaderText = "Costo Final";
            dgvGridview.Columns["ADMPRCF"].HeaderText = "Precio Final";
            dgvGridview.Columns["ADMMRGF"].HeaderText = "Margen Final";
            dgvGridview.Columns["ADMTAF"].HeaderText  = "Tabla Acc final";
            dgvGridview.Columns["ADMFCHU"].HeaderText = "Fecha";
            dgvGridview.Columns["ADMHORU"].HeaderText = "Hora";
            dgvGridview.Columns["ADMUSRU"].HeaderText = "Usuario";
            dgvGridview.Columns["ADMEVC"].HeaderText  = "Event Costo";
            dgvGridview.Columns["ADMEVP"].HeaderText  = "Event Precio";
            dgvGridview.Columns["ADMEVE"].HeaderText  = "Event Etiqueta";

            dgvGridview.Columns["ADMUSRA"].HeaderText = "Usuario Alta";
            dgvGridview.Columns["ADMFCHA"].HeaderText = "Fecha Alta";
            dgvGridview.Columns["ADMHORA"].HeaderText = "Hora Alta";

            dgvGridview.Columns["ADMMAR"].Width  = 40;
            dgvGridview.Columns["ADMFCH"].Width  = 80;
            dgvGridview.Columns["ADMTPO"].Width  = 70;
            dgvGridview.Columns["ADMTMP"].Width  = 40;
            dgvGridview.Columns["ADMTAB"].Width  = 40;
            dgvGridview.Columns["ADMTDA"].Width  = 40;
            dgvGridview.Columns["ADMTDD"].Width  = 150;
            dgvGridview.Columns["ADMPRV"].Width  = 40;
            dgvGridview.Columns["ADMPRD"].Width  = 150;
            dgvGridview.Columns["ADMSTY"].Width  = 70;
            dgvGridview.Columns["ADMSTD"].Width  = 150;
            dgvGridview.Columns["ADMIDC"].Width  = 40;
            dgvGridview.Columns["ADMNCP"].Width  = 150;
            dgvGridview.Columns["ADMDP"].Width   = 40;
            dgvGridview.Columns["ADMSD"].Width   = 40;
            dgvGridview.Columns["ADMCL"].Width   = 40;
            dgvGridview.Columns["ADMSC"].Width   = 40;
            dgvGridview.Columns["ADMDPD"].Width  = 100;
            dgvGridview.Columns["ADMSDD"].Width  = 100;
            dgvGridview.Columns["ADMCLD"].Width  = 100;
            dgvGridview.Columns["ADMSCD"].Width  = 100;
            dgvGridview.Columns["ADMORD"].Width  = 70;
            dgvGridview.Columns["ADMFRB"].Width  = 80;
            dgvGridview.Columns["ADMCRB"].Width  = 60;
            dgvGridview.Columns["ADMVPZ"].Width  = 60;
            dgvGridview.Columns["ADMPVT"].Width  = 60;
            dgvGridview.Columns["ADMONH"].Width  = 60;
            dgvGridview.Columns["ADMONO"].Width  = 60;
            dgvGridview.Columns["ADMRTB"].Width  = 60;
            dgvGridview.Columns["ADMCDP"].Width  = 80;
            dgvGridview.Columns["ADMCOR"].Width  = 80;
            dgvGridview.Columns["ADMCFN"].Width  = 80;
            dgvGridview.Columns["ADMTAC"].Width  = 40;
            dgvGridview.Columns["ADMCSTC"].Width = 60;
            dgvGridview.Columns["ADMPRCC"].Width = 60;
            dgvGridview.Columns["ADMMRGC"].Width = 60;
            dgvGridview.Columns["ADMMTX"].Width  = 60;
            dgvGridview.Columns["ADMCLP"].Width  = 60;
            dgvGridview.Columns["ADMCLA"].Width  = 60;
            dgvGridview.Columns["ADMFBO"].Width  = 80;
            dgvGridview.Columns["ADMOHB"].Width  = 60;
            dgvGridview.Columns["ADMTBO"].Width  = 40;
            dgvGridview.Columns["ADMCSTA"].Width = 60;
            dgvGridview.Columns["ADMPRCA"].Width = 60;
            dgvGridview.Columns["ADMMRGA"].Width = 60;
            dgvGridview.Columns["ADMCSTF"].Width = 60;
            dgvGridview.Columns["ADMPRCF"].Width = 60;
            dgvGridview.Columns["ADMMRGF"].Width = 60;
            dgvGridview.Columns["ADMTAF"].Width  = 40;
            dgvGridview.Columns["ADMFCHU"].Width = 80;
            dgvGridview.Columns["ADMHORU"].Width = 80;
            dgvGridview.Columns["ADMUSRU"].Width = 60;
            dgvGridview.Columns["ADMEVC"].Width  = 60;
            dgvGridview.Columns["ADMEVP"].Width  = 60;
            dgvGridview.Columns["ADMEVE"].Width  = 60;
            dgvGridview.Columns["ADMUSRA"].Width = 60;
            dgvGridview.Columns["ADMFCHA"].Width = 80;
            dgvGridview.Columns["ADMHORA"].Width = 80;

            dgvGridview.Columns["ADMMAR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMFCH"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMTPO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMTMP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMTAB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMTDA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMTDD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridview.Columns["ADMPRV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridview.Columns["ADMPRD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridview.Columns["ADMSTY"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridview.Columns["ADMSTD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridview.Columns["ADMIDC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMNCP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridview.Columns["ADMDP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMSD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMCL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMSC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMDPD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridview.Columns["ADMSDD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridview.Columns["ADMCLD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridview.Columns["ADMSCD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridview.Columns["ADMORD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMFRB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMCRB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["ADMVPZ"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["ADMPVT"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMONH"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["ADMONO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["ADMRTB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["ADMCDP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMCOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMCFN"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMTAC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMCSTC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["ADMPRCC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["ADMMRGC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["ADMMTX"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMCLP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMCLA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMFBO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMOHB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMTBO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMCSTA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["ADMPRCA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["ADMMRGA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["ADMCSTF"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["ADMPRCF"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["ADMMRGF"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridview.Columns["ADMTAF"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMFCHU"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMHORU"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMUSRU"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMEVC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMEVP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMEVE"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMUSRA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMFCHA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridview.Columns["ADMHORA"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridview.Columns["ADMCRB"].DefaultCellStyle.Format = "###,###";
            dgvGridview.Columns["ADMVPZ"].DefaultCellStyle.Format = "###,###";
            dgvGridview.Columns["ADMPVT"].DefaultCellStyle.Format = "###,###.00";
            dgvGridview.Columns["ADMONH"].DefaultCellStyle.Format = "###,###";
            dgvGridview.Columns["ADMONO"].DefaultCellStyle.Format = "###,###";
            dgvGridview.Columns["ADMRTB"].DefaultCellStyle.Format = "#,###.00";

            dgvGridview.Columns["ADMFCH"].DefaultCellStyle.Format = "20##-##-##";

            dgvGridview.Columns["ADMCSTC"].DefaultCellStyle.Format = "###,###.00";
            dgvGridview.Columns["ADMPRCC"].DefaultCellStyle.Format = "###,###.00";
            dgvGridview.Columns["ADMMRGC"].DefaultCellStyle.Format = "###,###.00";
            dgvGridview.Columns["ADMCSTA"].DefaultCellStyle.Format = "###,###.00";
            dgvGridview.Columns["ADMPRCA"].DefaultCellStyle.Format = "###,###.00";
            dgvGridview.Columns["ADMMRGA"].DefaultCellStyle.Format = "###,###.00";
            dgvGridview.Columns["ADMCSTF"].DefaultCellStyle.Format = "###,###.00";
            dgvGridview.Columns["ADMPRCF"].DefaultCellStyle.Format = "###,###.00";
            dgvGridview.Columns["ADMMRGF"].DefaultCellStyle.Format = "###,###.00";
            dgvGridview.Columns["ADMFRB"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridview.Columns["ADMFBO"].DefaultCellStyle.Format = "20##-##-##";


            dgvGridview.Columns["ADMFCHU"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridview.Columns["ADMHORU"].DefaultCellStyle.Format = "##-##-##";

            dgvGridview.Columns["ADMMAR"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridview.Columns["ADMFCH"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMTPO"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMTMP"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMTAB"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMTDA"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["ADMTDD"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["ADMPRV"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["ADMPRD"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["ADMSTY"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMSTD"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMIDC"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMNCP"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMDP"].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridview.Columns["ADMSD"].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridview.Columns["ADMCL"].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridview.Columns["ADMSC"].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridview.Columns["ADMDPD"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMSDD"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMCLD"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMSCD"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMORD"].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridview.Columns["ADMFRB"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["ADMCRB"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["ADMVPZ"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["ADMPVT"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridview.Columns["ADMONH"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridview.Columns["ADMONO"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMRTB"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMCDP"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["ADMCOR"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["ADMCFN"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["ADMTAC"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["ADMCSTC"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMPRCC"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMMRGC"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMMTX"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["ADMCLP"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMCLA"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMFBO"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["ADMOHB"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["ADMTBO"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["ADMCSTA"].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridview.Columns["ADMPRCA"].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridview.Columns["ADMMRGA"].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridview.Columns["ADMCSTF"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["ADMPRCF"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["ADMMRGF"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["ADMTAF"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMFCHU"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["ADMHORU"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["ADMUSRU"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridview.Columns["ADMEVC"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMEVP"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMEVE"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridview.Columns["ADMUSRA"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["ADMFCHA"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridview.Columns["ADMHORA"].HeaderCell.Style.BackColor = Color.LightSkyBlue;

              dgvGridview.Columns["ADMCFN"].Visible = false;

              if (rbNivelEstilo.Checked)
              {
                  dgvGridview.Columns["ADMTDA"].Visible = false;
                  dgvGridview.Columns["ADMTDD"].Visible = false;
              }
              else 
              {
                  dgvGridview.Columns["ADMTDA"].Visible = true;
                  dgvGridview.Columns["ADMTDD"].Visible = true;
              }

            foreach (DataGridViewRow row in dgvGridview.Rows)
            {
                // Pagar
                if (Convert.ToString(row.Cells["ADMCDP"].Value) == "P a g a r") { row.Cells["ADMCDP"].Style.BackColor = Color.LightGreen; }
                // 11%
                if (Convert.ToString(row.Cells["ADMCDP"].Value) == "10%") { row.Cells["ADMCDP"].Style.BackColor = Color.Yellow; }
                // 15%
                if (Convert.ToString(row.Cells["ADMCDP"].Value) == "15%") { row.Cells["ADMCDP"].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(row.Cells["ADMCDP"].Value) == "20%") { row.Cells["ADMCDP"].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(row.Cells["ADMCDP"].Value) == "25%") { row.Cells["ADMCDP"].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(row.Cells["ADMCDP"].Value) == "30%") { row.Cells["ADMCDP"].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(row.Cells["ADMCDP"].Value) == "35%") { row.Cells["ADMCDP"].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(row.Cells["ADMCDP"].Value) == "40%") { row.Cells["ADMCDP"].Style.BackColor = Color.LightSalmon; }
                // Dev ó 40%
                if (Convert.ToString(row.Cells["ADMCDP"].Value) == "40%") { row.Cells["ADMCDP"].Style.BackColor = Color.Red; row.Cells["ADMCDP"].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(row.Cells["ADMCDP"].Value) == "50%") { row.Cells["ADMCDP"].Style.BackColor = Color.Red; row.Cells["ADMCDP"].Style.ForeColor = Color.White; }
                //Dev ó 50%
                if (Convert.ToString(row.Cells["ADMCDP"].Value) == "50%") { row.Cells["ADMCDP"].Style.BackColor = Color.Red; row.Cells["ADMCDP"].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(row.Cells["ADMCDP"].Value) == "Devolucion") { row.Cells["ADMCDP"].Style.BackColor = Color.Red; row.Cells["ADMCDP"].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(row.Cells["ADMCDP"].Value) == "Devolución") { row.Cells["ADMCDP"].Style.BackColor = Color.Red; row.Cells["ADMCDP"].Style.ForeColor = Color.White; }

                // Pagar
                if (Convert.ToString(row.Cells["ADMCOR"].Value) == "P a g a r") { row.Cells["ADMCOR"].Style.BackColor = Color.LightGreen; }
                // 11%
                if (Convert.ToString(row.Cells["ADMCOR"].Value) == "10%") { row.Cells["ADMCOR"].Style.BackColor = Color.Yellow; }
                // 15%
                if (Convert.ToString(row.Cells["ADMCOR"].Value) == "15%") { row.Cells["ADMCOR"].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(row.Cells["ADMCOR"].Value) == "20%") { row.Cells["ADMCOR"].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(row.Cells["ADMCOR"].Value) == "25%") { row.Cells["ADMCOR"].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(row.Cells["ADMCOR"].Value) == "30%") { row.Cells["ADMCOR"].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(row.Cells["ADMCOR"].Value) == "35%") { row.Cells["ADMCOR"].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(row.Cells["ADMCOR"].Value) == "40%") { row.Cells["ADMCOR"].Style.BackColor = Color.LightSalmon; }
                // Dev ó 40%
                if (Convert.ToString(row.Cells["ADMCOR"].Value) == "40%") { row.Cells["ADMCOR"].Style.BackColor = Color.Red; row.Cells["ADMCOR"].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(row.Cells["ADMCOR"].Value) == "50%") { row.Cells["ADMCOR"].Style.BackColor = Color.Red; row.Cells["ADMCOR"].Style.ForeColor = Color.White; }
                //Dev ó 50%
                if (Convert.ToString(row.Cells["ADMCOR"].Value) == "50%") { row.Cells["ADMCOR"].Style.BackColor = Color.Red; row.Cells["ADMCOR"].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(row.Cells["ADMCOR"].Value) == "Devolucion") { row.Cells["ADMCOR"].Style.BackColor = Color.Red; row.Cells["ADMCOR"].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(row.Cells["ADMCOR"].Value) == "Devolución") { row.Cells["ADMCOR"].Style.BackColor = Color.Red; row.Cells["ADMCOR"].Style.ForeColor = Color.White; }
             //   if (Convert.ToString(row.Cells["RDDRUT"].Value) != "") { row.Cells["RDDNOT"].Style.ForeColor = Color.Green; }
             //   if (Convert.ToString(row.Cells["RDDRUT"].Value) == "") { row.Cells["RDDNOT"].Style.ForeColor = Color.Red; }
            }

        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridview.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    dgvGridview.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }

        private void Administracion_Resize(object sender, EventArgs e)
        {
            dgvGridview.Width = this.Width - dgvOffset;
            dgvGridview.Height = this.Height - dgvOffset2;
            pgbProg.Width = this.Width - pgbOffset;
        }

        private void tbCal01_Click(object sender, EventArgs e)
        {
            mcC1.Visible = true;
            mcC1.Focus();
        }

        private void mcCal01_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbHasta.Text = mcCal01.SelectionEnd.ToShortDateString();
            FechaCal = tbHasta.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchHasN = long.Parse(FechaFmt.ToString());
            FchHas = FechaFmt.ToString();

            mcCal01.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbHasta.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    BindAdministracion();
                }
            }

        }

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            marca = " ";
            ComboBox cmbMarca = (ComboBox)sender;
            marca = cmbMarca.SelectedValue.ToString();

            BindAdministracion();
        }

        private void cbCompradores_SelectedValueChanged(object sender, EventArgs e)
        {
            comprador = " ";
            ComboBox cmbComprador = (ComboBox)sender;
            comprador = cmbComprador.SelectedValue.ToString();

            BindAdministracion();
        }

        private void fotoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MuestraFoto();
        }

        private void MuestraFoto()
        {
            try
            {
                Fotos i = new Fotos();
                i.Show();
            }
            catch { }
            finally { }
        }

        private void dgvGridview_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            MmsWin.Front.Utilerias.VarTem.rddFchBon = this.dgvGridview.CurrentRow.Cells["ADMFBO"].Value.ToString();

            MmsWin.Front.Utilerias.VarTem.rddTipoCal = this.dgvGridview.CurrentRow.Cells["ADMTPO"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.rddTemporada = this.dgvGridview.CurrentRow.Cells["ADMTMP"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.rddTienda = this.dgvGridview.CurrentRow.Cells["ADMTDA"].Value.ToString();

            MmsWin.Front.Utilerias.VarTem.rddFchRev = this.dgvGridview.CurrentRow.Cells["ADMFCH"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.rddProveedor = this.dgvGridview.CurrentRow.Cells["ADMPRV"].Value.ToString();
            MmsWin.Front.Utilerias.VarTem.rddEstilo = this.dgvGridview.CurrentRow.Cells["ADMSTY"].Value.ToString();
            //MmsWin.Front.Utilerias.VarTem.rddNota      = this.dgvGridview.CurrentRow.Cells["RDDNOT"].Value.ToString();
            //MmsWin.Front.Utilerias.VarTem.tmpRutaPdf   = this.dgvGridview.CurrentRow.Cells["RDDRUT"].Value.ToString();

            MmsWin.Front.Utilerias.Fotos.numPrv = this.dgvGridview.CurrentRow.Cells["ADMPRV"].Value.ToString();
            MmsWin.Front.Utilerias.Fotos.numSty = this.dgvGridview.CurrentRow.Cells["ADMSTY"].Value.ToString();
        }

        private void dgvGridview_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                FechaCal = tbCal01.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FechaApli = long.Parse(FechaFmt.ToString());

                BindAdministracion();
            }
        }

        private void EliminarTSM1_Click(object sender, EventArgs e)
        {
            string message = "Corfirmar la Eliminación del Registro";
            string caption = "Advertencia...";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                string ParFchBon    = MmsWin.Front.Utilerias.VarTem.rddFchBon;

                string ParTipoCal   = MmsWin.Front.Utilerias.VarTem.rddTipoCal;
                string ParTemporada = MmsWin.Front.Utilerias.VarTem.rddTemporada;
                string ParTienda    = MmsWin.Front.Utilerias.VarTem.rddTienda;

                string ParFchRev    = MmsWin.Front.Utilerias.VarTem.rddFchRev;
                string ParProveedor = MmsWin.Front.Utilerias.VarTem.rddProveedor;
                string ParEstilo    = MmsWin.Front.Utilerias.VarTem.rddEstilo;
                string ParNota      = MmsWin.Front.Utilerias.VarTem.rddNota;

                //MmsWin.Negocio.ConvenioMelody.Administracion.GetInstance().EliminaDocumentos(ParFchBon, ParFchRev, ParTipoCal, ParTemporada, ParTienda, ParProveedor, ParEstilo, ParNota);

                BindAdministracion();
            }
        }

        private void Administracion_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("ConvenioMelody", "Administracion", ParUser);
            }
        }
        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            //
            string NomCol;
            Int32 NoCol = dgvGridview.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvGridview.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      
            //
            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void dgvGridview_Sorted(object sender, EventArgs e)
        {
            SetFontAndColors();
            rowStyle();
        }

        private void cargaPDFTSM_Click(object sender, EventArgs e)
        {
            CargaPDF();
        }

        private void CargaPDF()
        {
            try
            {
                CargaPDF i = new CargaPDF();
                i.Show();
            }
            catch { }
            finally { }
        }

        private void cosnsultaPDFTSM_Click(object sender, EventArgs e)
        {
            try
            {
                string notaPDF = MmsWin.Front.Utilerias.VarTem.tmpRutaPdf;
                Process.Start(notaPDF);
            }
            catch { MessageBox.Show("No hay PDF Cargado"); }
        }

        private void tbProveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbCal01.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindAdministracion();
                tbProveedor.Focus();
            }
        }

        private void tbNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbCal01.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindAdministracion();
                tbNombre.Focus();
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbCal01.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindAdministracion();
                tbDescripcion.Focus();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                FechaCal = tbCal01.Text;
                FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
                FchDeN = long.Parse(FechaFmt.ToString());
                FchDe = FechaFmt.ToString();

                BindAdministracion();
                tbDescripcion.Focus();
            }
        }

        private void mcC1_DateSelected(object sender, DateRangeEventArgs e)
        {
            tbCal01.Text = mcC1.SelectionEnd.ToShortDateString();
            FechaCal = tbCal01.Text;
            FechaFmt = FechaCal.Substring(8, 2) + FechaCal.Substring(3, 2) + FechaCal.Substring(0, 2);
            FchDeN = long.Parse(FechaFmt.ToString());
            FchDe = FechaFmt.ToString();

            mcC1.Visible = false;
            if (FchDeN > 0 && FchHasN > 0)
            {
                if (FchDeN > FchHasN)
                {
                    tbCal01.Text = " "; FechaCal = " "; FechaFmt = " ";
                    MessageBox.Show("La Fecha Desde no puede ser menor a la Fecha Hasta");
                }
                else
                {
                    BindAdministracion(); ;
                }
            }
        }

        private void mcC1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcC1.Visible = false;
            }
        }

        private void mcC1_Leave(object sender, EventArgs e)
        {
            mcC1.Visible = false;
        }

        private void mcCal01_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                mcCal01.Visible = false;
            }
        }

        private void mcCal01_Leave(object sender, EventArgs e)
        {
            mcCal01.Visible = false;
        }

        private void tbHasta_Click(object sender, EventArgs e)
        {
            mcCal01.Visible = true;
            mcCal01.Focus();
        }

        private void pbExcel_Click(object sender, EventArgs e)
        {
            System.Data.DataTable dtDowns = (System.Data.DataTable)(dgvGridview.DataSource);
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            int nc = dgvGridview.Columns.Count;


            for (int ii = 1; ii <= nc; ii++)
            {
                xlWorkSheet.Cells[1, ii] = dgvGridview.Columns[ii - 1].HeaderText;
            }

            System.Data.DataTable dtDocumentos = (System.Data.DataTable)(dgvGridview.DataSource);
            int nr = dgvGridview.RowCount;

            int r = 0;
            int rt = 3;
            foreach (DataRow row in dtDocumentos.Rows)
            {
                var gsArray = new[]       {
                                                    row["NOTBON"], //01 Fecha Bonificacion
                                                    row["NOTPRV"], //02 Proveedor
                                                    row["NOTPRN"], //03 Nombre
                                                    row["NOTSTY"], //04 Estilo
                                                    row["NOTDES"], //05 Descripcion
                                                    row["NOTDCP"], //06 Comprador
                                                    row["NOTNOT"], //07 Nota de Credito
                                                    row["NOTSUB"], //08 Subtotal
                                                    row["NOTIVA"], //09 Iva
                                                    row["NOTTOT"], //10 Total
                                                    row["NOTCST"], //11 Costo
                                                    row["NOTPRC"], //12 Precio
                                                    row["NOTMRG"], //13 Margen
                                                    row["NOTNCA"], //14 No Calificacion
                                                    row["NOTFCM"], //15 Fecha Compra
                                                    row["NOTFRE"], //16 Fecha Revision
                                                    row["NOTPZA"], //17 Piezas
                                                    row["NOTVTA"], //18 Venta
                                                    row["NOTONH"], //19 on Hand
                                                    row["NOTPVT"], //20 % Venta
                                                    row["NOTCAL"], //21 Calificaion
                                                    row["NOTTAB"], //22 Tabla de Accion
                                                    row["NOTCMP"], //23 Compras Obsercvaciones
                                                    row["NOTRUT"], //24 Ruta
                                                    row["NOTMAR"], //25 Marca
                                                    row["NOTCOM"], //26 Comprador
                                                    row["NOTBDG"], //27 Bodega
                                                    row["NOTNMR"], //28 Marca
                                                    row["NOTFCHA"],//29 Fecha
                                                    row["NOTHORA"],//30 Hora
                                                    row["NOTUSR"]  //31 Usuario

                                                   };

                Range rng = xlWorkSheet.get_Range("A" + rt, "AE" + rt);
                rng.Value = gsArray;

                this.Text = "Notas de Crédito / " + " " + (r += 1).ToString() + " Registro(s) de " + nr;

                rt++;
            }

            xlWorkSheet.Columns[1].ColumnWidth = 3;
            xlWorkSheet.Columns[2].ColumnWidth = 15;
            xlWorkSheet.Columns[3].ColumnWidth = 50;
            xlWorkSheet.Columns[4].ColumnWidth = 15;
            xlWorkSheet.Columns[5].ColumnWidth = 50;
            xlWorkSheet.Columns[6].ColumnWidth = 20;
            xlWorkSheet.Columns[7].ColumnWidth = 10;
            xlWorkSheet.Columns[8].ColumnWidth = 10;
            xlWorkSheet.Columns[9].ColumnWidth = 10;
            xlWorkSheet.Columns[10].ColumnWidth = 10;
            xlWorkSheet.Columns[11].ColumnWidth = 11;
            xlWorkSheet.Columns[12].ColumnWidth = 11;
            xlWorkSheet.Columns[13].ColumnWidth = 11;
            xlWorkSheet.Columns[14].ColumnWidth = 11;
            xlWorkSheet.Columns[15].ColumnWidth = 11;
            xlWorkSheet.Columns[16].ColumnWidth = 11;
            xlWorkSheet.Columns[17].ColumnWidth = 11;
            xlWorkSheet.Columns[18].ColumnWidth = 11;
            xlWorkSheet.Columns[19].ColumnWidth = 11;
            xlWorkSheet.Columns[20].ColumnWidth = 11;
            xlWorkSheet.Columns[21].ColumnWidth = 11;
            xlWorkSheet.Columns[22].ColumnWidth = 11;
            xlWorkSheet.Columns[23].ColumnWidth = 11;
            xlWorkSheet.Columns[24].ColumnWidth = 11;
            xlWorkSheet.Columns[25].ColumnWidth = 11;
            xlWorkSheet.Columns[26].ColumnWidth = 11;
            xlWorkSheet.Columns[27].ColumnWidth = 11;
            xlWorkSheet.Columns[28].ColumnWidth = 11;
            xlWorkSheet.Columns[29].ColumnWidth = 11;
            xlWorkSheet.Columns[30].ColumnWidth = 11;
            xlWorkSheet.Columns[31].ColumnWidth = 11;


            var Rang1 = xlWorkSheet.get_Range("A1", "A1");
            Rang1.Interior.Color = Color.LightGreen;

            xlWorkSheet.Cells[1, 2].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 3].Cells.Interior.Color = Color.LightSkyBlue;

            xlWorkSheet.Cells[1, 4].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 5].Cells.Interior.Color = Color.LightSalmon;

            var Rang2 = xlWorkSheet.get_Range("F1", "F1");
            Rang2.Interior.Color = Color.LightGreen;

            var Rang3 = xlWorkSheet.get_Range("G1", "G1");
            Rang3.Interior.Color = Color.LightSkyBlue;

            var Rang4 = xlWorkSheet.get_Range("H1", "H1");
            Rang4.Interior.Color = Color.LightSalmon;

            var Rang5 = xlWorkSheet.get_Range("I1", "I1");
            Rang5.Interior.Color = Color.LightSkyBlue;

            var Rang6 = xlWorkSheet.get_Range("J1", "J1");
            Rang6.Interior.Color = Color.LightGreen;

            var Rang7 = xlWorkSheet.get_Range("K1", "K1");
            Rang7.Interior.Color = Color.LightSalmon;

            var Rang9 = xlWorkSheet.get_Range("L1", "L1");
            Rang9.Interior.Color = Color.LightGray;

            var Rang8 = xlWorkSheet.get_Range("M1", "M1");
            Rang8.WrapText = true;
            Rang8.Font.Bold = true;
            Rang8.Font.Color = Color.Black;
            Rang8.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang8.Font.Underline = true;
            Rang8.HorizontalAlignment = HorizontalAlignment.Center;
            Rang8.Interior.Color = Color.LightGray;

            xlWorkSheet.Cells[1, 14].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 15].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 16].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 17].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 18].Cells.Interior.Color = Color.LightGray;
            xlWorkSheet.Cells[1, 19].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 20].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 21].Cells.Interior.Color = Color.LightGray;
            xlWorkSheet.Cells[1, 22].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 23].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 24].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 25].Cells.Interior.Color = Color.LightGray;
            xlWorkSheet.Cells[1, 26].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 27].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 28].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 29].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 30].Cells.Interior.Color = Color.LightGreen;
            xlWorkSheet.Cells[1, 31].Cells.Interior.Color = Color.LightGray;



            String Rango = "A2" + ":" + "AE" + rt;
            Excel.Range SourceRange = (Excel.Range)xlWorkSheet.get_Range("A2", "AE" + rt); // or whatever range you want here
            FormatAsTable(SourceRange, "Table1", "TableStyleMedium2");

            xlWorkSheet.Rows[2].Hidden = true;

            xlWorkSheet.Columns["A"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["G"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["K:M"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["O:P"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["T:V"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["Y:AE"].HorizontalAlignment  = XlHAlign.xlHAlignCenter;

            xlWorkSheet.Columns["A"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["O"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["P"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["AC"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["AD"].NumberFormat = "00-00-00";

            var range = xlWorkSheet.get_Range("A3", "A3");
            range.Select();

            string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
            xlApp.ActiveWindow.Zoom = 80;
            xlWorkBook.SaveAs("C:\\Reportes\\NotasCredito" + Hoy + ".xlsx", Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            string comando = @"C:\\Reportes\\NotasCredito" + Hoy + ".xlsx";
            ExecuteCommand(comando);
        }

        static void ExecuteCommand(string _Command)
        {
            //Indicamos que deseamos inicializar el proceso cmd.exe junto a un comando de arranque. 
            //(/C, le indicamos al proceso cmd que deseamos que cuando termine la tarea asignada se cierre el proceso).
            //Para mas informacion consulte la ayuda de la consola con cmd.exe /? 
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;
            //Inicializa el proceso
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            string result = proc.StandardOutput.ReadToEnd();
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        public void FormatAsTable(Excel.Range SourceRange, string TableName, string TableStyleName)
        {
            SourceRange.Worksheet.ListObjects.Add(XlListObjectSourceType.xlSrcRange,
            SourceRange, System.Type.Missing, XlYesNoGuess.xlYes, System.Type.Missing).Name =
                TableName;
            SourceRange.Select();
            SourceRange.Worksheet.ListObjects[TableName].TableStyle = TableStyleName;
            SourceRange.Worksheet.ListObjects[TableName].ShowAutoFilter = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowHeaders = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowTotals = false;
        }

        private void tbProveedor_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindAdministracion();
                tbProveedor.Focus();
            }
        }

        private void tbNombre_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindAdministracion();
                tbNombre.Focus();
            }
        }

        private void tbEstilo_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindAdministracion();
                tbEstilo.Focus();
            }
        }

        private void tbDescripcion_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindAdministracion();
                tbDescripcion.Focus();
            }
        }

        private void btExcel_Click(object sender, EventArgs e)
        {
            try
            {
                this.Cursor = Cursors.WaitCursor;
                System.Data.DataTable dtDowns = (System.Data.DataTable)(dgvGridview.DataSource);
                Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                if (xlApp == null)
                {
                    MessageBox.Show("Excel is not properly installed!!");
                    return;
                }
                Excel.Workbook xlWorkBook;
                Excel.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;
                xlWorkBook = xlApp.Workbooks.Add(misValue);
                xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                int nc = dgvGridview.Columns.Count;

                for (int ii = 1; ii <= nc; ii++)
                {

                    xlWorkSheet.Cells[1, ii] = dgvGridview.Columns[ii - 1].HeaderText;

                }

                System.Data.DataTable dtConvenio = (System.Data.DataTable)(dgvGridview.DataSource);
                int nr = dgvGridview.RowCount;
                this.pgbProg.Visible = true;

                pgbProg.Maximum = nr;
                pgbProg.Value = 0;
                int r = 0;
                int rt = 3;
                foreach (DataRow row in dtConvenio.Rows)
                {
                    var gsArray = new[] 
                {         
                 row["ADMMAR"],  //00 Marca
                 row["ADMFCH"],  //01 Fecha
                 row["ADMTPO"],  //02 Tipo
                 row["ADMTMP"],  //03 Temporada
                 row["ADMTAB"],  //04 Tabla Porcentaje
                 row["ADMTDA"],  //05 Tienda
                 row["ADMTDD"],  //06 Descripcion Tienda 
                 row["ADMPRV"],  //07 Proveedor 
                 row["ADMPRD"],  //08 Nombre  
                 row["ADMSTY"],  //09 Estilo 
                 row["ADMSTD"],  //10 Descripcion  
                 row["ADMIDC"],  //11 Semana 
                 row["ADMNCP"],  //12 Semana 
                 row["ADMDP"],   //13 Departamento 
                 row["ADMSD"],   //14 Sub-Depto 
                 row["ADMCL"],   //15 Clase 
                 row["ADMSC"],   //16 Sub-Clase 
                 row["ADMDPD"],  //17 Departamento 
                 row["ADMSDD"],  //18 Sub-Depto  
                 row["ADMCLD"],  //19 Clase 
                 row["ADMSCD"],  //20 Sub-Clase 
                 row["ADMORD"],  //21 Orden 
                 row["ADMFRB"],  //22 Fecha Recibo 

                 row["ADMCRB"],  //23 Cantidad Recibida 
                 row["ADMVPZ"],  //24 Piezas Vendidas 
                 row["ADMPVT"],  //25 Porcentaje de Venta 

                 row["ADMONH"],  //26 On Hand 
                 row["ADMONO"],  //27 On Order 
                 row["ADMRTB"],  //28 Rentabilidad 
                 row["ADMCDP"],  //29 Calificacion 

                 row["ADMCOR"],  //30 Calificacion Original 
                 row["ADMCFN"],  //31 Calificacion Final 
                 row["ADMTAC"],  //32 Tabla de Accion 
                 row["ADMCSTC"], //33 Costo 
                 row["ADMPRCC"], //34 Precio 

                 row["ADMMRGC"], //35 Margen 
                 row["ADMMTX"],  //36 Matriz 
                 row["ADMCLP"],  //37 Semana 

                 row["ADMCLA"],  //38 Semana 
                 row["ADMFBO"],  //39 Fecha Bonificacion 
                 row["ADMOHB"],  //40 On Hand Bonificacion 
                 row["ADMTBO"],  //41 Semana 
                 row["ADMCSTA"], //42 Costo 
                 row["ADMPRCA"], //43 Precio 
                 row["ADMMRGA"], //44 Margen 
                 row["ADMCSTF"], //45 Costo 
                 row["ADMPRCF"], //46 Precio 
                 row["ADMMRGF"], //47 Margen 

                 row["ADMTAF"],  //48 Tabla de Accion final 
                 row["ADMFCHU"], //49 Fecha 
                 row["ADMHORU"], //50 Hora 
                 row["ADMUSRU"], //51 Usuario 
                 row["ADMEVC"],  //52 Evento Costos 
                 row["ADMEVP"],  //53 Evento Precio 
                 row["ADMEVE"],  //54 Evento Etiqueta 
                 row["ADMUSRA"], //55 Usuario  
                 row["ADMFCHA"], //56 Fecha 
                 row["ADMHORA"]  //57 Hora 

                };

                    Range rng = xlWorkSheet.get_Range("A" + rt, "BF" + rt);
                    rng.Value = gsArray;

                    pgbProg.Value += 1;

                    this.Text = "Administración / " + " " + (r += 1).ToString() + " Registro(s)";

                    // Pagar
                    if (row["ADMCDP"].ToString() == "P a g a r") { xlWorkSheet.Cells[rt, 30].Cells.Interior.Color = Color.LightGreen; xlWorkSheet.Cells[rt, 30].Cells.Font.Color = Color.Black; }
                    // 15%
                    if (row["ADMCDP"].ToString() == "15%") { xlWorkSheet.Cells[rt, 30].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 30].Cells.Font.Color = Color.Black; }
                    // 20% 
                    if (row["ADMCDP"].ToString() == "20%") { xlWorkSheet.Cells[rt, 30].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 30].Cells.Font.Color = Color.Black; }
                    // 25%
                    if (row["ADMCDP"].ToString() == "25%") { xlWorkSheet.Cells[rt, 30].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 30].Cells.Font.Color = Color.Black; }
                    // 30%
                    if (row["ADMCDP"].ToString() == "30%") { xlWorkSheet.Cells[rt, 30].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 30].Cells.Font.Color = Color.Black; }
                    // 35% 
                    if (row["ADMCDP"].ToString() == "35%") { xlWorkSheet.Cells[rt, 30].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 30].Cells.Font.Color = Color.Black; }
                    // 40%
                    if (row["ADMCDP"].ToString() == "40%") { xlWorkSheet.Cells[rt, 30].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 30].Cells.Font.Color = Color.White; }
                    // Dev ó 40%
                    if (row["ADMCDP"].ToString() == "40%") { xlWorkSheet.Cells[rt, 30].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 30].Cells.Font.Color = Color.White; }
                    //Dev o 50%
                    if (row["ADMCDP"].ToString() == "50%") { xlWorkSheet.Cells[rt, 30].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 30].Cells.Font.Color = Color.White; }
                    //Dev o 50%
                    if (row["ADMCDP"].ToString() == "50%") { xlWorkSheet.Cells[rt, 30].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 30].Cells.Font.Color = Color.White; }
                    // Devolucion
                    if (row["ADMCDP"].ToString() == "Devolución") { xlWorkSheet.Cells[rt, 30].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 30].Cells.Font.Color = Color.White; }

                    // Pagar
                    if (row["ADMCOR"].ToString() == "P a g a r") { xlWorkSheet.Cells[rt, 31].Cells.Interior.Color = Color.LightGreen; xlWorkSheet.Cells[rt, 31].Cells.Font.Color = Color.Black; }
                    // 15%
                    if (row["ADMCOR"].ToString() == "15%") { xlWorkSheet.Cells[rt, 31].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 31].Cells.Font.Color = Color.Black; }
                    // 20%
                    if (row["ADMCOR"].ToString() == "20%") { xlWorkSheet.Cells[rt, 31].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 31].Cells.Font.Color = Color.Black; }
                    // 25%
                    if (row["ADMCOR"].ToString() == "25%") { xlWorkSheet.Cells[rt, 31].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 31].Cells.Font.Color = Color.Black; }
                    // 30%
                    if (row["ADMCOR"].ToString() == "30%") { xlWorkSheet.Cells[rt, 31].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 31].Cells.Font.Color = Color.Black; }
                    // 35%
                    if (row["ADMCOR"].ToString() == "35%") { xlWorkSheet.Cells[rt, 31].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 31].Cells.Font.Color = Color.Black; }
                    // 40%
                    if (row["ADMCOR"].ToString() == "40%") { xlWorkSheet.Cells[rt, 31].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 31].Cells.Font.Color = Color.White; }
                    // Dev ó 40%
                    if (row["ADMCOR"].ToString() == "40%") { xlWorkSheet.Cells[rt, 31].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 31].Cells.Font.Color = Color.White; }
                    //Dev o 50%
                    if (row["ADMCOR"].ToString() == "50%") { xlWorkSheet.Cells[rt, 31].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 31].Cells.Font.Color = Color.White; }
                    //Dev o 50%
                    if (row["ADMCOR"].ToString() == "50%") { xlWorkSheet.Cells[rt, 31].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 31].Cells.Font.Color = Color.White; }
                    // Devolucion
                    if (row["ADMCOR"].ToString() == "Devolución") { xlWorkSheet.Cells[rt, 31].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 31].Cells.Font.Color = Color.White; }


                    // Pagar
                    if (row["ADMCFN"].ToString() == "P a g a r") { xlWorkSheet.Cells[rt, 32].Cells.Interior.Color = Color.LightGreen; xlWorkSheet.Cells[rt, 32].Cells.Font.Color = Color.Black; }
                    // 15%
                    if (row["ADMCFN"].ToString() == "15%") { xlWorkSheet.Cells[rt, 32].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 32].Cells.Font.Color = Color.Black; }
                    // 20%
                    if (row["ADMCFN"].ToString() == "20%") { xlWorkSheet.Cells[rt, 32].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 32].Cells.Font.Color = Color.Black; }
                    // 25%
                    if (row["ADMCFN"].ToString() == "25%") { xlWorkSheet.Cells[rt, 32].Cells.Interior.Color = Color.Yellow; xlWorkSheet.Cells[rt, 32].Cells.Font.Color = Color.Black; }
                    // 30%
                    if (row["ADMCFN"].ToString() == "30%") { xlWorkSheet.Cells[rt, 32].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 32].Cells.Font.Color = Color.Black; }
                    // 35%
                    if (row["ADMCFN"].ToString() == "35%") { xlWorkSheet.Cells[rt, 32].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 32].Cells.Font.Color = Color.Black; }
                    // 40%
                    if (row["ADMCFN"].ToString() == "40%") { xlWorkSheet.Cells[rt, 32].Cells.Interior.Color = Color.LightSalmon; xlWorkSheet.Cells[rt, 32].Cells.Font.Color = Color.Black; }
                    // Dev ó 40%
                    if (row["ADMCFN"].ToString() == "40%") { xlWorkSheet.Cells[rt, 32].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 32].Cells.Font.Color = Color.White; }
                    //Dev o 50%
                    if (row["ADMCFN"].ToString() == "50%") { xlWorkSheet.Cells[rt, 32].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 32].Cells.Font.Color = Color.White; }
                    //Dev o 50%
                    if (row["ADMCFN"].ToString() == "50%") { xlWorkSheet.Cells[rt, 32].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 32].Cells.Font.Color = Color.White; }
                    // Devolucion
                    if (row["ADMCFN"].ToString() == "Devolución") { xlWorkSheet.Cells[rt, 32].Cells.Interior.Color = Color.Red; xlWorkSheet.Cells[rt, 32].Cells.Font.Color = Color.White; }
                    rt++;
                }
                xlWorkSheet.Columns[1].ColumnWidth = 2;
                xlWorkSheet.Columns[2].ColumnWidth = 5;
                xlWorkSheet.Columns[3].ColumnWidth = 15;
                xlWorkSheet.Columns[4].ColumnWidth = 10;
                xlWorkSheet.Columns[5].ColumnWidth = 2;
                xlWorkSheet.Columns[6].ColumnWidth = 2;
                xlWorkSheet.Columns[7].ColumnWidth = 25;
                xlWorkSheet.Columns[8].ColumnWidth = 5;
                xlWorkSheet.Columns[9].ColumnWidth = 25;
                xlWorkSheet.Columns[10].ColumnWidth = 10;
                xlWorkSheet.Columns[11].ColumnWidth = 25;
                xlWorkSheet.Columns[12].ColumnWidth = 5;
                xlWorkSheet.Columns[13].ColumnWidth = 25;
                xlWorkSheet.Columns[14].ColumnWidth = 2;
                xlWorkSheet.Columns[15].ColumnWidth = 2;
                xlWorkSheet.Columns[16].ColumnWidth = 2;
                xlWorkSheet.Columns[17].ColumnWidth = 2;
                xlWorkSheet.Columns[18].ColumnWidth = 25;
                xlWorkSheet.Columns[19].ColumnWidth = 25;
                xlWorkSheet.Columns[20].ColumnWidth = 25;
                xlWorkSheet.Columns[21].ColumnWidth = 25;
                xlWorkSheet.Columns[22].ColumnWidth = 5;
                xlWorkSheet.Columns[23].ColumnWidth = 5;
                xlWorkSheet.Columns[24].ColumnWidth = 5;
                xlWorkSheet.Columns[25].ColumnWidth = 5;
                xlWorkSheet.Columns[26].ColumnWidth = 5;
                xlWorkSheet.Columns[27].ColumnWidth = 5;
                xlWorkSheet.Columns[28].ColumnWidth = 5;
                xlWorkSheet.Columns[29].ColumnWidth = 5;
                xlWorkSheet.Columns[30].ColumnWidth = 10;
                xlWorkSheet.Columns[31].ColumnWidth = 10;
                xlWorkSheet.Columns[32].ColumnWidth = 10;
                xlWorkSheet.Columns[33].ColumnWidth = 5;
                xlWorkSheet.Columns[34].ColumnWidth = 5;
                xlWorkSheet.Columns[35].ColumnWidth = 5;
                xlWorkSheet.Columns[36].ColumnWidth = 5;
                xlWorkSheet.Columns[37].ColumnWidth = 5;
                xlWorkSheet.Columns[38].ColumnWidth = 5;
                xlWorkSheet.Columns[39].ColumnWidth = 5;
                xlWorkSheet.Columns[40].ColumnWidth = 10;
                xlWorkSheet.Columns[41].ColumnWidth = 5;
                xlWorkSheet.Columns[42].ColumnWidth = 5;
                xlWorkSheet.Columns[43].ColumnWidth = 5;
                xlWorkSheet.Columns[44].ColumnWidth = 5;
                xlWorkSheet.Columns[45].ColumnWidth = 5;
                xlWorkSheet.Columns[46].ColumnWidth = 5;
                xlWorkSheet.Columns[47].ColumnWidth = 5;
                xlWorkSheet.Columns[48].ColumnWidth = 5;
                xlWorkSheet.Columns[49].ColumnWidth = 5;
                xlWorkSheet.Columns[50].ColumnWidth = 10;
                xlWorkSheet.Columns[51].ColumnWidth = 5;
                xlWorkSheet.Columns[52].ColumnWidth = 10;
                xlWorkSheet.Columns[53].ColumnWidth = 5;
                xlWorkSheet.Columns[54].ColumnWidth = 5;
                xlWorkSheet.Columns[55].ColumnWidth = 5;
                xlWorkSheet.Columns[56].ColumnWidth = 10;
                xlWorkSheet.Columns[57].ColumnWidth = 10;
                xlWorkSheet.Columns[58].ColumnWidth = 5;

                var Rang1 = xlWorkSheet.get_Range("A1", "E1");
                Rang1.Interior.Color = Color.LightCoral;
                Rang1.Font.Color = Color.White;
                Rang1.Borders.LineStyle = BorderStyle.FixedSingle;

                var Rang2 = xlWorkSheet.get_Range("F1", "G1");
                Rang2.Interior.Color = Color.LightSlateGray;
                Rang2.Font.Color = Color.White;
                Rang2.Borders.LineStyle = BorderStyle.FixedSingle;

                var Rang3 = xlWorkSheet.get_Range("H1", "K1");
                Rang3.Interior.Color = Color.Blue;
                Rang3.Font.Color = Color.White;
                Rang3.Borders.LineStyle = BorderStyle.FixedSingle;

                var Rang4 = xlWorkSheet.get_Range("L1", "M1");
                Rang4.Interior.Color = Color.Green;
                Rang4.Font.Color = Color.White;
                Rang4.Borders.LineStyle = BorderStyle.FixedSingle;

                var Rang5 = xlWorkSheet.get_Range("N1", "Q1");
                Rang5.Interior.Color = Color.Blue;
                Rang5.Font.Color = Color.White;
                Rang5.Borders.LineStyle = BorderStyle.FixedSingle;

                var Rang6 = xlWorkSheet.get_Range("R1", "U1");
                Rang6.Interior.Color = Color.FromArgb(255, 255, 192);
                //Rang6.Font.Color = Color.White;
                Rang6.Borders.LineStyle = BorderStyle.FixedSingle;

                var Rang7 = xlWorkSheet.get_Range("V1", "X1");
                Rang7.Interior.Color = Color.LightCoral;
                Rang7.Font.Color = Color.White;
                Rang7.Borders.LineStyle = BorderStyle.FixedSingle;

                var Rang8 = xlWorkSheet.get_Range("Y1", "Z1");
                Rang8.Interior.Color = Color.LightSkyBlue;
                Rang8.Font.Color = Color.White;
                Rang8.Borders.LineStyle = BorderStyle.FixedSingle;

                var Rang9 = xlWorkSheet.get_Range("AA1", "AB1");
                Rang9.Interior.Color = Color.LightSlateGray;
                Rang9.Font.Color = Color.White;
                Rang9.Borders.LineStyle = BorderStyle.FixedSingle;

                var Rang10 = xlWorkSheet.get_Range("AC1", "AC1");
                Rang10.Interior.Color = Color.LightSkyBlue;
                Rang10.Font.Color = Color.White;
                Rang10.Borders.LineStyle = BorderStyle.FixedSingle;

                var Rang11 = xlWorkSheet.get_Range("AD1", "AF1");
                Rang11.Interior.Color = Color.LightSeaGreen;
                Rang11.Font.Color = Color.White;
                Rang11.Borders.LineStyle = BorderStyle.FixedSingle;

                var Rang12 = xlWorkSheet.get_Range("AG1", "AG1");
                Rang12.Interior.Color = Color.LightSlateGray;
                Rang12.Font.Color = Color.White;
                Rang12.Borders.LineStyle = BorderStyle.FixedSingle;

                var Rang12A = xlWorkSheet.get_Range("AH1", "AJ1");
                Rang12A.Interior.Color = Color.LightSlateGray;
                Rang12A.Font.Color = Color.White;
                Rang12A.Borders.LineStyle = BorderStyle.FixedSingle;

                var Rang13 = xlWorkSheet.get_Range("AK1", "AM1");
                Rang13.Interior.Color = Color.LightSeaGreen;
                Rang13.Font.Color = Color.White;
                Rang13.Borders.LineStyle = BorderStyle.FixedSingle;

                var Rang14 = xlWorkSheet.get_Range("AN1", "AP1");
                Rang14.WrapText = true;
                Rang14.Font.Bold = true;
                Rang14.Interior.Color = Color.LightSlateGray;
                Rang14.Font.Color = Color.White;
                Rang14.Borders.LineStyle = BorderStyle.FixedSingle;
                Rang14.Font.Underline = true;
                Rang14.HorizontalAlignment = HorizontalAlignment.Center;

                var Rang15 = xlWorkSheet.get_Range("AQ1", "AS1");
                Rang15.WrapText = true;
                Rang15.Font.Bold = true;
                Rang15.Interior.Color = Color.LightSkyBlue;
                Rang15.Font.Color = Color.White;
                Rang15.Borders.LineStyle = BorderStyle.FixedSingle;
                Rang15.Font.Underline = true;
                Rang15.HorizontalAlignment = HorizontalAlignment.Center;

                var Rang16 = xlWorkSheet.get_Range("AT1", "AV1");
                Rang16.WrapText = true;
                Rang16.Font.Bold = true;
                Rang16.Interior.Color = Color.LightCoral;
                Rang16.Font.Color = Color.White;
                Rang16.Borders.LineStyle = BorderStyle.FixedSingle;
                Rang16.Font.Underline = true;
                Rang16.HorizontalAlignment = HorizontalAlignment.Center;

                var Rang17 = xlWorkSheet.get_Range("AW1", "AW1");
                Rang17.WrapText = true;
                Rang17.Font.Bold = true;
                Rang17.Interior.Color = Color.LightSlateGray;
                Rang17.Font.Color = Color.White;
                Rang17.Borders.LineStyle = BorderStyle.FixedSingle;
                Rang17.Font.Underline = true;
                Rang17.HorizontalAlignment = HorizontalAlignment.Center;

                var Rang18 = xlWorkSheet.get_Range("AX1", "AZ1");
                Rang18.WrapText = true;
                Rang18.Font.Bold = true;
                Rang18.Interior.Color = Color.FromArgb(0, 0, 192);
                Rang18.Font.Color = Color.White;
                Rang18.Borders.LineStyle = BorderStyle.FixedSingle;
                Rang18.Font.Underline = true;
                Rang18.HorizontalAlignment = HorizontalAlignment.Center;

                var Rang19 = xlWorkSheet.get_Range("BA1", "BC1");
                Rang19.WrapText = true;
                Rang19.Font.Bold = true;
                Rang19.Interior.Color = Color.LightCoral;
                Rang19.Font.Color = Color.White;
                Rang19.Borders.LineStyle = BorderStyle.FixedSingle;
                Rang19.Font.Underline = true;
                Rang19.HorizontalAlignment = HorizontalAlignment.Center;

                var Rang20 = xlWorkSheet.get_Range("BD1", "BF1");
                Rang20.WrapText  = true;
                Rang20.Font.Bold = true;
                Rang20.Interior.Color = Color.LightSlateGray;
                Rang20.Font.Color     = Color.White;
                Rang20.Borders.LineStyle   = BorderStyle.FixedSingle;
                Rang20.Font.Underline      = true;
                Rang20.HorizontalAlignment = HorizontalAlignment.Center;

                String Rango = "A2" + ":" + "BF" + rt;
                Excel.Range SourceRange = (Excel.Range)xlWorkSheet.get_Range("A2", "BF" + rt);
                FormatAsTable(SourceRange, "Table1", "TableStyleMedium2");

                xlWorkSheet.Rows[2].Hidden = true;

                xlWorkSheet.Columns["A:B"].HorizontalAlignment  = XlHAlign.xlHAlignCenter;
                xlWorkSheet.Columns["D:E"].HorizontalAlignment  = XlHAlign.xlHAlignCenter;
                xlWorkSheet.Columns["F"].HorizontalAlignment    = XlHAlign.xlHAlignRight;
                xlWorkSheet.Columns["H"].HorizontalAlignment    = XlHAlign.xlHAlignRight;
                xlWorkSheet.Columns["J"].HorizontalAlignment    = XlHAlign.xlHAlignLeft;
                xlWorkSheet.Columns["L"].HorizontalAlignment    = XlHAlign.xlHAlignCenter;
                xlWorkSheet.Columns["N:Q"].HorizontalAlignment  = XlHAlign.xlHAlignCenter;
                xlWorkSheet.Columns["V:W"].HorizontalAlignment  = XlHAlign.xlHAlignCenter;
                xlWorkSheet.Columns["X:AB"].HorizontalAlignment = XlHAlign.xlHAlignRight;
                xlWorkSheet.Columns["AC"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;
                xlWorkSheet.Columns["AD:AG"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
                xlWorkSheet.Columns["AH:AM"].HorizontalAlignment = XlHAlign.xlHAlignRight;
                xlWorkSheet.Columns["AN"].HorizontalAlignment    = XlHAlign.xlHAlignCenter;
                xlWorkSheet.Columns["AO"].HorizontalAlignment    = XlHAlign.xlHAlignRight;
                xlWorkSheet.Columns["AP"].HorizontalAlignment    = XlHAlign.xlHAlignCenter;
                xlWorkSheet.Columns["AQ:AV"].HorizontalAlignment = XlHAlign.xlHAlignRight;
                xlWorkSheet.Columns["AW:BF"].HorizontalAlignment    = XlHAlign.xlHAlignCenter;

                xlWorkSheet.Columns["B"].NumberFormat = "20##-##-##";
                xlWorkSheet.Columns["W"].NumberFormat = "20##-##-##";
                xlWorkSheet.Columns["AN"].NumberFormat = "20##-##-##";
                xlWorkSheet.Columns["AX"].NumberFormat = "20##-##-##";
                xlWorkSheet.Columns["BE"].NumberFormat = "20##-##-##";

                xlWorkSheet.Columns["AY"].NumberFormat = "##-##-##";
                xlWorkSheet.Columns["BF"].NumberFormat = "##-##-##";

                xlWorkSheet.Columns["X"].NumberFormat = "###,###";
                xlWorkSheet.Columns["Y"].NumberFormat = "###,###";
                xlWorkSheet.Columns["Z"].NumberFormat = "#,###.00";
                xlWorkSheet.Columns["AA:AB"].NumberFormat = "###,###";
                xlWorkSheet.Columns["AC"].NumberFormat = "#,###.00";
                xlWorkSheet.Columns["AH:AM"].NumberFormat = "###,###.00";
                xlWorkSheet.Columns["AO"].NumberFormat = "###,###";
                xlWorkSheet.Columns["AQ:AV"].NumberFormat = "###,###.00";

                var range = xlWorkSheet.get_Range("A3", "A3");
                range.Select();

                //xlApp.Range["Q"].Select();

                xlApp.Range["AF:AF"].EntireColumn.Delete();
                //xlApp.Range["J:J"].EntireColumn.Delete();
                //xlApp.Range["Z:AD"].EntireColumn.Delete();
                //xlApp.Range["AR:AR"].EntireColumn.Delete();
                //xlApp.Range["BH:BH"].EntireColumn.Delete();
                //xlApp.Range["BR:BW"].EntireColumn.Delete();



                string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
                xlApp.ActiveWindow.Zoom = 80;
                xlWorkBook.SaveAs("C:\\Reportes\\Administracion" + Hoy + ".xlsx", Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
                xlWorkBook.Close(true, misValue, misValue);
                xlApp.Quit();
                releaseObject(xlWorkSheet);
                releaseObject(xlWorkBook);
                releaseObject(xlApp);

                string comando = @"C:\\Reportes\\Administracion" + Hoy + ".xlsx";
                ExecuteCommand(comando);

                this.pgbProg.Visible = false;
                this.Cursor = Cursors.Default;
            }
            catch { this.Cursor = Cursors.Default; }
        }

        private void cbTipoConsulta_SelectedIndexChanged(object sender, EventArgs e)
        {
            tipoCalificacion = " ";
            ComboBox cbTipoConsulta = (ComboBox)sender;
            tipoCalificacion = cbTipoConsulta.SelectedItem.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpTipoGlobal = tipoCalificacion;
            MmsWin.Front.Utilerias.VarTem.parTipoCalificacion = tipoCalificacion;

            BindAdministracion();
        }

        private void cbAdministracion_SelectedIndexChanged(object sender, EventArgs e)
        {
            tipoConsulta = " ";
            ComboBox cbTipoConsulta = (ComboBox)sender;
            tipoConsulta = cbTipoConsulta.SelectedItem.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpTipoGlobal = tipoConsulta;
            MmsWin.Front.Utilerias.VarTem.parTipoCalificacion = tipoConsulta;

            BindAdministracion();
        }

        private void cbTemporada_SelectedValueChanged(object sender, EventArgs e)
        {
            temporada = " ";
            ComboBox cbTemporada = (ComboBox)sender;
            temporada = cbTemporada.SelectedValue.ToString();

            BindAdministracion();
        }

        private void btResumen_Click(object sender, EventArgs e)
        {
            
                            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "ResumenDiferenciado").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana Resumen Diferenciado ya esta abierta...");
                    }
                    else
                    {
                        ResumenDiferenciado i = new ResumenDiferenciado();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }

        }

        private void rbNivelEstilo_Click(object sender, EventArgs e)
        {       
            nivelEstilo();

            BindAdministracion();

            tbIdTda.Text = string.Empty;
            tbTdaNombre.Text = string.Empty;
        }

        private void rbNivelTienda_Click(object sender, EventArgs e)
        {
            nivelTienda();

            BindAdministracion();
        }

        private void nivelEstilo()
        {
            tbIdTda.Visible = false;
            tbTdaNombre.Visible = false;
            try
            {
                dgvGridview.Columns["ADMTDA"].Visible = false;
                dgvGridview.Columns["ADMTDD"].Visible = false;
            }
            catch { }

            tbProveedor.Location = new System.Drawing.Point(315, 71);
            tbNombre.Location = new System.Drawing.Point(355, 71);
            tbEstilo.Location = new System.Drawing.Point(505, 71);
            tbDescripcion.Location = new System.Drawing.Point(575, 71);
            tbIdComp.Location = new System.Drawing.Point(725, 71);
            tbDesComp.Location = new System.Drawing.Point(765, 71);
            c_depto.Location = new System.Drawing.Point(915, 71);
            c_subDepto.Location = new System.Drawing.Point(955, 71);
            c_clase.Location = new System.Drawing.Point(995, 71);
            c_subClase.Location = new System.Drawing.Point(1035, 71);
        }

        private void nivelTienda()
        {
            tbIdTda.Visible = true;
            tbTdaNombre.Visible = true;
            dgvGridview.Columns["ADMTDA"].Visible = true;
            dgvGridview.Columns["ADMTDD"].Visible = true;

            tbProveedor.Location = new System.Drawing.Point(504, 71);
            tbNombre.Location = new System.Drawing.Point(544, 71);
            tbEstilo.Location = new System.Drawing.Point(694, 71);
            tbDescripcion.Location = new System.Drawing.Point(764, 71);
            tbIdComp.Location = new System.Drawing.Point(914, 71);
            tbDesComp.Location = new System.Drawing.Point(954, 71);
            c_depto.Location = new System.Drawing.Point(1104, 71);
            c_subDepto.Location = new System.Drawing.Point(1144, 71);
            c_clase.Location = new System.Drawing.Point(1184, 71);
            c_subClase.Location = new System.Drawing.Point(1224, 71);
        }

        private void c_depto_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindAdministracion();
                c_depto.Focus();
            }
        }

        private void c_subDepto_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindAdministracion();
                c_subDepto.Focus();
            }
        }

        private void c_clase_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindAdministracion();
                c_clase.Focus();
            }
        }

        private void c_subClase_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindAdministracion();
                c_subClase.Focus();
            }
        }

        private void tbTemporada_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindAdministracion();
                tbTemporada.Focus();
            }
        }

        private void tbTbporc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindAdministracion();
                tbTbporc.Focus();
            }
        }

        private void tbIdTda_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindAdministracion();
                tbIdTda.Focus();
            }
        }

        private void tbTdaNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindAdministracion();
                tbTdaNombre.Focus();
            }
        }

        private void tbIdComp_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindAdministracion();
                tbIdComp.Focus();
            }
        }

        private void tbDesComp_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindAdministracion();
                tbDesComp.Focus();
            }
        }
    }
}
