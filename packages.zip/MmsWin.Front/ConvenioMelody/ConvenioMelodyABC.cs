﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class ConvenioMelodyABC : Form
    {
        #region Variables
        // variables de la Ventana
        public static string capLista;
        public static string capCorreo;
        public static string capNombre;
        public static string capEstatus;
        public static string capUsuario;
        public static string capFecha;
        public static string capHora;
        #endregion

        public ConvenioMelodyABC()
        {
            InitializeComponent();
        }

        private void ConvenioMelodyABC_Load(object sender, EventArgs e)
        {
            //if (MmsWin.Front.ConvenioMelody.CalificacionGrid.corrLista != "")
            //{

            //    try
            //    {
            //        Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
            //                      "ConvenioMelodyGrid").SingleOrDefault<Form>();
            //        {
            //            if (existe != null)
            //            {
            //                CargaVariables();
            //            }
            //        }
            //    }
            //    catch { }
            //}

            DateTime fecha = Convert.ToDateTime(DateTime.Now.ToShortDateString());
            tbFecha.Text = Convert.ToString(fecha.ToString("yyyy-MM-dd"));

            DateTime hora = DateTime.Now;
            tbHora.Text = (hora.ToString("HH:mm:ss", CultureInfo.InvariantCulture));   
        }

        private void CargaVariables()
        {
            //tbLista.Text = MmsWin.Front.ConvenioMelody.CalificacionGrid.corrLista;
            //tbSemana.Text = MmsWin.Front.ConvenioMelody.CalificacionGrid.corrCorreo;
            //tbTipo.Text = MmsWin.Front.ConvenioMelody.CalificacionGrid.corrNombre;
            //tbEstatus.Text = MmsWin.Front.ConvenioMelody.CalificacionGrid.corrEstatus;
            //tbUsuario.Text = MmsWin.Front.ConvenioMelody.CalificacionGrid.corrUsuario;
            //tbFecha.Text = MmsWin.Front.ConvenioMelody.CalificacionGrid.corrFecha;
            //tbHora.Text = MmsWin.Front.ConvenioMelody.CalificacionGrid.corrHora;
        }

        private void btCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btAceptar_Click(object sender, EventArgs e)
        {
            if (tbLista.Text != "")
            {
                string lista = tbLista.Text;
                string correo = tbSemana.Text;
                string nombre = tbTipo.Text;
                string estatus = tbEstatus.Text;
                string usuario = tbUsuario.Text;
                string fecha = tbFecha.Text;
                string hora = tbHora.Text;
                string stCorreo = string.Empty;
                //stCorreo = MmsWin.Negocio.Correo.Correo.GetInstance().GuardaCorreo(lista, correo, nombre, estatus, usuario, fecha, hora);

                //MessageBox.Show(stCorreo);
                this.Close();
            }
            else 
            {
                MessageBox.Show("No debe quedar en blanco el campo de Lista...");
            }
        }

        private void btActualizar_Click(object sender, EventArgs e)
        {
            if (tbLista.Text != "")
            {
                string lista    = tbLista.Text;
                string correo   = tbSemana.Text;
                string nombre   = tbTipo.Text;
                string estatus  = tbEstatus.Text;
                string usuario  = tbUsuario.Text;
                string fecha    = tbFecha.Text;
                string hora     = tbHora.Text;
                string stCorreo = string.Empty;
                //stCorreo = MmsWin.Negocio.Correo.Correo.GetInstance().ActualizaCorreo(lista, correo, nombre, estatus, usuario, fecha, hora);

                //MessageBox.Show(stCorreo);
                this.Close();
            }
            else
            {
                MessageBox.Show("No debe quedar en blanco el campo de Lista...");
            }

        }

        private void btEliminar_Click(object sender, EventArgs e)
        {
            string message = "Esta seguro de eliminar este registro?";
            string caption = "Confirmación";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                eliminaRegistro();
            }
            else
            {
                MessageBox.Show("Proceso cancelado por el usuario");
            }
        }

        private void eliminaRegistro() 
        {
            if (tbLista.Text != "")
            {
                string lista = tbLista.Text;
                string correo = tbSemana.Text;
                string nombre = tbTipo.Text;
                string estatus = tbEstatus.Text;
                string usuario = tbUsuario.Text;
                string fecha = tbFecha.Text;
                string hora = tbHora.Text;
                string stCorreo = string.Empty;
                //stCorreo = MmsWin.Negocio.Correo.Correo.GetInstance().EliminaCorreo(lista, correo, nombre, estatus, usuario, fecha, hora);

                //MessageBox.Show(stCorreo);
                this.Close();
            }
            else
            {
                MessageBox.Show("No debe quedar en blanco el campo de Lista...");
            }
        }

        private void ConvenioMelodyABC_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                CargaVariables();
            }
        }

        private void tbLista_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                CargaVariables();
            }
        }

    }
}
