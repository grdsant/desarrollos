﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class DetalleTemporada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DetalleTemporada));
            this.panel01 = new System.Windows.Forms.Panel();
            this.tbSCD = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbProveedor = new System.Windows.Forms.TextBox();
            this.tbCLD = new System.Windows.Forms.TextBox();
            this.tbSDD = new System.Windows.Forms.TextBox();
            this.tbSC = new System.Windows.Forms.TextBox();
            this.tbCL = new System.Windows.Forms.TextBox();
            this.tbSD = new System.Windows.Forms.TextBox();
            this.tbDP = new System.Windows.Forms.TextBox();
            this.btRelleno = new System.Windows.Forms.Button();
            this.tbDPD = new System.Windows.Forms.TextBox();
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.lbTitulo = new System.Windows.Forms.Label();
            this.pbSalir = new System.Windows.Forms.PictureBox();
            this.panel01.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).BeginInit();
            this.SuspendLayout();
            // 
            // panel01
            // 
            this.panel01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel01.Controls.Add(this.tbSCD);
            this.panel01.Controls.Add(this.tbDescripcion);
            this.panel01.Controls.Add(this.tbEstilo);
            this.panel01.Controls.Add(this.tbNombre);
            this.panel01.Controls.Add(this.tbProveedor);
            this.panel01.Controls.Add(this.tbCLD);
            this.panel01.Controls.Add(this.tbSDD);
            this.panel01.Controls.Add(this.tbSC);
            this.panel01.Controls.Add(this.tbCL);
            this.panel01.Controls.Add(this.tbSD);
            this.panel01.Controls.Add(this.tbDP);
            this.panel01.Controls.Add(this.btRelleno);
            this.panel01.Controls.Add(this.tbDPD);
            this.panel01.Controls.Add(this.dgvGridView);
            this.panel01.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel01.Location = new System.Drawing.Point(0, 69);
            this.panel01.Name = "panel01";
            this.panel01.Size = new System.Drawing.Size(1240, 538);
            this.panel01.TabIndex = 11;
            // 
            // tbSCD
            // 
            this.tbSCD.Location = new System.Drawing.Point(986, 3);
            this.tbSCD.Name = "tbSCD";
            this.tbSCD.Size = new System.Drawing.Size(100, 20);
            this.tbSCD.TabIndex = 34;
            this.tbSCD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSCD_KeyPress);
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDescripcion.Location = new System.Drawing.Point(346, 3);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(180, 20);
            this.tbDescripcion.TabIndex = 26;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress_1);
            // 
            // tbEstilo
            // 
            this.tbEstilo.Location = new System.Drawing.Point(266, 3);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(80, 20);
            this.tbEstilo.TabIndex = 25;
            this.tbEstilo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbEstilo_KeyPress);
            // 
            // tbNombre
            // 
            this.tbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNombre.Location = new System.Drawing.Point(86, 3);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(180, 20);
            this.tbNombre.TabIndex = 24;
            this.tbNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNombre_KeyPress);
            // 
            // tbProveedor
            // 
            this.tbProveedor.Location = new System.Drawing.Point(46, 3);
            this.tbProveedor.Name = "tbProveedor";
            this.tbProveedor.Size = new System.Drawing.Size(40, 20);
            this.tbProveedor.TabIndex = 23;
            this.tbProveedor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbProveedor_KeyPress);
            // 
            // tbCLD
            // 
            this.tbCLD.Location = new System.Drawing.Point(886, 3);
            this.tbCLD.Name = "tbCLD";
            this.tbCLD.Size = new System.Drawing.Size(100, 20);
            this.tbCLD.TabIndex = 33;
            this.tbCLD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCLD_KeyPress);
            // 
            // tbSDD
            // 
            this.tbSDD.Location = new System.Drawing.Point(786, 3);
            this.tbSDD.Name = "tbSDD";
            this.tbSDD.Size = new System.Drawing.Size(100, 20);
            this.tbSDD.TabIndex = 32;
            this.tbSDD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSDD_KeyPress);
            // 
            // tbSC
            // 
            this.tbSC.Location = new System.Drawing.Point(646, 3);
            this.tbSC.Name = "tbSC";
            this.tbSC.Size = new System.Drawing.Size(40, 20);
            this.tbSC.TabIndex = 30;
            this.tbSC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSC_KeyPress);
            // 
            // tbCL
            // 
            this.tbCL.Location = new System.Drawing.Point(606, 3);
            this.tbCL.Name = "tbCL";
            this.tbCL.Size = new System.Drawing.Size(40, 20);
            this.tbCL.TabIndex = 29;
            this.tbCL.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCL_KeyPress);
            // 
            // tbSD
            // 
            this.tbSD.Location = new System.Drawing.Point(566, 3);
            this.tbSD.Name = "tbSD";
            this.tbSD.Size = new System.Drawing.Size(40, 20);
            this.tbSD.TabIndex = 28;
            this.tbSD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSD_KeyPress);
            // 
            // tbDP
            // 
            this.tbDP.Location = new System.Drawing.Point(526, 3);
            this.tbDP.Name = "tbDP";
            this.tbDP.Size = new System.Drawing.Size(40, 20);
            this.tbDP.TabIndex = 27;
            this.tbDP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDP_KeyPress);
            // 
            // btRelleno
            // 
            this.btRelleno.Location = new System.Drawing.Point(3, 2);
            this.btRelleno.Name = "btRelleno";
            this.btRelleno.Size = new System.Drawing.Size(44, 22);
            this.btRelleno.TabIndex = 35;
            this.btRelleno.UseVisualStyleBackColor = true;
            // 
            // tbDPD
            // 
            this.tbDPD.Location = new System.Drawing.Point(686, 3);
            this.tbDPD.Name = "tbDPD";
            this.tbDPD.Size = new System.Drawing.Size(100, 20);
            this.tbDPD.TabIndex = 31;
            this.tbDPD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDPD_KeyPress);
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.Location = new System.Drawing.Point(4, 24);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.ReadOnly = true;
            this.dgvGridView.Size = new System.Drawing.Size(1232, 510);
            this.dgvGridView.TabIndex = 0;
            this.dgvGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellClick);
            this.dgvGridView.SelectionChanged += new System.EventHandler(this.dgvGridView_SelectionChanged);
            this.dgvGridView.DoubleClick += new System.EventHandler(this.dgvGridView_DoubleClick);
            // 
            // lbTitulo
            // 
            this.lbTitulo.AutoSize = true;
            this.lbTitulo.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbTitulo.Location = new System.Drawing.Point(9, 10);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(238, 21);
            this.lbTitulo.TabIndex = 33;
            this.lbTitulo.Text = "Detalle del Grupo nivel estilo";
            // 
            // pbSalir
            // 
            this.pbSalir.Image = ((System.Drawing.Image)(resources.GetObject("pbSalir.Image")));
            this.pbSalir.Location = new System.Drawing.Point(1205, 12);
            this.pbSalir.Name = "pbSalir";
            this.pbSalir.Size = new System.Drawing.Size(23, 22);
            this.pbSalir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSalir.TabIndex = 46;
            this.pbSalir.TabStop = false;
            this.pbSalir.Click += new System.EventHandler(this.pbSalir_Click_1);
            // 
            // DetalleTemporada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(1240, 607);
            this.Controls.Add(this.pbSalir);
            this.Controls.Add(this.lbTitulo);
            this.Controls.Add(this.panel01);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "DetalleTemporada";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DetalleTemporada";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DetalleTemporada_FormClosing);
            this.Load += new System.EventHandler(this.DetalleTemporada_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.DetalleTemporada_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.DetalleTemporada_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.DetalleTemporada_MouseUp);
            this.panel01.ResumeLayout(false);
            this.panel01.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel01;
        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.Label lbTitulo;
        private System.Windows.Forms.PictureBox pbSalir;
        private System.Windows.Forms.TextBox tbSCD;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.TextBox tbProveedor;
        private System.Windows.Forms.TextBox tbCLD;
        private System.Windows.Forms.TextBox tbSDD;
        private System.Windows.Forms.TextBox tbSC;
        private System.Windows.Forms.TextBox tbCL;
        private System.Windows.Forms.TextBox tbSD;
        private System.Windows.Forms.TextBox tbDP;
        private System.Windows.Forms.Button btRelleno;
        private System.Windows.Forms.TextBox tbDPD;
    }
}