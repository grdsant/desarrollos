﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class GrupoTemporada
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GrupoTemporada));
            this.panel01 = new System.Windows.Forms.Panel();
            this.tbStyDes = new System.Windows.Forms.TextBox();
            this.tbSty = new System.Windows.Forms.TextBox();
            this.tbPrvDes = new System.Windows.Forms.TextBox();
            this.tbPrv = new System.Windows.Forms.TextBox();
            this.tbSCD = new System.Windows.Forms.TextBox();
            this.tbCLD = new System.Windows.Forms.TextBox();
            this.tbDPD = new System.Windows.Forms.TextBox();
            this.tbSC = new System.Windows.Forms.TextBox();
            this.tbCL = new System.Windows.Forms.TextBox();
            this.tbSD = new System.Windows.Forms.TextBox();
            this.tbDP = new System.Windows.Forms.TextBox();
            this.tbDesTmpMms = new System.Windows.Forms.TextBox();
            this.tbSDD = new System.Windows.Forms.TextBox();
            this.tbTmpMms = new System.Windows.Forms.TextBox();
            this.tbTipo = new System.Windows.Forms.TextBox();
            this.btRelleno = new System.Windows.Forms.Button();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.detalleDelGrupoDeTemporadasTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.eliminarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.lbTitulo = new System.Windows.Forms.Label();
            this.btTemporadas = new System.Windows.Forms.Button();
            this.btJerarquias = new System.Windows.Forms.Button();
            this.btEstilos = new System.Windows.Forms.Button();
            this.lbTextMarca = new System.Windows.Forms.Label();
            this.lbMarca = new System.Windows.Forms.Label();
            this.lbTextDescripcion = new System.Windows.Forms.Label();
            this.lbTextTemporada = new System.Windows.Forms.Label();
            this.lbTemporada = new System.Windows.Forms.Label();
            this.lbDescripcion = new System.Windows.Forms.Label();
            this.pbSalir = new System.Windows.Forms.PictureBox();
            this.btProveedor = new System.Windows.Forms.Button();
            this.panel01.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.cmMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).BeginInit();
            this.SuspendLayout();
            // 
            // panel01
            // 
            this.panel01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel01.Controls.Add(this.tbStyDes);
            this.panel01.Controls.Add(this.tbSty);
            this.panel01.Controls.Add(this.tbPrvDes);
            this.panel01.Controls.Add(this.tbPrv);
            this.panel01.Controls.Add(this.tbSCD);
            this.panel01.Controls.Add(this.tbCLD);
            this.panel01.Controls.Add(this.tbDPD);
            this.panel01.Controls.Add(this.tbSC);
            this.panel01.Controls.Add(this.tbCL);
            this.panel01.Controls.Add(this.tbSD);
            this.panel01.Controls.Add(this.tbDP);
            this.panel01.Controls.Add(this.tbDesTmpMms);
            this.panel01.Controls.Add(this.tbSDD);
            this.panel01.Controls.Add(this.tbTmpMms);
            this.panel01.Controls.Add(this.tbTipo);
            this.panel01.Controls.Add(this.btRelleno);
            this.panel01.Controls.Add(this.tbDescripcion);
            this.panel01.Controls.Add(this.dgvGridView);
            this.panel01.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel01.Location = new System.Drawing.Point(0, 69);
            this.panel01.Name = "panel01";
            this.panel01.Size = new System.Drawing.Size(1240, 538);
            this.panel01.TabIndex = 0;
            // 
            // tbStyDes
            // 
            this.tbStyDes.Location = new System.Drawing.Point(1085, 6);
            this.tbStyDes.Name = "tbStyDes";
            this.tbStyDes.Size = new System.Drawing.Size(151, 20);
            this.tbStyDes.TabIndex = 15;
            this.tbStyDes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbStyDes_KeyPress);
            // 
            // tbSty
            // 
            this.tbSty.Location = new System.Drawing.Point(995, 6);
            this.tbSty.Name = "tbSty";
            this.tbSty.Size = new System.Drawing.Size(90, 20);
            this.tbSty.TabIndex = 14;
            this.tbSty.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSty_KeyPress);
            // 
            // tbPrvDes
            // 
            this.tbPrvDes.Location = new System.Drawing.Point(845, 6);
            this.tbPrvDes.Name = "tbPrvDes";
            this.tbPrvDes.Size = new System.Drawing.Size(150, 20);
            this.tbPrvDes.TabIndex = 13;
            this.tbPrvDes.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbPrvDes_KeyPress);
            // 
            // tbPrv
            // 
            this.tbPrv.Location = new System.Drawing.Point(805, 6);
            this.tbPrv.Name = "tbPrv";
            this.tbPrv.Size = new System.Drawing.Size(40, 20);
            this.tbPrv.TabIndex = 12;
            this.tbPrv.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbPrv_KeyPress);
            // 
            // tbSCD
            // 
            this.tbSCD.Location = new System.Drawing.Point(725, 6);
            this.tbSCD.Name = "tbSCD";
            this.tbSCD.Size = new System.Drawing.Size(80, 20);
            this.tbSCD.TabIndex = 11;
            this.tbSCD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSCD_KeyPress);
            // 
            // tbCLD
            // 
            this.tbCLD.Location = new System.Drawing.Point(645, 6);
            this.tbCLD.Name = "tbCLD";
            this.tbCLD.Size = new System.Drawing.Size(80, 20);
            this.tbCLD.TabIndex = 10;
            this.tbCLD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCLD_KeyPress);
            // 
            // tbDPD
            // 
            this.tbDPD.Location = new System.Drawing.Point(485, 6);
            this.tbDPD.Name = "tbDPD";
            this.tbDPD.Size = new System.Drawing.Size(80, 20);
            this.tbDPD.TabIndex = 8;
            this.tbDPD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDPD_KeyPress);
            // 
            // tbSC
            // 
            this.tbSC.Location = new System.Drawing.Point(445, 6);
            this.tbSC.Name = "tbSC";
            this.tbSC.Size = new System.Drawing.Size(40, 20);
            this.tbSC.TabIndex = 7;
            this.tbSC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSC_KeyPress);
            // 
            // tbCL
            // 
            this.tbCL.Location = new System.Drawing.Point(405, 6);
            this.tbCL.Name = "tbCL";
            this.tbCL.Size = new System.Drawing.Size(40, 20);
            this.tbCL.TabIndex = 6;
            this.tbCL.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCL_KeyPress);
            // 
            // tbSD
            // 
            this.tbSD.Location = new System.Drawing.Point(365, 6);
            this.tbSD.Name = "tbSD";
            this.tbSD.Size = new System.Drawing.Size(40, 20);
            this.tbSD.TabIndex = 5;
            this.tbSD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSD_KeyPress);
            // 
            // tbDP
            // 
            this.tbDP.Location = new System.Drawing.Point(325, 6);
            this.tbDP.Name = "tbDP";
            this.tbDP.Size = new System.Drawing.Size(40, 20);
            this.tbDP.TabIndex = 4;
            this.tbDP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDP_KeyPress);
            // 
            // tbDesTmpMms
            // 
            this.tbDesTmpMms.Location = new System.Drawing.Point(235, 6);
            this.tbDesTmpMms.Name = "tbDesTmpMms";
            this.tbDesTmpMms.Size = new System.Drawing.Size(90, 20);
            this.tbDesTmpMms.TabIndex = 3;
            this.tbDesTmpMms.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDesTmpMms_KeyPress);
            // 
            // tbSDD
            // 
            this.tbSDD.Location = new System.Drawing.Point(565, 6);
            this.tbSDD.Name = "tbSDD";
            this.tbSDD.Size = new System.Drawing.Size(80, 20);
            this.tbSDD.TabIndex = 9;
            this.tbSDD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSDD_KeyPress);
            // 
            // tbTmpMms
            // 
            this.tbTmpMms.Location = new System.Drawing.Point(195, 6);
            this.tbTmpMms.Name = "tbTmpMms";
            this.tbTmpMms.Size = new System.Drawing.Size(40, 20);
            this.tbTmpMms.TabIndex = 2;
            this.tbTmpMms.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTmpMms_KeyPress);
            // 
            // tbTipo
            // 
            this.tbTipo.Location = new System.Drawing.Point(45, 6);
            this.tbTipo.Name = "tbTipo";
            this.tbTipo.Size = new System.Drawing.Size(40, 20);
            this.tbTipo.TabIndex = 0;
            this.tbTipo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTipo_KeyPress);
            // 
            // btRelleno
            // 
            this.btRelleno.Location = new System.Drawing.Point(2, 5);
            this.btRelleno.Name = "btRelleno";
            this.btRelleno.Size = new System.Drawing.Size(44, 22);
            this.btRelleno.TabIndex = 99;
            this.btRelleno.UseVisualStyleBackColor = true;
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.Location = new System.Drawing.Point(85, 6);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(110, 20);
            this.tbDescripcion.TabIndex = 1;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress);
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.ContextMenuStrip = this.cmMenu;
            this.dgvGridView.Location = new System.Drawing.Point(3, 27);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.ReadOnly = true;
            this.dgvGridView.Size = new System.Drawing.Size(1233, 508);
            this.dgvGridView.TabIndex = 16;
            this.dgvGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellClick);
            this.dgvGridView.SelectionChanged += new System.EventHandler(this.dgvGridView_SelectionChanged);
            this.dgvGridView.DoubleClick += new System.EventHandler(this.dgvGridView_DoubleClick);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.detalleDelGrupoDeTemporadasTSMI,
            this.eliminarTSMI});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(225, 48);
            // 
            // detalleDelGrupoDeTemporadasTSMI
            // 
            this.detalleDelGrupoDeTemporadasTSMI.Name = "detalleDelGrupoDeTemporadasTSMI";
            this.detalleDelGrupoDeTemporadasTSMI.Size = new System.Drawing.Size(224, 22);
            this.detalleDelGrupoDeTemporadasTSMI.Text = "Detalle del Grupo nivel Estilo";
            this.detalleDelGrupoDeTemporadasTSMI.Click += new System.EventHandler(this.detalleDelGrupoDeTemporadasTSMI_Click);
            // 
            // eliminarTSMI
            // 
            this.eliminarTSMI.Name = "eliminarTSMI";
            this.eliminarTSMI.Size = new System.Drawing.Size(224, 22);
            this.eliminarTSMI.Text = "Eliminar";
            this.eliminarTSMI.Click += new System.EventHandler(this.eliminarTSMI_Click);
            // 
            // lbTitulo
            // 
            this.lbTitulo.AutoSize = true;
            this.lbTitulo.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbTitulo.Location = new System.Drawing.Point(8, 8);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(120, 21);
            this.lbTitulo.TabIndex = 33;
            this.lbTitulo.Text = "Agrupaciones";
            // 
            // btTemporadas
            // 
            this.btTemporadas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTemporadas.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btTemporadas.Image = ((System.Drawing.Image)(resources.GetObject("btTemporadas.Image")));
            this.btTemporadas.Location = new System.Drawing.Point(595, 8);
            this.btTemporadas.Name = "btTemporadas";
            this.btTemporadas.Size = new System.Drawing.Size(114, 39);
            this.btTemporadas.TabIndex = 20;
            this.btTemporadas.Text = "Temporadas";
            this.btTemporadas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btTemporadas.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btTemporadas.UseCompatibleTextRendering = true;
            this.btTemporadas.UseVisualStyleBackColor = true;
            this.btTemporadas.Click += new System.EventHandler(this.btTemporadas_Click);
            // 
            // btJerarquias
            // 
            this.btJerarquias.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btJerarquias.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btJerarquias.Image = ((System.Drawing.Image)(resources.GetObject("btJerarquias.Image")));
            this.btJerarquias.Location = new System.Drawing.Point(715, 8);
            this.btJerarquias.Name = "btJerarquias";
            this.btJerarquias.Size = new System.Drawing.Size(114, 39);
            this.btJerarquias.TabIndex = 21;
            this.btJerarquias.Text = "Jerarquias";
            this.btJerarquias.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btJerarquias.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btJerarquias.UseCompatibleTextRendering = true;
            this.btJerarquias.UseVisualStyleBackColor = true;
            this.btJerarquias.Click += new System.EventHandler(this.btJerarquias_Click);
            // 
            // btEstilos
            // 
            this.btEstilos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btEstilos.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btEstilos.Image = ((System.Drawing.Image)(resources.GetObject("btEstilos.Image")));
            this.btEstilos.Location = new System.Drawing.Point(835, 8);
            this.btEstilos.Name = "btEstilos";
            this.btEstilos.Size = new System.Drawing.Size(114, 39);
            this.btEstilos.TabIndex = 22;
            this.btEstilos.Text = "Estilos";
            this.btEstilos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btEstilos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btEstilos.UseCompatibleTextRendering = true;
            this.btEstilos.UseVisualStyleBackColor = true;
            this.btEstilos.Click += new System.EventHandler(this.btEstilos_Click);
            // 
            // lbTextMarca
            // 
            this.lbTextMarca.AutoSize = true;
            this.lbTextMarca.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTextMarca.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbTextMarca.Location = new System.Drawing.Point(-2, 45);
            this.lbTextMarca.Name = "lbTextMarca";
            this.lbTextMarca.Size = new System.Drawing.Size(58, 21);
            this.lbTextMarca.TabIndex = 39;
            this.lbTextMarca.Text = "Marca:";
            // 
            // lbMarca
            // 
            this.lbMarca.AutoSize = true;
            this.lbMarca.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMarca.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbMarca.Location = new System.Drawing.Point(54, 45);
            this.lbMarca.Name = "lbMarca";
            this.lbMarca.Size = new System.Drawing.Size(26, 21);
            this.lbMarca.TabIndex = 40;
            this.lbMarca.Text = "xx";
            // 
            // lbTextDescripcion
            // 
            this.lbTextDescripcion.AutoSize = true;
            this.lbTextDescripcion.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTextDescripcion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbTextDescripcion.Location = new System.Drawing.Point(182, 45);
            this.lbTextDescripcion.Name = "lbTextDescripcion";
            this.lbTextDescripcion.Size = new System.Drawing.Size(97, 21);
            this.lbTextDescripcion.TabIndex = 43;
            this.lbTextDescripcion.Text = "Descripción:";
            // 
            // lbTextTemporada
            // 
            this.lbTextTemporada.AutoSize = true;
            this.lbTextTemporada.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTextTemporada.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbTextTemporada.Location = new System.Drawing.Point(85, 45);
            this.lbTextTemporada.Name = "lbTextTemporada";
            this.lbTextTemporada.Size = new System.Drawing.Size(58, 21);
            this.lbTextTemporada.TabIndex = 41;
            this.lbTextTemporada.Text = "Grupo:";
            // 
            // lbTemporada
            // 
            this.lbTemporada.AutoSize = true;
            this.lbTemporada.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTemporada.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbTemporada.Location = new System.Drawing.Point(149, 45);
            this.lbTemporada.Name = "lbTemporada";
            this.lbTemporada.Size = new System.Drawing.Size(26, 21);
            this.lbTemporada.TabIndex = 42;
            this.lbTemporada.Text = "xx";
            // 
            // lbDescripcion
            // 
            this.lbDescripcion.AutoSize = true;
            this.lbDescripcion.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDescripcion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbDescripcion.Location = new System.Drawing.Point(286, 45);
            this.lbDescripcion.Name = "lbDescripcion";
            this.lbDescripcion.Size = new System.Drawing.Size(26, 21);
            this.lbDescripcion.TabIndex = 44;
            this.lbDescripcion.Text = "xx";
            // 
            // pbSalir
            // 
            this.pbSalir.Image = ((System.Drawing.Image)(resources.GetObject("pbSalir.Image")));
            this.pbSalir.Location = new System.Drawing.Point(1202, 15);
            this.pbSalir.Name = "pbSalir";
            this.pbSalir.Size = new System.Drawing.Size(23, 22);
            this.pbSalir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSalir.TabIndex = 45;
            this.pbSalir.TabStop = false;
            this.pbSalir.Click += new System.EventHandler(this.pbSalir_Click);
            // 
            // btProveedor
            // 
            this.btProveedor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btProveedor.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btProveedor.Image = ((System.Drawing.Image)(resources.GetObject("btProveedor.Image")));
            this.btProveedor.Location = new System.Drawing.Point(955, 8);
            this.btProveedor.Name = "btProveedor";
            this.btProveedor.Size = new System.Drawing.Size(114, 39);
            this.btProveedor.TabIndex = 24;
            this.btProveedor.Text = "Proveedor";
            this.btProveedor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btProveedor.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btProveedor.UseCompatibleTextRendering = true;
            this.btProveedor.UseVisualStyleBackColor = true;
            this.btProveedor.Click += new System.EventHandler(this.btProveedor_Click);
            // 
            // GrupoTemporada
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1240, 607);
            this.Controls.Add(this.btProveedor);
            this.Controls.Add(this.pbSalir);
            this.Controls.Add(this.lbDescripcion);
            this.Controls.Add(this.lbTemporada);
            this.Controls.Add(this.lbTextDescripcion);
            this.Controls.Add(this.lbTextTemporada);
            this.Controls.Add(this.lbMarca);
            this.Controls.Add(this.lbTextMarca);
            this.Controls.Add(this.btEstilos);
            this.Controls.Add(this.btJerarquias);
            this.Controls.Add(this.btTemporadas);
            this.Controls.Add(this.lbTitulo);
            this.Controls.Add(this.panel01);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GrupoTemporada";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GrupoTemporada";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.GrupoTemporada_FormClosing);
            this.Load += new System.EventHandler(this.GrupoTemporada_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.GrupoTemporada_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.GrupoTemporada_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.GrupoTemporada_MouseUp);
            this.panel01.ResumeLayout(false);
            this.panel01.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.cmMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel01;
        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.Label lbTitulo;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.Button btRelleno;
        private System.Windows.Forms.ToolStripMenuItem detalleDelGrupoDeTemporadasTSMI;
        private System.Windows.Forms.Button btTemporadas;
        private System.Windows.Forms.Button btJerarquias;
        private System.Windows.Forms.Button btEstilos;
        private System.Windows.Forms.Label lbTextMarca;
        private System.Windows.Forms.Label lbMarca;
        private System.Windows.Forms.Label lbTextDescripcion;
        private System.Windows.Forms.Label lbTextTemporada;
        private System.Windows.Forms.Label lbTemporada;
        private System.Windows.Forms.Label lbDescripcion;
        private System.Windows.Forms.PictureBox pbSalir;
        private System.Windows.Forms.ToolStripMenuItem eliminarTSMI;
        private System.Windows.Forms.Button btProveedor;
        private System.Windows.Forms.TextBox tbTmpMms;
        private System.Windows.Forms.TextBox tbTipo;
        private System.Windows.Forms.TextBox tbDesTmpMms;
        private System.Windows.Forms.TextBox tbSDD;
        private System.Windows.Forms.TextBox tbSCD;
        private System.Windows.Forms.TextBox tbCLD;
        private System.Windows.Forms.TextBox tbDPD;
        private System.Windows.Forms.TextBox tbSC;
        private System.Windows.Forms.TextBox tbCL;
        private System.Windows.Forms.TextBox tbSD;
        private System.Windows.Forms.TextBox tbDP;
        private System.Windows.Forms.TextBox tbStyDes;
        private System.Windows.Forms.TextBox tbSty;
        private System.Windows.Forms.TextBox tbPrvDes;
        private System.Windows.Forms.TextBox tbPrv;
    }
}