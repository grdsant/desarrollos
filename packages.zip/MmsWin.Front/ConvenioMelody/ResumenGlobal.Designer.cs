﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class ResumenGlobal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ResumenGlobal));
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.cmMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.detalleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbTitulo = new System.Windows.Forms.Label();
            this.pbSalir = new System.Windows.Forms.PictureBox();
            this.btQuitaChk = new System.Windows.Forms.Button();
            this.btPoneChks = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.cmMenuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.BackgroundColor = System.Drawing.Color.Silver;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.ContextMenuStrip = this.cmMenuStrip;
            this.dgvGridView.Location = new System.Drawing.Point(9, 40);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.Size = new System.Drawing.Size(673, 242);
            this.dgvGridView.TabIndex = 0;
            this.dgvGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellDoubleClick);
            this.dgvGridView.CellParsing += new System.Windows.Forms.DataGridViewCellParsingEventHandler(this.dgvGridView_CellParsing);
            this.dgvGridView.SelectionChanged += new System.EventHandler(this.dgvGridView_SelectionChanged);
            this.dgvGridView.Sorted += new System.EventHandler(this.dgvGridView_Sorted_1);
            this.dgvGridView.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dgvGridView_KeyPress);
            this.dgvGridView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvGridView_KeyUp);
            // 
            // cmMenuStrip
            // 
            this.cmMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.detalleToolStripMenuItem});
            this.cmMenuStrip.Name = "cmMenuStrip";
            this.cmMenuStrip.Size = new System.Drawing.Size(267, 26);
            // 
            // detalleToolStripMenuItem
            // 
            this.detalleToolStripMenuItem.Name = "detalleToolStripMenuItem";
            this.detalleToolStripMenuItem.Size = new System.Drawing.Size(266, 22);
            this.detalleToolStripMenuItem.Text = "Detalle de Calificación (nivel Tienda)";
            this.detalleToolStripMenuItem.Click += new System.EventHandler(this.detalleToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkGray;
            this.panel1.Location = new System.Drawing.Point(9, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(673, 44);
            this.panel1.TabIndex = 13;
            // 
            // lbTitulo
            // 
            this.lbTitulo.AutoSize = true;
            this.lbTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.Location = new System.Drawing.Point(13, 5);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(100, 13);
            this.lbTitulo.TabIndex = 14;
            this.lbTitulo.Text = "Resumen de Estilos";
            // 
            // pbSalir
            // 
            this.pbSalir.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pbSalir.BackColor = System.Drawing.Color.Gray;
            this.pbSalir.Image = ((System.Drawing.Image)(resources.GetObject("pbSalir.Image")));
            this.pbSalir.Location = new System.Drawing.Point(673, 6);
            this.pbSalir.Name = "pbSalir";
            this.pbSalir.Size = new System.Drawing.Size(15, 13);
            this.pbSalir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSalir.TabIndex = 12;
            this.pbSalir.TabStop = false;
            this.pbSalir.Click += new System.EventHandler(this.pbSalir_Click);
            // 
            // btQuitaChk
            // 
            this.btQuitaChk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btQuitaChk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btQuitaChk.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btQuitaChk.Image = global::MmsWin.Front.Properties.Resources.Unchecked_Checkbox_24px1;
            this.btQuitaChk.Location = new System.Drawing.Point(582, 21);
            this.btQuitaChk.Name = "btQuitaChk";
            this.btQuitaChk.Size = new System.Drawing.Size(82, 35);
            this.btQuitaChk.TabIndex = 8;
            this.btQuitaChk.Text = "Quitar Checks";
            this.btQuitaChk.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btQuitaChk.UseVisualStyleBackColor = false;
            this.btQuitaChk.Visible = false;
            this.btQuitaChk.Click += new System.EventHandler(this.btQuitaChk_Click);
            // 
            // btPoneChks
            // 
            this.btPoneChks.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btPoneChks.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btPoneChks.ForeColor = System.Drawing.Color.Green;
            this.btPoneChks.Image = global::MmsWin.Front.Properties.Resources.CheckedNo_Checkbox_24px;
            this.btPoneChks.Location = new System.Drawing.Point(508, 21);
            this.btPoneChks.Name = "btPoneChks";
            this.btPoneChks.Size = new System.Drawing.Size(75, 35);
            this.btPoneChks.TabIndex = 7;
            this.btPoneChks.Text = "Poner Checks";
            this.btPoneChks.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btPoneChks.UseVisualStyleBackColor = false;
            this.btPoneChks.Visible = false;
            this.btPoneChks.Click += new System.EventHandler(this.btPoneChks_Click);
            // 
            // ResumenGlobal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(694, 293);
            this.Controls.Add(this.lbTitulo);
            this.Controls.Add(this.pbSalir);
            this.Controls.Add(this.btQuitaChk);
            this.Controls.Add(this.btPoneChks);
            this.Controls.Add(this.dgvGridView);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ResumenGlobal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Resumen Global";
            this.Load += new System.EventHandler(this.ResumenGlobal_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ResumenGlobal_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ResumenGlobal_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ResumenGlobal_MouseUp);
            this.Resize += new System.EventHandler(this.ResumenGlobal_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.cmMenuStrip.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion
        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.ContextMenuStrip cmMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem detalleToolStripMenuItem;
        private System.Windows.Forms.Button btQuitaChk;
        private System.Windows.Forms.Button btPoneChks;
        private System.Windows.Forms.PictureBox pbSalir;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbTitulo;
    }
}