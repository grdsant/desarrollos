﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class GrupoTemporada : Form
    {
        #region Variables locales
        public static string marca        { get; set; }
        public static string grupo        { get; set; }
        public static string descripcion  { get; set; }
        public static string estatus      { get; set; }
        #endregion

        int nr = 0;
        string ParUser;
        bool Carga;

        int dgvOffset;
        int dgvOffset2;

        Point mousedownpoint = Point.Empty;

        public GrupoTemporada()
        {
            InitializeComponent();
            dgvOffset  = this.Width  - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }

        private void GrupoTemporada_Load(object sender, EventArgs e)
        {
            lbMarca.Text = MmsWin.Front.ConvenioMelody.GrupoTemporada.marca;
            lbTemporada.Text = MmsWin.Front.ConvenioMelody.GrupoTemporada.grupo;
            lbDescripcion.Text = MmsWin.Front.ConvenioMelody.GrupoTemporada.descripcion;

            Carga = true;
            BindData();
            // Seguridad...                                                                     
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("ConvenioMelody", "GrupoTemporada", ParUser);
            tbTipo.Focus();
        }

        // Carga Datos                                                                                    
        //
        protected void BindData()
        {
            if (Carga == true)
            {
                this.Cursor = Cursors.WaitCursor;
                nr = 0;
                dgvGridView.DataSource = null;
                System.Data.DataTable dtDatos = null;
                try
                {
                    //string marca   = tbMarca.Text;
                    //string tipo    = tbGrupo.Text;
                    string renglon = tbDescripcion.Text;

                    string tipo      = tbTipo.Text;
                    string desc = tbDescripcion.Text;
                    string tmpMms    = tbTmpMms.Text;
                    string desTmpMms = tbDesTmpMms.Text;
                    string dp     = tbDP.Text;
                    string sd     = tbSD.Text;
                    string cl     = tbCL.Text;
                    string sc     = tbSC.Text;
                    string dpd    = tbDPD.Text;
                    string sdd    = tbSDD.Text;
                    string cld    = tbCLD.Text;
                    string scd    = tbSCD.Text;
                    string prv    = tbPrv.Text;
                    string prvDes = tbPrvDes.Text;
                    string sty    = tbSty.Text;
                    string styDes = tbStyDes.Text; 

                    dtDatos = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenGrupoTemporadaPropia(
                    marca,
                    grupo,
                    tipo,     
                    desc,
                    tmpMms,    
                    desTmpMms, 
                    dp,    
                    sd,     
                    cl,     
                    sc,     
                    dpd,    
                    sdd,   
                    cld,   
                    scd,    
                    prv,    
                    prvDes, 
                    sty,   
                    styDes 
                    );
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                try
                {
                    if (dtDatos.Rows.Count > 0)
                    {
                        SetDoubleBuffered(dgvGridView);
                        dgvGridView.DataSource = null;
                        dgvGridView.DataSource = dtDatos;
                        nr = dgvGridView.RowCount;
                        lbTitulo.Text = "Grupos / "+ (nr).ToString();
                        SetFontAndColors();
                        rowStyle();

                        // Seguridad...                                                                     
                        ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        Seguridad("ConvenioMelody", "GrupoTemporada", ParUser);
                        tbTipo.Focus();
                    }
                }
                catch { }
                

                this.Cursor = Cursors.Default;
            }
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        // Atributos y caracteristicas                                                                    
        //
        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.WhiteSmoke;
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new Font(dgvGridView.ColumnHeadersDefaultCellStyle.Font, FontStyle.Bold);

            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Olive;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.WhiteSmoke;
            this.dgvGridView.RowsDefaultCellStyle.BackColor = Color.Gray;
            this.dgvGridView.RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty;
            this.dgvGridView.RowHeadersDefaultCellStyle.BackColor = Color.Gray;
            this.dgvGridView.Columns[1].Frozen = true;

            dgvGridView.Columns["GTPMAR"].HeaderText = "Marca";
            dgvGridView.Columns["GTPGPO"].HeaderText = "Grupo";
            dgvGridView.Columns["GTPREN"].HeaderText = "Renglon";
            dgvGridView.Columns["GTPSEC"].HeaderText = "Secuencia";
            dgvGridView.Columns["GTPTPO"].HeaderText = "Tipo";
            dgvGridView.Columns["GTPTPD"].HeaderText = "Descripción";
            dgvGridView.Columns["GTPTMP"].HeaderText = "Temporada Mms";
            dgvGridView.Columns["GTPDES"].HeaderText = "Descripción";

            dgvGridView.Columns["GTPDP"].HeaderText = "DP";
            dgvGridView.Columns["GTPSD"].HeaderText = "SD";
            dgvGridView.Columns["GTPCL"].HeaderText = "CL";
            dgvGridView.Columns["GTPSC"].HeaderText = "SC";

            dgvGridView.Columns["GTPDPD"].HeaderText = "Departamento";
            dgvGridView.Columns["GTPSDD"].HeaderText = "Sub Depto";
            dgvGridView.Columns["GTPCLD"].HeaderText = "Clase";
            dgvGridView.Columns["GTPSCD"].HeaderText = "Sub Clase";

            dgvGridView.Columns["GTPPRV"].HeaderText = "Proveedor";
            dgvGridView.Columns["GTPDPR"].HeaderText = "Nombre";

            dgvGridView.Columns["GTPSTY"].HeaderText = "Estilo";
            dgvGridView.Columns["GTPDST"].HeaderText = "Descripción";

            dgvGridView.Columns["GTPSTS"].HeaderText = "Estatus";

            dgvGridView.Columns["GTPUSR"].HeaderText = "Usuario Alta";
            dgvGridView.Columns["GTPFCH"].HeaderText = "Fecha Alta";
            dgvGridView.Columns["GTPHOR"].HeaderText = "Hora Alta";

            dgvGridView.Columns["GTPUCA"].HeaderText = "Usuario Cambio";
            dgvGridView.Columns["GTPFCA"].HeaderText = "Fecha Cambio";
            dgvGridView.Columns["GTPHCA"].HeaderText = "Hora Cambio";

            dgvGridView.Columns["GTPMAR"].Width = 40;
            dgvGridView.Columns["GTPGPO"].Width = 40;
            dgvGridView.Columns["GTPREN"].Width = 40;
            dgvGridView.Columns["GTPSEC"].Width = 40;
            dgvGridView.Columns["GTPTPO"].Width = 40;
            dgvGridView.Columns["GTPTPD"].Width = 110;
            dgvGridView.Columns["GTPTMP"].Width = 40;
            dgvGridView.Columns["GTPDES"].Width = 90;

            dgvGridView.Columns["GTPDP"].Width = 40;
            dgvGridView.Columns["GTPSD"].Width = 40;
            dgvGridView.Columns["GTPCL"].Width = 40;
            dgvGridView.Columns["GTPSC"].Width = 40;

            dgvGridView.Columns["GTPDPD"].Width = 80;
            dgvGridView.Columns["GTPSDD"].Width = 80;
            dgvGridView.Columns["GTPCLD"].Width = 80;
            dgvGridView.Columns["GTPSCD"].Width = 80;

            dgvGridView.Columns["GTPPRV"].Width = 40;
            dgvGridView.Columns["GTPDPR"].Width = 150;

            dgvGridView.Columns["GTPSTY"].Width = 90;
            dgvGridView.Columns["GTPDST"].Width = 150;

            dgvGridView.Columns["GTPSTS"].Width = 30;

            dgvGridView.Columns["GTPUSR"].Width = 70;
            dgvGridView.Columns["GTPFCH"].Width = 80;
            dgvGridView.Columns["GTPHOR"].Width = 80;

            dgvGridView.Columns["GTPUCA"].Width = 70;
            dgvGridView.Columns["GTPFCA"].Width = 80;
            dgvGridView.Columns["GTPHCA"].Width = 80;

            dgvGridView.Columns["GTPMAR"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["GTPGPO"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["GTPREN"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["GTPSEC"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["GTPTPO"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["GTPTPD"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["GTPTMP"].HeaderCell.Style.BackColor = Color.LightSalmon;
            dgvGridView.Columns["GTPDES"].HeaderCell.Style.BackColor = Color.LightSalmon;

            dgvGridView.Columns["GTPDP"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns["GTPSD"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns["GTPCL"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns["GTPSC"].HeaderCell.Style.BackColor = Color.LightGreen;

            dgvGridView.Columns["GTPDPD"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            dgvGridView.Columns["GTPSDD"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            dgvGridView.Columns["GTPCLD"].HeaderCell.Style.BackColor = Color.LightSeaGreen;
            dgvGridView.Columns["GTPSCD"].HeaderCell.Style.BackColor = Color.LightSeaGreen;

            dgvGridView.Columns["GTPPRV"].HeaderCell.Style.BackColor = Color.LightSlateGray;
            dgvGridView.Columns["GTPDPR"].HeaderCell.Style.BackColor = Color.LightSlateGray;

            dgvGridView.Columns["GTPSTY"].HeaderCell.Style.BackColor = Color.LightCoral;
            dgvGridView.Columns["GTPDST"].HeaderCell.Style.BackColor = Color.LightCoral;

            dgvGridView.Columns["GTPSTS"].HeaderCell.Style.BackColor = Color.LightGreen;

            dgvGridView.Columns["GTPUSR"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns["GTPFCH"].HeaderCell.Style.BackColor = Color.LightSkyBlue;
            dgvGridView.Columns["GTPHOR"].HeaderCell.Style.BackColor = Color.LightSkyBlue;

            dgvGridView.Columns["GTPUCA"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns["GTPFCA"].HeaderCell.Style.BackColor = Color.LightGreen;
            dgvGridView.Columns["GTPHCA"].HeaderCell.Style.BackColor = Color.LightGreen;

            dgvGridView.Columns["GTPMAR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["GTPGPO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["GTPREN"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["GTPSEC"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["GTPTPO"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["GTPTPD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["GTPTMP"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["GTPDES"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            dgvGridView.Columns["GTPDP"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["GTPSD"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["GTPCL"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["GTPSC"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns["GTPDPD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["GTPSDD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["GTPCLD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["GTPSCD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            dgvGridView.Columns["GTPPRV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["GTPDPR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            dgvGridView.Columns["GTPSTY"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["GTPDST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;

            dgvGridView.Columns["GTPSTS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns["GTPUSR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["GTPFCH"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["GTPHOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns["GTPUSR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["GTPFCH"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["GTPHOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns["GTPFCH"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns["GTPHOR"].DefaultCellStyle.Format = "##:##:##";

            dgvGridView.Columns["GTPFCA"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns["GTPHCA"].DefaultCellStyle.Format = "##:##:##";

            dgvGridView.Columns["GTPREN"].Visible = false;
            dgvGridView.Columns["GTPSEC"].Visible = false;
        }
        // Estilo de Renglones                                                                            
        //
        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                //if (vez == "Si")
                //{
                //    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                //    vez = "No";
                //}
                //else
                //{
                //    vez = "Si";
                //}
            }
        }

        // Seguridad                                                                                 
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab    = row["SEGHAC"].ToString();
                string ValVis    = row["SEGVIC"].ToString();
                string tipo      = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                          
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "0") { valorHab = true; }
                    dgvGridView.Columns[Controles].ReadOnly = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    dgvGridView.Columns[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }
                    cmMenu.Items[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    cmMenu.Items[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
        }

        private void GrupoTemporada_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void GrupoTemporada_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedownpoint.IsEmpty)
                return;
            Form f = sender as Form;
            f.Location = new Point(f.Location.X + (e.X - mousedownpoint.X), f.Location.Y + (e.Y - mousedownpoint.Y));
        }

        private void GrupoTemporada_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

        private void btABC_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
            //                  "DetCatTempABC").SingleOrDefault<Form>();
            //    {
            //        if (existe != null)
            //        {
            //            MessageBox.Show("Las ventana de tablas de Despalzamiento esta abierta...");
            //        }
            //        else
            //        {
            //            MmsWin.Front.ConvenioMelody.DetCatTempABC.marca       = "";
            //            MmsWin.Front.ConvenioMelody.DetCatTempABC.grupo       = "";
            //            MmsWin.Front.ConvenioMelody.DetCatTempABC.descripcion = "";
            //            MmsWin.Front.ConvenioMelody.DetCatTempABC.estatus     = "";

            //            MmsWin.Front.ConvenioMelody.DetCatTempABC.userAlta    = "";
            //            MmsWin.Front.ConvenioMelody.DetCatTempABC.fechaAlta   = "";
            //            MmsWin.Front.ConvenioMelody.DetCatTempABC.horaAlta    = "";
            //            MmsWin.Front.ConvenioMelody.DetCatTempABC.userCambio  = "";
            //            MmsWin.Front.ConvenioMelody.DetCatTempABC.fechaCambio = "";
            //            MmsWin.Front.ConvenioMelody.DetCatTempABC.horaCambio  = "";

            //            GrupoTemporadaABC i = new GrupoTemporadaABC();
            //            //i.MdiParent = this.MdiParent;
            //            i.Show();
            //        }
            //    }
            //}
            //catch { }
            //finally { }
        }

        private void GrupoTemporada_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("ConvenioMelody", "GrupoTemporada", ParUser);
            }
        }
        // Carga Seguridad                                                                                
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            // Controles                                                                  
            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            string NomCol;
            Int32 NoCol = dgvGridView.ColumnCount;
            for (int i = 0; i < NoCol; i++)
            {
                NomCol = dgvGridView.Columns[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomCol;
                workRow["Tipo"] = "Columna";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Menu                                                                      
            string NomMenu;
            Int32 NoItems = cmMenu.Items.Count;
            for (int i = 0; i < NoItems; i++)
            {
                NomMenu = cmMenu.Items[i].Name.ToString();

                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = NomMenu;
                workRow["Tipo"] = "Menu";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void dgvGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            cargaVariables();
        }

        private void cargaVariables()
        {
            try
            {
                // Guarda varibles de pantalla

                MmsWin.Front.ConvenioMelody.DetCatTempABC.marca = this.dgvGridView.CurrentRow.Cells["COMMAR"].Value.ToString();
                MmsWin.Front.ConvenioMelody.DetCatTempABC.grupo = this.dgvGridView.CurrentRow.Cells["COMTPP"].Value.ToString();
                MmsWin.Front.ConvenioMelody.DetCatTempABC.descripcion = this.dgvGridView.CurrentRow.Cells["COMDES"].Value.ToString();
                MmsWin.Front.ConvenioMelody.DetCatTempABC.estatus = this.dgvGridView.CurrentRow.Cells["COMSTS"].Value.ToString();

                MmsWin.Front.ConvenioMelody.DetCatTempABC.userAlta = this.dgvGridView.CurrentRow.Cells["COMUAL"].Value.ToString();

                string FechaCal = this.dgvGridView.CurrentRow.Cells["COMFAL"].Value.ToString();
                string FechaFmt = "20" + FechaCal.Substring(0, 2) + "/" + FechaCal.Substring(2, 2) + "/" + FechaCal.Substring(4, 2);
                MmsWin.Front.ConvenioMelody.DetCatTempABC.fechaAlta = FechaFmt;

                string HoraCal = this.dgvGridView.CurrentRow.Cells["COMHAL"].Value.ToString();
                string HoraFmt = HoraCal.Substring(0, 2) + ":" + HoraCal.Substring(2, 2) + ":" + HoraCal.Substring(4, 2);
                MmsWin.Front.ConvenioMelody.DetCatTempABC.horaAlta = HoraFmt;

                MmsWin.Front.ConvenioMelody.DetCatTempABC.userCambio = this.dgvGridView.CurrentRow.Cells["COMUCA"].Value.ToString();
                MmsWin.Front.ConvenioMelody.DetCatTempABC.fechaCambio = this.dgvGridView.CurrentRow.Cells["COMFCA"].Value.ToString();
                MmsWin.Front.ConvenioMelody.DetCatTempABC.horaCambio = this.dgvGridView.CurrentRow.Cells["COMHCA"].Value.ToString();

                dgvGridView.Columns["COMUAL"].HeaderText = "Usuario";
                dgvGridView.Columns["COMFAL"].HeaderText = "Fecha Alta";
                dgvGridView.Columns["COMHAL"].HeaderText = "Hora alta";
                dgvGridView.Columns["COMUCA"].HeaderText = "Usuario Cambio";
                dgvGridView.Columns["COMFCA"].HeaderText = "Fecha Cambio";
                dgvGridView.Columns["COMHCA"].HeaderText = "Hora Cambio";
            }
            catch { }
        }

        private void dgvGridView_SelectionChanged(object sender, EventArgs e)
        {
            cargaVariables();
        }

        private void ConsultarTSMI_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
            //                  "GrupoTemporadaABC").SingleOrDefault<Form>();
            //    {
            //        if (existe != null)
            //        {
            //            MessageBox.Show("Las ventana de tablas de Despalzamiento esta abierta...");
            //        }
            //        else
            //        {
            //            GrupoTemporadaABC i = new GrupoTemporadaABC();

            //            i.Show();
            //        }
            //    }
            //}
            //catch { }
            //finally { }
        }

        private void dgvGridView_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "DetCatTempABC").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de tablas de Despalzamiento esta abierta...");
                    }
                    else
                    {
                        DetCatTempABC i = new DetCatTempABC();
                        //i.MdiParent = this.MdiParent;
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        //private void tbMarca_KeyPress_1(object sender, KeyPressEventArgs e)
        //{
        //    if (e.KeyChar == (char)Keys.Enter)
        //    {
        //        BindData();
        //        tbMarca.Focus();
        //    }
        //}

        //private void tbTemporada_KeyPress(object sender, KeyPressEventArgs e)
        //{
        //    if (e.KeyChar == (char)Keys.Enter)
        //    {
        //        BindData();
        //        tbGrupo.Focus();
        //    }
        //}

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbDescripcion.Focus();
            }
        }

        private void detalleTSMI_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "GrupoTemporada").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de detalle de Temporadas esta abierta...");
                    }
                    else
                    {
                        GrupoTemporada i = new GrupoTemporada();
                        //i.MdiParent = this.MdiParent;
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void detalleDelGrupoDeTemporadasTSMI_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "DetalleTemporada").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de detalle de Temporadas esta abierta...");
                    }
                    else
                    {
                        DetalleTemporada i = new DetalleTemporada();
                        //i.MdiParent = this.MdiParent;
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void btTemporadas_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Temporadas").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de Temporadas esta abierta...");
                    }
                    else
                    {
                        Temporadas i = new Temporadas();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void btJerarquias_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Jerarquias").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de Jerarquias esta abierta...");
                    }
                    else
                    {
                        Jerarquias i = new Jerarquias();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void btEstilos_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Estilos").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de Estilos esta abierta...");
                    }
                    else
                    {
                        Estilos i = new Estilos();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void eliminarTSMI_Click(object sender, EventArgs e)
        {
            string message = "Esta seguro de elimiar los registros seleccionados?";
            string caption = "Confirmación";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                string mensaje = string.Empty;

                try
                {
                    System.Data.DataTable dtGrupos = new System.Data.DataTable("Grupos");
                    dtGrupos.Columns.Add("marca", typeof(String));
                    dtGrupos.Columns.Add("grupo", typeof(String));
                    dtGrupos.Columns.Add("renglon", typeof(String));
                    dtGrupos.Columns.Add("secuencia", typeof(String));

                    DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
                    foreach (DataGridViewRow item in Seleccionados)
                    {
                        DataRow workRow = dtGrupos.NewRow();

                        workRow["marca"] = item.Cells["GTPMAR"].Value.ToString();
                        workRow["grupo"] = item.Cells["GTPGPO"].Value.ToString();
                        workRow["renglon"] = item.Cells["GTPREN"].Value.ToString();
                        workRow["secuencia"] = item.Cells["GTPSEC"].Value.ToString();

                        dtGrupos.Rows.Add(workRow);
                    }

                    if (dtGrupos.Rows.Count > 0)
                    {
                        string usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        mensaje = MmsWin.Negocio.Catalogos.Grupos.GetInstance().EliminaGrupos(dtGrupos);
                        MessageBox.Show(mensaje);
                        BindData();
                    }
                    else
                    {
                        MessageBox.Show("Debe seleccionar un(os) grupo(s).");
                    }
                }
                catch { }
                finally { }
            }

        }

        private void btProveedor_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Proveedores").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de Estilos esta abierta...");
                    }
                    else
                    {
                        Proveedores i = new Proveedores();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void tbTipo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbTipo.Focus();
            }
        }

        private void tbTmpMms_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbTmpMms.Focus();
            }
        }

        private void tbDesTmpMms_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbDesTmpMms.Focus();
            }
        }

        private void tbDP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbDP.Focus();
            }
        }

        private void tbSD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbSD.Focus();
            }
        }

        private void tbCL_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbCL.Focus();
            }
        }

        private void tbSC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbSC.Focus();
            }
        }

        private void tbDPD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbDPD.Focus();
            }
        }

        private void tbSDD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbSDD.Focus();
            }
        }

        private void tbCLD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbCLD.Focus();
            }
        }

        private void tbSCD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbSCD.Focus();
            }
        }

        private void tbPrv_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbPrv.Focus();
            }
        }

        private void tbPrvDes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbPrvDes.Focus();
            }
        }

        private void tbSty_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbSty.Focus();
            }
        }

        private void tbStyDes_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindData();
                tbStyDes.Focus();
            }
        }

    }
}
