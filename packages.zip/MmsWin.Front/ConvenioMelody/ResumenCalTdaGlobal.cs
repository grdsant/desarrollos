﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using MmsWin.Front.Convenio;
using System.Windows.Forms;
using MmsWin.Front.Utilerias;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class ResumenCalTdaGlobal : Form
    {
        #region Variables
        // variables de la Ventana
        public static string parTemporada;
        public static string parTipoCalificacion;
        public static string parFchCalificacion;
        public static string parFchInicial;
        public static string parProveedor;
        public static string parNombre;
        public static string parEstilo;
        public static string parDescripcion;
        #endregion

        #region Grid
        // variables de la Ventana
        public static string gridMarca;
        public static string gridFechaCalifica;
        public static string gridTipoCalifica;
        public static string gridTemporada;
        public static string gridTabla;
        public static string gridProveedor;
        public static string gridEstilo;
        public static string gridOrden;
        #endregion

        int nr;
        bool Carga;
        String ParUser;
        string marca;
        string comprador;

        int dgvOffset;
        int dgvOffset2;

        public static string parCalificacion;
        public static string parCalificacionOriginal;

        String FchDe;
        String FchHas;

        string Seleccion = string.Empty;

        Point mousedownpoint = Point.Empty;

        public static string romperForeach = "No";
        public static string siHuboRebaja  = "No";
        public static string parMarca;
        public static string parFchDesde;
        public static string parFchHasta;
        public static string ParFchBon;
        public static string parOrigen;
        public static DataTable dtDiferenciados { get; set; }
        public static string parComprador;

        public ResumenCalTdaGlobal()
        {
            InitializeComponent();
            dgvOffset = this.Width - dgvGridView.Width;
            dgvOffset2 = this.Height - dgvGridView.Height;
        }

        private void ResumenCalTdaGlobal_Load(object sender, EventArgs e)
        {
        #region Variables
            // variables de la Ventana
            MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.parTemporada        = string.Empty;
            MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.parTipoCalificacion = string.Empty;
            MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.parFchCalificacion  = string.Empty;
            MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.parFchInicial       = string.Empty;
            MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.parProveedor        = string.Empty;
            MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.parNombre           = string.Empty;
            MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.parEstilo           = string.Empty;
            MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.parDescripcion      = string.Empty;
        #endregion
            Point mousedownpoint = Point.Empty;
            Carga     = false;
            marca     = "999";
            comprador = "999";

            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;

            try
            {
                System.Data.DataTable tbFechaInicial = null;
                tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();
            }
            catch (Exception ex)
            {
                throw ex;
            }

            try
            {
                Carga = true;
                BinData();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void BinData()
        {
            if (Carga == true)
            {
                EliminacheckBox();
                nr = 0;
                System.Data.DataTable dtCalificacionesTda = null;
                try
                {
                    this.Cursor = Cursors.WaitCursor;

                    string tipo      = string.Empty;
                    string temporada = string.Empty;
                    string tabla     = string.Empty;

                    string FchDe = string.Empty;
                    string FchHas = string.Empty;

                    marca               = MmsWin.Front.Utilerias.VarTem.parmarca;
                    comprador           = MmsWin.Front.Utilerias.VarTem.parcomprador;
                    FchDe               = MmsWin.Front.Utilerias.VarTem.parFchDe;
                    FchHas              = MmsWin.Front.Utilerias.VarTem.parFchHas;
                    tipo                = MmsWin.Front.Utilerias.VarTem.partipo;
                    temporada           = MmsWin.Front.Utilerias.VarTem.partemporada;
                    parTipoCalificacion = MmsWin.Front.Utilerias.VarTem.parTipoCalificacion;
                    parFchCalificacion  = MmsWin.Front.Utilerias.VarTem.parFchCalificacion;
                    parProveedor        = MmsWin.Front.Utilerias.VarTem.parProveedor;
                    parNombre           = MmsWin.Front.Utilerias.VarTem.parNombre;
                    parEstilo           = MmsWin.Front.Utilerias.VarTem.parEstilo;
                    parDescripcion      = MmsWin.Front.Utilerias.VarTem.parDescripcion;

                    string tipoconsulta = MmsWin.Front.ConvenioMelody.CalificacionGrid.parTipoConsulta;
                    if (tipoconsulta == "GlobalTda")
                    {
                        parProveedor = string.Empty;
                        parEstilo    = string.Empty;
                    }

                    string usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                    dtCalificacionesTda = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().EjecutaConsultaTda(marca, comprador, FchDe, FchHas, tipo, temporada, parTipoCalificacion, parFchCalificacion, parProveedor, parNombre, parEstilo, parDescripcion, usuario);
                    dgvGridView.DataSource = null;
                    try
                    {
                        if (dtCalificacionesTda.Rows.Count > 0)
                        {
                            SetDoubleBuffered(dgvGridView);
                            dgvGridView.DataSource = null;
                            dgvGridView.DataSource = dtCalificacionesTda;
                            nr = dgvGridView.RowCount;
                            this.Text = "Resumen por Estilos y Tiendas" + " " + (nr - 1).ToString() + " Registro(s)";
                            dgvGridView.DataSource = dtCalificacionesTda;
                            CreaCheckBox();
                            SetFontAndColors();
                            rowStyle();
                            dgvGridView.Focus();
                            dgvGridView.Select();
                            dgvGridView.CurrentCell = dgvGridView.Rows[0].Cells[3];
                            //this.dgvGridView.Sort(this.dgvGridView.Columns[0],
                            //ListSortDirection.Ascending);
                        }
                    }
                    catch
                    {
                        MessageBox.Show("No hay registros Cargados...verifique la seleccion.");
                    }

                    this.Cursor = Cursors.Default;
                }

                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        private void SetFontAndColors()
        {
            int i = 0;
            try
            {
                this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                this.dgvGridView.EnableHeadersVisualStyles = false;
                this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
                this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
                this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
                this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
                this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
                //this.dgvGridView.RowHeadersVisible = false;
                //this.dgvGridView.Columns["MDYSTY"].Frozen = true;
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                dgvGridView.Columns["RSMCAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["RSMNTD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["RSMNST"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["RSMINV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgvGridView.Columns["RSMPOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["RSMUSR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["RSMFCH"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dgvGridView.Columns["RSMHOR"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                dgvGridView.Columns["RSMCAL"].Width = 100;
                dgvGridView.Columns["RSMNTD"].Width = 60;
                dgvGridView.Columns["RSMNST"].Width = 60;
                dgvGridView.Columns["RSMINV"].Width = 80;
                dgvGridView.Columns["RSMPOR"].Width = 80;
                dgvGridView.Columns["RSMUSR"].Width = 80;
                dgvGridView.Columns["RSMFCH"].Width = 80;
                dgvGridView.Columns["RSMHOR"].Width = 80;

                dgvGridView.Columns["RSMCAL"].HeaderText  = "Calificación";
                dgvGridView.Columns["RSMNTD"].HeaderText  = "Tiendas Calificadas";
                dgvGridView.Columns["RSMNST"].HeaderText  = "Estilos";
                dgvGridView.Columns["RSMINV"].HeaderText  = "Inventario";
                dgvGridView.Columns["RSMPOR"].HeaderText  = "         % ";
                dgvGridView.Columns["RSMUSR"].HeaderText  = "Usuario";
                dgvGridView.Columns["RSMFCH"].HeaderText  = "Fecha";
                dgvGridView.Columns["RSMHOR"].HeaderText  = "Hora";
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                dgvGridView.Columns["RSMNTD"].DefaultCellStyle.Format = "###,##0";
                dgvGridView.Columns["RSMNST"].DefaultCellStyle.Format = "###,##0";
                dgvGridView.Columns["RSMINV"].DefaultCellStyle.Format = "#,###,##0";
                dgvGridView.Columns["RSMPOR"].DefaultCellStyle.Format = "##.00%";
                // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
                dgvGridView.Columns["RSMCAL"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RSMCAL"].HeaderCell.Style.ForeColor = Color.White;

                dgvGridView.Columns["RSMNTD"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RSMNTD"].HeaderCell.Style.ForeColor = Color.White;

                dgvGridView.Columns["RSMNST"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RSMNST"].HeaderCell.Style.ForeColor = Color.White;

                dgvGridView.Columns["RSMINV"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RSMINV"].HeaderCell.Style.ForeColor = Color.White;

                dgvGridView.Columns["RSMPOR"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RSMPOR"].HeaderCell.Style.ForeColor = Color.White;

                dgvGridView.Columns["RSMUSR"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RSMUSR"].HeaderCell.Style.ForeColor = Color.White;

                dgvGridView.Columns["RSMFCH"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RSMFCH"].HeaderCell.Style.ForeColor = Color.White;

                dgvGridView.Columns["RSMHOR"].HeaderCell.Style.BackColor = Color.LightSlateGray;
                dgvGridView.Columns["RSMHOR"].HeaderCell.Style.ForeColor = Color.White;

                dgvGridView.Columns["RSMPOR"].Visible  = false;
                dgvGridView.Columns["RSMUSR"].Visible  = false;
                dgvGridView.Columns["RSMFCH"].Visible  = false;
                dgvGridView.Columns["RSMHOR"].Visible  = false;
                //dgvGridView.Columns["COMPRAS"].Visible = false;
            }
            catch { }
        }

        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                dgvGridView.Select();

                // Pagar
                if (Convert.ToString(rowp.Cells["RSMCAL"].Value) == "P a g a r") { rowp.Cells["RSMCAL"].Style.BackColor = Color.LightGreen; }
                // 10%
                if (Convert.ToString(rowp.Cells["RSMCAL"].Value) == "10%") { rowp.Cells["RSMCAL"].Style.BackColor = Color.Yellow; }
                // 15%
                if (Convert.ToString(rowp.Cells["RSMCAL"].Value) == "15%") { rowp.Cells["RSMCAL"].Style.BackColor = Color.Yellow; }
                // 20%
                if (Convert.ToString(rowp.Cells["RSMCAL"].Value) == "20%") { rowp.Cells["RSMCAL"].Style.BackColor = Color.Yellow; }
                // 25%
                if (Convert.ToString(rowp.Cells["RSMCAL"].Value) == "25%") { rowp.Cells["RSMCAL"].Style.BackColor = Color.Yellow; }
                // 30%
                if (Convert.ToString(rowp.Cells["RSMCAL"].Value) == "30%") { rowp.Cells["RSMCAL"].Style.BackColor = Color.LightSalmon; }
                // 35%
                if (Convert.ToString(rowp.Cells["RSMCAL"].Value) == "35%") { rowp.Cells["RSMCAL"].Style.BackColor = Color.LightSalmon; }
                // 40%
                if (Convert.ToString(rowp.Cells["RSMCAL"].Value) == "40%") { rowp.Cells["RSMCAL"].Style.BackColor = Color.LightSalmon; }
                //Dev o 50%
                if (Convert.ToString(rowp.Cells["RSMCAL"].Value) == "50%") { rowp.Cells["RSMCAL"].Style.BackColor = Color.Red; rowp.Cells["RSMCAL"].Style.ForeColor = Color.White; }
                //Dev o 50%
                if (Convert.ToString(rowp.Cells["RSMCAL"].Value) == "50%") { rowp.Cells["RSMCAL"].Style.BackColor = Color.Red; rowp.Cells["RSMCAL"].Style.ForeColor = Color.White; }
                // Devolucion
                if (Convert.ToString(rowp.Cells["RSMCAL"].Value) == "Devolución") { rowp.Cells["RSMCAL"].Style.BackColor = Color.Red; rowp.Cells["RSMCAL"].Style.ForeColor = Color.White; }

                Regs += 1;
                if (vez == "Si")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.WhiteSmoke;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }

                if ((Convert.ToString((rowp.Cells[0].Value))) == "Total")
                {
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.LightSlateGray;
                    dgvGridView.Rows[Regs - 1].DefaultCellStyle.ForeColor = Color.White;  
            
                    // Totales por columna                                      
                    int tot31 = dgvGridView.Rows.Cast<DataGridViewRow>()
                    .Sum(t => Convert.ToInt32(t.Cells[3].Value));
                    rowp.Cells[3].Value = tot31;
                }
            }
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        private void ResumenCalTdaGlobal_Resize(object sender, EventArgs e)
        {
            dgvGridView.Width = this.Width - dgvOffset;
            dgvGridView.Height = this.Height - dgvOffset2;
        }

        private void dgvGridView_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                BinData();
                dgvGridView.Focus();
                dgvGridView.Select();
            }
        }

        private void dgvGridView_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                SendKeys.Send("{UP}");
                SendKeys.Flush();
            }
        }

        private void cbMarca_SelectedValueChanged(object sender, EventArgs e)
        {
            marca = " ";
            ComboBox cmbMarca = (ComboBox)sender;
            marca = cmbMarca.SelectedValue.ToString();
            BinData();
        }

        private void tbTipoCalificacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void tbFchCalificacion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void tbProveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void tbNombre_KeyPress_1(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
            }
        }

        private void dgvGridView_Sorted(object sender, EventArgs e)
        {
            rowStyle();
        }

        private void cbComprador_SelectedValueChanged(object sender, EventArgs e)
        {
            comprador = " ";
            nr = 0;
            ComboBox cmbComprador = (ComboBox)sender;
            comprador = cmbComprador.SelectedValue.ToString();
            MmsWin.Front.Utilerias.VarTem.tmpComprador = cmbComprador.SelectedValue.ToString();

            BinData();
        }

        private void fotoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MuestraFoto();
        }

        private void MuestraFoto()
        {
            try
            {
                Fotos i = new Fotos();
                i.Show();
            }
            catch { }
            finally { }
        }

        private void dgvGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            dgvGridView.Select();
            dgvGridView.Focus();
            Kardex();
        }

        private void Kardex()
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Kardex").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del Kardex ya esta abierta");
                    }
                    else
                    {
                        Kardex i = new Kardex();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void tbTabla_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbTipoCalificacion.Focus();
            }
        }

        private void tbTemporada_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BinData();
                //tbTipoCalificacion.Focus();
            }
        }

        private void dgvGridView_CellParsing(object sender, DataGridViewCellParsingEventArgs e)
        {
            int Row = e.RowIndex;
            int Col = e.ColumnIndex;
            string campo         = string.Empty;
            string checkBox      = string.Empty;
            string observaciones = string.Empty;
            string usuario       = string.Empty;
            string fechaUser     = string.Empty;
            string horaUser      = string.Empty;

            string marca     = MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.gridMarca         ;
            string fecha     = MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.gridFechaCalifica ;
            string tipo      = MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.gridTipoCalifica  ;
            string temporada = MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.gridTemporada     ;
            string tabla     = MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.gridTabla         ;
            string proveedor = MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.gridProveedor     ;
            string estilo    = MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.gridEstilo        ;
            string orden     = MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.gridOrden         ;

            DateTime hoy = DateTime.Now;

            fechaUser = hoy.Date.ToString("yyMMdd");
            horaUser = DateTime.Now.ToString("HHmmss");
            usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;

            campo = this.dgvGridView.Rows[Row].Cells[Col].OwningColumn.Name;
            if (campo == "CHKCOMP")
            {
                observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBC"].Value.ToString();
                Boolean chk = Convert.ToBoolean((this.dgvGridView.CurrentRow.Cells["CHKCOMP"].Value));
                if (chk == true)
                {
                    checkBox = "0";
                }
                else
                {
                    checkBox = "1";
                }
                MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateCheckBoxCompras(marca, fecha, tipo, temporada, tabla, proveedor, estilo,
                                                                                        orden, checkBox, observaciones, usuario, fechaUser, horaUser);
            }
            if (campo == "CHKCONTR")
            {
                observaciones = this.dgvGridView.CurrentRow.Cells["MDYOBT"].Value.ToString();
                Boolean chk = Convert.ToBoolean((this.dgvGridView.CurrentRow.Cells["CHKCONTR"].Value));
                if (chk == true)
                {
                    checkBox = "0";
                }
                else
                {
                    checkBox = "1";
                }
                MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().UpdateCheckBoxContraloria(marca, fecha, tipo, temporada, tabla, proveedor, estilo,
                                                                                        orden, checkBox, observaciones, usuario, fechaUser, horaUser);
            }
        }

        private void dgvGridView_Sorted_1(object sender, EventArgs e)
        {
            rowStyle();
        }

        private void EliminacheckBox()
        {
            try
            {
                dgvGridView.Columns.Remove("COMPRAS");
            }
            catch { }
        }

        private void CreaCheckBox()
        {
            DataGridViewCheckBoxColumn Compras = new DataGridViewCheckBoxColumn();

            dgvGridView.Columns.Add(Compras);
            dgvGridView.Columns[8].Name = "COMPRAS";
            dgvGridView.Columns[8].HeaderText = "Revisado Comprador";
            dgvGridView.Columns[8].Width = 70;
            dgvGridView.Columns[8].HeaderCell.Style.BackColor = Color.FromArgb(0, 192, 0);
            dgvGridView.Columns[8].HeaderCell.Style.ForeColor = Color.White;
        }

        private void detalleCalNivEstTSMI_Click(object sender, EventArgs e)
        {
            Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "CalificacionGridTdaMasivo").SingleOrDefault<Form>();
            {
                if (existe != null)
                {
                    MessageBox.Show("Las ventana del Convenio Melody ya esta abierta");
                }
                else
                {
                    MmsWin.Front.Utilerias.VarTem.parProveedor = string.Empty;
                    MmsWin.Front.Utilerias.VarTem.parEstilo    = string.Empty;

                    MmsWin.Front.Utilerias.VarTem.tmpPrv = string.Empty;
                    MmsWin.Front.Utilerias.VarTem.tmpSty = string.Empty;

                    MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parProveedor   = string.Empty;
                    MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parNombre      = string.Empty;
                    MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parEstilo      = string.Empty;
                    MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parDescripcion = string.Empty;

                    CalificacionGridTdaMasivo i = new CalificacionGridTdaMasivo();
                    i.Show();
                }
            }
        }

        private void dgvGridView_SelectionChanged(object sender, EventArgs e)
        {
            cargaVariables();
        }

        private void cargaVariables()
        {
            try
            {
                MmsWin.Front.ConvenioMelody.ResumenGlobal.parCalificacion = this.dgvGridView.CurrentRow.Cells["RSMCAL"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parCalificacion = this.dgvGridView.CurrentRow.Cells["RSMCAL"].Value.ToString();
                MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parOrigen = "Global";

                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parCalificacion = this.dgvGridView.CurrentRow.Cells["RSMCAL"].Value.ToString();
                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parOrigen = "Global";

                MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.parCalificacion = this.dgvGridView.CurrentRow.Cells["RSMCAL"].Value.ToString();
                MmsWin.Front.ConvenioMelody.ResumenCalTdaGlobal.parOrigen = "Global";
            }
            catch { }
        }

        private void btPoneChks_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                if ((Convert.ToString((rowp.Cells[0].Value))) != "Total")
                {
                    DataGridViewCheckBoxCell chk2 = (DataGridViewCheckBoxCell)rowp.Cells["COMPRAS"];
                    dgvGridView.BeginEdit(true);
                    chk2.Value = 1;
                    dgvGridView.BeginEdit(false);
                }
            }
        }

        private void btQuitaChk_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                if ((Convert.ToString((rowp.Cells[0].Value))) != "Total")
                {
                    DataGridViewCheckBoxCell chk2 = (DataGridViewCheckBoxCell)rowp.Cells["COMPRAS"];
                    dgvGridView.BeginEdit(true);
                    chk2.Value = 0;
                    dgvGridView.BeginEdit(false);
                }
            }
        }

        private void pbSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ResumenCalTdaGlobal_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void ResumenCalTdaGlobal_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedownpoint.IsEmpty)
                return;
            Form f = sender as Form;
            f.Location = new Point(f.Location.X + (e.X - mousedownpoint.X), f.Location.Y + (e.Y - mousedownpoint.Y));
        }

        private void ResumenCalTdaGlobal_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

        private void rebajaDiferenciadaTSMI_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "MasivoDiferenciado").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La Ventana ya esta abierta...");
                    }
                    else
                    {
                        string FechaBon = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
                        if (FechaBon != null)
                        {
                            string calificaion = MmsWin.Front.ConvenioMelody.CalificacionGrid.gridCalificacion;
                            string convMarcaNo = MmsWin.Front.ConvenioMelody.CalificacionGrid.gridMarca;

                            string FechaBinificacion = FechaBon.Substring(8, 2) + FechaBon.Substring(3, 2) + FechaBon.Substring(0, 2);
                            string FechaAbierta      = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenMarcaConfiguracion1(convMarcaNo);
                            if (FechaBinificacion == FechaAbierta)
                            {
                                MessageBox.Show("La Rebaja se va a concentrar en la fecha :" + FechaBon);
                                RecuperaMovimientosDiferenciados();
                                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.ParFchBon = FechaBinificacion;


                                MmsWin.Front.Utilerias.VarTem.parProveedor = string.Empty;
                                MmsWin.Front.Utilerias.VarTem.parEstilo = string.Empty;

                                MmsWin.Front.Utilerias.VarTem.tmpPrv = string.Empty;
                                MmsWin.Front.Utilerias.VarTem.tmpSty = string.Empty;

                                MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parProveedor = string.Empty;
                                MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parNombre = string.Empty;
                                MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parEstilo = string.Empty;
                                MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parDescripcion = string.Empty;

                                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parProveedor = string.Empty;
                                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parNombre = string.Empty;
                                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parEstilo = string.Empty;
                                MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parDescripcion = string.Empty;

                                MasivoDiferenciado i = new MasivoDiferenciado();
                                i.Show();
                            }
                            else
                            {
                                MessageBox.Show("La fecha " + FechaBon + " No esta abierta para captura de Notas de Credito");
                            }
                        }
                        else
                        {
                            MessageBox.Show("La ventana de Calificacion no esta abierta...");
                        }
                    }
                }
            }
            catch { }
            finally { }
        }

        private void RecuperaMovimientosDiferenciados()
        {
            System.Data.DataTable dtDiferenciados = new System.Data.DataTable("Diferenciados");
            dtDiferenciados.Columns.Add("ParTipo", typeof(String));
            dtDiferenciados.Columns.Add("ParTemporada", typeof(String));
            dtDiferenciados.Columns.Add("ParTienda", typeof(String));

            DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
            foreach (DataGridViewRow item in Seleccionados)
            {
                DataRow workRow = dtDiferenciados.NewRow();
                workRow["ParTipo"]      = item.Cells["MDYTPO"].Value.ToString();
                workRow["ParTemporada"] = item.Cells["MDYTMP"].Value.ToString();
                workRow["ParTienda"]    = item.Cells["MDYTDA"].Value.ToString();

                dtDiferenciados.Rows.Add(workRow);
            }

            int regs = dtDiferenciados.Rows.Count;
            if (regs == 0)
            {
                DataRow workRow = dtDiferenciados.NewRow();
                workRow["ParTipo"]      = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTipoCalifica;
                workRow["ParTemporada"] = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTemporada;
                workRow["ParTienda"]    = MmsWin.Front.ConvenioMelody.CalificacionGridTda.gridTienda;

                dtDiferenciados.Rows.Add(workRow);
            }


            MmsWin.Front.ConvenioMelody.NotaDiferenciada.dtDiferenciados = dtDiferenciados;
        }

        private void btAplicar_Click(object sender, EventArgs e)
        {
            // - - - - - - - - - - - - - - - - - - - - - - -
            MmsWin.Front.Utilerias.VarTem.parProveedor = string.Empty;
            MmsWin.Front.Utilerias.VarTem.parEstilo    = string.Empty;

            MmsWin.Front.Utilerias.VarTem.tmpPrv = string.Empty;
            MmsWin.Front.Utilerias.VarTem.tmpSty = string.Empty;

            MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parProveedor   = string.Empty;
            MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parNombre      = string.Empty;
            MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parEstilo      = string.Empty;
            MmsWin.Front.ConvenioMelody.CalificacionGridTdaMasivo.parDescripcion = string.Empty;

            MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parProveedor   = string.Empty;
            MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parNombre      = string.Empty;
            MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parEstilo      = string.Empty;
            MmsWin.Front.ConvenioMelody.MasivoDiferenciado.parDescripcion = string.Empty;

            MmsWin.Front.ConvenioMelody.ResumenCalTda.parProveedor   = string.Empty;
            MmsWin.Front.ConvenioMelody.ResumenCalTda.parNombre      = string.Empty;
            MmsWin.Front.ConvenioMelody.ResumenCalTda.parEstilo      = string.Empty;
            MmsWin.Front.ConvenioMelody.ResumenCalTda.parDescripcion = string.Empty;
            // - - - - - - - - - - - - - - - - - - - - - - -

         if (Seleccion != "")
            {
                string FechaBon = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
                string FechaBinificacion = FechaBon.Substring(8, 2) + FechaBon.Substring(3, 2) + FechaBon.Substring(0, 2);
                ParFchBon = FechaBinificacion;

                DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
                foreach (DataGridViewRow rowp in Seleccionados)
                {
                    string message = "Se va a concentrar la rebaja diferenciada en la fecha: " + FechaBon;
                    string caption = "Confirmar";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result;
                    result = MessageBox.Show(message, caption, buttons);
                    if (result == System.Windows.Forms.DialogResult.Yes)
                    {
                        string tipo             = string.Empty;
                        string temporada        = string.Empty;
                        string comprador        = string.Empty;
                        string tipoCalificacion = string.Empty;
                        string tabla            = string.Empty;
                        string fchCalificacion  = string.Empty;
                        string proveedor        = string.Empty;
                        string estilo           = string.Empty;
                        string calificacion     = string.Empty;
                        string nombre           = string.Empty;
                        string descripcion      = string.Empty;

                        comprador = parComprador;
                        FchDe     = parFchDesde;
                        FchHas    = parFchHasta;
                        temporada = parTemporada;
                        tipoCalificacion = parTipoCalificacion;
                        fchCalificacion  = parFchCalificacion;
                        proveedor    = parProveedor;
                        nombre       = parNombre;
                        estilo       = parEstilo;
                        descripcion  = parDescripcion;
                        calificacion = parCalificacion;

                        dtDiferenciados = MmsWin.Negocio.ConvenioMelody.CalendarioProgramacionGrid.GetInstance().ObtenCalificaionTdaXcalificacion(parMarca, comprador, FchDe, FchHas, temporada, tipoCalificacion, parFchCalificacion, parProveedor, parNombre, parEstilo, parDescripcion, parCalificacion, parOrigen);

                        GuardarNota();
                    }
                    else
                    {
                        MessageBox.Show("El proceso fue cancelado por el Usuario.");
                    }
                }
            }
            else
            {
                MessageBox.Show("No hay Registro seleccionado...");
            }
        }

        private void GuardarNota()
        {
            string ParTipo      = string.Empty;
            string ParTemporada = string.Empty;
            string ParTienda    = string.Empty;
            string ParFchRev    = string.Empty;
            string ParProveedor = string.Empty;
            string PartbEstilo  = string.Empty;

            string TpoMov = "RBD";
            string TpoCal = "NOR";

            System.Data.DataTable dtGuardaNota = null;

            string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
            string ParNotCal = "DIFERENCIADO";

            string ParSubtot = string.Empty;
            string ParPorc = "0";

            ParPorc = ParPorc.Replace(".", "");
            String RutaPdf = MmsWin.Front.Utilerias.VarTem.tmpDestNcPDF;

            foreach (DataRow row1 in dtDiferenciados.Rows)
            {
                if (row1["MDYTDD"].ToString() != "Total")
                {
                    ParTipo      = row1["MDYTPO"].ToString();
                    ParTemporada = row1["MDYTMP"].ToString();
                    ParTienda    = row1["MDYTDA"].ToString();
                    ParFchRev    = row1["MDYFCH"].ToString();
                    ParProveedor = row1["MDYPRV"].ToString();
                    PartbEstilo  = row1["MDYSTY"].ToString();

                    string varInd1 = "0";
                    string varInd2 = "0";

                    siHuboRebaja = "No";
                    dtGuardaNota = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().GuardaNotaDiferenciada(ParFchBon, ParFchRev, ParTipo, ParTemporada, ParTienda, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, ParPorc, varInd1, varInd2, TpoMov, TpoCal, RutaPdf);

                    if (dtGuardaNota.Rows.Count > 0)
                    {
                        foreach (DataRow row in dtGuardaNota.Rows)
                        {

                            varInd1 = row["NOTIN1"].ToString();
                            varInd2 = row["NOTIN2"].ToString();

                            if (varInd1 == "1" && varInd2 == "0")
                            {
                                siHuboRebaja = "Si";
                            }
                            else
                            {
                                if (varInd2 == "1")
                                {
                                    string message = "Ya existe La Rebaja, Haz Click en (Si) para remplazar ";
                                    string caption = "Aviso";
                                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                                    DialogResult result;
                                    result = MessageBox.Show(message, caption, buttons);
                                    if (result == System.Windows.Forms.DialogResult.Yes)
                                    {
                                        varInd1 = "2";
                                        varInd2 = "2";
                                        RutaPdf = MmsWin.Front.Utilerias.VarTem.tmpRutaPdf;
                                        MmsWin.Negocio.Utilerias.Utilerias.GetInstance().GuardaNotaDiferenciada(ParFchBon, ParFchRev, ParTipo, ParTemporada, ParTienda, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, ParPorc, varInd1, varInd2, TpoMov, TpoCal, RutaPdf);
                                        MessageBox.Show("Se actualizo la Rebaja exitosamente");
                                        this.Close();
                                    }
                                    else
                                    {
                                        romperForeach = "Si";
                                        break;
                                    }
                                }
                            }

                        }

                        if (romperForeach == "Si")
                        {
                            break;
                        }
                    }
                }
            }
            if (siHuboRebaja == "Si")
            {
                MessageBox.Show("Se guardó la Reabaja exitosamente");
                //this.Close();
            }
        }

        private void dgvGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Seleccion = string.Empty;
            Seleccion = this.dgvGridView.CurrentRow.Cells["RSMCAL"].Value.ToString();
            if (Seleccion != "Total" && Seleccion != "P a g a r" && Seleccion != "")
            {
                cargaVariables();
            }
            else
            {
                Seleccion = string.Empty;
                MessageBox.Show("Error en la selección. Este registro no es valido");
            }
        }
    }
}
