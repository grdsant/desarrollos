﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class Jerarquias : Form
    {
        Point mousedownpoint = Point.Empty;
        int nr;

        public System.Data.DataTable dtJerarquias = null;

        public Jerarquias()
        {
            InitializeComponent();
        }

        private void pbSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Jerarquias_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void Jerarquias_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedownpoint.IsEmpty)
                return;
            Form f = sender as Form;
            f.Location = new Point(f.Location.X + (e.X - mousedownpoint.X), f.Location.Y + (e.Y - mousedownpoint.Y));
        }

        private void Jerarquias_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

        private void Jerarquias_Load(object sender, EventArgs e)
        {
            tbDP.Text = "999";
            BindJerarquias();
            SetFontAndColors();
            rowStyle();
            tbDP.Text = string.Empty;
        }

        protected void BindJerarquias()
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string dp = tbDP.Text;
                string sd = tbSD.Text;
                string cl = tbCL.Text;
                string sc = tbSC.Text;
                string dpd = tbDPD.Text;
                string sdd = tbSDD.Text;
                string cld = tbCLD.Text;
                string scd = tbSCD.Text;

                dtJerarquias = MmsWin.Negocio.Catalogos.Jerarquia.GetInstance().ObtenJerarquias(dp, sd, cl, sc, dpd, sdd, cld, scd);
            }
            catch 
            {
                
            }
            if (dtJerarquias != null)
            {
                if (dtJerarquias.Rows.Count > 0)
                {
                    SetDoubleBuffered(dgvGridView);
                    dgvGridView.DataSource = null;

                    dgvGridView.DataSource = dtJerarquias;

                    nr = dgvGridView.RowCount;
                    lbJerarquias.Text = "Jerarquias / " + (nr).ToString() + " Registro(s)";
                    //SetFontAndColors();
                    //rowStyle();

                    //// Seguridad...
                    //ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                    //Seguridad("Convenio", "Convenio", ParUser);
                    //dgvGridView.Visible = false;

                    //dgvGridView.Focus();
                    //dgvGridView.Select();
                }
            }
            this.Cursor = Cursors.Default;
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        // Atributos y caracteristicas                                                                    
        //
        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.WhiteSmoke;
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new Font(dgvGridView.ColumnHeadersDefaultCellStyle.Font, FontStyle.Bold);


            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Olive;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.WhiteSmoke;
            this.dgvGridView.RowsDefaultCellStyle.BackColor = Color.Gray;
            this.dgvGridView.RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty;
            this.dgvGridView.RowHeadersDefaultCellStyle.BackColor = Color.Gray;
            this.dgvGridView.Columns[1].Frozen = true;

            dgvGridView.Columns["JERDP"].HeaderText  = "DP";
            dgvGridView.Columns["JERSD"].HeaderText  = "SD";
            dgvGridView.Columns["JERCL"].HeaderText  = "CL";
            dgvGridView.Columns["JERSC"].HeaderText  = "SC";
            dgvGridView.Columns["JERDPD"].HeaderText = "Departamento";
            dgvGridView.Columns["JERSDD"].HeaderText = "Sub Depto";
            dgvGridView.Columns["JERCLD"].HeaderText = "Clase";
            dgvGridView.Columns["JERSCD"].HeaderText = "Sub Clase";
            dgvGridView.Columns["JERSTS"].HeaderText = "Sts";
            dgvGridView.Columns["JERUAL"].HeaderText = "Usuario";
            dgvGridView.Columns["JERFAL"].HeaderText = "Fecha";
            dgvGridView.Columns["JERHAL"].HeaderText = "Hora";

            dgvGridView.Columns["JERDP"].Width  = 40;
            dgvGridView.Columns["JERSD"].Width  = 40;
            dgvGridView.Columns["JERCL"].Width  = 40;
            dgvGridView.Columns["JERSC"].Width  = 40;
            dgvGridView.Columns["JERDPD"].Width = 150;
            dgvGridView.Columns["JERSDD"].Width = 150;
            dgvGridView.Columns["JERCLD"].Width = 150;
            dgvGridView.Columns["JERSCD"].Width = 150;
            dgvGridView.Columns["JERSTS"].Width = 40;
            dgvGridView.Columns["JERUAL"].Width = 70;
            dgvGridView.Columns["JERFAL"].Width = 80;
            dgvGridView.Columns["JERHAL"].Width = 80;

            dgvGridView.Columns["JERFAL"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns["JERHAL"].DefaultCellStyle.Format = "##:##:##";

            dgvGridView.Columns["JERDP"].DefaultCellStyle.NullValue  = true;
            dgvGridView.Columns["JERSD"].DefaultCellStyle.NullValue  = true;
            dgvGridView.Columns["JERCL"].DefaultCellStyle.NullValue  = true;
            dgvGridView.Columns["JERSC"].DefaultCellStyle.NullValue  = true;
            dgvGridView.Columns["JERDPD"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["JERSDD"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["JERCLD"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["JERSCD"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["JERSTS"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["JERUAL"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["JERFAL"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["JERHAL"].DefaultCellStyle.NullValue = true;

            dgvGridView.Columns["JERDP"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["JERSD"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["JERCL"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["JERSC"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["JERDPD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["JERSDD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["JERCLD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["JERSCD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["JERSTS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["JERUAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["JERFAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["JERHAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns["JERDP"].HeaderCell.Style.BackColor  = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["JERSD"].HeaderCell.Style.BackColor  = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["JERCL"].HeaderCell.Style.BackColor  = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["JERSC"].HeaderCell.Style.BackColor  = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["JERDPD"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["JERSDD"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["JERCLD"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["JERSCD"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["JERSTS"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["JERUAL"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["JERFAL"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["JERHAL"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);

            dgvGridView.Columns["JERDP"].HeaderCell.Style.ForeColor  = Color.WhiteSmoke;
            dgvGridView.Columns["JERSD"].HeaderCell.Style.ForeColor  = Color.WhiteSmoke;
            dgvGridView.Columns["JERCL"].HeaderCell.Style.ForeColor  = Color.WhiteSmoke;
            dgvGridView.Columns["JERSC"].HeaderCell.Style.ForeColor  = Color.WhiteSmoke;
            dgvGridView.Columns["JERDPD"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["JERSDD"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["JERCLD"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["JERSCD"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["JERSTS"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["JERUAL"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["JERFAL"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["JERHAL"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
        }
        // Estilo de Renglones                                                                            
        //
        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    //dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.LightGray;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }

        private void tbDP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindJerarquias();
                tbDP.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbSD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindJerarquias();
                tbSD.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbCL_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindJerarquias();
                tbCL.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbSC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindJerarquias();
                tbSC.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbDPD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindJerarquias();
                tbDPD.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbSDD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindJerarquias();
                tbSDD.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbCLD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindJerarquias();
                tbCLD.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbSCD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindJerarquias();
                tbSCD.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void AgregarTSMI_Click(object sender, EventArgs e)
        {
            string message = "Esta seguro de agregar esta(s) temporada(s)?";
            string caption = "Confirmación";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                try
                {
                    string MoverFecha = string.Empty;

                    System.Data.DataTable dtJerarquias = new System.Data.DataTable("Jerarquias");

                    dtJerarquias.Columns.Add("marca", typeof(String));
                    dtJerarquias.Columns.Add("grupo", typeof(String));
                    dtJerarquias.Columns.Add("tipo", typeof(String));
                    dtJerarquias.Columns.Add("dp", typeof(String));
                    dtJerarquias.Columns.Add("sd", typeof(String));
                    dtJerarquias.Columns.Add("cl", typeof(String));
                    dtJerarquias.Columns.Add("sc", typeof(String));

                    DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
                    foreach (DataGridViewRow item in Seleccionados)
                    {
                        DataRow workRow = dtJerarquias.NewRow();

                        workRow["marca"] = MmsWin.Front.ConvenioMelody.GrupoTemporada.marca;
                        workRow["grupo"] = MmsWin.Front.ConvenioMelody.GrupoTemporada.grupo;
                        workRow["tipo"] = "JER";
                        workRow["dp"] = item.Cells["JERDP"].Value.ToString();
                        workRow["sd"] = item.Cells["JERSD"].Value.ToString();
                        workRow["cl"] = item.Cells["JERCL"].Value.ToString();
                        workRow["sc"] = item.Cells["JERSC"].Value.ToString();


                        dtJerarquias.Rows.Add(workRow);
                    }

                    if (dtJerarquias.Rows.Count > 0)
                    {
                        string usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        string mensaje = MmsWin.Negocio.ConvenioMelody.Jerarquias.GetInstance().AgregarJerarquias(dtJerarquias, usuario);
                        MessageBox.Show(mensaje);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Debe seleccionar la(s) Jeraraquia(s)...");
                    }
                }
                catch { }
                finally { }
            }
        }

    }
}
