﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class NotaDiferenciada : Form
    {

        #region Conexion
        public static string srv_Doctos = ConfigurationManager.ConnectionStrings["srvDoctos"].ToString();
        #endregion

        public int    marca       { get; set; }
        public string noMarca     { get; set; }
        public string ordenCompra { get; set; }
        public string temporada   { get; set; }
        public string comprador   { get; set; }
        public int    noEvento    { get; set; }

        public static DataTable dtDiferenciados { get; set; }

        string ParUser;
        public NotaDiferenciada()
        {
            InitializeComponent();
        }

        private void Nota_Load(object sender, EventArgs e)
        {
            ToolTip tooltip = new ToolTip();
            tooltip.SetToolTip(this.lbPorcentajeRebajado, "Porcentaje Rebajado");
            tooltip.SetToolTip(this.lbMargenRebajado, "Margen");
            tooltip.SetToolTip(this.lbPecioPromedio, "Precio Promedio");
            // Carga Datos del DatagridView

            tbFchCal.Text = MmsWin.Front.Utilerias.VarTem.NotaFchRevision;
            tbFchApl.Text = MmsWin.Front.Utilerias.VarTem.NotaFchBonifica;
            tbProvee.Text = MmsWin.Front.Utilerias.VarTem.NotaProveedor;
            tbNombre.Text = MmsWin.Front.Utilerias.VarTem.NotaNombre;
            tbEstilo.Text = MmsWin.Front.Utilerias.VarTem.NotaEstilo;
            tbDescripcion.Text = MmsWin.Front.Utilerias.VarTem.NotaDescripcion;

            tbReferencia.Text = " ";
            tbReferencia.Focus();

            // Seguridad...
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("ConvenioMelody", "Nota", ParUser);

            cbPorcentajes.SelectedIndex = 0;
            mtbPorc.Text = "0.00";
        }

        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }

        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
        }

        private void btnCambiar_Click(object sender, EventArgs e)
        {
            // Habilita nota de Crédito
            tbReferencia.Enabled = false;
            //mtbSubTotal.Enabled = true;
            //mtbSubTotal.Focus();


                // Habilita nota de Crédito

                if (mtbSubTotal.Text == "0")
                {
                    mtbIva.Text = "0";
                    mtbTotal.Text = "0";
                    mtbNOTCSTD.Text = "0";
                    mtbNOTPZA1.Text = "0";
                    mtbNOTIMP1.Text = "0";
                    mtbNOTDCF2.Text = "0";
                    mtbNOTIDC2.Text = "0";
                    mtbNOTIMF2.Text = "0";
                }
                mtbSubTotal.Enabled = false;
                mtbPorc.Enabled = false;
                cbPorcentajes.Enabled = true;
                mtbPorc.Focus();
            
        }

        private void CalculoSubtotal()
        {
            string PrecioFinalXaplicar     = string.Empty;
            string  porcentajeXaplicarText = string.Empty;
            double porcentajeXaplicar = 0;
            double precioActual = 0;
            double costoActual = 0;
            string ParTipo            = string.Empty;
            string ParTemporada       = string.Empty;
            string ParTienda          = string.Empty;
            string ParPorc = string.Empty;

            this.Cursor = Cursors.WaitCursor;
            // Recalculo . . . . .mo
            System.Data.DataTable dtCalculoNota     = null;
            System.Data.DataTable dtDetallexRebajar = null;
            
            string ParFchBon = tbFchApl.Text;
            ParFchBon = ParFchBon.Substring(8, 2) + ParFchBon.Substring(3, 2) + ParFchBon.Substring(0, 2);
            string ParFchRev = tbFchCal.Text;
            ParFchRev = ParFchRev.Substring(8, 2) + ParFchRev.Substring(3, 2) + ParFchRev.Substring(0, 2);
            string ParProveedor = tbProvee.Text;
            string PartbEstilo  = tbEstilo.Text;
            string ParUsuario   = MmsWin.Front.Utilerias.VarTem.tmpUser;
            string ParNotCal    = tbReferencia.Text;
            string ParSubtot    = mtbSubTotal.Text;

            mtbPorc.Text = mtbPorc.Text.Replace("%", "");
            ParPorc = string.Format("{0:n4}", double.Parse(mtbPorc.Text));

            ParSubtot = ParSubtot.Replace(".", "");
            ParSubtot = ParSubtot.Replace(",", "");
            ParPorc   = ParPorc.Replace(".", "");
            ParPorc   = ParPorc.Replace(",", "");
            string TipMov = "BON";
            string TipCal = "NOR";

            foreach (DataRow row in dtDiferenciados.Rows)
            {
                ParTipo      = row["ParTipo"].ToString();
                ParTemporada = row["ParTemporada"].ToString();
                ParTienda    = row["ParTienda"].ToString();

                dtCalculoNota = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenCalculoNotasDiferenciada(ParFchBon, ParFchRev, ParTipo, ParTemporada, ParTienda, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, TipMov, TipCal, ParPorc);
            }
            if (dtCalculoNota.Rows.Count > 0)
            {
                foreach (DataRow row in dtCalculoNota.Rows)
                {
                    mtbSubTotal.Text = string.Format("{0:n2}", double.Parse(row["NOTSUB"].ToString()));
                    mtbIva.Text      = string.Format("{0:n2}", double.Parse(row["NOTIVA"].ToString()));
                    mtbTotal.Text    = string.Format("{0:n2}", double.Parse(row["NOTTOT"].ToString()));

                    mtbCosto.Text  = string.Format("{0:n4}", double.Parse(row["NOTCST"].ToString()));
                    costoActual    = double.Parse(row["NOTCST"].ToString());
                    mtbPrecio.Text = string.Format("{0:n3}", double.Parse(row["NOTPRC"].ToString()));
                    precioActual   = double.Parse(row["NOTPRC"].ToString());
                    mtbMargen.Text = string.Format("{0:n3}", double.Parse(row["NOTMRG"].ToString()));

                    mtbCostoNuevo.Text  = string.Format("{0:n4}", double.Parse(row["NOTCST1"].ToString()));
                    mtbPrecioNuevo.Text = string.Format("{0:n3}", double.Parse(row["NOTPRC1"].ToString()));
                    mtbMargenNuevo.Text = string.Format("{0:n3}", double.Parse(row["NOTMRG1"].ToString()));

                    mtbCostoFinal.Text  = string.Format("{0:n4}", double.Parse(row["NOTCST2"].ToString()));
                    mtbPrecioFinal.Text = string.Format("{0:n3}", double.Parse(row["NOTPRC2"].ToString()));
                    PrecioFinalXaplicar = string.Format("{0:n3}", double.Parse(row["NOTPRC2"].ToString()));
                    mtbMargenFinal.Text = string.Format("{0:n3}", double.Parse(row["NOTMRG2"].ToString()));

                    mtbNOTONH.Text  = string.Format("{0:n0}", double.Parse(row["NOTONH"].ToString()));
                    mtbNOTTAB.Text  = string.Format("{0:n0}", row["NOTTAB"].ToString());
                    mtbNOTTABF.Text = string.Format("{0:n0}", row["NOTTABF"].ToString());

                    mtbNOTCSTD.Text = string.Format("{0:n4}", double.Parse(row["NOTCSTD"].ToString()));
                    mtbNOTPZA1.Text = string.Format("{0:n0}", double.Parse(row["NOTPZA1"].ToString()));
                    mtbNOTIMP1.Text = string.Format("{0:n2}", double.Parse(row["NOTIMP1"].ToString()));

                    mtbNOTDCF2.Text = string.Format("{0:n4}", double.Parse(row["NOTDCF2"].ToString()));
                    mtbNOTIDC2.Text = string.Format("{0:n4}", double.Parse(row["NOTIDC2"].ToString()));
                    mtbNOTIMF2.Text = string.Format("{0:n4}", double.Parse(row["NOTIMF2"].ToString()));

                    try
                    {
                        mtbPorc.Text = string.Format("{0:n4}", double.Parse(row["NOTCAP"].ToString()));
                        porcentajeXaplicar = double.Parse(row["NOTCAP"].ToString());
                        porcentajeXaplicarText = string.Format("{0:n4}", double.Parse(row["NOTCAP"].ToString()));
                        
                    }
                    catch { mtbPorc.Text = "0"; porcentajeXaplicar = 0; }                   
                }
            }

            // Inserta tiendas a Rebajar
            MmsWin.Negocio.Utilerias.Utilerias.GetInstance().InsertaRegistrosArebajar(dtDiferenciados, ParUsuario, porcentajeXaplicarText, PrecioFinalXaplicar);

            dtDetallexRebajar = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenDetalleXrebajar(ParFchBon, ParProveedor, PartbEstilo, ParUsuario);

            this.Cursor = Cursors.Default;
            mtbSubTotal.Enabled = false;
            porcentajeTope(dtDetallexRebajar, porcentajeXaplicar, precioActual, costoActual);
        }

        private void porcentajeTope(DataTable dtDetallexRebajar, double porcentajeXaplicar, double precioActual, double costoActual)
        {
            double inventarioActual = 0;

            double PrecioOriginal = 0;
            double PrecioActual = 0;
            double margen = 0;

            double importeOrinal = 0;
            double importeRebaja = 0;

            foreach (DataRow row3 in dtDetallexRebajar.Rows)
            {
                try
                {
                    // Porcentaje Rebajado
                    inventarioActual += Convert.ToDouble(row3[11].ToString());
                    importeOrinal += Convert.ToDouble(row3[13].ToString());
                    importeRebaja += Convert.ToDouble(row3[14].ToString());

                    if (inventarioActual != 0)
                    {
                        PrecioOriginal = importeOrinal / inventarioActual;
                        PrecioActual = importeRebaja / inventarioActual;
                    }
                    margen = ((PrecioActual / PrecioOriginal * 100) - 100) * -1;
                    lbPorcentajeRebajado.Text = (string.Format("{0:n2}", margen)) + " %"; ;
                    lbPecioPromedio.Text = (string.Format("{0:n2}", PrecioActual)); 
                    // Margen Rebajado 
                    double prcSinIva = PrecioActual / 1.16;
                    double cstEntrePrcSinIva = costoActual / prcSinIva;
                    double margenRebajado = (1-cstEntrePrcSinIva)* 100;
                    margenRebajado = Math.Truncate(margenRebajado * 10000) / 10000;
                    lbMargenRebajado.Text = (string.Format("{0:n2}", margenRebajado)) + " %"; ;
                }
                catch { }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (mtbSubTotal.Text != " ") // && mtbSubTotal.Text != "0.00")
            {
                GuardarNota();
            }
            else
            {
                MessageBox.Show("No debe quedar en blanco el Subtotal");
            }
        }

        private void GuardarNota()
        {
            string ParTipo      = string.Empty;
            string ParTemporada = string.Empty;
            string ParTienda    = string.Empty;

            string TpoMov = "RBD";
            string TpoCal = "NOR";



                // Recalculo . . . . .
                System.Data.DataTable dtGuardaNota = null;

                string ParFchBon = tbFchApl.Text;
                ParFchBon = ParFchBon.Substring(8, 2) + ParFchBon.Substring(3, 2) + ParFchBon.Substring(0, 2);
                string ParFchRev = tbFchCal.Text;
                ParFchRev = ParFchRev.Substring(8, 2) + ParFchRev.Substring(3, 2) + ParFchRev.Substring(0, 2);

                string ParProveedor = tbProvee.Text;
                string PartbEstilo = tbEstilo.Text;
                string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                string ParNotCal = tbReferencia.Text;
                string ParSubtot = mtbSubTotal.Text;
                string ParPorc = mtbPorc.Text;


                ParSubtot = ParSubtot.Replace(".", "");
                ParSubtot = ParSubtot.Replace(",", "");
                ParPorc = ParPorc.Replace(".", "");
                String RutaPdf = MmsWin.Front.Utilerias.VarTem.tmpDestNcPDF;

                foreach (DataRow row1 in dtDiferenciados.Rows)
                {
                    ParTipo = row1["ParTipo"].ToString();
                    ParTemporada = row1["ParTemporada"].ToString();
                    ParTienda = row1["ParTienda"].ToString();

                    string varInd1 = "0";
                    string varInd2 = "0";

                    dtGuardaNota = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().GuardaNotaDiferenciada(ParFchBon, ParFchRev, ParTipo, ParTemporada, ParTienda, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, ParPorc, varInd1, varInd2, TpoMov, TpoCal, RutaPdf);

                    if (dtGuardaNota.Rows.Count > 0)
                    {
                        foreach (DataRow row in dtGuardaNota.Rows)
                        {
                            varInd1 = row["NOTIN1"].ToString();
                            varInd2 = row["NOTIN2"].ToString();

                            if (varInd1 == "1" && varInd2 == "0")
                            {
                               // MessageBox.Show("Se guardó la Nota de Crédito exitosamente");
                                this.Close();

                            }
                            else
                            {
                                if (varInd2 == "1")
                                {
                                    string message = "Ya existe La Nota de Crédito, Haz Click en (Si) para remplazar ";
                                    string caption = "Aviso";
                                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                                    DialogResult result;
                                    result = MessageBox.Show(message, caption, buttons);
                                    if (result == System.Windows.Forms.DialogResult.Yes)
                                    {
                                        varInd1 = "2";
                                        varInd2 = "2";
                                        RutaPdf = MmsWin.Front.Utilerias.VarTem.tmpRutaPdf;
                                        MmsWin.Negocio.Utilerias.Utilerias.GetInstance().GuardaNotaDiferenciada(ParFchBon, ParFchRev, ParTipo, ParTemporada, ParTienda, ParProveedor, PartbEstilo, ParNotCal, ParUsuario, ParSubtot, ParPorc, varInd1, varInd2, TpoMov, TpoCal, RutaPdf);
                                        MessageBox.Show("Se actualizo la Nota de Crédito exitosamente");
                                        this.Close();
                                    }
                                }
                            }
                        }
                    }
                }
            // Bloquea Numero de Nota de Crédito 
            mtbSubTotal.Enabled = false;
        }

        private void mtbSubTotal_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                // Habilita nota de Crédito

                if (mtbSubTotal.Text == "0")
                {
                    mtbIva.Text = "0";
                    mtbTotal.Text = "0";
                    mtbNOTCSTD.Text = "0";
                    mtbNOTPZA1.Text = "0";
                    mtbNOTIMP1.Text = "0";
                    mtbNOTDCF2.Text = "0";
                    mtbNOTIDC2.Text = "0";
                    mtbNOTIMF2.Text = "0";
                }
                mtbSubTotal.Enabled = false;
                mtbPorc.Enabled = false;
                cbPorcentajes.Enabled = true;
                mtbPorc.Focus();
            }
        }

        private void mtbPorc_KeyPress(object sender, KeyPressEventArgs e)
        {
            double porcentaje = 0;
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (mtbPorc.Text != "  ")
                {
                    mtbPorc.Enabled = false;
                    tbReferencia.Enabled = true;
                    tbReferencia.Focus();

                    if (tbReferencia.Text != " ")
                    {
                                //if (mtbSubTotal.Text != "0")
                                //{
                                    CalculoSubtotal();
                                    Valida70porciento();
                                //}
                                if (mtbSubTotal.Text == "0")
                                {
                                    mtbIva.Text = "0";
                                    mtbTotal.Text = "0";
                                    mtbNOTCSTD.Text = "0";
                                    mtbNOTPZA1.Text = "0";
                                    mtbNOTIMP1.Text = "0";
                                    mtbNOTDCF2.Text = "0";
                                    mtbNOTIDC2.Text = "0";
                                    mtbNOTIMF2.Text = "0";

                                    mtbCostoNuevo.Text = mtbCosto.Text;
                                    mtbPrecioNuevo.Text = mtbPrecio.Text;
                                    mtbMargenNuevo.Text = mtbMargen.Text;

                                    mtbCostoFinal.Text = mtbCosto.Text;
                                    mtbPrecioFinal.Text = mtbPrecio.Text;
                                    mtbMargenFinal.Text = mtbMargen.Text;
                                }
                    }
                    else { MessageBox.Show("No debe quedar en blanco la referencia"); }
                }
            }

        }

        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.gbNota.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }

            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void Nota_FormClosing(object sender, FormClosingEventArgs e)
        {
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("ConvenioMelody", "Nota", ParUser);
            }
        }

        private void pbExaminarPDF_Click(object sender, EventArgs e)
        {
            OpenFileDialog buscar = new OpenFileDialog();
            if (buscar.ShowDialog() == DialogResult.OK)
            {
                tbFuentePDF.Text = buscar.FileName;
                string[] path = buscar.FileName.Split('\\');
                int contador = path.Count();
                string nombre = path[contador - 1];

                string[] nomExt = nombre.Split('.');
                contador = nomExt.Count();
                string nomSinExt = nomExt[0];
                string ext = nomExt[contador - 1];

                if (ext == "PDF" || ext == "pdf")
                {
                    string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
                    string newDest = tbReferencia.Text + "_" +
                                     tbProvee.Text + "_" +
                                     tbEstilo.Text + "_" +
                                     Hoy +
                                     ".PDF";

                    string pathDest = @"\\" + srv_Doctos + @"\Notas_Credito_Proveedor\"; 

                    //string pathDest = @"\\172.16.50.25\Notas_Credito_Proveedor\";
                    
                    tbDestinoPDF.Text = pathDest + newDest;
                }
                else
                {
                    MessageBox.Show("Este documento no es tipo PDF");
                    tbFuentePDF.Text = "";
                }
            }
        }

        private void pbCargarPDF_Click(object sender, EventArgs e)
        {

            string comando = "copy " + '\u0022' + tbFuentePDF.Text + '\u0022' + ' ' + tbDestinoPDF.Text;


            string message = "Esta seguro de cargar esta Nota de Crédito";
            string caption = "Confirmación";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                MmsWin.Front.Utilerias.VarTem.tmpDestNcPDF = tbDestinoPDF.Text;

                String rutaPdf = MmsWin.Front.Utilerias.VarTem.tmpDestNcPDF;
                if (rutaPdf != "")
                {
                    tbFuentePDF.BackColor = Color.GreenYellow;
                    string borra = "del " + rutaPdf;
                    System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + borra);
                    procStartInfo.RedirectStandardOutput = true;
                    procStartInfo.UseShellExecute = false;
                    procStartInfo.CreateNoWindow = false;
                    System.Diagnostics.Process proc = new System.Diagnostics.Process();
                    proc.StartInfo = procStartInfo;
                    proc.Start();
                }
                // Copia Archivo PDF
                ExecuteCommand(comando);
                //tbFuentePDF.BackColor = Color.Green;

                //this.Close();

            }

        }

        static void ExecuteCommand(string _Command)
        {
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            procStartInfo.CreateNoWindow = false;
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            string result = proc.StandardOutput.ReadToEnd();
            if (result == "        1 archivo(s) copiado(s).\r\n")
            {

            }

            MessageBox.Show(result);
        }

        private void tbReferencia_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                tbReferencia.Text = (tbReferencia.Text).Trim();
                if (tbReferencia.Text != "")
                {
                        CalculoSubtotal();
                        Valida70porciento();
                        cbPorcentajes.Enabled = true;
                        btnCambiar.Focus();
                    
                }
                else { MessageBox.Show("No debe quedar en blanco la Referencia..."); }
            }
        }

        private void Valida70porciento()
        {
            double porcentaje = 0;
            mtbPorc.ForeColor = Color.Black;
            porcentaje = Convert.ToDouble(mtbPorc.Text);
            if (porcentaje <= .70)
            {

            //lbPorcentajeRebajado.ForeColor = Color.Black;
            try
            {
            //porcentaje = Convert.ToDouble((lbPorcentajeRebajado.Text).Replace("%", ""));
            }
            catch { porcentaje = 0; }
            if (porcentaje <= 70.00)
            {
            }
            //else { lbPorcentajeRebajado.ForeColor = Color.Red; MessageBox.Show("No debe rebasar el 70 % ..."); }

            }
            else { mtbPorc.ForeColor = Color.Red; MessageBox.Show("No debe rebasar el 70 % ..."); }
        }

        private void lbMargenRebajado_Click(object sender, EventArgs e)
        {
            Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "ValidacionDiferenciado").SingleOrDefault<Form>();
            {
                if (existe != null)
                {
                    MessageBox.Show("La ventana de Validacion ya esta abierta");
                }
                else
                {
                    ValidacionDiferenciado i = new ValidacionDiferenciado();
                    i.Show();
                }
            }
        }

        private void cbPorcentajes_SelectedIndexChanged(object sender, EventArgs e)
        {
            mtbPorc.Text = " ";
            ComboBox cbPorcentajes = (ComboBox)sender;
            mtbPorc.Text = cbPorcentajes.SelectedItem.ToString();
            mtbPorc.Text = mtbPorc.Text.Replace("%", "");
            mtbPorc.Text = "." + mtbPorc.Text;

            if (mtbPorc.Text == ".  ")
            {
                mtbPorc.Text = "0.00";
            }
                cbPorcentajes.Enabled = false;
                tbReferencia.Enabled = true;
                tbReferencia.Focus();

                if (tbReferencia.Text != " ")
                {
                    CalculoSubtotal();
                    Valida70porciento();

                    if (mtbSubTotal.Text == "0")
                    {
                        mtbIva.Text = "0";
                        mtbTotal.Text = "0";
                        mtbNOTCSTD.Text = "0";
                        mtbNOTPZA1.Text = "0";
                        mtbNOTIMP1.Text = "0";
                        mtbNOTDCF2.Text = "0";
                        mtbNOTIDC2.Text = "0";
                        mtbNOTIMF2.Text = "0";

                        mtbCostoNuevo.Text = mtbCosto.Text;
                        mtbPrecioNuevo.Text = mtbPrecio.Text;
                        mtbMargenNuevo.Text = mtbMargen.Text;

                        mtbCostoFinal.Text = mtbCosto.Text;
                        mtbPrecioFinal.Text = mtbPrecio.Text;
                        mtbMargenFinal.Text = mtbMargen.Text;
                    }
                }
                else { MessageBox.Show("No debe quedar en blanco la referencia"); }
        }
    }
}
