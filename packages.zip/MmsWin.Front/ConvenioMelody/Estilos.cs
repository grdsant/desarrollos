﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class Estilos : Form
    {
        Point mousedownpoint = Point.Empty;
        int nr;

        public System.Data.DataTable dtEstilos = null;

        public Estilos()
        {
            InitializeComponent();
        }

        private void pbSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Estilos_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void Estilos_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedownpoint.IsEmpty)
                return;
            Form f = sender as Form;
            f.Location = new Point(f.Location.X + (e.X - mousedownpoint.X), f.Location.Y + (e.Y - mousedownpoint.Y));
        }

        private void Estilos_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

        private void Estilos_Load(object sender, EventArgs e)
        {
            tbProveedor.Text = "999999";
            BindEstilos();
            SetFontAndColors();
            rowStyle();
            tbProveedor.Text = string.Empty;
        }

        protected void BindEstilos()
        {
            this.Cursor = Cursors.WaitCursor;
            try
            {
                string proveedor   = tbProveedor.Text;
                string nombre      = tbNombre.Text;
                string estilo      = tbEstilo.Text;
                string descripcion = tbDescripcion.Text;

                string dp = tbDP.Text;
                string sd = tbSD.Text;
                string cl = tbCL.Text;
                string sc = tbSC.Text;
                string dpd = tbDPD.Text;
                string sdd = tbSDD.Text;
                string cld = tbCLD.Text;
                string scd = tbSCD.Text;

                string usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                dtEstilos = MmsWin.Negocio.Catalogos.Estilos.GetInstance().ObtenEsilos(proveedor,nombre, estilo, descripcion, dp, sd, cl, sc, dpd, sdd, cld, scd, usuario);
            }
            catch  {  }

            if (dtEstilos != null)
            {
                if (dtEstilos.Rows.Count > 0)
                {
                    SetDoubleBuffered(dgvGridView);
                    dgvGridView.DataSource = null;

                    dgvGridView.DataSource = dtEstilos;

                    nr = dgvGridView.RowCount;
                    lbEstilos.Text = "Estilos / " + " " + (nr).ToString() + " Registro(s)";
                    //SetFontAndColors();
                    //rowStyle();

                    //// Seguridad...
                    //ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                    //Seguridad("Convenio", "Convenio", ParUser);
                    //dgvGridView.Visible = false;

                    //dgvGridView.Focus();
                    //dgvGridView.Select();
                }
            }
            this.Cursor = Cursors.Default;
        }

        public static void SetDoubleBuffered(Control control)
        {
            // set instance non-public property with name "DoubleBuffered" to true
            typeof(Control).InvokeMember("DoubleBuffered",
                BindingFlags.SetProperty | BindingFlags.Instance | BindingFlags.NonPublic,
                null, control, new object[] { true });
        }

        // Atributos y caracteristicas                                                                    
        //
        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.WhiteSmoke;
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new Font(dgvGridView.ColumnHeadersDefaultCellStyle.Font, FontStyle.Bold);


            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Olive;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.WhiteSmoke;
            this.dgvGridView.RowsDefaultCellStyle.BackColor = Color.Gray;
            this.dgvGridView.RowHeadersDefaultCellStyle.SelectionBackColor = Color.Empty;
            this.dgvGridView.RowHeadersDefaultCellStyle.BackColor = Color.Gray;
            this.dgvGridView.Columns[1].Frozen = true;

            dgvGridView.Columns["ESTPRV"].HeaderText = "Proveedor";
            dgvGridView.Columns["ESTPRD"].HeaderText = "Nombre";
            dgvGridView.Columns["ESPSTY"].HeaderText = "Estilo";
            dgvGridView.Columns["ESPDES"].HeaderText = "Descripción";
            dgvGridView.Columns["ESTDP"].HeaderText  = "DP";
            dgvGridView.Columns["ESTSD"].HeaderText  = "SD";
            dgvGridView.Columns["ESTCL"].HeaderText  = "CL";
            dgvGridView.Columns["ESTSC"].HeaderText  = "SC";
            dgvGridView.Columns["ESTDPD"].HeaderText = "Departamento";
            dgvGridView.Columns["ESTSDD"].HeaderText = "Sub Depto";
            dgvGridView.Columns["ESTCLD"].HeaderText = "Clase";
            dgvGridView.Columns["ESTSCD"].HeaderText = "Sub Clase";
            dgvGridView.Columns["ESTSTS"].HeaderText = "Sts";
            dgvGridView.Columns["ESTUAL"].HeaderText = "Usuario";
            dgvGridView.Columns["ESTFAL"].HeaderText = "Fecha";
            dgvGridView.Columns["ESTHAL"].HeaderText = "Hora";

            dgvGridView.Columns["ESTPRV"].Width = 40;
            dgvGridView.Columns["ESTPRD"].Width = 180;
            dgvGridView.Columns["ESPSTY"].Width = 80;
            dgvGridView.Columns["ESPDES"].Width = 180;
            dgvGridView.Columns["ESTDP"].Width  = 40;
            dgvGridView.Columns["ESTSD"].Width  = 40;
            dgvGridView.Columns["ESTCL"].Width  = 40;
            dgvGridView.Columns["ESTSC"].Width  = 40;
            dgvGridView.Columns["ESTDPD"].Width = 100;
            dgvGridView.Columns["ESTSDD"].Width = 100;
            dgvGridView.Columns["ESTCLD"].Width = 100;
            dgvGridView.Columns["ESTSCD"].Width = 100;
            dgvGridView.Columns["ESTSTS"].Width = 40;
            dgvGridView.Columns["ESTUAL"].Width = 70;
            dgvGridView.Columns["ESTFAL"].Width = 80;
            dgvGridView.Columns["ESTHAL"].Width = 80;

            dgvGridView.Columns["ESTFAL"].DefaultCellStyle.Format = "20##-##-##";
            dgvGridView.Columns["ESTHAL"].DefaultCellStyle.Format = "##:##:##";

            dgvGridView.Columns["ESTPRV"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTPRD"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESPSTY"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESPDES"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTDP"].DefaultCellStyle.NullValue  = true;
            dgvGridView.Columns["ESTSD"].DefaultCellStyle.NullValue  = true;
            dgvGridView.Columns["ESTCL"].DefaultCellStyle.NullValue  = true;
            dgvGridView.Columns["ESTSC"].DefaultCellStyle.NullValue  = true;
            dgvGridView.Columns["ESTDPD"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTSDD"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTCLD"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTSCD"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTSTS"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTUAL"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTFAL"].DefaultCellStyle.NullValue = true;
            dgvGridView.Columns["ESTHAL"].DefaultCellStyle.NullValue = true;

            dgvGridView.Columns["ESTPRV"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["ESTPRD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["ESPSTY"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["ESPDES"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["ESTDP"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["ESTSD"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["ESTCL"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["ESTSC"].DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;
            dgvGridView.Columns["ESTDPD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["ESTSDD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["ESTCLD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["ESTSCD"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dgvGridView.Columns["ESTSTS"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["ESTUAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["ESTFAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvGridView.Columns["ESTHAL"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvGridView.Columns["ESTPRV"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTPRD"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESPSTY"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESPDES"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTDP"].HeaderCell.Style.BackColor  = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTSD"].HeaderCell.Style.BackColor  = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTCL"].HeaderCell.Style.BackColor  = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTSC"].HeaderCell.Style.BackColor  = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTDPD"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTSDD"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTCLD"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTSCD"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTSTS"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTUAL"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTFAL"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);
            dgvGridView.Columns["ESTHAL"].HeaderCell.Style.BackColor = Color.FromArgb(64, 64, 64);

            dgvGridView.Columns["ESTPRV"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTPRD"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESPSTY"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESPDES"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTDP"].HeaderCell.Style.ForeColor  = Color.WhiteSmoke;
            dgvGridView.Columns["ESTSD"].HeaderCell.Style.ForeColor  = Color.WhiteSmoke;
            dgvGridView.Columns["ESTCL"].HeaderCell.Style.ForeColor  = Color.WhiteSmoke;
            dgvGridView.Columns["ESTSC"].HeaderCell.Style.ForeColor  = Color.WhiteSmoke;
            dgvGridView.Columns["ESTDPD"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTSDD"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTCLD"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTSCD"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTSTS"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTUAL"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTFAL"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
            dgvGridView.Columns["ESTHAL"].HeaderCell.Style.ForeColor = Color.WhiteSmoke;
        }
        // Estilo de Renglones                                                                            
        //
        private void rowStyle()
        {
            string vez = "si";
            int Regs = 0;
            foreach (DataGridViewRow rowp in dgvGridView.Rows)
            {
                int kia = rowp.Index;
                Regs += 1;
                if (vez == "Si")
                {
                    //dgvGridView.Rows[Regs - 1].DefaultCellStyle.BackColor = Color.LightGray;
                    vez = "No";
                }
                else
                {
                    vez = "Si";
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tbProveedor_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindEstilos();
                tbProveedor.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindEstilos();
                tbNombre.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbEstilo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindEstilos();
                tbEstilo.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindEstilos();
                tbDescripcion.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbDP_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindEstilos();
                tbDP.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbSD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindEstilos();
                tbSD.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbCL_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindEstilos();
                tbCL.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbSC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindEstilos();
                tbSC.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbDPD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindEstilos();
                tbDPD.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbSDD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindEstilos();
                tbSDD.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbCLD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindEstilos();
                tbCLD.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void tbSCD_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BindEstilos();
                tbSCD.Focus();
                SetFontAndColors();
                rowStyle();
            }
        }

        private void AgregarTSMI_Click(object sender, EventArgs e)
        {
            string message = "Esta seguro de agregar los estilos seleccionados?";
            string caption = "Confirmación";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                try
                {
                    string MoverFecha = string.Empty;

                    System.Data.DataTable dtEstilos = new System.Data.DataTable("Estilos");

                    dtEstilos.Columns.Add("marca", typeof(String));
                    dtEstilos.Columns.Add("grupo", typeof(String));
                    dtEstilos.Columns.Add("tipo", typeof(String));
                    dtEstilos.Columns.Add("dp", typeof(String));
                    dtEstilos.Columns.Add("sd", typeof(String));
                    dtEstilos.Columns.Add("cl", typeof(String));
                    dtEstilos.Columns.Add("sc", typeof(String));
                    dtEstilos.Columns.Add("proveedor", typeof(String));
                    dtEstilos.Columns.Add("estilo", typeof(String));

                    DataGridViewSelectedRowCollection Seleccionados = dgvGridView.SelectedRows;
                    foreach (DataGridViewRow item in Seleccionados)
                    {
                        DataRow workRow = dtEstilos.NewRow();

                        workRow["marca"] = MmsWin.Front.ConvenioMelody.GrupoTemporada.marca;
                        workRow["grupo"] = MmsWin.Front.ConvenioMelody.GrupoTemporada.grupo;
                        workRow["tipo"] = "EST";
                        workRow["dp"] = item.Cells["ESTDP"].Value.ToString();
                        workRow["sd"] = item.Cells["ESTSD"].Value.ToString();
                        workRow["cl"] = item.Cells["ESTCL"].Value.ToString();
                        workRow["sc"] = item.Cells["ESTSC"].Value.ToString();
                        workRow["proveedor"] = item.Cells["ESTPRV"].Value.ToString();
                        workRow["estilo"] = item.Cells["ESPSTY"].Value.ToString();

                        dtEstilos.Rows.Add(workRow);
                    }

                    if (dtEstilos.Rows.Count > 0)
                    {
                        string usuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        string mensaje = MmsWin.Negocio.ConvenioMelody.Estilos.GetInstance().AgregarEstilos(dtEstilos, usuario);
                        MessageBox.Show(mensaje);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Debe seleccionar por lo menos un estilo");
                    }
                }
                catch { }
                finally { }
            }
        }
    }
}
