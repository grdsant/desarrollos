﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class CalificacionGridTda
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.cmMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.fotoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rebajaDiferenciadaTlSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbHasta = new System.Windows.Forms.TextBox();
            this.tbDesde = new System.Windows.Forms.TextBox();
            this.mcC2 = new System.Windows.Forms.MonthCalendar();
            this.mcC1 = new System.Windows.Forms.MonthCalendar();
            this.btExcel = new System.Windows.Forms.Button();
            this.pgbProg = new System.Windows.Forms.ProgressBar();
            this.btQuitaChk = new System.Windows.Forms.Button();
            this.btPoneChks = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.cmMenuStrip.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.ContextMenuStrip = this.cmMenuStrip;
            this.dgvGridView.Location = new System.Drawing.Point(9, 40);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.Size = new System.Drawing.Size(845, 439);
            this.dgvGridView.TabIndex = 0;
            this.dgvGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellClick);
            this.dgvGridView.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellDoubleClick);
            this.dgvGridView.CellParsing += new System.Windows.Forms.DataGridViewCellParsingEventHandler(this.dgvGridView_CellParsing);
            this.dgvGridView.SelectionChanged += new System.EventHandler(this.dgvGridView_SelectionChanged);
            this.dgvGridView.Sorted += new System.EventHandler(this.dgvGridView_Sorted);
            this.dgvGridView.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dgvGridView_KeyPress);
            this.dgvGridView.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgvGridView_KeyUp);
            // 
            // cmMenuStrip
            // 
            this.cmMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fotoToolStripMenuItem,
            this.rebajaDiferenciadaTlSMI});
            this.cmMenuStrip.Name = "cmMenuStrip";
            this.cmMenuStrip.Size = new System.Drawing.Size(179, 48);
            // 
            // fotoToolStripMenuItem
            // 
            this.fotoToolStripMenuItem.Name = "fotoToolStripMenuItem";
            this.fotoToolStripMenuItem.Size = new System.Drawing.Size(178, 22);
            this.fotoToolStripMenuItem.Text = "Foto";
            this.fotoToolStripMenuItem.Click += new System.EventHandler(this.fotoToolStripMenuItem_Click);
            // 
            // rebajaDiferenciadaTlSMI
            // 
            this.rebajaDiferenciadaTlSMI.Name = "rebajaDiferenciadaTlSMI";
            this.rebajaDiferenciadaTlSMI.Size = new System.Drawing.Size(178, 22);
            this.rebajaDiferenciadaTlSMI.Text = "Rebaja Diferenciada";
            this.rebajaDiferenciadaTlSMI.Click += new System.EventHandler(this.rebajaDiferenciadaTlSMI_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.tbHasta);
            this.groupBox2.Controls.Add(this.tbDesde);
            this.groupBox2.Location = new System.Drawing.Point(230, 67);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(247, 47);
            this.groupBox2.TabIndex = 26;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Rango";
            this.groupBox2.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(130, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 38;
            this.label1.Text = "Hasta";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 13);
            this.label2.TabIndex = 37;
            this.label2.Text = "Desde";
            // 
            // tbHasta
            // 
            this.tbHasta.BackColor = System.Drawing.SystemColors.Control;
            this.tbHasta.Location = new System.Drawing.Point(167, 19);
            this.tbHasta.Name = "tbHasta";
            this.tbHasta.ReadOnly = true;
            this.tbHasta.Size = new System.Drawing.Size(74, 20);
            this.tbHasta.TabIndex = 36;
            this.tbHasta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbHasta.Click += new System.EventHandler(this.tbHasta_Click);
            // 
            // tbDesde
            // 
            this.tbDesde.Location = new System.Drawing.Point(50, 19);
            this.tbDesde.Name = "tbDesde";
            this.tbDesde.ReadOnly = true;
            this.tbDesde.Size = new System.Drawing.Size(76, 20);
            this.tbDesde.TabIndex = 35;
            this.tbDesde.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbDesde.Click += new System.EventHandler(this.tbDesde_Click);
            // 
            // mcC2
            // 
            this.mcC2.BackColor = System.Drawing.Color.Gray;
            this.mcC2.ForeColor = System.Drawing.Color.Black;
            this.mcC2.Location = new System.Drawing.Point(375, 126);
            this.mcC2.Name = "mcC2";
            this.mcC2.TabIndex = 45;
            this.mcC2.Visible = false;
            this.mcC2.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcC2_DateSelected);
            this.mcC2.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcC2_KeyUp);
            // 
            // mcC1
            // 
            this.mcC1.BackColor = System.Drawing.Color.Gray;
            this.mcC1.ForeColor = System.Drawing.Color.Black;
            this.mcC1.Location = new System.Drawing.Point(85, 126);
            this.mcC1.Name = "mcC1";
            this.mcC1.TabIndex = 44;
            this.mcC1.Visible = false;
            this.mcC1.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.mcC1_DateSelected);
            this.mcC1.KeyUp += new System.Windows.Forms.KeyEventHandler(this.mcC1_KeyUp);
            // 
            // btExcel
            // 
            this.btExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btExcel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btExcel.Image = global::MmsWin.Front.Properties.Resources.Microsoft_Excel_24px;
            this.btExcel.Location = new System.Drawing.Point(736, 5);
            this.btExcel.Name = "btExcel";
            this.btExcel.Size = new System.Drawing.Size(117, 31);
            this.btExcel.TabIndex = 54;
            this.btExcel.Text = "Exportar a Excel";
            this.btExcel.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btExcel.UseVisualStyleBackColor = false;
            this.btExcel.Click += new System.EventHandler(this.btExcel_Click);
            // 
            // pgbProg
            // 
            this.pgbProg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pgbProg.Location = new System.Drawing.Point(11, 481);
            this.pgbProg.Name = "pgbProg";
            this.pgbProg.Size = new System.Drawing.Size(843, 10);
            this.pgbProg.TabIndex = 55;
            this.pgbProg.Visible = false;
            // 
            // btQuitaChk
            // 
            this.btQuitaChk.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btQuitaChk.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btQuitaChk.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btQuitaChk.Image = global::MmsWin.Front.Properties.Resources.Unchecked_Checkbox_24px2;
            this.btQuitaChk.Location = new System.Drawing.Point(617, 5);
            this.btQuitaChk.Name = "btQuitaChk";
            this.btQuitaChk.Size = new System.Drawing.Size(117, 31);
            this.btQuitaChk.TabIndex = 62;
            this.btQuitaChk.Text = "Quitar Checks";
            this.btQuitaChk.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btQuitaChk.UseVisualStyleBackColor = false;
            this.btQuitaChk.Visible = false;
            this.btQuitaChk.Click += new System.EventHandler(this.btQuitaChk_Click);
            // 
            // btPoneChks
            // 
            this.btPoneChks.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btPoneChks.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btPoneChks.ForeColor = System.Drawing.Color.Green;
            this.btPoneChks.Image = global::MmsWin.Front.Properties.Resources.CheckedNo_Checkbox_24px;
            this.btPoneChks.Location = new System.Drawing.Point(498, 5);
            this.btPoneChks.Name = "btPoneChks";
            this.btPoneChks.Size = new System.Drawing.Size(117, 31);
            this.btPoneChks.TabIndex = 61;
            this.btPoneChks.Text = "Poner Checks";
            this.btPoneChks.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btPoneChks.UseVisualStyleBackColor = false;
            this.btPoneChks.Visible = false;
            this.btPoneChks.Click += new System.EventHandler(this.btPoneChks_Click);
            // 
            // CalificacionGridTda
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(863, 496);
            this.Controls.Add(this.btQuitaChk);
            this.Controls.Add(this.btPoneChks);
            this.Controls.Add(this.pgbProg);
            this.Controls.Add(this.btExcel);
            this.Controls.Add(this.mcC2);
            this.Controls.Add(this.mcC1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dgvGridView);
            this.DoubleBuffered = true;
            this.MinimizeBox = false;
            this.Name = "CalificacionGridTda";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calificaciones por Tienda";
            this.Load += new System.EventHandler(this.CalificacionGridTda_Load);
            this.Resize += new System.EventHandler(this.CalificacionGridTda_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.cmMenuStrip.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }
        #endregion
        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.ContextMenuStrip cmMenuStrip;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbHasta;
        private System.Windows.Forms.TextBox tbDesde;
        private System.Windows.Forms.MonthCalendar mcC2;
        private System.Windows.Forms.MonthCalendar mcC1;
        private System.Windows.Forms.ToolStripMenuItem fotoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rebajaDiferenciadaTlSMI;
        private System.Windows.Forms.Button btExcel;
        private System.Windows.Forms.ProgressBar pgbProg;
        private System.Windows.Forms.Button btQuitaChk;
        private System.Windows.Forms.Button btPoneChks;
    }
}