﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class Estilos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Estilos));
            this.panel1 = new System.Windows.Forms.Panel();
            this.tbSCD = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbEstilo = new System.Windows.Forms.TextBox();
            this.tbNombre = new System.Windows.Forms.TextBox();
            this.tbProveedor = new System.Windows.Forms.TextBox();
            this.tbCLD = new System.Windows.Forms.TextBox();
            this.tbSDD = new System.Windows.Forms.TextBox();
            this.tbSC = new System.Windows.Forms.TextBox();
            this.tbCL = new System.Windows.Forms.TextBox();
            this.tbSD = new System.Windows.Forms.TextBox();
            this.tbDP = new System.Windows.Forms.TextBox();
            this.btRelleno = new System.Windows.Forms.Button();
            this.tbDPD = new System.Windows.Forms.TextBox();
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.lbEstilos = new System.Windows.Forms.Label();
            this.pbSalir = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.AgregarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.cmMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel1.Controls.Add(this.tbSCD);
            this.panel1.Controls.Add(this.tbDescripcion);
            this.panel1.Controls.Add(this.tbEstilo);
            this.panel1.Controls.Add(this.tbNombre);
            this.panel1.Controls.Add(this.tbProveedor);
            this.panel1.Controls.Add(this.tbCLD);
            this.panel1.Controls.Add(this.tbSDD);
            this.panel1.Controls.Add(this.tbSC);
            this.panel1.Controls.Add(this.tbCL);
            this.panel1.Controls.Add(this.tbSD);
            this.panel1.Controls.Add(this.tbDP);
            this.panel1.Controls.Add(this.btRelleno);
            this.panel1.Controls.Add(this.tbDPD);
            this.panel1.Controls.Add(this.dgvGridView);
            this.panel1.Location = new System.Drawing.Point(1, 33);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1164, 420);
            this.panel1.TabIndex = 2;
            // 
            // tbSCD
            // 
            this.tbSCD.Location = new System.Drawing.Point(985, 2);
            this.tbSCD.Name = "tbSCD";
            this.tbSCD.Size = new System.Drawing.Size(100, 20);
            this.tbSCD.TabIndex = 11;
            this.tbSCD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSCD_KeyPress);
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbDescripcion.Location = new System.Drawing.Point(345, 2);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(180, 20);
            this.tbDescripcion.TabIndex = 3;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress);
            // 
            // tbEstilo
            // 
            this.tbEstilo.Location = new System.Drawing.Point(265, 2);
            this.tbEstilo.Name = "tbEstilo";
            this.tbEstilo.Size = new System.Drawing.Size(80, 20);
            this.tbEstilo.TabIndex = 2;
            this.tbEstilo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbEstilo_KeyPress);
            // 
            // tbNombre
            // 
            this.tbNombre.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbNombre.Location = new System.Drawing.Point(85, 2);
            this.tbNombre.Name = "tbNombre";
            this.tbNombre.Size = new System.Drawing.Size(180, 20);
            this.tbNombre.TabIndex = 1;
            this.tbNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbNombre_KeyPress);
            // 
            // tbProveedor
            // 
            this.tbProveedor.Location = new System.Drawing.Point(45, 2);
            this.tbProveedor.Name = "tbProveedor";
            this.tbProveedor.Size = new System.Drawing.Size(40, 20);
            this.tbProveedor.TabIndex = 0;
            this.tbProveedor.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbProveedor_KeyPress);
            // 
            // tbCLD
            // 
            this.tbCLD.Location = new System.Drawing.Point(885, 2);
            this.tbCLD.Name = "tbCLD";
            this.tbCLD.Size = new System.Drawing.Size(100, 20);
            this.tbCLD.TabIndex = 10;
            this.tbCLD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCLD_KeyPress);
            // 
            // tbSDD
            // 
            this.tbSDD.Location = new System.Drawing.Point(785, 2);
            this.tbSDD.Name = "tbSDD";
            this.tbSDD.Size = new System.Drawing.Size(100, 20);
            this.tbSDD.TabIndex = 9;
            this.tbSDD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSDD_KeyPress);
            // 
            // tbSC
            // 
            this.tbSC.Location = new System.Drawing.Point(645, 2);
            this.tbSC.Name = "tbSC";
            this.tbSC.Size = new System.Drawing.Size(40, 20);
            this.tbSC.TabIndex = 7;
            this.tbSC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSC_KeyPress);
            // 
            // tbCL
            // 
            this.tbCL.Location = new System.Drawing.Point(605, 2);
            this.tbCL.Name = "tbCL";
            this.tbCL.Size = new System.Drawing.Size(40, 20);
            this.tbCL.TabIndex = 6;
            this.tbCL.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbCL_KeyPress);
            // 
            // tbSD
            // 
            this.tbSD.Location = new System.Drawing.Point(565, 2);
            this.tbSD.Name = "tbSD";
            this.tbSD.Size = new System.Drawing.Size(40, 20);
            this.tbSD.TabIndex = 5;
            this.tbSD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSD_KeyPress);
            // 
            // tbDP
            // 
            this.tbDP.Location = new System.Drawing.Point(525, 2);
            this.tbDP.Name = "tbDP";
            this.tbDP.Size = new System.Drawing.Size(40, 20);
            this.tbDP.TabIndex = 4;
            this.tbDP.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDP_KeyPress);
            // 
            // btRelleno
            // 
            this.btRelleno.Location = new System.Drawing.Point(2, 1);
            this.btRelleno.Name = "btRelleno";
            this.btRelleno.Size = new System.Drawing.Size(44, 22);
            this.btRelleno.TabIndex = 22;
            this.btRelleno.UseVisualStyleBackColor = true;
            // 
            // tbDPD
            // 
            this.tbDPD.Location = new System.Drawing.Point(685, 2);
            this.tbDPD.Name = "tbDPD";
            this.tbDPD.Size = new System.Drawing.Size(100, 20);
            this.tbDPD.TabIndex = 8;
            this.tbDPD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDPD_KeyPress);
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.ContextMenuStrip = this.cmMenu;
            this.dgvGridView.Location = new System.Drawing.Point(3, 23);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.Size = new System.Drawing.Size(1158, 395);
            this.dgvGridView.TabIndex = 12;
            // 
            // lbEstilos
            // 
            this.lbEstilos.AutoSize = true;
            this.lbEstilos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEstilos.ForeColor = System.Drawing.Color.Silver;
            this.lbEstilos.Location = new System.Drawing.Point(3, 5);
            this.lbEstilos.Name = "lbEstilos";
            this.lbEstilos.Size = new System.Drawing.Size(63, 20);
            this.lbEstilos.TabIndex = 3;
            this.lbEstilos.Text = "Estilos";
            // 
            // pbSalir
            // 
            this.pbSalir.Image = ((System.Drawing.Image)(resources.GetObject("pbSalir.Image")));
            this.pbSalir.Location = new System.Drawing.Point(1173, 7);
            this.pbSalir.Name = "pbSalir";
            this.pbSalir.Size = new System.Drawing.Size(22, 18);
            this.pbSalir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSalir.TabIndex = 8;
            this.pbSalir.TabStop = false;
            this.pbSalir.Click += new System.EventHandler(this.pbSalir_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1136, 7);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(22, 18);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AgregarTSMI});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(153, 26);
            // 
            // AgregarTSMI
            // 
            this.AgregarTSMI.Name = "AgregarTSMI";
            this.AgregarTSMI.Size = new System.Drawing.Size(152, 22);
            this.AgregarTSMI.Text = "Agregar Estilos";
            this.AgregarTSMI.Click += new System.EventHandler(this.AgregarTSMI_Click);
            // 
            // Estilos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1166, 453);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pbSalir);
            this.Controls.Add(this.lbEstilos);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Estilos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Estilos";
            this.Load += new System.EventHandler(this.Estilos_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Estilos_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Estilos_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Estilos_MouseUp);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.cmMenu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbEstilos;
        private System.Windows.Forms.PictureBox pbSalir;
        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbEstilo;
        private System.Windows.Forms.TextBox tbNombre;
        private System.Windows.Forms.TextBox tbProveedor;
        private System.Windows.Forms.TextBox tbCLD;
        private System.Windows.Forms.TextBox tbSDD;
        private System.Windows.Forms.TextBox tbSC;
        private System.Windows.Forms.TextBox tbCL;
        private System.Windows.Forms.TextBox tbSD;
        private System.Windows.Forms.Button btRelleno;
        private System.Windows.Forms.TextBox tbDPD;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox tbDP;
        private System.Windows.Forms.TextBox tbSCD;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem AgregarTSMI;
    }
}