﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class CatalogoTemporadas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CatalogoTemporadas));
            this.panel01 = new System.Windows.Forms.Panel();
            this.tbMarca = new System.Windows.Forms.TextBox();
            this.btRelleno = new System.Windows.Forms.Button();
            this.btABC = new System.Windows.Forms.Button();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbTemporada = new System.Windows.Forms.TextBox();
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.cmMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.ConsultarTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.detalleTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.detGrupNivelEstTSMI = new System.Windows.Forms.ToolStripMenuItem();
            this.lbTitulo = new System.Windows.Forms.Label();
            this.pbSalir = new System.Windows.Forms.PictureBox();
            this.panel01.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.cmMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).BeginInit();
            this.SuspendLayout();
            // 
            // panel01
            // 
            this.panel01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel01.Controls.Add(this.tbMarca);
            this.panel01.Controls.Add(this.btRelleno);
            this.panel01.Controls.Add(this.btABC);
            this.panel01.Controls.Add(this.tbDescripcion);
            this.panel01.Controls.Add(this.tbTemporada);
            this.panel01.Controls.Add(this.dgvGridView);
            this.panel01.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel01.Location = new System.Drawing.Point(0, 53);
            this.panel01.Name = "panel01";
            this.panel01.Size = new System.Drawing.Size(607, 321);
            this.panel01.TabIndex = 11;
            // 
            // tbMarca
            // 
            this.tbMarca.Location = new System.Drawing.Point(47, 6);
            this.tbMarca.Name = "tbMarca";
            this.tbMarca.Size = new System.Drawing.Size(59, 20);
            this.tbMarca.TabIndex = 5;
            this.tbMarca.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbMarca_KeyPress_1);
            // 
            // btRelleno
            // 
            this.btRelleno.Location = new System.Drawing.Point(3, 5);
            this.btRelleno.Name = "btRelleno";
            this.btRelleno.Size = new System.Drawing.Size(45, 22);
            this.btRelleno.TabIndex = 4;
            this.btRelleno.UseVisualStyleBackColor = true;
            // 
            // btABC
            // 
            this.btABC.ForeColor = System.Drawing.Color.Black;
            this.btABC.Location = new System.Drawing.Point(555, 4);
            this.btABC.Name = "btABC";
            this.btABC.Size = new System.Drawing.Size(48, 23);
            this.btABC.TabIndex = 3;
            this.btABC.Text = "Nuevo";
            this.btABC.UseVisualStyleBackColor = true;
            this.btABC.Click += new System.EventHandler(this.btABC_Click);
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.Location = new System.Drawing.Point(167, 6);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(200, 20);
            this.tbDescripcion.TabIndex = 2;
            this.tbDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbDescripcion_KeyPress);
            // 
            // tbTemporada
            // 
            this.tbTemporada.Location = new System.Drawing.Point(106, 6);
            this.tbTemporada.Name = "tbTemporada";
            this.tbTemporada.Size = new System.Drawing.Size(61, 20);
            this.tbTemporada.TabIndex = 1;
            this.tbTemporada.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbTemporada_KeyPress);
            // 
            // dgvGridView
            // 
            this.dgvGridView.AllowUserToAddRows = false;
            this.dgvGridView.AllowUserToDeleteRows = false;
            this.dgvGridView.AllowUserToOrderColumns = true;
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.ContextMenuStrip = this.cmMenu;
            this.dgvGridView.Location = new System.Drawing.Point(4, 27);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.ReadOnly = true;
            this.dgvGridView.Size = new System.Drawing.Size(599, 289);
            this.dgvGridView.TabIndex = 0;
            this.dgvGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvGridView_CellClick);
            this.dgvGridView.SelectionChanged += new System.EventHandler(this.dgvGridView_SelectionChanged);
            this.dgvGridView.DoubleClick += new System.EventHandler(this.dgvGridView_DoubleClick);
            // 
            // cmMenu
            // 
            this.cmMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ConsultarTSMI,
            this.detalleTSMI,
            this.detGrupNivelEstTSMI});
            this.cmMenu.Name = "cmMenu";
            this.cmMenu.Size = new System.Drawing.Size(225, 70);
            // 
            // ConsultarTSMI
            // 
            this.ConsultarTSMI.Name = "ConsultarTSMI";
            this.ConsultarTSMI.Size = new System.Drawing.Size(224, 22);
            this.ConsultarTSMI.Text = "Mantenimiento";
            this.ConsultarTSMI.Click += new System.EventHandler(this.ConsultarTSMI_Click);
            // 
            // detalleTSMI
            // 
            this.detalleTSMI.Name = "detalleTSMI";
            this.detalleTSMI.Size = new System.Drawing.Size(224, 22);
            this.detalleTSMI.Text = "Detalle del grupo";
            this.detalleTSMI.Click += new System.EventHandler(this.detalleTSMI_Click);
            // 
            // detGrupNivelEstTSMI
            // 
            this.detGrupNivelEstTSMI.Name = "detGrupNivelEstTSMI";
            this.detGrupNivelEstTSMI.Size = new System.Drawing.Size(224, 22);
            this.detGrupNivelEstTSMI.Text = "Detalle del Grupo nivel estilo";
            this.detGrupNivelEstTSMI.Click += new System.EventHandler(this.detGrupNivelEstTSMI_Click);
            // 
            // lbTitulo
            // 
            this.lbTitulo.AutoSize = true;
            this.lbTitulo.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbTitulo.Location = new System.Drawing.Point(9, 13);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(108, 21);
            this.lbTitulo.TabIndex = 33;
            this.lbTitulo.Text = "Agrupaciones";
            // 
            // pbSalir
            // 
            this.pbSalir.Image = ((System.Drawing.Image)(resources.GetObject("pbSalir.Image")));
            this.pbSalir.Location = new System.Drawing.Point(576, 13);
            this.pbSalir.Name = "pbSalir";
            this.pbSalir.Size = new System.Drawing.Size(22, 18);
            this.pbSalir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSalir.TabIndex = 34;
            this.pbSalir.TabStop = false;
            this.pbSalir.Click += new System.EventHandler(this.pbSalir_Click_1);
            // 
            // CatalogoTemporadas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(607, 374);
            this.Controls.Add(this.pbSalir);
            this.Controls.Add(this.lbTitulo);
            this.Controls.Add(this.panel01);
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CatalogoTemporadas";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CatalogoTemporadas";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CatalogoTemporadas_FormClosing);
            this.Load += new System.EventHandler(this.CatalogoTemporadas_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.CatalogoTemporadas_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.CatalogoTemporadas_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.CatalogoTemporadas_MouseUp);
            this.panel01.ResumeLayout(false);
            this.panel01.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.cmMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel01;
        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbTemporada;
        private System.Windows.Forms.Label lbTitulo;
        private System.Windows.Forms.Button btABC;
        private System.Windows.Forms.ContextMenuStrip cmMenu;
        private System.Windows.Forms.ToolStripMenuItem ConsultarTSMI;
        private System.Windows.Forms.Button btRelleno;
        private System.Windows.Forms.TextBox tbMarca;
        private System.Windows.Forms.ToolStripMenuItem detalleTSMI;
        private System.Windows.Forms.PictureBox pbSalir;
        private System.Windows.Forms.ToolStripMenuItem detGrupNivelEstTSMI;
    }
}