﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class DetCatTempABC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel01 = new System.Windows.Forms.Panel();
            this.lbAyudaSts = new System.Windows.Forms.Label();
            this.lbAyudaSecuencia = new System.Windows.Forms.Label();
            this.lbAyudaTabla = new System.Windows.Forms.Label();
            this.lbAyudaMarca = new System.Windows.Forms.Label();
            this.lbMsjSts = new System.Windows.Forms.Label();
            this.lbMsjDescripcion = new System.Windows.Forms.Label();
            this.lbMsjTemporada = new System.Windows.Forms.Label();
            this.lbMsjMarca = new System.Windows.Forms.Label();
            this.lbEstatus = new System.Windows.Forms.Label();
            this.lbSecuencia = new System.Windows.Forms.Label();
            this.lbNoTabla = new System.Windows.Forms.Label();
            this.lbMarca = new System.Windows.Forms.Label();
            this.btElimiar = new System.Windows.Forms.Button();
            this.btCambio = new System.Windows.Forms.Button();
            this.btAlta = new System.Windows.Forms.Button();
            this.btCancelar = new System.Windows.Forms.Button();
            this.lbHora = new System.Windows.Forms.Label();
            this.lbFecha = new System.Windows.Forms.Label();
            this.lbUsuario = new System.Windows.Forms.Label();
            this.tbHoraCambio = new System.Windows.Forms.TextBox();
            this.tbFechaCambio = new System.Windows.Forms.TextBox();
            this.tbHoraAlta = new System.Windows.Forms.TextBox();
            this.tbFechaAlta = new System.Windows.Forms.TextBox();
            this.tbUserCambio = new System.Windows.Forms.TextBox();
            this.tbUserAlta = new System.Windows.Forms.TextBox();
            this.tbSts = new System.Windows.Forms.TextBox();
            this.tbDescripcion = new System.Windows.Forms.TextBox();
            this.tbTemporada = new System.Windows.Forms.TextBox();
            this.tbMarca = new System.Windows.Forms.TextBox();
            this.lbTitulo = new System.Windows.Forms.Label();
            this.panel01.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel01
            // 
            this.panel01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.panel01.Controls.Add(this.lbAyudaSts);
            this.panel01.Controls.Add(this.lbAyudaSecuencia);
            this.panel01.Controls.Add(this.lbAyudaTabla);
            this.panel01.Controls.Add(this.lbAyudaMarca);
            this.panel01.Controls.Add(this.lbMsjSts);
            this.panel01.Controls.Add(this.lbMsjDescripcion);
            this.panel01.Controls.Add(this.lbMsjTemporada);
            this.panel01.Controls.Add(this.lbMsjMarca);
            this.panel01.Controls.Add(this.lbEstatus);
            this.panel01.Controls.Add(this.lbSecuencia);
            this.panel01.Controls.Add(this.lbNoTabla);
            this.panel01.Controls.Add(this.lbMarca);
            this.panel01.Controls.Add(this.btElimiar);
            this.panel01.Controls.Add(this.btCambio);
            this.panel01.Controls.Add(this.btAlta);
            this.panel01.Controls.Add(this.btCancelar);
            this.panel01.Controls.Add(this.lbHora);
            this.panel01.Controls.Add(this.lbFecha);
            this.panel01.Controls.Add(this.lbUsuario);
            this.panel01.Controls.Add(this.tbHoraCambio);
            this.panel01.Controls.Add(this.tbFechaCambio);
            this.panel01.Controls.Add(this.tbHoraAlta);
            this.panel01.Controls.Add(this.tbFechaAlta);
            this.panel01.Controls.Add(this.tbUserCambio);
            this.panel01.Controls.Add(this.tbUserAlta);
            this.panel01.Controls.Add(this.tbSts);
            this.panel01.Controls.Add(this.tbDescripcion);
            this.panel01.Controls.Add(this.tbTemporada);
            this.panel01.Controls.Add(this.tbMarca);
            this.panel01.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel01.Location = new System.Drawing.Point(0, 44);
            this.panel01.Name = "panel01";
            this.panel01.Size = new System.Drawing.Size(442, 251);
            this.panel01.TabIndex = 10;
            // 
            // lbAyudaSts
            // 
            this.lbAyudaSts.AutoSize = true;
            this.lbAyudaSts.Location = new System.Drawing.Point(280, 100);
            this.lbAyudaSts.Name = "lbAyudaSts";
            this.lbAyudaSts.Size = new System.Drawing.Size(148, 13);
            this.lbAyudaSts.TabIndex = 47;
            this.lbAyudaSts.Text = "A = Activo ,  D = Desactivado";
            // 
            // lbAyudaSecuencia
            // 
            this.lbAyudaSecuencia.AutoSize = true;
            this.lbAyudaSecuencia.Location = new System.Drawing.Point(279, 73);
            this.lbAyudaSecuencia.Name = "lbAyudaSecuencia";
            this.lbAyudaSecuencia.Size = new System.Drawing.Size(0, 13);
            this.lbAyudaSecuencia.TabIndex = 42;
            // 
            // lbAyudaTabla
            // 
            this.lbAyudaTabla.AutoSize = true;
            this.lbAyudaTabla.Location = new System.Drawing.Point(280, 47);
            this.lbAyudaTabla.Name = "lbAyudaTabla";
            this.lbAyudaTabla.Size = new System.Drawing.Size(62, 13);
            this.lbAyudaTabla.TabIndex = 41;
            this.lbAyudaTabla.Text = "del 1 al 999";
            // 
            // lbAyudaMarca
            // 
            this.lbAyudaMarca.AutoSize = true;
            this.lbAyudaMarca.Location = new System.Drawing.Point(280, 21);
            this.lbAyudaMarca.Name = "lbAyudaMarca";
            this.lbAyudaMarca.Size = new System.Drawing.Size(156, 13);
            this.lbAyudaMarca.TabIndex = 40;
            this.lbAyudaMarca.Text = "10 Meody, 30 Milano, 60 Kaltex";
            // 
            // lbMsjSts
            // 
            this.lbMsjSts.AutoSize = true;
            this.lbMsjSts.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbMsjSts.Location = new System.Drawing.Point(251, 100);
            this.lbMsjSts.Name = "lbMsjSts";
            this.lbMsjSts.Size = new System.Drawing.Size(28, 13);
            this.lbMsjSts.TabIndex = 39;
            this.lbMsjSts.Text = "error";
            this.lbMsjSts.Visible = false;
            // 
            // lbMsjDescripcion
            // 
            this.lbMsjDescripcion.AutoSize = true;
            this.lbMsjDescripcion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbMsjDescripcion.Location = new System.Drawing.Point(251, 73);
            this.lbMsjDescripcion.Name = "lbMsjDescripcion";
            this.lbMsjDescripcion.Size = new System.Drawing.Size(28, 13);
            this.lbMsjDescripcion.TabIndex = 34;
            this.lbMsjDescripcion.Text = "error";
            this.lbMsjDescripcion.Visible = false;
            // 
            // lbMsjTemporada
            // 
            this.lbMsjTemporada.AutoSize = true;
            this.lbMsjTemporada.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbMsjTemporada.Location = new System.Drawing.Point(251, 47);
            this.lbMsjTemporada.Name = "lbMsjTemporada";
            this.lbMsjTemporada.Size = new System.Drawing.Size(28, 13);
            this.lbMsjTemporada.TabIndex = 33;
            this.lbMsjTemporada.Text = "error";
            this.lbMsjTemporada.Visible = false;
            // 
            // lbMsjMarca
            // 
            this.lbMsjMarca.AutoSize = true;
            this.lbMsjMarca.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbMsjMarca.Location = new System.Drawing.Point(251, 20);
            this.lbMsjMarca.Name = "lbMsjMarca";
            this.lbMsjMarca.Size = new System.Drawing.Size(28, 13);
            this.lbMsjMarca.TabIndex = 32;
            this.lbMsjMarca.Text = "error";
            this.lbMsjMarca.Visible = false;
            // 
            // lbEstatus
            // 
            this.lbEstatus.AutoSize = true;
            this.lbEstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEstatus.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbEstatus.Location = new System.Drawing.Point(15, 100);
            this.lbEstatus.Name = "lbEstatus";
            this.lbEstatus.Size = new System.Drawing.Size(49, 13);
            this.lbEstatus.TabIndex = 31;
            this.lbEstatus.Text = "Estatus";
            // 
            // lbSecuencia
            // 
            this.lbSecuencia.AutoSize = true;
            this.lbSecuencia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSecuencia.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbSecuencia.Location = new System.Drawing.Point(15, 73);
            this.lbSecuencia.Name = "lbSecuencia";
            this.lbSecuencia.Size = new System.Drawing.Size(74, 13);
            this.lbSecuencia.TabIndex = 26;
            this.lbSecuencia.Text = "Descripción";
            // 
            // lbNoTabla
            // 
            this.lbNoTabla.AutoSize = true;
            this.lbNoTabla.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNoTabla.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbNoTabla.Location = new System.Drawing.Point(15, 47);
            this.lbNoTabla.Name = "lbNoTabla";
            this.lbNoTabla.Size = new System.Drawing.Size(41, 13);
            this.lbNoTabla.TabIndex = 25;
            this.lbNoTabla.Text = "Grupo";
            // 
            // lbMarca
            // 
            this.lbMarca.AutoSize = true;
            this.lbMarca.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbMarca.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbMarca.Location = new System.Drawing.Point(15, 21);
            this.lbMarca.Name = "lbMarca";
            this.lbMarca.Size = new System.Drawing.Size(42, 13);
            this.lbMarca.TabIndex = 24;
            this.lbMarca.Text = "Marca";
            // 
            // btElimiar
            // 
            this.btElimiar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btElimiar.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btElimiar.Image = global::MmsWin.Front.Properties.Resources.Waste_32px;
            this.btElimiar.Location = new System.Drawing.Point(333, 192);
            this.btElimiar.Name = "btElimiar";
            this.btElimiar.Size = new System.Drawing.Size(100, 39);
            this.btElimiar.TabIndex = 20;
            this.btElimiar.Text = "   Eliminar";
            this.btElimiar.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btElimiar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btElimiar.UseVisualStyleBackColor = true;
            this.btElimiar.Click += new System.EventHandler(this.btElimiar_Click);
            // 
            // btCambio
            // 
            this.btCambio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCambio.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btCambio.Image = global::MmsWin.Front.Properties.Resources.Change_32px;
            this.btCambio.Location = new System.Drawing.Point(227, 192);
            this.btCambio.Name = "btCambio";
            this.btCambio.Size = new System.Drawing.Size(100, 39);
            this.btCambio.TabIndex = 19;
            this.btCambio.Text = "  Cambio";
            this.btCambio.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btCambio.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btCambio.UseVisualStyleBackColor = true;
            this.btCambio.Click += new System.EventHandler(this.btCambio_Click);
            // 
            // btAlta
            // 
            this.btAlta.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btAlta.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btAlta.Image = global::MmsWin.Front.Properties.Resources.Save_32px;
            this.btAlta.Location = new System.Drawing.Point(121, 192);
            this.btAlta.Name = "btAlta";
            this.btAlta.Size = new System.Drawing.Size(100, 39);
            this.btAlta.TabIndex = 18;
            this.btAlta.Text = "     Alta";
            this.btAlta.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btAlta.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btAlta.UseCompatibleTextRendering = true;
            this.btAlta.UseVisualStyleBackColor = true;
            this.btAlta.Click += new System.EventHandler(this.btAlta_Click);
            // 
            // btCancelar
            // 
            this.btCancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCancelar.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btCancelar.Image = global::MmsWin.Front.Properties.Resources.Back_Arrow_32px;
            this.btCancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btCancelar.Location = new System.Drawing.Point(15, 192);
            this.btCancelar.Name = "btCancelar";
            this.btCancelar.Size = new System.Drawing.Size(100, 39);
            this.btCancelar.TabIndex = 17;
            this.btCancelar.Text = "   Salir";
            this.btCancelar.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btCancelar.UseVisualStyleBackColor = true;
            this.btCancelar.Click += new System.EventHandler(this.btCancelar_Click);
            // 
            // lbHora
            // 
            this.lbHora.AutoSize = true;
            this.lbHora.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbHora.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbHora.Location = new System.Drawing.Point(78, 169);
            this.lbHora.Name = "lbHora";
            this.lbHora.Size = new System.Drawing.Size(34, 13);
            this.lbHora.TabIndex = 16;
            this.lbHora.Text = "Hora";
            // 
            // lbFecha
            // 
            this.lbFecha.AutoSize = true;
            this.lbFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFecha.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbFecha.Location = new System.Drawing.Point(78, 143);
            this.lbFecha.Name = "lbFecha";
            this.lbFecha.Size = new System.Drawing.Size(42, 13);
            this.lbFecha.TabIndex = 15;
            this.lbFecha.Text = "Fecha";
            // 
            // lbUsuario
            // 
            this.lbUsuario.AutoSize = true;
            this.lbUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbUsuario.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lbUsuario.Location = new System.Drawing.Point(330, 120);
            this.lbUsuario.Name = "lbUsuario";
            this.lbUsuario.Size = new System.Drawing.Size(50, 13);
            this.lbUsuario.TabIndex = 14;
            this.lbUsuario.Text = "Usuario";
            // 
            // tbHoraCambio
            // 
            this.tbHoraCambio.BackColor = System.Drawing.SystemColors.Control;
            this.tbHoraCambio.Enabled = false;
            this.tbHoraCambio.Location = new System.Drawing.Point(229, 162);
            this.tbHoraCambio.Name = "tbHoraCambio";
            this.tbHoraCambio.Size = new System.Drawing.Size(100, 20);
            this.tbHoraCambio.TabIndex = 13;
            // 
            // tbFechaCambio
            // 
            this.tbFechaCambio.BackColor = System.Drawing.SystemColors.Control;
            this.tbFechaCambio.Enabled = false;
            this.tbFechaCambio.Location = new System.Drawing.Point(229, 136);
            this.tbFechaCambio.Name = "tbFechaCambio";
            this.tbFechaCambio.Size = new System.Drawing.Size(100, 20);
            this.tbFechaCambio.TabIndex = 12;
            // 
            // tbHoraAlta
            // 
            this.tbHoraAlta.BackColor = System.Drawing.SystemColors.Control;
            this.tbHoraAlta.Enabled = false;
            this.tbHoraAlta.Location = new System.Drawing.Point(121, 162);
            this.tbHoraAlta.Name = "tbHoraAlta";
            this.tbHoraAlta.Size = new System.Drawing.Size(100, 20);
            this.tbHoraAlta.TabIndex = 11;
            // 
            // tbFechaAlta
            // 
            this.tbFechaAlta.BackColor = System.Drawing.SystemColors.Control;
            this.tbFechaAlta.Enabled = false;
            this.tbFechaAlta.Location = new System.Drawing.Point(121, 136);
            this.tbFechaAlta.Name = "tbFechaAlta";
            this.tbFechaAlta.Size = new System.Drawing.Size(100, 20);
            this.tbFechaAlta.TabIndex = 10;
            // 
            // tbUserCambio
            // 
            this.tbUserCambio.BackColor = System.Drawing.SystemColors.Control;
            this.tbUserCambio.Enabled = false;
            this.tbUserCambio.Location = new System.Drawing.Point(333, 162);
            this.tbUserCambio.Name = "tbUserCambio";
            this.tbUserCambio.Size = new System.Drawing.Size(100, 20);
            this.tbUserCambio.TabIndex = 9;
            // 
            // tbUserAlta
            // 
            this.tbUserAlta.BackColor = System.Drawing.SystemColors.Control;
            this.tbUserAlta.Enabled = false;
            this.tbUserAlta.Location = new System.Drawing.Point(333, 136);
            this.tbUserAlta.Name = "tbUserAlta";
            this.tbUserAlta.Size = new System.Drawing.Size(100, 20);
            this.tbUserAlta.TabIndex = 8;
            // 
            // tbSts
            // 
            this.tbSts.Location = new System.Drawing.Point(108, 93);
            this.tbSts.Name = "tbSts";
            this.tbSts.Size = new System.Drawing.Size(143, 20);
            this.tbSts.TabIndex = 7;
            this.tbSts.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbDescripcion
            // 
            this.tbDescripcion.Location = new System.Drawing.Point(108, 66);
            this.tbDescripcion.Name = "tbDescripcion";
            this.tbDescripcion.Size = new System.Drawing.Size(143, 20);
            this.tbDescripcion.TabIndex = 2;
            this.tbDescripcion.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTemporada
            // 
            this.tbTemporada.Location = new System.Drawing.Point(108, 40);
            this.tbTemporada.Name = "tbTemporada";
            this.tbTemporada.Size = new System.Drawing.Size(143, 20);
            this.tbTemporada.TabIndex = 1;
            this.tbTemporada.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbMarca
            // 
            this.tbMarca.Location = new System.Drawing.Point(108, 14);
            this.tbMarca.Name = "tbMarca";
            this.tbMarca.Size = new System.Drawing.Size(143, 20);
            this.tbMarca.TabIndex = 0;
            this.tbMarca.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbTitulo
            // 
            this.lbTitulo.AutoSize = true;
            this.lbTitulo.Font = new System.Drawing.Font("Arial Unicode MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.lbTitulo.Location = new System.Drawing.Point(8, 8);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(169, 21);
            this.lbTitulo.TabIndex = 32;
            this.lbTitulo.Text = "Mantenimiento Grupos";
            // 
            // DetCatTempABC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(442, 295);
            this.Controls.Add(this.lbTitulo);
            this.Controls.Add(this.panel01);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DetCatTempABC";
            this.Text = "DetCatTempABC";
            this.Load += new System.EventHandler(this.DetCatTempABC_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.DetCatTempABC_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.DetCatTempABC_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.DetCatTempABC_MouseUp);
            this.panel01.ResumeLayout(false);
            this.panel01.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel01;
        private System.Windows.Forms.Label lbEstatus;
        private System.Windows.Forms.Label lbSecuencia;
        private System.Windows.Forms.Label lbNoTabla;
        private System.Windows.Forms.Label lbMarca;
        private System.Windows.Forms.Button btElimiar;
        private System.Windows.Forms.Button btCambio;
        private System.Windows.Forms.Button btAlta;
        private System.Windows.Forms.Button btCancelar;
        private System.Windows.Forms.Label lbHora;
        private System.Windows.Forms.Label lbFecha;
        private System.Windows.Forms.Label lbUsuario;
        private System.Windows.Forms.TextBox tbHoraCambio;
        private System.Windows.Forms.TextBox tbFechaCambio;
        private System.Windows.Forms.TextBox tbHoraAlta;
        private System.Windows.Forms.TextBox tbFechaAlta;
        private System.Windows.Forms.TextBox tbUserCambio;
        private System.Windows.Forms.TextBox tbUserAlta;
        private System.Windows.Forms.TextBox tbSts;
        private System.Windows.Forms.TextBox tbDescripcion;
        private System.Windows.Forms.TextBox tbTemporada;
        private System.Windows.Forms.TextBox tbMarca;
        private System.Windows.Forms.Label lbTitulo;
        private System.Windows.Forms.Label lbAyudaSts;
        private System.Windows.Forms.Label lbAyudaSecuencia;
        private System.Windows.Forms.Label lbAyudaTabla;
        private System.Windows.Forms.Label lbAyudaMarca;
        private System.Windows.Forms.Label lbMsjSts;
        private System.Windows.Forms.Label lbMsjDescripcion;
        private System.Windows.Forms.Label lbMsjTemporada;
        private System.Windows.Forms.Label lbMsjMarca;
    }
}