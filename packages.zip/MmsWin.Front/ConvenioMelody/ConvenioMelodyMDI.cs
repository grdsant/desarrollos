﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MmsWin.Front.Properties;
using MmsWin.Front.Convenio;

namespace MmsWin.Front.ConvenioMelody
{
    public partial class ConvenioMelodyMDI : Form, IForm
    {
     int nr;
        string ParUser;
        String marca;

        #region [ IForm Members y variables de formatos de excepción ]

        //OCG: Formatos
        public Entidades.Reprogramaciones eReprogramaciones = new Entidades.Reprogramaciones();

        public bool RecibeEntidades(Entidades.Reprogramaciones EntidadReprogramacion)
        {
            eReprogramaciones = EntidadReprogramacion;
            return true;
        }

        #endregion

        private int childFormNumber = 0;

        public ConvenioMelodyMDI()
        {
            InitializeComponent();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Archivos de texto (*.txt)|*.txt|Todos los archivos (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Archivos de texto (*.txt)|*.txt|Todos los archivos (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ToolBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toolStrip.Visible = toolBarToolStripMenuItem.Checked;
        }

        private void StatusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            statusStrip.Visible = statusBarToolStripMenuItem.Checked;
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void tsbCorreo_Click(object sender, EventArgs e)
        {
            //MmsWin.Front.ConvenioMelody.ConvenioMelodyGrid i = new MmsWin.Front.ConvenioMelody.ConvenioMelodyGrid();
            //i.Show();
            //i.MdiParent = this;
            //i.Show();
        }

        private void stbAltas_Click(object sender, EventArgs e)
        {
            //MmsWin.Front.ConvenioMelody.ConvenioMelodyABC i = new MmsWin.Front.ConvenioMelody.ConvenioMelodyABC();
            //i.Show();
            //i.MdiParent = this;
            //i.Show();
        }

        private void printPreviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MmsWin.Front.ConvenioMelody.CalificacionGrid i = new MmsWin.Front.ConvenioMelody.CalificacionGrid();
            i.MdiParent = this;
            i.Show();
        }

        private void stbMaximizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void ConvenioMelodyMDI_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
            {
                ConvenioMelodyMDI.ActiveForm.Close();
            }
        }

        private void ConsultaCalificacionesTSB_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "CalificacionGrid").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        //CalificacionGrid Calificacion = (CalificacionGrid)this.ActiveMdiChild;
                        //i.WindowState = FormWindowState.Maximized;
                        //this.FormBorderStyle = FormBorderStyle.FixedToolWindow;
                        //this.TopLevel = false;
                        //Calificacion.Show();
                        MessageBox.Show("Las ventana de Calificaciones esta abierta...");

                        //this.WindowState = FormWindowState.Maximized;

                        //CalificacionGrid i = new CalificacionGrid();
                        //i.TopMost = true;
                        //i.Show();
                        //i.MdiParent = this;
                        //this.TopLevel = true;
                        //this.TopMost = true;
                        //this.Focus();
                        //this.TopMost = true;                     
                        //this.Show(this);
                        //i.TopMost = true;
                        //i.BringToFront();
                        //var form = new CalificacionGrid();
                        //form.TopLevel = false;
                        //form.Parent = myHostPanel;
                        //form.Show();
                        //CalificacionGrid cf = new CalificacionGrid();
                        //this.MdiParent = this;
                        ////cf.Show();
                        //this.Focus();
                        //Rectangle tabControlRectangle = new Rectangle(tabControl1.Location, tabControl1.Size);
                        //Rectangle childFormRectangle = new Rectangle(frm.Location, frm.Size);
                        //if (tabControlRectangle.IntersectsWith(childFormRectangle))
                        //{
                        //    tabControl1.Visible = false;
                        //}
                        //else
                        //{
                        //    tabControl1.Visible = true;
                        //}
                        //i.WindowState = FormWindowState.Normal;
                        //i.BringToFront();
                        //this.TopLevel = true;
                        //i.Focus();
                        //i.TopMost = true;
                        //i.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
                        //i.ShowInTaskbar = false;
                        //i.TopMost = true;
                        //i.Focus();
                        //i.BringToFront();
                        //this.TopMost = false;
                        //i.Show(this);
                        //i.Activate();
                        //i.BringToFront();
                        //i.Focus();
                        //i.TopMost = true;
                        //CheckMdiChildren(i);
                        //foreach (Form child in iMdiParent)
                        //{
                        //    if (child.Name == "CalificacionGrid")
                        //    {
                        //        child.BringToFront(); //to show only one form with specific name
                        //        return;
                        //    }
                        //}
                        //this.Select();
                        //CalificacionGrid Accounts = Application.OpenForms["CalificacionGrid "] as CalificacionGrid;
                        CalificacionGrid i = new CalificacionGrid();
                        i.TopMost = true;
                    }
                    else
                    {
                        CalificacionGrid i = new CalificacionGrid();
                        i.MdiParent = this;
                        i.Opener = this;
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void CalendarioDeProgTSB_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "CalendarioProgramacionGrid").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana del Calendario esta abierta...");
                    }
                    else
                    {
                        CalendarioProgramacionGrid i = new CalendarioProgramacionGrid();
                        i.MdiParent = this;
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void TemporadasTSB_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "CatalogoTemporadas").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana de catalogo de temporadas ya esta abierta...");
                    }
                    else
                    {
                        CatalogoTemporadas i = new CatalogoTemporadas();
                        //i.MdiParent = this;
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void ConvenioMelodyMDI_Load(object sender, EventArgs e)
        {
            // Seguridad... x las Columnas nuevas
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("CalificaMelody", "CalificaMelodyMDI", ParUser);
        }
        // Seguridad                                                                                
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab    = row["SEGHAC"].ToString();
                string ValVis    = row["SEGVIC"].ToString();
                string tipo      = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica Seguridad                                                                         
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }
            //--------------------------------------
            // Aplica a Columnas
            if (tipo == "Columna")
            {
                //try
                //{
                //    bool valorHab = false;
                //    if (ValHab == "0") { valorHab = true; }
                //    dgvBonificaciones.Columns[Controles].ReadOnly = valorHab;
                //}
                //catch { }

                //try
                //{
                //    bool valorVis = false;
                //    if (ValVis == "1") { valorVis = true; }
                //    dgvBonificaciones.Columns[Controles].Visible = valorVis;
                //}
                //catch { }
            }
            //--------------------------------------
            // Aplica a opciones de Menu
            if (tipo == "Menu")
            {
                //    try
                //    {
                //        bool valorHab = false;
                //        if (ValHab == "1") { valorHab = true; }
                //        cmMenu.Items[Controles].Enabled = valorHab;
                //    }
                //    catch { }

                //    try
                //    {
                //        bool valorVis = false;
                //        if (ValVis == "1") { valorVis = true; }
                //        cmMenu.Items[Controles].Visible = valorVis;
                //    }
                //    catch { }
            }
            //--------------------------------------
        }

        private void ConvenioMelodyMDI_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Carga Seguridad  
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("CalificaMelody", "CalificaMelodyMDI", ParUser);
            }
        }

        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            // Columnas                                                                  
            //
            //string NomCol;
            //Int32 NoCol = dgvBonificaciones.ColumnCount;
            //for (int i = 0; i < NoCol; i++)
            //{
            //    NomCol = dgvBonificaciones.Columns[i].Name.ToString();

            //    DataRow workRow = dtControles.NewRow();
            //    workRow["Aplicacion"] = Aplicacion;
            //    workRow["Modulo"] = Modulo;
            //    workRow["Control"] = NomCol;
            //    workRow["Tipo"] = "Columna";
            //    workRow["Usuario"] = Usuario;
            //    dtControles.Rows.Add(workRow);
            //}
            // Menu                                                                      
            //
            //string NomMenu;
            //Int32 NoItems = cmMenu.Items.Count;
            //for (int i = 0; i < NoItems; i++)
            //{
            //    NomMenu = cmMenu.Items[i].Name.ToString();

            //    DataRow workRow = dtControles.NewRow();
            //    workRow["Aplicacion"] = Aplicacion;
            //    workRow["Modulo"] = Modulo;
            //    workRow["Control"] = NomMenu;
            //    workRow["Tipo"] = "Menu";
            //    workRow["Usuario"] = Usuario;
            //    dtControles.Rows.Add(workRow);
            //}
            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void toolStripDropDownButton1_Click(object sender, EventArgs e)
        {

        }

        //Evento click para todos los ToolStripMenuItem de las reprogramaciones
     	 
        private void TSMI_Click(object sender, EventArgs e)
        {
            if (sender == this.tsmiReprogramaciones)
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "Preautorizaciones").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana ya se encuentra abierta...");
                    }
                    else
                    {
                        Preautorizaciones i = new Preautorizaciones();
                        i.Marca = (Comun.Engine.Marca)Convert.ToInt32(eReprogramaciones.MarcaID);
                        i.Comprador = Convert.ToInt32(eReprogramaciones.CompradorID);
                        i.ShowDialog(this);
                    }
                }
            }

            if (sender == this.tsmiCambioCalificacion)
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "AutorizaDevolucion").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana ya se encuentra abierta...");
                    }
                    else
                    {
                        AutorizaDevolucion i = new AutorizaDevolucion();
                        i.Marca = eReprogramaciones.MarcaID;
                        i.Comprador = Convert.ToInt32(eReprogramaciones.CompradorID);
                        i.ShowDialog(this);
                    }
                }
            }
        }				
		
        private void ConvenioMelodyMDI_Enter(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }

        private void RebajaDiferenciadaTSB_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "RebajaDiferenciada").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana de Calificaciones esta abierta...");
                    }
                    else
                    {
                         RebajaDiferenciada i = new RebajaDiferenciada();
                         i.MdiParent = this;
                         //i.Opener = this;
                         i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void DocDiferenciadosTSB_Click(object sender, EventArgs e)
        {
            //ToolStripDropDownMenu Vtanas = new ToolStripDropDownMenu();
            

            //int nVntana = Vtanas.Items.Count();
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "DocDiferenciados").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana de Calificaciones esta abierta...");
                    }
                    else
                    {
                        DocDiferenciados i = new DocDiferenciados();
                        i.MdiParent = this;
                        //i.Opener = this;
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbReprogramaciones_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Reprogramacion").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana Reprogramacion ya esta abierta...");
                    }
                    else
                    {
                        Reprogramacion i = new Reprogramacion();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void tsbTablaCalificacion_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "TablasPorc").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana de tablas de Despalzamiento esta abierta...");
                    }
                    else
                    {
                        TablasPorc i = new TablasPorc();
                        //i.MdiParent = this;
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbAdministracion_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Administracion").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana Administracion ya esta abierta...");
                    }
                    else
                    {
                        Administracion i = new Administracion();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

    }
}
