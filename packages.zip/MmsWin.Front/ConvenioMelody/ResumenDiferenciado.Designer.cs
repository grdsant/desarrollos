﻿namespace MmsWin.Front.ConvenioMelody
{
    partial class ResumenDiferenciado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ResumenDiferenciado));
            this.pnlResumen = new System.Windows.Forms.Panel();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.tbTiendas = new System.Windows.Forms.TextBox();
            this.lbTiendas = new System.Windows.Forms.Label();
            this.lbAplicado = new System.Windows.Forms.Label();
            this.lbSugerido = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.tbEstilos = new System.Windows.Forms.TextBox();
            this.lbEstilos = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.lbOHactual = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.tbPrecios = new System.Windows.Forms.TextBox();
            this.tbCostos = new System.Windows.Forms.TextBox();
            this.tbPiezas = new System.Windows.Forms.TextBox();
            this.lbPrecio = new System.Windows.Forms.Label();
            this.lbCosto = new System.Windows.Forms.Label();
            this.lbPiezas = new System.Windows.Forms.Label();
            this.lbSinRebajar = new System.Windows.Forms.Label();
            this.lbRebajados = new System.Windows.Forms.Label();
            this.lbCalificados = new System.Windows.Forms.Label();
            this.pbSalir = new System.Windows.Forms.PictureBox();
            this.pnlResumen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlResumen
            // 
            this.pnlResumen.AutoSize = true;
            this.pnlResumen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pnlResumen.Controls.Add(this.textBox45);
            this.pnlResumen.Controls.Add(this.textBox44);
            this.pnlResumen.Controls.Add(this.textBox43);
            this.pnlResumen.Controls.Add(this.textBox42);
            this.pnlResumen.Controls.Add(this.textBox41);
            this.pnlResumen.Controls.Add(this.label5);
            this.pnlResumen.Controls.Add(this.textBox22);
            this.pnlResumen.Controls.Add(this.textBox13);
            this.pnlResumen.Controls.Add(this.textBox14);
            this.pnlResumen.Controls.Add(this.textBox15);
            this.pnlResumen.Controls.Add(this.tbTiendas);
            this.pnlResumen.Controls.Add(this.lbTiendas);
            this.pnlResumen.Controls.Add(this.lbAplicado);
            this.pnlResumen.Controls.Add(this.lbSugerido);
            this.pnlResumen.Controls.Add(this.textBox21);
            this.pnlResumen.Controls.Add(this.textBox23);
            this.pnlResumen.Controls.Add(this.textBox24);
            this.pnlResumen.Controls.Add(this.textBox25);
            this.pnlResumen.Controls.Add(this.label1);
            this.pnlResumen.Controls.Add(this.textBox17);
            this.pnlResumen.Controls.Add(this.textBox18);
            this.pnlResumen.Controls.Add(this.textBox19);
            this.pnlResumen.Controls.Add(this.tbEstilos);
            this.pnlResumen.Controls.Add(this.lbEstilos);
            this.pnlResumen.Controls.Add(this.textBox10);
            this.pnlResumen.Controls.Add(this.textBox11);
            this.pnlResumen.Controls.Add(this.textBox12);
            this.pnlResumen.Controls.Add(this.lbOHactual);
            this.pnlResumen.Controls.Add(this.panel1);
            this.pnlResumen.Controls.Add(this.textBox9);
            this.pnlResumen.Controls.Add(this.textBox8);
            this.pnlResumen.Controls.Add(this.textBox7);
            this.pnlResumen.Controls.Add(this.textBox6);
            this.pnlResumen.Controls.Add(this.textBox5);
            this.pnlResumen.Controls.Add(this.textBox4);
            this.pnlResumen.Controls.Add(this.tbPrecios);
            this.pnlResumen.Controls.Add(this.tbCostos);
            this.pnlResumen.Controls.Add(this.tbPiezas);
            this.pnlResumen.Controls.Add(this.lbPrecio);
            this.pnlResumen.Controls.Add(this.lbCosto);
            this.pnlResumen.Controls.Add(this.lbPiezas);
            this.pnlResumen.Controls.Add(this.lbSinRebajar);
            this.pnlResumen.Controls.Add(this.lbRebajados);
            this.pnlResumen.Controls.Add(this.lbCalificados);
            this.pnlResumen.Location = new System.Drawing.Point(2, 54);
            this.pnlResumen.Name = "pnlResumen";
            this.pnlResumen.Size = new System.Drawing.Size(1013, 386);
            this.pnlResumen.TabIndex = 0;
            this.pnlResumen.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlResumen_Paint);
            this.pnlResumen.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pnlResumen_MouseDown);
            this.pnlResumen.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pnlResumen_MouseMove);
            this.pnlResumen.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pnlResumen_MouseUp);
            // 
            // textBox45
            // 
            this.textBox45.Enabled = false;
            this.textBox45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox45.Location = new System.Drawing.Point(886, 232);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(61, 22);
            this.textBox45.TabIndex = 74;
            this.textBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox44
            // 
            this.textBox44.Enabled = false;
            this.textBox44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox44.Location = new System.Drawing.Point(886, 200);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(61, 22);
            this.textBox44.TabIndex = 73;
            this.textBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox43
            // 
            this.textBox43.Enabled = false;
            this.textBox43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox43.Location = new System.Drawing.Point(886, 167);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(61, 22);
            this.textBox43.TabIndex = 72;
            this.textBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox42
            // 
            this.textBox42.Enabled = false;
            this.textBox42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox42.Location = new System.Drawing.Point(886, 132);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(61, 22);
            this.textBox42.TabIndex = 71;
            this.textBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox41
            // 
            this.textBox41.Enabled = false;
            this.textBox41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox41.Location = new System.Drawing.Point(886, 100);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(61, 22);
            this.textBox41.TabIndex = 70;
            this.textBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gray;
            this.label5.Location = new System.Drawing.Point(902, 61);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 24);
            this.label5.TabIndex = 69;
            this.label5.Text = "%";
            // 
            // textBox22
            // 
            this.textBox22.Enabled = false;
            this.textBox22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox22.Location = new System.Drawing.Point(304, 132);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(115, 22);
            this.textBox22.TabIndex = 68;
            this.textBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox13
            // 
            this.textBox13.Enabled = false;
            this.textBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.Location = new System.Drawing.Point(708, 132);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(161, 22);
            this.textBox13.TabIndex = 67;
            this.textBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox14
            // 
            this.textBox14.Enabled = false;
            this.textBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(571, 132);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(115, 22);
            this.textBox14.TabIndex = 66;
            this.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox15
            // 
            this.textBox15.Enabled = false;
            this.textBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(436, 132);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(115, 22);
            this.textBox15.TabIndex = 65;
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbTiendas
            // 
            this.tbTiendas.Enabled = false;
            this.tbTiendas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTiendas.Location = new System.Drawing.Point(174, 132);
            this.tbTiendas.Name = "tbTiendas";
            this.tbTiendas.Size = new System.Drawing.Size(115, 22);
            this.tbTiendas.TabIndex = 64;
            this.tbTiendas.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbTiendas
            // 
            this.lbTiendas.AutoSize = true;
            this.lbTiendas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTiendas.ForeColor = System.Drawing.Color.Gray;
            this.lbTiendas.Location = new System.Drawing.Point(93, 138);
            this.lbTiendas.Name = "lbTiendas";
            this.lbTiendas.Size = new System.Drawing.Size(72, 20);
            this.lbTiendas.TabIndex = 63;
            this.lbTiendas.Text = "Tiendas";
            // 
            // lbAplicado
            // 
            this.lbAplicado.AutoSize = true;
            this.lbAplicado.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAplicado.ForeColor = System.Drawing.Color.Gray;
            this.lbAplicado.Location = new System.Drawing.Point(433, 34);
            this.lbAplicado.Name = "lbAplicado";
            this.lbAplicado.Size = new System.Drawing.Size(92, 24);
            this.lbAplicado.TabIndex = 38;
            this.lbAplicado.Text = "Aplicado";
            // 
            // lbSugerido
            // 
            this.lbSugerido.AutoSize = true;
            this.lbSugerido.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSugerido.ForeColor = System.Drawing.Color.Gray;
            this.lbSugerido.Location = new System.Drawing.Point(301, 34);
            this.lbSugerido.Name = "lbSugerido";
            this.lbSugerido.Size = new System.Drawing.Size(95, 24);
            this.lbSugerido.TabIndex = 37;
            this.lbSugerido.Text = "Sugerido";
            // 
            // textBox21
            // 
            this.textBox21.Enabled = false;
            this.textBox21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox21.Location = new System.Drawing.Point(304, 100);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(115, 22);
            this.textBox21.TabIndex = 36;
            this.textBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox23
            // 
            this.textBox23.Enabled = false;
            this.textBox23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox23.Location = new System.Drawing.Point(304, 233);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(115, 22);
            this.textBox23.TabIndex = 34;
            this.textBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox24
            // 
            this.textBox24.Enabled = false;
            this.textBox24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox24.Location = new System.Drawing.Point(304, 200);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(115, 22);
            this.textBox24.TabIndex = 33;
            this.textBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox25
            // 
            this.textBox25.Enabled = false;
            this.textBox25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox25.Location = new System.Drawing.Point(304, 167);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(115, 22);
            this.textBox25.TabIndex = 32;
            this.textBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(301, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 24);
            this.label1.TabIndex = 31;
            this.label1.Text = "Rebajados";
            // 
            // textBox17
            // 
            this.textBox17.Enabled = false;
            this.textBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox17.Location = new System.Drawing.Point(708, 100);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(161, 22);
            this.textBox17.TabIndex = 30;
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox18
            // 
            this.textBox18.Enabled = false;
            this.textBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(571, 100);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(115, 22);
            this.textBox18.TabIndex = 29;
            this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox19
            // 
            this.textBox19.Enabled = false;
            this.textBox19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox19.Location = new System.Drawing.Point(436, 100);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(115, 22);
            this.textBox19.TabIndex = 28;
            this.textBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbEstilos
            // 
            this.tbEstilos.Enabled = false;
            this.tbEstilos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbEstilos.Location = new System.Drawing.Point(174, 100);
            this.tbEstilos.Name = "tbEstilos";
            this.tbEstilos.Size = new System.Drawing.Size(115, 22);
            this.tbEstilos.TabIndex = 27;
            this.tbEstilos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbEstilos
            // 
            this.lbEstilos.AutoSize = true;
            this.lbEstilos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEstilos.ForeColor = System.Drawing.Color.Gray;
            this.lbEstilos.Location = new System.Drawing.Point(93, 106);
            this.lbEstilos.Name = "lbEstilos";
            this.lbEstilos.Size = new System.Drawing.Size(63, 20);
            this.lbEstilos.TabIndex = 26;
            this.lbEstilos.Text = "Estilos";
            // 
            // textBox10
            // 
            this.textBox10.Enabled = false;
            this.textBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(708, 233);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(161, 22);
            this.textBox10.TabIndex = 20;
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox11
            // 
            this.textBox11.Enabled = false;
            this.textBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(708, 200);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(161, 22);
            this.textBox11.TabIndex = 19;
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox12
            // 
            this.textBox12.Enabled = false;
            this.textBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(708, 167);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(161, 22);
            this.textBox12.TabIndex = 18;
            this.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbOHactual
            // 
            this.lbOHactual.AutoSize = true;
            this.lbOHactual.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOHactual.ForeColor = System.Drawing.Color.Gray;
            this.lbOHactual.Location = new System.Drawing.Point(704, 58);
            this.lbOHactual.Name = "lbOHactual";
            this.lbOHactual.Size = new System.Drawing.Size(165, 24);
            this.lbOHactual.TabIndex = 17;
            this.lbOHactual.Text = "Inventario Actual";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Location = new System.Drawing.Point(1, -55);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1009, 52);
            this.panel1.TabIndex = 16;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // textBox9
            // 
            this.textBox9.Enabled = false;
            this.textBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(571, 233);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(115, 22);
            this.textBox9.TabIndex = 14;
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox8
            // 
            this.textBox8.Enabled = false;
            this.textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(571, 200);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(115, 22);
            this.textBox8.TabIndex = 13;
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox7
            // 
            this.textBox7.Enabled = false;
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(571, 167);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(115, 22);
            this.textBox7.TabIndex = 12;
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox6
            // 
            this.textBox6.Enabled = false;
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(436, 233);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(115, 22);
            this.textBox6.TabIndex = 11;
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox5
            // 
            this.textBox5.Enabled = false;
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(436, 200);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(115, 22);
            this.textBox5.TabIndex = 10;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox4
            // 
            this.textBox4.Enabled = false;
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(436, 167);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(115, 22);
            this.textBox4.TabIndex = 9;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbPrecios
            // 
            this.tbPrecios.Enabled = false;
            this.tbPrecios.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPrecios.Location = new System.Drawing.Point(174, 233);
            this.tbPrecios.Name = "tbPrecios";
            this.tbPrecios.Size = new System.Drawing.Size(115, 22);
            this.tbPrecios.TabIndex = 8;
            this.tbPrecios.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbCostos
            // 
            this.tbCostos.Enabled = false;
            this.tbCostos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCostos.Location = new System.Drawing.Point(174, 200);
            this.tbCostos.Name = "tbCostos";
            this.tbCostos.Size = new System.Drawing.Size(115, 22);
            this.tbCostos.TabIndex = 7;
            this.tbCostos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tbPiezas
            // 
            this.tbPiezas.Enabled = false;
            this.tbPiezas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPiezas.Location = new System.Drawing.Point(174, 167);
            this.tbPiezas.Name = "tbPiezas";
            this.tbPiezas.Size = new System.Drawing.Size(115, 22);
            this.tbPiezas.TabIndex = 6;
            this.tbPiezas.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lbPrecio
            // 
            this.lbPrecio.AutoSize = true;
            this.lbPrecio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPrecio.ForeColor = System.Drawing.Color.Gray;
            this.lbPrecio.Location = new System.Drawing.Point(93, 239);
            this.lbPrecio.Name = "lbPrecio";
            this.lbPrecio.Size = new System.Drawing.Size(59, 20);
            this.lbPrecio.TabIndex = 5;
            this.lbPrecio.Text = "Precio";
            // 
            // lbCosto
            // 
            this.lbCosto.AutoSize = true;
            this.lbCosto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCosto.ForeColor = System.Drawing.Color.Gray;
            this.lbCosto.Location = new System.Drawing.Point(93, 206);
            this.lbCosto.Name = "lbCosto";
            this.lbCosto.Size = new System.Drawing.Size(56, 20);
            this.lbCosto.TabIndex = 4;
            this.lbCosto.Text = "Costo";
            // 
            // lbPiezas
            // 
            this.lbPiezas.AutoSize = true;
            this.lbPiezas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPiezas.ForeColor = System.Drawing.Color.Gray;
            this.lbPiezas.Location = new System.Drawing.Point(93, 173);
            this.lbPiezas.Name = "lbPiezas";
            this.lbPiezas.Size = new System.Drawing.Size(62, 20);
            this.lbPiezas.TabIndex = 3;
            this.lbPiezas.Text = "Piezas";
            // 
            // lbSinRebajar
            // 
            this.lbSinRebajar.AutoSize = true;
            this.lbSinRebajar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSinRebajar.ForeColor = System.Drawing.Color.Gray;
            this.lbSinRebajar.Location = new System.Drawing.Point(567, 58);
            this.lbSinRebajar.Name = "lbSinRebajar";
            this.lbSinRebajar.Size = new System.Drawing.Size(118, 24);
            this.lbSinRebajar.TabIndex = 2;
            this.lbSinRebajar.Text = "Sin Rebajar";
            // 
            // lbRebajados
            // 
            this.lbRebajados.AutoSize = true;
            this.lbRebajados.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRebajados.ForeColor = System.Drawing.Color.Gray;
            this.lbRebajados.Location = new System.Drawing.Point(433, 58);
            this.lbRebajados.Name = "lbRebajados";
            this.lbRebajados.Size = new System.Drawing.Size(109, 24);
            this.lbRebajados.TabIndex = 1;
            this.lbRebajados.Text = "Rebajados";
            // 
            // lbCalificados
            // 
            this.lbCalificados.AutoSize = true;
            this.lbCalificados.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCalificados.ForeColor = System.Drawing.Color.Gray;
            this.lbCalificados.Location = new System.Drawing.Point(171, 58);
            this.lbCalificados.Name = "lbCalificados";
            this.lbCalificados.Size = new System.Drawing.Size(111, 24);
            this.lbCalificados.TabIndex = 0;
            this.lbCalificados.Text = "Calificados";
            // 
            // pbSalir
            // 
            this.pbSalir.BackColor = System.Drawing.Color.Gray;
            this.pbSalir.Image = ((System.Drawing.Image)(resources.GetObject("pbSalir.Image")));
            this.pbSalir.Location = new System.Drawing.Point(977, 12);
            this.pbSalir.Name = "pbSalir";
            this.pbSalir.Size = new System.Drawing.Size(28, 25);
            this.pbSalir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSalir.TabIndex = 69;
            this.pbSalir.TabStop = false;
            this.pbSalir.Click += new System.EventHandler(this.pbSalir_Click_1);
            // 
            // ResumenDiferenciado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1017, 452);
            this.Controls.Add(this.pbSalir);
            this.Controls.Add(this.pnlResumen);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ResumenDiferenciado";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Resumen Diferenciado";
            this.Load += new System.EventHandler(this.ResumenDiferenciado_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ResumenDiferenciado_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.ResumenDiferenciado_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.ResumenDiferenciado_MouseUp);
            this.pnlResumen.ResumeLayout(false);
            this.pnlResumen.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pnlResumen;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox tbPrecios;
        private System.Windows.Forms.TextBox tbCostos;
        private System.Windows.Forms.TextBox tbPiezas;
        private System.Windows.Forms.Label lbPrecio;
        private System.Windows.Forms.Label lbCosto;
        private System.Windows.Forms.Label lbPiezas;
        private System.Windows.Forms.Label lbSinRebajar;
        private System.Windows.Forms.Label lbRebajados;
        private System.Windows.Forms.Label lbCalificados;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label lbOHactual;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox tbEstilos;
        private System.Windows.Forms.Label lbEstilos;
        private System.Windows.Forms.Label lbAplicado;
        private System.Windows.Forms.Label lbSugerido;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox tbTiendas;
        private System.Windows.Forms.Label lbTiendas;
        private System.Windows.Forms.PictureBox pbSalir;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.Label label5;
    }
}