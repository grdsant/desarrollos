﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Iseries.Reprogramaciones
{
    public partial class Reprograma : Form
    {
        public Reprograma()
        {
            InitializeComponent();
        }

        private void Reprograma_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dsReprograma.SAT177F14S' Puede moverla o quitarla según sea necesario.
            this.SAT177F14STableAdapter.Fill(this.dsReprograma.SAT177F14S);

            this.reportViewer1.RefreshReport();
        }
    }
}
