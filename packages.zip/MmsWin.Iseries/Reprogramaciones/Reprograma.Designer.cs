﻿namespace MmsWin.Iseries.Reprogramaciones
{
    partial class Reprograma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.dsReprograma = new MmsWin.Iseries.Reprogramaciones.dsReprograma();
            this.SAT177F14SBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SAT177F14STableAdapter = new MmsWin.Iseries.Reprogramaciones.dsReprogramaTableAdapters.SAT177F14STableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dsReprograma)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SAT177F14SBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.SAT177F14SBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "MmsWin.Iseries.Reprogramaciones.InfReprograma.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(1037, 437);
            this.reportViewer1.TabIndex = 0;
            // 
            // dsReprograma
            // 
            this.dsReprograma.DataSetName = "dsReprograma";
            this.dsReprograma.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // SAT177F14SBindingSource
            // 
            this.SAT177F14SBindingSource.DataMember = "SAT177F14S";
            this.SAT177F14SBindingSource.DataSource = this.dsReprograma;
            // 
            // SAT177F14STableAdapter
            // 
            this.SAT177F14STableAdapter.ClearBeforeFill = true;
            // 
            // Reprograma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1037, 437);
            this.Controls.Add(this.reportViewer1);
            this.Name = "Reprograma";
            this.Text = "Reprograma";
            this.Load += new System.EventHandler(this.Reprograma_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dsReprograma)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SAT177F14SBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource SAT177F14SBindingSource;
        private dsReprograma dsReprograma;
        private dsReprogramaTableAdapters.SAT177F14STableAdapter SAT177F14STableAdapter;
    }
}