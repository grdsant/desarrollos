﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
//using cwbx;

namespace MmsWin.Iseries.Downs
{
    //public class Downs
    //{
    //    public static void Call()
    //    {       
    //        string AS400Name = "192.168.2.83";
    //        string AS400User = "PGMGSR";
    //        string AS400Password = "ENERO3G0";
    //        string AS400Lib = "MMSATPGM";
    //        string AS400Pgm = "SAT103C1";

    //        cwbx.AS400System AS400 = new cwbx.AS400System(); //Direccion
    //        cwbx.Program Program = new cwbx.Program();       //Datos de Conexion y ejecucion

    //        AS400.Define(AS400Name);                         // Direccion
    //        Program.system = AS400;
    //        Program.system.UserID = AS400User;           // Usuario 
    //        Program.system.Password = AS400Password;     // Password
    //        Program.LibraryName = AS400Lib;              // Libreria
    //        Program.ProgramName = AS400Pgm;              // Programa

    //        AS400.Signon();                              // Inicia Sesion
    //        AS400.Connect(cwbcoServiceEnum.cwbcoServiceRemoteCmd);
            
    //        if (AS400.IsConnected(cwbcoServiceEnum.cwbcoServiceAll) == 0)
    //        {
    //            Console.Write("Not Connected");
    //        }
    //        else
    //        {
    //            ProgramParameters parms = new ProgramParameters();
    //            parms.Append("MsgToAS400", cwbrcParameterTypeEnum.cwbrcInput, 30);
    //            parms.Append("ReplyFromAS400", cwbrcParameterTypeEnum.cwbrcOutput, 30);

    //            StringConverter strcon = new StringConverter();
    //            strcon.Length = 30;
    //            parms["MsgToAS400"].Value = strcon.ToBytes("This is from a dot net pgm,hi");
    //            try
    //            {
    //                Program.Call(parms);

    //                String reply = strcon.FromBytes(parms["ReplyFromAS400"].Value);
    //                Console.WriteLine(reply);
    //                Console.ReadLine();
    //            }
    //            catch { }

    //            {
    //                foreach (Error error in AS400.Errors)
    //                {
    //                    Console.WriteLine(error.ToString());
    //                }
    //          //      throw;
    //            }
    //        }
    //    }
    //}
}
