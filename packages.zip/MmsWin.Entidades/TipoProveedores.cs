﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MmsWin.Entidades
{
    public class TipoProveedores
    {
        public int ProveedorID { get; set; }
        public string Proveedor { get; set; }
        public string TipoID { get; set; }
        public string Tipo { get; set; }     
    }
}
