﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Entidades
{
    public class BonificacionParcial
    {
        /// <summary> 
        /// Número de proveedor 
        /// </summary>  
        public int POVNUM { get; set; } // Número de proveedor
        
        /// <summary> 
        /// Style Number
        /// </summary>  
        public string SSTYLQ { get; set; } // Style Number
        
        /// <summary> 
        /// Orden de compra
        /// </summary>  
        public int PONUMB { get; set; } // Orden de compra
        
        /// <summary> 
        /// Número de marca
        /// </summary>  
        public int NUMARC { get; set; } // Número de marca
        
        /// <summary> 
        /// Número comprador
        /// </summary>  
        public string BYRNUM { get; set; } // Número comprador
        
        /// <summary> 
        /// Fecha de recibo
        /// </summary>  
        public int FECREC { get; set; } // Fecha de recibo
        
        /// <summary> 
        /// Piezas recibidas
        /// </summary>  
        public int PIEREC { get; set; } // Piezas recibidas
        
        /// <summary> 
        /// Fecha de recibo
        /// </summary>  
        public int FECREV { get; set; } // Fecha de recibo
        
        /// <summary> 
        /// Calificación
        /// </summary>  
        public string CALIFI { get; set; } // Calificación
        
        /// <summary> 
        /// Calificación original
        /// </summary>  
        public string CALORI { get; set; } // Calificación original
        
        /// <summary> 
        /// On hand
        /// </summary>  
        public decimal ONHAND { get; set; } // On hand

        /// <summary> 
        /// On order
        /// </summary>  
        public decimal ONORDR { get; set; } // On order
        
        /// <summary> 
        /// Costo total
        /// </summary>  
        public decimal CSTTOT { get; set; } // Costo total
        
        /// <summary>
        /// Bodega
        /// </summary>  
        public decimal BODEGA { get; set; } // Bodega

        /// <summary> 
        /// Costo actual
        /// </summary>  
        public decimal CSTACT { get; set; } // Costo actual

        /// <summary> 
        /// Precio actual
        /// </summary>  
        public decimal PREACT { get; set; } // Precio actual

        /// <summary> 
        /// Season Code
        /// </summary>  
        public string CODTEM { get; set; } // Season Code

        /// <summary> 
        /// Status autorización
        /// </summary>  
        public string AUSTAT { get; set; } // Status autorización

        /// <summary> 
        /// Usuario registro
        /// </summary> 
        public string SUSREG { get; set; } // Usuario registro

        /// <summary> 
        /// Fecha de registro
        /// </summary>  
        public int SFEREG { get; set; } // Fecha de registro

        /// <summary> 
        /// Hora de registro
        /// </summary>  
        public int SHRREG { get; set; } // Hora de registro
    }
}


