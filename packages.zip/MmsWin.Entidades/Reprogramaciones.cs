﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Entidades
{
    /// <summary>
    /// Entidad para el traspaso de datos de las Reprogramaciones
    /// </summary>
    public class Reprogramaciones
    {
        #region [ Propiedades que reciben los RPG ]

        public string ProveedorID { get; set; }
        public string Proveedor { get; set; }
        public string EstiloID { get; set; }
        public string Estilo { get; set; }
        public string FechaRevision { get; set; }
        public string FechaReprogracion { get; set; }
        public string CompradorID { get; set; }
        public string Comprador { get; set; }
        public string Observaciones { get; set; }
        public string MarcaID { get; set; }
        public string FechaCreacion { get; set; }
        public string HoraCreacion { get; set; }
        public string Usuario { get; set; }
        public string MotivoReprogramacionID { get; set; }
        public string Estatus { get; set; }
        public string Folio { get; set; }

        #endregion

        #region [ Propiedades para revisión de politica ]

        public string OrdenCompra { get; set; }
        public string FechaRecibo { get; set; }
        public string strCalificacion { get; set; }
        public decimal decCalificacion { get; set; }
        public string Temporada { get; set; }
        public string TipoCalificacion { get; set; }
        public string OnHand { get; set; }
        public string CostoTotal { get; set; }
        public string CostoActual { get; set; }
        public string NoEventos { get; set; }
        public decimal MontoBonificacion { get; set; }
        public decimal PiezasBonificar { get; set; }
        public decimal CalificacionRentabilidad { get; set; }

        /// <summary>
        /// Fecha de recibo en formato entero de 6 posiciones
        /// </summary>
        public string intFechaRecibo { get; set; }

        /// <summary>
        /// Fecha de reprogramación en formato entero de 6 posiciones
        /// </summary>
        public string intFechaReprogramacion { get; set; }

        /// <summary>
        /// Fecha de reprogramación en formato entero de 6 posiciones
        /// </summary>
        public string intFechaRevision { get; set; }

        #endregion

    }
}
