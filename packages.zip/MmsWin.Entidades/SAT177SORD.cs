﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MmsWin.Entidades
{
    public class SAT177SORD
    {
        public string ORDID { get; set; }
        public int ORDPRV { get; set; }
        public string ORDDES { get; set; }
        public int ORDFCH { get; set; }
        public int ORDHOR { get; set; }
        public string ORDSTS { get; set; }
    }
}
