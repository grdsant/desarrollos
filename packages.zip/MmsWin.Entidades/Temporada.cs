﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MmsWin.Entidades
{
    public class Temporada
    {

        public string Origen { get; set; }
        public string CodTemporada { get; set; }
        public int Marca { get; set; }
        public int Id_Proveedor { get; set; }
        public string Proveedor { get; set; }
        public string Id_Estilo { get; set; }
        public string Estilo { get; set; }
        public int Id_Departamento { get; set; }
        public int Id_Subdepartamento { get; set; }
        public int Id_Clase { get; set; }
        public int Id_SubClase { get; set; }
        public DateTime FechaReciboIni { get; set; }
        public DateTime FechaReciboFin { get; set; }
        public DateTime FechaCalificacion { get; set; }
        public string Comprador { get; set; }
    }
}
