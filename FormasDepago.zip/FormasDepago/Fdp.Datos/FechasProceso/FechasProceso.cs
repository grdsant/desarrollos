﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace Fdp.Datos.FechasProceso
{
    public class FechasProceso
    {


        #region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        #endregion

        public static DataTable ObtenerDatos(string fechaInicial, string fechaFinal)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtFechasProceso = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL MMSATPGM.SAT211R10 (\n");
                sql.AppendFormat("X'0" + "{0}" + "F'" + "," + "\n", fechaInicial.PadLeft(6, '0'));
                sql.AppendFormat("X'0" + "{0}" + "F'" + "\n", fechaFinal.PadLeft(6, '0'));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();  

                sql.Clear();
                sql.Append("SELECT  * \n");

                sql.Append("FROM MMSATOBJ.SAT211CTL \n");
                sql.AppendFormat(" WHERE  CUPFCH <> 0 \n");
                if (fechaInicial != "") { sql.AppendFormat("and CUPFCH between " +  "{0}" + "\n", fechaInicial); }
                if (fechaFinal != "") { sql.AppendFormat(" and " + "{0}" + "\n", fechaFinal); }

                sql.Append(" ORDER BY CUPFCH  \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtFechasProceso = new DataTable("FechasProceso");
                dtFechasProceso.Load(db2Reader);
                db2Reader.Close();

                return dtFechasProceso;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string ProcesarFechas(string fechaInicial, string fechaFinal)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql  = new StringBuilder();
            string stRespuesta = string.Empty;
            DataTable dtRegistros = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT * FROM MMSATOBJ.SAT211CTL \n");
                sql.AppendFormat(" where ");
                sql.AppendFormat("CUPFCH = " + "{0}" + "\n", fechaInicial.PadLeft(6, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtRegistros = new DataTable("Registros");
                dtRegistros.Load(db2Reader);
                db2Reader.Close();

                foreach (DataRow row in dtRegistros.Rows)
                {
                    string Estatus = row["CUPSTS"].ToString();

                    if (Estatus != "Procesando")
                    {
                        sql.Clear();
                        sql.Append("CALL MMSATPGM.SAT211C (\n");
                        sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", fechaInicial.PadLeft(6, '0'));
                        sql.AppendFormat("'" + "{0}" + "'" + "\n", fechaFinal.PadLeft(6, '0'));
                        sql.Append(")");

                        db2Comm.CommandText = sql.ToString();
                        db2Comm.ExecuteNonQuery();
                    }
                }
                    return stRespuesta;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
