﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace FormasDepago
{
    /// <summary>
    /// Lógica de interacción para FechasProceso.xaml
    /// </summary>
    public partial class FechasProceso : Window
    {
        //int nr;

        public System.Data.DataTable dtDatos = null;

        public FechasProceso(int cont)
        {
            InitializeComponent();
            double widthPrimary = System.Windows.SystemParameters.PrimaryScreenWidth;
            double heightPrimary = System.Windows.SystemParameters.PrimaryScreenHeight;

            double widthArea = System.Windows.SystemParameters.WorkArea.Height;
            double heightArea = System.Windows.SystemParameters.WorkArea.Width;

            double widthThis = this.Width;
            double heihgtThis = this.Height;

            dgDatos.MaxWidth = widthThis - 40;
            dgDatos.MaxHeight = heihgtThis - 120;

            dgDatos.Visibility = Visibility.Hidden;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            FormasDepago.MainWindow.cont = 0;

            this.Close();
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void LbTitulo_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (WindowState == WindowState.Maximized)
            {
                WindowState = WindowState.Normal;
            }
            else
            {
                WindowState = WindowState.Maximized;
            }
        }

        private void wndFechasProcesos_Loaded(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.ProgressBar ProgressEstatus = new System.Windows.Controls.ProgressBar();
            ProgressEstatus.IsIndeterminate = true;

            BinDatos();

            ProgressEstatus.IsIndeterminate = false;

            try
            {
                RebindData();
                SetTimer();
            }
            catch 
            {
                
            }
        }

        protected void BinDatos()
        {
            try
            {
                string fechaInicial = FormasDepago.MainWindow.VarFechaInicial;
                string fechaFinal = FormasDepago.MainWindow.VarFechaFinal;

                dtDatos = Fdp.Negocio.FechasProceso.FechasProceso.GetInstance().ObtenDatos(fechaInicial, fechaFinal);
            }
            catch { }

            if (dtDatos != null)
            {
                if (dtDatos.Rows.Count > 0)
                {
                    dgDatos.Visibility = Visibility.Visible;

                    lbTitulo.Content = " Fechas de Proceso" + " / " + dtDatos.Rows.Count + " Registros";
                    dgDatos.ItemsSource = null;

                    dgDatos.ItemsSource = dtDatos.DefaultView;

                    SetFontAndcolors();
                    RowStyle();


                }
                else
                {
                    dgDatos.Visibility = Visibility.Hidden;
                }
            }
        }

        private void SetFontAndcolors()
        {
            dgDatos.Columns[0].Header = "Fecha Proceso";
            dgDatos.Columns[1].Header = "Minutos";
            dgDatos.Columns[2].Header = "Dia Procesado";
            dgDatos.Columns[3].Header = "Hora Procesado";
            dgDatos.Columns[4].Header = "Tienda";
            dgDatos.Columns[5].Header = "Estatus";
        }

        private void RowStyle()
        {

        }

        private void DataGrid_DatePicker_Loaded(object sender, RoutedEventArgs e)
        {
            // get the DatePicker control
            DatePicker lDatePicker = sender as DatePicker;
            lDatePicker.VerticalContentAlignment = System.Windows.VerticalAlignment.Center;

            // find the inner textbox and adjust the Background colour
            DatePickerTextBox lInnerTextBox = lDatePicker.Template.FindName("PART_TextBox", lDatePicker) as DatePickerTextBox;
            lInnerTextBox.Background = Brushes.Transparent;
            lInnerTextBox.VerticalContentAlignment = System.Windows.VerticalAlignment.Center;
            lInnerTextBox.Height = lDatePicker.ActualHeight - 2;

            // remove watermark
            ContentControl lWatermark = lInnerTextBox.Template.FindName("PART_Watermark", lInnerTextBox) as ContentControl;
            lWatermark.IsHitTestVisible = false;
            lWatermark.Focusable = false;
            lWatermark.Visibility = System.Windows.Visibility.Collapsed;
            lWatermark.Opacity = 0;

            // just as demo
            ContentControl lContentHost = lInnerTextBox.Template.FindName("PART_ContentHost", lInnerTextBox) as ContentControl;

            //// remove ugly borders
            //RemoveBorders(lInnerTextBox);  // hardcore <img draggable="false" class="emoji" alt="🙂" src="https://s0.wp.com/wp-content/mu-plugins/wpcom-smileys/twemoji/2/svg/1f642.svg">  
        }


        private void Procesar_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = System.Windows.MessageBox.Show("Se va a procesar las fechas que se muestran en la pantalla", "Confirmación", MessageBoxButton.YesNo);
            switch (result)
            {
                case MessageBoxResult.Yes:
                    System.Windows.MessageBox.Show("Click para procesar", "ok");
                 
                    foreach (DataRowView item in dgDatos.ItemsSource)
                    {
                        if (item[5].ToString() != "Procesando")
                        {
                            string fechaInicial = item[0].ToString();
                            string fechaInFinal = item[0].ToString();

                            Fdp.Negocio.FechasProceso.FechasProceso.GetInstance().ProcesaFecha(fechaInicial, fechaInFinal);
                        }
                    }
                    break;
                case MessageBoxResult.No:
                    System.Windows.MessageBox.Show("Cancelado por el usuario", "Confirmación");
                    break;
            }

        }

        private void dgDatos_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {
            foreach (DataGridRow row in dgDatos.SelectedItems)
            {
                System.Data.DataRow MyRow = (System.Data.DataRow)row.Item;
                string value = MyRow["CUPFCH"].ToString();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        //Refreshes grid data on timer tick
        protected void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            RebindData();
        }

        //Get data and bind to the grid
        private void RebindData()
        {
            BinDatos();
        }

        //Set and start the timer
        private void SetTimer()
        {
            DispatcherTimer dispatcherTimer = new DispatcherTimer();
            dispatcherTimer.Tick += new EventHandler(dispatcherTimer_Tick);
            dispatcherTimer.Interval = new TimeSpan(0, 0, 2);
            dispatcherTimer.Start();
        }

    }
}
