﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using Color = System.Drawing.Color;
using System.Windows.Forms;
using System.Windows;
using MessageBox = System.Windows.MessageBox;

namespace FormasDepago
{
    /// <summary>
    /// Interaction logic for TrxVentas.xaml
    /// </summary>
    public partial class TrxVentas : System.Windows.Window
    {
        public System.Data.DataTable dtDatos = null;
        public static string VarFechaInicial { get; set; }
        public static string VarFechaFinal   { get; set; }
        public static string VarTienda       { get; set; }
        public static string VarTiendaIni    { get; set; }

        string tienda = string.Empty;

        public TrxVentas(int cont1)
        {
            InitializeComponent();
            double widthPrimary = System.Windows.SystemParameters.PrimaryScreenWidth;
            double heightPrimary = System.Windows.SystemParameters.PrimaryScreenHeight;

            double widthArea = System.Windows.SystemParameters.WorkArea.Height;
            double heightArea = System.Windows.SystemParameters.WorkArea.Width;

            double widthThis = this.Width;
            double heihgtThis = this.Height;

            dgDatos.MaxWidth = widthThis - 30;
            dgDatos.MaxHeight = heihgtThis - 120;

            dgDatos.Visibility = Visibility.Hidden;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            double widthThis = this.Width;
            double heihgtThis = this.Height;

            try
            {
                dgDatos.MaxWidth = widthThis - 30;
                dgDatos.MaxHeight = heihgtThis - 120;
            }
            catch { }
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void Window_Initialized(object sender, EventArgs e)
        {

        }

        private void btCerrar_Click(object sender, RoutedEventArgs e)
        {
            FormasDepago.MainWindow.cont1 = 0;
            this.Close();
        }

        private void btMaximizar_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Maximized)
            {
                WindowState = WindowState.Normal;
            }
            else
            {
                WindowState = WindowState.Maximized;
            }
        }

        private void btMinimizar_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void LbTitulo_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (WindowState == WindowState.Maximized)
            {
                WindowState = WindowState.Normal;
            }
            else
            {
                WindowState = WindowState.Maximized;
            }
        }

        private void FechaInicial_CalendarClosed(object sender, RoutedEventArgs e)
        {

        }

        private void FechaInicial_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void FechaInicial_Initialized(object sender, EventArgs e)
        {

        }

        private void FechaFinal_Initialized(object sender, EventArgs e)
        {

        }

        private void FechaFinal_CalendarClosed(object sender, RoutedEventArgs e)
        {

        }

        private void FechaFinal_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btRecargar_Click(object sender, RoutedEventArgs e)
        {
            BinDatos();
        }

        protected void BinDatos()
        {
            try
            {
                string fechainicialC = FechaInicial.Text;
                fechainicialC = fechainicialC.Substring(8, 2) + fechainicialC.Substring(3, 2) + fechainicialC.Substring(0, 2);
                string fechafinalC = FechaFinal.Text;
                fechafinalC = fechafinalC.Substring(8, 2) + fechafinalC.Substring(3, 2) + fechafinalC.Substring(0, 2);

                FormasDepago.TrxVentas.VarFechaInicial = fechainicialC;
                FormasDepago.TrxVentas.VarFechaFinal = fechafinalC;

                string tienda = FormasDepago.TrxVentas.VarTienda;

                string usuario = FormasDepago.MainWindow.VarUsuario;

                dtDatos = null;
                dgDatos.ItemsSource = null;

                dtDatos = Fdp.Negocio.TrxVentas.TrxVentas.GetInstance().ObtenDatos(fechainicialC, fechafinalC, tienda, usuario);
            }
            catch { }

            if (dtDatos != null)
            {
                if (dtDatos.Rows.Count > 0)
                {
                    dgDatos.Visibility = Visibility.Visible;

                    lbTitulo.Content = " Transacciones por tienda" + " / " + dtDatos.Rows.Count + " Registros";
                    dgDatos.ItemsSource = null;

                    dgDatos.ItemsSource = dtDatos.DefaultView;

                }
                else
                {
                    dgDatos.Visibility = Visibility.Hidden;
                }
            }
        }

        private void btExportar_Click(object sender, RoutedEventArgs e)
        {
            CargaExcel();
        }

        private void CargaExcel()
        {
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                System.Windows.MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            int nc = dgDatos.Columns.Count;


            for (int ii = 1; ii <= nc; ii++)
            {
                xlWorkSheet.Cells[1, ii] = dgDatos.Columns[ii - 1].Header;
            }

            int nr = dgDatos.Items.Count;

            int r = 0;
            int rt = 3;
            foreach (DataRow row in dtDatos.Rows)
            {
                var gsArray = new[]       {
                            row["TRXSTR"], // 01
                            row["TRXFCH"], // 02
                            row["TRXTIM"], // 03
                            row["TRXTRN"], // 04
                            row["TRXSEQ"], // 05
                            row["TRXTYP"], // 06
                            row["TRXSKU"], // 07
                            row["TRXPRV"], // 08
                            row["TRXSTY"], // 09
                            row["TRXQTY"], // 10
                            row["TRXCST"], // 11
                            row["TRXPSI"], // 12
                            row["TRXIVA"], // 13
                            row["TRXPCI"], // 14
                            row["TRXCSTA"], // 15
                            row["TRXPSIA"], // 16
                            row["TRXMRGA"], // 17
                            row["TRXDP"],   // 18
                            row["TRXSD"],   // 19
                            row["TRXCL"],   // 20
                            row["TRXSC"],   // 21
                            row["TRXDPD"],  // 22
                            row["TRXSDD"],  // 23
                            row["TRXCLD"],  // 24
                            row["TRXSCD"]   // 25
                };

                Range rng = xlWorkSheet.get_Range("A" + rt, "Y" + rt);
                rng.Value = gsArray;

                lbTitulo.Content = " Formas de Pago" + " / " + (r += 1).ToString();

                rt++;
            }
            xlWorkSheet.Columns[01].ColumnWidth = 04;
            xlWorkSheet.Columns[02].ColumnWidth = 10;
            xlWorkSheet.Columns[03].ColumnWidth = 10;
            xlWorkSheet.Columns[04].ColumnWidth = 04;
            xlWorkSheet.Columns[05].ColumnWidth = 04;
            xlWorkSheet.Columns[06].ColumnWidth = 04;
            xlWorkSheet.Columns[07].ColumnWidth = 10;
            xlWorkSheet.Columns[08].ColumnWidth = 05;
            xlWorkSheet.Columns[09].ColumnWidth = 15;
            xlWorkSheet.Columns[10].ColumnWidth = 05;
            xlWorkSheet.Columns[11].ColumnWidth = 10;
            xlWorkSheet.Columns[12].ColumnWidth = 10;
            xlWorkSheet.Columns[13].ColumnWidth = 10;
            xlWorkSheet.Columns[14].ColumnWidth = 10;
            xlWorkSheet.Columns[15].ColumnWidth = 10;
            xlWorkSheet.Columns[16].ColumnWidth = 10;
            xlWorkSheet.Columns[17].ColumnWidth = 10;

            xlWorkSheet.Columns[18].ColumnWidth = 5;
            xlWorkSheet.Columns[19].ColumnWidth = 5;
            xlWorkSheet.Columns[20].ColumnWidth = 5;
            xlWorkSheet.Columns[21].ColumnWidth = 5;

            xlWorkSheet.Columns[22].ColumnWidth = 20;
            xlWorkSheet.Columns[23].ColumnWidth = 20;
            xlWorkSheet.Columns[24].ColumnWidth = 20;
            xlWorkSheet.Columns[25].ColumnWidth = 20;


            var Rang01 = xlWorkSheet.get_Range("A1", "C1");
            Rang01.Interior.Color = Color.Gray;

            var Rang02 = xlWorkSheet.get_Range("D1", "G1");
            Rang02.Interior.Color = Color.LightSkyBlue;

            var Rang03 = xlWorkSheet.get_Range("H1", "I1");
            Rang03.Interior.Color = Color.Gray;

            var Rang04 = xlWorkSheet.get_Range("J1", "J1");
            Rang04.Interior.Color = Color.LightGray;

            var Rang05 = xlWorkSheet.get_Range("K1", "N1");
            Rang05.Interior.Color = Color.LightSkyBlue;

            var Rang06 = xlWorkSheet.get_Range("O1", "Q1");
            Rang06.Interior.Color = Color.Gray;

            var Rang07 = xlWorkSheet.get_Range("R1", "Y1");
            Rang07.Interior.Color = Color.LightBlue;


            var Rang23 = xlWorkSheet.get_Range("A1", "Y1");
            Rang23.WrapText = true;
            Rang23.Font.Bold = true;
            Rang23.Font.Color = Color.White;
            Rang23.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang23.Font.Underline = true;
            //Rang23.HorizontalAlignment = AlignmentX.Left;
            //Rang02.HorizontalAlignment = XlHAlign.xlHAlignCenter;

            String Rango = "A2" + ":" + "Y" + rt;
            Excel.Range SourceRange = (Excel.Range)xlWorkSheet.get_Range("A2", "Y" + rt); // or whatever range you want here
            FormatAsTable(SourceRange, "Table1", "TableStyleMedium2");

            xlWorkSheet.Rows[2].Hidden = true;

            xlWorkSheet.Columns["A:C"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["D:E"].HorizontalAlignment = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["F"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["G:H"].HorizontalAlignment = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["I"].HorizontalAlignment   = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["J:Q"].HorizontalAlignment = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["R:U"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["V:Y"].HorizontalAlignment = XlHAlign.xlHAlignLeft;


            xlWorkSheet.Columns["A"].NumberFormat = "#####";
            xlWorkSheet.Columns["B"].NumberFormat = "2000-00-00";
            xlWorkSheet.Columns["C"].NumberFormat = "00-00-00";
            xlWorkSheet.Columns["D"].NumberFormat = "#####";
            xlWorkSheet.Columns["E"].NumberFormat = "#####";
            xlWorkSheet.Columns["G"].NumberFormat = "#########";
            xlWorkSheet.Columns["H"].NumberFormat = "######";
            xlWorkSheet.Columns["J"].NumberFormat = "###,###";
            xlWorkSheet.Columns["K:Q"].NumberFormat = "###,###.00";

            var range = xlWorkSheet.get_Range("A3", "A3");
            range.Select();

            //xlApp.Range["I:J"].EntireColumn.Delete();

            string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
            xlApp.ActiveWindow.Zoom = 80;
            xlWorkBook.SaveAs("C:\\Reportes\\TransaccionXtienda" + Hoy + ".xlsx", Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            string comando = @"C:\\Reportes\\TransaccionXtienda" + Hoy + ".xlsx";
            ExecuteCommand(comando);
        }

        static void ExecuteCommand(string _Command)
        {
            //Indicamos que deseamos inicializar el proceso cmd.exe junto a un comando de arranque. 
            //(/C, le indicamos al proceso cmd que deseamos que cuando termine la tarea asignada se cierre el proceso).
            //Para mas informacion consulte la ayuda de la consola con cmd.exe /? 
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;
            //Inicializa el proceso
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            string result = proc.StandardOutput.ReadToEnd();
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        public void FormatAsTable(Excel.Range SourceRange, string TableName, string TableStyleName)
        {
            SourceRange.Worksheet.ListObjects.Add(XlListObjectSourceType.xlSrcRange,
            SourceRange, System.Type.Missing, XlYesNoGuess.xlYes, System.Type.Missing).Name =
                TableName;
            SourceRange.Select();
            SourceRange.Worksheet.ListObjects[TableName].TableStyle = TableStyleName;
            SourceRange.Worksheet.ListObjects[TableName].ShowAutoFilter = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowHeaders = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowTotals = false;
        }

        private void dgDatos_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {

        }

        private void cbTiendas_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            try
            {
                string[] arr;
                arr = cbTiendas.SelectedValue.ToString().Split();
                tienda = arr[1];
                FormasDepago.TrxVentas.VarTienda = tienda;
                if (tienda == "9999")
                {
                    FormasDepago.TrxVentas.VarTienda = FormasDepago.TrxVentas.VarTiendaIni;
                }
            }
            catch { }

            // Carga de Tiendas
            try
            {
                BinDatos();
            }
            catch { }
        }

        private void cbTiendas_Loaded(object sender, RoutedEventArgs e)
        {
            string fechainicialC = FormasDepago.TrxVentas.VarFechaInicial;
            fechainicialC = fechainicialC.Substring(4, 2) + "/" + fechainicialC.Substring(2, 2) + "/" + fechainicialC.Substring(0, 2);
            FechaInicial.Text = fechainicialC;

            string fechafinalC = FormasDepago.TrxVentas.VarFechaFinal;
            fechafinalC = fechafinalC.Substring(4, 2) +  "/" + fechafinalC.Substring(2, 2) +  "/" + fechafinalC.Substring(0, 2);
            FechaFinal.Text = fechafinalC;

            // Carga de Tiendas
            try
            {
                BindTiendas();
            }
            catch { }
        }

        protected void BindTiendas()
        {
            try
            {
                cbTiendas.ItemsSource = Fdp.Negocio.FormasDepago.FormasDepago.GetInstance().ObtenTiendas().ToList();
                cbTiendas.DisplayMemberPath = "Value";
                cbTiendas.SelectedValue = "Key";
                //cbTiendas.SelectedValue = FormasDepago.TrxVentas.VarTienda;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void cbTiendas_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                // Carga de Datos
                try
                {
                    BinDatos();
                }
                catch { }
            }
        }

        private void Row_DoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Card01.Visibility = Visibility.Hidden;
        }

        private void Button_LostFocus(object sender, RoutedEventArgs e)
        {
            Card01.Visibility = Visibility.Hidden;
        }

        private void cbNivel_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {

        }

        private void cbNivel_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
