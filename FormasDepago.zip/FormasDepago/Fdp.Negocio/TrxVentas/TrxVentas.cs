﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fdp.Negocio.TrxVentas
{
    public class TrxVentas
    {
        internal static TrxVentas TrxVenta;

        public static TrxVentas GetInstance()
        {
            if (TrxVenta == null)
                TrxVenta = new TrxVentas();
            return TrxVenta;
        }

        public DataTable ObtenDatos(string fechaInicial, string fechaFinal, string tienda, string usuario)
        {
            try
            {
                return Fdp.Datos.TrxVentas.TrxVentas.ObtenerDatos(fechaInicial, fechaFinal, tienda, usuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
