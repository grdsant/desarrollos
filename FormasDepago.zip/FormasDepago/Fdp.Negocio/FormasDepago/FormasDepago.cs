﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fdp.Negocio.FormasDepago
{
    public class FormasDepago
    {
        internal static FormasDepago FormasDepagos;
        public static FormasDepago GetInstance()
        {
            if (FormasDepagos == null)
                FormasDepagos = new FormasDepago();
            return FormasDepagos;
        }

        public DataTable ObtenDatos(string fechaInicial, string fechaFinal, string tienda, string nivel, string usuario)
        {
            try
            {
                return Fdp.Datos.FormasDepago.FormasDepago.ObtenerDatos(fechaInicial, fechaFinal, tienda, nivel,  usuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Dictionary<string, string> ObtenTiendas()
        {
            try
            {
                return Fdp.Datos.FormasDepago.FormasDepago.ObtenTiendas();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenLogin1(string ParUsuario, string ParPassword)
        {
            DataTable dtLogin1 = null;
            try
            {
                dtLogin1 = Fdp.Datos.FormasDepago.FormasDepago.ObtenLogin(ParUsuario, ParPassword);

                if (dtLogin1 != null)
                {
                    DataView dv = dtLogin1.DefaultView;
                    dtLogin1 = dv.ToTable();
                }
                return dtLogin1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
