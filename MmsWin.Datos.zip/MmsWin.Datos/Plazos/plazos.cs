﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;

namespace MmsWin.Datos.Plazos
{
    public class plazos
    {
        #region " Conexiones "
        // Ambiente
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseriesAll"].ToString();

        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
        #endregion

        #region " Plazos de ejecución de devoluciones, bonificaciones y rebajas."
        public static DataTable detallePlazosDBR(string marca, string comprador)
        {
            OleDbConnection db2Conn = null;
            DataTable dtFolios = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Clear();

                sql.Append("SELECT \n");
                sql.Append("       IDPROV,	   \n");    // # Prove
                sql.Append("       PROVEEDOR,  \n");    // Descripción Proveedor
                sql.Append("       IDESTILO,   \n");	// # Estilo 
                sql.Append("       ESTILO,	   \n");    // Descripción Estilo
                sql.Append("       IDCOMPRADOR,\n");    // # Comprador
                sql.Append("       COMPRADOR,  \n");    // Descripción Comprador
                sql.Append("       FECHA,	   \n");    // Días que subio a tabla de accion 30 dias antes de la actual
                sql.Append("       FECHADOS,   \n");    // Fecha en el subio
                sql.Append("       FECHATRES,  \n");    // Fecha Actual
                sql.Append("       IDMARCA,	   \n");    // # Marca
                sql.Append("       MARCA       \n");    // Marca
                sql.Append("FROM MMNETLIB.SAT177DBR\n");
                sql.Append("WHERE FECHA < 30\n");

                if (marca != "999") // Filtra marca
                    sql.AppendFormat(" AND IDMARCA = '{0}'  \n", marca);
                if (comprador != "999") // Filtra comprador
                    sql.AppendFormat(" AND IDCOMPRADOR = '{0}'  \n", comprador);

                sql.Append("ORDER BY ESTILO, PROVEEDOR\n");

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtFolios);

                return dtFolios;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion
    }
}
