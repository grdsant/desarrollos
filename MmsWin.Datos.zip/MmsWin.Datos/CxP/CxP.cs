﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;
using MmsWin.Comun;

namespace MmsWin.Datos.CxP
{
    public class CxP
    {

        #region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
        #endregion

        public static DataTable ObtenCxP(string marca, string FchDe, string FchHas, string Folio,
                                            string comprador, string ParProveedor, string PartbNombre, string PartbEstilo, 
                                            string ParDescripcion, string ParFechaRevision)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtReprog = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT * FROM \n");
                sql.Append(" " + LibSatObj + ".SAT177F99 \n");

                sql.AppendFormat(" WHERE CXPFPR BETWEEN " + "'" + "{0}" + "'" + "\n", FchDe);
                sql.AppendFormat(" AND " + "'" + "{0}" + "'" + "\n", FchHas);

                if ((marca != "") && (marca != "999")) { sql.AppendFormat(" and CXPNMR = " + "'" + "{0}" + "'" + "\n", marca); }
                if ((comprador != "") && (comprador != "999")) { sql.AppendFormat(" and CXPCID = " + "'" + "{0}" + "'" + "\n", comprador); }

                if (Folio            != "") { sql.AppendFormat(" and CXPFOLID LIKE " + "'%" + "{0}" + "%'" + "\n", Folio); }
                if (ParProveedor     != "") { sql.AppendFormat(" and CXPPRV        = " + "'" + "{0}" + "'" + "\n", ParProveedor); }
                if (PartbNombre      != "") { sql.AppendFormat(" and CXPPRN   LIKE " + "'%" + "{0}" + "%'" + "\n", PartbNombre); }
                if (PartbEstilo      != "") { sql.AppendFormat(" and CXPSTY        = " + "'" + "{0}" + "'" + "\n", PartbEstilo); }
                if (ParDescripcion   != "") { sql.AppendFormat(" and CXPDES   LIKE " + "'%" + "{0}" + "%'" + "\n", ParDescripcion); }
                if (ParFechaRevision != "") { sql.AppendFormat(" and CXPFCA        = " + "'" + "{0}" + "'" + "\n", ParFechaRevision); }

                sql.Append(" ORDER BY CXPPRV, CXPSTY  ASC\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtReprog = new DataTable("CxP");
                dtReprog.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtReprog;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void EliminaCxP(string ParProveedor, string ParEstilo, string ParFchRev, string ParFchRepro)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("DELETE FROM " + LibSatObj + ".SAT177F14 WHERE\n");
                sql.Append(" REPPRV = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParProveedor.PadLeft(6, '0'));
                sql.Append(" AND REPSTY = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParEstilo.PadRight(15, ' '));
                sql.Append(" AND REPFRV = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParFchRev.PadLeft(6, '0'));
                sql.Append(" AND REPFRP = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParFchRepro.PadLeft(6, '0'));

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        /// <summary>
        /// Obtener las reprogramaciones preautorizadas para que se liguen a un formato.
        /// El único estatus que se trae el método es aquel en estatus 'P'.
        /// </summary>
        /// <returns>DataTable con los datos</returns>
        /// <remarks>PROGRMADOR: OCG 01/12/2016</remarks>
        public static DataTable CargaCxPesSinFormato(string Folio, int Cadena, int Comprador = 0)
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.AppendLine(" SELECT ");
                sql.AppendLine(" F1.REPSTY EstiloID, F1.REPSDS Descripcion, ");
                sql.AppendLine(" F1.REPMID MotivoID, F5.DSCMOV Motivo, ");
                sql.AppendLine(" SUBSTRING(CHAR(F1.REPFRV), 5, 2) || '/'|| SUBSTRING(CHAR(F1.REPFRV),3, 2) || '/' || '20' || SUBSTRING(CHAR(F1.REPFRV),1, 2) Fecha_Calif, ");
                sql.AppendLine(" SUBSTRING(CHAR(F1.REPFRP), 5, 2) || '/'|| SUBSTRING(CHAR(F1.REPFRP),3, 2) || '/' || '20' || SUBSTRING(CHAR(F1.REPFRP),1, 2) Fecha_Reprog, ");
                sql.AppendLine(" F1.REPPRV ProveedorID, F1.REPPDS Proveedor, ");
                sql.AppendLine(" F1.REPCOM CompradorID, F1.REPCDS Comprador, ");
                sql.AppendLine(" F1.REPMAR Marca, F1.REPSTS Estatus, F1.REPUSR Usuario, MMNETLIB.FORMATFECH(F1.REPFRV) FechaVenc, MMNETLIB.FORMATFECH(F1.REPFRP) FechaReprog ");
                sql.AppendLine(" FROM MMSATOBJ.SAT177F14 F1 INNER JOIN MMNETLIB.SAT179F5 F5 ON F1.REPMID = F5.MOVOID ");
                sql.AppendLine(" WHERE F1.REPMID > 0 AND F1.REPFOL = 0 AND F1.REPSTS = 'P' ");

                if (Cadena != 999)
                {
                    sql.AppendFormat(" AND F1.REPMAR = {0}", (int)Cadena);
                }


                if (Comprador != 999)
                {
                    sql.AppendFormat(" AND F1.REPCOM = {0}", (int)Comprador);
                }


                if (Folio.Trim() != "")
                {
                    sql.AppendFormat(" AND  (F1.REPSTY LIKE '{0}%' OR  F1.REPSDS LIKE '{0}%')", Folio);
                }


                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtMotivos);

                return dtMotivos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        /// <summary>
        /// Obtener el número de folio siguiente para el reporte
        /// </summary>
        /// <param name="Tabla">1 = MMSATOBJ.SAT177F14, 2 = MMSATOBJ.SAT177F41 </param>
        /// <returns>Folio</returns>
        /// <remarks>PROGRMADOR: OCG 19/12/2016</remarks>
        public static string ObtenerFolio(int Tabla = 1)
        {
            StringBuilder sql = new StringBuilder();
            string dato = "";

            if (Tabla == 1)
            {
                //Obtener el siguiente folio de reprogramaciones
                sql.Append(" SELECT MAX(REPFOL) + 1 FROM MMSATOBJ.SAT177F14 WHERE REPMID > 0 ");
            }
            else if (Tabla == 2)
            {
                //Obtener el siguiente folio para la ampliación de órdenes de compra
                sql.Append("SELECT MAX(AOCFOL) + 1 FROM MMNETLIB.SAT177F41 ");
            }
            else if (Tabla == 3)
            {
                //Obtener el siguiente folio para la excepción de cobro de FillRate
                sql.Append("SELECT IFNULL(MAX(FFRFOL),0) + 1 FROM  MMNETLIB.SAT177F43 ");
            }
            else if (Tabla == 4)
            {
                //Obtener el siguiente folio para la excepción de cobro de FillRate
                sql.Append("SELECT IFNULL(MAX(FOLIOS),0) + 1 FROM  MMNETLIB.BONPARCIAL ");
            }


            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                OleDbDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    dato = reader[0].ToString();
                }

                reader.Close();
            }

            return dato;
        }

        /// <summary>
        /// Asigna el estilo preautorizado a un folio de reporte
        /// </summary>
        /// <param name="Folio">Número de folio al que se ligará</param>
        /// <param name="Marca">Marca a la que pertenece el estilo</param>
        /// <param name="EstiloID">Número Estilo</param>
        /// <param name="ProveedorID">Número Proveedor</param>
        /// <param name="REPFRV">Fecha revisión</param>
        /// <param name="REPFRP">Fecha nueva programación</param>
        /// <returns>True: Actualización satisfactoria, False: Actualización fallida</returns>
        public static bool AsignaFolio(string Folio, string Marca, string EstiloID, string ProveedorID, int REPFRV, int REPFRP)
        {
            StringBuilder sql = new StringBuilder();

            sql.AppendFormat(" UPDATE MMSATOBJ.SAT177F14 SET REPFOL = {0} WHERE	REPSTY = '{1}' AND REPPRV = {2} AND REPFRV = {3} AND REPFRP = {4} AND REPMAR = {5} ", Folio, EstiloID, ProveedorID, REPFRV, REPFRP, Marca);

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                command.ExecuteNonQuery();

                return true;
            }
        }

        /// <summary>
        /// Carga los Folios disponibles en el sistema para consulta
        /// </summary>
        /// <param name="Folio">Folio que se busca</param>
        /// <returns>DataTable con los folios encontrados</returns>
        public static DataTable CargaListaFolios(string Folio = "", string Status = "P", int Cadena = 999, int Comprador = 999)
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.AppendLine(" SELECT DISTINCT REPFOL Folio,  ");
                sql.AppendLine(" CASE REPSTS  ");
                sql.AppendLine(" WHEN 'P' THEN 'Pendiente'  ");
                sql.AppendLine(" WHEN 'A' THEN 'Autorizado'  ");
                sql.AppendLine(" WHEN 'C' THEN 'Vencido'  ");
                sql.AppendLine(" END	Estatus ,  ");
                sql.AppendLine(" REPSTS  ");
                sql.AppendLine(" FROM   ");
                sql.AppendLine(" MMSATOBJ.SAT177F14 WHERE REPMID > 0 AND REPFOL > 0  ");
                sql.AppendFormat(" AND Repfol LIKE '{0}%' ", Folio);
                sql.AppendFormat(" AND REPSTS = '{0}' ", Status);

                if (Cadena != 999)
                {
                    sql.AppendFormat(" AND REPMAR = {0} ", Cadena);
                }

                if (Comprador != 999)
                {
                    sql.AppendFormat(" AND  REPCOM = {0} ", Comprador);
                }

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtMotivos);

                return dtMotivos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        /// <summary>
        /// Carga los folios de las Solicitudes de Ampliación de Ordenes de Compra
        /// </summary>
        /// <param name="Folio">Folio a buscar</param>
        /// <param name="Estatus">Estatus por el que se desea filtrar</param>
        /// <returns>Datatable con los datos</returns>
        public static DataTable CargaListaFoliosOC(string Folio = "", string Estatus = "P", string Comprador = "")
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Append(" SELECT DISTINCT Folio, Estatus, AOCSTS ");
                sql.Append(" FROM  MMNETLIB.CVOACFOXCO  ");
                sql.AppendFormat(" WHERE AOCSTS = '{0}'  ", Estatus);


                if (Comprador != "999")
                {
                    sql.AppendFormat(" AND BYRNUM = '{0}'  ", Comprador);
                }


                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtMotivos);

                return dtMotivos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        /// <summary>
        /// Carga el detalle de los estilos preautorizados por folio
        /// </summary>
        /// <param name="Folio">Número de reporte</param>
        /// <returns>DataTable con los datos</returns>
        /// <remarks>PROGRMADOR: OCG 20/12/2016</remarks>
        public static DataTable CargaDetalleFolio(string Folio)
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Append(" SELECT ");
                sql.Append(" F1.REPSTY EstiloID, F1.REPSDS Descripcion, ");
                sql.Append(" F1.REPMID MotivoID, F5.DSCMOV Motivo, ");
                sql.Append(" SUBSTRING(CHAR(F1.REPFRV), 5, 2) || '/'|| SUBSTRING(CHAR(F1.REPFRV),3, 2) || '/' || '20' || SUBSTRING(CHAR(F1.REPFRV),1, 2) Fecha_Calif, ");
                sql.Append(" SUBSTRING(CHAR(F1.REPFRP), 5, 2) || '/'|| SUBSTRING(CHAR(F1.REPFRP),3, 2) || '/' || '20' || SUBSTRING(CHAR(F1.REPFRP),1, 2) Fecha_Reprog, ");
                sql.Append(" F1.REPPRV ProveedorID, F1.REPPDS Proveedor, ");
                sql.Append(" F1.REPCOM CompradorID, F1.REPCDS Comprador, ");
                sql.Append(" F1.REPMAR Marca, F1.REPSTS Estatus, F1.REPUSR Usuario, MMNETLIB.FORMATFECH(F1.REPFRV) FechaVenc, MMNETLIB.FORMATFECH(F1.REPFRP) FechaReprog ");
                sql.Append(" FROM MMSATOBJ.SAT177F14 F1 INNER JOIN MMNETLIB.SAT179F5 F5 ON F1.REPMID = F5.MOVOID ");
                sql.Append(" WHERE F1.REPMID > 0 ");
                sql.AppendFormat(" AND F1.REPFOL = '{0}' ", Folio);

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtMotivos);

                return dtMotivos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        /// <summary>
        /// Libera los estilos indicados para poder ser vinculados a otra solicitud
        /// </summary>
        /// <param name="EstiloID">Número Estilo</param>
        /// <param name="ProveedorID">Número Proveedor</param>
        /// <param name="REPFRV">Fecha revisión</param>
        /// <param name="REPFRP">Fecha nueva programación</param>
        /// <returns>True: Actualización satisfactoria, False: Actualización fallida</returns>
        public static bool LiberarEstilos(string EstiloID, string ProveedorID, int REPFRV, int REPFRP)
        {
            StringBuilder sql = new StringBuilder();

            sql.AppendFormat(" UPDATE MMSATOBJ.SAT177F14 SET REPFOL = 0 WHERE REPSTY = {0} AND REPPRV = {1} AND REPFRV = {2} AND REPFRP = {3} ", EstiloID, ProveedorID, REPFRV, REPFRP);

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                command.ExecuteNonQuery();

                return true;
            }
        }

        /// <summary>
        /// Autorizar los estilos indicados 
        /// </summary>
        /// <param name="EstiloID">Número Estilo</param>
        /// <param name="ProveedorID">Número Proveedor</param>
        /// <param name="REPFRV">Fecha revisión</param>
        /// <param name="REPFRP">Fecha nueva programación</param>
        /// <returns>True: Actualización satisfactoria, False: Actualización fallida</returns>
        public static bool AutorizarEstilos(string EstiloID, string ProveedorID, int REPFRV, int REPFRP)
        {
            StringBuilder sql = new StringBuilder();

            sql.AppendFormat(" UPDATE MMSATOBJ.SAT177F14 SET REPSTS = 'A' WHERE REPSTY = '{0}' AND REPPRV = {1} AND REPFRV = {2} AND REPFRP = {3} ", EstiloID, ProveedorID, REPFRV, REPFRP);

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                command.ExecuteNonQuery();

                return true;
            }
        }

        /// <summary>
        /// Obtiene el porcentaje mínimo para que el estilo pueda ser reprogramado para su calificación
        /// </summary>
        /// <param name="Cadena">Número de la marca o cadena</param>
        /// <param name="Fecha">Fecha en la que se hizo la revisión o calificación</param>
        /// <returns>Porcentaje mínimo que debe de tener en la calificación</returns>
        /// <remarks>PROGRMADOR: OCG 28/12/2016</remarks>
        public static string PorcentajeMinimoReprogramar(int Cadena, DateTime Fecha)
        {
            StringBuilder sql = new StringBuilder();
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("es-MX");
            string dato = "";
            string[] Fechas;

            Fechas = Fecha.GetDateTimeFormats();

            sql.Append(" SELECT TABPRM FROM MMSATOBJ.SAT177TART ");
            sql.AppendFormat(" WHERE HTBMAR = {0} ", Cadena);
            sql.AppendFormat(" AND '{0}' BETWEEN PERIODO_DE AND PEDIODO_AL ", Fechas[6]);

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                OleDbDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    dato = reader[0].ToString();
                }

                reader.Close();
            }

            return dato;
        }

        /// <summary>
        /// Busca el proveedor en la tabla de proveedores internacionales para determinar su origen
        /// </summary>
        /// <param name="NumeroProveedor">Número de proveedor</param>
        /// <returns>Número del proveedor si es que es encontrado</returns>
        /// /// <remarks>PROGRMADOR: OCG 28/12/2016</remarks>
        public static int ProveedorNacional(int NumeroProveedor)
        {
            int dato = 0;

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(string.Format(" SELECT ORDPRV FROM MMSATOBJ.SAT177SORD WHERE ORDPRV = {0} ", NumeroProveedor), connection);

                connection.Open();

                OleDbDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    dato = Convert.ToInt32(reader[0].ToString());
                }

                reader.Close();
            }

            return dato;
        }

        public static bool AsignaFolioOC(int Folio, int OrdenCompra, string Usuario)
        {
            StringBuilder sql = new StringBuilder();

            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("es-MX");

            string[] Fechas;
            int Fecha400 = 0;

            Fechas = DateTime.Now.GetDateTimeFormats();
            Fecha400 = Convert.ToInt32(Fechas[6].Replace("-", "").Substring(2, 6));


            sql.Append(" INSERT INTO MMNETLIB.SAT177F41 (AOCFOL, AOCORD, AOCFCH, AOCSTS, AOCUSR, AOCFCHA, AOCHORA, AOCUSRA )");

            sql.AppendFormat(" VALUES ({0},{1},{2},'P','{3}',{2},{2},'{3}') ", Folio, OrdenCompra, Fecha400, Usuario);

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                command.ExecuteNonQuery();

                return true;
            }
        }

        public static bool AsignaFolioOCFillRate(int Folio, int OrdenCompra, string Usuario)
        {
            StringBuilder sql = new StringBuilder();
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("es-MX");

            string[] Fechas;
            int Fecha400 = 0;

            Fechas = DateTime.Now.GetDateTimeFormats();
            Fecha400 = Convert.ToInt32(Fechas[6].Replace("-", "").Substring(2, 6));

            sql.AppendLine("INSERT INTO MMNETLIB.SAT177F43");
            sql.AppendFormat("VALUES ({0},0,0,{1},1,'P',{2},{2},'{3}',0)",
                Folio, OrdenCompra, Fecha400, Usuario);

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                command.ExecuteNonQuery();

                return true;
            }
        }

        public static DataTable CargaMotivosAOC()
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Append(" SELECT AOMOTIV ID, AODESCR Descripcion FROM MMNETLIB.SAT177F42 WHERE AOCUCVE = 'AOC'  ");

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtMotivos);

                return dtMotivos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static bool ActualizarFechaAmpliacion(DateTime Fecha, int MotivoID, int Folio, int OrdenCompra)
        {
            StringBuilder sql = new StringBuilder();
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("es-MX");

            int Fecha400 = 0;
            string[] Fechas;
            Fechas = Fecha.GetDateTimeFormats();
            Fecha400 = Convert.ToInt32(Fechas[6].Replace("-", "").Substring(2, 6));

            sql.AppendFormat(" UPDATE MMNETLIB.SAT177F41 SET AOFECHA = {0}, AOMOTIV = {1} WHERE AOCFOL = {2} AND AOCORD = {3} ", Fecha400, MotivoID, Folio, OrdenCompra);

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                command.ExecuteNonQuery();

                return true;
            }
        }

        public static bool LiberarOrdeneCompra(int OrdenCompra)
        {
            StringBuilder sql = new StringBuilder();

            sql.AppendFormat(" DELETE FROM MMNETLIB.SAT177F41 WHERE AOCORD = {0} ", OrdenCompra);

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                command.ExecuteNonQuery();

                return true;
            }
        }

        public static bool AutorizarOrdenesCompra(int OrdenCompra, string Usuario)
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("es-MX");
            int Fecha400 = 0;
            string[] Fechas;
            Fechas = DateTime.Now.GetDateTimeFormats();
            Fecha400 = Convert.ToInt32(Fechas[6].Replace("-", "").Substring(2, 6));

            StringBuilder sql = new StringBuilder();

            //sql.AppendFormat(" UPDATE MMNETLIB.SAT177F41 SET AOCSTS = 'A', AOCUSRA = '{1}', AOFECHA = '{2}', AOCHORA = {3}  WHERE AOCORD = {0}  ", OrdenCompra, Usuario, Fecha400, Convert.ToInt32(Fechas[94].Replace(":","" )));
            sql.AppendFormat(" UPDATE MMNETLIB.SAT177F41 SET AOCSTS = 'A', AOCUSRA = '{1}', AOFECHA = '{2}', AOCHORA = {3}  WHERE AOCORD = {0}  ", OrdenCompra, Usuario, Fecha400, Fecha400);

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                command.ExecuteNonQuery();

                return true;
            }
        }

        public static DataTable CargaOCFillRate(string Param)
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                //sql.AppendFormat("SELECT * FROM MMNETLIB.SAT177REFR WHERE FFREST = 'P'  AND FFRFOL = 0 AND PONUMB LIKE '{0}%'", Param);
                sql.AppendFormat("SELECT * FROM MMNETLIB.SAT177REFR ORDER BY FillRateOC ", Param);

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtMotivos);

                return dtMotivos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable CargaOCFillRate(int Param)
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.AppendFormat("SELECT * FROM MMNETLIB.SAT177REFR WHERE FFRFOL = '{0}'", Param);
                //sql.AppendFormat("SELECT * FROM TABLE(MMNETLIB.fnOrdenCompraFillRate_porFolio({0})) X", Param);

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtMotivos);

                return dtMotivos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable CargaListaFoliosOCFillRate(string Folio = "", string Estatus = "P")
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Append(" SELECT DISTINCT   ");
                sql.Append(" FFRFOL Folio   ");
                sql.Append(" ,CASE FFREST  ");
                sql.Append(" WHEN 'P' THEN 'Pendiente'  ");
                sql.Append(" WHEN 'A' THEN 'Autorizado'  ");
                sql.Append(" WHEN 'C' THEN 'Vencido'   ");
                sql.Append(" END AS 	Estatus  ");
                sql.Append(" ,FFREST AOCSTS  ");
                sql.Append(" FROM  MMNETLIB.SAT177F43  ");
                sql.AppendFormat(" WHERE FFREST = '{0}'  ", Estatus);

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtMotivos);

                return dtMotivos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static bool AutorizarExcepcionFillRate(int OrdenCompra)
        {
            StringBuilder sql = new StringBuilder();

            sql.AppendFormat(" UPDATE MMNETLIB.SAT177F43 SET FFREST = 'A' WHERE FFRPOR = {0}  ", OrdenCompra);

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                command.ExecuteNonQuery();

                return true;
            }
        }

        public static decimal ObtenerPorcentajePenalizacion(decimal FillRate)
        {
            StringBuilder sql = new StringBuilder();
            decimal dato = 0;

            //Obtener el siguiente folio de reprogramaciones
            sql.AppendFormat(" SELECT MMNETLIB.fn_PorcentajePenFillRate({0}) FROM sysibm.sysdummy1", FillRate);

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                OleDbDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    dato = Convert.ToDecimal(reader[0].ToString());
                }

                reader.Close();
            }

            return dato;
        }

        public static DataTable CargaMotivosExceFillRate()
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Append("SELECT MFRVID ID, MFRDSC Descripcion FROM MMNETLIB.SAT177MFR");

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtMotivos);

                return dtMotivos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static bool ActualizarMontoFR(DateTime Fecha, int MotivoID, int Folio, int Monto)
        {
            StringBuilder sql = new StringBuilder();
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("es-MX");
            int Fecha400 = 0;
            string[] Fechas;
            Fechas = Fecha.GetDateTimeFormats();
            Fecha400 = Convert.ToInt32(Fechas[6].Replace("-", "").Substring(2, 6));

            sql.AppendFormat(" UPDATE MMNETLIB.SAT177F43 SET FFRFEC = {0}, FFRFID = {1}, FFRNMT = {3} WHERE FFRFOL = {2} ", Fecha400, MotivoID, Folio, Monto);

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                command.ExecuteNonQuery();

                return true;
            }
        }

        public static string[] ObtFechasPeriodoFillRate(byte idConfiguracion)
        {
            StringBuilder sql = new StringBuilder();
            string[] dato = new string[2];

            sql.AppendFormat("SELECT 	TO_CHAR((MMNETLIB.FIRST_DAY(CURRENT_DATE) - MMNETLIB.FNPAFRFEDE({0}) MONTH),'DD/MM/YYYY') DE ", idConfiguracion.ToString());
            sql.AppendFormat(",TO_CHAR((LAST_DAY(CURRENT_DATE) - MMNETLIB.FNPAFRFEHA({0}) MONTH),'DD/MM/YYYY') HA ", idConfiguracion.ToString());
            sql.Append("FROM sysibm.sysdummy1 ");


            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                OleDbDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    dato[0] = Convert.ToString(reader[0]);//Fecha inicial del periodo
                    dato[1] = Convert.ToString(reader[1]);//Fecha final del periodo
                }

                reader.Close();
            }
            return dato;
        }

        public static decimal ObtFillRatePolitica_porProveedor(int idProveedor, byte idConfiguracion)
        {
            StringBuilder sql = new StringBuilder();
            decimal dato = 0;

            sql.AppendFormat("SELECT MMNETLIB.FillRateProveedor_porPolitica({0},{1},160101) FROM sysibm.sysdummy1 ", idProveedor.ToString(), idConfiguracion.ToString());

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                OleDbDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    dato = Convert.ToDecimal(reader[0]);//Fecha inicial del periodo
                }

                reader.Close();
            }
            return dato;
        }

        public static DataTable obtCatProveedoresFillRate()
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Append(" SELECT * FROM MMNETLIB.vw_ProveedoresFillRate ORDER BY 3   ");

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtMotivos);

                return dtMotivos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static bool LiberarOrdeneCompraFillRate(int OrdenCompra)
        {
            StringBuilder sql = new StringBuilder();

            sql.AppendFormat(" DELETE FROM MMNETLIB.SAT177F43 WHERE FFRPOR = {0} ", OrdenCompra);

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                command.ExecuteNonQuery();

                return true;
            }
        }

        /// <summary>
        /// Obtiene los meses en los que se puede extender una reprogramación, cuando se excede de las 4 semanas
        /// </summary>
        /// <param name="idMarca">Marca</param>
        /// <returns>Matriz con el rango de fechas</returns>
        /// <remarks>PROGRMADOR: OCG 09/02/2017</remarks>
        public static DateTime[] obtPeriodoSemanasExtendidas(byte idMarca)
        {
            StringBuilder sql = new StringBuilder();
            DateTime[] dato = new DateTime[2];

            sql.AppendFormat("SELECT MMNETLIB.FORMATFECH(FIRDES) FIRDES,  MMNETLIB.FORMATFECH(FIRHAS) FIRHAS FROM MMNETLIB.SAT177CFR WHERE FIRGRU = 'SD' AND FIRAMARCA = {0}", idMarca.ToString());

            try
            {
                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();

                    OleDbDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        dato[0] = Convert.ToDateTime(reader[0]);//Fecha inicial del periodo
                        dato[1] = Convert.ToDateTime(reader[1]);//Fecha final del periodo
                    }

                    reader.Close();
                }
                return dato;
            }
            catch (Exception ex)
            {
                throw new System.ArgumentNullException("connection", ex.Message);
            }
        }

        /// <summary>
        /// Obtener total de reprogramaciones por Proveedor-FechaRecibo-Estilo de la tabla
        /// MMSTOBJ.SAT177F14
        /// </summary>
        /// <param name="idProveedor">Número Proveedor</param>
        /// <param name="fechaRecibo">Fecha de Recibo</param>
        /// <param name="idEstilo">Número de Estilo</param>
        /// <remarks>PROGRMADOR: OCG 09/02/2017</remarks>
        /// <returns>Total de reprogramaciones</returns>
        public static byte obtNoCxPes(int idProveedor, int fechaRecibo, string idEstilo, int OrdenCompra)
        {
            StringBuilder sql = new StringBuilder();
            byte dato = 0;

            // Se comenta por que esta validación tiene un bug por falta de la Orden de Compra 
            // como llave
            //sql.Append(" SELECT COUNT(REPSTY) REPTOT FROM MMSATOBJ.SAT177F14 ");
            //sql.AppendFormat(" WHERE REPPRV = {0} AND REPFRV = {1}  AND REPSTY = '{2}'", idProveedor, fechaRecibo, idEstilo);
            //sql.AppendLine(" GROUP BY REPPRV, REPSTY, REPFRV ");

            sql.AppendFormat("SELECT COUNT(ORDENCOM) REPTOT FROM MMNETLIB.AUDREPROG WHERE ORDENCOM = {0}", OrdenCompra);

            try
            {
                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();

                    OleDbDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        dato = Convert.ToByte(reader[0]);//Fecha inicial del periodo
                    }

                    reader.Close();
                }
                return dato;
            }
            catch (Exception ex)
            {
                throw new System.ArgumentNullException("connection", ex.Message);
            }
        }

    }
}
