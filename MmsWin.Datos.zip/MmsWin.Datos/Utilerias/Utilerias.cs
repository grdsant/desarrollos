﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;
using MmsWin.Comun;
using Data.Common.Ole;


namespace MmsWin.Datos.Utilerias
{
    public class Utilerias
    {

        #region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
        #endregion

        public static DataTable ObtenFechaInicial()
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtFechaInicial = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                string ParUsuario = "CALIFICA";
                sql.Append("CALL " + LibSatPgm + ".SAT179C4 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParUsuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader dbcall = db2Comm.ExecuteReader();
                dbcall.Close();

                sql.Clear();
                sql.Append("SELECT DSPFCH  FROM " + LibSatObj + ".SAT179PF FETCH FIRST 1 ROWS ONLY\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtFechaInicial = new DataTable("FechaInicial");
                dtFechaInicial.Load(db2Reader);

                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtFechaInicial;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenCalculos(string ParFchBon, string ParFchRev, string ParProveedor, string ParEstilo, string ParNotCal, string ParUsuario)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtCalculos = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R22 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchBon.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchRev.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParProveedor.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParEstilo.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParNotCal.PadRight(20, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParUsuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177F22 FETCH FIRST 1 ROWS ONLY\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtCalculos = new DataTable("Calculos");
                dtCalculos.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtCalculos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenCalculoNota(string ParFchBon, string ParFchRev, string ParProveedor, string ParEstilo, string ParNotCal, string ParUsuario, string ParSubTot, string TipMov, string TipCal, string ParPorc)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtCalculosNota = null;

            try
            {
                string RutaPdf = "";
                string varInd1 = "";
                string varInd2 = "";

                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R23 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchBon.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchRev.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParProveedor.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParEstilo.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParNotCal.PadRight(20, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParSubTot.PadLeft(15, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParUsuario.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParPorc.PadLeft(9, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", varInd1.PadLeft(1, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", varInd2.PadRight(1, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", TipMov.PadRight(3, ' '));    // BON = Bonificacion, DEV = Devolucion
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", TipCal.PadRight(3, ' '));    // CXO = Calificacion por Omision, NOR = normal 
                sql.AppendFormat("'" + "{0}" + "'" + "\n", RutaPdf.PadRight(100, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177F23 FETCH FIRST 1 ROWS ONLY\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtCalculosNota = new DataTable("CalculosNota");
                dtCalculosNota.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtCalculosNota;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenCalculoNotaDiferenciada(string ParFchBon, string ParFchRev, string ParTipo, string ParTemporada, string ParTienda, string ParProveedor, string ParEstilo, string ParNotCal, string ParUsuario, string ParSubTot, string TipMov, string TipCal, string ParPorc)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtCalculosNota = null;

            try
            {
                string RutaPdf = "";
                string varInd1 = "";
                string varInd2 = "";

                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R233 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchBon.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchRev.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParTipo.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParTemporada.PadRight(3, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParTienda.PadRight(3, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParProveedor.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParEstilo.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParNotCal.PadRight(20, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParSubTot.PadLeft(15, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParUsuario.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParPorc.PadLeft(9, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", varInd1.PadLeft(1, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", varInd2.PadRight(1, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", TipMov.PadRight(3, ' '));    // BON = Bonificacion, DEV = Devolucion
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", TipCal.PadRight(3, ' '));    // CXO = Calificacion por Omision, NOR = normal 
                sql.AppendFormat("'" + "{0}" + "'" + "\n", RutaPdf.PadRight(100, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177F23 FETCH FIRST 1 ROWS ONLY\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtCalculosNota = new DataTable("CalculosNota");
                dtCalculosNota.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtCalculosNota;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void InsertaRegistrosArebajar(DataTable dtDiferenciados, string usuario, string porcentajeXaplicar, string PrecioFinalXaplicar)
        {
            string mensaje            = string.Empty;
            string cadenaConexionDb2  = Db2_Prod;

            string tienda             = string.Empty;
            string proveedor          = string.Empty;
            string estilo             = string.Empty;
            string precioTienda       = "0";
            string xSeleccionar       = "1";
            //string porcentajeXaplicar = "0";
            string seleccionXaplicar  = "0";
            string inventarioActual   = "0";

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtExist = null;

            db2Conn = new OleDbConnection(cadenaConexionDb2);
            db2Conn.Open();
            OleDbCommand db2Comm = db2Conn.CreateCommand();


            //db2Conn = new OleDbConnection(cadenaConexionDb2);
            //db2Conn.Open();
            //OleDbCommand db2Comm = db2Conn.CreateCommand();
            sql.Append("CALL " + LibSatPgm + ".SAT177C8 (\n");
            sql.AppendFormat("'" + "{0}" + "'" + "\n", usuario.PadRight(10, ' '));
            sql.Append(")");

            db2Comm.CommandText = sql.ToString();
            OleDbDataReader dbcall = db2Comm.ExecuteReader();
            dbcall.Close();


            foreach (DataRow row in dtDiferenciados.Rows)
            {
                tienda           = row["ParTienda"].ToString();
                proveedor        = row["ParProveedor"].ToString();
                estilo           = row["ParEstilo"].ToString();
                inventarioActual = row["ParInventario"].ToString();

                try
                {
                    sql.Clear();
                    sql.Append("SELECT   \n");
                    sql.Append("RXTSTR,  \n");  //00 Tienda
                    sql.Append("RXTPRV,  \n");  //01 Proveedor
                    sql.Append("RXTSTY   \n");  //02 Estilo

                    sql.Append("FROM " + LibSatObj + ".SAT177F78 \n");
                    sql.AppendFormat(" WHERE \n");
                    sql.AppendFormat("     RXTSTR = " + "'" + "{0}" + "'" + "\n", tienda.PadLeft(5, '0'));
                    sql.AppendFormat(" and RXTPRV = " + "'" + "{0}" + "'" + "\n", proveedor.PadLeft(6, '0'));
                    sql.AppendFormat(" and RXTSTY = " + "'" + "{0}" + "'" + "\n", estilo.PadRight(15, ' '));

                    db2Comm.CommandText = sql.ToString();
                    OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                    dtExist = new DataTable("validacion");
                    dtExist.Load(db2Reader);

                    if (dtExist.Rows.Count > 0)
                    {
                        sql.Clear();
                        sql.Append("Update  \n");      
                        sql.Append(" " + LibSatObj + ".SAT177F78 \n");
                        sql.Append("set \n");

                        sql.AppendFormat("RXTPRE = " + "'" + "{0}" + "'" + "," + "\n", PrecioFinalXaplicar); // Precio Tienda 
                        sql.AppendFormat("RXTXSE = " + "'" + "{0}" + "'" + "," + "\n", xSeleccionar); // Identificador 
                        sql.AppendFormat("RXTPOR = " + "'" + "{0}" + "'" + " " + "\n", porcentajeXaplicar);  // porcentaje 
                        sql.AppendFormat(" WHERE \n");
                        sql.AppendFormat("     RXTSTR = " + "'" + "{0}" + "'" + "\n", tienda.PadLeft(5, '0'));
                        sql.AppendFormat(" and RXTPRV = " + "'" + "{0}" + "'" + "\n", proveedor.PadLeft(6, '0'));
                        sql.AppendFormat(" and RXTSTY = " + "'" + "{0}" + "'" + "\n", estilo.PadRight(15, ' '));

                        db2Comm.CommandText = sql.ToString();
                        db2Comm.ExecuteNonQuery();

                        mensaje = "Se actualizó el registro exitosamente...";
                        //return mensaje;
                    }
                     
                    else
                    {

                        try
                        {
                            sql.Clear();
                            sql.Append("Insert Into \n"); //00 Comando 
                            sql.Append(" " + LibSatObj + ".SAT177F78 (\n");
                            sql.Append("RXTSTR, \n");     //00 Tienda
                            sql.Append("RXTPRV, \n");     //01 Proveedor
                            sql.Append("RXTSTY, \n");     //02 Estilo
                            sql.Append("RXTFEF, \n");     //03 Fecha Efectiva 
                            sql.Append("RXTPRE, \n");     //04 Precio
                            sql.Append("RXTONH, \n");     //05 Inventario Actual
                            sql.Append("RXTINS, \n");     //06 InsBal
                            sql.Append("RXTAPL, \n");     //07 Aplicado
                            sql.Append("RXTSEL, \n");     //08 Selecciona x palicar 
                            sql.Append("RXTXSE, \n");     //09 X seleccionar
                            sql.Append("RXTPOR, \n");     //10 Porcentaje 
                            sql.Append("RXTORI, \n");     //11 Precio Original 
                            sql.Append("RXTACT, \n");     //12 Precio Actual
                            sql.Append("RXTPRO, \n");     //13 Importe Original
                            sql.Append("RXTPCD )\n");     //14 Importe Con Descuento


                            sql.Append("Values \n"); //    00 Lista de Valores a grabar

                            sql.AppendFormat("(" + "'" + "{0}" + "'" + "," + "\n", tienda);            //00 Tienda
                            sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", proveedor);         //01 Proveedor
                            sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", estilo);            //02 Estilo 
                            sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", 0);                 //03 Fecha Efectiva 
                            sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", PrecioFinalXaplicar);//04 Precio 
                            sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", inventarioActual);  //05 Inventario Actual
                            sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", '0');               //06 InsBal
                            sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", '0');               //07 Aplicado 
                            sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", seleccionXaplicar); //08 Selecciona x palicar
                            sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", xSeleccionar);      //09 X seleccionar
                            sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", porcentajeXaplicar);//10 Porcentaje 
                            sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", '0');               //11 Precio Original  
                            sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", '0');               //12 Precio Actual 
                            sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", '0');               //13 Importe Original 
                            sql.AppendFormat(" " + "'" + "{0}" + "'" + ")" + "\n", '0');               //14 Importe Con Descuento

                            db2Comm.CommandText = sql.ToString();
                            db2Comm.ExecuteNonQuery();

                            mensaje = "Se guardo el registro exitosamente...";
                            //return mensaje;
                        }
                        catch {  }
                    }

                    db2Reader.Close();
                }
                catch  { }
                //finally
                //{
                //    if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                //        db2Conn.Close();
                //}               
            }

        }

        public static DataTable ObtenDetalleXrebajar(string ParFchBon, string ParProveedor, string PartbEstilo, string ParUsuario)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtDetalleXrebajar = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R76 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParProveedor.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", PartbEstilo.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParUsuario.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParFchBon.PadLeft(6, '0'));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT * \n");
                sql.Append("FROM MMSATOBJ.SAT177F77  \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtDetalleXrebajar = new DataTable("DetalleXrebajar");
                dtDetalleXrebajar.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtDetalleXrebajar;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable GuardaNota(string ParFchBon, string ParFchRev, string ParProveedor, string ParEstilo, string ParNotCal, string ParUsuario, string ParSubTot, string ParPorc, string varInd1, string varInd2, string TpoMov, string TpoCal, string RutaPdf)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtGuardaNota = null;

            if (RutaPdf == null)
            {
                RutaPdf = "";
            }

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R23 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchBon.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchRev.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParProveedor.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParEstilo.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParNotCal.PadRight(20, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParSubTot.PadLeft(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParUsuario.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParPorc.PadRight(9, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", varInd1.PadRight(1, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", varInd2.PadRight(1, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", TpoMov.PadLeft(3, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", TpoCal.PadLeft(3, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", RutaPdf.PadRight(100, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177F23 FETCH FIRST 1 ROWS ONLY\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtGuardaNota = new DataTable("CalculosNota");
                dtGuardaNota.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtGuardaNota;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable GuardaNotaDiferenciada(string ParFchBon, string ParFchRev, string ParTipo, string ParTemporada, string ParTienda, string ParProveedor, string ParEstilo, string ParNotCal, string ParUsuario, string ParSubTot, string ParPorc, string varInd1, string varInd2, string TpoMov, string TpoCal, string RutaPdf)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtGuardaNota = null;

            if (RutaPdf == null)
            {
                RutaPdf = "";
            }

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                DataTable dtExist = null;
                string mensaje = string.Empty;

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("RBDFBO,  \n");  //00 Fecha
                sql.Append("RBDPRV,  \n");  //01 Proveedor
                sql.Append("RBDSTY,  \n");  //02 Estilo
                sql.Append("RBDSTR   \n");  //03 Tienda

                sql.Append("FROM " + LibSatObj + ".SAT177F25Z \n");
                sql.AppendFormat(" WHERE \n");
                sql.AppendFormat("     RBDFBO = " + "'" + "{0}" + "'" + "\n", ParFchBon.PadLeft(6, '0'));
                sql.AppendFormat(" and RBDPRV = " + "'" + "{0}" + "'" + "\n", ParProveedor.PadLeft(6, '0'));
                sql.AppendFormat(" and RBDSTY = " + "'" + "{0}" + "'" + "\n", ParEstilo.PadRight(15, ' '));
                sql.AppendFormat(" and RBDSTR = " + "'" + "{0}" + "'" + "\n", ParTienda.PadLeft(5, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader1 = db2Comm.ExecuteReader();
                dtExist = new DataTable("ValidaSiExiste");
                dtExist.Load(db2Reader1);

                if (dtExist.Rows.Count > 0)
                {
                    mensaje = "El Registro ya existe...";
                }
                else
                {
                    sql.Clear();
                    sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");
                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    // Agregar Rebaja de Precios
                    sql.Clear();
                    sql.Append("CALL " + LibSatPgm + ".SAT177R233 (\n");
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchBon.PadLeft(6, '0'));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchRev.PadLeft(6, '0'));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParTipo.PadRight(15, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParTemporada.PadRight(3, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParTienda.PadLeft(5, '0'));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParProveedor.PadLeft(6, '0'));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParEstilo.PadRight(15, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParNotCal.PadRight(20, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParSubTot.PadLeft(15, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParUsuario.PadRight(10, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParPorc.PadRight(9, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", varInd1.PadRight(1, '0'));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", varInd2.PadRight(1, '0'));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", TpoMov.PadLeft(3, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", TpoCal.PadLeft(3, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", RutaPdf.PadRight(100, ' '));
                    sql.Append(")");

                    if (ParPorc != "00000")
                    {
                        db2Comm.CommandText = sql.ToString();
                        db2Comm.ExecuteNonQuery();
                    }
                }
                sql.Clear();
                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177F23 FETCH FIRST 1 ROWS ONLY\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtGuardaNota = new DataTable("CalculosNota");
                dtGuardaNota.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtGuardaNota;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable GuardaNotaAnt(string ParFchBon, string ParFchRev, string ParProveedor, string ParEstilo, string ParNotCal, string ParUsuario, string ParSubTot, string ParPorc, string varInd1, string varInd2, string TpoMov, string ParFechaRcb, string ParBodega, string ParOrden, string ParPzas, string TpoCal)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtGuardaNota = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R231 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchBon.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchRev.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParProveedor.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParEstilo.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParNotCal.PadRight(20, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParSubTot.PadLeft(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParPorc.PadRight(9, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParUsuario.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", varInd1.PadRight(1, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", varInd2.PadRight(1, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFechaRcb.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParBodega.PadLeft(5, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParOrden.PadLeft(10, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParPzas.PadLeft(9, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", TpoMov.PadLeft(3, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", TpoCal.PadLeft(3, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177F231 FETCH FIRST 1 ROWS ONLY\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtGuardaNota = new DataTable("CalculosNota");
                dtGuardaNota.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtGuardaNota;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenEstilo(string ParPrv, string ParSty)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtEstilo = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                //  sql.Append("CALL MMSATPGM.SAT177R22 (\n");
                //  sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchBon.PadLeft(6, '0'));
                //  sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchRev.PadLeft(6, '0'));
                //  sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParProveedor.PadLeft(6, '0'));
                //  sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParEstilo.PadRight(15, ' '));
                //  sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParNotCal.PadRight(20, ' '));
                //  sql.AppendFormat("'" + "{0}" + "'" + "\n", ParUsuario.PadRight(10, ' '));
                //  sql.Append(")");

                //  db2Comm.CommandText = sql.ToString();
                //  db2Comm.ExecuteNonQuery();

                //  sql.Clear();

                sql.Append("SELECT SASNUM , ASNAME, SSTYLQ, SSTYLE FROM " + Lib610Lib + ".INSMST, " + Lib610Lib + ".APSUPP \n");
                sql.AppendFormat(" WHERE SASNUM = ASNUM AND SASNUM = " + "'" + "{0}" + "'" + "\n", ParPrv.PadLeft(6, '0'));
                sql.AppendFormat(" AND SSTYLQ = " + "'" + "{0}" + "'" + "\n", ParSty.PadRight(15, ' '));
                //  sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtEstilo = new DataTable("Estilo");
                dtEstilo.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtEstilo;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return dtEstilo;
        }

        public static DataTable ObtenPrcCst(string ParPrv, string ParSty)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtPrcCst = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT CST, PRC FROM " + LibSatObj + ".GAT027F  \n");
                sql.AppendFormat(" WHERE PRV  = " + "'" + "{0}" + "'" + "\n", ParPrv.PadLeft(6, '0'));
                sql.AppendFormat(" AND STL = " + "'" + "{0}" + "'" + "\n", ParSty.PadRight(15, ' '));


                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtPrcCst = new DataTable("Precio Costo");
                dtPrcCst.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtPrcCst;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return dtPrcCst;
        }

        public static DataTable ObtenRecibos(string ParPrv, string ParSty)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtRecibos = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT RCBDAT, RCBLOC, RCBNUM, sum(RCBREC) FROM " + LibSatObj + ".SAT103L3  \n");
                sql.AppendFormat(" WHERE RCBVND  = " + "'" + "{0}" + "'" + "\n", ParPrv.PadLeft(6, '0'));
                sql.AppendFormat(" AND RCBSTY = " + "'" + "{0}" + "'" + "\n", ParSty.PadRight(15, ' '));
                sql.Append(" GROUP BY RCBDAT, RCBLOC, RCBNUM \n");
                sql.Append(" ORDER BY RCBDAT DESC \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtRecibos = new DataTable("Recibos");
                dtRecibos.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtRecibos;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return dtRecibos;
        }

        public static void EjecutaCorreos(string ParFchBon, string ParFchEfe, string ParUser)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R29 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchBon.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchEfe.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParUser.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

        }

        public static void EjecutaCorreosDev(string ParFchBon, string ParFchEfe, string ParUser)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R29D (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchBon.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchEfe.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParUser.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

        }

        public static void EjecutaCorreosDiferenciados(string ParFchBon, string ParFchEfe, string ParUser)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R29F (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchBon.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchEfe.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParUser.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

        }

        public static DataTable ObtenCorreos(string ParFchBon, string ParFchEfe, string ParMarca, string ParUser)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtCorreos = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177F29  \n");
                sql.AppendFormat(" WHERE ENVMAR  = " + "'" + "{0}" + "'" + "\n", ParMarca.PadLeft(3, '0'));
                sql.Append(" ORDER BY ENVPRV, ENVSTY \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtCorreos = new DataTable("Correos");
                dtCorreos.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtCorreos;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return dtCorreos;
        }

        public static DataTable ObtenCorreosDev(string ParFchBon, string ParMarca, string ParUser)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtCorreos = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177F29D  \n");
                sql.AppendFormat(" WHERE ENVMAR  = " + "'" + "{0}" + "'" + "\n", ParMarca.PadLeft(3, '0'));
                sql.Append(" ORDER BY ENVPRV, ENVSTY \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtCorreos = new DataTable("Correos");
                dtCorreos.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtCorreos;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return dtCorreos;
        }

        public static DataTable ObtenCorreosDiferenciados(string ParFchBon, string ParFchEfe, string ParMarca, string ParUser)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtCorreos = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177F29F  \n");
                sql.AppendFormat(" WHERE ENVMAR  = " + "'" + "{0}" + "'" + "\n", ParMarca.PadLeft(3, '0'));
                sql.Append(" ORDER BY ENVMAR, ENVSTR, ENVPRV, ENVSTY \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtCorreos = new DataTable("Correos");
                dtCorreos.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtCorreos;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return dtCorreos;
        }

        public static DataTable ObtenDestino(string ParMarcaDes)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtDestino = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177F17  \n");
                sql.AppendFormat(" WHERE LSTLST  = " + "'" + "{0}" + "'" + "\n", ParMarcaDes.PadRight(20, ' '));
                sql.Append(" ORDER BY LSTLST, LSTNOM \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtDestino = new DataTable("Correos");
                dtDestino.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtDestino;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return dtDestino;
        }

        public static DataTable ObtenDestinoDev(string ParMarcaDes)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtDestino = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177F17  \n");
                sql.AppendFormat(" WHERE LSTLST  = " + "'" + "{0}" + "'" + "\n", ParMarcaDes.PadRight(20, ' '));
                sql.Append(" ORDER BY LSTLST, LSTNOM \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtDestino = new DataTable("Correos");
                dtDestino.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtDestino;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return dtDestino;
        }

        public static DataTable ObtenDestinoDiferenciados(string ParMarcaDes)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtDestino = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177F17F  \n");
                sql.AppendFormat(" WHERE LSTLST  = " + "'" + "{0}" + "'" + "\n", ParMarcaDes.PadRight(20, ' '));
                sql.Append(" ORDER BY LSTLST, LSTNOM \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtDestino = new DataTable("Correos");
                dtDestino.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtDestino;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return dtDestino;
        }

        public static string ObtenMarcaConfiguracion(string ParMarca)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtMarcaNumero = null;
            string stFechaAbierta = "";

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT MARFAB FROM " + LibSatObj + ".SAT177SMAR  \n");
                sql.AppendFormat(" WHERE MARMAR  = " + "'" + "{0}" + "'" + "\n", ParMarca.PadLeft(3, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtMarcaNumero = new DataTable("Correos");
                dtMarcaNumero.Load(db2Reader);
                db2Reader.Close();

                if (dtMarcaNumero.Rows.Count > 0)
                {
                    foreach (DataRow row in dtMarcaNumero.Rows)
                    {
                        stFechaAbierta = string.Format("{0}", double.Parse(row["MARFAB"].ToString()));
                    }
                }

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return stFechaAbierta;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return stFechaAbierta;
        }

        public static string ObtenVecesAreprogramarConfiguracion(string ParMarca)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtMarcaNumero = null;
            string stVecesAreprogramar = "";

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT MARVEZ FROM " + LibSatObj + ".SAT177SMAR  \n");
                sql.AppendFormat(" WHERE MARMAR  = " + "'" + "{0}" + "'" + "\n", ParMarca.PadLeft(3, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtMarcaNumero = new DataTable("Correos");
                dtMarcaNumero.Load(db2Reader);
                db2Reader.Close();

                if (dtMarcaNumero.Rows.Count > 0)
                {
                    foreach (DataRow row in dtMarcaNumero.Rows)
                    {
                        stVecesAreprogramar = string.Format("{0}", double.Parse(row["MARVEZ"].ToString()));
                    }
                }

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return stVecesAreprogramar;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return stVecesAreprogramar;
        }

        public static string ObtenOnHandTransito(string ParPrv, string ParSty, out string stOnHand, out string stTransito)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtOnhandTransito = null;
            string stOnHandTransito = "";
            stOnHand = "On Hand";
            stTransito = "Transito";

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT CSHAND + CSINTQ, CSHAND, CSINTQ FROM " + Lib610Lib + ".INSCBL \n");
                sql.AppendFormat(" WHERE IASNUM  = " + "'" + "{0}" + "'" + "\n", ParPrv.PadLeft(6, '0'));
                sql.AppendFormat(" and   ISTYLN  = " + "'" + "{0}" + "'" + "\n", ParSty.PadRight(15, ' '));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtOnhandTransito = new DataTable("OnHandTransito");
                dtOnhandTransito.Load(db2Reader);
                db2Reader.Close();

                if (dtOnhandTransito.Rows.Count > 0)
                {
                    foreach (DataRow row in dtOnhandTransito.Rows)
                    {
                        stOnHandTransito = string.Format("{0}", double.Parse(row[0].ToString()));
                        stOnHand = string.Format("{0}", double.Parse(row[1].ToString()));
                        stTransito = string.Format("{0}", double.Parse(row[2].ToString()));
                    }
                }

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return stOnHandTransito;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return stOnHandTransito;
        }

        /// <summary>
        /// Recupera el parametro solicitado para aplicar las reglas del negocio
        /// </summary>
        /// <param name="Dato">Información requerida</param>
        /// <param name="Cadena">Marca de la que se requiere</param>
        /// <returns>Valor recuperado de MMSATOBJ.SAT177SMAR</returns>
        /// <remarks>Desarrollador: OCG | 15/12/2016</remarks>
        public static string ObtenerConfiguracion(Comun.Engine.Paremetrizacion Dato, int Cadena)
        {
            StringBuilder sql = new StringBuilder();
            string dato = "";

            sql.Append(" SELECT ");

            switch (Dato)
            {
                case Comun.Engine.Paremetrizacion.Reprogramaciones:
                    sql.AppendFormat(" MARVEZ ");
                    break;

                case Comun.Engine.Paremetrizacion.Semanas:
                    sql.AppendFormat(" MARSAR ");
                    break;
            }

            sql.AppendFormat(" FROM MMSATOBJ.SAT177SMAR WHERE MARMID = {0} ", Cadena);

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                OleDbDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    dato = reader[0].ToString();
                }

                reader.Close();
            }

            return dato;
        }

        public static bool GuardaNotaCredito(int marca, string noMarca, int noEvento, string ordenCompra, string temporada, string ParFchBon, string ParFchRev, string ParProveedor, string ParEstilo, string ParNotCal, string ParUsuario,string comprador)
        {
            string cadenaConexionDb2 = Db2_Prod;
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("es-MX");

            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            bool continua = false;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                string[] Fechas = DateTime.Now.GetDateTimeFormats();

                int Fecha400 = Convert.ToInt32(Fechas[6].Replace("-", "").Substring(2, 6));

                sql.Clear();
                sql.Append("INSERT INTO MMNETLIB.SAT177NTC\n");
                sql.Append("(NTCPRV,NTCSTY,NTCORC,NTCDCP,NTCNTAC,NTCNMR,NTCMAR,NTCNEV,NTCTEMP,NTCFRE,NTCBON,NTCFEA,NTCUSR, NTCEST) \n");
               sql.AppendFormat("VALUES('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}','{11}','{12}','T')\n",
                   ParProveedor.PadLeft(6, '0'), ParEstilo.PadRight(15, ' '), ordenCompra, comprador, ParNotCal.PadRight(20, ' '),
                    marca, noMarca, noEvento, temporada, ParFchRev.PadLeft(6, '0'), ParFchBon.PadLeft(6, '0'), Fecha400, ParUsuario.PadRight(10, ' ')
                   );

               db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                continua = true;

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return continua;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenInfoEstilo(int pProveedor, string pEstilo)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            DataTable dtInfoEstilo = null;
            db2Conn = new OleDbConnection(cadenaConexionDb2);
            db2Conn.Open();
            OleDbCommand db2Comm = db2Conn.CreateCommand();
            try
            {
                sql.Clear();
                sql.Append("SELECT SASNUM, ASNAME, SSTYLQ, SSTYLE, SSEASN, UPPER(SEADSC) SEADSC, CSTINI, CST, PRCINI, PRC,\n");
                sql.Append("       CSHAND, CBWKCR, CBWK01, CBWK02, CBWK03, CBWK04, CBWK05, CBWK06, CBWK07, CBWK08, SATRB5, CSINTQ\n");
                sql.Append("  FROM MM610LIB.INSMST MST\n");
                sql.Append(" INNER JOIN MM610LIB.APSUPP UPP ON UPP.ASNUM = MST.SASNUM\n");
                sql.Append("  LEFT JOIN MMSATOBJ.GAT027F GAT ON GAT.PRV = MST.SASNUM\n");
                sql.Append("                                AND GAT.STL = MST.SSTYLQ\n");
                sql.Append("  LEFT JOIN MM610LIB.TBLSEA SEA ON SEA.SEANUM = MST.SSEASN\n");
                sql.Append("  LEFT JOIN MM610LIB.INSCBL CBL ON CBL.IASNUM = MST.SASNUM\n");
                sql.Append("                               AND CBL.ISTYLN = MST.SSTYLQ \n");
                sql.AppendFormat(" WHERE SASNUM = {0}\n", pProveedor);
                sql.AppendFormat("   AND SSTYLQ = '{0}'\n", pEstilo);

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtInfoEstilo = new DataTable("Calculos");
                dtInfoEstilo.Load(db2Reader);
                db2Reader.Close();

                return dtInfoEstilo;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenFechasRebajas(int pProveedor, string pEstilo)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            DataTable dtInfoFechasRebajas = null;
            db2Conn = new OleDbConnection(cadenaConexionDb2);
            db2Conn.Open();
            OleDbCommand db2Comm = db2Conn.CreateCommand();
            try
            {
                sql.Clear();
                sql.Append("SELECT PLNCDT,PLNAMT,PLNEVT,PLNLVL,PLNSTR,PLNITM\n");
                sql.Append("  FROM MM610LIB.PRCPLN	\n");
                sql.AppendFormat(" WHERE PLNVND = {0}\n", pProveedor);
                sql.AppendFormat("   AND PLNSTY = '{0}'\n", pEstilo);
                sql.AppendFormat(" AND PLNTYP <> 99 \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtInfoFechasRebajas = new DataTable("FechasRebajas");
                dtInfoFechasRebajas.Load(db2Reader);
                db2Reader.Close();

                return dtInfoFechasRebajas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenPosDistro(int pMarca, int pProveedor, string pEstilo)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            DataTable dtPosDistro = null;
            db2Conn = new OleDbConnection(cadenaConexionDb2);
            db2Conn.Open();
            OleDbCommand db2Comm = db2Conn.CreateCommand();
            try
            {
                sql.Clear();
                sql.Append("SELECT MARCA,NUMPROV ,NUMESTILO ,PIEZAS \n");
                sql.Append("  FROM MMNETLIB.SAT177POSD	\n");
                sql.AppendFormat(" WHERE MARCA     = {0}\n",   pMarca);
                sql.AppendFormat("   AND NUMPROV   = {0}\n",   pProveedor);
                sql.AppendFormat("   AND NUMESTILO = '{0}'\n", pEstilo);

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtPosDistro = new DataTable("PosDistro");
                dtPosDistro.Load(db2Reader);
                db2Reader.Close();

                return dtPosDistro;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
