﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Configuracion
{
    public class Configuracion
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static DataTable ObtenConfiguracion()
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConfiguracion = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT MARMID, MARDES, MARMAR, MARDAS, MARSAR, MARFAB, MARPNT, \n");
                sql.Append("  MARPLC, MARPRE, MARVEZ, MARSTS, MARULH, MARULF FROM " + LibSatObj + ".sat177smar       \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtConfiguracion = new DataTable("Configuracion");
                dtConfiguracion.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtConfiguracion;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable UpdateConfiguracion(DataTable dtConfiguracion)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                foreach (DataRow row in dtConfiguracion.Rows)
                {
                    string marca = row["MarcaT"].ToString();
                    string descripcion = row["Descripcion"].ToString();
                    string marcaN = row["MarcaN"].ToString();
                    string diasxO = row["DiasxO"].ToString();
                    string semAReprog = row["SemAReprog"].ToString();
                    string fechaAbierta = row["FechaAbierta"].ToString();
                    string porNtaCred = row["PorNtaCred"].ToString();
                    string vezAReprog = row["VezAReprog"].ToString();
                    string estatus = row["Estatus"].ToString();
                    string fecha = row["Fecha"].ToString();
                    string hora = row["Hora"].ToString();

                    string cali = row["Calificacion"].ToString();
                    string margPre = row["MargenPrecio"].ToString();
                   // string redMul = row["RedondeoMult"].ToString();

                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT177SMAR SET \n");
                    sql.AppendFormat("MARMID = " + "'" + "{0}" + "'" + "," + "\n", marca.PadRight(10, ' '));
                    sql.AppendFormat("MARDES = " + "'" + "{0}" + "'" + "," + "\n", descripcion.PadRight(10, ' '));
                    sql.AppendFormat("MARMAR = " + "'" + "{0}" + "'" + "," + "\n", marcaN.PadLeft(3, '0'));
                    sql.AppendFormat("MARDAS = " + "'" + "{0}" + "'" + "," + "\n", diasxO.PadLeft(5, '0'));
                    sql.AppendFormat("MARVEZ = " + "'" + "{0}" + "'" + "," + "\n", vezAReprog.PadLeft(5, '0'));
                    sql.AppendFormat("MARSAR = " + "'" + "{0}" + "'" + "," + "\n", semAReprog.PadLeft(5, '0'));
                    sql.AppendFormat("MARULF = " + "'" + "{0}" + "'" + "," + "\n", fecha.PadLeft(6, '0'));
                    sql.AppendFormat("MARULH = " + "'" + "{0}" + "'" + "," + "\n", hora.PadLeft(6, '0'));
                    sql.AppendFormat("MARSTS = " + "'" + "{0}" + "'" + "," + "\n", estatus.PadLeft(1, ' '));
                    sql.AppendFormat("MARFAB = " + "'" + "{0}" + "'" + "," + "\n", fechaAbierta.PadLeft(6, '0'));
                    sql.AppendFormat("MARPNT = " + "'" + "{0}" + "'" + "," + "\n", porNtaCred.PadLeft(9, '0'));
                    sql.AppendFormat("MARPLC = '{0}', \n", cali);
                    sql.AppendFormat("MARPRE = '{0}' \n", margPre);
                    		
                    sql.Append("WHERE \n");
                    sql.AppendFormat("MARMAR = " + "'" + "{0}" + "'" + "\n", marcaN.PadLeft(3, '0'));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();
                }
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtConfiguracion;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void EliminadtConfiguracion(string marcaB)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("DELETE FROM " + LibSatObj + ".SAT177SMAR WHERE\n");
                sql.Append(" MARMAR = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", marcaB);

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch
            {    }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
