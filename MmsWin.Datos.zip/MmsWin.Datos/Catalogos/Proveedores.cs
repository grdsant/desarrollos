﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;

namespace MmsWin.Datos.Catalogos
{
    public class Proveedores
    {

        #region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
        #endregion

        public static DataTable ObtenProveedores(string proveedor, string nombre, string usuario)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            DataTable dtProveedores = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT   \n");

                sql.Append("ASNUM, \n");  //00 Proveedor 
                sql.Append("ASNAME, \n");  //01 Nombre
                sql.Append("ASDTIN \n");  //01 Fecha

                sql.Append("FROM " + Lib610Lib + ".APSUPP \n");

                sql.AppendFormat(" WHERE ASNUM >= 0" + "\n");

                if (proveedor != "") { sql.AppendFormat(" and ASNUM = "  + "'"  + "{0}" + "'"  + "\n", proveedor); }
                if (nombre != "") { sql.AppendFormat(" and ASNAME like " + "'%" + "{0}" + "%'" + "\n", nombre); }

                sql.Append(" ORDER BY ASNUM, ASNAME  DESC \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtProveedores = new DataTable("Proveedores");
                dtProveedores.Load(db2Reader);


                if (dtProveedores.Rows.Count == 0)
                {
                    DataRow row = dtProveedores.NewRow();
                    row["ASNUM"] = "0";
                    row["ASNAME"] = "No se encontraron Registros.";
                    row["ASDTIN"] = "0";
                    dtProveedores.Rows.Add(row);
                }

                db2Reader.Close();

                return dtProveedores;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
