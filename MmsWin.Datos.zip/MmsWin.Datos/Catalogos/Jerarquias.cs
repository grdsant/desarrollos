﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Catalogos
{
    public class Jerarquias
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static string EliminaJerarquias(DataTable dtJerarquias)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                foreach (DataRow row in dtJerarquias.Rows)
                {
                    string marca = row["marca"].ToString();
                    string grupo = row["grupo"].ToString();
                    string renglon = row["renglon"].ToString();
                    string secuencia = row["secuencia"].ToString();
                    mensaje = "Ocurrio un problema al tratar de eliminar el registro";
                    sql.Clear();
                    sql.Append("Delete " + LibSatObj + ".SAT177F72 \n");
                    sql.Append("where " + "\n");
                    sql.Append(" GTPMAR = \n");
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", marca);
                    sql.Append(" AND GTPGPO = \n");
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", grupo);
                    sql.Append(" AND GTPREN = \n");
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", renglon);
                    sql.Append(" AND GTPSEC = \n");
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", secuencia);

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Se eliminó correctamente.";
                }

                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

        }

    }
}
