﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Catalogos
{
    public class TemporadasMms
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static Dictionary<string, string> ObtenTemporadasMms()
        {
            string cadenaConexionDb2 = Db2_Prod;

            DataTable dtGrupos = null;
            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            Dictionary<string, string> diTemporadas = new Dictionary<string , string>();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                OleDbCommand db2Comm2 = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT SEANUM, SEADSC FROM " + Lib610Lib + ".TBLSEA\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                if (db2Reader.Read())
                {
                    db2Reader.Close();
                }
                db2Reader = db2Comm.ExecuteReader();
                diTemporadas.Add("999", "Todos");
                while (db2Reader.Read())
                {
                    diTemporadas.Add(db2Reader.GetString(0), db2Reader.GetString(1));
                }
        
                sql.Clear();
                sql.Append("SELECT COMTPP, COMDES FROM " + LibSatObj + ".SAT177F71\n");

                db2Comm2.CommandText = sql.ToString();
                OleDbDataReader db2Reader2 = db2Comm2.ExecuteReader();
                if (db2Reader2.Read())
                {
                    db2Reader2.Close();
                }
                db2Reader2 = db2Comm2.ExecuteReader();

                dtGrupos = new DataTable("Grupos");
                dtGrupos.Load(db2Reader2);
                db2Reader2.Close();

                foreach (DataRow row in dtGrupos.Rows)
                {
                    string idTmp = row["COMTPP"].ToString();
                    string tmpDes = row["COMDES"].ToString();
                    diTemporadas.Add(idTmp, idTmp + ' ' + tmpDes);
                }

                db2Reader2.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return diTemporadas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

        }

        public static DataTable ObtenTemporadasMmsSEA(string temporada, string descripcion)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection  db2Conn = null;
            StringBuilder        sql = new StringBuilder();
            DataTable   dtTemporadas = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("SEANUM,  \n");  //00 Season Code  
                sql.Append("SEADSC  \n");  //01 Season Description
                sql.Append("FROM " + Lib610Lib + ".TBLSEA \n");

                sql.AppendFormat(" WHERE SEANUM !=" + "'" + " " + "'" + "\n");

                if (temporada != "") { sql.AppendFormat(" and SEANUM like " + "'%" + "{0}" + "%'" + "\n", temporada); }
                if (descripcion != "") { sql.AppendFormat(" and SEADSC like " + "'%" + "{0}" + "%'" + "\n", descripcion); }

                sql.Append(" ORDER BY SEANUM DESC \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtTemporadas = new DataTable("Temporadas");
                dtTemporadas.Load(db2Reader);
                db2Reader.Close();

                return dtTemporadas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
