﻿using System;
using System.Configuration;
using System.Data;
using System.Data.OleDb;

namespace MmsWin.Datos.Catalogos
{
    /// <summary>
    /// Opciones para el manejo del catálogo de Motivos
    /// </summary>
    /// <remarks>PROGRMADOR: OCG 01/12/2016</remarks>
    public class Motivos
    {
        #region Conexion

        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();

        #endregion

        /// <summary>
        /// Cargo los Motivos de Ampliación de calificación de AS/400 DB2
        /// </summary>
        /// <returns>DataTable de toda la tabla</returns>
        /// <remarks>PROGRMADOR: OCG 01/12/2016</remarks>
        /// 
        public static DataTable CargaMotivos()
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();

            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand("SELECT MOVOID, DSCMOV FROM MMNETLIB.SAT179F5", db2Conn);
                cmdDb2.CommandType = CommandType.Text;
                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);
                daDb2.Fill(dtMotivos);

                return dtMotivos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        #region "devolucion en sustitucion de una bonificacion "
        public static DataTable CargaMotivosDSB()
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();

            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand("SELECT AOMOTIV AS MOVOID, AODESCR AS DSCMOV FROM MMNETLIB.SAT177F42 WHERE AOCUCVE = 'DSB' AND AOESTAT = 'A'", db2Conn);
                cmdDb2.CommandType = CommandType.Text;


                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtMotivos);

                return dtMotivos;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion
    }
}

