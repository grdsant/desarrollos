﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Catalogos
{
    public class Temporada
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static DataTable ObtenTemporada()
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT distinct TMPIDT, TMPTEM FROM " + LibSatObj + ".SAT177F46\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                if (db2Reader.Read())
                {
                    db2Reader.Close();
                }

                db2Reader = db2Comm.ExecuteReader();

                System.Data.DataTable dtTemporada = new System.Data.DataTable("Temporada");
                dtTemporada.Columns.Add("Des", typeof(String));
                dtTemporada.Columns.Add("Id", typeof(int));

                DataRow workRow = dtTemporada.NewRow();
                workRow["Des"] = "Todas";
                workRow["Id"] = 999;

                dtTemporada.Rows.Add(workRow);

                while (db2Reader.Read())
                {
                    workRow = dtTemporada.NewRow();
                   
                    workRow["Des"] = db2Reader.GetString(1);
                    workRow["Id"] = db2Reader.GetValue(0);

                    dtTemporada.Rows.Add(workRow);
                }
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtTemporada;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

        }

            }
}
