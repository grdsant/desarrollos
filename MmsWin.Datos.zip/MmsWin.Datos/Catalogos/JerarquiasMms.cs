﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Catalogos
{
    public class JerarquiasMms
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static DataTable ObtenJerarquiasMms(string dp, string sd, string cl, string sc, string dpd, string sdd, string cld, string scd)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection  db2Conn = null;
            StringBuilder        sql = new StringBuilder();
            DataTable   dtJerarquias = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("JERDP,  \n");   //00 Departamento 
                sql.Append("JERSD,  \n");    //01 Sub Departamento
                sql.Append("JERCL,  \n");   //02 Clase  
                sql.Append("JERSC,  \n");    //03 Sub clase
                sql.Append("JERDPD,  \n");  //04 Des Departamento  
                sql.Append("JERSDD,  \n");   //05 Des Sub Departamento
                sql.Append("JERCLD,  \n");  //06 Des Clase
                sql.Append("JERSCD,  \n");   //07 Des Sub clase
                sql.Append("JERSTS,  \n");  //08 Estatus
                sql.Append("JERUAL,  \n");   //09 Usuario
                sql.Append("JERFAL,  \n");   //10 Fecha
                sql.Append("JERHAL  \n");   //11 Hora

                sql.Append("FROM " + LibSatObj + ".SAT177F79 \n");

                sql.AppendFormat(" WHERE JERDP >= 0" + "\n");

                if (dp  != "") { sql.AppendFormat(" and JERDP = " + "'" + "{0}" + "'" + "\n", dp); }
                if (sd  != "") { sql.AppendFormat(" and JERSD = " + "'" + "{0}" + "'" + "\n", sd); }
                if (cl  != "") { sql.AppendFormat(" and JERCL = " + "'" + "{0}" + "'" + "\n", cl); }
                if (sc  != "") { sql.AppendFormat(" and JERSC = " + "'" + "{0}" + "'" + "\n", sc); }
                if (dpd != "") { sql.AppendFormat(" and JERDPD like " + "'%" + "{0}" + "%'" + "\n", dpd); }
                if (sdd != "") { sql.AppendFormat(" and JERSDD like " + "'%" + "{0}" + "%'" + "\n", sdd); }
                if (cld != "") { sql.AppendFormat(" and JERCLD like " + "'%" + "{0}" + "%'" + "\n", cld); }
                if (scd != "") { sql.AppendFormat(" and JERSCD like " + "'%" + "{0}" + "%'" + "\n", scd); }

                sql.Append(" ORDER BY JERDP, JERSD, JERCL, JERSC DESC \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtJerarquias = new DataTable("Jerarquias");
                dtJerarquias.Load(db2Reader);
                if (dtJerarquias.Rows.Count == 0)
                {
                    #region Registro Total
                    DataRow row = dtJerarquias.NewRow();
                    row["JERDP"] = "0";
                    row["JERSD"] = "0";
                    row["JERCL"] = "0";
                    row["JERSC"] = "0";
                    row["JERDPD"]  = "No se encontraron Regist.";
                    row["JERSDD"] = " ";
                    row["JERCLD"] = " ";
                    row["JERSCD"] = " ";
                    row["JERSTS"] = " ";
                    row["JERUAL"] = " ";
                    row["JERFAL"] = "0";
                    row["JERHAL"] = "0";
                    dtJerarquias.Rows.Add(row);
                    #endregion
                }
                db2Reader.Close();

                return dtJerarquias;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

    }
}
