/*
 * Nombre: 
 * Descripción: Scripts de Ulises para las OC
 * Desarrollador: Omar Cervantes G.
 * Fecha:20/02/2017
 *  */

SELECT DISTINCT P.ponumb , POSTAT, POCDAT, POSVND, POSTYL, IDEPT, ISDEPT, ICLAS, ISCLAS , sum(pomcst * pomqty) as costo,
   CASE 
WHEN p.postor = 914  THEN 30 
WHEN p.postor = 4 THEN 30 
WHEN p.postor = 6 THEN 30 
WHEN p.postor = 915   THEN 10
WHEN p.postor = 3   THEN 10
WHEN p.postor = 5   THEN 10 
WHEN p.postor = 7   THEN 60 
WHEN p.postor = 917   THEN 60 
ELSE p.postor END AS marca
from mm610lib.pomhdr P
LEFT JOIN mm610lib.POMDTL D ON P.PONUMB = D.PONUMB
where postat in ('3','9') 
and pocdat >= 161101  and pocdat <= 161130
group by P.ponumb , POSTAT, POCDAT, POSVND, POSTYL, 
IDEPT, ISDEPT, ICLAS, ISCLAS,P.postor


ENTREGADOS

SELECT  DISTINCT P.ponumb , POSVND, POSTYL, p.pordat, IDEPT, ISDEPT, ICLAS,ISCLAS, sum(pomcst * pomqty) Costo ,
CASE 
WHEN p.POLOC = 914  THEN 30 
WHEN p.POLOC = 4 THEN 30 
WHEN p.POLOC = 6 THEN 30 
WHEN p.POLOC = 915   THEN 10
WHEN p.POLOC = 3   THEN 10
WHEN p.POLOC = 5   THEN 10 
WHEN p.POLOC = 7   THEN 60 
WHEN p.POLOC = 917   THEN 60 
ELSE 0 END AS marca
  from mm610lib.pomrch    P
JOIN mm610lib.pomrcd  D ON P.PONUMB = D.PONUMB
JOIN MM610LIB.INVMST I ON D.INUMBR= I.INUMBR
where p.pordat >= 161101 and p.pordat <=161130 and p.POLOC in (914,4,6,3,5,915,7,917)
group by P.ponumb , POSVND, POSTYL, p.pordat, IDEPT, ISDEPT, ICLAS,ISCLAS,p.POLOC
