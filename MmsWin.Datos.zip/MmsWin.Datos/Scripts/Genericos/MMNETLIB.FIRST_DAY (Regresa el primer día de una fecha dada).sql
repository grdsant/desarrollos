
/*
 * Nombre: FIRST_DAY
 * Descripci�n: Regresa una fecha en formato ingles tipo texto a partir de una fecha AS400
 * Desarrollador: Omar Cervantes G.
 * Fecha:20/02/2017
 *  */
CREATE OR REPLACE FUNCTION MMNETLIB.FIRST_DAY(arg DATE) RETURNS DATE
  NO EXTERNAL ACTION CONTAINS SQL NOT DETERMINISTIC
  RETURN arg + (DAY(arg)  + 1) DAYS;

--VALUES MMNETLIB.FIRST_DAY(CURRENT DATE);
