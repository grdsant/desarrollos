/*
 * Nombre: 
 * Descripción: Regresa la fecha establecida para iniciar la búsqueda de las O.C. de Fill Rate
 * Desarrollador: Omar Cervantes G.
 * Fecha:20/02/2017
 *  */
--Regresa la fecha establecida para iniciar la búsqueda de las O.C. de Fill Rate
   CREATE OR REPLACE FUNCTION  MMNETLIB.FORMATFECH(PARAM NUMERIC(6,0))
     RETURNS VARCHAR(10)
     LANGUAGE SQL
     --READS SQL DATA
     NO EXTERNAL ACTION
     NOT DETERMINISTIC
     RETURN(
     	SUBSTRING(CHAR(FORMATFECH.PARAM), 5, 2) || '/'|| SUBSTRING(CHAR(FORMATFECH.PARAM),3, 2) || '/' || '20' || SUBSTRING(CHAR(FORMATFECH.PARAM),1, 2) 
     )
     
     
--DROP FUNCTION  MMNETLIB.FORMATFECH
--GRANT ALL ON FUNCTION MMNETLIB.FORMATFECH TO PGMCGC,PGMGSR,PUBLIC WITH GRANT OPTION;

