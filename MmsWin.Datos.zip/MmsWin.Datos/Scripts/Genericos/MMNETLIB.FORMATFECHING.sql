/*
 * Nombre: 
 * Descripción: Regresa la fecha establecida para iniciar la búsqueda de las O.C. de Fill Rate
 * Desarrollador: Omar Cervantes G.
 * Fecha:20/02/2017
 *  */
   CREATE OR REPLACE FUNCTION  MMNETLIB.FORMATFECHING(PARAM NUMERIC(6,0))
     RETURNS VARCHAR(10)
     LANGUAGE SQL
     --READS SQL DATA
     NO EXTERNAL ACTION
     NOT DETERMINISTIC
     RETURN(
     	'20' || SUBSTRING(CHAR(FORMATFECHING.PARAM), 1, 2) || '-'|| SUBSTRING(CHAR(FORMATFECHING.PARAM),3, 2) || '-'  || SUBSTRING(CHAR(FORMATFECHING.PARAM),5, 2)     	
     )
     


