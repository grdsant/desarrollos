﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;

namespace MmsWin.Datos.ConvenioMelody
{
    public class CalificacionGrid
    {
        #region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
        #endregion

        public static string EjecutaEnvio(string marca, string fecha, string tipo, string temporada, string tabla, string proveedor, string estilo)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();


            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R002 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", fecha.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", tipo.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", temporada.PadRight(3, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", tabla.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", proveedor.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", estilo.PadRight(15, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                

                return string.Empty;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

    }
}
