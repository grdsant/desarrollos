﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.ConvenioMelody
{
    public class Grupos
    {
#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static string AgregarGrupos(DataTable dtTemporadas, string usuario)
        {          
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                foreach (DataRow row in dtTemporadas.Rows)
                {
                    string marca = row["marca"].ToString();
                    string grupo = row["grupo"].ToString();
                    string tipo = row["tipo"].ToString();
                    string tempMms = row["tempMms"].ToString();
                    mensaje = "Ocurrió un problema al tratar de agregar la temporada."; 
                    sql.Clear();
                    sql.Append("CALL " + LibSatPgm + ".SAT177R81 (\n");
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", grupo.PadLeft(3, '0'));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", tipo.PadRight(3, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", tempMms.PadRight(3, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", usuario.PadRight(10, ' '));
                    sql.Append(")");

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Se agregó la temporada(s) correctamente.";                   
                }

                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
