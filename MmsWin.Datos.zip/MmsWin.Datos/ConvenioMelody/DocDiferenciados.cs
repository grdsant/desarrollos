﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.ConvenioMelody
{
    public class DocDiferenciados
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static DataTable ObtenDocDiferenciados(string marca, string comprador, string FchDe, string FchHas, string ParTienda, string ParProveedor, string PartbNombre, string PartbEstilo, string ParDescripcion)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtDocDiferenciados = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                if (marca == "[999, Todas]")
                {
                    marca = "999";
                }

                sql.Clear();
                sql.Append("SELECT * FROM\n");
                sql.Append(" " + LibSatObj + ".SAT177F35\n");

                if (FchDe != "")
                {
                    sql.AppendFormat(" WHERE RDDBON BETWEEN " + "'" + "{0}" + "'" + "\n", FchDe);
                    sql.AppendFormat(" AND " + "'" + "{0}" + "'" + "\n", FchHas);

                    if (marca     != "999") { sql.AppendFormat(" and RDDNMR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0')); }
                    if (comprador != "999") { sql.AppendFormat(" and RDDCOM = " + "'" + "{0}" + "'" + "\n", comprador); }

                    if (ParTienda      != "") { sql.AppendFormat(" and RDDSTR = "    + "'"  + "{0}" + "'"  + "\n", ParTienda); }
                    if (ParProveedor   != "") { sql.AppendFormat(" and RDDPRV = "    + "'"  + "{0}" + "'"  + "\n", ParProveedor); }
                    if (PartbNombre    != "") { sql.AppendFormat(" and RDDPRN LIKE " + "'%" + "{0}" + "%'" + "\n", PartbNombre); }
                    if (PartbEstilo    != "") { sql.AppendFormat(" and RDDSTY = "    + "'"  + "{0}" + "'"  + "\n", PartbEstilo); }
                    if (ParDescripcion != "") { sql.AppendFormat(" and RDDDES LIKE " + "'%" + "{0}" + "%'" + "\n", ParDescripcion); }
                }

                sql.Append(" ORDER BY RDDCAL, RDDPRV, RDDSTY  ASC\n"); 

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtDocDiferenciados = new DataTable("DocDiferenciados");
                dtDocDiferenciados.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtDocDiferenciados;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void EliminaDocumento(string ParFchBon, string ParFchRev, string ParTipoCal, string ParTemporada, string ParTienda, string ParProveedor, string ParEstilo, string ParNota)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("DELETE FROM " + LibSatObj + ".SAT177F35 WHERE\n");
                sql.Append(" RDDBON = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParFchBon.PadLeft(6, '0'));
                sql.Append(" AND RDDFRE = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParFchRev.PadLeft(6, '0'));
                sql.Append(" AND RDDTPO = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParTipoCal.PadRight(15, ' '));
                sql.Append(" AND RDDTMP = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParTemporada.PadRight(3, ' '));
                sql.Append(" AND RDDSTR = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParTienda.PadLeft(5, '0'));
                sql.Append(" AND RDDPRV = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParProveedor.PadLeft(6, '0'));
                sql.Append(" AND RDDSTY = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParEstilo.PadRight(15, ' '));
                sql.Append(" AND RDDNOT = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParNota.PadRight(10, ' '));

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch
            {  }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void EjecutaCargaPDF(string ParFchBon, string ParFchCal, string ParNota, string ParTienda, string ParPrv, string ParSty, string ParDest, string ParTpo, string ParUser)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R35 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchBon.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchCal.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParNota.PadRight(20, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParTienda.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParPrv.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParSty.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParDest.PadRight(100, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParTpo.PadLeft(1, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParUser.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

    }
}
