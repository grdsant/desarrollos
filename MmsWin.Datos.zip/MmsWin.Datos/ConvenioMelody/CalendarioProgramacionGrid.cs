﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;
    
namespace MmsWin.Datos.ConvenioMelody
{
    public class CalendarioProgramacionGrid
    {
        #region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
        #endregion

        public static DataTable ObtenCalendarioProgramacionGrid(string marca, string anio, string temporadaCombo, string usuario)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConvenioMelody = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT179C4 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", usuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                #region Campos de la Tabla SAT177F54
                sql.Clear();
                sql.Append("SELECT \n");
                sql.Append("T1.CPRMAR, \n"); //00 Marca
                sql.Append("T1.CPRANO, \n"); //01 Año
                sql.Append("T1.CPRTXT, \n"); //02 Text
                sql.Append("T1.CPRSEA, \n"); //03 Temporada
                sql.Append("T1.CPRTAB, \n"); //04 Temporada

                sql.Append("T1.CPRTB2, \n"); //05 04 Tabla 2 Nivel Tienda
                
                sql.Append("T1.CPRSED, \n"); //06 05 Temporada descripción

                sql.Append("T1.CPRREN, \n"); //07 06 Renglon 
                sql.Append("T1.CPRSEQ, \n"); //08 07 Secuencia 
                sql.Append("T1.CPRS01, \n"); //09 08 Semana 
                sql.Append("T1.CPRS02, \n"); //10 09 Semana 
                sql.Append("T1.CPRS03, \n"); //11 10 Semana  
                sql.Append("T1.CPRS04, \n"); //12 11 Semana 
                sql.Append("T1.CPRS05, \n"); //13 12 Semana 
                sql.Append("T1.CPRS06, \n"); //14 13 Semana 
                sql.Append("T1.CPRS07, \n"); //15 14 Semana 
                sql.Append("T1.CPRS08, \n"); //16 15 Semana 
                sql.Append("T1.CPRS09, \n"); //17 16 Semana 
                sql.Append("T1.CPRS10, \n"); //18 17 Semana 
                sql.Append("T1.CPRS11, \n"); //19 18 Semana 
                sql.Append("T1.CPRS12, \n"); //20 19 Semana 
                sql.Append("T1.CPRS13, \n"); //21 20 Semana 
                sql.Append("T1.CPRS14, \n"); //22 21 Semana 
                sql.Append("T1.CPRS15, \n"); //23 22 Semana 
                sql.Append("T1.CPRS16, \n"); //24 23 Semana 
                sql.Append("T1.CPRS17, \n"); //25 24 Semana 
                sql.Append("T1.CPRS18, \n"); //26 25 Semana 
                sql.Append("T1.CPRS19, \n"); //27 26 Semana 
                sql.Append("T1.CPRS20, \n"); //28 27 Semana 
                sql.Append("T1.CPRS21, \n"); //29 28 Semana 
                sql.Append("T1.CPRS22, \n"); //30 29 Semana 
                sql.Append("T1.CPRS23, \n"); //31 30 Semana 
                sql.Append("T1.CPRS24, \n"); //32 31 Semana 
                sql.Append("T1.CPRS25, \n"); //33 32 Semana 
                sql.Append("T1.CPRS26, \n"); //34 33 Semana 
                sql.Append("T1.CPRS27, \n"); //35 34 Semana 
                sql.Append("T1.CPRS28, \n"); //36 35 Semana 
                sql.Append("T1.CPRS29, \n"); //37 36 Semana 
                sql.Append("T1.CPRS30, \n"); //38 37 Semana 
                sql.Append("T1.CPRS31, \n"); //39 38 Semana  
                sql.Append("T1.CPRS32, \n"); //40 39 Semana 
                sql.Append("T1.CPRS33, \n"); //41 40 Semana 
                sql.Append("T1.CPRS34, \n"); //42 41 Semana 
                sql.Append("T1.CPRS35, \n"); //43 42 Semana 
                sql.Append("T1.CPRS36, \n"); //44 43 Semana 
                sql.Append("T1.CPRS37, \n"); //45 44 Semana 
                sql.Append("T1.CPRS38, \n"); //46 45 Semana 
                sql.Append("T1.CPRS39, \n"); //47 46 Semana 
                sql.Append("T1.CPRS40, \n"); //48 47 Semana 
                sql.Append("T1.CPRS41, \n"); //49 48 Semana 
                sql.Append("T1.CPRS42, \n"); //50 49 Semana 
                sql.Append("T1.CPRS43, \n"); //51 50 Semana 
                sql.Append("T1.CPRS44, \n"); //52 51 Semana 
                sql.Append("T1.CPRS45, \n"); //53 52 Semana 
                sql.Append("T1.CPRS46, \n"); //54 53 Semana 
                sql.Append("T1.CPRS47, \n"); //55 54 Semana 
                sql.Append("T1.CPRS48, \n"); //56 55 Semana 
                sql.Append("T1.CPRS49, \n"); //57 56 Semana 
                sql.Append("T1.CPRS50, \n"); //58 57 Semana 
                sql.Append("T1.CPRS51, \n"); //59 58 Semana 
                sql.Append("T1.CPRS52, \n"); //60 59 Semana 
                sql.Append("T1.CPRS53, \n"); //61 60 Semana 
                
                sql.Append("T1.CPRX01, \n"); //62 61 Semana NEXT 
                sql.Append("T1.CPRX02, \n"); //63 62 Semana NEXT 
                sql.Append("T1.CPRX03, \n"); //64 63 Semana NEXT 
                sql.Append("T1.CPRX04, \n"); //65 64 Semana NEXT 
                sql.Append("T1.CPRX05, \n"); //66 65 Semana NEXT 
                sql.Append("T1.CPRX06, \n"); //67 66 Semana NEXT 
                sql.Append("T1.CPRX07, \n"); //68 67 Semana NEXT 
                sql.Append("T1.CPRX08, \n"); //69 68 Semana NEXT 
                sql.Append("T1.CPRX09, \n"); //70 69 Semana NEXT 
                sql.Append("T1.CPRX10, \n"); //71 70 Semana NEXT 
                sql.Append("T1.CPRX11, \n"); //72 71 Semana NEXT 
                sql.Append("T1.CPRX12, \n"); //73 72 Semana NEXT 
                sql.Append("T1.CPRX13, \n"); //74 73 Semana NEXT 
                sql.Append("T1.CPRX14, \n"); //75 74 Semana NEXT 
                sql.Append("T1.CPRX15, \n"); //76 75 Semana NEXT 
                sql.Append("T1.CPRX16, \n"); //77 76 Semana NEXT 
                sql.Append("T1.CPRX17, \n"); //78 77 Semana NEXT 
                sql.Append("T1.CPRX18, \n"); //79 78 Semana NEXT 
                sql.Append("T1.CPRX19, \n"); //80 79 Semana NEXT 
                sql.Append("T1.CPRX20, \n"); //81 80 Semana NEXT 
                sql.Append("T1.CPRX21, \n"); //82 81 Semana NEXT 
                sql.Append("T1.CPRX22, \n"); //83 82 Semana NEXT 
                sql.Append("T1.CPRX23, \n"); //84 83 Semana NEXT 
                sql.Append("T1.CPRX24, \n"); //85 84 Semana NEXT 
                sql.Append("T1.CPRX25, \n"); //86 85 Semana NEXT 

                sql.Append("T1.CPRX26, \n"); //87 86 Semana NEXT 
                sql.Append("T1.CPRX27, \n"); //88 87 Semana NEXT 
                sql.Append("T1.CPRX28, \n"); //89 88 Semana NEXT 
                sql.Append("T1.CPRX29, \n"); //90 89 Semana NEXT 
                sql.Append("T1.CPRX30, \n"); //91 90 Semana NEXT 
                sql.Append("T1.CPRX31, \n"); //92 91 Semana NEXT 
                sql.Append("T1.CPRX32, \n"); //93 92 Semana NEXT 
                sql.Append("T1.CPRX33, \n"); //94 93 Semana NEXT 
                sql.Append("T1.CPRX34, \n"); //95 94 Semana NEXT 
                sql.Append("T1.CPRX35, \n"); //96 95 Semana NEXT 
                sql.Append("T1.CPRX36, \n"); //97 96 Semana NEXT 
                sql.Append("T1.CPRX37, \n"); //98 97 Semana NEXT 
                sql.Append("T1.CPRX38, \n"); //99 98 Semana NEXT 
                sql.Append("T1.CPRX39, \n"); //100 99 Semana NEXT 
                sql.Append("T1.CPRX40, \n"); //101 100 Semana NEXT 
                sql.Append("T1.CPRX41, \n"); //102 101 Semana NEXT 
                sql.Append("T1.CPRX42, \n"); //103 102 Semana NEXT 
                sql.Append("T1.CPRX43, \n"); //104 103 Semana NEXT 
                sql.Append("T1.CPRX44, \n"); //105 104 Semana NEXT 
                sql.Append("T1.CPRX45, \n"); //106 105 Semana NEXT 
                sql.Append("T1.CPRX46, \n"); //107 106 Semana NEXT 
                sql.Append("T1.CPRX47, \n"); //108 107 Semana NEXT 
                sql.Append("T1.CPRX48, \n"); //109 108 Semana NEXT 
                sql.Append("T1.CPRX49, \n"); //110 109 Semana NEXT 
                sql.Append("T1.CPRX50, \n"); //111 110 Semana NEXT 
                sql.Append("T1.CPRX51, \n"); //112 111 Semana NEXT 
                sql.Append("T1.CPRX52, \n"); //113 112 Semana NEXT 
                sql.Append("T1.CPRX53, \n"); //114 113 Semana NEXT 

                sql.Append("T1.CPRUAL, \n"); //115 114-86 Semana 
                sql.Append("T1.CPRFAL, \n"); //116 115-87 Semana 
                sql.Append("T1.CPRHAL, \n"); //117 116-88 Semana 
                sql.Append("T1.CPRUCA, \n"); //118 117-89 Semana 
                sql.Append("T1.CPRFCA, \n"); //119 118-90 Semana 
                sql.Append("T1.CPRHCA \n");  //120 119-91 Semana 
                #endregion

                sql.Append("FROM " + LibSatObj + ".SAT177F54 T1\n");
                    sql.AppendFormat(" WHERE T1.CPRMAR  = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));

                    if (anio != "0") { sql.AppendFormat(" and T1.CPRANO = " + "'" + "{0}" + "'" + "\n", anio.PadLeft(2, '0')); }
                    if (temporadaCombo != "Todas" && temporadaCombo != "999") { sql.AppendFormat(" and T1.CPRSEA = " + "'" + "{0}" + "'" + "\n", temporadaCombo.PadRight(3, ' ')); }
                    sql.AppendFormat(" or T1.CPRREN = " + "'" + "{0}" + "'" + "\n", "0".PadLeft(5, '0'));
                    sql.AppendFormat(" and T1.CPRMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat(" and T1.CPRANO = " + "'" + "{0}" + "'" + "\n", anio.PadLeft(2, '0'));

                    sql.Append(" ORDER BY T1.CPRMAR, T1.CPRANO, T1.CPRSEQ, T1.CPRREN  ASC\n");

                    db2Comm.CommandText = sql.ToString();
                    OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                    dtConvenioMelody = new DataTable("ConvenioMelody");
                    dtConvenioMelody.Load(db2Reader);
                    db2Reader.Close();

                return dtConvenioMelody;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenCalificaiones(string marca, string comprador, string FchDe, string FchHas, string tipo, string temporada, string parTipoCalificacion, string parFchCalificacion, string parProveedor, string parNombre, string parEstilo, string parDescripcion)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConvenioMelody = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                #region Campos de la Tabla SAT177F59
                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("MDYMAR,  \n");  //00 Marca
                sql.Append("MDYTMP,  \n");  //01 Año
                sql.Append("MDYTAB,  \n");  //02 Año
                sql.Append("MDYTPO,  \n");  //03 Text
                sql.Append("MDYFCH,  \n");  //04 Temporada
                sql.Append("MDYPRV,  \n");  //05 Temporada descripción
                sql.Append("MDYPRVD, \n");  //06 Renglon 
                sql.Append("MDYSTY,  \n");  //07 Secuencia 
                sql.Append("MDYSTYD, \n");  //08 Semana 
                sql.Append("MDYCOM,  \n");  //09 Semana 
                sql.Append("MDYCMP,  \n");  //10 Semana  
                sql.Append("MDYDEP,  \n");  //11 Semana 
                sql.Append("MDYSDP,  \n");  //12 Semana 
                sql.Append("MDYCLS,  \n");  //13 Semana 
                sql.Append("MDYSCL,  \n");  //14 Semana 
                sql.Append("MDYDEPD, \n");  //15 Semana 
                sql.Append("MDYSDPD, \n");  //16 Semana 
                sql.Append("MDYCLSD, \n");  //17 Semana 
                sql.Append("MDYSCLD, \n");  //18 Semana 
                sql.Append("MDYORD,  \n");  //19 Semana 
                sql.Append("MDYFRB,  \n");  //20 Semana 
                sql.Append("MDYCRB,  \n");  //21 Semana 
                sql.Append("MDYVPZ,  \n");  //22 Semana 
                sql.Append("MDYPVT,  \n");  //23 Semana 

                sql.Append("MDYCDP,  \n");  //24 Semana 
                sql.Append("MDYCOR,  \n");  //25 Semana 
                sql.Append("MDYCFN,  \n");  //26 Semana 
                
                sql.Append("MDYRTB,  \n");  //27 Semana 
                sql.Append("MDYRT2,  \n");  //28 Semana 
                sql.Append("MDYRT3,  \n");  //29 Semana 
                sql.Append("MDYRT4,  \n");  //30 Semana 

                sql.Append("MDYOHP,  \n");  //31 Semana 
                sql.Append("MDYTST,  \n");  //32 Semana 
                sql.Append("MDYONO,  \n");  //33 Semana 
                sql.Append("MDYRST,  \n");  //34 Semana 
                sql.Append("MDYPDI,  \n");  //34 35 Semana 
                sql.Append("MDYDDV,  \n");  //35 36 Semana 

                sql.Append("MDYCTT,  \n");  //36 37 Semana 
                sql.Append("MDYPZA,  \n");  //37 38 Semana 
                sql.Append("MDYCSB,  \n");  //38 39 Semana 
                
                sql.Append("MDYSM01, \n");  //39 40 Semana 
                sql.Append("MDYSM02, \n");  //40 41 Semana 
                sql.Append("MDYSM03, \n");  //41 42 Semana 
                sql.Append("MDYSM04, \n");  //42 43 Semana 
                sql.Append("MDYSM05, \n");  //43 44 Semana 
                sql.Append("MDYSM06, \n");  //44 45 Semana 
                sql.Append("MDYSM07, \n");  //45 46 Semana 
                sql.Append("MDYSM08, \n");  //46 47 Semana 
                sql.Append("MDYSM09, \n");  //47 48 Semana 
                sql.Append("MDYSM10, \n");  //48 49 Semana 

                sql.Append("MDYDPA,  \n");  //49 50 Semana 
                sql.Append("MDYCSTI, \n");  //50 51 Semana 
                sql.Append("MDYPREI, \n");  //51 52 Semana 
                sql.Append("MDYMRGI, \n");  //52 53 Semana 
                sql.Append("MDYCST,  \n");  //53 54 Semana 
                sql.Append("MDYPRC,  \n");  //54 55 Semana 
                sql.Append("MDYMRG,  \n");  //55 56 Semana 
                sql.Append("SLTSM01, \n");  //56 57 Semana  
                sql.Append("SLTSM02, \n");  //57 58 Semana 
                sql.Append("SLTSM03, \n");  //58 59 Semana 
                sql.Append("SLTSM04, \n");  //59 60 Semana 
                sql.Append("SLTSM05, \n");  //60 61 Semana 
                sql.Append("SLTSM06, \n");  //61 62 Semana 
                sql.Append("SLTSM07, \n");  //62 63 Semana 
                sql.Append("SLTSM08, \n");  //63 64 Semana 
                sql.Append("SLTSM09, \n");  //64 65 Semana 
                sql.Append("SLTSM10, \n");  //65 66 Semana 

                sql.Append("MDYBDG,  \n");  //66 67 Semana 

                sql.Append("MDYOBC,  \n");  //67 68 Semana 
                sql.Append("MDYCBC,  \n");  //68 69 Semana 
                sql.Append("MDYUCP,  \n");  //69 70 Semana 
                sql.Append("MDYFCP,  \n");  //70 71 Semana 
                sql.Append("MDYHCP,  \n");  //71 72 Semana 

                sql.Append("MDYOBT,  \n");  //72 73 Semana 
                sql.Append("MDYCBT,  \n");  //73 74 Semana 
                sql.Append("MDYUCT,  \n");  //74 75 Semana 
                sql.Append("MDYFCT,  \n");  //75 76 Semana 
                sql.Append("MDYHCT,  \n");  //76 77 Semana 
                
                sql.Append("MDYUAL,  \n");  //77 78 Semana 
                sql.Append("MDYFAL,  \n");  //78 79 Semana 
                sql.Append("MDYHAL,  \n");  //79 80 Semana 
                sql.Append("MDYUCA,  \n");  //80 81 Semana 
                sql.Append("MDYFCA,  \n");  //81 82 Semana 
                sql.Append("MDYHCA,  \n");  //82 83 Semana 
                sql.Append("MDYPTS   \n");  //83 84 Semana 
                #endregion

                sql.Append("FROM " + LibSatObj + ".SAT177F59 T1\n");
                sql.AppendFormat(" WHERE  MDYMAR <> 0 \n");
                if (marca     != "999") { sql.AppendFormat(" and MDYMAR  = " + "'" + "{0}" + "'" + "\n",      marca.PadLeft(3, '0')); }
                if (FchDe     != "0") { sql.AppendFormat(" and  MDYFCH between " + "'" + "{0}" + "'" + "\n",  FchDe.PadLeft(6, '0')); }
                if (FchHas    != "0") { sql.AppendFormat(" and " + "'" + "{0}" + "'" + "\n",                  FchHas.PadLeft(6, '0')); }
                if (tipo      != "") { sql.AppendFormat("  and MDYTPO = " + "'" + "{0}" + "'" + "\n",         tipo.PadRight(15, ' ')); }
                if (temporada != "") { sql.AppendFormat("  and MDYTMP = " + "'" + "{0}" + "'" + "\n",         temporada.PadRight(3, ' ')); }

                if (parTipoCalificacion != "" && parTipoCalificacion != "999" && parTipoCalificacion != "Todas") { sql.AppendFormat(" and MDYTPO  = " + "'" + "{0}" + "'" + "\n", parTipoCalificacion); }
                if (parFchCalificacion  != "") { sql.AppendFormat(" and MDYFCH  = " + "'" + "{0}" + "'" + "\n", parFchCalificacion.PadLeft(6, '0')); }
                if (parProveedor        != "") { sql.AppendFormat(" and MDYPRV  = " + "'" + "{0}" + "'" + "\n", parProveedor.PadLeft(6, '0')); }
                if (parNombre           != "") { sql.AppendFormat(" and MDYPRVD like " + "'" + "%" + "{0}" + "%" + "'" + "\n", parNombre); }
                if (parEstilo           != "") { sql.AppendFormat(" and MDYSTY  = " + "'" + "{0}" + "'" + "\n", parEstilo); }
                if (parDescripcion      != "") { sql.AppendFormat(" and MDYSTYD like " + "'" + "%" + "{0}" + "%" + "'" + "\n", parDescripcion); }
                if (comprador           != "999") { sql.AppendFormat(" and MDYCOM  IN " + "(" + "{0}" + ")" + "\n", comprador.PadRight(3, ' ')); }

                if (marca == "10" || marca == "30") { sql.Append(" ORDER BY MDYPVT DESC, MDYCDP  DESC\n"); }
                //if (marca == "30") { sql.Append(" ORDER BY MDYRTB DESC, MDYCDP  DESC\n"); }
                

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtConvenioMelody = new DataTable("ConvenioMelody");
                dtConvenioMelody.Load(db2Reader);
                db2Reader.Close();

                return dtConvenioMelody;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenCalificaionesTda(string marca, string comprador, string FchDe, string FchHas, string tipo, string temporada, string parTipoCalificacion, string parFchCalificacion, string parProveedor, string parNombre, string parEstilo, string parDescripcion)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConvenioMelody = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                #region Campos de la tabla
                sql.Append("SELECT   \n");
                sql.Append("MDYMAR,  \n");  //00 Marca
                sql.Append("MDYTDA,  \n");  //01 Tienda
                sql.Append("MDYTDD,  \n");  //02 Nombre
                sql.Append("MDYTMP,  \n");  //03 Año
                sql.Append("MDYTAB,  \n");  //04 Año
                sql.Append("MDYTPO,  \n");  //05 Text
                sql.Append("MDYFCH,  \n");  //06 Temporada
                sql.Append("MDYPRV,  \n");  //07 Temporada descripción
                sql.Append("MDYPRVD, \n");  //08 Renglon 
                sql.Append("MDYSTY,  \n");  //09 Secuencia 
                sql.Append("MDYSTYD, \n");  //10  
                sql.Append("MDYCOM,  \n");  //11  
                sql.Append("MDYCMP,  \n");  //12   
                sql.Append("MDYDEP,  \n");  //13  
                sql.Append("MDYSDP,  \n");  //14  
                sql.Append("MDYCLS,  \n");  //15  
                sql.Append("MDYSCL,  \n");  //16  
                sql.Append("MDYDEPD, \n");  //17  
                sql.Append("MDYSDPD, \n");  //18  
                sql.Append("MDYCLSD, \n");  //19  
                sql.Append("MDYSCLD, \n");  //20  
                sql.Append("MDYORD, \n");   //21  
                sql.Append("MDYFRB, \n");   //22  
                sql.Append("MDYCRB, \n");   //23  
                sql.Append("MDYVPZ, \n");   //24  
                sql.Append("MDYPVT,  \n");  //25                  
                sql.Append("MDYCDP,  \n");  //26  
                sql.Append("MDYCOR,  \n");  //27  
                sql.Append("MDYCFN,  \n");  //28  
                sql.Append("MDYRTB,  \n");  //29  
                sql.Append("MDYRT2,  \n");  //30  
                sql.Append("MDYRT3,  \n");  //31  
                sql.Append("MDYRT4,  \n");  //32  
                sql.Append("MDYOHP, \n");   //33  
                sql.Append("MDYTST, \n");   //34  
                sql.Append("MDYONO, \n");   //35  
                sql.Append("MDYPDI, \n");   //36  
                sql.Append("MDYDDV,  \n");  //37  
                sql.Append("MDYCTT, \n");   //38  
                sql.Append("MDYPZA, \n");   //39  
                sql.Append("MDYCSB, \n");   //40  
                sql.Append("MDYSM01, \n");  //41  
                sql.Append("MDYSM02, \n");  //42  
                sql.Append("MDYSM03, \n");  //43  
                sql.Append("MDYSM04, \n");  //44  
                sql.Append("MDYSM05, \n");  //45  
                sql.Append("MDYSM06, \n");  //46  
                sql.Append("MDYSM07, \n");  //47  
                sql.Append("MDYSM08, \n");  //48  
                sql.Append("MDYSM09, \n");  //49  
                sql.Append("MDYSM10, \n");  //50  
                sql.Append("MDYDPA,  \n");  //51  
                sql.Append("MDYCSTI, \n");  //52  
                sql.Append("MDYPREI, \n");  //53  
                sql.Append("MDYMRGI, \n");  //54  
                sql.Append("MDYCST,  \n");  //55  
                sql.Append("MDYPRC,  \n");  //56  
                sql.Append("MDYMRG,  \n");  //57  
                sql.Append("SLTSM01, \n");  //58   
                sql.Append("SLTSM02, \n");  //59  
                sql.Append("SLTSM03, \n");  //60  
                sql.Append("SLTSM04, \n");  //61  
                sql.Append("SLTSM05, \n");  //62  
                sql.Append("SLTSM06, \n");  //63  
                sql.Append("SLTSM07, \n");  //64  
                sql.Append("SLTSM08, \n");  //65  
                sql.Append("SLTSM09, \n");  //66  
                sql.Append("SLTSM10, \n");  //67  

                sql.Append("MDYBDG, \n");   //68  

                sql.Append("MDYOBC, \n");   //69  
                sql.Append("MDYCBC, \n");   //70  
                sql.Append("MDYUCP, \n");   //71  
                sql.Append("MDYFCP, \n");   //72  
                sql.Append("MDYHCP, \n");   //73  

                sql.Append("MDYOBT, \n");   //74  
                sql.Append("MDYCBT, \n");   //75  
                sql.Append("MDYUCT, \n");   //76  
                sql.Append("MDYFCT, \n");   //77  
                sql.Append("MDYHCT, \n");   //78  

                sql.Append("MDYUAL, \n");   //79  
                sql.Append("MDYFAL, \n");   //80  
                sql.Append("MDYHAL, \n");   //81  
                sql.Append("MDYUCA, \n");   //82  
                sql.Append("MDYFCA, \n");   //83 
                sql.Append("MDYHCA, \n");   //84 
                sql.Append("MDYMTX, \n");   //85  
                sql.Append("MDYCLP, \n");   //86 
                sql.Append("MDYCLA,  \n");   //87 
                sql.Append("(ISHAND + ISINTQ) Inventario  \n");   //88 
                #endregion
                sql.Append("FROM " + LibSatObj + ".SAT177F60 x\n");

                sql.AppendFormat("INNER JOIN MM610LIB.INSBAL y \n");
                sql.AppendFormat("ON \n");
                sql.AppendFormat("    x.MDYPRV = y.IASNUM \n");
                sql.AppendFormat("AND x.MDYSTY = y.ISTYLN \n");
                sql.AppendFormat("AND x.MDYTDA = y.ISTORE \n");

                sql.AppendFormat(" WHERE  MDYMAR <> 0 \n");
                if (marca     != "999") { sql.AppendFormat(" and MDYMAR  = " + "'" + "{0}" + "'"   + "\n", marca.PadLeft(3, '0')); }
                if (FchDe     != "0")   { sql.AppendFormat(" and MDYFCH between "  + "'"   + "{0}" + "'" + "\n", FchDe.PadLeft(6, '0')); }
                if (FchHas    != "0")   { sql.AppendFormat(" and " + "'" + "{0}"   + "'"   + "\n", FchHas.PadLeft(6, '0')); }
                if (tipo      != "")    { sql.AppendFormat(" and MDYTPO  = " + "'" + "{0}" + "'"   + "\n", tipo.PadRight(15, ' ')); }
                if (temporada != "")    { sql.AppendFormat(" and MDYTMP  = " + "'" + "{0}" + "'"   + "\n", temporada.PadRight(3, ' ')); }

                if (parTipoCalificacion != "")    { sql.AppendFormat(" and MDYTPO  = " + "'" + "{0}" + "'" + "\n", parTipoCalificacion); }
                if (parFchCalificacion  != "")    { sql.AppendFormat(" and MDYFCH  = " + "'" + "{0}" + "'" + "\n", parFchCalificacion.PadLeft(6, '0')); }
                if (parProveedor        != "")    { sql.AppendFormat(" and MDYPRV  = " + "'" + "{0}" + "'" + "\n", parProveedor.PadLeft(6, '0')); }
                if (parNombre           != "")    { sql.AppendFormat(" and MDYPRVD like " + "'" + "%" + "{0}" + "%" + "'" + "\n", parNombre); }
                if (parEstilo           != "")    { sql.AppendFormat(" and MDYSTY  = " + "'" + "{0}" + "'" + "\n", parEstilo); }
                if (parDescripcion      != "")    { sql.AppendFormat(" and MDYSTYD like " + "'" + "%" + "{0}" + "%" + "'" + "\n", parDescripcion); }
                if (comprador           != "999") { sql.AppendFormat(" and MDYCOM  = " + "'" + "{0}" + "'" + "\n", comprador.PadRight(3, ' ')); }

                if (marca == "10") { sql.Append(" ORDER BY MDYPVT DESC, MDYCDP  DESC\n"); }
                if (marca == "30") { sql.Append(" ORDER BY MDYPVT DESC, MDYCDP  DESC\n"); }

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtConvenioMelody = new DataTable("ConvenioMelody");
                dtConvenioMelody.Load(db2Reader);

                #region Registro Total
                DataRow row = dtConvenioMelody.NewRow();
                row["MDYMAR"]  = "0";  
                row["MDYTDA"]  = "0";  
                row["MDYTDD"]  = "Total";  
                row["MDYTMP"]  = "0";  
                row["MDYTAB"]  = "0";  
                row["MDYTPO"]  = "0";  
                row["MDYFCH"]  = "0";  
                row["MDYPRV"]  = "0";  
                row["MDYPRVD"] = "0"; 
                row["MDYSTY"]  = "0";  
                row["MDYSTYD"] = "0"; 
                row["MDYCOM"]  = "0";  
                row["MDYCMP"]  = "0";  
                row["MDYDEP"]  = "0";  
                row["MDYSDP"]  = "0";  
                row["MDYCLS"]  = "0";  
                row["MDYSCL"]  = "0";  
                row["MDYDEPD"] = "0"; 
                row["MDYSDPD"] = "0"; 
                row["MDYCLSD"] = "0"; 
                row["MDYSCLD"] = "0"; 
                row["MDYORD"]  = "0"; 
                row["MDYFRB"]  = "0"; 
                row["MDYCRB"]  = "0"; 
                row["MDYVPZ"]  = "0"; 
                row["MDYPVT"]  = "0";
                row["MDYCDP"] = "0";
                row["MDYCOR"] = "0";
                row["MDYCFN"] = "0";
                row["MDYRTB"] = "0";
                row["MDYRT2"] = "0";
                row["MDYRT3"] = "0";
                row["MDYRT4"] = "0";
                row["MDYOHP"] = "0";
                row["MDYTST"] = "0";
                row["MDYONO"] = "0";
                row["MDYPDI"] = "0";
                row["MDYDDV"] = "0"; 
                row["MDYSM01"] = "0";
                row["MDYSM02"] = "0";
                row["MDYSM03"] = "0";
                row["MDYSM04"] = "0";
                row["MDYSM05"] = "0";
                row["MDYSM06"] = "0";
                row["MDYSM07"] = "0";
                row["MDYSM08"] = "0";
                row["MDYSM09"] = "0";
                row["MDYSM10"] = "0"; 
                row["MDYDPA"]  = "0";  
                row["MDYCSTI"] = "0"; 
                row["MDYPREI"] = "0"; 
                row["MDYMRGI"] = "0"; 
                row["MDYCST"]  = "0";  
                row["MDYPRC"]  = "0";  
                row["MDYMRG"]  = "0";  
                row["SLTSM01"] = "0"; 
                row["SLTSM02"] = "0"; 
                row["SLTSM03"] = "0"; 
                row["SLTSM04"] = "0"; 
                row["SLTSM05"] = "0"; 
                row["SLTSM06"] = "0"; 
                row["SLTSM07"] = "0"; 
                row["SLTSM08"] = "0"; 
                row["SLTSM09"] = "0"; 
                row["SLTSM10"] = "0"; 
                row["MDYCTT"]  = "0"; 
                row["MDYPZA"]  = "0"; 
                row["MDYCSB"]  = "0"; 
                row["MDYBDG"]  = "0"; 
                row["MDYOBC"]  = "0"; 
                row["MDYCBC"]  = "0"; 
                row["MDYUCP"]  = "0"; 
                row["MDYFCP"]  = "0"; 
                row["MDYHCP"]  = "0"; 
                row["MDYOBT"]  = "0"; 
                row["MDYCBT"]  = "0"; 
                row["MDYUCT"]  = "0"; 
                row["MDYFCT"]  = "0"; 
                row["MDYHCT"]  = "0"; 
                row["MDYUAL"]  = "0"; 
                row["MDYFAL"]  = "0"; 
                row["MDYHAL"]  = "0"; 
                row["MDYUCA"]  = "0"; 
                row["MDYFCA"]  = "0"; 
                row["MDYHCA"]  = "0";
                row["MDYMTX"]  = "0";
                row["MDYCLP"]  = "0";
                row["MDYCLA"]  = " ";
                row["INVENTARIO"] = "0"; 
                dtConvenioMelody.Rows.Add(row);
                #endregion

                db2Reader.Close();

                return dtConvenioMelody;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenValidacion(string usuario)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtValidacion = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C7 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", usuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT * \n");
                sql.Append("FROM " + LibSatObj + ".SAT177F77 \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtValidacion = new DataTable("Validacion");
                dtValidacion.Load(db2Reader);
                db2Reader.Close();

                return dtValidacion;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenCalificaionesTdaXcalificacion(string marca, string comprador, string FchDe, string FchHas, string temporada, string parTipoCalificacion, string parFchCalificacion, string parProveedor, string parNombre, string parEstilo, string parDescripcion, string calificacion, string parOrigen)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConvenioMelody = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                #region Registros de la tabla SAT177F59 y SAT177F60
                sql.Clear();
                sql.Append("SELECT    \n");
                sql.Append("d.MDYMAR,  \n");  //00 Marca
                sql.Append("d.MDYTDA,  \n");  //01 Tienda
                sql.Append("d.MDYTDD,  \n");  //02 Nombre
                sql.Append("d.MDYTMP,  \n");  //03 Año
                sql.Append("d.MDYTAB,  \n");  //04 Año
                sql.Append("d.MDYTPO,  \n");  //05 Text
                sql.Append("d.MDYFCH,  \n");  //06 Temporada
                sql.Append("d.MDYPRV,  \n");  //07 Temporada descripción
                sql.Append("d.MDYPRVD, \n");  //08 Renglon 
                sql.Append("d.MDYSTY,  \n");  //09 Secuencia 
                sql.Append("d.MDYSTYD, \n");  //10  
                sql.Append("d.MDYCOM,  \n");  //11  
                sql.Append("d.MDYCMP,  \n");  //12   
                sql.Append("d.MDYDEP,  \n");  //13  
                sql.Append("d.MDYSDP,  \n");  //14  
                sql.Append("d.MDYCLS,  \n");  //15  
                sql.Append("d.MDYSCL,  \n");  //16  
                sql.Append("d.MDYDEPD, \n");  //17  
                sql.Append("d.MDYSDPD, \n");  //18  
                sql.Append("d.MDYCLSD, \n");  //19  
                sql.Append("d.MDYSCLD, \n");  //20  
                sql.Append("d.MDYORD, \n");   //21  
                sql.Append("d.MDYFRB, \n");   //22  
                sql.Append("d.MDYCRB, \n");   //23  
                sql.Append("d.MDYVPZ, \n");   //24  
                sql.Append("d.MDYPVT,  \n");  //25                  
                sql.Append("d.MDYCDP,  \n");  //26  
                sql.Append("d.MDYCOR,  \n");  //27  
                sql.Append("d.MDYCFN,  \n");  //28  
                sql.Append("d.MDYRTB,  \n");  //29  
                sql.Append("d.MDYRT2,  \n");  //30  
                sql.Append("d.MDYRT3,  \n");  //31  
                sql.Append("d.MDYRT4,  \n");  //32  
                sql.Append("d.MDYOHP, \n");   //33  
                sql.Append("d.MDYTST, \n");   //34  
                sql.Append("d.MDYONO, \n");   //35  
                sql.Append("d.MDYPDI, \n");   //36  
                sql.Append("d.MDYDDV,  \n");  //37  
                sql.Append("d.MDYCTT, \n");   //38  
                sql.Append("d.MDYPZA, \n");   //39  
                sql.Append("d.MDYCSB, \n");   //40  
                sql.Append("d.MDYSM01, \n");  //41  
                sql.Append("d.MDYSM02, \n");  //42  
                sql.Append("d.MDYSM03, \n");  //43  
                sql.Append("d.MDYSM04, \n");  //44  
                sql.Append("d.MDYSM05, \n");  //45  
                sql.Append("d.MDYSM06, \n");  //46  
                sql.Append("d.MDYSM07, \n");  //47  
                sql.Append("d.MDYSM08, \n");  //48  
                sql.Append("d.MDYSM09, \n");  //49  
                sql.Append("d.MDYSM10, \n");  //50  
                sql.Append("d.MDYDPA,  \n");  //51  
                sql.Append("d.MDYCSTI, \n");  //52  
                sql.Append("d.MDYPREI, \n");  //53  
                sql.Append("d.MDYMRGI, \n");  //54  
                sql.Append("d.MDYCST,  \n");  //55  
                sql.Append("d.MDYPRC,  \n");  //56  
                sql.Append("d.MDYMRG,  \n");  //57  
                sql.Append("d.SLTSM01, \n");  //58   
                sql.Append("d.SLTSM02, \n");  //59  
                sql.Append("d.SLTSM03, \n");  //60  
                sql.Append("d.SLTSM04, \n");  //61  
                sql.Append("d.SLTSM05, \n");  //62  
                sql.Append("d.SLTSM06, \n");  //63  
                sql.Append("d.SLTSM07, \n");  //64  
                sql.Append("d.SLTSM08, \n");  //65  
                sql.Append("d.SLTSM09, \n");  //66  
                sql.Append("d.SLTSM10, \n");  //67  

                sql.Append("d.MDYBDG, \n");   //68  

                sql.Append("d.MDYOBC, \n");   //69  
                sql.Append("d.MDYCBC, \n");   //70  
                sql.Append("d.MDYUCP, \n");   //71  
                sql.Append("d.MDYFCP, \n");   //72  
                sql.Append("d.MDYHCP, \n");   //73  

                sql.Append("d.MDYOBT, \n");   //74  
                sql.Append("d.MDYCBT, \n");   //75  
                sql.Append("d.MDYUCT, \n");   //76  
                sql.Append("d.MDYFCT, \n");   //77  
                sql.Append("d.MDYHCT, \n");   //78  

                sql.Append("d.MDYUAL, \n");   //79  
                sql.Append("d.MDYFAL, \n");   //80  
                sql.Append("d.MDYHAL, \n");   //81  
                sql.Append("d.MDYUCA, \n");   //82  
                sql.Append("d.MDYFCA, \n");   //83 
                sql.Append("d.MDYHCA, \n");   //84 
                sql.Append("d.MDYMTX, \n");   //85  
                sql.Append("d.MDYCLP, \n");   //86 
                sql.Append("d.MDYCLA  \n");   //87 
                #endregion

                sql.Append("FROM "       + LibSatObj + ".SAT177F59 c \n");
                sql.Append("LEFT JOIN  " + LibSatObj + ".SAT177F60 d \n");
                sql.Append("ON  c.MDYMAR = d.MDYMAR \n");
                sql.Append("and c.MDYFCH = d.MDYFCH \n");
                sql.Append("and c.MDYTPO = d.MDYTPO \n");
                sql.Append("and c.MDYTMP = d.MDYTMP \n");
                sql.Append("and c.MDYPRV = d.MDYPRV \n");
                sql.Append("and c.MDYSTY = d.MDYSTY \n");

                sql.AppendFormat(" WHERE  c.MDYMAR <> 0 \n");
                if (marca               != "999") { sql.AppendFormat(" and c.MDYMAR   = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0')); }
                if (FchDe               != "0") { sql.AppendFormat("   and c.MDYFCH between " + "'" + "{0}" + "'" + "\n", FchDe.PadLeft(6, '0')); }
                if (FchHas              != "0") { sql.AppendFormat("   and " + "'" + "{0}" + "'" + "\n", FchHas.PadLeft(6, '0')); }
                if (parTipoCalificacion != "") { sql.AppendFormat("    and c.MDYTPO   = " + "'" + "{0}" + "'" + "\n", parTipoCalificacion.PadRight(15, ' ')); }
                if (temporada           != "") { sql.AppendFormat("    and c.MDYTMP   = " + "'" + "{0}" + "'" + "\n", temporada.PadRight(3, ' ')); }

                //if (parTipoCalificacion != "") { sql.AppendFormat("    and c.MDYTPO       = " + "'" + "{0}" + "'" + "\n", parTipoCalificacion); }
                if (parFchCalificacion  != "") { sql.AppendFormat("    and c.MDYFCH       = " + "'" + "{0}" + "'" + "\n", parFchCalificacion.PadLeft(6, '0')); }
                if (parProveedor        != "") { sql.AppendFormat("    and c.MDYPRV       = " + "'" + "{0}" + "'" + "\n", parProveedor.PadLeft(6, '0')); }
                if (parNombre           != "") { sql.AppendFormat("    and c.MDYPRVD like "   + "'" + "%" + "{0}" + "%" + "'" + "\n", parNombre); }
                if (parEstilo           != "") { sql.AppendFormat("    and c.MDYSTY       = " + "'" + "{0}" + "'" + "\n", parEstilo); }
                if (parDescripcion      != "") { sql.AppendFormat("    and c.MDYSTYD like "   + "'" + "%" + "{0}" + "%" + "'" + "\n", parDescripcion); }
                if (comprador           != "999") { sql.AppendFormat(" and c.MDYCOM       = " + "'" + "{0}" + "'" + "\n", comprador.PadRight(3, ' ')); }
                if (parOrigen == "Global")
                {
                    if (calificacion != null) { sql.AppendFormat("    and d.MDYCDP       = " + "'" + "{0}" + "'" + "\n", calificacion); }
                }
                else
                {
                    if (calificacion != null) { sql.AppendFormat("    and c.MDYCDP       = " + "'" + "{0}" + "'" + "\n", calificacion); }
                }
                if (marca == "10") { sql.Append(" ORDER BY MDYTDA, MDYPVT , MDYCDP \n"); }
                if (marca == "30") { sql.Append(" ORDER BY MDYTDA, MDYPVT , MDYCDP \n"); }
                if (marca == "60") { sql.Append(" ORDER BY MDYTDA, MDYPVT , MDYCDP \n"); }

                db2Comm.CommandText       = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtConvenioMelody = new DataTable("ConvenioMelody");
                dtConvenioMelody.Load(db2Reader);

                #region Registro de Totales
                DataRow row = dtConvenioMelody.NewRow();
                row["MDYMAR"]  = "0";
                row["MDYTDA"]  = "0";
                row["MDYTDD"]  = "Total";
                row["MDYTMP"]  = "0";
                row["MDYTAB"]  = "0";
                row["MDYTPO"]  = "0";
                row["MDYFCH"]  = "0";
                row["MDYPRV"]  = "0";
                row["MDYPRVD"] = "0";
                row["MDYSTY"]  = "0";
                row["MDYSTYD"] = "0";
                row["MDYCOM"]  = "0";
                row["MDYCMP"]  = "0";
                row["MDYDEP"]  = "0";
                row["MDYSDP"]  = "0";
                row["MDYCLS"]  = "0";
                row["MDYSCL"]  = "0";
                row["MDYDEPD"] = "0";
                row["MDYSDPD"] = "0";
                row["MDYCLSD"] = "0";
                row["MDYSCLD"] = "0";
                row["MDYORD"]  = "0";
                row["MDYFRB"]  = "0";
                row["MDYCRB"]  = "0";
                row["MDYVPZ"]  = "0";
                row["MDYPVT"]  = "0";
                row["MDYCDP"]  = "0";
                row["MDYCOR"]  = "0";
                row["MDYCFN"]  = "0";
                row["MDYRTB"]  = "0";
                row["MDYRT2"]  = "0";
                row["MDYRT3"]  = "0";
                row["MDYRT4"]  = "0";
                row["MDYOHP"]  = "0";
                row["MDYTST"]  = "0";
                row["MDYONO"]  = "0";
                row["MDYPDI"]  = "0";
                row["MDYDDV"]  = "0";
                row["MDYSM01"] = "0";
                row["MDYSM02"] = "0";
                row["MDYSM03"] = "0";
                row["MDYSM04"] = "0";
                row["MDYSM05"] = "0";
                row["MDYSM06"] = "0";
                row["MDYSM07"] = "0";
                row["MDYSM08"] = "0";
                row["MDYSM09"] = "0";
                row["MDYSM10"] = "0";
                row["MDYDPA"]  = "0";
                row["MDYCSTI"] = "0";
                row["MDYPREI"] = "0";
                row["MDYMRGI"] = "0";
                row["MDYCST"]  = "0";
                row["MDYPRC"]  = "0";
                row["MDYMRG"]  = "0";
                row["SLTSM01"] = "0";
                row["SLTSM02"] = "0";
                row["SLTSM03"] = "0";
                row["SLTSM04"] = "0";
                row["SLTSM05"] = "0";
                row["SLTSM06"] = "0";
                row["SLTSM07"] = "0";
                row["SLTSM08"] = "0";
                row["SLTSM09"] = "0";
                row["SLTSM10"] = "0";
                row["MDYCTT"]  = "0";
                row["MDYPZA"]  = "0";
                row["MDYCSB"]  = "0";
                row["MDYBDG"]  = "0";
                row["MDYOBC"]  = "0";
                row["MDYCBC"]  = "0";
                row["MDYUCP"]  = "0";
                row["MDYFCP"]  = "0";
                row["MDYHCP"]  = "0";
                row["MDYOBT"]  = "0";
                row["MDYCBT"]  = "0";
                row["MDYUCT"]  = "0";
                row["MDYFCT"]  = "0";
                row["MDYHCT"]  = "0";
                row["MDYUAL"]  = "0";
                row["MDYFAL"]  = "0";
                row["MDYHAL"]  = "0";
                row["MDYUCA"]  = "0";
                row["MDYFCA"]  = "0";
                row["MDYHCA"]  = "0";
                row["MDYMTX"]  = "0";
                row["MDYCLP"]  = "0";
                row["MDYCLA"]  = " ";
                #endregion

                dtConvenioMelody.Rows.Add(row);

                db2Reader.Close();

                return dtConvenioMelody;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenResumensTda(string marca, string comprador, string FchDe, string FchHas, string tipo, string temporada, string parTipoCalificacion, string parFchCalificacion, string parProveedor, string parNombre, string parEstilo, string parDescripcion)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConvenioMelody = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT MDYCDP Calificacion, count(MDYCDP)  Tiendas, Sum(MDYOHP + MDYTST) Inventario, cast(count(MDYCDP)  \n");
                sql.Append(" AS numeric(9,2))/(SELECT cast(count(MDYCDP) AS numeric(9,2)) FROM mmsatobj.sat177f60 \n");

                sql.AppendFormat(" WHERE  MDYMAR <> 0 \n");
                if (marca     != "999") { sql.AppendFormat(" and MDYMAR  = " + "'" + "{0}" + "'"   + "\n",       marca.PadLeft(3, '0')); }
                if (FchDe     != "0")   { sql.AppendFormat(" and MDYFCH between "  + "'"   + "{0}" + "'" + "\n", FchDe.PadLeft(6, '0')); }
                if (FchHas    != "0")   { sql.AppendFormat(" and " + "'" + "{0}"   + "'"   + "\n",               FchHas.PadLeft(6, '0')); }
                if (tipo      != "")    { sql.AppendFormat(" and MDYTPO  = " + "'" + "{0}" + "'"   + "\n",       tipo.PadRight(15, ' ')); }
                if (temporada != "")    { sql.AppendFormat(" and MDYTMP  = " + "'" + "{0}" + "'"   + "\n",       temporada.PadRight(3, ' ')); }

                if (parTipoCalificacion != "")    { sql.AppendFormat(" and MDYTPO  = " + "'" + "{0}" + "'" + "\n", parTipoCalificacion); }
                if (parFchCalificacion  != "")    { sql.AppendFormat(" and MDYFCH  = " + "'" + "{0}" + "'" + "\n", parFchCalificacion.PadLeft(6, '0')); }
                if (parProveedor        != "")    { sql.AppendFormat(" and MDYPRV  = " + "'" + "{0}" + "'" + "\n", parProveedor.PadLeft(6, '0')); }
                if (parNombre           != "")    { sql.AppendFormat(" and MDYPRVD like  " +   "'" +   "%" + "{0}" + "%" + "'" + "\n", parNombre); }
                if (parEstilo           != "")    { sql.AppendFormat(" and MDYSTY  = " + "'" + "{0}" + "'" + "\n", parEstilo); }
                if (parDescripcion      != "")    { sql.AppendFormat(" and MDYSTYD like  " +   "'" +   "%" + "{0}" + "%" + "'" + "\n", parDescripcion); }
                if (comprador           != "999") { sql.AppendFormat(" and MDYCOM  = " + "'" + "{0}" + "'" + "\n", comprador.PadRight(3, ' ')); }

                sql.Append(" ) Porcentaje FROM mmsatobj.sat177f60  \n");

                sql.AppendFormat(" WHERE  MDYMAR <> 0 \n");
                if (marca     != "999") { sql.AppendFormat(" and MDYMAR  = " + "'"   + "{0}" + "'"   + "\n",       marca.PadLeft(3, '0')); }
                if (FchDe     != "0")   { sql.AppendFormat(" and MDYFCH between "    + "'"   + "{0}" + "'" + "\n", FchDe.PadLeft(6, '0')); }
                if (FchHas    != "0")   { sql.AppendFormat(" and " + "'"     + "{0}" + "'"   + "\n",               FchHas.PadLeft(6, '0')); }
                if (tipo      != "")    { sql.AppendFormat(" and MDYTPO  = " + "'"   + "{0}" + "'"   + "\n",       tipo.PadRight(15, ' ')); }
                if (temporada != "")    { sql.AppendFormat(" and MDYTMP  = " + "'"   + "{0}" + "'"   + "\n",       temporada.PadRight(3, ' ')); }

                if (parTipoCalificacion != "")    { sql.AppendFormat(" and MDYTPO  = "    + "'" + "{0}" + "'"   + "\n", parTipoCalificacion); }
                if (parFchCalificacion  != "")    { sql.AppendFormat(" and MDYFCH  = "    + "'" + "{0}" + "'"   + "\n", parFchCalificacion.PadLeft(6, '0')); }
                if (parProveedor        != "")    { sql.AppendFormat(" and MDYPRV  = "    + "'" + "{0}" + "'"   + "\n", parProveedor.PadLeft(6, '0')); }
                if (parNombre           != "")    { sql.AppendFormat(" and MDYPRVD like " + "'" + "%"   + "{0}" + "%" + "'" + "\n", parNombre); }
                if (parEstilo           != "")    { sql.AppendFormat(" and MDYSTY  = "    + "'" + "{0}" + "'"   + "\n", parEstilo); }
                if (parDescripcion      != "")    { sql.AppendFormat(" and MDYSTYD like " + "'" + "%"   + "{0}" + "%" + "'" + "\n", parDescripcion); }
                if (comprador           != "999") { sql.AppendFormat(" and MDYCOM  = "    + "'" + "{0}" + "'"   + "\n", comprador.PadRight(3, ' ')); }

                sql.Append(" GROUP BY MDYCDP \n");
                sql.Append(" ORDER BY  CASE REPLACE(replace(replace(upper(MDYCDP), '%', ''), ' ', ''), 'Ó', 'O') \n");
                sql.Append(" WHEN '' THEN 0 \n"); // DESC \n");
                sql.Append(" WHEN 'PAGAR' THEN 0 \n"); // DESC \n");
                sql.Append(" WHEN 'DEVOLUCION' THEN 100 \n"); // DESC \n");
                sql.Append(" WHEN 'POSTERGAR' THEN 101 \n"); // DESC \n");
                sql.Append(" ELSE CAST(replace(replace(upper(MDYCDP), '%', ''), ' ', '') AS INT) END \n"); // DESC \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtConvenioMelody = new DataTable("ConvenioMelody");
                dtConvenioMelody.Load(db2Reader);

                DataRow row = dtConvenioMelody.NewRow();
                row["CALIFICACION"] = "Total";
                row["TIENDAS"] = 0;
                row["INVENTARIO"] = 0;
                row["PORCENTAJE"] = 0;
                dtConvenioMelody.Rows.Add(row);

                db2Reader.Close();

                return dtConvenioMelody;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable EjecutaConsultaTda(string marca, string comprador, string FchDe, string FchHas, string tipo, string temporada, string parTipoCalificacion, string parFchCalificacion, string parProveedor, string parNombre, string parEstilo, string parDescripcion, string usuario)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            DataTable dtConvenioMelody = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R68 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", comprador.PadLeft(3, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", FchDe.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", FchHas.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", parTipoCalificacion.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", temporada.PadRight(3, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", usuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C68 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", usuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader dbcall = db2Comm.ExecuteReader();
                dbcall.Close();

                sql.Clear();
                sql.Append("SELECT * \n");

                sql.Append("FROM " + LibSatObj + ".SAT177F68 T1\n");

                //sql.Append(" ORDER BY RSMCAL  ASC \n");
                sql.Append(" ORDER BY  CASE REPLACE(replace(replace(upper(RSMCAL), '%', ''), ' ', ''), 'Ó', 'O') \n");
                sql.Append(" WHEN '' THEN 0 \n"); // DESC \n");
                sql.Append(" WHEN 'PAGAR' THEN 0 \n"); // DESC \n");
                sql.Append(" WHEN 'DEVOLUCION' THEN 100 \n"); // DESC \n");
                sql.Append(" WHEN 'POSTERGAR' THEN 101 \n"); // DESC \n");
                sql.Append(" ELSE CAST(replace(replace(upper(RSMCAL), '%', ''), ' ', '') AS INT) END \n"); // DESC \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtConvenioMelody = new DataTable("ConvenioMelody");
                dtConvenioMelody.Load(db2Reader);

                DataRow row = dtConvenioMelody.NewRow();
                row["RSMCAL"] = "Total";
                row["RSMNTD"] = 0;
                row["RSMNST"] = 0;
                row["RSMINV"] = 0;
                row["RSMPOR"] = 0;
                row["RSMUSR"] = "0";
                row["RSMFCH"] = 0;
                row["RSMHOR"] = 0;
                dtConvenioMelody.Rows.Add(row);
                db2Reader.Close();

                return dtConvenioMelody;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenResumensGlobal(string marca, string comprador, string FchDe, string FchHas, string tipo, string temporada, string parTipoCalificacion, string parFchCalificacion, string parProveedor, string parNombre, string parEstilo, string parDescripcion)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtResumenGlobal = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT MDYCDP Calificacion, count(MDYSTY)  Estilos, SUM(MDYCRB) Recibo, sum(MDYCST * MDYCRB) Costo_Recibo, Sum(MDYOHP + MDYTST) Inventario, SUM(MDYCTT) Costo_Inventario ,SUM(MDYCSB) Bonificacion , cast(count(MDYSTY)  \n");
                sql.Append(" AS numeric(9,2))/(SELECT cast(count(MDYSTY) AS numeric(9,2)) FROM MMSATOBJ.SAT177F59 \n");

                sql.AppendFormat(" WHERE MDYFCH BETWEEN " + "'" + "{0}" + "'" + "\n", FchDe);
                sql.AppendFormat("   and   " + "'" + "{0}" + "'" + "\n", FchHas);
                if (marca != "999") { sql.AppendFormat(" and MDYMAR  = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0')); }
                if (parTipoCalificacion != "" && parTipoCalificacion != "Todas") { sql.AppendFormat("  and MDYTPO = " + "'" + "{0}" + "'" + "\n", parTipoCalificacion.PadRight(15, ' ')); }
                if (temporada != "" && temporada != "[999, Todos]") { sql.AppendFormat("  and MDYTMP = " + "'" + "{0}" + "'" + "\n", temporada.PadRight(3, ' ')); }
                if (comprador != "" && comprador != "[999, Todos]" && comprador != "999") { sql.AppendFormat("  and MDYCOM = " + "'" + "{0}" + "'" + "\n", comprador.PadRight(3, ' ')); }

                sql.Append(" ) Porcentaje FROM MMSATOBJ.SAT177F59  \n");

                sql.AppendFormat(" WHERE MDYFCH BETWEEN " + "'" + "{0}" + "'" + "\n", FchDe);
                sql.AppendFormat("   and   " + "'" + "{0}" + "'" + "\n", FchHas);
                if (marca != "999") { sql.AppendFormat(" and MDYMAR  = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0')); }
                if (parTipoCalificacion != "" && parTipoCalificacion != "Todas") { sql.AppendFormat("  and MDYTPO = " + "'" + "{0}" + "'" + "\n", parTipoCalificacion.PadRight(15, ' ')); }
                if (temporada != "" && temporada != "[999, Todos]") { sql.AppendFormat("  and MDYTMP = " + "'" + "{0}" + "'" + "\n", temporada.PadRight(3, ' ')); }
                if (comprador != "" && comprador != "[999, Todos]" && comprador != "999") { sql.AppendFormat("  and MDYCOM = " + "'" + "{0}" + "'" + "\n", comprador.PadRight(3, ' ')); }

                sql.Append(" GROUP BY MDYCDP \n");
                sql.Append(" ORDER BY  CASE REPLACE(replace(replace(upper(MDYCDP), '%', ''), ' ', ''), 'Ó', 'O') \n");
                sql.Append(" WHEN '' THEN 0 \n");             // DESC \n");
                sql.Append(" WHEN 'PAGAR' THEN 0 \n");        // DESC \n");
                sql.Append(" WHEN 'DEVOLUCION' THEN 100 \n"); // DESC \n");
                sql.Append(" WHEN 'POSTERGAR' THEN 101 \n");  // DESC \n");
                sql.Append(" ELSE CAST(replace(replace(upper(MDYCDP), '%', ''), ' ', '') AS INT) END \n"); // DESC \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtResumenGlobal = new DataTable("ConvenioMelody");
                dtResumenGlobal.Load(db2Reader);

                DataRow row = dtResumenGlobal.NewRow();
                row["CALIFICACION"] = "Total";
                row["ESTILOS"] = 0;
                row["RECIBO"] = 0;
                row["COSTO_RECIBO"] = 0;
                row["INVENTARIO"] = 0;
                row["COSTO_INVENTARIO"] = 0;
                row["BONIFICACION"] = 0;
                row["PORCENTAJE"] = 0;
                dtResumenGlobal.Rows.Add(row);

                db2Reader.Close();

                return dtResumenGlobal;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string EventoCalificacion(string temporada, string tablaPorc, string tablaPorc2, string anio, string semana, string columna, string marca, string tipo, string estatus, string usuario, string rentOdespl)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R55 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", temporada.PadRight(3, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", tablaPorc.PadLeft(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", tablaPorc2.PadLeft(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", anio.PadLeft(2, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", semana.PadLeft(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", columna.PadLeft(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", tipo.PadRight(3, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", estatus.PadRight(1, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", usuario.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", rentOdespl.PadRight(20, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                mensaje = "Proceso exitoso...";

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string UpdateTemporada(string temporada, string anio, string semana, string columna, string marca, string usuario, string campo)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("UPDATE " + LibSatObj + ".SAT177F54  SET \n");
                sql.AppendFormat(campo + " = " + "'" + "{0}" + "'" + "\n", temporada.PadRight(3, ' '));
                sql.AppendFormat("WHERE CPRMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat("and CPRANO   = " + "'" + "{0}" + "'" + "\n", anio.PadLeft(2, '0'));
                sql.AppendFormat("and CPRREN   = " + "'" + "{0}" + "'" + "\n", semana.PadLeft(3, '0'));

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                mensaje = "Proceso exitoso...";

                if (columna == "3" || columna == "4")
                {
                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT177F55  SET \n");
                    if (columna == "3") { sql.AppendFormat("CLTSEA       = " + "'" + "{0}" + "'" + "\n", temporada.PadRight(3, ' ')); };
                    if (columna == "4") { sql.AppendFormat("CLTTAB       = " + "'" + "{0}" + "'" + "\n", temporada.PadRight(3, ' ')); };                   
                    sql.AppendFormat("WHERE CLTMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat("and CLTANO   = " + "'" + "{0}" + "'" + "\n", anio.PadLeft(2, '0'));
                    sql.AppendFormat("and CLTREN   = " + "'" + "{0}" + "'" + "\n", semana.PadLeft(3, '0'));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Proceso exitoso...";
                }
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string EjecutaSimulacion(string anio, string temporada, string marca, string renglon, string columna, string usuario, string calificacion, string rentOdesplaz)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C59 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", anio.PadLeft(2, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", temporada.PadRight(3, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", renglon.PadLeft(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", columna.PadLeft(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", usuario.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", calificacion.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", rentOdesplaz.PadRight(20, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                mensaje = "Proceso exitoso...";

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string ObtenFechaMms(string anio, int semana, out string fechaMms)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtOnhandTransitoOnOrder = null;
            string stMensaje = string.Empty;
            fechaMms = "";

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear(); 
                sql.Append("SELECT DATLIT FROM MM610LIB.INVCALL2" + " \n");
                sql.AppendFormat(" WHERE DATCCN = " + "1" + " \n");
                if (semana <= 53)
                {
                    sql.AppendFormat(" and DATCYR = " + anio + " \n");
                    sql.AppendFormat(" and DATWKY = " + semana + " \n");
                }
                else
                {
                    sql.AppendFormat(" and DATCYR = " + (Convert.ToInt16(anio)+1) + " \n");
                    sql.AppendFormat(" and DATWKY = " + (semana - 53) + " \n");
                }
                sql.AppendFormat(" and DATDAY = " + "1" + " \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtOnhandTransitoOnOrder = new DataTable("OnHandTransito");
                dtOnhandTransitoOnOrder.Load(db2Reader);
                db2Reader.Close();

                if (dtOnhandTransitoOnOrder.Rows.Count > 0)
                {
                    foreach (DataRow row in dtOnhandTransitoOnOrder.Rows)
                    {
                        fechaMms = row[0].ToString();
                    }
                }

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return stMensaje;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return stMensaje;
        }

        public static string UpdatesCheckBoxCompras(string marca, string fecha, string tipo, string temporada, string tabla, string proveedor, string estilo,
                                                    string orden, string checkBox, string Observaciones, string usuario, string fechaUser, string horaUser)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                mensaje = "Fallo el CheckBox Update...";
                    try
                    {
                        sql.Clear();
                        sql.Append("UPDATE " + LibSatObj + ".SAT177F59 SET \n");

                        sql.AppendFormat("MDYOBC = " + "'" + "{0}" + "'" + "," + "\n", Observaciones);
                        sql.AppendFormat("MDYCBC = " + "'" + "{0}" + "'" + "," + "\n", checkBox.PadLeft(1, '0'));
                        sql.AppendFormat("MDYUCP = " + "'" + "{0}" + "'" + "," + "\n", usuario);
                        sql.AppendFormat("MDYFCP = " + "'" + "{0}" + "'" + "," + "\n", fechaUser);
                        sql.AppendFormat("MDYHCP = " + "'" + "{0}" + "'" + "\n", horaUser);

                        sql.Append("WHERE \n");
                        sql.AppendFormat("     MDYMAR = " + "'" + "{0}" + "'" + "\n", marca);
                        sql.AppendFormat(" and MDYFCH = " + "'" + "{0}" + "'" + "\n", fecha);
                        sql.AppendFormat(" and MDYTPO = " + "'" + "{0}" + "'" + "\n", tipo);
                        sql.AppendFormat(" and MDYTMP = " + "'" + "{0}" + "'" + "\n", temporada);
                        sql.AppendFormat(" and MDYTAB = " + "'" + "{0}" + "'" + "\n", tabla);
                        sql.AppendFormat(" and MDYPRV = " + "'" + "{0}" + "'" + "\n", proveedor);
                        sql.AppendFormat(" and MDYSTY = " + "'" + "{0}" + "'" + "\n", estilo);
                        sql.AppendFormat(" and MDYORD = " + "'" + "{0}" + "'" + "\n", orden);

                        db2Comm.CommandText = sql.ToString();
                        db2Comm.ExecuteNonQuery();

                        mensaje = "Proceso exitoso...";
                    }
                    catch { }

                    return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

            }
        }

        public static string UpdatesCheckBoxContraloria(string marca, string fecha, string tipo, string temporada, string tabla, string proveedor, string estilo,
                                                    string orden, string checkBox, string Observaciones, string usuario, string fechaUser, string horaUser)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                mensaje = "Fallo el CheckBox Update...";
                try
                {
                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT177F59 SET \n");

                    sql.AppendFormat("MDYOBT = " + "'" + "{0}" + "'" + "," + "\n", Observaciones);
                    sql.AppendFormat("MDYCBT = " + "'" + "{0}" + "'" + "," + "\n", checkBox.PadLeft(1, '0'));
                    sql.AppendFormat("MDYUCT = " + "'" + "{0}" + "'" + "," + "\n", usuario);
                    sql.AppendFormat("MDYFCT = " + "'" + "{0}" + "'" + "," + "\n", fechaUser);
                    sql.AppendFormat("MDYHCT = " + "'" + "{0}" + "'" + "\n", horaUser);

                    sql.Append("WHERE \n");
                    sql.AppendFormat("     MDYMAR = " + "'" + "{0}" + "'" + "\n", marca);
                    sql.AppendFormat(" and MDYFCH = " + "'" + "{0}" + "'" + "\n", fecha);
                    sql.AppendFormat(" and MDYTPO = " + "'" + "{0}" + "'" + "\n", tipo);
                    sql.AppendFormat(" and MDYTMP = " + "'" + "{0}" + "'" + "\n", temporada);
                    sql.AppendFormat(" and MDYTAB = " + "'" + "{0}" + "'" + "\n", tabla);
                    sql.AppendFormat(" and MDYPRV = " + "'" + "{0}" + "'" + "\n", proveedor);
                    sql.AppendFormat(" and MDYSTY = " + "'" + "{0}" + "'" + "\n", estilo);
                    sql.AppendFormat(" and MDYORD = " + "'" + "{0}" + "'" + "\n", orden);

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Proceso exitoso...";
                }
                catch { }

                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

            }
        }

        public static string UpdatesCheckBoxComprasTda(string marca, string fecha, string tipo, string temporada, string tabla, string tienda, string proveedor, string estilo,
                                            string orden, string checkBox, string Observaciones, string usuario, string fechaUser, string horaUser)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                mensaje = "Fallo el CheckBox Update...";
                try
                {
                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT177F60 SET \n");

                    sql.AppendFormat("MDYOBC = " + "'" + "{0}" + "'" + "," + "\n", Observaciones);
                    sql.AppendFormat("MDYCBC = " + "'" + "{0}" + "'" + "," + "\n", checkBox.PadLeft(1, '0'));
                    sql.AppendFormat("MDYUCP = " + "'" + "{0}" + "'" + "," + "\n", usuario);
                    sql.AppendFormat("MDYFCP = " + "'" + "{0}" + "'" + "," + "\n", fechaUser);
                    sql.AppendFormat("MDYHCP = " + "'" + "{0}" + "'" + "\n", horaUser);

                    sql.Append("WHERE \n");
                    sql.AppendFormat("     MDYMAR = " + "'" + "{0}" + "'" + "\n", marca);
                    sql.AppendFormat(" and MDYTDA = " + "'" + "{0}" + "'" + "\n", tienda);
                    sql.AppendFormat(" and MDYFCH = " + "'" + "{0}" + "'" + "\n", fecha);
                    sql.AppendFormat(" and MDYTPO = " + "'" + "{0}" + "'" + "\n", tipo);
                    sql.AppendFormat(" and MDYTMP = " + "'" + "{0}" + "'" + "\n", temporada);
                    sql.AppendFormat(" and MDYTAB = " + "'" + "{0}" + "'" + "\n", tabla);
                    sql.AppendFormat(" and MDYPRV = " + "'" + "{0}" + "'" + "\n", proveedor);
                    sql.AppendFormat(" and MDYSTY = " + "'" + "{0}" + "'" + "\n", estilo);
                    sql.AppendFormat(" and MDYORD = " + "'" + "{0}" + "'" + "\n", orden);

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Proceso exitoso...";
                }
                catch { }

                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

            }
        }

        public static string UpdatesCheckBoxContraloriaTda(string marca, string fecha, string tipo, string temporada, string tabla, string tienda, string proveedor, string estilo,
                                                    string orden, string checkBox, string Observaciones, string usuario, string fechaUser, string horaUser)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                mensaje = "Fallo el CheckBox Update...";
                try
                {
                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT177F60 SET \n");

                    sql.AppendFormat("MDYOBT = " + "'" + "{0}" + "'" + "," + "\n", Observaciones);
                    sql.AppendFormat("MDYCBT = " + "'" + "{0}" + "'" + "," + "\n", checkBox.PadLeft(1, '0'));
                    sql.AppendFormat("MDYUCT = " + "'" + "{0}" + "'" + "," + "\n", usuario);
                    sql.AppendFormat("MDYFCT = " + "'" + "{0}" + "'" + "," + "\n", fechaUser);
                    sql.AppendFormat("MDYHCT = " + "'" + "{0}" + "'" + "\n", horaUser);

                    sql.Append("WHERE \n");
                    sql.AppendFormat("     MDYMAR = " + "'" + "{0}" + "'" + "\n", marca);
                    sql.AppendFormat(" and MDYTDA = " + "'" + "{0}" + "'" + "\n", tienda);
                    sql.AppendFormat(" and MDYFCH = " + "'" + "{0}" + "'" + "\n", fecha);
                    sql.AppendFormat(" and MDYTPO = " + "'" + "{0}" + "'" + "\n", tipo);
                    sql.AppendFormat(" and MDYTMP = " + "'" + "{0}" + "'" + "\n", temporada);
                    sql.AppendFormat(" and MDYTAB = " + "'" + "{0}" + "'" + "\n", tabla);
                    sql.AppendFormat(" and MDYPRV = " + "'" + "{0}" + "'" + "\n", proveedor);
                    sql.AppendFormat(" and MDYSTY = " + "'" + "{0}" + "'" + "\n", estilo);
                    sql.AppendFormat(" and MDYORD = " + "'" + "{0}" + "'" + "\n", orden);

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Proceso exitoso...";
                }
                catch { }

                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

            }
        }

        public static DataTable ObtenRebajaDiferenciada(string marca, string comprador, String FchDe, String FchHas, string ParProveedor, string PartbNombre, string PartbEstilo, string ParDescripcion)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtBonifica = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT  \n");

                sql.Append("RBDFBO, \n");   //00 Fecha Bonifica
                sql.Append("RBDTPO,  \n");  //01 Tipo
                sql.Append("RBDTMP,  \n");  //02 Temporada
                sql.Append("RBDSTR,  \n");  //03 Tienda
                sql.Append("RBDNAM,  \n");  //04 Nombre Tienda
                sql.Append("RBDPRV,  \n");  //05 Proveedor
                sql.Append("RBDPRN,  \n");  //06 Nombre
                sql.Append("RBDSTY,  \n");  //07 Estilo
                sql.Append("RBDDES,  \n");  //08 Descripcion
                sql.Append("RBDDCP,  \n");  //09 Comprador
                sql.Append("RBDFCM,  \n");  //10 Fecha Compra
                sql.Append("RBDFRE,  \n");  //11 Fecha Revision
                sql.Append("RBDPZA,  \n");  //12 Piezas
                sql.Append("RBDVTA,  \n");  //13 Venta
                sql.Append("RBDONH,  \n");  //14 OnHand
                sql.Append("RBDPVT,  \n");  //15 % Ventas
                sql.Append("RBDCAL,  \n");  //16 Calificacion
                sql.Append("RBDTAB,  \n");  //17 Tabla de Accion
                sql.Append("RBDNOT,  \n");  //18 Nota Credito
                sql.Append("RBDSUB,  \n");  //19 Sub_Tot
                sql.Append("RBDIVA,  \n");  //20 Iva 
                sql.Append("RBDTOT,  \n");  //21 Total
                sql.Append("RBDPBO,  \n");  //22 % Bonificacion
                sql.Append("RBDCST,  \n");  //23 Costo Actual
                sql.Append("RBDPRC,  \n");  //24 Precio Actual
                sql.Append("RBDMRG,  \n");  //25 Margen Actual
                sql.Append("RBDCST1, \n");  //26 Costo Nuevo
                sql.Append("RBDPRC1, \n");  //27 Precio Nuevo
                sql.Append("RBDMRG1, \n");  //28 Margen Nuevo
                sql.Append("RBDCST2, \n");  //29 Costo Final
                sql.Append("RBDPRC2, \n");  //30 Precio Final
                sql.Append("RBDMRG2, \n");  //31 Margen Final 
                sql.Append("RBDCMP,  \n");  //32 Compras Obs 
                sql.Append("RBDTAB2, \n");  //33 Tabla de Accion 2 
                sql.Append("RBDCSTD, \n");  //34 Diferecia Consto  
                sql.Append("RBDPZA1, \n");  //35 Piezas On Hand
                sql.Append("RBDIMP1, \n");  //36 Importe'On Hand 
                sql.Append("RBDPRO,  \n");  //37 Promocion

                sql.Append("RBDDCF2, \n");  //38 Dif Cst Final  
                sql.Append("RBDIDC2, \n");  //39 Imp OH Dif Cst
                sql.Append("RBDIMF2, \n");  //40 Imp Mrg Final

                sql.Append("RBDTABF, \n");  //41 Tabla de Accion Final  
                sql.Append("RBDMAR,  \n");  //42 Marca
                sql.Append("RBDCID,  \n");  //43 Comprador
                sql.Append("RBDBDG,  \n");  //44 Bodega
                sql.Append("RBDCK1,  \n");  //45 Compras
                sql.Append("RBDCK2,  \n");  //46 Contraloria
                sql.Append("RBDNMR,  \n");  //47 Marca
                sql.Append("RBDFCHA, \n");  //48 Fecha 
                sql.Append("RBDHORA, \n");  //49 Hora
                sql.Append("RBDUSR,  \n");  //50 Usuario
                sql.Append("RBDERR,  \n");  //51 Error
                sql.Append("RBDCLF,  \n");  //52 Correo Electronico
                sql.Append("RBDCXO,  \n");  //53 Cal x Omision
                sql.Append("RBDIDE,  \n");  //54 Ident. Estilos
                sql.Append("RBDRCS,  \n");  //55 Rebaja Costos 
                sql.Append("RBDRPR,  \n");  //56 Rebaja Precios
                sql.Append("RBDDEV,  \n");  //57 Devoluciones
                sql.Append("RBDCFA,  \n");  //58 Carga Facturas
                sql.Append("RBDPOL,  \n");  //59 Poliza Contable
                sql.Append("RBDCK3,  \n");  //60 Sts Correo
                sql.Append("RBDCK4,  \n");  //61 Sts Cal x Omi
                sql.Append("RBDCK5,  \n");  //62 Sts Ident
                sql.Append("RBDCK6,  \n");  //63 Sts  Costos
                sql.Append("RBDCK7,  \n");  //64 Sts Precios
                sql.Append("RBDCK8,  \n");  //65 Sts Dev
                sql.Append("RBDCK9,  \n");  //66 Sts Facturas
                sql.Append("RBDCK10, \n");  //67 Sts Poliza
                sql.Append("RBDNCS   \n");  //68 Nc PDF 

                sql.Append(" FROM    \n");  //
                sql.Append(" " + LibSatObj + ".SAT177F25 \n");

                if (FchDe != "")
                {
                    sql.AppendFormat(" WHERE RBDFBO BETWEEN " + "'" + "{0}" + "'" + "\n", FchDe);
                    sql.AppendFormat(" AND " + "'" + "{0}" + "'" + "\n", FchHas);

                    if (marca != "999") { sql.AppendFormat(" and RBDNMR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0')); }
                    if (comprador != "999") { sql.AppendFormat(" and RBDCID IN " + "(" + "{0}" + ")" + "\n", comprador.PadRight(3, ' ')); }

                    if (ParProveedor != "") { sql.AppendFormat(" and RBDPRV = " + "'" + "{0}" + "'" + "\n", ParProveedor); }
                    if (PartbNombre != "") { sql.AppendFormat(" and RBDPRN LIKE " + "'%" + "{0}" + "%'" + "\n", PartbNombre); }
                    if (PartbEstilo != "") { sql.AppendFormat(" and RBDSTY = " + "'" + "{0}" + "'" + "\n", PartbEstilo); }
                    if (ParDescripcion != "") { sql.AppendFormat(" and RBDDES LIKE " + "'%" + "{0}" + "%'" + "\n", ParDescripcion); }
                }

                sql.Append(" ORDER BY RBDCAL, RBDPRV, RBDSTY  ASC\n"); // Ordenado por Proveedor

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtBonifica = new DataTable("Bonificaciones");
                dtBonifica.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            return dtBonifica;
        }

        public static void EliminaRebajaDiferenciada(string ParFchBon, string ParFchRev, string ParTipoCal, string ParTemporada, string ParTienda, string ParProveedor, string ParEstilo)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("DELETE FROM " + LibSatObj + ".SAT177F25 WHERE\n");
                sql.Append(" RBDFBO = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParFchBon.PadLeft(6, '0'));
                sql.Append(" AND RBDFRE = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParFchRev.PadLeft(6, '0'));
                sql.Append(" AND RBDTPO = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParTipoCal.PadRight(15, ' '));
                sql.Append(" AND RBDTMP = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParTemporada.PadRight(3, ' '));
                sql.Append(" AND RBDSTR = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParTienda.PadLeft(6, '0'));
                sql.Append(" AND RBDPRV = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParProveedor.PadLeft(6, '0'));
                sql.Append(" AND RBDSTY = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParEstilo.PadRight(15, ' '));

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

            }
            catch
            { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenRutaPDFRebajaDiferenciada(String ParFchBon, String ParFchRev, String ParTipoCal, String ParTemporada, String ParTienda, String ParProveedor, String ParEstilo, String ParNota)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtRutaPDF = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT RDDRUT FROM  " + LibSatObj + ".SAT177F35 \n");

                sql.AppendFormat(" WHERE RDDBON = " + "'" + "{0}" + "'" + "\n", ParFchBon.PadLeft(6, '0'));
                sql.AppendFormat(" and RDDFRE   = " + "'" + "{0}" + "'" + "\n", ParFchRev.PadLeft(6, '0'));
                sql.AppendFormat(" and RDDTPO   = " + "'" + "{0}" + "'" + "\n", ParTipoCal.PadRight(15, ' '));
                sql.AppendFormat(" and RDDTMP   = " + "'" + "{0}" + "'" + "\n", ParTemporada.PadRight(3, ' '));
                sql.AppendFormat(" and RDDSTR   = " + "'" + "{0}" + "'" + "\n", ParTienda.PadLeft(5, '0'));
                sql.AppendFormat(" and RDDPRV   = " + "'" + "{0}" + "'" + "\n", ParProveedor.PadLeft(6, '0'));
                sql.AppendFormat(" and RDDSTY   = " + "'" + "{0}" + "'" + "\n", ParEstilo.PadRight(15, ' ')); ;
                sql.AppendFormat(" and RDDNOT   = " + "'" + "{0}" + "'" + "\n", ParNota.PadRight(20, ' '));

                db2Comm.CommandText       = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtRutaPDF = new DataTable("RebajasDiferenciadas");
                dtRutaPDF.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            return dtRutaPDF;
        }

        public static DataTable UpdateRebajaDiferenciada(DataTable dtRebajaDiferenciada)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                foreach (DataRow row in dtRebajaDiferenciada.Rows)
                {
                    string FechaBon      = row["FechaBon"].ToString();
                    string FechaRev      = row["FechaRev"].ToString();
                    string TipoCal       = row["TipoCal"].ToString();
                    string Temporada     = row["Temporada"].ToString();
                    string Tienda        = row["Tienda"].ToString();
                    string Proveedor     = row["Proveedor"].ToString();
                    string Estilo        = row["Estilo"].ToString();

                    string NotaCred      = row["NotaCred"].ToString();
                    string SubTotal      = row["SubTotal"].ToString();
                    string Iva           = row["Iva"].ToString();
                    string Total         = row["Total"].ToString();
                    string PorcBon       = row["PorcBon"].ToString();
                    string CostoAct      = row["CostoAct"].ToString();
                    string PrecioAct     = row["PrecioAct"].ToString();
                    string MargenAct     = row["MargenAct"].ToString();
                    string CostoNuev     = row["CostoNuev"].ToString();
                    string PrecioNuev    = row["PrecioNuev"].ToString();
                    string MargenNuev    = row["MargenNuev"].ToString();
                    string CostiFinal    = row["CostiFinal"].ToString();
                    string PrecioFinal   = row["PrecioFinal"].ToString();
                    string MargenFinal   = row["MargenFinal"].ToString();
                    string Observaciones = row["Observaciones"].ToString();
                    string TablaAccion2  = row["TablaAccion2"].ToString();
                    string TablaAccion   = row["TablaAccion"].ToString();
                    string Compras       = row["Compras"].ToString();
                    string Contraloria   = row["Contraloria"].ToString();
                    string DifCostoFinal = row["DifCostoFinal"].ToString();
                    string ImporteOnHand = row["ImporteOnHand"].ToString();
                    string ImporteMargen = row["ImporteMargen"].ToString();

                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT177F25 SET \n");
                    sql.AppendFormat("RBDNOT  = " + "'" + "{0}" + "'" + "," + "\n", NotaCred.PadRight(20, ' '));
                    sql.AppendFormat("RBDSUB  = " + "'" + "{0}" + "'" + "," + "\n", SubTotal.PadLeft(13, ' '));
                    sql.AppendFormat("RBDIVA  = " + "'" + "{0}" + "'" + "," + "\n", Iva.PadLeft(11, ' '));
                    sql.AppendFormat("RBDTOT  = " + "'" + "{0}" + "'" + "," + "\n", Total.PadLeft(13, ' '));
                    sql.AppendFormat("RBDPBO  = " + "'" + "{0}" + "'" + "," + "\n", PorcBon.PadLeft(9, ' '));
                    sql.AppendFormat("RBDCST  = " + "'" + "{0}" + "'" + "," + "\n", CostoAct.PadLeft(13, ' '));
                    sql.AppendFormat("RBDPRC  = " + "'" + "{0}" + "'" + "," + "\n", PrecioAct.PadLeft(13, ' '));
                    sql.AppendFormat("RBDMRG  = " + "'" + "{0}" + "'" + "," + "\n", MargenAct.PadLeft(13, ' '));
                    sql.AppendFormat("RBDCST1 = " + "'" + "{0}" + "'" + "," + "\n", CostoNuev.PadLeft(13, ' '));
                    sql.AppendFormat("RBDPRC1 = " + "'" + "{0}" + "'" + "," + "\n", PrecioNuev.PadLeft(13, ' '));
                    sql.AppendFormat("RBDMRG1 = " + "'" + "{0}" + "'" + "," + "\n", MargenNuev.PadLeft(13, ' '));
                    sql.AppendFormat("RBDCST2 = " + "'" + "{0}" + "'" + "," + "\n", CostiFinal.PadLeft(13, ' '));
                    sql.AppendFormat("RBDPRC2 = " + "'" + "{0}" + "'" + "," + "\n", PrecioFinal.PadRight(13, ' '));

                    try
                    {
                        double margen, costo, precio;
                        margen = 0; costo = 0; precio = 0;
                        costo = Convert.ToDouble(CostiFinal);
                        precio = Convert.ToDouble(PrecioFinal);
                        if (costo != 0 && precio != 0)
                        {
                            margen = (1 - (costo / (precio / 1.16))) * 100;
                            MargenFinal = Convert.ToString(margen);
                        }
                    }
                    catch { }

                    sql.AppendFormat("RBDMRG2 = " + "'" + "{0}" + "'" + "," + "\n", MargenFinal.PadRight(13, ' '));

                    sql.AppendFormat("RBDCMP  = " + "'" + "{0}" + "'" + "," + "\n", Observaciones.PadRight(150, ' '));
                    sql.AppendFormat("RBDTAB2 = " + "'" + "{0}" + "'" + "," + "\n", TablaAccion2.PadRight(2, ' '));
                    sql.AppendFormat("RBDTABF = " + "'" + "{0}" + "'" + "," + "\n", TablaAccion.PadRight(2, ' '));
                    sql.AppendFormat("RBDCK1  = " + "'" + "{0}" + "'" + "," + "\n", Compras.PadLeft(1, '0'));
                    sql.AppendFormat("RBDCK2  = " + "'" + "{0}" + "'" + "," + "\n", Contraloria.PadLeft(1, '0'));

                    sql.AppendFormat("RBDDCF2 = " + "'" + "{0}" + "'" + "," + "\n", DifCostoFinal.PadLeft(13, '0'));
                    sql.AppendFormat("RBDIDC2 = " + "'" + "{0}" + "'" + "," + "\n", ImporteOnHand.PadLeft(13, '0'));
                    sql.AppendFormat("RBDIMF2 = " + "'" + "{0}" + "'" + "\n", ImporteMargen.PadLeft(13, '0'));

                    sql.Append("WHERE \n");
                    sql.AppendFormat("RBDFBO = " + "'" + "{0}" + "'" + "\n", FechaBon.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("RBDFRE = " + "'" + "{0}" + "'" + "\n", FechaRev.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("RBDTPO = " + "'" + "{0}" + "'" + "\n", TipoCal.PadRight(15, ' '));
                    sql.Append("AND \n");
                    sql.AppendFormat("RBDTMP = " + "'" + "{0}" + "'" + "\n", Temporada.PadRight(3, ' '));
                    sql.Append("AND \n");
                    sql.AppendFormat("RBDSTR = " + "'" + "{0}" + "'" + "\n", Tienda.PadLeft(5, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("RBDPRV = " + "'" + "{0}" + "'" + "\n", Proveedor.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("RBDSTY = " + "'" + "{0}" + "'" + "\n", Estilo.PadRight(15, ' '));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();
                }
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtRebajaDiferenciada;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable UpdateCheckBoxRebajaDiferenciada(DataTable dtCheckBox)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                foreach (DataRow row in dtCheckBox.Rows)
                {
                    string FechaBon     = row["FechaBon"].ToString();
                    string FechaRev     = row["FechaRev"].ToString();
                    string TipoCal      = row["TipoCal"].ToString();
                    string Temporada    = row["Temporada"].ToString();
                    string Tienda       = row["Tienda"].ToString();
                    string Proveedor    = row["Proveedor"].ToString();
                    string Estilo       = row["Estilo"].ToString();

                    string Correo       = row["Correo"].ToString();
                    string Cor1         = row["Cor1"].ToString();
                    string CalxOmi      = row["CalxOmi"].ToString();
                    string Cal1         = row["Cal1"].ToString();
                    string Identif      = row["Identif"].ToString();
                    string Ide1         = row["Ide1"].ToString();
                    string Costo        = row["Costo"].ToString();
                    string Cos1         = row["Cos1"].ToString();
                    string Precio       = row["Precio"].ToString();
                    string Pre1         = row["Pre1"].ToString();
                    string Devolucion   = row["Devolucion"].ToString();
                    string Dev1         = row["Dev1"].ToString();
                    string FactEmit     = row["FactEmit"].ToString();
                    string Fac1         = row["Fac1"].ToString();
                    string Poliza1      = row["Poliza1"].ToString();
                    string Pol1         = row["Pol1"].ToString();

                    string stCorreo     = row["stCorreo"].ToString();
                    string stCor1       = row["stCor1"].ToString();
                    string stCalxOmi    = row["stCalxOmi"].ToString();
                    string stCal1       = row["stCal1"].ToString();
                    string stIdentif    = row["stIdentif"].ToString();
                    string stIde1       = row["stIde1"].ToString();
                    string stCosto      = row["stCosto"].ToString();
                    string stCos1       = row["stCos1"].ToString();
                    string stPrecio     = row["stPrecio"].ToString();
                    string stPre1       = row["stPre1"].ToString();
                    string stDevolucion = row["stDevolucion"].ToString();
                    string stDev1       = row["stDev1"].ToString();
                    string stFactEmit   = row["stFactEmit"].ToString();
                    string stFac1       = row["stFac1"].ToString();
                    string stPoliza1    = row["stPoliza1"].ToString();
                    string stPol1       = row["stPol1"].ToString();

                    string Compras      = row["Compras"].ToString();
                    string Com1         = row["Com1"].ToString();
                    string Contraloria  = row["Contraloria"].ToString();
                    string Con1         = row["Con1"].ToString();

                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT177F25 SET \n");

                    Int32 segundo = 0;
                    if (Cor1 == "1") { sql.AppendFormat("RBDCLF = " + "'" + "{0}" + "'" + "\n", Correo.PadLeft(1, '0')); }
                    if (Cor1 == "1") { segundo++; } if (Cal1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Cal1 == "1") { sql.AppendFormat("RBDCXO = " + "'" + "{0}" + "'" + "\n", CalxOmi.PadLeft(1, '0')); }
                    if (Cal1 == "1") { segundo++; } if (Ide1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Ide1 == "1") { sql.AppendFormat("RBDIDE = " + "'" + "{0}" + "'" + "\n", Identif.PadLeft(1, '0')); }
                    if (Ide1 == "1") { segundo++; } if (Cos1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Cos1 == "1") { sql.AppendFormat("RBDRCS = " + "'" + "{0}" + "'" + "\n", Costo.PadLeft(1, '0')); }
                    if (Cos1 == "1") { segundo++; } if (Pre1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Pre1 == "1") { sql.AppendFormat("RBDRPR = " + "'" + "{0}" + "'" + "\n", Precio.PadLeft(1, '0')); }
                    if (Pre1 == "1") { segundo++; } if (Dev1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Dev1 == "1") { sql.AppendFormat("RBDDEV = " + "'" + "{0}" + "'" + "\n", Devolucion.PadLeft(1, '0')); }
                    if (Dev1 == "1") { segundo++; } if (Fac1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Fac1 == "1") { sql.AppendFormat("RBDCFA = " + "'" + "{0}" + "'" + "\n", FactEmit.PadLeft(1, '0')); }
                    if (Fac1 == "1") { segundo++; } if (Pol1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Pol1 == "1") { sql.AppendFormat("RBDPOL = " + "'" + "{0}" + "'" + "\n", Poliza1.PadLeft(1, '0')); }
                    if (Pol1 == "1") { segundo++; } if (stCor1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                    if (stCor1 == "1") { sql.AppendFormat("RBDCK3 = " + "'" + "{0}" + "'" + "\n", stCorreo.PadLeft(1, '0')); }
                    if (stCor1 == "1") { segundo++; } if (stCal1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (stCal1 == "1") { sql.AppendFormat("RBDCK4 = " + "'" + "{0}" + "'" + "\n", stCalxOmi.PadLeft(1, '0')); }
                    if (stCal1 == "1") { segundo++; } if (stIde1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (stIde1 == "1") { sql.AppendFormat("RBDCK5 = " + "'" + "{0}" + "'" + "\n", stIdentif.PadLeft(1, '0')); }
                    if (stIde1 == "1") { segundo++; } if (stCos1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (stCos1 == "1") { sql.AppendFormat("RBDCK6 = " + "'" + "{0}" + "'" + "\n", stCosto.PadLeft(1, '0')); }
                    if (stCos1 == "1") { segundo++; } if (stPre1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (stPre1 == "1") { sql.AppendFormat("RBDCK7 = " + "'" + "{0}" + "'" + "\n", stPrecio.PadLeft(1, '0')); }
                    if (stPre1 == "1") { segundo++; } if (stDev1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (stDev1 == "1") { sql.AppendFormat("RBDCK8 = " + "'" + "{0}" + "'" + "\n", stDevolucion.PadLeft(1, '0')); }
                    if (stDev1 == "1") { segundo++; } if (stFac1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (stFac1 == "1") { sql.AppendFormat("RBDCK9 = " + "'" + "{0}" + "'" + "\n", stFactEmit.PadLeft(1, '0')); }
                    if (stFac1 == "1") { segundo++; } if (stPol1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (stPol1 == "1") { sql.AppendFormat("RBDCK10 = " + "'" + "{0}" + "'" + "\n", stPoliza1.PadLeft(1, '0')); }
                    if (stPol1 == "1") { segundo++; } if (Com1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }

                    if (Com1 == "1") { sql.AppendFormat("RBDCK1 = " + "'" + "{0}" + "'" + "\n", Compras.PadLeft(1, '0')); }
                    if (Com1 == "1") { segundo++; } if (Con1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Con1 == "1") { sql.AppendFormat("RBDCK2 = " + "'" + "{0}" + "'" + "\n", Contraloria.PadLeft(1, '0')); }

                    sql.Append("WHERE \n");
                    sql.AppendFormat("RBDFBO = " + "'" + "{0}" + "'" + "\n", FechaBon.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("RBDFRE = " + "'" + "{0}" + "'" + "\n", FechaRev.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("RBDTPO = " + "'" + "{0}" + "'" + "\n", TipoCal.PadRight(15, ' '));
                    sql.Append("AND \n");
                    sql.AppendFormat("RBDTMP = " + "'" + "{0}" + "'" + "\n", Temporada.PadRight(3, ' '));
                    sql.Append("AND \n");
                    sql.AppendFormat("RBDSTR = " + "'" + "{0}" + "'" + "\n", Tienda.PadLeft(5, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("RBDPRV = " + "'" + "{0}" + "'" + "\n", Proveedor.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("RBDSTY = " + "'" + "{0}" + "'" + "\n", Estilo.PadRight(15, ' '));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();
                }
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtCheckBox;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        
        public static DataTable ObtenTablasPorc(string marca, string tabla)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtTablasPorc = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("DTBMAR,  \n");  //00 Marca
                sql.Append("DTBNTB,  \n");  //01 Tabla
                sql.Append("DTBSEC,  \n");  //02 Secuencia
                sql.Append("DTBDEL,  \n");  //03 Del %
                sql.Append("DTBAL,   \n");  //04 Al %
                sql.Append("DTBPOR,  \n");  //05 Porcentaje
                sql.Append("DTBCAL,  \n");  //06 Calificación 
                sql.Append("DTBSTS,  \n");  //07 Estatus 
                sql.Append("DTBUAL,  \n");  //08 Usuario Alta 
                sql.Append("DTBFAL,  \n");  //09 Fecha Alta 
                sql.Append("DTBHAL,  \n");  //10 Hora de Alta  
                sql.Append("DTBUCA,  \n");  //11 Usuario Cambio 
                sql.Append("DTBFCA,  \n");  //12 Fecha Cambio 
                sql.Append("DTBHCA   \n");  //13 Hora Cambio 

                sql.Append("FROM " + LibSatObj + ".SAT177F53 T1\n");
                sql.AppendFormat(" WHERE  DTBFAL <> 0 \n");
                if (marca != "") { sql.AppendFormat(" and DTBMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0')); }
                if (tabla != "") { sql.AppendFormat(" and DTBNTB = " + "'" + "{0}" + "'" + "\n", tabla.PadLeft(3, '0')); }

                sql.Append(" ORDER BY DTBMAR, DTBNTB, DTBSEC  \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtTablasPorc = new DataTable("TablasDePorcentajes");
                dtTablasPorc.Load(db2Reader);
                db2Reader.Close();

                return dtTablasPorc;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string InsertTablasporc(string marca, string tabla, string secuencia, string delr, string alr, string porcentaje, string calificacion, string estatus, string userAlta, string fechaAlta, string horaAlta, string userCambio, string fechaCambio, string horaCambio)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtExist = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                    sql.Clear();
                    sql.Append("SELECT   \n");
                    sql.Append("DTBMAR,  \n");  //00 Marca
                    sql.Append("DTBNTB,  \n");  //01 Tabla
                    sql.Append("DTBSEC   \n");  //02 Secuencia

                    sql.Append("FROM " + LibSatObj + ".SAT177F53 T1\n");
                    sql.AppendFormat(" WHERE \n");
                    sql.AppendFormat("     DTBMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat(" and DTBNTB = " + "'" + "{0}" + "'" + "\n", tabla.PadLeft(3, '0'));
                    sql.AppendFormat(" and DTBSEC = " + "'" + "{0}" + "'" + "\n", secuencia.PadLeft(3, '0'));

                    db2Comm.CommandText = sql.ToString();
                    OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                    dtExist = new DataTable("TablasDePorcentajes");
                    dtExist.Load(db2Reader);

                    if (dtExist.Rows.Count > 0)
                    {
                        mensaje = "El Registro ya existe...";
                    }
                    else
                    {
                        sql.Clear();
                        sql.Append("Insert Into \n"); //00 Comando 
                        sql.Append(" " + LibSatObj + ".SAT177F53 (\n");
                        sql.Append("DTBMAR, \n");     //00 Marca
                        sql.Append("DTBNTB, \n");     //00 Tabla
                        sql.Append("DTBSEC, \n");     //00 Secuencia

                        sql.Append("DTBDEL, \n");     //00 Del Rango
                        sql.Append("DTBAL, \n");      //00 Al Rango 
                        sql.Append("DTBPOR, \n");     //00 %
                        sql.Append("DTBCAL, \n");     //00 Calificacion

                        sql.Append("DTBSTS, \n");     //04 Estatus

                        sql.Append("DTBUAL, \n");     //05 Usuario de Alta
                        sql.Append("DTBFAL, \n");     //06 Fecha de Alta
                        sql.Append("DTBHAL, \n");     //04 Hora de Alta
                        sql.Append("DTBUCA, \n");     //04 Usuario de Cambio
                        sql.Append("DTBFCA, \n");     //04 Fecha de Cambio 
                        sql.Append("DTBHCA )\n");     //04 Hora de Cambio 


                        sql.Append("Values \n"); //    00 Lista de Valores a grabar

                        sql.AppendFormat("(" + "'" + "{0}" + "'" + "," + "\n", marca);       //00 Lista
                        sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", tabla);       //01 Correo
                        sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", secuencia);   //02 Nombre 

                        sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", delr);   //02 Nombre 
                        sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", alr);   //02 Nombre 
                        sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", porcentaje);   //02 Nombre 
                        sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", calificacion);   //02 Nombre 

                        sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", estatus);     //06 Hora de Alta 
                        sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", userAlta);    //04 Usuairo 
                        sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", fechaAlta);   //05 Fecha de alta 
                        sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", horaAlta);    //06 Hora de Alta
                        sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", ' ');         //04 Usuairo 
                        sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", '0');         //05 Fecha de alta 
                        sql.AppendFormat(" " + "'" + "{0}" + "'" + ")" + "\n", '0');         //06 Hora de Alta

                        db2Comm.CommandText = sql.ToString();
                        db2Comm.ExecuteNonQuery();

                        mensaje = "Se guardo el registro exitosamente...";
                    }
                    db2Reader.Close();
                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string UpdateTablasporc(string marca, string tabla, string secuencia, string delr, string alr, string porcentaje, string calificacion, string estatus, string userAlta, string fechaAlta, string horaAlta, string userCambio, string fechaCambio, string horaCambio)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtExist = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("DTBMAR,  \n");  //00 Marca
                sql.Append("DTBNTB,  \n");  //01 Tabla
                sql.Append("DTBSEC   \n");  //02 Secuencia

                sql.Append("FROM " + LibSatObj + ".SAT177F53 T1\n");
                sql.AppendFormat(" WHERE \n");
                sql.AppendFormat("     DTBMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat(" and DTBNTB = " + "'" + "{0}" + "'" + "\n", tabla.PadLeft(3, '0'));
                sql.AppendFormat(" and DTBSEC = " + "'" + "{0}" + "'" + "\n", secuencia.PadLeft(3, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                dtExist = new DataTable("TablasDePorcentajes");
                dtExist.Load(db2Reader);

                if (dtExist.Rows.Count == 0)
                {
                    mensaje = "El Registro no existe...";
                }
                else
                {
                    sql.Clear();
                    sql.Append("Update  \n"); 
                    sql.Append(" " + LibSatObj + ".SAT177F53 \n");
                    sql.Append("set \n"); 

                    //sql.AppendFormat("DTBMAR = " + "'" + "{0}" + "'" + "," + "\n", marca);       //00 Lista
                    //sql.AppendFormat("DTBNTB = " + "'" + "{0}" + "'" + "," + "\n", tabla);      //01 Correo
                    sql.AppendFormat("DTBSEC = " + "'" + "{0}" + "'" + "," + "\n", secuencia);      //02 Nombre 

                    sql.AppendFormat("DTBDEL = " + "'" + "{0}" + "'" + "," + "\n", delr);          //02 Nombre 
                    sql.AppendFormat("DTBAL = " + "'" + "{0}" + "'" + "," + "\n", alr);             //02 Nombre 
                    sql.AppendFormat("DTBPOR = " + "'" + "{0}" + "'" + "," + "\n", porcentaje);      //02 Nombre 
                    sql.AppendFormat("DTBCAL = " + "'" + "{0}" + "'" + "," + "\n", calificacion);      //02 Nombre 

                    sql.AppendFormat("DTBSTS = " + "'" + "{0}" + "'" + "," + "\n", estatus);    //06 Hora de Alta 
                    sql.AppendFormat("DTBUAL = " + "'" + "{0}" + "'" + "," + "\n", userAlta);   //04 Usuairo 
                    sql.AppendFormat("DTBFAL = " + "'" + "{0}" + "'" + "," + "\n", fechaAlta.PadLeft(6, '0'));  //05 Fecha de alta 
                    sql.AppendFormat("DTBHAL = " + "'" + "{0}" + "'" + "," + "\n", horaAlta.PadLeft(6, '0'));  //06 Hora de Alta
                    sql.AppendFormat("DTBUCA = " + "'" + "{0}" + "'" + "," + "\n", userCambio); //04 Usuairo 
                    sql.AppendFormat("DTBFCA = " + "'" + "{0}" + "'" + "," + "\n", fechaCambio.PadLeft(6, '0'));  //05 Fecha de alta 
                    sql.AppendFormat("DTBHCA = " + "'" + "{0}" + "'" + " " + "\n", horaCambio.PadLeft(6, '0'));  //06 Hora de Alta
                    sql.AppendFormat(" WHERE \n");
                    sql.AppendFormat("     DTBMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat(" and DTBNTB = " + "'" + "{0}" + "'" + "\n", tabla.PadLeft(3, '0'));
                    sql.AppendFormat(" and DTBSEC = " + "'" + "{0}" + "'" + "\n", secuencia.PadLeft(3, '0'));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Se actualizó el registro exitosamente...";
                }
                db2Reader.Close();
                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string DeleteTablasporc(string marca, string tabla, string secuencia)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtExist = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("DTBMAR,  \n");  //00 Marca
                sql.Append("DTBNTB,  \n");  //01 Tabla
                sql.Append("DTBSEC   \n");  //02 Secuencia

                sql.Append("FROM " + LibSatObj + ".SAT177F53 T1\n");
                sql.AppendFormat(" WHERE \n");
                sql.AppendFormat("     DTBMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat(" and DTBNTB = " + "'" + "{0}" + "'" + "\n", tabla.PadLeft(3, '0'));
                sql.AppendFormat(" and DTBSEC = " + "'" + "{0}" + "'" + "\n", secuencia.PadLeft(3, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                dtExist = new DataTable("TablasDePorcentajes");
                dtExist.Load(db2Reader);

                if (dtExist.Rows.Count == 0)
                {
                    mensaje = "El Registro no existe...";
                }
                else
                {
                    sql.Clear();
                    sql.Append("Delete  \n");

                    sql.Append(" " + LibSatObj + ".SAT177F53 \n");
                    sql.AppendFormat(" WHERE \n");
                    sql.AppendFormat("     DTBMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat(" and DTBNTB = " + "'" + "{0}" + "'" + "\n", tabla.PadLeft(3, '0'));
                    sql.AppendFormat(" and DTBSEC = " + "'" + "{0}" + "'" + "\n", secuencia.PadLeft(3, '0'));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Se Elimino el registro exitosamente...";
                }
                db2Reader.Close();
                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
      
        public static string InsertRenglonNuevo(string marca, string anio)
        {
            if ((anio.Length) > 2)
            {
                anio = anio.Substring(2, 2);
            }

            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("INSERT INTO MMSATOBJ.SAT177F54 (CPRMAR, CPRANO, CPRREN, CPRSEQ, CPRUAL, CPRFAL, CPRHAL)  \n");
                sql.Append("SELECT  CPRMAR, CPRANO, (SELECT (MAX(CPRREN)+1) CPRREN  FROM MMSATOBJ.SAT177F54  \n");  //00 Marca
                sql.Append("WHERE  \n");
                sql.AppendFormat(" CPRMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                sql.Append(" AND  \n");
                sql.AppendFormat(" CPRANO = " + "'" + "{0}" + "'" + "\n", anio.PadLeft(2, '0'));
                sql.Append(" ), (SELECT (MAX(CPRSEQ) + 10) CPRSEQ FROM MMSATOBJ.SAT177F54  \n");
                sql.Append("WHERE  \n");
                sql.AppendFormat(" CPRMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                sql.Append(" AND  \n");
                sql.AppendFormat(" CPRANO = " + "'" + "{0}" + "'" + "\n", anio.PadLeft(2, '0'));
                sql.Append(" ), CPRUAL, CPRFAL, CPRHAL FROM MMSATOBJ.SAT177F54  \n");
                sql.Append("WHERE  \n");
                sql.AppendFormat(" CPRMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                sql.Append(" AND  \n");
                sql.AppendFormat(" CPRANO = " + "'" + "{0}" + "'" + "\n", anio.PadLeft(2, '0'));
                sql.Append("FETCH FIRST 1 ROWS ONLY \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        // Temporadas 
        public static DataTable ObtenTemporadaPropia(string marca, string temporada, string descripcion)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtTablasPorc = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("COMMAR,  \n");  //00 Marca
                sql.Append("COMTPP,  \n");  //01 Tabla
                sql.Append("COMDES,  \n");  //02 Secuencia
                sql.Append("COMSTS,  \n");  //07 Estatus 
                sql.Append("COMUAL,  \n");  //08 Usuario Alta 
                sql.Append("COMFAL,  \n");  //09 Fecha Alta 
                sql.Append("COMHAL,  \n");  //10 Hora de Alta  
                sql.Append("COMUCA,  \n");  //11 Usuario Cambio 
                sql.Append("COMFCA,  \n");  //12 Fecha Cambio 
                sql.Append("COMHCA   \n");  //13 Hora Cambio 

                sql.Append("FROM " + LibSatObj + ".SAT177F71 \n");
                sql.AppendFormat(" WHERE  COMFAL <> 0 \n");
                if (marca != "") { sql.AppendFormat(" and COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0')); }
                if (temporada != "") { sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0')); }
                if (descripcion != "") { sql.AppendFormat(" and COMDES like " + "'" + "%" + "{0}" + "%" + "'" + "\n", descripcion); }

                sql.Append(" ORDER BY COMMAR, COMTPP  \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtTablasPorc = new DataTable("TabladePorcentaje");
                dtTablasPorc.Load(db2Reader);
                db2Reader.Close();

                return dtTablasPorc;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string InsertTemporadaPropia(string marca, string temporada, string descripcion, string estatus, string userAlta, string fechaAlta, string horaAlta, string userCambio, string fechaCambio, string horaCambio)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtExist = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("COMMAR,  \n");  //00 Marca
                sql.Append("COMTPP,  \n");  //01 Tabla
                sql.Append("COMDES   \n");  //02 Secuencia

                sql.Append("FROM " + LibSatObj + ".SAT177F71 \n");
                sql.AppendFormat(" WHERE \n");
                sql.AppendFormat("     COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                dtExist = new DataTable("TablasDePorcentajes");
                dtExist.Load(db2Reader);

                if (dtExist.Rows.Count > 0)
                {
                    mensaje = "El Registro ya existe...";
                }
                else
                {
                    sql.Clear();
                    sql.Append("Insert Into \n"); //00 Comando 
                    sql.Append(" " + LibSatObj + ".SAT177F71 (\n");
                    sql.Append("COMMAR, \n");     //00 Marca
                    sql.Append("COMTPP, \n");     //00 Tabla
                    sql.Append("COMDES, \n");     //00 Secuencia
                    sql.Append("COMSTS, \n");     //04 Estatus 
                    sql.Append("COMUAL, \n");     //05 Usuario de Alta
                    sql.Append("COMFAL, \n");     //06 Fecha de Alta
                    sql.Append("COMHAL, \n");     //04 Hora de Alta
                    sql.Append("COMUCA, \n");     //04 Usuario de Cambio
                    sql.Append("COMFCA, \n");     //04 Fecha de Cambio 
                    sql.Append("COMHCA )\n");     //04 Hora de Cambio 


                    sql.Append("Values \n"); //    00 Lista de Valores a grabar

                    sql.AppendFormat("(" + "'" + "{0}" + "'" + "," + "\n", marca);       //00 Lista
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", temporada);   //01 Correo
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", descripcion); //02 Nombre 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", estatus);     //06 Hora de Alta 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", userAlta);    //04 Usuairo 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", fechaAlta);   //05 Fecha de alta 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", horaAlta);    //06 Hora de Alta
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", ' ');         //04 Usuairo 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", '0');         //05 Fecha de alta 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + ")" + "\n", '0');         //06 Hora de Alta

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Se guardo el registro exitosamente...";
                }
                db2Reader.Close();
                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string UpdateTemporadaPropia(string marca, string temporada, string descripcion, string estatus, string userAlta, string fechaAlta, string horaAlta, string userCambio, string fechaCambio, string horaCambio)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtExist = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("COMMAR,  \n");  //00 Marca
                sql.Append("COMTPP,  \n");  //01 Tabla
                sql.Append("COMDES   \n");  //02 Secuencia

                sql.Append("FROM " + LibSatObj + ".SAT177F71 \n");
                sql.AppendFormat(" WHERE \n");
                sql.AppendFormat("     COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                dtExist = new DataTable("TablasDePorcentajes");
                dtExist.Load(db2Reader);

                if (dtExist.Rows.Count == 0)
                {
                    mensaje = "El Registro no existe...";
                }
                else
                {
                    sql.Clear();
                    sql.Append("Update  \n");
                    sql.Append(" " + LibSatObj + ".SAT177F71 \n");
                    sql.Append("set \n");

                    //sql.AppendFormat("DTBMAR = " + "'" + "{0}" + "'" + "," + "\n", marca);       //00 Lista
                    //sql.AppendFormat("DTBNTB = " + "'" + "{0}" + "'" + "," + "\n", tabla);      //01 Correo
                    sql.AppendFormat("COMDES = " + "'" + "{0}" + "'" + "," + "\n", descripcion);      //02 Nombre 
                    sql.AppendFormat("COMSTS = " + "'" + "{0}" + "'" + "," + "\n", estatus);    //06 Hora de Alta 
                    sql.AppendFormat("COMUAL = " + "'" + "{0}" + "'" + "," + "\n", userAlta); //04 Usuairo 
                    sql.AppendFormat("COMFAL = " + "'" + "{0}" + "'" + "," + "\n", fechaAlta.PadLeft(6, '0'));  //05 Fecha de alta 
                    sql.AppendFormat("COMHAL = " + "'" + "{0}" + "'" + "," + "\n", horaAlta.PadLeft(6, '0'));  //06 Hora de Alta
                    sql.AppendFormat("COMUCA = " + "'" + "{0}" + "'" + "," + "\n", userCambio); //04 Usuairo 
                    sql.AppendFormat("COMFCA = " + "'" + "{0}" + "'" + "," + "\n", fechaCambio.PadLeft(6, '0'));  //05 Fecha de alta 
                    sql.AppendFormat("COMHCA = " + "'" + "{0}" + "'" + " " + "\n", horaCambio.PadLeft(6, '0'));  //06 Hora de Alta
                    sql.AppendFormat(" WHERE \n");
                    sql.AppendFormat("     COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0'));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Se actualizó el registro exitosamente...";
                }
                db2Reader.Close();
                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string DeleteTemporadaPropia(string marca, string temporada, string descripcion)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtExist = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("COMMAR,  \n");  //00 Marca
                sql.Append("COMTPP,  \n");  //01 Tabla
                sql.Append("COMDES   \n");  //02 Secuencia

                sql.Append("FROM " + LibSatObj + ".SAT177F71 \n");
                sql.AppendFormat(" WHERE \n");
                sql.AppendFormat("     COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0'));
                sql.AppendFormat(" and COMDES = " + "'" + "{0}" + "'" + "\n", descripcion.PadLeft(3, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                dtExist = new DataTable("TablasDePorcentajes");
                dtExist.Load(db2Reader);

                if (dtExist.Rows.Count == 0)
                {
                    mensaje = "El Registro no existe...";
                }
                else
                {
                    sql.Clear();
                    sql.Append("Delete  \n");

                    sql.Append(" " + LibSatObj + ".SAT177F71 \n");
                    sql.AppendFormat(" WHERE \n");
                    sql.AppendFormat("     COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0'));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Se Elimino el registro exitosamente...";
                }
                db2Reader.Close();
                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        // Grupo de Temporadas
        public static DataTable ObtenGrupoTemporadaPropia(
                    string marca, 
                    string grupo,
                    string tipo,
                    string desc,
                    string tmpMms,
                    string desTmpMms,
                    string dp,
                    string sd,
                    string cl,
                    string sc,
                    string dpd,
                    string sdd,
                    string cld,
                    string scd,
                    string prv,
                    string prvDes,
                    string sty,
                    string styDes
            )
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtTablasPorc = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("GTPMAR,  \n");  //00 Marca
                sql.Append("GTPGPO,  \n");  //01 Tabla
                sql.Append("GTPREN,  \n");  //02 Secuencia
                sql.Append("GTPSEC,  \n");  //07 Estatus 
                sql.Append("GTPTPO,  \n");  //08 Usuario Alta 
                sql.Append("GTPTPD,  \n");  //09 Fecha Alta 
                sql.Append("GTPTMP,  \n");  //10 Hora de Alta  
                sql.Append("GTPDES,  \n");  //11 Usuario Cambio

                sql.Append("GTPDP,  \n");  //12 Usuario Cambio
                sql.Append("GTPSD,  \n");  //13 Usuario Cambio
                sql.Append("GTPCL,  \n");  //14 Usuario Cambio
                sql.Append("GTPSC,  \n");  //15 Usuario Cambio

                sql.Append("GTPDPD,  \n");  //12 Usuario Cambio
                sql.Append("GTPSDD,  \n");  //13 Usuario Cambio
                sql.Append("GTPCLD,  \n");  //14 Usuario Cambio
                sql.Append("GTPSCD,  \n");  //15 Usuario Cambio

                sql.Append("GTPPRV,  \n");  //12 Fecha Cambio 
                sql.Append("GTPDPR,  \n");  //13 Hora Cambio 

                sql.Append("GTPSTY,  \n");  //12 Fecha Cambio 
                sql.Append("GTPDST,  \n");  //13 Hora Cambio 

                sql.Append("GTPSTS,  \n");  //13 Hora Cambio 

                sql.Append("GTPUSR,  \n");  //12 Fecha Cambio 
                sql.Append("GTPFCH,  \n");  //12 Fecha Cambio 
                sql.Append("GTPHOR,   \n");  //13 Hora Cambio 

                sql.Append("GTPUCA,  \n");  //12 Fecha Cambio 
                sql.Append("GTPFCA,  \n");  //12 Fecha Cambio 
                sql.Append("GTPHCA   \n");  //13 Hora Cambio 

                sql.Append("FROM " + LibSatObj + ".SAT177F72 \n");
                sql.AppendFormat(" WHERE  GTPFCH <> 0 \n");
                if (marca     != "") { sql.AppendFormat(" and GTPMAR = " + "'" + "{0}" + "'" + "\n", marca); }
                if (grupo     != "") { sql.AppendFormat(" and GTPGPO = " + "'" + "{0}" + "'" + "\n", grupo); }
                if (tipo      != "") { sql.AppendFormat(" and GTPTPO = " + "'" + "{0}" + "'" + "\n", tipo); }
                if (desc      != "") { sql.AppendFormat(" and GTPTPD = " + "'" + "{0}" + "'" + "\n", desc); }
                if (tmpMms    != "") { sql.AppendFormat(" and GTPTMP = " + "'" + "{0}" + "'" + "\n", tmpMms); }
                if (desTmpMms != "") { sql.AppendFormat(" and GTPDES = " + "'" + "{0}" + "'" + "\n", desTmpMms); }
                if (dp        != "") { sql.AppendFormat(" and GTPDP  = " + "'" + "{0}" + "'" + "\n", dp); }
                if (sd        != "") { sql.AppendFormat(" and GTPSD  = " + "'" + "{0}" + "'" + "\n", sd); }
                if (cl        != "") { sql.AppendFormat(" and GTPCL  = " + "'" + "{0}" + "'" + "\n", cl); }
                if (sc        != "") { sql.AppendFormat(" and GTPSC  = " + "'" + "{0}" + "'" + "\n", sc); }
                if (dpd       != "") { sql.AppendFormat(" and GTPDPD = " + "'" + "{0}" + "'" + "\n", dpd); }
                if (sdd       != "") { sql.AppendFormat(" and GTPSDD = " + "'" + "{0}" + "'" + "\n", sdd); }
                if (cld       != "") { sql.AppendFormat(" and GTPCLD = " + "'" + "{0}" + "'" + "\n", cld); }
                if (scd       != "") { sql.AppendFormat(" and GTPSCD = " + "'" + "{0}" + "'" + "\n", scd); }
                if (prv       != "") { sql.AppendFormat(" and GTPPRV = " + "'" + "{0}" + "'" + "\n", prv); }
                if (prvDes    != "") { sql.AppendFormat(" and GTPDPR = " + "'" + "{0}" + "'" + "\n", prvDes); }
                if (sty       != "") { sql.AppendFormat(" and GTPSTY = " + "'" + "{0}" + "'" + "\n", sty); }
                if (styDes    != "") { sql.AppendFormat(" and GTPDST = " + "'" + "{0}" + "'" + "\n", styDes); } 

                sql.Append(" ORDER BY GTPMAR, GTPGPO, GTPREN, GTPSEC  \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtTablasPorc = new DataTable("TabladePorcentaje");
                dtTablasPorc.Load(db2Reader);
                db2Reader.Close();

                return dtTablasPorc;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string InsertGrupoTemporadaPropia(
            string marca,     string temporadaPro, string renglon,  string secuecia,
            string tipoMms,   string descTpoMms,   string tmpMms,   string descTmpMms,  string Depto,       string subDepto,    
            string clase,     string subClase,     string desDepto, string desSubDepto, string desClas,     string desSubClase,
            string Proveedor, string desProv,      string estilo,   string desEstio,    string estatus,
            string userAlta,  string fechaAlta,    string horaAlta, string userCambio,  string fechaCambio, string horaCambio)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtExist = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("GTPMAR,  \n");  //00 Marca
                sql.Append("GTPGPO,  \n");  //01 TemporadaPropia
                sql.Append("GTPREN   \n");  //02 Renglon

                sql.Append("FROM " + LibSatObj + ".SAT177F72 \n");
                sql.AppendFormat(" WHERE \n");
                sql.AppendFormat("     GTPMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat(" and GTPGPO = " + "'" + "{0}" + "'" + "\n", temporadaPro.PadLeft(3, '0'));
                sql.AppendFormat(" and GTPREN = " + "'" + "{0}" + "'" + "\n", renglon.PadLeft(5, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                dtExist = new DataTable("GruposDeTemporada");
                dtExist.Load(db2Reader);

                if (dtExist.Rows.Count > 0)
                {
                    mensaje = "El Registro ya existe...";
                }
                else
                {
                    sql.Clear();
                    sql.Append("Insert Into \n"); 
                    sql.Append(" " + LibSatObj + ".SAT177F72 (\n");
                    sql.Append("GTPMAR, \n");     //00 Marca
                    sql.Append("GTPGPO, \n");     //01 Temp Propia
                    sql.Append("GTPREN, \n");     //02 Renglon 
                    sql.Append("GTPSEC, \n");     //03 Secuencia 
                    sql.Append("GTPTPO, \n");     //04 TIPO MMS
                    sql.Append("GTPTPD, \n");     //05 Descripción
                    sql.Append("GTPTMP, \n");     //06 Temp MMS 
                    sql.Append("GTPDES, \n");     //07 Descripción 

                    sql.Append("GTPDP, \n");      //08 Depto 
                    sql.Append("GTPSD, \n");      //09 Sub-Depto
                    sql.Append("GTPCL, \n");      //10 Clase 
                    sql.Append("GTPSC, \n");      //11 Sub-Clase

                    sql.Append("GTPDPD, \n");     //12 Departamento 
                    sql.Append("GTPSDD, \n");     //13 Sub-Depto
                    sql.Append("GTPCLD, \n");     //14 Clase 
                    sql.Append("GTPSCD, \n");     //15 Sub-Clase 

                    sql.Append("GTPPRV, \n");     //16 Proveedor  
                    sql.Append("GTPDPR, \n");     //17 Descripción  

                    sql.Append("GTPSTY, \n");     //18 Estilo
                    sql.Append("GTPDST, \n");     //19 Descripción  

                    sql.Append("GTPSTS, \n");     //20 Estatus

                    sql.Append("GTPUSR, \n");     //21 Usuario
                    sql.Append("GTPFCH, \n");     //22 Fecha 
                    sql.Append("GTPHOR, \n");     //23 Hora 

                    sql.Append("GTPUCA, \n");     //24 Usuario
                    sql.Append("GTPFCA, \n");     //25 Fecha 
                    sql.Append("GTPHCA )\n");     //26 Hora 

                    sql.Append("Values \n");      // 00 Lista de Valores a grabar

                    sql.AppendFormat("(" + "'" + "{0}" + "'" + "," + "\n", marca);        //00 marca
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", temporadaPro); //01 TemporadaPropia
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", renglon);      //02 Renglon 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", secuecia);     //03 Secuencia 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", tipoMms);      //04 Tipo MMS 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", descTpoMms);   //05 Descripcion Tipo MMS 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", tmpMms);       //06 Temporada MMS
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", descTmpMms);   //07 Descripcion Temporada MMs 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", Depto);        //08 Departamento
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", subDepto);     //09 Sub Departamento
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", clase);        //10 Clase
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", subClase);     //11 Sub clase
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", desDepto);     //12 Descripcion Departamento
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", desSubDepto);  //13 Decripcion Sub Departamento
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", desClas);      //14 Descripcion Clase
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", desSubClase);  //15 Descipcion Sub Clase
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", Proveedor);    //16 Proveedor
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", desProv);      //17 Descripcion del Proveedor
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", estilo);       //18 Estilo
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", desEstio);     //19 Descripcion del Estilo
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", estatus);      //20 Estatus
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", userAlta);     //21 Usuario Alta
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", fechaAlta);    //22 Fecha Alta
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", horaAlta);     //23 Hora Alta
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", userCambio);   //24 Usuario Cambio
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", fechaCambio);  //25 Fecha Cambio
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + ")" + "\n", horaCambio);   //26 Hora Cambio

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Se guardo el registro exitosamente...";
                }
                db2Reader.Close();
                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string UpdateGrupoTemporadaPropia(string marca, string temporada, string descripcion, string estatus, string userAlta, string fechaAlta, string horaAlta, string userCambio, string fechaCambio, string horaCambio)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtExist = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("COMMAR,  \n");  //00 Marca
                sql.Append("COMTPP,  \n");  //01 Tabla
                sql.Append("COMDES   \n");  //02 Secuencia

                sql.Append("FROM " + LibSatObj + ".SAT177F71 \n");
                sql.AppendFormat(" WHERE \n");
                sql.AppendFormat("     COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                dtExist = new DataTable("TablasDePorcentajes");
                dtExist.Load(db2Reader);

                if (dtExist.Rows.Count == 0)
                {
                    mensaje = "El Registro no existe...";
                }
                else
                {
                    sql.Clear();
                    sql.Append("Update  \n");
                    sql.Append(" " + LibSatObj + ".SAT177F71 \n");
                    sql.Append("set \n");

                    //sql.AppendFormat("DTBMAR = " + "'" + "{0}" + "'" + "," + "\n", marca);       //00 Lista
                    //sql.AppendFormat("DTBNTB = " + "'" + "{0}" + "'" + "," + "\n", tabla);      //01 Correo
                    sql.AppendFormat("COMDES = " + "'" + "{0}" + "'" + "," + "\n", descripcion);      //02 Nombre 
                    sql.AppendFormat("COMSTS = " + "'" + "{0}" + "'" + "," + "\n", estatus);    //06 Hora de Alta 
                    sql.AppendFormat("COMUAL = " + "'" + "{0}" + "'" + "," + "\n", userAlta); //04 Usuairo 
                    sql.AppendFormat("COMFAL = " + "'" + "{0}" + "'" + "," + "\n", fechaAlta.PadLeft(6, '0'));  //05 Fecha de alta 
                    sql.AppendFormat("COMHAL = " + "'" + "{0}" + "'" + "," + "\n", horaAlta.PadLeft(6, '0'));  //06 Hora de Alta
                    sql.AppendFormat("COMUCA = " + "'" + "{0}" + "'" + "," + "\n", userCambio); //04 Usuairo 
                    sql.AppendFormat("COMFCA = " + "'" + "{0}" + "'" + "," + "\n", fechaCambio.PadLeft(6, '0'));  //05 Fecha de alta 
                    sql.AppendFormat("COMHCA = " + "'" + "{0}" + "'" + " " + "\n", horaCambio.PadLeft(6, '0'));  //06 Hora de Alta
                    sql.AppendFormat(" WHERE \n");
                    sql.AppendFormat("     COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0'));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Se actualizó el registro exitosamente...";
                }
                db2Reader.Close();
                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string DeleteGrupoTemporadaPropia(string marca, string temporada, string descripcion)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtExist = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("COMMAR,  \n");  //00 Marca
                sql.Append("COMTPP,  \n");  //01 Tabla
                sql.Append("COMDES   \n");  //02 Secuencia

                sql.Append("FROM " + LibSatObj + ".SAT177F71 \n");
                sql.AppendFormat(" WHERE \n");
                sql.AppendFormat("     COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0'));
                sql.AppendFormat(" and COMDES = " + "'" + "{0}" + "'" + "\n", descripcion.PadLeft(3, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                dtExist = new DataTable("TablasDePorcentajes");
                dtExist.Load(db2Reader);

                if (dtExist.Rows.Count == 0)
                {
                    mensaje = "El Registro no existe...";
                }
                else
                {
                    sql.Clear();
                    sql.Append("Delete  \n");

                    sql.Append(" " + LibSatObj + ".SAT177F71 \n");
                    sql.AppendFormat(" WHERE \n");
                    sql.AppendFormat("     COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0'));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Se Elimino el registro exitosamente...";
                }
                db2Reader.Close();
                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        // Detalle Grupo de Temporadas
        public static DataTable ObtenDetalleGrupoTemporadaPropia(string marca, string temporada, string descripcion)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtTablasPorc = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("COMMAR,  \n");  //00 Marca
                sql.Append("COMTPP,  \n");  //01 Tabla
                sql.Append("COMDES,  \n");  //02 Secuencia
                sql.Append("COMSTS,  \n");  //07 Estatus 
                sql.Append("COMUAL,  \n");  //08 Usuario Alta 
                sql.Append("COMFAL,  \n");  //09 Fecha Alta 
                sql.Append("COMHAL,  \n");  //10 Hora de Alta  
                sql.Append("COMUCA,  \n");  //11 Usuario Cambio 
                sql.Append("COMFCA,  \n");  //12 Fecha Cambio 
                sql.Append("COMHCA   \n");  //13 Hora Cambio 

                sql.Append("FROM " + LibSatObj + ".SAT177F71 \n");
                sql.AppendFormat(" WHERE  COMFAL <> 0 \n");
                if (marca != "") { sql.AppendFormat(" and COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0')); }
                if (temporada != "") { sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0')); }
                if (descripcion != "") { sql.AppendFormat(" and COMDES like " + "'" + "%" + "{0}" + "%" + "'" + "\n", descripcion); }

                sql.Append(" ORDER BY COMMAR, COMTPP  \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtTablasPorc = new DataTable("TabladePorcentaje");
                dtTablasPorc.Load(db2Reader);
                db2Reader.Close();

                return dtTablasPorc;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string InsertDetalleGrupoTemporadaPropia(string marca, string temporada, string descripcion, string estatus, string userAlta, string fechaAlta, string horaAlta, string userCambio, string fechaCambio, string horaCambio)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtExist = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("COMMAR,  \n");  //00 Marca
                sql.Append("COMTPP,  \n");  //01 Tabla
                sql.Append("COMDES   \n");  //02 Secuencia

                sql.Append("FROM " + LibSatObj + ".SAT177F71 \n");
                sql.AppendFormat(" WHERE \n");
                sql.AppendFormat("     COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                dtExist = new DataTable("TablasDePorcentajes");
                dtExist.Load(db2Reader);

                if (dtExist.Rows.Count > 0)
                {
                    mensaje = "El Registro ya existe...";
                }
                else
                {
                    sql.Clear();
                    sql.Append("Insert Into \n"); //00 Comando 
                    sql.Append(" " + LibSatObj + ".SAT177F71 (\n");
                    sql.Append("COMMAR, \n");     //00 Marca
                    sql.Append("COMTPP, \n");     //00 Tabla
                    sql.Append("COMDES, \n");     //00 Secuencia
                    sql.Append("COMSTS, \n");     //04 Estatus 
                    sql.Append("COMUAL, \n");     //05 Usuario de Alta
                    sql.Append("COMFAL, \n");     //06 Fecha de Alta
                    sql.Append("COMHAL, \n");     //04 Hora de Alta
                    sql.Append("COMUCA, \n");     //04 Usuario de Cambio
                    sql.Append("COMFCA, \n");     //04 Fecha de Cambio 
                    sql.Append("COMHCA )\n");     //04 Hora de Cambio 


                    sql.Append("Values \n"); //    00 Lista de Valores a grabar

                    sql.AppendFormat("(" + "'" + "{0}" + "'" + "," + "\n", marca);       //00 Lista
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", temporada);   //01 Correo
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", descripcion); //02 Nombre 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", estatus);     //06 Hora de Alta 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", userAlta);    //04 Usuairo 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", fechaAlta);   //05 Fecha de alta 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", horaAlta);    //06 Hora de Alta
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", ' ');         //04 Usuairo 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + "," + "\n", '0');         //05 Fecha de alta 
                    sql.AppendFormat(" " + "'" + "{0}" + "'" + ")" + "\n", '0');         //06 Hora de Alta

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Se guardo el registro exitosamente...";
                }
                db2Reader.Close();
                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string UpdateDetalleGrupoTemporadaPropia(string marca, string temporada, string descripcion, string estatus, string userAlta, string fechaAlta, string horaAlta, string userCambio, string fechaCambio, string horaCambio)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtExist = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("COMMAR,  \n");  //00 Marca
                sql.Append("COMTPP,  \n");  //01 Tabla
                sql.Append("COMDES   \n");  //02 Secuencia

                sql.Append("FROM " + LibSatObj + ".SAT177F71 \n");
                sql.AppendFormat(" WHERE \n");
                sql.AppendFormat("     COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                dtExist = new DataTable("TablasDePorcentajes");
                dtExist.Load(db2Reader);

                if (dtExist.Rows.Count == 0)
                {
                    mensaje = "El Registro no existe...";
                }
                else
                {
                    sql.Clear();
                    sql.Append("Update  \n");
                    sql.Append(" " + LibSatObj + ".SAT177F71 \n");
                    sql.Append("set \n");

                    //sql.AppendFormat("DTBMAR = " + "'" + "{0}" + "'" + "," + "\n", marca);       //00 Lista
                    //sql.AppendFormat("DTBNTB = " + "'" + "{0}" + "'" + "," + "\n", tabla);      //01 Correo
                    sql.AppendFormat("COMDES = " + "'" + "{0}" + "'" + "," + "\n", descripcion);      //02 Nombre 
                    sql.AppendFormat("COMSTS = " + "'" + "{0}" + "'" + "," + "\n", estatus);    //06 Hora de Alta 
                    sql.AppendFormat("COMUAL = " + "'" + "{0}" + "'" + "," + "\n", userAlta); //04 Usuairo 
                    sql.AppendFormat("COMFAL = " + "'" + "{0}" + "'" + "," + "\n", fechaAlta.PadLeft(6, '0'));  //05 Fecha de alta 
                    sql.AppendFormat("COMHAL = " + "'" + "{0}" + "'" + "," + "\n", horaAlta.PadLeft(6, '0'));  //06 Hora de Alta
                    sql.AppendFormat("COMUCA = " + "'" + "{0}" + "'" + "," + "\n", userCambio); //04 Usuairo 
                    sql.AppendFormat("COMFCA = " + "'" + "{0}" + "'" + "," + "\n", fechaCambio.PadLeft(6, '0'));  //05 Fecha de alta 
                    sql.AppendFormat("COMHCA = " + "'" + "{0}" + "'" + " " + "\n", horaCambio.PadLeft(6, '0'));  //06 Hora de Alta
                    sql.AppendFormat(" WHERE \n");
                    sql.AppendFormat("     COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0'));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Se actualizó el registro exitosamente...";
                }
                db2Reader.Close();
                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string DeleteDetalleGrupoTemporadaPropia(string marca, string temporada, string descripcion)
        {
            string mensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtExist = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("COMMAR,  \n");  //00 Marca
                sql.Append("COMTPP,  \n");  //01 Tabla
                sql.Append("COMDES   \n");  //02 Secuencia

                sql.Append("FROM " + LibSatObj + ".SAT177F71 \n");
                sql.AppendFormat(" WHERE \n");
                sql.AppendFormat("     COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0'));
                sql.AppendFormat(" and COMDES = " + "'" + "{0}" + "'" + "\n", descripcion.PadLeft(3, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                dtExist = new DataTable("TablasDePorcentajes");
                dtExist.Load(db2Reader);

                if (dtExist.Rows.Count == 0)
                {
                    mensaje = "El Registro no existe...";
                }
                else
                {
                    sql.Clear();
                    sql.Append("Delete  \n");

                    sql.Append(" " + LibSatObj + ".SAT177F71 \n");
                    sql.AppendFormat(" WHERE \n");
                    sql.AppendFormat("     COMMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat(" and COMTPP = " + "'" + "{0}" + "'" + "\n", temporada.PadLeft(3, '0'));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    mensaje = "Se Elimino el registro exitosamente...";
                }
                db2Reader.Close();
                return mensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenAdministracion(string marca, string comprador, string fechaInicio, string fechaFinal, string temporada, string tipoCalificacion, string tipoConsulta, string niveltienda, string proveedor, string estilo, string depto, string subDepto, string clase, string subClase, string usuario)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConvenioMelody = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");
                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R75 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", comprador.PadRight(3, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", fechaInicio.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", fechaFinal.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", temporada.PadRight(3, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", tipoCalificacion.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", tipoConsulta.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", niveltienda);
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", proveedor.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", estilo.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", depto.PadRight(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", subDepto.PadRight(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", clase.PadRight(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", subClase.PadRight(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", usuario.PadRight(10, ' '));
                sql.Append(")");
                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                #region Campos de la Tabla SAT177F75
                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("ADMMAR,  \n");  //00 Marca
                sql.Append("ADMFCH,  \n");  //01 Año
                sql.Append("ADMTPO,  \n");  //02 Año
                sql.Append("ADMTMP,  \n");  //03 Text
                sql.Append("ADMTAB,  \n");  //04 Temporada
                sql.Append("ADMTDA,  \n");  //05 Temporada descripción
                sql.Append("ADMTDD,  \n");  //06 Renglon 
                sql.Append("ADMPRV,  \n");  //07 Secuencia 
                sql.Append("ADMPRD,  \n");  //08 Semana 
                sql.Append("ADMSTY,  \n");  //09 Semana 
                sql.Append("ADMSTD,  \n");  //10 Semana  
                sql.Append("ADMIDC,  \n");  //11 Semana 
                sql.Append("ADMNCP,  \n");  //12 Semana 
                sql.Append("ADMDP,   \n");  //13 Semana 
                sql.Append("ADMSD,   \n");  //14 Semana 
                sql.Append("ADMCL,   \n");  //15 Semana 
                sql.Append("ADMSC,   \n");  //16 Semana 
                sql.Append("ADMDPD,  \n");  //17 Semana 
                sql.Append("ADMSDD,  \n");  //18 Semana 
                sql.Append("ADMCLD,  \n");  //19 Semana 
                sql.Append("ADMSCD,  \n");  //20 Semana 
                sql.Append("ADMORD,  \n");  //21 Semana 
                sql.Append("ADMFRB,  \n");  //22 Semana 

                sql.Append("ADMCRB,  \n");  //23 Semana 
                sql.Append("ADMVPZ,  \n");  //24 Semana 
                sql.Append("ADMPVT,  \n");  //25 Semana 

                sql.Append("ADMONH,  \n");  //26 Semana 
                sql.Append("ADMONO,  \n");  //27 Semana 
                sql.Append("ADMRTB,  \n");  //28 Semana 
                sql.Append("ADMCDP,  \n");  //29 Semana 

                sql.Append("ADMCOR,  \n");  //30 Semana 
                sql.Append("ADMCFN,  \n");  //31 Semana 
                sql.Append("ADMTAC,  \n");  //32 Semana 
                sql.Append("ADMCSTC, \n");  //33 Semana 
                sql.Append("ADMPRCC, \n");  //34 Semana 

                sql.Append("ADMMRGC, \n");  //35 Semana 
                sql.Append("ADMMTX,  \n");  //36 Semana 
                sql.Append("ADMCLP,  \n");  //37 Semana 

                sql.Append("ADMCLA,  \n");  //38 Semana 
                sql.Append("ADMFBO,  \n");  //39 Semana 
                sql.Append("ADMOHB,  \n");  //40 Semana 
                sql.Append("ADMTBO,  \n");  //41 Semana 
                sql.Append("ADMCSTA, \n");  //42 Semana 
                sql.Append("ADMPRCA, \n");  //43 Semana 
                sql.Append("ADMMRGA, \n");  //44 Semana 
                sql.Append("ADMCSTF, \n");  //45 Semana 
                sql.Append("ADMPRCF, \n");  //46 Semana 
                sql.Append("ADMMRGF, \n");  //47 Semana 

                sql.Append("ADMTAF,  \n");  //48 Semana 
                sql.Append("ADMFCHU, \n");  //49 Semana 
                sql.Append("ADMHORU, \n");  //50 Semana 
                sql.Append("ADMUSRU, \n");  //51 Semana 
                sql.Append("ADMEVC,  \n");  //52 Semana 
                sql.Append("ADMEVP,  \n");  //53 Semana 
                sql.Append("ADMEVE,  \n");  //54 Semana 
                sql.Append("ADMUSRA, \n");  //55 Semana  
                sql.Append("ADMFCHA, \n");  //56 Semana 
                sql.Append("ADMHORA  \n");  //57 Semana 
                #endregion

                sql.Append("FROM " + LibSatObj + ".SAT177F75 \n");
                sql.Append(" ORDER BY ADMPVT DESC, ADMRTB  DESC\n"); 

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtConvenioMelody = new DataTable("Administracion");
                dtConvenioMelody.Load(db2Reader);
                db2Reader.Close();

                return dtConvenioMelody;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenResumenAdministracion()
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConvenioMelody = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");
                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                #region Campos de la Tabla SAT177F75
                sql.Clear();
                sql.Append("SELECT   \n");
                sql.Append("RSMLLA,  \n");  //00 Llave
                sql.Append("RSMCAL,  \n");  //01 Calificados
                sql.Append("RSMRSU,  \n");  //02 Sugerido Rebajado
                sql.Append("RSMRAP,  \n");  //03 Aplicado Rebajado
                sql.Append("RSMSRE,  \n");  //04 Sin Rebaja
                sql.Append("RSMIAC,  \n");  //05 Inventario Actual
                sql.Append("ADMUSRA,  \n"); //06 Usuario Alta 
                sql.Append("ADMFCHA,  \n"); //07 Fecha Alta 
                sql.Append("ADMHORA  \n");  //08 Hora Alta 

                #endregion

                sql.Append("FROM " + LibSatObj + ".SAT177F76 \n");
                sql.Append(" ORDER BY RSMLLA DESC \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtConvenioMelody = new DataTable("ResumenAdmin");
                dtConvenioMelody.Load(db2Reader);
                db2Reader.Close();

                return dtConvenioMelody;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
