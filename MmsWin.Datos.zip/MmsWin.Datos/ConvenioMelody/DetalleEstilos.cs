﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Catalogos
{
    public class DetalleEstilos
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static DataTable ObtenDetalleEstilos(string marca, string grupo, string tipo, string proveedor, string nombre, string estilo, string descripcion, string dp, string sd, string cl, string sc, string dpd, string sdd, string cld, string scd, string usuario)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn  = null;
            StringBuilder sql = new StringBuilder();
            DataTable dtEstilos = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                string file = "SAT177F86";
                string pgm = "SAT177R86";
                if (proveedor != "999999")
                {
                    sql.Clear();
                    sql.Append("CALL " + LibSatPgm + ".SAT177C86 (\n");
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", LibSatObj.PadRight(10, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", file.PadRight(10, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", LibSatPgm.PadRight(10, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", pgm.PadRight(10, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", usuario.PadRight(10, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", grupo.PadLeft(3, '0'));
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", tipo.PadLeft(3, ' '));
                    sql.Append(")");

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();
                }
                sql.Clear();
                sql.Append("SELECT   \n");

                sql.Append("ESTPRV, \n");  //00 Departamento 
                sql.Append("ESTPRD, \n");  //01 Sub Departamento
                sql.Append("ESPSTY, \n");  //02 Departamento 
                sql.Append("ESPDES, \n");  //03 Sub Departamento
                sql.Append("ESTDP,  \n");  //04 Departamento 
                sql.Append("ESTSD,  \n");  //05 Sub Departamento
                sql.Append("ESTCL,  \n");  //06 Clase  
                sql.Append("ESTSC,  \n");  //07 Sub clase
                sql.Append("ESTDPD, \n");  //08 Des Departamento  
                sql.Append("ESTSDD, \n");  //09 Des Sub Departamento
                sql.Append("ESTCLD, \n");  //10 Des Clase
                sql.Append("ESTSCD, \n");  //11 Des Sub clase
                sql.Append("ESTSTS, \n");  //12 Estatus
                sql.Append("ESTUAL, \n");  //13 Usuario
                sql.Append("ESTFAL, \n");  //14 Fecha
                sql.Append("ESTHAL  \n");  //15 Hora

                sql.Append("FROM " + LibSatObj + ".SAT177F86 \n");

                sql.AppendFormat(" WHERE ESTPRV >= 0" + "\n");

                if (proveedor   != "") { sql.AppendFormat(" and ESTPRV    = " + "'"  + "{0}" + "'"  + "\n", proveedor); }
                if (nombre      != "") { sql.AppendFormat(" and ESTPRD like " + "'%" + "{0}" + "%'" + "\n", nombre); }
                if (estilo      != "") { sql.AppendFormat(" and ESPSTY    = " + "'"  + "{0}" + "'"  + "\n", estilo); }
                if (descripcion != "") { sql.AppendFormat(" and ESPDES like " + "'%" + "{0}" + "%'" + "\n", descripcion); }

                if (dp  != "") { sql.AppendFormat(" and ESTDP = " + "'" + "{0}" + "'" + "\n", dp); }
                if (sd  != "") { sql.AppendFormat(" and ESTSD = " + "'" + "{0}" + "'" + "\n", sd); }
                if (cl  != "") { sql.AppendFormat(" and ESTCL = " + "'" + "{0}" + "'" + "\n", cl); }
                if (sc  != "") { sql.AppendFormat(" and ESTSC = " + "'" + "{0}" + "'" + "\n", sc); }
                if (dpd != "") { sql.AppendFormat(" and ESTDPD like " + "'%" + "{0}" + "%'" + "\n", dpd); }
                if (sdd != "") { sql.AppendFormat(" and ESTSDD like " + "'%" + "{0}" + "%'" + "\n", sdd); }
                if (cld != "") { sql.AppendFormat(" and ESTCLD like " + "'%" + "{0}" + "%'" + "\n", cld); }
                if (scd != "") { sql.AppendFormat(" and ESTSCD like " + "'%" + "{0}" + "%'" + "\n", scd); }

                sql.Append(" ORDER BY ESTPRV, ESPSTY, ESTDP, ESTSD, ESTCL, ESTSC  DESC \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtEstilos = new DataTable("Estilos");
                dtEstilos.Load(db2Reader);


                if (dtEstilos.Rows.Count == 0)
                {
                    #region Registro Total
                    DataRow row = dtEstilos.NewRow();
                    row["ESTPRV"] = "0";
                    row["ESTPRD"] = "No se encontraron Registros.";
                    row["ESPSTY"] = " ";
                    row["ESPDES"] = " ";
                    row["ESTDP"] = "0";
                    row["ESTSD"] = "0";
                    row["ESTCL"] = "0";
                    row["ESTSC"] = "0";
                    row["ESTDPD"] = " ";
                    row["ESTSDD"] = " ";
                    row["ESTCLD"] = " ";
                    row["ESTSCD"] = " ";
                    row["ESTSTS"] = " ";
                    row["ESTUAL"] = " ";
                    row["ESTFAL"] = "0";
                    row["ESTHAL"] = "0";
                    dtEstilos.Rows.Add(row);
                    #endregion
                }

                db2Reader.Close();

                return dtEstilos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
