﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Convenio
{
    public class Convenio
    {

        #region Conexion
        // Equipo
        // public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();

        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseriesAll"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
        #endregion

        public static DataTable ObtenConvenio(string marca, string comprador, String FchDe, String FchHas, string ParProveedor, string PartbNombre, string PartbEstilo, string ParDescripcion, string temporada, string origen, string conRpg, string sinRpg, string ParUsuario, Boolean simulador, string conExcep)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConvenio = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                if (simulador == true)  // || ParUsuario == "CALIFICA")
                {
                    sql.Clear();
                    sql.Append("CALL " + LibSatPgm + ".SAT179C4 (\n");
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", ParUsuario.PadRight(10, ' '));
                    sql.Append(")");

                    db2Comm.CommandText = sql.ToString();
                    OleDbDataReader dbcall = db2Comm.ExecuteReader();
                    dbcall.Close();


                    //Se agrega para darle vuelta al procesos manual
                    try
                    {
                        sql.Clear();
                        sql.Append(" CREATE ALIAS MMNETLIB.SATSEISEM FOR MMSATOBJ.SAT179PF(SEISSEM) ");


                        db2Comm.CommandText = sql.ToString();
                        OleDbDataReader dbcall2 = db2Comm.ExecuteReader();
                        dbcall.Close();
                    }
                    catch (Exception ex)
                    {
                    }
                }

                sql.Clear();
                sql.Append("SELECT \n");
                sql.Append("T1.DSPPRV, \n"); //00 Proveedor
                sql.Append("T1.DSPNOM, \n"); //01 Nombre
                sql.Append("T1.DSPSTY, \n"); //02 Estilo 
                sql.Append("T1.DSPDES, \n"); //03 Descripcion
                sql.Append("T1.DSPDCP, \n"); //04 Comprador 
                sql.Append("T1.DSPORD, \n"); //05 Orden 
                sql.Append("T1.DSPFRB, \n"); //06 Fch.Recibo 
                sql.Append("T1.DSPPRB, \n"); //07 Pza.Recibo
                sql.Append("T1.DSPMRG, \n"); //08 Margen
                sql.Append("T1.DSP4P3, \n"); //09 Mrg * 4.3 
                sql.Append("T1.DSPRTB, \n"); //10 Rentabilidad
                sql.Append("T1.DSPRT2, \n"); //11 Rent. 2 
                sql.Append("T1.DSPRT3, \n"); //12 Rent. 3
                sql.Append("T1.DSPRT4, \n"); //13 Rent. 4 
                sql.Append("T1.DSPCAL, \n"); //14 Calificacion
                sql.Append("T1.DSPCOR, \n"); //15 Cal.Original
                sql.Append("T1.DSPCLF, \n"); //16 Calificacion Final
                sql.Append("T1.DSPONH, \n"); //17 On.Hand 
                sql.Append("T1.DSPONO, \n"); //18 On Order  
                sql.Append("T1.DSPRSTD, \n");//19 Resurtido 
                sql.Append("T1.DSPPDI, \n"); //20 66 63 62 Observ. Contraloria
                sql.Append("T1.DSPSM1, \n"); //21 20 Sem.1 
                sql.Append("T1.DSPSM2, \n"); //22 21 Sem.2
                sql.Append("T1.DSPSM3, \n"); //23 22 Sem.3
                sql.Append("T1.DSPSM4, \n"); //24 23 Sem.4
                sql.Append("T1.DSPSM5, \n"); //25 24 Sem.5
                sql.Append("T1.DSPSM6, \n"); //26 25 Sem.6
                sql.Append("T1.DSPSM7, \n"); //27 26 Sem.7
                sql.Append("T1.DSPSM8, \n"); //28 27 Sem.8
                sql.Append("T1.DSPPOR, \n"); //29 28 %
                sql.Append("T1.DSPFRV, \n"); //30 29 Fch.Revision
                sql.Append("T1.DSPCST, \n"); //31 30 Costo Total
                sql.Append("T1.DSPPZA, \n"); //32 31 Piezas a Bonificar 
                sql.Append("T1.DSPCSB, \n"); //33 32 Costo a Bonificar 
                sql.Append("T1.DSPCBF, \n"); //34 33 32 Costo a Bonificar Final 
                sql.Append("T1.DSPMAR, \n"); //35 34 33 Marca 
                sql.Append("T1.DSPBDG, \n"); //36 35 34 Bodega
                sql.Append("T1.DSPCSTA, \n");//37 36 35 Costo a Actual
                sql.Append("T1.DSPPREA, \n");//38 37 36 Preco a Actual
                sql.Append("T1.DRECB0, \n"); //39 38 37 Rec.0 
                sql.Append("T1.DRECB1, \n"); //40 39 38 Rec.1
                sql.Append("T1.DRECB2, \n"); //41 40 39 Rec.2
                sql.Append("T1.DRECB3, \n"); //42 41 40 Rec.3
                sql.Append("T1.DRECB4, \n"); //43 42 41 Rec.4
                sql.Append("T1.DRECB5, \n"); //44 43 42 Rec.5
                sql.Append("T1.DRECB6, \n"); //45 44 43 Rec.6
                sql.Append("T1.DRECB7, \n"); //46 45 44 Rec.7
                sql.Append("T1.DRECB8, \n"); //4746 45 Rec.8
                //sql.Append("IFNULL(T2.MTETMP, 'TT') AS DSPASN, \n"); //47 46 Season Code
                sql.Append("T1.DSPASN, \n"); //48 47 46 Season Code
                sql.Append("T1.DSPORI, \n"); //49 48 47 Origen  
                sql.Append("T1.DSPRPG, \n"); //50 49 48 Reprogramado
                sql.Append("T1.DSPNMR, \n"); //51 50 49 Marca  
                sql.Append("T1.DSPNCS, \n"); //52 51 50 NC PDF
                sql.Append("T1.DSPREP, \n"); //53 52 51 Reprog Proxima
                sql.Append("T1.DSPNRP, \n"); //54 53 52 51 No. Reprogramaciones
                sql.Append("T1.DSPFPX, \n"); //55 54 53 52 Proxima Reprogramacion
                sql.Append("T1.DSPOBS, \n"); //56 55 54 53 Observaciones
                sql.Append("T1.BONCK1, \n"); //57 56 55 54 COMPRAS
                sql.Append("T1.DSPUCP, \n"); //58 57 56 55 Usuario Compras
                sql.Append("T1.DSPFCP, \n"); //59 58 57 56 Fecha Compras 
                sql.Append("T1.DSPHCP, \n"); //60 59 58 57 Hora Compras  
                sql.Append("T1.BONCK2, \n"); //61 60 59 58 CONTRALORIA
                sql.Append("T1.DSPUCT, \n"); //62 61 60 59 Usuario Contral
                sql.Append("T1.DSPFCT, \n"); //63 62 61 60 Fecha Contral  
                sql.Append("T1.DSPHCT, \n"); //64 63 62 61 Hora Contral
                sql.Append("T1.DSPOBC, \n"); //65 64 63 62 Observ. Contraloria 
                sql.AppendLine("   IFNULL(R.REPFOL,-1) REPSTY,  "); // 66 65  Si tiene estilo, indica que 
                sql.Append("T1.DSPOMI \n"); //67 66 63 62 Observ. Contraloria
          
                if (simulador == true)
                {
                    sql.Append("FROM MMNETLIB.SATSEISEM T1\n");
                }
                else
                {
                    sql.Append("FROM " + LibSatObj + ".SAT179F1 T1\n");
                }

                //JOIN con la tabla de temporadas generada por Ulises
              //  sql.AppendFormat(" LEFT JOIN MMNETLIB.SAT177F40 T2\n");
              //  sql.AppendFormat(" ON T1.DSPSTY = T2.MTESTY AND T1.DSPPRV = T2.MTEPRV\n");

                //Join con la tabla
                sql.AppendLine(" LEFT JOIN MMSATOBJ.SAT177F14 R ");
                sql.AppendLine(" ON R.REPPRV = T1.DSPPRV ");
                sql.AppendLine(" AND R.REPSTY = T1.DSPSTY ");
                sql.AppendLine(" AND R.REPFRV = T1.DSPFRB ");

                if (FchDe != "")
                {
                    sql.AppendFormat(" WHERE T1.DSPFCH BETWEEN " + "'" + "{0}" + "'" + "\n", FchDe);
                    sql.AppendFormat(" AND " + "'" + "{0}" + "'" + "\n", FchHas);

                    if (marca     != "999") { sql.AppendFormat(" and T1.DSPNMR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0')); }
                    if (comprador != "999") { sql.AppendFormat(" and T1.DSPCOM IN " + "(" + "{0}" + ")" + "\n", comprador); }
                    if (temporada != "999") { sql.AppendFormat(" and T1.DSPASN in(" + "{0}" + ")" + "\n", temporada); }
                    if (origen    != "999") { sql.AppendFormat(" and T1.DSPORI = " + "'" + "{0}" + "'" + "\n", origen); }

                    if (conRpg == " ")
                    {
                        if (conRpg != "999") { sql.AppendFormat(" and (T1.DSPRPG = " + "'" + "{0}" + "'" + "\n", conRpg); }
                        if (conRpg != "999") { sql.AppendFormat(" and T1.DSPREP = " + "'" + "{0}" + "')" + "\n", conRpg); }
                    }
                    if (conRpg == "1")
                    {
                        if (conRpg != "999") { sql.AppendFormat(" and (T1.DSPRPG = " + "'" + "{0}" + "'" + "\n", conRpg); }
                        if (conRpg != "999") { sql.AppendFormat(" or T1.DSPREP = " + "'" + "{0}" + "')" + "\n", conRpg); }
                    }

                    if (ParProveedor   != "") { sql.AppendFormat(" and T1.DSPPRV = " + "'" + "{0}" + "'" + "\n", ParProveedor); }
                    if (PartbNombre    != "") { sql.AppendFormat(" and T1.DSPNOM LIKE " + "'%" + "{0}" + "%'" + "\n", PartbNombre); }
                    if (PartbEstilo    != "") { sql.AppendFormat(" and T1.DSPSTY = " + "'" + "{0}" + "'" + "\n", PartbEstilo); }
                    if (ParDescripcion != "") { sql.AppendFormat(" and T1.DSPDES LIKE " + "'%" + "{0}" + "%'" + "\n", ParDescripcion); }

                    if (conExcep != "999")
                    {
                        if (conExcep == "16")//Sin excepciones
                        {
                            sql.AppendFormat(" AND IFNULL(R.REPFOL,-1) <= 0  \n");
                        }
                        else if (conExcep == "17")//Con excepciones autorizadas
                        {
                            sql.AppendFormat(" AND IFNULL(R.REPFOL, -1) > 0 AND R.REPSTS = 'A' \n");
                        }
                        else if (conExcep == "18")//Excepciones pendientes de autorizar
                        {
                            sql.AppendFormat("  AND IFNULL(R.REPFOL, -1) = 0 AND R.REPSTS = 'P' \n");
                        }
                        else if (conExcep == "19")//Sin revisar
                        {
                            sql.AppendFormat("  AND T1.BONCK1 = 0 AND DSPCAL <> ' P a g a r          '  \n");
                        }
                    }

                    sql.Append(" ORDER BY  T1.DSPFCH, T1.DSPPRV, T1.DSPSTY  ASC\n");

                    db2Comm.CommandText = sql.ToString();
                    OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                    dtConvenio = new DataTable("Convenio");
                    dtConvenio.Load(db2Reader);
                    db2Reader.Close();

                }

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtConvenio;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        /// <summary>
        /// Obtiene las fechas de pre-calificación existente
        /// Desarrollador: OCG
        /// </summary>
        /// <returns>Datatable con los datos</returns>
        public static DataTable ObtenFechasPrecalificacion()
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConvenio = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();

                sql.Append(" SELECT MMNETLIB.FORMATFECH(Z.DSPFCH) DSPFCH FROM ( ");
                sql.Append(" SELECT DISTINCT DATE(MMNETLIB.FORMATFECHING(DSPFCH)) DSPFCH_F, DSPFCH FROM MMNETLIB.SATSEISEM ORDER BY DSPFCH ASC ) Z ");
                sql.Append(" ORDER BY Z.DSPFCH_F ");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtConvenio = new DataTable("Convenio");
                dtConvenio.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtConvenio;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void UpdateConvenio(DataTable dtConvenio)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                foreach (DataRow row in dtConvenio.Rows)
                {
                    string FechaRev = row["FechaRev"].ToString();
                    string Proveedor = row["Proveedor"].ToString();
                    string Estilo = row["Estilo"].ToString();

                    string CalificaFinal = row["CalificaFinal"].ToString();
                    string CostoFinal = row["CostoFinal"].ToString();

                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT179PL1 SET \n");
                    sql.AppendFormat("DSPCLF = " + "'" + "{0}" + "'" + "\n", CalificaFinal.PadRight(150, ' '));
                    sql.AppendFormat(" , DSPCBF = " + "'" + "{0}" + "'" + "\n", CostoFinal.PadLeft(13, '0'));

                    sql.Append("WHERE \n");
                    sql.AppendFormat("DSPFCH = " + "'" + "{0}" + "'" + "\n", FechaRev.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("DSPPRV = " + "'" + "{0}" + "'" + "\n", Proveedor.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("DSPSTY = " + "'" + "{0}" + "'" + "\n", Estilo.PadRight(15, ' '));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT179LF1 SET \n");
                    sql.AppendFormat("DSPCLF = " + "'" + "{0}" + "'" + "\n", CalificaFinal.PadRight(150, ' '));
                    sql.AppendFormat(" , DSPCBF = " + "'" + "{0}" + "'" + "\n", CostoFinal.PadLeft(13, '0'));

                    sql.Append("WHERE \n");
                    sql.AppendFormat("DSPFCH = " + "'" + "{0}" + "'" + "\n", FechaRev.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("DSPPRV = " + "'" + "{0}" + "'" + "\n", Proveedor.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("DSPSTY = " + "'" + "{0}" + "'" + "\n", Estilo.PadRight(15, ' '));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                }
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static List<String> ObtenCompradores()
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtCompradores = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT  BYRNAM FROM " + Lib610Lib + ".TBLBYR\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();
                if (db2Reader.Read())
                {
                    db2Reader.Close();
                }
                db2Reader = db2Comm.ExecuteReader();
                List<String> lista = new List<String>();
                lista.Add("Todos");
                string textConvert;
                while (db2Reader.Read())
                {
                    textConvert = db2Reader.GetString(0);
                    lista.Add(textConvert.Replace('#', 'Ñ'));
                }

                dtCompradores = new DataTable("Compradores");
                dtCompradores.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return lista;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void EjecutaSimulador(string ParFchIni, string ParFchFin, string ParUsuario)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT179R0 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchIni.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchFin.PadLeft(6, '0'));
                sql.AppendFormat("'SIMULADOR '" + "\n", ParUsuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void EjecutaCalificacion(string ParFchIni, string ParFchFin, string ParUsuario)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT179R0 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchIni.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchFin.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParUsuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable UpdateCheckBox(DataTable dtCheckBox, string ParUser, string fecha, string hora)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("CALL " + LibSatPgm + ".SAT179C5 \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader dbcall = db2Comm.ExecuteReader();
                dbcall.Close();

                foreach (DataRow row in dtCheckBox.Rows)
                {
                    string FechaRev = row["FechaRev"].ToString();
                    string Proveedor = row["Proveedor"].ToString();
                    string Estilo = row["Estilo"].ToString();
                    string Observaciones = row["DSPOBS"].ToString();

                    string Compras = row["Compras"].ToString();
                    string Com1 = row["Com1"].ToString();

                    try
                    {
                        sql.Clear();
                        sql.Append("UPDATE " + LibSatObj + ".SAT179PL1 SET \n");

                        if (Com1 == "1") { sql.AppendFormat("BONCK1 = " + "'" + "{0}" + "'" + "\n", Compras.PadLeft(1, '0')); }
                        if (Observaciones != "") { sql.AppendFormat(", DSPOBS = " + "'" + "{0}" + "'" + "\n", Observaciones.PadRight(100, ' ')); }
                        if (ParUser != "") { sql.AppendFormat(", DSPUCP = " + "'" + "{0}" + "'" + "\n", ParUser.PadRight(10, ' ')); }
                        if (fecha != "") { sql.AppendFormat(", DSPFCP = " + "'" + "{0}" + "'" + "\n", fecha.PadLeft(6, '0')); }
                        if (hora != "") { sql.AppendFormat(", DSPHCP = " + "'" + "{0}" + "'" + "\n", hora.PadLeft(6, '0')); }

                        sql.Append("WHERE \n");
                        sql.AppendFormat("DSPFCH = " + "'" + "{0}" + "'" + "\n", FechaRev.PadLeft(6, '0'));
                        sql.Append("AND \n");
                        sql.AppendFormat("DSPPRV = " + "'" + "{0}" + "'" + "\n", Proveedor.PadLeft(6, '0'));
                        sql.Append("AND \n");
                        sql.AppendFormat("DSPSTY = " + "'" + "{0}" + "'" + "\n", Estilo.PadRight(15, ' '));

                        db2Comm.CommandText = sql.ToString();
                        db2Comm.ExecuteNonQuery();
                    }
                    catch { }

                    try
                    {
                        sql.Clear();
                        sql.Append("UPDATE " + LibSatObj + ".SAT179LF1 SET \n");

                        if (Com1 == "1") { sql.AppendFormat("BONCK1 = " + "'" + "{0}" + "'" + "\n", Compras.PadLeft(1, '0')); }
                        if (Observaciones != "") { sql.AppendFormat(", DSPOBS = " + "'" + "{0}" + "'" + "\n", Observaciones.PadRight(100, ' ')); }
                        if (ParUser != "") { sql.AppendFormat(", DSPUCP = " + "'" + "{0}" + "'" + "\n", ParUser.PadRight(10, ' ')); }
                        if (fecha != "") { sql.AppendFormat(", DSPFCP = " + "'" + "{0}" + "'" + "\n", fecha.PadLeft(6, '0')); }
                        if (hora != "") { sql.AppendFormat(", DSPHCP = " + "'" + "{0}" + "'" + "\n", hora.PadLeft(6, '0')); }

                        sql.Append("WHERE \n");
                        sql.AppendFormat("DSPFCH = " + "'" + "{0}" + "'" + "\n", FechaRev.PadLeft(6, '0'));
                        sql.Append("AND \n");
                        sql.AppendFormat("DSPPRV = " + "'" + "{0}" + "'" + "\n", Proveedor.PadLeft(6, '0'));
                        sql.Append("AND \n");
                        sql.AppendFormat("DSPSTY = " + "'" + "{0}" + "'" + "\n", Estilo.PadRight(15, ' '));

                        db2Comm.CommandText = sql.ToString();
                        db2Comm.ExecuteNonQuery();
                    }
                    catch { }
                }
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtCheckBox;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable UpdateCheckBox2(DataTable dtCheckBox, string ParUser, string fecha, string hora)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("CALL " + LibSatPgm + ".SAT179C5 \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader dbcall = db2Comm.ExecuteReader();
                dbcall.Close();

                foreach (DataRow row in dtCheckBox.Rows)
                {
                    string FechaRev      = row["FechaRev"].ToString();
                    string Proveedor     = row["Proveedor"].ToString();
                    string Estilo        = row["Estilo"].ToString();
                    string Observaciones = row["DSPOBC"].ToString();

                    string Contraloria = row["Contraloria"].ToString();
                    string Cont1       = row["Cont1"].ToString();

                    string Omitir = row["Omitir"].ToString();
                    string Cont2  = row["Cont2"].ToString();

                    try
                    {
                        sql.Clear();
                        sql.Append("UPDATE " + LibSatObj + ".SAT179PL1 SET \n");

                        if (Cont1 == "1") { sql.AppendFormat("BONCK2    = " + "'" + "{0}" + "'" + "\n", Contraloria.PadLeft(1, '0')); }
                        if (Cont1 == "1" && Cont2 == "1") { sql.AppendFormat("," + "\n"); }
                        if (Cont2 == "1") { sql.AppendFormat("DSPOMI    = " + "'" + "{0}" + "'" + "\n", Omitir.PadLeft(1, '0')); }
                        if (Observaciones != "") { sql.AppendFormat(", DSPOBC = " + "'" + "{0}" + "'" + "\n", Observaciones.PadRight(100, ' ')); }
                        if (ParUser != "") { sql.AppendFormat(", DSPUCT = " + "'" + "{0}" + "'" + "\n", ParUser.PadRight(10, ' ')); }
                        if (fecha != "") { sql.AppendFormat(",   DSPFCT = " + "'" + "{0}" + "'" + "\n", fecha.PadLeft(6, '0')); }
                        if (hora != "") { sql.AppendFormat(",    DSPHCT = " + "'" + "{0}" + "'" + "\n", hora.PadLeft(6, '0')); }

                        sql.Append("WHERE \n");
                        sql.AppendFormat("DSPFCH = " + "'" + "{0}" + "'" + "\n", FechaRev.PadLeft(6, '0'));
                        sql.Append("AND \n");
                        sql.AppendFormat("DSPPRV = " + "'" + "{0}" + "'" + "\n", Proveedor.PadLeft(6, '0'));
                        sql.Append("AND \n");
                        sql.AppendFormat("DSPSTY = " + "'" + "{0}" + "'" + "\n", Estilo.PadRight(15, ' '));

                        db2Comm.CommandText = sql.ToString();
                        db2Comm.ExecuteNonQuery();
                    }
                    catch { }

                    try
                    {
                        sql.Clear();
                        sql.Append("UPDATE " + LibSatObj + ".SAT179LF1 SET \n");

                        if (Cont1 == "1") { sql.AppendFormat("BONCK2    = " + "'" + "{0}" + "'" + "\n", Contraloria.PadLeft(1, '0')); }
                        if (Cont1 == "1" && Cont2 == "1") { sql.AppendFormat("," + "\n"); }
                        if (Cont2 == "1") { sql.AppendFormat("DSPOMI    = " + "'" + "{0}" + "'" + "\n", Omitir.PadLeft(1, '0')); }
                        if (Observaciones != "") { sql.AppendFormat(", DSPOBC = " + "'" + "{0}" + "'" + "\n", Observaciones.PadRight(100, ' ')); }
                        if (ParUser != "") { sql.AppendFormat(", DSPUCT = " + "'" + "{0}" + "'" + "\n", ParUser.PadRight(10, ' ')); }
                        if (fecha   != "") { sql.AppendFormat(", DSPFCT = " + "'" + "{0}" + "'" + "\n", fecha.PadLeft(6, '0')); }
                        if (hora    != "") { sql.AppendFormat(", DSPHCT = " + "'" + "{0}" + "'" + "\n", hora.PadLeft(6, '0')); }

                        sql.Append("WHERE \n");
                        sql.AppendFormat("DSPFCH = " + "'" + "{0}" + "'" + "\n", FechaRev.PadLeft(6, '0'));
                        sql.Append("AND \n");
                        sql.AppendFormat("DSPPRV = " + "'" + "{0}" + "'" + "\n", Proveedor.PadLeft(6, '0'));
                        sql.Append("AND \n");
                        sql.AppendFormat("DSPSTY = " + "'" + "{0}" + "'" + "\n", Estilo.PadRight(15, ' '));

                        db2Comm.CommandText = sql.ToString();
                        db2Comm.ExecuteNonQuery();
                    }
                    catch { }
                }
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtCheckBox;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenRutaPDF(String ParFchCal, String ParPrv, String ParSty, String ParNota)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtRutaPDF = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT NOTRUT FROM  " + LibSatObj + ".SAT177L30 \n");

                sql.AppendFormat(" WHERE NOTFRE = " + "'" + "{0}" + "'" + "\n", ParFchCal.PadLeft(6, '0'));
                sql.AppendFormat(" and NOTPRV = " + "'" + "{0}" + "'" + "\n", ParPrv.PadLeft(6, '0'));
                sql.AppendFormat(" and NOTSTY = " + "'" + "{0}" + "'" + "\n", ParSty.PadRight(15, ' ')); ;
                if (ParNota != "Mas de 1" && ParNota != null)
                {
                    sql.AppendFormat(" and NOTNOT = " + "'" + "{0}" + "'" + "\n", ParNota.PadRight(20, ' '));
                }
                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtRutaPDF = new DataTable("Bonificaciones");
                dtRutaPDF.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            return dtRutaPDF;
        }

        #region Temporada

        public static DataTable ObtenTemporada(string marca, string comprador, string temporada, string origen)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConvenio = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT * \n");
                sql.Append("FROM ( \n");
                sql.Append("SELECT PINPRV ID_PROV, PINPRVD	PROVEEDOR,  \n");
                sql.Append("PINSTY ID_ESTILO,PINSTYD ESTILO, \n");
                sql.Append("PINCMP COMPRADOR,	 \n");
                sql.Append("PINDEP ID_DEPTO,	PINDEPD DEPARTAMENTO, \n");
                sql.Append("PINSDP ID_SUBDEPTO,PINSDPD SUBDEPARTAMENTO,  \n");
                sql.Append("PINCLS ID_CLASE,PINCLSD CLASE, \n");
                sql.Append("PINSCL ID_SUBCLASE,  PINSCLD SUBCLASE, \n");
                sql.Append("PINCSTO COSTO_ANT,	PINPRCO	PRECIO_ANT,PINMRGO MB_ANT, \n");
                sql.Append("PINCST COSTO_ACT,	PINPRC PRECIO_ACT,PINMRG MB_ACT, \n");
                sql.Append("PINFRB FECHA_RECIBO,PINCRB CANTIDAD_RECIBIDA,	 \n");
                sql.Append("PINFUR FEC_ULT_RECIBO,	PINVPZ	PIEZAS_VENTA, PINVIM IMPORTE_VENTA, \n");
                sql.Append("PINPVT VENTA,	PINAJU	AJUSTE_INVENTARIO, \n");
                sql.Append("PINOHP ONHAND_PLUS,PINCCO CALIFICACION,PINBON BONIFICACION, \n");
                sql.Append("PINBEF BONIFICACION_EFECTIVA,PINPSU PRECIO_SUG,PINVTE DV_EFECTIVOS, \n");
                sql.Append("PINPDV PRIMER_DIA_VENTA,PIN1SP SEM_VTA_PIEZAS,	PINVE7 VTA_X_DIA, \n");
                sql.Append("PIN1SI SEM_VTA_IMP,PINDVT DV,PINPVD VTA_DIARIA, \n");
                sql.Append("CASE  \n");
                sql.Append("WHEN PINBDG = 914  THEN 30  \n");
                sql.Append("WHEN PINBDG = 4 THEN 30 \n");
                sql.Append("WHEN PINBDG = 6 THEN 30 \n");
                sql.Append("WHEN PINBDG = 915 THEN 10 \n");
                sql.Append("WHEN PINBDG = 3   THEN 10 \n");
                sql.Append("WHEN PINBDG = 5   THEN 10  \n");
                sql.Append("WHEN PINBDG = 7   THEN 60  \n");
                sql.Append("WHEN PINBDG = 917 THEN 60 ELSE 0 END AS  MARCA	 \n");

                sql.Append(",PINEVE	EVENTO,PINFCHE FECHA_EVENTO	,PINASN TEMPORADA, 'NAC' ORIGEN,--,PINCSTA 	,PINPRCA	,PINMRGA	,PINASN,PINCCO, \n");
                //sql.Append("PINOCP OBSERVACIONES_COMPRAS,PINCCP REV, PINUCP USUARIO, PINFCP FECHA, PINHCP HORA,\n");
                //sql.Append("PINOCT OBSERVACIONES_CONTRALORIA,PINCCT REV_, PINUCT USUARIO_CONTRALORIA, PINFCT FECHA_, PINHCT HORA_\n");

                sql.Append("'' OBSERVACIONES_COMPRAS,'' REV, '' USUARIO, '' FECHA, '' HORA,\n");
                sql.Append("'' OBSERVACIONES_CONTRALORIA,'' REV_, '' USUARIO_CONTRALORIA, '' FECHA_, '' HORA_\n");

                if (marca == "60")
                    sql.Append("from paso.SAT178F2Ej ) GEN \n");
                else if (marca == "30")
                    sql.Append("from paso.SAT178F2Ez ) GEN \n");
                else if (marca == "10")
                    sql.Append("from paso.SAT178F2EH ) GEN \n");
                else
                    sql.Append("from paso.SAT178F2E ) GEN \n");

                sql.AppendFormat("WHERE TEMPORADA= '{0}' \n", temporada);

                if (marca != "999")
                    sql.AppendFormat("AND MARCA= {0} \n", marca);

                if (comprador != "999")
                    sql.AppendFormat("AND COMPRADOR= '{0}' \n", comprador);

                if (origen != "999")
                    sql.AppendFormat("AND ORIGEN= '{0}' \n", origen);

                db2Comm.CommandText = sql.ToString();

                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtConvenio = new DataTable("Convenio");
                dtConvenio.Load(db2Reader);
                db2Reader.Close();


                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtConvenio;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Obten cantidad de veces que a cambiado un Solicitud de Calificación "
        public static int cantidadNoCalificacion(string estilo, string proveedor, string ordencom, string marca, string tempo)
        {
            int resultado = 0;
            StringBuilder sql = new StringBuilder();
            string noEvento = "";
            OleDbConnection db2Conn = null;

            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append(" SELECT COALESCE(COUNT(SDBQUY), 0) \n"); // # maximo de EVENTOS QUE SE HAN ACTUALIZADO
                sql.Append("FROM MMNETLIB.SAT177CAL \n");
                sql.AppendFormat("WHERE SDBSTY = '{0}' \n", estilo);
                sql.AppendFormat("  AND SDBPRV = {0} \n", proveedor);
                if (ordencom != "")
                    sql.AppendFormat("AND SDBPOR = '{0}'\n", ordencom);

                sql.AppendFormat("AND SDBMAR = {0} \n", marca);
                sql.AppendFormat("AND SDBTEMP= '{0}' \n", tempo == "999" ? "TT" : tempo);
                // sql.Append("      AND SDBTIPO = 'C'\n");

                db2Comm.CommandText = sql.ToString();

                OleDbDataReader reader = db2Comm.ExecuteReader();

                while (reader.Read())
                {
                    noEvento = reader[0].ToString();
                }

                resultado = int.Parse(noEvento == "" ? "0" : noEvento);

                reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Inserta los cambios de calificacion sin folio y estsatus pendiente "
        public static bool insertNuevoCambioCal(string estilo, string proveedor, string ordencom, string marca, string nvaCalificacion, string estatus, string NoEventos, string fecharevic, string Usuario, string temp, string tipoReporte, decimal costoNvo, decimal difNuevo, string motivo, string calDirecta)
        {
            try
            {
                System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("es-MX");

                StringBuilder sql = new StringBuilder();
                string[] Fechas = DateTime.Now.GetDateTimeFormats();

                int Fecha400 = Convert.ToInt32(Fechas[6].Replace("-", "").Substring(2, 6));

                sql.Clear();
                sql.Append(" INSERT INTO MMNETLIB.SAT177CAL (SDBSTY, SDBPRV, SDBPOR, SDBCNVA, SDBEST, SDBQUY, SDBMAR, SDBFREV, SDBFEA, SDBUSR, SDBTEMP, SDBTIPO, SDBCTDNVO, SDBCDNVO, SDBMOT,SDBPAGAR) \n");
                sql.AppendFormat(" VALUES ('{0}', {1}, '{2}', {3}, '{4}', {5}, {6}, {7}, '{8}', '{9}','{10}','{11}',{12},{13},'{14}','{15}') "
                    , estilo, proveedor, ordencom, nvaCalificacion, estatus, NoEventos, marca, fecharevic, Fecha400, Usuario, temp, tipoReporte, costoNvo, difNuevo, motivo, calDirecta);

                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();

                    command.ExecuteNonQuery();

                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Regresa la consulta con los estilos en estaus de translado para asigna a folio "
        public static DataTable cambioCalEstatusTranslado()
        {
            OleDbConnection db2Conn = null;
            DataTable dtCamCalificacion = new DataTable();
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                sql.Clear();
                sql.Append("SELECT * FROM (\n");
                sql.Append("SELECT \n");
                sql.Append("         T2.DSPFRV AS FECHAR, \n");
                sql.Append("         SUBSTRING(CHAR(T2.DSPFRV), 5, 2) || '/'|| SUBSTRING(CHAR(T2.DSPFRV),3, 2) || '/' || '20' || SUBSTRING(CHAR(T2.DSPFRV),1, 2) AS FECHAREV,\n");
                sql.Append("         T1.SCCPRV AS IDPROV, \n");
                sql.Append("         T2.DSPNOM AS PROVEEDOR, \n");
                sql.Append("         T1.SCCSTY AS IDESTILO,  \n");
                sql.Append("         T2.DSPDES AS ESTILO,  \n");
                sql.Append("         T2.DSPDCP AS COMPRADOR, \n");
                sql.Append("         T1.SCCPOR AS ODCOMPRA, \n");
                sql.Append("         T2.DSPCAL AS PORCAL,  \n");
                sql.Append("         T1.SCCCAL AS PORCALNUE,\n");
                sql.Append("         T2.DSPONH AS ONHAND,   \n");
                sql.Append("         T2.DSPCSTA AS CSTACT, \n");
                sql.Append("         T2.DSPCST AS CSTTOT,  \n");
                sql.Append("         T2.DSPCSB AS CSTBON,  \n");
                sql.Append("         T2.DSPNMR AS MARCA,\n");
                sql.Append("         T1.SCCTEMP AS TEMP\n");
                sql.Append("    FROM MMNETLIB.SAT177SCC01 T1 \n");
                sql.Append("         INNER JOIN \n");
                sql.Append("         MMSATOBJ.SAT179F1 T2 ON CAST(T1.SCCSTY AS VARCHAR(100))= TRIM(CAST(T2.DSPSTY AS VARCHAR(100)))\n");
                sql.Append("          		             AND T1.SCCPRV = T2.DSPPRV\n");
                sql.Append("							 AND T1.SCCPOR = T2.DSPORD\n");
                sql.Append("							 AND T1.SCCMAR = T2.DSPNMR\n");
                sql.Append("							 AND T1.SCCFREV = T2.DSPFRV \n");
                sql.Append(" WHERE T1.SCCEST = 'T'\n");
                sql.Append("UNION ALL \n");
                sql.Append(" SELECT \n");
                sql.Append("         T2.PINFRB AS FECHAR, \n");
                sql.Append("         SUBSTRING(CHAR(T2.PINFRB), 5, 2) || '/'|| SUBSTRING(CHAR(T2.PINFRB),3, 2) || '/' || '20' || SUBSTRING(CHAR(T2.PINFRB),1, 2) AS FECHAREV,\n");
                sql.Append("         T1.SCCPRV AS IDPROV, \n");
                sql.Append("         T2.PINPRVD AS PROVEEDOR, \n");
                sql.Append("         T1.SCCSTY AS IDESTILO,  \n");
                sql.Append("         T2.PINSTYD AS ESTILO,  \n");
                sql.Append("         T2.PINCMP AS COMPRADOR, \n");
                sql.Append("         T1.SCCPOR AS ODCOMPRA, \n");
                sql.Append("         T2.PINCCO AS PORCAL,  \n");
                sql.Append("         T1.SCCCAL AS PORCALNUE,\n");
                sql.Append("         T2.PINOHP AS ONHAND,   \n");
                sql.Append("         T2.PINCST AS CSTACT, \n");
                sql.Append("         (T2.PINOHP * T2.PINCST) AS CSTTOT,  \n");
                sql.Append("         T2.PINBON AS CSTBON,  \n");
                sql.Append("         T1.SCCMAR AS MARCA,\n");
                sql.Append("         T1.SCCTEMP AS TEMP\n");
                sql.Append("  FROM MMNETLIB.SAT177SCC01 T1 INNER JOIN \n");
                sql.Append("       PASO.SAT178F2E T2 ON CAST(T1.SCCSTY AS VARCHAR(100))= TRIM(CAST(T2.PINSTY AS VARCHAR(100)))\n");
                sql.Append("          		             AND T1.SCCPRV = T2.PINPRV\n");
                sql.Append("							 AND T1.SCCMAR = CASE \n");
                sql.Append("												WHEN T2.PINBDG = 914  THEN 30  \n");
                sql.Append("												WHEN T2.PINBDG = 4 THEN 30 \n");
                sql.Append("												WHEN T2.PINBDG = 6 THEN 30 \n");
                sql.Append("												WHEN T2.PINBDG = 915 THEN 10 \n");
                sql.Append("												WHEN T2.PINBDG = 3   THEN 10 \n");
                sql.Append("												WHEN T2.PINBDG = 5   THEN 10  \n");
                sql.Append("												WHEN T2.PINBDG = 7   THEN 60  \n");
                sql.Append("												WHEN T2.PINBDG = 917 THEN 60 ELSE 0 END\n");
                sql.Append("							 AND T1.SCCFREV = T2.PINFRB \n");
                sql.Append(" WHERE T1.SCCEST = 'T'\n");
                sql.Append("		) convenio				\n");
                sql.Append(" ORDER BY PROVEEDOR,ESTILO  ASC\n");

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;
                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);
                daDb2.Fill(dtCamCalificacion);

                return dtCamCalificacion;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Obtener el número de folio para Estilos Preautorizados "
        public static string ObtieneFolio()
        {
            StringBuilder sql = new StringBuilder();
            string dato = "";

            try
            {
                sql.Clear();
                sql.Append("  SELECT IFNULL(MAX(SCCFOL), 0) + 1  FROM MMNETLIB.SAT177SCC01 ");  // # maximo del folio a insertar

                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();

                    OleDbDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        dato = reader[0].ToString();
                    }

                    reader.Close();
                }

                return dato;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Actualiza el estado y agrega el número de folio para Estilos Preautorizados "
        public static int nuevoFolioCamCal(DataTable dtIngresaFolio)
        {
            try
            {
                int idApp = 0;
                StringBuilder sql = new StringBuilder();
                using (OleDbConnection DB = new OleDbConnection(Db2_Prod))
                {
                    DB.Open();
                    OleDbCommand command = new OleDbCommand();
                    command.Connection = DB;
                    command.CommandType = CommandType.Text;

                    foreach (DataRow insert in dtIngresaFolio.Rows)
                    {
                        string folio = string.Empty, idProv = string.Empty, idStilo = string.Empty, ordenCompra = string.Empty, marcaT = string.Empty, fecharevi = string.Empty;
                        string tem = string.Empty;

                        folio = insert["FOLIO"].ToString();
                        idProv = insert["IDPROV"].ToString();
                        idStilo = insert["IDESTILO"].ToString();
                        ordenCompra = insert["ODCOMPRA"].ToString();
                        marcaT = insert["MARCA"].ToString();
                        fecharevi = insert["FECHAR"].ToString();
                        tem = insert["TEMP"].ToString();

                        sql.Clear();
                        sql.Append("UPDATE MMNETLIB.SAT177SCC01	\n");
                        sql.AppendFormat(" SET  SCCFOL = {0}, SCCEST = 'P' \n", folio);
                        sql.AppendFormat("WHERE SCCSTY = '{0}' \n", idStilo); ;
                        sql.AppendFormat("  AND SCCPRV = {0} \n", idProv);
                        sql.AppendFormat("  AND SCCPOR = {0} \n", ordenCompra);
                        sql.AppendFormat("  AND SCCMAR = {0} \n", marcaT);
                        sql.AppendFormat("  AND SCCFREV = {0} \n", fecharevi);
                        sql.AppendFormat("  AND SCCTEMP = '{0}' \n", tem);

                        command.CommandText = sql.ToString();
                        command.ExecuteNonQuery();
                        idApp = 1;
                    }
                }
                return idApp;
            }
            catch (Exception ex)
            {
                throw new Exception(" No se pudo completar el proceso del Folio. !Comuniquese con el administrador¡");
            }
        }
        #endregion

        #region " Carga los Folio que ya estan dados de alta "
        public static DataTable CargaListaFolios(string Folio = "P")
        {
            OleDbConnection db2Conn = null;
            DataTable dtFolios = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Clear();
                sql.Append("SELECT DISTINCT SCCFOL AS FOLIO,\n");
                sql.Append("     CAST(CASE SCCEST WHEN 'P' THEN 'Pendiente' \n");
                sql.Append("                      WHEN 'A' THEN 'Autorizado'  \n");
                sql.Append("                      WHEN 'C' THEN 'Vencido' END AS VARCHAR(20)) AS ESTATUS,\n");
                sql.Append("                      CAST(SCCEST AS VARCHAR(10)) AS IDESTATUS\n");
                sql.Append("   FROM MMNETLIB.SAT177SCC01 \n");
                sql.AppendFormat(" 	WHERE SCCEST ='{0}'\n ", Folio);
                sql.Append(" ORDER BY SCCFOL ASC\n");

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtFolios);

                return dtFolios;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Carga el detalle de los estilos que ya tienen folio Devolucion y Bonifica"
        public static DataTable CargaDetalleFolioDevBon(string Folio)
        {
            OleDbConnection db2Conn = null;
            DataTable dtFolios = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {

                sql.Clear();
                sql.Append(" SELECT \n");
                sql.Append("	  FECHAR,\n");
                sql.Append("	  FECHAREV,\n");
                sql.Append("	  FOLIO,\n");
                sql.Append("	  IDPROV,\n");
                sql.Append("	  PROVEEDOR,\n");
                sql.Append("	  IDESTILO,\n");
                sql.Append("	  ESTILO,\n");
                sql.Append("	  COMPRADOR,	\n");
                sql.Append("	  ODCOMPRA,	\n");
                sql.Append("	  IDTIPOOP,\n");
                sql.Append("      TIPOOP,\n");
                //sql.Append("      CALDIR,\n");
                sql.Append("      PORCAL,\n");
                sql.Append("	  ONHAND,\n");
                sql.Append("	  CSTACT,\n");
                sql.Append("	  CSTTOT,\n");
                sql.Append("	  CSTBON,\n");
                sql.Append("	  CSTBONNUE,\n");
                sql.Append("	  PORNVOBONXDEV,\n");
                sql.Append("	  CSTNVOBONXDEV,\n");
                sql.Append("	  PENDEVXBON,\n");
                sql.Append("	  PORNVODEVXBON,\n");
                sql.Append("	  PORNVOCCAL,\n");
                sql.Append("	  CSTNVOCCAL,\n");
                sql.Append("	  DIFNVOCCAL,\n");
                sql.Append("	  MARCA,\n");
                sql.Append("	  TEMP,\n");
                sql.Append("	  ESTATUS\n");
                sql.Append("	  FROM MMNETLIB.SAT177CDP1\n");
                sql.AppendFormat("WHERE FOLIO = '{0}' \n", Folio);
                sql.Append("ORDER BY PROVEEDOR,	ESTILO   	\n");


                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtFolios);

                return dtFolios;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Autoriza los Flios cambia el estatus "
        public static bool AutorizaFolio(string folio, string estatus, DataTable autorizado)
        {
            StringBuilder sql = new StringBuilder();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    connection.Open();
                    OleDbCommand command = new OleDbCommand();
                    command.Connection = connection;
                    command.CommandType = CommandType.Text;

                    sql.Clear();
                    sql.AppendFormat(" UPDATE MMNETLIB.SAT177SCC01 SET SCCEST = '{0}' WHERE SCCFOL = '{1}' ", estatus, folio);
                    command.CommandText = sql.ToString();
                    command.ExecuteNonQuery();
                    /*
                    foreach (DataRow insert in autorizado.Rows)
                    {
                        string idProv = string.Empty, idStilo = string.Empty, ordenCompra = string.Empty, marcaT = string.Empty, califNueva = string.Empty, fecharevi = string.Empty;
                        string temp = string.Empty;

                        decimal bonificaNue = 0;
                        idProv = insert["IDPROV"].ToString();
                        idStilo = insert["IDESTILO"].ToString();
                        ordenCompra = insert["ODCOMPRA"].ToString();
                        marcaT = insert["MARCA"].ToString();
                        califNueva = insert["PORCALNUE"].ToString();
                        bonificaNue = Convert.ToDecimal(insert["CSTBONNUE"].ToString());
                        fecharevi = insert["FECHAR"].ToString();
                        temp = insert["TEMP"].ToString();

                        if (temp.ToUpper().Trim() == "TT")
                        {
                            sql.Clear();
                            sql.Append("UPDATE MMSATOBJ.SAT179F1 \n");
                            sql.AppendFormat(" SET  DSPCLF = '{0}', DSPCSB = '{1}' \n", califNueva, bonificaNue);
                            sql.AppendFormat("WHERE DSPSTY = '{0}' \n", idStilo); ;
                            sql.AppendFormat("  AND DSPPRV = {0} \n", idProv);
                            sql.AppendFormat("  AND DSPORD = {0} \n", ordenCompra);
                            sql.AppendFormat("  AND DSPNMR = {0} \n", marcaT);
                            sql.AppendFormat("  AND DSPFRV = {0} \n", fecharevi);

                            command.CommandText = sql.ToString();
                            command.ExecuteNonQuery();

                            sql.Clear();
                            sql.Append("CALL MMSATPGM.SAT179C4 (\n");
                            sql.Append("'CALIFICA  '\n");
                            sql.Append(") \n");

                            command.CommandText = sql.ToString();
                            command.ExecuteNonQuery();

                            sql.Clear();
                            sql.Append("UPDATE MMSATOBJ.SAT179PF \n");
                            sql.AppendFormat(" SET  DSPCLF = '{0}', DSPCSB = '{1}' \n", califNueva, bonificaNue);
                            sql.AppendFormat("WHERE DSPSTY = '{0}' \n", idStilo); ;
                            sql.AppendFormat("  AND DSPPRV = {0} \n", idProv);
                            sql.AppendFormat("  AND DSPORD = {0} \n", ordenCompra);
                            sql.AppendFormat("  AND DSPNMR = {0} \n", marcaT);
                            sql.AppendFormat("  AND DSPFRV = {0} \n", fecharevi);

                            command.CommandText = sql.ToString();
                            command.ExecuteNonQuery();
                        }
                        else
                        {
                            sql.Clear();
                            sql.Append("UPDATE PASO.SAT178F2E \n");
                            sql.AppendFormat(" SET  PINCCO = '{0}' \n", califNueva);
                            sql.AppendFormat("WHERE PINSTY = '{0}' \n", idStilo); ;
                            sql.AppendFormat("  AND PINPRV = {0} \n", idProv);
                            sql.AppendFormat("  AND CASE \n");
                            sql.AppendFormat("	         WHEN PINBDG = 914  THEN 30  \n");
                            sql.AppendFormat("           WHEN PINBDG = 4 THEN 30 \n");
                            sql.AppendFormat("           WHEN PINBDG = 6 THEN 30 \n");
                            sql.AppendFormat("           WHEN PINBDG = 915 THEN 10 \n");
                            sql.AppendFormat("           WHEN PINBDG = 3   THEN 10 \n");
                            sql.AppendFormat("           WHEN PINBDG = 5   THEN 10  \n");
                            sql.AppendFormat("           WHEN PINBDG = 7   THEN 60  \n");
                            sql.AppendFormat("           WHEN PINBDG = 917 THEN 60 ELSE 0 END = {0} \n", marcaT);
                            sql.AppendFormat("  AND PINFRB = {0} \n", fecharevi);

                            command.CommandText = sql.ToString();
                            command.ExecuteNonQuery();
                        }
                    }
                    */
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Elimina los registros que no autorizaron "
        public static bool EliminaNoAutorizados(string folio, string fechaRev, string estilo, string proveedor, string ordencompra, string marca, string temp)
        {
            StringBuilder sql = new StringBuilder();
            try
            {
                sql.Clear();
                sql.AppendFormat(" DELETE FROM MMNETLIB.SAT177SCC01 WHERE SCCFOL = '{0}' AND SCCPRV = '{1}' AND SCCSTY = '{2}' AND SCCPOR = '{3}' AND SCCMAR = '{4}' AND SCCFREV = '{5}' AND SCCTEMP = '{6}'", folio, proveedor, estilo, ordencompra, marca, fechaRev, temp);

                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();

                    command.ExecuteNonQuery();

                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Acualiza el cambios de Calificacion "
        public static bool cambioCalAutorizados(string folio, string estilo, string proveedor, string ordencompra, string marca, decimal nuevaCalificacion)
        {
            StringBuilder sql = new StringBuilder();
            try
            {
                sql.Clear();
                sql.AppendFormat(" UPDATE MMNETLIB.SAT177SCC01 \n");
                sql.AppendFormat(" SET  SCCCAL = {0} \n", nuevaCalificacion);
                sql.AppendFormat("WHERE SCCFOL = '{0}' \n", folio);
                sql.AppendFormat("  AND SCCSTY = '{0}' \n", estilo);
                sql.AppendFormat("  AND SCCPRV = {0} \n", proveedor);
                sql.AppendFormat("  AND SCCPOR = {0} \n", ordencompra);
                sql.AppendFormat("  AND SCCMAR = {0} \n", marca); ;

                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();

                    command.ExecuteNonQuery();

                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " obtiene el Maximo Calificacion pr marca"
        public static decimal obtenMaximoCalificacion(string marca)
        {
            decimal resultado = 0;
            StringBuilder sql = new StringBuilder();
            string noEvento = "";
            OleDbConnection db2Conn = null;

            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.AppendFormat("SELECT IFNULL(MARPLC, 0) FROM MMSATOBJ.SAT177SMAR WHERE MARMID  = '{0}' \n", marca);
                db2Comm.CommandText = sql.ToString();

                OleDbDataReader reader = db2Comm.ExecuteReader();

                while (reader.Read())
                {
                    noEvento = reader[0].ToString();
                }

                resultado = Convert.ToDecimal(noEvento == "" ? "0" : noEvento);

                reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " obtiene la penalizacion p0r marca"
        public static decimal obtenBoXDevo(string marca)
        {
            decimal resultado = 0;
            StringBuilder sql = new StringBuilder();
            string regresa = "";
            OleDbConnection db2Conn = null;

            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.AppendFormat("SELECT IFNULL(FIRDEC, 0) FROM MMNETLIB.SAT177CFR WHERE FIRGRU = 'BD' AND FIRAMARCA = '{0}' \n", marca);
                db2Comm.CommandText = sql.ToString();

                OleDbDataReader reader = db2Comm.ExecuteReader();

                while (reader.Read())
                {
                    regresa = reader[0].ToString();
                }

                resultado = Convert.ToDecimal(regresa == "" ? "0" : regresa);

                reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " obtiene la penalizacion p0r marca"
        public static string obtenPenalizacionBon(string marca)
        {
            StringBuilder sql = new StringBuilder();
            string regresa = "";
            OleDbConnection db2Conn = null;

            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.AppendFormat("SELECT IFNULL(FIRPEN, 0) FROM MMNETLIB.SAT177CFR WHERE FIRGRU = 'DB' AND FIRAMARCA = '{0}' \n", marca);
                db2Comm.CommandText = sql.ToString();

                OleDbDataReader reader = db2Comm.ExecuteReader();

                while (reader.Read())
                {
                    regresa = reader[0].ToString();
                }

                reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return regresa;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Inserta los cambios de la Devolucion por bonificacion sin folio y estsatus pendiente "
        public static bool insertNuevaDevolucionBon(string estilo, string proveedor, string ordencom, string marca, string penalizacion, string montoPena, string motivo, string estatus, string NoEventos, string fecharevic, string Usuario, string temp, string calDirecta)
        {
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("es-MX");

            StringBuilder sql = new StringBuilder();
            string[] Fechas = DateTime.Now.GetDateTimeFormats();

            int Fecha400 = Convert.ToInt32(Fechas[6].Replace("-", "").Substring(2, 6));


            sql.Clear();
            sql.Append(" INSERT INTO MMNETLIB.SAT177CAL (SDBSTY, SDBPRV, SDBPOR, SDBPORP, SDBCAL, SDBMOT , SDBEST, SDBQUY, SDBMAR, SDBFREV, SDBFEA, SDBUSR, SDBTEMP, SDBPAGAR, SDBTIPO) \n ");
            sql.AppendFormat("                     VALUES ('{0}', '{1}', '{2}', '{3}', {4}, '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}','{12}','{13}','B') ",
                                      estilo, proveedor, ordencom, penalizacion, decimal.Parse(montoPena), motivo, estatus, NoEventos, marca, fecharevic, Fecha400, Usuario, temp, calDirecta);

            using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
            {
                OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                connection.Open();

                command.ExecuteNonQuery();

                return true;
            }
        }
        #endregion

        #region " Inserta los cambios de de bonificacion por devolución sin folio y estsatus pendiente "
        public static bool insertNuevaBonXDev(string estilo, string proveedor, string ordencom, string marca, string porcentageNvo, string costoNuevo, string motivo, string estatus, string NoEventos, string fecharevic, string Usuario, string temp, string calDirecta)
        {
            try
            {

                System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("es-MX");

                StringBuilder sql = new StringBuilder();

                string[] Fechas = DateTime.Now.GetDateTimeFormats();

                int Fecha400 = Convert.ToInt32(Fechas[6].Replace("-", "").Substring(2, 6));

                sql.Clear();
                sql.Append(" INSERT INTO MMNETLIB.SAT177CAL (SDBSTY, SDBPRV, SDBPOR, SDBMOT, SDBEST, SDBQUY, SDBMAR, SDBFREV, SDBFEA, SDBUSR, SDBTEMP, SDBDPNVO, SDBDCTNVO, SDBPAGAR, SDBTIPO) \n ");
                sql.AppendFormat("                     VALUES ('{0}', '{1}', '{2}',  '{3}',   '{4}',  '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', {11}, {12}, '{13}', 'D') ",
                                                            estilo, proveedor, ordencom, motivo, estatus, NoEventos, marca, fecharevic, Fecha400, Usuario, temp, Convert.ToDecimal(porcentageNvo), Convert.ToDecimal(costoNuevo), calDirecta);

                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();

                    command.ExecuteNonQuery();

                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Regresa la consulta con los estilos en estaus de translado para asigna a folio en devolucion "
        public static DataTable cambioDelEstatusTranslado(string idComprador, string Marca)
        {
            OleDbConnection db2Conn = null;
            DataTable dtCamDevolucion = new DataTable();
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                sql.Clear();
                sql.Append("SELECT \n");
                sql.Append("       FECHAR,\n");
                sql.Append("       FECHAREV,\n");
                sql.Append("       IDPROV,\n");
                sql.Append("       PROVEEDOR,\n");
                sql.Append("       IDESTILO,\n");
                sql.Append("       ESTILO,\n");
                sql.Append("       COMPRADOR,\n");
                sql.Append("       ODCOMPRA,\n");
                sql.Append("       IDTIPOOP,\n");
                sql.Append("       TIPOOP,\n");
                // sql.Append("       CALDIR,\n");
                sql.Append("       ONHAND,\n");
                sql.Append("       CSTACT,\n");
                sql.Append("       CSTTOT,\n");
                sql.Append("       CSTBON,\n");
                sql.Append("       MARCA,\n");
                sql.Append("       TEMP\n");

                sql.Append("      FROM MMNETLIB.SAT177CDP1 \n");

                sql.Append("      WHERE IDESTATUS = 'T' \n");
                if (idComprador != "999")
                    sql.AppendFormat("    AND  IDCOMPRADOR = '{0}' \n", idComprador);

                sql.Append("     ORDER BY PROVEEDOR,ESTILO  ASC\n");

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;
                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);
                daDb2.Fill(dtCamDevolucion);

                return dtCamDevolucion;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Actualiza el estado y agrega el número de folio para Estilos Preautorizados en devolucion bonificacion"
        public static int nuevoFolioCamDevBon(DataTable dtIngresaFolio)
        {
            try
            {
                int idApp = 0;
                StringBuilder sql = new StringBuilder();
                using (OleDbConnection DB = new OleDbConnection(Db2_Prod))
                {
                    DB.Open();
                    OleDbCommand command = new OleDbCommand();
                    command.Connection = DB;
                    command.CommandType = CommandType.Text;

                    foreach (DataRow insert in dtIngresaFolio.Rows)
                    {
                        string folio = string.Empty, idProv = string.Empty, idStilo = string.Empty, ordenCompra = string.Empty, marcaT = string.Empty, fecharevi = string.Empty;
                        string tem = string.Empty, tipoOperacion = string.Empty;

                        folio = insert["FOLIO"].ToString();
                        idProv = insert["IDPROV"].ToString();
                        idStilo = insert["IDESTILO"].ToString();
                        ordenCompra = insert["ODCOMPRA"].ToString();
                        marcaT = insert["MARCA"].ToString();
                        fecharevi = insert["FECHAR"].ToString();
                        tem = insert["TEMP"].ToString();
                        tipoOperacion = insert["IDTIPOOP"].ToString();

                        sql.Clear();
                        sql.Append("UPDATE MMNETLIB.SAT177CAL	\n");
                        sql.AppendFormat(" SET  SDBFOL = {0}, SDBEST = 'P' \n", folio);
                        sql.AppendFormat("WHERE SDBSTY = '{0}' \n", idStilo); ;
                        sql.AppendFormat("  AND SDBPRV = {0} \n", idProv);
                        sql.AppendFormat("  AND SDBPOR = {0} \n", ordenCompra);
                        sql.AppendFormat("  AND SDBMAR = {0} \n", marcaT);
                        sql.AppendFormat("  AND SDBFREV = {0} \n", fecharevi);
                        sql.AppendFormat("  AND SDBTEMP = '{0}' \n", tem);
                        sql.AppendFormat("  AND SDBTIPO = '{0}' \n", tipoOperacion);

                        command.CommandText = sql.ToString();
                        command.ExecuteNonQuery();
                        idApp = 1;
                    }
                }
                return idApp;
            }
            catch (Exception ex)
            {
                throw new Exception(" No se pudo completar el proceso del Folio. !Comuniquese con el administrador¡");
            }
        }
        #endregion

        #region " Obtener el número de folio para Estilos Preautorizados devolucion Bonificacion"
        public static string ObtieneFolioDevBon()
        {
            StringBuilder sql = new StringBuilder();
            string dato = "";

            try
            {
                sql.Clear();
                sql.Append("  SELECT IFNULL(MAX(SDBFOL), 0) + 1  FROM MMNETLIB.SAT177CAL ");  // # maximo del folio a insertar

                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();

                    OleDbDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        dato = reader[0].ToString();
                    }

                    reader.Close();
                }

                return dato;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Carga los Folio que ya estan dados de alta en estatus P y A de Devolucion Bonifinicacion "
        public static DataTable CargaListaFoliosDevBon(string idComprador, string Folio = "P")
        {
            OleDbConnection db2Conn = null;
            DataTable dtFolios = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Clear();
                sql.Append(" SELECT DISTINCT SDBFOL AS FOLIO, ");
                sql.Append(" CAST(CASE SDBEST WHEN 'P' THEN 'Pendiente' ");
                sql.Append("     WHEN 'A' THEN 'Autorizado' END AS VARCHAR(20)) AS ESTATUS, ");
                sql.Append(" CAST(SDBEST AS VARCHAR(10)) AS IDESTATUS ");
                sql.Append(" FROM MMNETLIB.SAT177CAL T1    ");
                sql.Append(" LEFT JOIN MMNETLIB.SAT177CDP1 T2 ");
                sql.Append(" ON T1.SDBSTY = T2.IDESTILO");
                sql.Append(" AND T1.SDBPRV = T2.IDPROV ");
                sql.Append(" AND T1.SDBPOR = T2.ODCOMPRA ");
                sql.Append(" AND T1.SDBMAR = T2.MARCA ");
                //sql.Append(" AND T1.SDBFREV = T2.MDYFCH");
                sql.AppendFormat(" 	WHERE SDBEST ='{0}'\n ", Folio);

                if (idComprador != "999")
                    sql.AppendFormat(" 	AND  T2.IDCOMPRADOR ='{0}'\n ", idComprador);

                sql.Append(" ORDER BY SDBFOL ASC\n");

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtFolios);

                return dtFolios;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Carga el detalle de los estilos que ya tienen folio "
        public static DataTable CargaDetalleFolio(string Folio)
        {
            OleDbConnection db2Conn = null;
            DataTable dtFolios = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Clear();
                sql.Append(" SELECT * FROM ( \n");
                sql.Append(" SELECT T2.DSPFRV AS FECHAR, \n");
                sql.Append("      SUBSTRING(CHAR(T2.DSPFRV), 5, 2) || '/'|| SUBSTRING(CHAR(T2.DSPFRV),3, 2) || '/' || '20' || SUBSTRING(CHAR(T2.DSPFRV),1, 2) AS FECHAREV, \n");
                sql.Append("      T1.SCCFOL AS FOLIO,  \n");
                sql.Append("      T1.SCCPRV AS IDPROV,   \n");
                sql.Append("      T2.DSPNOM AS PROVEEDOR,  \n");
                sql.Append("      T1.SCCSTY AS IDESTILO, \n");
                sql.Append("      T2.DSPDES AS ESTILO,  \n");
                sql.Append("      T2.DSPDCP AS COMPRADOR,  \n");
                sql.Append("      T1.SCCPOR AS ODCOMPRA,  \n");
                sql.Append("      T2.DSPCAL AS PORCAL,  \n");
                sql.Append("      CAST(T1.SCCCAL AS VARCHAR(100)) || '%' AS PORCALNUE, \n");
                sql.Append("      T2.DSPONH AS ONHAND,  \n");
                sql.Append("      T2.DSPCSTA AS CSTACT,  \n");
                sql.Append("      T2.DSPCST AS CSTTOT,  \n");
                sql.Append("      T2.DSPCSB AS CSTBON,  \n");
                sql.Append("      CASE WHEN T1.SCCCAL = 0 THEN 0 ELSE ((T2.DSPCST * T1.SCCCAL) / 100.0) END AS CSTBONNUE,\n");
                sql.Append("      T2.DSPNMR AS MARCA,  \n");
                sql.Append("      T1.SCCTEMP AS TEMP,  \n");
                sql.Append("      CAST(CASE T1.SCCEST WHEN 'P' THEN 'Pendiente' \n");
                sql.Append("                          WHEN 'A' THEN 'Autorizado' END AS VARCHAR(20)) AS ESTATUS \n");
                sql.Append(" FROM MMNETLIB.SAT177SCC01 T1  \n");
                sql.Append("         INNER JOIN  \n");
                sql.Append("      MMSATOBJ.SAT179F1 T2 ON CAST(T1.SCCSTY AS VARCHAR(100))= TRIM(CAST(T2.DSPSTY AS VARCHAR(100))) \n");
                sql.Append("       		              AND T1.SCCPRV = T2.DSPPRV \n");
                sql.Append("						  AND T1.SCCPOR = T2.DSPORD \n");
                sql.Append("						  AND T1.SCCMAR = T2.DSPNMR \n");
                sql.Append("						  AND T1.SCCFREV = T2.DSPFRV  \n");
                sql.Append("UNION ALL \n");
                sql.Append(" SELECT \n");
                sql.Append("         T2.PINFRB AS FECHAR, \n");
                sql.Append("         SUBSTRING(CHAR(T2.PINFRB), 5, 2) || '/'|| SUBSTRING(CHAR(T2.PINFRB),3, 2) || '/' || '20' || SUBSTRING(CHAR(T2.PINFRB),1, 2) AS FECHAREV,\n");
                sql.Append("         T1.SCCFOL AS FOLIO, \n");
                sql.Append("         T1.SCCPRV AS IDPROV, \n");
                sql.Append("         T2.PINPRVD AS PROVEEDOR, \n");
                sql.Append("         T1.SCCSTY AS IDESTILO,  \n");
                sql.Append("         T2.PINSTYD AS ESTILO,  \n");
                sql.Append("         T2.PINCMP AS COMPRADOR, \n");
                sql.Append("         T1.SCCPOR AS ODCOMPRA, \n");
                sql.Append("         T2.PINCCO AS PORCAL,  \n");
                sql.Append("         CAST(T1.SCCCAL AS VARCHAR(100)) || '%' AS PORCALNUE, \n");
                sql.Append("         T2.PINOHP AS ONHAND,   \n");
                sql.Append("         T2.PINCST AS CSTACT, \n");
                sql.Append("         (T2.PINOHP * T2.PINCST) AS CSTTOT,  \n");
                sql.Append("         T2.PINBON AS CSTBON,  \n");
                sql.Append("         CASE WHEN T1.SCCCAL = 0 THEN 0 ELSE (((T2.PINOHP * T2.PINCST) * T1.SCCCAL) / 100.0) END AS CSTBONNUE,\n");
                sql.Append("         T1.SCCMAR AS MARCA,\n");
                sql.Append("         T1.SCCTEMP AS TEMP, \n");
                sql.Append("         CAST(CASE T1.SCCEST WHEN 'P' THEN 'Pendiente' \n");
                sql.Append("                          WHEN 'A' THEN 'Autorizado' END AS VARCHAR(20)) AS ESTATUS \n");
                sql.Append("  FROM MMNETLIB.SAT177SCC01 T1 INNER JOIN \n");
                sql.Append("       PASO.SAT178F2E T2 ON CAST(T1.SCCSTY AS VARCHAR(100))= TRIM(CAST(T2.PINSTY AS VARCHAR(100)))\n");
                sql.Append("          		             AND T1.SCCPRV = T2.PINPRV\n");
                sql.Append("							 AND T1.SCCMAR = CASE \n");
                sql.Append("												WHEN T2.PINBDG = 914  THEN 30  \n");
                sql.Append("												WHEN T2.PINBDG = 4 THEN 30 \n");
                sql.Append("												WHEN T2.PINBDG = 6 THEN 30 \n");
                sql.Append("												WHEN T2.PINBDG = 915 THEN 10 \n");
                sql.Append("												WHEN T2.PINBDG = 3   THEN 10 \n");
                sql.Append("												WHEN T2.PINBDG = 5   THEN 10  \n");
                sql.Append("												WHEN T2.PINBDG = 7   THEN 60  \n");
                sql.Append("												WHEN T2.PINBDG = 917 THEN 60 ELSE 0 END\n");
                sql.Append("							 AND T1.SCCFREV = T2.PINFRB \n");
                sql.Append("     )califica\n");
                sql.AppendFormat("WHERE FOLIO = '{0}' \n", Folio);
                sql.Append("ORDER BY PROVEEDOR,	ESTILO   \n");

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtFolios);

                return dtFolios;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Elimina los registros que no autorizaron del Dev Bonifica"
        public static bool EliminaNoAutorizadosDebBon(string folio, string fechaRev, string estilo, string proveedor, string ordencompra, string marca, string temp, string tipoOp)
        {
            StringBuilder sql = new StringBuilder();
            try
            {
                sql.Clear();
                sql.AppendFormat(" DELETE FROM MMNETLIB.SAT177CAL WHERE SDBFOL = '{0}' AND SDBPRV = '{1}' AND SDBSTY = '{2}' AND SDBPOR = '{3}' AND SDBMAR = '{4}' AND SDBFREV = '{5}' AND SDBTEMP = '{6}' AND SDBTIPO = '{7}'", folio, proveedor, estilo, ordencompra, marca, fechaRev, temp, tipoOp);

                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();

                    command.ExecuteNonQuery();

                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Autoriza los Flios cambia el estatus Mot DEvo Boni "
        public static bool AutorizaFolioDevBon(string folio, string estatus, DataTable autorizado, string usuario)
        {
            StringBuilder sql = new StringBuilder();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("es-MX");

                    connection.Open();
                    OleDbCommand command = new OleDbCommand();
                    command.Connection = connection;
                    command.CommandType = CommandType.Text;

                    string[] Fechas = DateTime.Now.GetDateTimeFormats();

                    int Fecha400 = Convert.ToInt32(Fechas[6].Replace("-", "").Substring(2, 6));
                    int minutos400 = Convert.ToInt32(Fechas[94].Replace(":", ""));

                    sql.Clear();
                    sql.AppendFormat(" UPDATE MMNETLIB.SAT177CAL SET SDBEST = '{0}' WHERE SDBFOL = '{1}' ", estatus, folio);
                    command.CommandText = sql.ToString();
                    command.ExecuteNonQuery();
                    /*
                    foreach (DataRow insert in autorizado.Rows)
                    {
                        string idProv = string.Empty, idStilo = string.Empty, ordenCompra = string.Empty, marcaT = string.Empty, califNueva = string.Empty, fecharevi = string.Empty;
                        string temp = string.Empty, tipoOper = String.Empty, calDirecta = string.Empty, marca = string.Empty;
                        //FECHAR	FECHAREV	FOLIO	IDPROV	PROVEEDOR	IDESTILO	ESTILO	COMPRADOR	ODCOMPRA	IDTIPOOP	TIPOOP	CALDIR
                        //ONHAND	CSTACT	CSTTOT	CSTBON	CSTBONNUE	PORNVOBONXDEV	CSTNVOBONXDEV	PENDEVXBON	PORNVODEVXBON	PORNVOCCAL	CSTNVOCCAL	DIFNVOCCAL	MARCA
                        //    ONHAND	CSTACT	CSTTOT	CSTBON	CSTBONNUE	  PORNVOBONXDEV	CSTNVOBONXDEV	PENDEVXBON	PORNVODEVXBON	PORNVOCCAL	CSTNVOCCAL	DIFNVOCCAL	MARCA
                        //    4,720	 31	    146,320 58,528	14,986,679.68	    0	          0 	          7	         10,242.4	      0         	0	      0     	30
                        decimal bonificaNue = 0, onhand = 0, cstact = 0, csttot = 0, cstbon = 0, cstbonnue = 0, pornvobonxdev = 0, cstnvobonxdev = 0;
                        decimal pornvodevxbon = 0, pornvoccal = 0, cstnvoccal = 0, difnvoccal = 0;
                        fecharevi = insert["FECHAR"].ToString();
                        idProv = insert["IDPROV"].ToString();
                        idStilo = insert["IDESTILO"].ToString();
                        ordenCompra = insert["ODCOMPRA"].ToString();
                        tipoOper = insert["IDTIPOOP"].ToString();
                        //calDirecta = insert["CALDIR"].ToString();

                        onhand = Convert.ToDecimal(insert["ONHAND"].ToString());
                        cstact = Convert.ToDecimal(insert["CSTACT"].ToString());
                        csttot = Convert.ToDecimal(insert["CSTTOT"].ToString());
                        cstbon = Convert.ToDecimal(insert["CSTBON"].ToString());
                        cstbonnue = Convert.ToDecimal(insert["CSTBONNUE"].ToString());
                        pornvobonxdev = Convert.ToDecimal(insert["PORNVOBONXDEV"].ToString());
                        cstnvobonxdev = Convert.ToDecimal(insert["CSTNVOBONXDEV"].ToString());
                        pornvodevxbon = Convert.ToDecimal(insert["PORNVODEVXBON"].ToString());
                        pornvoccal = Convert.ToDecimal(insert["PORNVOCCAL"].ToString());
                        cstnvoccal = Convert.ToDecimal(insert["CSTNVOCCAL"].ToString());
                        difnvoccal = Convert.ToDecimal(insert["DIFNVOCCAL"].ToString());

                        marcaT = insert["MARCA"].ToString();
                        temp = insert["TEMP"].ToString();


                        //if (temp.ToUpper().Trim() == "TT")
                        //{
                        if (calDirecta.Replace(" ", "").Trim() == "Pagar")
                        {
                            califNueva = calDirecta;
                            bonificaNue = 0;
                        }
                        else if (tipoOper.Trim() == "D")
                        {
                            califNueva = cstnvobonxdev.ToString();
                            bonificaNue = pornvobonxdev;
                        }
                        else if (tipoOper.Trim() == " B")
                        {
                            califNueva = "Devolucion";
                            bonificaNue = 0;
                        }
                        else if (tipoOper.Trim() == " C")
                        {
                            califNueva = pornvoccal.ToString();
                            bonificaNue = cstnvoccal;
                        }

                        sql.Clear();
                        sql.Append("UPDATE MMSATOBJ.SAT179F1 \n");
                        sql.AppendFormat(" SET  DSPCLF = '{0}', DSPCSB = '{1}', \n",bonificaNue , califNueva);
                        sql.AppendFormat("      DSPFCT = '{0}', DSPHCT = '{1}', \n", Fecha400, minutos400);
                        sql.AppendFormat("      DSPUCT = '{0}' \n", usuario);
                        //DSPUCP            Usuario Compras                                10      
                        //DSPFCP            Fecha Compras                                   6    0 
                        //DSPHCP            Hora Compras                                    6    0 
                        //DSPUCT            Usuario Contral                                10      
                        //DSPFCT            Fecha Contral                                   6    0 
                        //DSPHCT            Hora Contral                                    6    0
                        sql.AppendFormat("WHERE DSPSTY = '{0}' \n", idStilo); ;
                        sql.AppendFormat("  AND DSPPRV = {0} \n", idProv);
                        sql.AppendFormat("  AND DSPORD = {0} \n", ordenCompra);
                        sql.AppendFormat("  AND DSPNMR = {0} \n", marcaT);
                        sql.AppendFormat("  AND DSPFRV = {0} \n", fecharevi);

                        command.CommandText = sql.ToString();
                        command.ExecuteNonQuery();

                        sql.Clear();
                        sql.Append("CALL MMSATPGM.SAT179C4 (\n");
                        sql.Append("'CALIFICA  '\n");
                        sql.Append(") \n");

                        command.CommandText = sql.ToString();
                        command.ExecuteNonQuery();

                        sql.Clear();
                        sql.Append("UPDATE MMSATOBJ.SAT179PF \n");
                        sql.AppendFormat(" SET  DSPCLF = '{0}', DSPCSB = '{1}', \n",bonificaNue , califNueva);
                        sql.AppendFormat("      DSPFCT = '{0}', DSPHCT = '{1}', \n", Fecha400, minutos400);
                        sql.AppendFormat("      DSPUCT = '{0}' \n", usuario);
                        sql.AppendFormat("WHERE DSPSTY = '{0}' \n", idStilo); ;
                        sql.AppendFormat("  AND DSPPRV = {0} \n", idProv);
                        sql.AppendFormat("  AND DSPORD = {0} \n", ordenCompra);
                        sql.AppendFormat("  AND DSPNMR = {0} \n", marcaT);
                        sql.AppendFormat("  AND DSPFRV = {0} \n", fecharevi);

                        command.CommandText = sql.ToString();
                        command.ExecuteNonQuery();
                        //}
                        //else
                        //{
                        //    sql.Clear();
                        //    sql.Append("UPDATE PASO.SAT178F2E \n");
                        //    sql.AppendFormat(" SET  PINCCO = '{0}' \n", califNueva);
                        //    sql.AppendFormat("WHERE PINSTY = '{0}' \n", idStilo); ;
                        //    sql.AppendFormat("  AND PINPRV = {0} \n", idProv);
                        //    sql.AppendFormat("  AND CASE \n");
                        //    sql.AppendFormat("	         WHEN PINBDG = 914  THEN 30  \n");
                        //    sql.AppendFormat("           WHEN PINBDG = 4 THEN 30 \n");
                        //    sql.AppendFormat("           WHEN PINBDG = 6 THEN 30 \n");
                        //    sql.AppendFormat("           WHEN PINBDG = 915 THEN 10 \n");
                        //    sql.AppendFormat("           WHEN PINBDG = 3   THEN 10 \n");
                        //    sql.AppendFormat("           WHEN PINBDG = 5   THEN 10  \n");
                        //    sql.AppendFormat("           WHEN PINBDG = 7   THEN 60  \n");
                        //    sql.AppendFormat("           WHEN PINBDG = 917 THEN 60 ELSE 0 END = {0} \n", marcaT);
                        //    sql.AppendFormat("  AND PINFRB = {0} \n", fecharevi);

                        //    command.CommandText = sql.ToString();
                        //    command.ExecuteNonQuery();
                        //}
                    }
                    */
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Obten cantidad de veces que a cambiado un Bonifica a DEvolucion "
        public static int cantidadNoBoniDev(string estilo, string proveedor, string ordencom, string marca, string tempo)
        {
            int resultado = 0;
            StringBuilder sql = new StringBuilder();
            string noEvento = "";
            OleDbConnection db2Conn = null;

            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append(" SELECT COALESCE(COUNT(SDBQUY), 0) \n"); // # maximo de EVENTOS QUE SE HAN ACTUALIZADO
                sql.Append("FROM MMNETLIB.SAT177CAL \n");
                sql.AppendFormat("WHERE SDBSTY = '{0}' \n", estilo);
                sql.AppendFormat("  AND SDBPRV = {0} \n", proveedor);
                if (ordencom != "")
                    sql.AppendFormat("AND SDBPOR = '{0}'\n", ordencom);

                sql.AppendFormat("AND SDBMAR = {0} \n", marca);
                sql.AppendFormat("AND SDBTEMP= '{0}' \n", tempo == "999" ? "TT" : tempo);
                // sql.Append("      AND SDBTIPO = 'B'\n");

                db2Comm.CommandText = sql.ToString();

                OleDbDataReader reader = db2Comm.ExecuteReader();

                while (reader.Read())
                {
                    noEvento = reader[0].ToString();
                }

                resultado = int.Parse(noEvento == "" ? "0" : noEvento);

                reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Obten cantidad de veces que a cambiado  DEvolucion  a Bonifica"
        public static int cantidadNoDevBoni(string estilo, string proveedor, string ordencom, string marca, string tempo)
        {
            int resultado = 0;
            StringBuilder sql = new StringBuilder();
            string noEvento = "";
            OleDbConnection db2Conn = null;

            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append(" SELECT COALESCE(COUNT(SDBQUY), 0) \n"); // # maximo de EVENTOS QUE SE HAN ACTUALIZADO
                sql.Append("FROM MMNETLIB.SAT177CAL \n");
                sql.AppendFormat("WHERE SDBSTY = '{0}' \n", estilo);
                sql.AppendFormat("  AND SDBPRV = {0} \n", proveedor);
                if (ordencom != "")
                    sql.AppendFormat("AND SDBPOR = '{0}'\n", ordencom);

                sql.AppendFormat("AND SDBMAR = {0} \n", marca);
                sql.AppendFormat("AND SDBTEMP= '{0}' \n", tempo == "999" ? "TT" : tempo);
                //sql.Append("      AND SDBTIPO = 'D'\n");

                db2Comm.CommandText = sql.ToString();

                OleDbDataReader reader = db2Comm.ExecuteReader();

                while (reader.Read())
                {
                    noEvento = reader[0].ToString();
                }

                resultado = int.Parse(noEvento == "" ? "0" : noEvento);

                reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Obten cantidad de veces que a cambiado un Solicitud de nota de creditó "
        public static int cantidadNoCredito(string estilo, string proveedor, string ordencom, string marca, string tempo)
        {
            int resultado = 0;
            StringBuilder sql = new StringBuilder();
            string noEvento = "";
            OleDbConnection db2Conn = null;

            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append(" SELECT COALESCE(COUNT(NTCNEV), 0) \n"); // # maximo de EVENTOS QUE SE HAN ACTUALIZADO
                sql.Append("FROM MMNETLIB.SAT177NTC \n");
                sql.AppendFormat("WHERE NTCSTY = '{0}' \n", estilo);
                sql.AppendFormat("  AND NTCPRV = {0} \n", proveedor);
                if (ordencom != "")
                    sql.AppendFormat("AND NTCORC = '{0}'\n", ordencom);

                sql.AppendFormat("AND NTCNMR = {0} \n", marca);
                sql.AppendFormat("AND NTCTEMP= '{0}' \n", tempo == "999" ? "TT" : tempo);

                db2Comm.CommandText = sql.ToString();

                OleDbDataReader reader = db2Comm.ExecuteReader();

                while (reader.Read())
                {
                    noEvento = reader[0].ToString();
                }

                resultado = int.Parse(noEvento == "" ? "0" : noEvento);

                reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Regresa la consulta con los estilos de la nota de credito en estatus de translado para asigna a folio en devolucion "
        public static DataTable notaCrestoEstatusTraslado()
        {
            OleDbConnection db2Conn = null;
            DataTable dtCamDevolucion = new DataTable();
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                sql.Clear();
                sql.Append("SELECT\n");
                sql.Append("		NTCBON,     \n");           // Fecha Bonifica en 400
                sql.Append("		FECHABON,   \n");           // Fecha Bonifica
                sql.Append("		NTCFRE,    \n");            // Fecha Revisión en 400
                sql.Append("		FECHAREV,   \n");           // Fecha Revisión
                sql.Append("		IDPROV,     \n");           // # Proveedor
                sql.Append("		PROVEEDOR,  \n");           // Proveedor
                sql.Append("		IDESTILO,   \n");           // # Estilo
                sql.Append("		ESTILO,  \n");              // Estilo
                sql.Append("		IDCOMPRADOR,  \n");         // # Comprador
                sql.Append("		COMPRADOR, \n");            // Comprador
                sql.Append("		ODCOMPRA,  \n");            // Orden de Compra
                sql.Append("		PIEZAS,  \n");              // Piezas 
                sql.Append("		VENTA,   \n");              // Venta
                sql.Append("		ONHAND,   \n");             // On Hand
                sql.Append("		PORVENTAS,	\n");           // % Ventas
                sql.Append("		CALIFICACION, \n");         // Calificación
                sql.Append("		NOTACREDITO,\n");	       // Nota Crédito
                sql.Append("		IDMARCA, \n");       	   // # Marca
                sql.Append("		MARCA,  \n");               // Marca
                sql.Append("		TEMPORADA \n");             // Temporada
                sql.Append("   FROM MMNETLIB.SAT177VNT  \n");     // Vista  de 
                sql.Append(" WHERE ESTATUS = 'T' \n");          // Estatus de Traslado 1ra Face
                sql.Append(" ORDER BY PROVEEDOR,ESTILO  ASC\n");

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;
                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);
                daDb2.Fill(dtCamDevolucion);

                return dtCamDevolucion;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Obtener el número de folio para Estilos Nota de Credito  "
        public static string ObtieneFolioNotaCredito()
        {
            StringBuilder sql = new StringBuilder();
            string dato = "";

            try
            {
                sql.Clear();
                sql.Append("  SELECT IFNULL(MAX(NTCFOL), 0) + 1  FROM MMNETLIB.SAT177NTC  ");  // # maximo del folio a insertar

                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();

                    OleDbDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        dato = reader[0].ToString();
                    }

                    reader.Close();
                }

                return dato;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Actualiza el estado y agrega el número de folio para Estilos Preautorizados en las notas de credito"
        public static int estatusTempNotasCredito(DataTable dtIngresaFolio)
        {
            try
            {
                int idApp = 0;
                StringBuilder sql = new StringBuilder();
                using (OleDbConnection DB = new OleDbConnection(Db2_Prod))
                {
                    DB.Open();
                    OleDbCommand command = new OleDbCommand();
                    command.Connection = DB;
                    command.CommandType = CommandType.Text;

                    foreach (DataRow insert in dtIngresaFolio.Rows)
                    {
                        string folio = string.Empty, idProv = string.Empty, idStilo = string.Empty, ordenCompra = string.Empty;
                        string marcaT = string.Empty, fechaRevi = string.Empty, fechaBon = string.Empty;
                        string tem = string.Empty, comprador = string.Empty;

                        folio = insert["FOLIO"].ToString();
                        idProv = insert["IDPROV"].ToString();
                        idStilo = insert["IDESTILO"].ToString();
                        ordenCompra = insert["ODCOMPRA"].ToString();
                        marcaT = insert["IDMARCA"].ToString();
                        fechaRevi = insert["NTCFRE"].ToString();
                        fechaBon = insert["NTCBON"].ToString();
                        tem = insert["TEMPORADA"].ToString();
                        comprador = insert["COMPRADOR"].ToString();

                        sql.Clear();
                        sql.Append("UPDATE MMNETLIB.SAT177NTC	\n");
                        sql.AppendFormat(" SET  NTCFOL = {0}, NTCEST = 'P' \n", folio);
                        sql.AppendFormat("WHERE NTCSTY = '{0}' \n", idStilo); ;
                        sql.AppendFormat("  AND NTCPRV = {0} \n", idProv);
                        sql.AppendFormat("  AND NTCORC = {0} \n", ordenCompra);
                        sql.AppendFormat("  AND NTCNMR = {0} \n", marcaT);
                        sql.AppendFormat("  AND NTCFRE = {0} \n", fechaRevi);
                        sql.AppendFormat("  AND NTCTEMP = '{0}' \n", tem);
                        sql.AppendFormat("  AND NTCBON = '{0}' \n", fechaBon);

                        command.CommandText = sql.ToString();
                        command.ExecuteNonQuery();
                        idApp = 1;
                    }
                }
                return idApp;
            }
            catch (Exception ex)
            {
                throw new Exception(" No se pudo completar el proceso del Folio. !Comuniquese con el administrador¡");
            }
        }
        #endregion

        #region " Carga los Folio que ya estan dados de alta "
        public static DataTable cargaListaFoliosNotaCre(string Folio = "P")
        {
            OleDbConnection db2Conn = null;
            DataTable dtFolios = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Clear();
                sql.Append(" SELECT DISTINCT NTCFOL AS FOLIO,\n");
                sql.Append("  CAST(CASE NTCEST WHEN 'P' THEN 'Pendiente'\n");
                sql.Append("                   WHEN 'A' THEN 'Autorizado' END AS VARCHAR(20)) AS ESTATUS,\n");
                sql.Append("                   CAST(NTCEST AS VARCHAR(10)) AS IDESTATUS\n");
                sql.Append(" FROM MMNETLIB.SAT177NTC \n");
                sql.AppendFormat("	WHERE NTCEST ='{0}'\n ", Folio);
                sql.Append("  ORDER BY NTCFOL ASC\n");


                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtFolios);

                return dtFolios;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Carga el detalle de los estilos que ya tienen folio Nota de Credito"
        public static DataTable CargaDetalleFolioNotaCredito(string Folio)
        {
            OleDbConnection db2Conn = null;
            DataTable dtFolios = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {

                sql.Clear();
                sql.Append(" SELECT\n");
                sql.Append("  	  FOLIO,\n");
                sql.Append("  	  NTCBON,\n");
                sql.Append("  	  FECHABON,\n");
                sql.Append("  	  NTCFRE,\n");
                sql.Append("  	  FECHAREV,\n");
                sql.Append("  	  IDPROV,\n");
                sql.Append("  	  PROVEEDOR,	\n");
                sql.Append("  	  IDESTILO,	\n");
                sql.Append("  	  ESTILO,	\n");
                sql.Append("  	  IDCOMPRADOR,	\n");
                sql.Append("  	  COMPRADOR,	\n");
                sql.Append("  	  ODCOMPRA,\n");
                sql.Append("  	  PIEZAS,	\n");
                sql.Append("  	  VENTA,	\n");
                sql.Append("  	  ONHAND,\n");
                sql.Append("  	  PORVENTAS,	\n");
                sql.Append("  	  CALIFICACION,\n");
                sql.Append("  	  NOTACREDITO,	\n");
                sql.Append("  	  SUBTOTAL,	\n");
                sql.Append("  	  IVA,	\n");
                sql.Append("  	  TOTAL,\n");
                sql.Append("  	  PORBONIFICA,	\n");
                sql.Append("  	  CSTACT,	\n");
                sql.Append("  	  PRCACT,\n");
                sql.Append("  	  MARACT,	\n");
                sql.Append("  	  CSTNVO,	\n");
                sql.Append("  	  PRCNVO,	\n");
                sql.Append("  	  MARNVO,	\n");
                sql.Append("  	  CSTFIN,	\n");
                sql.Append("  	  PRCFIN,	\n");
                sql.Append("  	  MARFIN,	\n");
                sql.Append("  	  DIFCOSTO,	\n");
                sql.Append("  	  PZAONHAND,	\n");
                sql.Append("  	  IMPONHAND,\n");
                sql.Append("  	  DIFCSTFIN,	\n");
                sql.Append("  	  IMPDISCST,	\n");
                sql.Append("  	  IMPMARFIN,	\n");
                sql.Append("  	  IDMARCA,	\n");
                sql.Append("  	  MARCA,\n");
                sql.Append("  	  TEMPORADA,	\n");
                sql.Append("  	  ESTATUS AS IDESTUS,\n");
                sql.Append("  	  CASE WHEN ESTATUS = 'P' THEN 'PENDIENTE' WHEN ESTATUS = 'A' THEN 'AUTORIZADO' END AS ESTATUS\n");
                sql.Append("  FROM MMNETLIB.SAT177VNT  \n");
                sql.AppendFormat("WHERE ESTATUS = 'P' AND FOLIO = '{0}' \n", Folio);
                sql.Append("  ORDER BY PROVEEDOR, ESTILO  ASC	\n");

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtFolios);

                return dtFolios;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Elimina los registros que no autorizaron Nota d eCredito"
        public static bool EliminaNoAutorizadosNotaCredito(string folio, string fechaBon, string fechaRev, string estilo, string proveedor, string ordencompra, string marca, string temp, string comprador)
        {
            StringBuilder sql = new StringBuilder();
            try
            {
                sql.Clear();
                sql.Append(" DELETE FROM MMNETLIB.SAT177NTC \n");
                sql.AppendFormat("   WHERE NTCFOL = '{0}' AND NTCPRV = '{1}' AND NTCSTY = '{2}' AND NTCORC = '{3}' AND NTCNMR = '{4}' AND NTCFRE = '{5}' AND NTCTEMP = '{6}' AND NTCBON = '{7}'",
                                            folio, proveedor, estilo, ordencompra, marca, fechaRev, temp, fechaBon);

                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();

                    command.ExecuteNonQuery();

                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Autoriza los Flios cambia el estatus "
        public static bool AutorizaFolioNotaCredito(string folio, string estatus, DataTable autorizado)
        {
            StringBuilder sql = new StringBuilder();
            try
            {
                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    connection.Open();
                    OleDbCommand command = new OleDbCommand();
                    command.Connection = connection;
                    command.CommandType = CommandType.Text;

                    sql.Clear();
                    sql.AppendFormat(" UPDATE MMNETLIB.SAT177NTC SET NTCEST = '{0}' WHERE NTCFOL = '{1}' ", estatus, folio);
                    command.CommandText = sql.ToString();
                    command.ExecuteNonQuery();
                    /*
                    foreach (DataRow insert in autorizado.Rows)
                    {
                        string idProv = string.Empty, idStilo = string.Empty, ordenCompra = string.Empty, marcaT = string.Empty, califNueva = string.Empty, fecharevi = string.Empty;
                        string temp = string.Empty;

                        decimal bonificaNue = 0;
                        idProv = insert["IDPROV"].ToString();
                        idStilo = insert["IDESTILO"].ToString();
                        ordenCompra = insert["ODCOMPRA"].ToString();
                        marcaT = insert["MARCA"].ToString();
                        califNueva = insert["PORCALNUE"].ToString();
                        bonificaNue = Convert.ToDecimal(insert["CSTBONNUE"].ToString());
                        fecharevi = insert["FECHAR"].ToString();
                        temp = insert["TEMP"].ToString();

                        if (temp.ToUpper().Trim() == "TT")
                        {
                            sql.Clear();
                            sql.Append("UPDATE MMSATOBJ.SAT179F1 \n");
                            sql.AppendFormat(" SET  DSPCLF = '{0}', DSPCSB = '{1}' \n", califNueva, bonificaNue);
                            sql.AppendFormat("WHERE DSPSTY = '{0}' \n", idStilo); ;
                            sql.AppendFormat("  AND DSPPRV = {0} \n", idProv);
                            sql.AppendFormat("  AND DSPORD = {0} \n", ordenCompra);
                            sql.AppendFormat("  AND DSPNMR = {0} \n", marcaT);
                            sql.AppendFormat("  AND DSPFRV = {0} \n", fecharevi);

                            command.CommandText = sql.ToString();
                            command.ExecuteNonQuery();

                            sql.Clear();
                            sql.Append("CALL MMSATPGM.SAT179C4 (\n");
                            sql.Append("'CALIFICA  '\n");
                            sql.Append(") \n");

                            command.CommandText = sql.ToString();
                            command.ExecuteNonQuery();

                            sql.Clear();
                            sql.Append("UPDATE MMSATOBJ.SAT179PF \n");
                            sql.AppendFormat(" SET  DSPCLF = '{0}', DSPCSB = '{1}' \n", califNueva, bonificaNue);
                            sql.AppendFormat("WHERE DSPSTY = '{0}' \n", idStilo); ;
                            sql.AppendFormat("  AND DSPPRV = {0} \n", idProv);
                            sql.AppendFormat("  AND DSPORD = {0} \n", ordenCompra);
                            sql.AppendFormat("  AND DSPNMR = {0} \n", marcaT);
                            sql.AppendFormat("  AND DSPFRV = {0} \n", fecharevi);

                            command.CommandText = sql.ToString();
                            command.ExecuteNonQuery();
                        }
                        else
                        {
                            sql.Clear();
                            sql.Append("UPDATE PASO.SAT178F2E \n");
                            sql.AppendFormat(" SET  PINCCO = '{0}' \n", califNueva);
                            sql.AppendFormat("WHERE PINSTY = '{0}' \n", idStilo); ;
                            sql.AppendFormat("  AND PINPRV = {0} \n", idProv);
                            sql.AppendFormat("  AND CASE \n");
                            sql.AppendFormat("	         WHEN PINBDG = 914  THEN 30  \n");
                            sql.AppendFormat("           WHEN PINBDG = 4 THEN 30 \n");
                            sql.AppendFormat("           WHEN PINBDG = 6 THEN 30 \n");
                            sql.AppendFormat("           WHEN PINBDG = 915 THEN 10 \n");
                            sql.AppendFormat("           WHEN PINBDG = 3   THEN 10 \n");
                            sql.AppendFormat("           WHEN PINBDG = 5   THEN 10  \n");
                            sql.AppendFormat("           WHEN PINBDG = 7   THEN 60  \n");
                            sql.AppendFormat("           WHEN PINBDG = 917 THEN 60 ELSE 0 END = {0} \n", marcaT);
                            sql.AppendFormat("  AND PINFRB = {0} \n", fecharevi);

                            command.CommandText = sql.ToString();
                            command.ExecuteNonQuery();
                        }
                    }
                    */
                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Proceso de bonificación parcial "

        /// <summary>
        /// Inserta o actualiza la información del estilo que requiere de una bonificación anticipada
        /// </summary>
        /// <param name="ent">Entidad Entidades.BonificacionParcial (Tabla) </param>
        /// <returns>True, en caso correcto o, False en lo contrario</returns>
        public static bool BonificacionParcial_iu(Entidades.BonificacionParcial ent)
        {
            StringBuilder sql = new StringBuilder();
            bool data = false;

            sql.AppendFormat("CALL MMNETLIB.BONPARC_IU({0},'{1}',{2},{3},'{4}',{5},{6},{7},'{8}','{9}',{10},{11},{12},{13},{14},{15},'{16}','{17}','{18}') ",
               ent.POVNUM, ent.SSTYLQ, ent.PONUMB, ent.NUMARC, ent.BYRNUM, ent.FECREC, ent.PIEREC, ent.FECREV, ent.CALIFI, ent.CALORI, ent.ONHAND, ent.ONORDR, ent.CSTTOT,
                ent.BODEGA, ent.CSTACT, ent.PREACT, ent.CODTEM, ent.AUSTAT, ent.SUSREG);

            try
            {
                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();
                    command.ExecuteNonQuery();

                    data = true;

                }
            }
            catch (Exception)
            {
                data = false;
            }
            return data;
        }

        public static bool BonificacionParcial_u(int OrdenCompra, int folio, string Usuario)
        {
            StringBuilder sql = new StringBuilder();
            bool data = false;

            sql.AppendFormat("CALL MMNETLIB.BONPARC_U({0},{1},'{2}') ", OrdenCompra, folio, Usuario);

            try
            {
                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();
                    command.ExecuteNonQuery();

                    data = true;

                }
            }
            catch (Exception)
            {
                data = false;
            }
            return data;
        }

        public static DataTable CargaListaFoliosBonAnt(string Folio = "", string Estatus = "P", string Comprador = "")
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Append(" SELECT DISTINCT Folio, Estatus, AOCSTS ");
                sql.Append(" FROM  MMNETLIB.VWBONPARFO  ");
                sql.AppendFormat(" WHERE AOCSTS = '{0}'  ", Estatus);


                if (Comprador != "999")
                {
                    sql.AppendFormat(" AND BYRNUM = '{0}'  ", Comprador);
                }


                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtMotivos);

                return dtMotivos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        /// <summary>
        /// Autoriza las OC del folio seleccionado
        /// </summary>
        /// <param name="folio"></param>
        /// <param name="Usuario"></param>
        /// <returns></returns>
        public static bool BonificacionParcial_uf(int folio, string Usuario)
        {
            StringBuilder sql = new StringBuilder();
            bool data = false;

            sql.AppendFormat("CALL MMNETLIB.BONPARC_UF({0},'{1}') ", folio, Usuario);

            try
            {
                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();
                    command.ExecuteNonQuery();

                    data = true;

                }
            }
            catch (Exception)
            {
                data = false;
            }
            return data;
        }




        ///// <summary>
        ///// Autoriza las OC del folio seleccionado
        ///// </summary>
        ///// <param name="folio"></param>
        ///// <param name="Usuario"></param>
        ///// <returns></returns>
        //public static bool BonificacionParcial_uf(int folio, string Usuario)
        //{
        //    StringBuilder sql = new StringBuilder();
        //    bool data = false;

        //    sql.AppendFormat("CALL MMNETLIB.BONPARC_UF({0},'{1}') ", folio, Usuario);

        //    try
        //    {
        //        using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
        //        {
        //            OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

        //            connection.Open();
        //            command.ExecuteNonQuery();

        //            data = true;

        //        }
        //    }
        //    catch (Exception)
        //    {
        //        data = false;
        //    }
        //    return data;
        //}

        public static bool BonificacionParcial_desautorizar(int OrdenCompra, string Usuario)
        {
            StringBuilder sql = new StringBuilder();
            bool data = false;

            sql.AppendFormat("CALL MMNETLIB.BONPARC_UD({0},'{1}') ", OrdenCompra, Usuario);

            try
            {
                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();
                    command.ExecuteNonQuery();

                    data = true;

                }
            }
            catch (Exception)
            {
                data = false;
            }
            return data;
        }

        public static DataTable CargaLSTBonPar(int OrdenCompra)
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Append("SELECT FOLIOS, AUSTAT ESTA, PONUMB ORDCOM, POVNUM PROV, SSTYLQ EST, ONHACT ONHAND, COSTO, BONORIGINAL, BONACTUAL ");
                sql.AppendLine(" FROM MMNETLIB.VWBONPARCI ");
                sql.AppendLine("  WHERE PONUMB = " + OrdenCompra.ToString());



                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtMotivos);

                return dtMotivos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static bool BonificacionParcial_actualizaNotCre(int OrdenCompra, string Usuario)
        {
            StringBuilder sql = new StringBuilder();
            bool data = false;

            sql.AppendFormat("CALL MMNETLIB.BONPAR_UFNC({0},'{1}') ", OrdenCompra, Usuario);

            try
            {
                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();
                    command.ExecuteNonQuery();

                    data = true;

                }
            }
            catch (Exception)
            {
                data = false;
            }
            return data;
        }

        public static DataTable CargaBonificacionParcial(string Busca = "", int Origen = 1, byte Vista = 1, string Comprador = "")
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();
            StringBuilder sql = new StringBuilder();
            string buscaProveedor = string.Empty;

            buscaProveedor = Busca;

            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                if (Vista == 1)
                {
                    sql.Append(" SELECT * FROM MMNETLIB.VWBONPARCI");

                    if (Comprador != "999")
                    {
                        if (Busca.Trim() == string.Empty)
                        {
                            sql.AppendFormat(" WHERE BYRNUM = '{1}' AND Origen = {0} AND FOLIOS = 0  "
                                , Origen
                                , Comprador);
                        }
                        else
                        {
                            sql.AppendFormat(" WHERE BYRNUM = '{2}' AND Origen = {1} AND FOLIOS = 0 AND (PONUMB = '{0}' OR POVNUM = '{3}') "
                                , Busca = (Busca.Length > 10) ? Busca.Substring(0, Busca.Length - 1) : Busca
                                , Origen
                                , Comprador
                                , buscaProveedor = (buscaProveedor.Length > 6) ? buscaProveedor.Substring(0, buscaProveedor.Length - 1) : buscaProveedor);
                        }
                    }
                    else
                    {
                        if (Busca.Trim() == string.Empty)
                        {
                            sql.AppendFormat(" WHERE Origen = {0} AND FOLIOS = 0  ", Origen);
                        }
                        else
                        {
                            sql.AppendFormat(" WHERE Origen = {1} AND FOLIOS = 0 AND (PONUMB = '{0}' OR POVNUM = '{2}') "
                               , (Busca.Length > 10) ? Busca.Substring(1, Busca.Length - 1) : Busca
                               , Origen
                               , (buscaProveedor.Length > 6) ? buscaProveedor.Substring(1, buscaProveedor.Length - 1) : buscaProveedor);
                        }
                    }
                }
                else if (Vista == 2)
                {
                    sql.Append(" SELECT * FROM MMNETLIB.VWBONPARCI");
                    sql.AppendFormat(" WHERE FOLIOS = {0} ", Busca);
                }

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;


                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtMotivos);

                return dtMotivos;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        #endregion

        /// <summary>
        /// Identifica si el Convenio trabaja en modalidad de FULL PATEO
        /// </summary>
        /// <param name="marca"></param>
        /// <returns>True, si esta marcadao como A</returns>
        /// 
        public static bool banderaFullPateo(int marca)
        {
            bool resultado = false;
            StringBuilder sql = new StringBuilder();
            OleDbConnection db2Conn = null;

            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.AppendFormat("SELECT FIREST  FROM  MMNETLIB.SAT177CFR WHERE FIRGRU = 'FP' AND FIRAMARCA = {0} \n", marca);
                db2Comm.CommandText = sql.ToString();

                OleDbDataReader reader = db2Comm.ExecuteReader();

                while (reader.Read())
                {
                    if (reader[0].ToString() == "A")
                    {
                        resultado = true;
                    }

                }

                reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
