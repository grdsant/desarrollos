﻿using System;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Text;

namespace MmsWin.Datos.Convenio
{
    /// <summary>
    /// Manejo de la información de las Ordenes de Compra
    /// </summary>
    /// <remarks>PROGRMADOR: OCG 13/12/2016</remarks>
    public class OrdenesCompra
    {
        #region Conexion

        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();

        #endregion

        /// <summary>
        /// Cargo los Motivos de Ampliación de calificación de AS/400 DB2
        /// </summary>
        /// <returns>DataTable de toda la tabla</returns>
        /// <remarks>PROGRMADOR: OCG 01/12/2016</remarks>
        public static DataTable CargaOrdenesCompra(string Busca = "", int Origen = 1, byte Vista = 1, string Comprador = "")
        {
            OleDbConnection db2Conn = null;
            DataTable dtMotivos = new DataTable();
            StringBuilder sql = new StringBuilder();
            string buscaProveedor = string.Empty;

            buscaProveedor = Busca;

            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                if (Vista == 1)
                {
                    sql.Append(" SELECT * FROM MMNETLIB.SAT177AOC");

                    if (Comprador != "999")
                    {
                        if (Busca.Trim() == string.Empty)
                        {
                            sql.AppendFormat(" WHERE POBUYR = '{1}' AND Origen = {0} AND FOLIOS = 0  "
                                , Origen
                                , Comprador);
                        }
                        else
                        {
                            sql.AppendFormat(" WHERE POBUYR = '{2}' AND Origen = {1} AND FOLIOS = 0 AND (PONUMB = '{0}' OR POVNUM = '{3}') "
                                , Busca = (Busca.Length > 10) ? Busca.Substring(0, Busca.Length -1) : Busca
                                , Origen
                                , Comprador
                                , buscaProveedor = (buscaProveedor.Length > 6) ? buscaProveedor.Substring(0, buscaProveedor.Length - 1) : buscaProveedor);
                        }
                    }
                    else
                    {
                        if (Busca.Trim() == string.Empty)
                        {
                            sql.AppendFormat(" WHERE Origen = {0} AND FOLIOS = 0  ", Origen);
                        }
                        else
                        {
                            sql.AppendFormat(" WHERE Origen = {1} AND FOLIOS = 0 AND (PONUMB = '{0}' OR POVNUM = '{2}') "
                               , (Busca.Length > 10) ? Busca.Substring(1, Busca.Length -1) : Busca
                               , Origen
                               , (buscaProveedor.Length > 6) ? buscaProveedor.Substring(1, buscaProveedor.Length -1) : buscaProveedor);
                        }
                    }
                }
                else if (Vista == 2)
                {
                    sql.Append(" SELECT * FROM MMNETLIB.SAT176AOC");
                    sql.AppendFormat(" WHERE FOLIOS = {0} ", Busca);
                }

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;


                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtMotivos);

                return dtMotivos;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}

