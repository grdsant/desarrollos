﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Convenio
{
    public class TblHdrRentabilidad
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static DataTable ObtenTblHdrRentabilidad()
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtTblHdrRentabilidad = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177SHTB\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtTblHdrRentabilidad = new DataTable("TblHdrRentabilidad");
                dtTblHdrRentabilidad.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtTblHdrRentabilidad;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable WriteTblHdrRentabilidad(string marca, string tabla, string descripcion, string fechaInicial, string fechaFinal, string usuario, string fechaReg, string horaReg, string estatus)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtPerfil = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R43 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", tabla.PadLeft(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", descripcion.PadRight(50, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", fechaInicial.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", fechaFinal.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", usuario.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", fechaReg.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", horaReg.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", estatus.PadRight(1, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177SHTB\n");
                sql.AppendFormat(" WHERE ");
                sql.AppendFormat(" HTBMAR = " + "'" + "{0}" + "'" + "\n", marca);
                sql.AppendFormat(" AND ");
                sql.AppendFormat(" HTBTBR = " + "'" + "{0}" + "'" + "\n", tabla);

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtPerfil = new DataTable("RentabilidadHeader");
                dtPerfil.Load(db2Reader);
                db2Reader.Close();
            }

            catch (OleDbException ex)
            {
                if (ex.ErrorCode != -2147467259)

                    throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            return dtPerfil;
        }

        public static DataTable UpdateTblHdrRentabilidad(DataTable dtConfiguracion)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                foreach (DataRow row in dtConfiguracion.Rows)
                {
                    string marca = row["Marca"].ToString();
                    string tabla = row["Tabla"].ToString();
                    string descripcion = row["Descripcion"].ToString();
                    string fechaInicial = row["FechaInicial"].ToString();
                    string fechaFinal = row["FechaFinal"].ToString();
                    string usuario = row["Usuario"].ToString();
                    string fechaReg = row["FechaRegistro"].ToString();
                    string horaReg = row["HoraRegistro"].ToString();
                    string estatus = row["Estatus"].ToString();
                    string marcaB = row["MarcaB"].ToString();
                    string tablaB = row["TablaB"].ToString();

                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT177SHTB SET \n");
                    sql.AppendFormat("HTBMAR = " + "'" + "{0}" + "'" + "," + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat("HTBTBR = " + "'" + "{0}" + "'" + "," + "\n", tabla.PadLeft(3, '0'));
                    sql.AppendFormat("HTBDES = " + "'" + "{0}" + "'" + "," + "\n", descripcion.PadRight(50, ' '));
                    sql.AppendFormat("HTBFHI = " + "'" + "{0}" + "'" + "," + "\n", fechaInicial.PadLeft(6, '0'));
                    sql.AppendFormat("HTBFHF = " + "'" + "{0}" + "'" + "," + "\n", fechaFinal.PadLeft(6, '0'));
                    sql.AppendFormat("HTBUSR = " + "'" + "{0}" + "'" + "," + "\n", usuario.PadRight(10, ' '));
                    sql.AppendFormat("HTBFRG = " + "'" + "{0}" + "'" + "," + "\n", fechaReg.PadLeft(6, '0'));
                    sql.AppendFormat("HTBHRG = " + "'" + "{0}" + "'" + "," + "\n", horaReg.PadLeft(6, '0'));
                    sql.AppendFormat("HTBSTS = " + "'" + "{0}" + "'" + "," + "\n", estatus.PadRight(1, ' '));
                    sql.AppendFormat("HTBMARB = " + "'" + "{0}" + "'" + "," + "\n", marcaB.PadLeft(3, '0'));
                    sql.AppendFormat("HTBTBRB = " + "'" + "{0}" + "'" + "\n", tablaB.PadLeft(3, '0'));
                    sql.Append("WHERE \n");
                    sql.AppendFormat("HTBMARB = " + "'" + "{0}" + "'" + "\n", marcaB.PadLeft(3, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("HTBTBRB = " + "'" + "{0}" + "'" + "\n", tablaB.PadLeft(3, '0'));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();
                }
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtConfiguracion;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void EliminaTblHdrRentabilidad(string marcaB, string tablaB)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("DELETE FROM " + LibSatObj + ".SAT177SHTB WHERE\n");
                sql.Append(" HTBMAR = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", marcaB);
                sql.Append(" AND HTBTBR = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", tablaB);

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch
            { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
