﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Convenio
{
   public class Kardex
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

       public static DataTable ObtenKardex(string proveedor, string estilo, string usuario)
       {
           string cadenaConexionDb2 = Db2_Prod;

           OleDbConnection db2Conn = null;

           StringBuilder sql = new StringBuilder();
           DataTable dtConfiguracion = null;

           try
           {
               db2Conn = new OleDbConnection(cadenaConexionDb2);
               db2Conn.Open();
               OleDbCommand db2Comm = db2Conn.CreateCommand();

               sql.Clear();
               sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

               db2Comm.CommandText = sql.ToString();
               db2Comm.ExecuteNonQuery();

               sql.Clear();
               sql.Append("CALL " + LibSatPgm + ".SAT177RKR (\n");
               sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", proveedor.PadLeft(6, '0'));
               sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", estilo.PadRight(15, ' '));
               sql.AppendFormat("'" + "{0}" + "'" + "\n", usuario.PadRight(10, ' '));
               sql.Append(")");

               db2Comm.CommandText = sql.ToString();
               db2Comm.ExecuteNonQuery();

               sql.Clear();
               sql.Append("SELECT * FROM " + LibSatObj + ".SAT177KR ORDER BY RSOANO, RSOSEM\n");

               db2Comm.CommandText = sql.ToString();
               OleDbDataReader db2Reader = db2Comm.ExecuteReader();

               dtConfiguracion = new DataTable("Kardex");
               dtConfiguracion.Load(db2Reader);
               db2Reader.Close(); 

               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();

               return dtConfiguracion;
           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();
           }
       }

       public static DataTable ObtenKardexPorSemana(string proveedor, string estilo, string anio, string semana, string usuario)
       {
           string cadenaConexionDb2 = Db2_Prod;

           OleDbConnection db2Conn = null;

           StringBuilder sql = new StringBuilder();
           DataTable dtKardexPorSemana = null;

           try
           {
               db2Conn = new OleDbConnection(cadenaConexionDb2);
               db2Conn.Open();
               OleDbCommand db2Comm = db2Conn.CreateCommand();

               sql.Clear();
               sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

               db2Comm.CommandText = sql.ToString();
               db2Comm.ExecuteNonQuery();

               sql.Clear();
               sql.Append("SELECT HPEANO, HPESEM, HPETYP, HPEQTY  FROM " + LibSatObj + ".SAT252F6L \n");
               sql.AppendFormat(" WHERE HPEPRV = " + "'" + "{0}" + "'" + "\n", proveedor.PadLeft(6, '0'));
               sql.AppendFormat(" and HPESTY   = " + "'" + "{0}" + "'" + "\n", estilo.PadRight(15, ' '));
               sql.AppendFormat(" and HPEANO   = " + "'" + "{0}" + "'" + "\n", anio.PadLeft(2, '0'));
               sql.AppendFormat(" and HPESEM   = " + "'" + "{0}" + "'" + "\n", semana.PadLeft(2, '0')); 
               sql.AppendFormat(" ORDER BY HPEANO, HPESEM \n");

               db2Comm.CommandText = sql.ToString();
               OleDbDataReader db2Reader = db2Comm.ExecuteReader();

               dtKardexPorSemana = new DataTable("Kardex por Semana");
               dtKardexPorSemana.Load(db2Reader);
               db2Reader.Close();

               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();

               return dtKardexPorSemana;
           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();
           }
       }

       public static DataTable ObtenKardexPorDia(string proveedor, string estilo, string anio, string semana, string tipo, string usuario)
       {
           string cadenaConexionDb2 = Db2_Prod;

           OleDbConnection db2Conn = null;

           StringBuilder sql = new StringBuilder();
           DataTable dtKardexPorDia = null;

           try
           {
               db2Conn = new OleDbConnection(cadenaConexionDb2);
               db2Conn.Open();
               OleDbCommand db2Comm = db2Conn.CreateCommand();

               sql.Clear();
               sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

               db2Comm.CommandText = sql.ToString();
               db2Comm.ExecuteNonQuery();

               sql.Clear();

               sql.Append("SELECT HPEANO, HPESEM, HPEDAY, HPETYP, HPEQTY  FROM " + LibSatObj + ".SAT252F501 \n");
               sql.AppendFormat(" WHERE HPEPRV =   " + "'" + "{0}" + "'" + "\n", proveedor.PadLeft(6, '0'));
               sql.AppendFormat("   and HPESTY   = " + "'" + "{0}" + "'" + "\n", estilo.PadRight(15, ' '));
               sql.AppendFormat("   and HPEANO   = " + "'" + "{0}" + "'" + "\n", anio.PadLeft(2, '0'));
               sql.AppendFormat("   and HPESEM   = " + "'" + "{0}" + "'" + "\n", semana.PadLeft(2, '0'));

               sql.AppendFormat(" ORDER BY HPEANO, HPESEM \n");

               db2Comm.CommandText = sql.ToString();
               OleDbDataReader db2Reader = db2Comm.ExecuteReader();

               dtKardexPorDia = new DataTable("Kardex por Dia");
               dtKardexPorDia.Load(db2Reader);
               db2Reader.Close();

               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();

               return dtKardexPorDia;
           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();
           }
       }

       public static DataTable ObtenKardexPorSku(string proveedor, string estilo, string anio, string semana, string tipo, string fechaTipo, string usuario)
       {
           string cadenaConexionDb2 = Db2_Prod;

           OleDbConnection db2Conn = null;

           StringBuilder sql = new StringBuilder();
           DataTable dtKardexPorSku = null;

           try
           {
               db2Conn = new OleDbConnection(cadenaConexionDb2);
               db2Conn.Open();
               OleDbCommand db2Comm = db2Conn.CreateCommand();

               sql.Clear();
               sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

               db2Comm.CommandText = sql.ToString();
               db2Comm.ExecuteNonQuery();

               sql.Clear();
               sql.Append("SELECT b.ITRLOC, c.STRNAM, b.INUMBR, b.ITRQTY, b.ITRREF, b.PGMNAM, b.LGUSER, \n");
               sql.Append("b.ITPDTE, b.ITRSDT, b.ITRSTM FROM " + Lib610Lib + ".INVMSTLB a INNER JOIN   \n");
               sql.Append(" " + Lib610Lib + ".INVAUDLS8 b ON a.INUMBR=b.INUMBR \n");
               sql.Append(" INNER JOIN " + Lib610Lib + ".TBLSTR c on b.ITRLOC = c.STRNUM \n");

               sql.AppendFormat(" WHERE a.ASNUM    =   " + "'" + "{0}" + "'" + "\n", proveedor.PadLeft(6, '0'));
               sql.AppendFormat("   and a.ISTYLN   = " + "'" + "{0}" + "'" + "\n", estilo.PadRight(15, ' '));
               sql.AppendFormat("   and b.ITRDAT   = " + "'" + "{0}" + "'" + "\n", fechaTipo.PadLeft(6, '0'));
               sql.AppendFormat("   and b.ITRTYP   = " + "'" + "{0}" + "'" + "\n", tipo.PadLeft(3, '0'));

               sql.AppendFormat(" ORDER BY b.ITRDAT, b.ITRTYP \n");

               db2Comm.CommandText = sql.ToString();
               OleDbDataReader db2Reader = db2Comm.ExecuteReader();

               dtKardexPorSku = new DataTable("Kardex");
               dtKardexPorSku.Load(db2Reader);
               db2Reader.Close();

               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();

               return dtKardexPorSku;
           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();
           }
       }

       public static void ActualizaKardex(string proveedor, string estilo, string resp)
       {
           string cadenaConexionDb2 = Db2_Prod;

           OleDbConnection db2Conn = null;

           StringBuilder sql = new StringBuilder();

           try
           {
               db2Conn = new OleDbConnection(cadenaConexionDb2);
               db2Conn.Open();
               OleDbCommand db2Comm = db2Conn.CreateCommand();
               sql.Clear();
               sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

               db2Comm.CommandText = sql.ToString();
               db2Comm.ExecuteNonQuery();

               sql.Clear();
               sql.Append("CALL " + LibSatPgm + ".SAT252C05 (\n");
               sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", proveedor.PadLeft(6, '0'));
               sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", estilo.PadRight(15, ' '));
               sql.AppendFormat("'" + "{0}" + "'" + "\n", resp.PadRight(2, ' '));
               sql.Append(")");

               db2Comm.CommandText = sql.ToString();
               db2Comm.ExecuteNonQuery();

               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();
           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();
           }
       }

    }
}
