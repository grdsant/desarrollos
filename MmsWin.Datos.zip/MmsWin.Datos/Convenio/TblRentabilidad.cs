﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Convenio
{
    public class TblRentabilidad
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static DataTable ObtenTblRentabilidad(string tblTabla, string tblMarca)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtTblRentabilidad = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177STAB\n");

                if (tblTabla != "" | tblMarca != "") { sql.AppendFormat(" WHERE "); }

                if (tblTabla != "")
                { sql.AppendFormat(" TABNTB = " + "'" + "{0}" + "'" + "\n", tblTabla); }
                if (tblTabla != "" && tblMarca != "") { sql.AppendFormat(" AND "); }
                if (tblMarca != "")
                { sql.AppendFormat(" TABMAR = " + "'" + "{0}" + "'" + "\n", tblMarca); }

                sql.Append(" ORDER BY TABNTB, TABMAR, TABSEC\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtTblRentabilidad = new DataTable("TblRentabilidad");
                dtTblRentabilidad.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtTblRentabilidad;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable UpdateTblRentabilidad(DataTable dtTblRentabilidad)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                foreach (DataRow row in dtTblRentabilidad.Rows)
                {
                    string tabla = row["Tabla"].ToString();
                    string marca = row["Marca"].ToString();
                    string secuencia = row["Secuencia"].ToString();
                    string del = row["Del"].ToString();
                    string al = row["Al"].ToString();
                    string por = row["Por"].ToString();
                    string delr = row["Delr"].ToString();
                    string alr = row["Alr"].ToString();
                    string porr = row["Porr"].ToString();
                    string usuario = row["Usuario"].ToString();
                    string fecha = row["Fecha"].ToString();
                    string hora = row["Hora"].ToString();
                    string estatus = row["Estatus"].ToString();

                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT177STAB SET \n");
                    sql.AppendFormat("TABNTB = " + "'" + "{0}" + "'" + "," + "\n", tabla.PadLeft(3, '0'));
                    sql.AppendFormat("TABMAR = " + "'" + "{0}" + "'" + "," + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat("TABSEC = " + "'" + "{0}" + "'" + "," + "\n", secuencia.PadLeft(3, '0'));
                    sql.AppendFormat("TABDEL = " + "'" + "{0}" + "'" + "," + "\n", del.PadRight(15, ' '));
                    sql.AppendFormat("TABAL = " + "'" + "{0}" + "'" + "," + "\n", al.PadRight(15, ' '));
                    sql.AppendFormat("TABPOR = " + "'" + "{0}" + "'" + "," + "\n", por.PadRight(15, ' '));
                    sql.AppendFormat("TABDELR = " + "'" + "{0}" + "'" + "," + "\n", delr.PadLeft(13, '0'));
                    sql.AppendFormat("TABALR = " + "'" + "{0}" + "'" + "," + "\n", alr.PadLeft(13, '0'));
                    sql.AppendFormat("TABPORR = " + "'" + "{0}" + "'" + "," + "\n", porr.PadLeft(13, '0'));
                    sql.AppendFormat("TABUSR = " + "'" + "{0}" + "'" + "," + "\n", usuario.PadRight(10, ' '));
                    sql.AppendFormat("TABFCH = " + "'" + "{0}" + "'" + "," + "\n", fecha.PadLeft(6, '0'));
                    sql.AppendFormat("TABHOR = " + "'" + "{0}" + "'" + "," + "\n", hora.PadLeft(6, '0'));
                    sql.AppendFormat("TABSTS = " + "'" + "{0}" + "'" + "\n", estatus.PadRight(1, ' '));
                    sql.Append("WHERE \n");
                    sql.AppendFormat("TABNTB = " + "'" + "{0}" + "'" + "\n", tabla.PadLeft(3, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("TABMAR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("TABSEC = " + "'" + "{0}" + "'" + "\n", secuencia.PadLeft(3, '0'));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();
                }
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtTblRentabilidad;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void EliminaTblRentabilidad(string tablaB, string marcaB, string SecuenciaB)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("DELETE FROM " + LibSatObj + ".SAT177STAB WHERE\n");
                sql.Append(" TABNTB = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", tablaB);
                sql.Append(" AND TABMAR = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", marcaB);
                sql.Append(" AND TABSEC = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", SecuenciaB);

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch
            {   }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
