﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Convenio
{
    public class Reprog
    {
        /// <summary>
        /// Última calificación obtenida por el estilo
        /// </summary>
        public int CalificacionRentabilidad { get; set; }

        #region [ Conexion  ]
                // Equipo
                public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
                // Ambiente
                public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
                public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
                public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();

        #endregion

        public static DataTable ObtenReprog(string ParProv, string ParSty, string ParOrden, string ParMarca, string ParComprador, string ParCompDesc)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtReprog = null;
           
            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT COUNT(*) FROM " + LibSatObj + ".SAT179LF4\n");

                sql.AppendFormat(" WHERE DSPPRV = " + "'" + "{0}" + "'" + "\n", ParProv.PadLeft(6, '0'));
                sql.AppendFormat(" AND   DSPSTY = " + "'" + "{0}" + "'" + "\n", ParSty);
                sql.AppendFormat(" AND   DSPORD = " + "'" + "{0}" + "'" + "\n", ParOrden.PadLeft(10, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtReprog = new DataTable("Reprogramacion");
                dtReprog.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtReprog;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenReprogF14(string ParProv, string ParSty, string ParFchRev)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtReprog = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT COUNT(*) FROM " + LibSatObj + ".SAT177F14\n");

                sql.AppendFormat(" WHERE REPPRV = " + "'" + "{0}" + "'" + "\n", ParProv.PadLeft(6, '0'));
                sql.AppendFormat(" AND   REPSTY = " + "'" + "{0}" + "'" + "\n", ParSty);
                sql.AppendFormat(" AND   REPFRV = " + "'" + "{0}" + "'" + "\n", ParFchRev.PadLeft(6, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtReprog = new DataTable("Reprogramacion");
                dtReprog.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtReprog;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void WriteReprog(string PrvRpr, string NomRpr, string StyRpr, string DesRpr, string FchRevRpr, string FchRprRpr, string CompDesc, string ObsRpr, string MarcaRpr, string CompradorRpr, string FechaRpr, string HoraRpr, string UsrRpr, string orden, string MotivoID = "", string Estatus = "")
           {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R41 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", PrvRpr.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", NomRpr.PadRight(35, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", StyRpr.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", DesRpr.PadRight(30, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", FchRevRpr.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", FchRprRpr.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", CompDesc.PadRight(30, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ObsRpr.PadRight(100, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", MarcaRpr.PadLeft(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", CompradorRpr.PadRight(3, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", FechaRpr.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", HoraRpr.PadLeft(6, '0'));

                if (MotivoID != "")
                {
                    //Modificada para continuar cadena y permitir agregar el ID del motivo
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", UsrRpr.PadRight(10, ' '));
                    
                    // orden de Compra
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", orden.PadLeft(10, '0'));

                    //ID del Motivo
                    sql.AppendFormat("'" + "{0}" + "'," + "\n", MotivoID.PadLeft(10, '0'));

                    //Estatus por defecto de la reprogramación
                    sql.AppendFormat("'{0}',\n",Estatus);

                    //Folio por defecto
                    sql.AppendFormat("'      0'\n");
                }
                else
                {
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", UsrRpr.PadLeft(10, ' '));
                }

                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();
            }
            catch (OleDbException ex)
            {
                if (ex.ErrorCode != -2147467259)

                    throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static bool LogReprogramacion(int NoProveedor, string NoStilo, int FechaRev, int OrdenCompra, string Usuario)
        {
            StringBuilder sql = new StringBuilder();
            bool data = false;

            sql.AppendFormat("CALL MMNETLIB.SPAUD_I({0},'{1}',{2},{3},'{4}') ", NoProveedor, NoStilo, FechaRev, OrdenCompra, Usuario);

            try
            {
                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();
                    command.ExecuteNonQuery();

                    data = true;

                }
            }
            catch (Exception)
            {
                data = false;
            }
            return data;
        }

    }
}
