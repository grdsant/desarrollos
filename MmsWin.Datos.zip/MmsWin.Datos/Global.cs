﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;

namespace MmsWin.Datos
{
    /// <summary>
    /// Clase general para el acceso a datos
    /// </summary>
    public class Global
    {
        /// <summary>
        /// Recuperar la cadena de conexión hacia el AS400
        /// </summary>
        public static string strConexion = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();


        /// <summary>
        /// Recupera los datos a partir de la consulta proporcionada
        /// </summary>
        /// <param name="Query">Consulta SQL</param>
        /// <returns>DataTable con los datos recuperados</returns>
        /// <remarks>Desarrollador: Omar Cervantes G. | 14/02/2017</remarks>
        public static DataTable CargaDataTable(string Query, bool AgregarTodos = true)
        {
            OleDbConnection db2Conn = null;
            DataTable dt = new DataTable();
            StringBuilder sql = new StringBuilder();
            DataRow row = dt.NewRow();

            try
            {
                db2Conn = new OleDbConnection(strConexion);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(Query, db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dt);

                if (AgregarTodos)
                {
                    row[0] = "999";
                    row[1] = "TODOS";
                    dt.Rows.Add(row);
                }

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public static bool SAT177SORD_insert(Entidades.SAT177SORD iClass)
        {
            StringBuilder sql = new StringBuilder();
            bool data = false;

            sql.AppendFormat("CALL MMNETLIB.SAT177SORD_i('{0}',{1},'{2}') ", iClass.ORDID, iClass.ORDPRV, iClass.ORDDES);

            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConexion))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();
                    command.ExecuteNonQuery();

                    data = true;

                }
            }
            catch (Exception)
            {
                data = false;
            }
            return data;
        }


        public static bool SAT177SORD_delete(Entidades.SAT177SORD iClass)
        {
            StringBuilder sql = new StringBuilder();
            bool data = false;

            sql.AppendFormat("CALL MMNETLIB.SAT177SORD_d('{0}') ", iClass.ORDPRV);

            try
            {
                using (OleDbConnection connection = new OleDbConnection(strConexion))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();
                    command.ExecuteNonQuery();

                    data = true;

                }
            }
            catch (Exception)
            {
                data = false;
            }
            return data;
        }
    }
}
