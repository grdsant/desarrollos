﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Login
{
    public class Login
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        public static string Servidor = ConfigurationManager.ConnectionStrings["IPservidor"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static DataTable ObtenLogin(string ParUsuario, string ParPassword)
        {
            Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
            Servidor = ConfigurationManager.ConnectionStrings["IPservidor"].ToString();
            string cadenaConexionDb2 = "Provider=IBMDA400;Data Source=" + Servidor + ";User Id=" + ParUsuario + " ;Password=" + ParPassword;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtLogin = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R3 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParUsuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177F3\n");
                sql.Append(" ORDER BY USRUSR ASC\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtLogin = new DataTable("Login");
                dtLogin.Load(db2Reader);
                db2Reader.Close();
            }

            catch (OleDbException ex)
            {
   //             if (ex.ErrorCode != -2147467259)          
                throw ex;
            }

            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return dtLogin;
        }

        public static DataTable ValidaVersion()
        {
            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConvenio = null;

            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();

                sql.Append(" SELECT ID, FECHAVERS, NOVERSION FROM MMNETLIB.AUDREVVER WHERE ID = 1 ");
                
                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtConvenio = new DataTable("AuditoriaVersion");
                dtConvenio.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtConvenio;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

    }
}
