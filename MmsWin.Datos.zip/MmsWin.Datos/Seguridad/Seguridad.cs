﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Seguridad
{
    public class Seguridad
    {

        #region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
        #endregion

        public static DataTable ObtenSeguridad(string Aplicacion, string Modulo, string Usuario, bool NuevaSeguridad  = false)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtSeguridad = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                if (NuevaSeguridad == true)
                {
                    sql.Append(" SELECT DISTINCT D.PDTAPL, D.PDTMOD, D.PDTPER,  c.CLSTIP AS SEGTIP, c.CLSCTL AS SEGCLS, D.PDTHAC AS SEGHAC, D.PDTVIC AS SEGVIC, U.USRUSR");
                    sql.AppendLine(" FROM MMSATOBJ.SAT177SPDT D -- Detalle del perfil ");
                    sql.AppendLine(" INNER JOIN MMSATOBJ.SAT177SCLS C   "); // Controles
                    sql.AppendLine("  ON c.CLSMOD = d.PDTMOD  ");
                    sql.AppendLine("  AND c.CLSAPL = d.PDTAPL  ");
                    sql.AppendLine("  AND C.CLSCTL = D.PDTCLS  ");
                    sql.AppendLine(" INNER JOIN MMSATOBJ.SAT177SUSR U  "); // Usuarios
                    sql.AppendLine("  ON U.USRPER = D.PDTPER  ");
                    sql.AppendFormat("   AND U.USRUSR = '{0}'  ", Usuario);
                    sql.AppendFormat("   WHERE PDTAPL = '{0}'  ", Aplicacion);
                    //sql.AppendLine("   AND PDTPER = 'PERFIL 10'  ");
                    sql.AppendFormat("   AND PDTMOD = '{0}' ", Modulo);
                    sql.AppendLine("   AND C.CLSTIP NOT IN ('Columna') ");
                    sql.AppendLine("  ORDER BY  c.CLSCTL ");
                }
                else
                {
                    sql.Clear();
                    sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    sql.Clear();
                    sql.Append("CALL " + LibSatPgm + ".SAT177RSEG (\n");
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", Aplicacion.PadRight(35, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", Modulo.PadRight(35, ' '));
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", Usuario.PadRight(10, ' '));
                    sql.Append(")");

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    sql.Clear();
                    sql.Append("SELECT * FROM " + LibSatObj + ".SAT177SSEG\n");
                    sql.Append(" ORDER BY SEGCLS ASC\n");
                }

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtSeguridad = new DataTable("Seguridad");
                dtSeguridad.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtSeguridad;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
