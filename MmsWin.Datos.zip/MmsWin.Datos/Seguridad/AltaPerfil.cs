﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Seguridad
{
    public class AltaPerfil
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static DataTable WritePerfil(string Perfil, string Descripcion, string Fecha, string Hora, string Estatus)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtPerfil = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R33 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", Perfil.PadRight(35, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", Descripcion.PadRight(50, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", Fecha.PadRight(6, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", Hora.PadRight(6, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", Estatus.PadRight(1, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177SPER\n");
                sql.AppendFormat(" WHERE ");
                sql.AppendFormat(" PERPER = " + "'" + "{0}" + "'" + "\n", Perfil);

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtPerfil = new DataTable("Perfil");
                dtPerfil.Load(db2Reader);
                db2Reader.Close();
            }

            catch (OleDbException ex)
            {
                if (ex.ErrorCode != -2147467259)

                    throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            return dtPerfil;
        }
    }
}
