﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Seguridad
{
   public class PerfilDetalle
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

       public static DataTable ObtenPerfilDetalle(string perfil, string aplicacion, string modulo, string control)
       {
           string cadenaConexionDb2 = Db2_Prod;

           OleDbConnection db2Conn = null;

           StringBuilder sql = new StringBuilder();
           DataTable dtPerfilDetalle = null;

           try
           {
               db2Conn = new OleDbConnection(cadenaConexionDb2);
               db2Conn.Open();
               OleDbCommand db2Comm = db2Conn.CreateCommand();

               sql.Append("SELECT * FROM " + LibSatObj + ".SAT177SPDT\n");


               if (perfil != "" | aplicacion != "" | modulo != "" | control != "") { sql.AppendFormat(" WHERE "); }

               if (perfil != "")
               {
                   sql.AppendFormat(" PDTPER LIKE " + "'%" + "{0}" + "%'" + "\n", perfil);
               }

               if (perfil != "" && aplicacion != "") { sql.AppendFormat(" AND "); }

               if (aplicacion != "")
               {
                   sql.AppendFormat(" PDTAPL LIKE " + "'%" + "{0}" + "%'" + "\n", aplicacion);
               }

               if ((perfil != "" | aplicacion != "") && modulo != "") { sql.AppendFormat(" AND "); }

               if (modulo != "")
               {
                   sql.AppendFormat(" PDTMOD LIKE " + "'%" + "{0}" + "%'" + "\n", modulo);
               }

               if ((perfil != "" | aplicacion != "" | modulo != "") && control != "") { sql.AppendFormat(" AND "); }

               if (control != "")
               {
                   sql.AppendFormat(" PDTCLS LIKE " + "'%" + "{0}" + "%'" + "\n", control);
               }

               sql.Append(" ORDER BY PDTPER, PDTAPL, PDTMOD, PDTCLS  ASC\n");

               db2Comm.CommandText = sql.ToString();
               OleDbDataReader db2Reader = db2Comm.ExecuteReader();

               dtPerfilDetalle = new DataTable("Perfiles");
               dtPerfilDetalle.Load(db2Reader);
               db2Reader.Close();

               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();

               return dtPerfilDetalle;
           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();
           }
       }

       public static void WritePerfilDetalle(string perfil, string aplicacion, string modulo,string control, string fecha, string hora, string estatus)
       {
           string cadenaConexionDb2 = Db2_Prod;

           OleDbConnection db2Conn = null;

           StringBuilder sql = new StringBuilder();

           try
           {
               db2Conn = new OleDbConnection(cadenaConexionDb2);
               db2Conn.Open();
               OleDbCommand db2Comm = db2Conn.CreateCommand();

               sql.Clear();
               sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

               db2Comm.CommandText = sql.ToString();
               db2Comm.ExecuteNonQuery();

               sql.Clear();
               sql.Append("CALL " + LibSatPgm + ".SAT177R34 (\n");
               sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", perfil.PadRight(35, ' '));
               sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", aplicacion.PadRight(35, ' '));
               sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", modulo.PadRight(35, ' '));
               sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", control.PadRight(50, ' '));
               sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", fecha.PadRight(6, '0'));
               sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", hora.PadRight(6, '0'));
               sql.AppendFormat("'" + "{0}" + "'" + "\n", estatus.PadRight(1, ' '));
               sql.Append(")");

               db2Comm.CommandText = sql.ToString();
               db2Comm.ExecuteNonQuery();
           }

           catch (OleDbException ex)
           {
               if (ex.ErrorCode != -2147467259)

                   throw ex;
           }
           finally
           {
               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();
           }
       }

       public static void UpdatePerfilesDetalle(DataTable dtPerfilDetalle)
       {
           string cadenaConexionDb2 = Db2_Prod;

           OleDbConnection db2Conn = null;

           StringBuilder sql = new StringBuilder();

           try
           {
               db2Conn = new OleDbConnection(cadenaConexionDb2);
               db2Conn.Open();
               OleDbCommand db2Comm = db2Conn.CreateCommand();

               foreach (DataRow row in dtPerfilDetalle.Rows)
               {
                   string perfil = row["Perfil"].ToString();
                   string aplicacion = row["Aplicacion"].ToString();
                   string modulo = row["Modulo"].ToString();
                   string control = row["Control"].ToString();
                   string disponible = row["Disponible"].ToString();
                   string visible = row["Visible"].ToString();
                   string fecha = row["Fecha"].ToString();
                   string hora = row["Hora"].ToString();
                   string estatus = row["Estatus"].ToString();

                   sql.Clear();
                   sql.Append("UPDATE " + LibSatObj + ".SAT177SPDT SET \n");

                   sql.AppendFormat("PDTHAC = " + "'" + "{0}" + "'" + "," + "\n", disponible.PadRight(1, '0'));
                   sql.AppendFormat("PDTVIC = " + "'" + "{0}" + "'" + "\n", visible.PadRight(1, '0'));
                   sql.Append("WHERE \n");
                   sql.AppendFormat("PDTPER = " + "'" + "{0}" + "'" + "\n", perfil.PadRight(35, ' '));
                   sql.Append("AND \n");
                   sql.AppendFormat("PDTAPL = " + "'" + "{0}" + "'" + "\n", aplicacion.PadRight(35, ' '));
                   sql.Append("AND \n");
                   sql.AppendFormat("PDTMOD = " + "'" + "{0}" + "'" + "\n", modulo.PadRight(35, ' '));
                   sql.Append("AND \n");
                   sql.AppendFormat("PDTCLS = " + "'" + "{0}" + "'" + "\n", control.PadRight(35, ' '));

                   db2Comm.CommandText = sql.ToString();
                   db2Comm.ExecuteNonQuery();
               }
               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();
           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();
           }
       }

       public static void EliminaPerfilDetalle(string Perfil, string Aplicacion, string Modulo, string Control)
       {
           string cadenaConexionDb2 = Db2_Prod;
           OleDbConnection db2Conn = null;
           StringBuilder sql = new StringBuilder();
           try
           {
               db2Conn = new OleDbConnection(cadenaConexionDb2);
               db2Conn.Open();
               OleDbCommand db2Comm = db2Conn.CreateCommand();

               sql.Append("DELETE FROM " + LibSatObj + ".SAT177SPDT WHERE\n");
               sql.Append(" PDTPER = \n");
               sql.AppendFormat("'" + "{0}" + "'" + "\n", Perfil);
               sql.Append(" AND \n");
               sql.Append(" PDTAPL = \n");
               sql.AppendFormat("'" + "{0}" + "'" + "\n", Aplicacion);
               sql.Append(" AND \n");
               sql.Append(" PDTMOD = \n");
               sql.AppendFormat("'" + "{0}" + "'" + "\n", Modulo);
               sql.Append(" AND \n");
               sql.Append(" PDTCLS = \n");
               sql.AppendFormat("'" + "{0}" + "'" + "\n", Control);

               db2Comm.CommandText = sql.ToString();
               db2Comm.ExecuteNonQuery();

               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();
           }
           catch
           {

           }
           finally
           {
               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();
           }
       }
    }
}
