﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;
using System.Threading.Tasks;


namespace MmsWin.Datos.Seguridad
{
    public class Usuarios
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static DataTable ObtenUsuarios(string usuario, string nombre, string password, string nivel, string marca, string descripcion, string comprador, string correo, string perfil)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtUsuarios = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177SUSR\n");


                if (usuario != "" | nombre != "" | password != "" | nivel != "" | marca != "" | descripcion != "" | comprador != "" | correo != "" | perfil != "") { sql.AppendFormat(" WHERE "); }

                if (usuario != "")
                {sql.AppendFormat(" USRUSR LIKE " + "'%" + "{0}" + "%'" + "\n", usuario); }
                if (usuario != "" && nombre != "") { sql.AppendFormat(" AND "); }
                if (nombre != "")
                {sql.AppendFormat(" USRNOM LIKE " + "'%" + "{0}" + "%'" + "\n", nombre); }
                if ((usuario != "" | nombre != "") && password != "") { sql.AppendFormat(" AND "); }
                if (password != "")
                {sql.AppendFormat(" USRPSW LIKE " + "'%" + "{0}" + "%'" + "\n", password); }
                if ((usuario != "" | nombre != "" | password != "") && nivel != "") { sql.AppendFormat(" AND "); }
                if (nivel != "")
                {sql.AppendFormat(" USRVIL LIKE " + "'%" + "{0}" + "%'" + "\n", nivel); }
                if ((usuario != "" | nombre != "" | password != "" | nivel != "") && marca != "") { sql.AppendFormat(" AND "); }
                if (marca != "")
                {sql.AppendFormat(" USRMAR LIKE " + "'%" + "{0}" + "%'" + "\n", marca); }
                if ((usuario != "" | nombre != "" | password != "" | nivel != "" | marca != "") && descripcion != "") { sql.AppendFormat(" AND "); }
                if (descripcion != "")
                {sql.AppendFormat(" USRMRD LIKE " + "'%" + "{0}" + "%'" + "\n", descripcion); }
                if ((usuario != "" | nombre != "" | password != "" | nivel != "" | marca != "" | descripcion != "") && comprador != "") { sql.AppendFormat(" AND "); }
                if (comprador != "")
                {sql.AppendFormat(" USRCOM LIKE " + "'%" + "{0}" + "%'" + "\n", comprador); }
                if ((usuario != "" | nombre != "" | password != "" | nivel != "" | marca != "" | descripcion != "" | comprador != "") && correo != "") { sql.AppendFormat(" AND "); }
                if (correo != "")
                {sql.AppendFormat(" USRDIR LIKE " + "'%" + "{0}" + "%'" + "\n", correo); }
                if ((usuario != "" | nombre != "" | password != "" | nivel != "" | marca != "" | descripcion != "" | comprador != "" | correo != "") && perfil != "") { sql.AppendFormat(" AND "); }
                if (perfil != "")
                {sql.AppendFormat(" USRPER LIKE " + "'%" + "{0}" + "%'" + "\n", perfil); }
                
                sql.Append(" ORDER BY USRUSR ASC\n"); 

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtUsuarios = new DataTable("Usuarios");
                dtUsuarios.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtUsuarios;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static  DataTable UpdateUsuarios(DataTable dtUsuario)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                foreach (DataRow row in dtUsuario.Rows)
                {
                    string usuario = row["Usuario"].ToString();
                    string nombre = row["Nombre"].ToString();
                    string password = row["Password"].ToString();
                    string nivel = row["Nivel"].ToString();
                    string marca = row["Marca"].ToString();
                    string descripcion = row["Descripcion"].ToString();
                    string comprador = row["Comprador"].ToString();
                    string correo = row["Correo"].ToString();
                    string perfil = row["Perfil"].ToString();
                    string fecha = row["Fecha"].ToString();
                    string hora = row["Hora"].ToString();
                    string estatus = row["Estatus"].ToString();
                    string usuarioB = row["UsuarioB"].ToString();
                    string perfilB = row["PerfilB"].ToString();

                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT177SUSR SET \n");
                    sql.AppendFormat("USRUSR = " + "'" + "{0}" + "'" + "," + "\n", usuario.PadRight(10, ' '));
                    sql.AppendFormat("USRNOM = " + "'" + "{0}" + "'" + "," + "\n", nombre.PadRight(10, ' '));
                    sql.AppendFormat("USRPSW = " + "'" + "{0}" + "'" + "," + "\n", password.PadRight(10, ' '));
                    sql.AppendFormat("USRVIL = " + "'" + "{0}" + "'" + "," + "\n", nivel.PadRight(13, ' '));
                    sql.AppendFormat("USRMAR = " + "'" + "{0}" + "'" + "," + "\n", marca.PadLeft(3, '0'));
                    sql.AppendFormat("USRMRD = " + "'" + "{0}" + "'" + "," + "\n", descripcion.PadRight(20, ' '));
                    sql.AppendFormat("USRCOM = " + "'" + "{0}" + "'" + "," + "\n", comprador.PadRight(3, ' '));
                    sql.AppendFormat("USRDIR = " + "'" + "{0}" + "'" + "," + "\n", correo.PadRight(100, ' '));
                    sql.AppendFormat("USRPER = " + "'" + "{0}" + "'" + "," + "\n", perfil.PadRight(100, ' '));
                    sql.AppendFormat("USRULF = " + "'" + "{0}" + "'" + "," + "\n", fecha.PadLeft(6, '0'));
                    sql.AppendFormat("USRULH = " + "'" + "{0}" + "'" + "," + "\n", hora.PadLeft(6, '0'));
                    sql.AppendFormat("USRSTS = " + "'" + "{0}" + "'" + "," + "\n", estatus.PadRight(1, ' '));
                    sql.AppendFormat("USRUSRB = " + "'" + "{0}" + "'" + "," + "\n", usuario.PadRight(10, ' '));
                    sql.AppendFormat("USRPERB = " + "'" + "{0}" + "'" + "\n", perfil.PadRight(100, ' '));
                    sql.Append("WHERE \n");
                    sql.AppendFormat("USRUSRB = " + "'" + "{0}" + "'" + "\n", usuarioB.PadRight(10, ' '));
                    sql.Append("AND \n");
                    sql.AppendFormat("USRPERB = " + "'" + "{0}" + "'" + "\n", perfilB.PadRight(35, ' '));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();
                }
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

           
                return dtUsuario;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void EliminaUsuario(string usuarioB, string perfilB)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("DELETE FROM " + LibSatObj + ".SAT177SUSR WHERE\n");
                sql.Append(" USRUSRB = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", usuarioB);
                sql.Append(" AND USRPERB = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", perfilB);

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch
            {

            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
