﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Seguridad
{
    public class Perfiles
    {


#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static DataTable ObtenPerfiles(string perfil, string descripcion)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtPerfiles = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177SPER\n");

                if (perfil != "" | descripcion != "") { sql.AppendFormat(" WHERE "); }

                if (perfil != "")
                {
                    sql.AppendFormat(" PERPER LIKE " + "'%" + "{0}" + "%'" + "\n", perfil);
                }

                if (perfil != "" && descripcion != "") { sql.AppendFormat(" AND "); }

                if (descripcion != "")
                {
                    sql.AppendFormat(" PERDES LIKE " + "'%" + "{0}" + "%'" + "\n", descripcion);
                }

                sql.Append(" ORDER BY PERPER ASC\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtPerfiles = new DataTable("Perfiles");
                dtPerfiles.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtPerfiles;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable UpdatePerfiles(DataTable dtUsuario)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                foreach (DataRow row in dtUsuario.Rows)
                {
                    string perfil = row["Perfil"].ToString();
                    string descripcion = row["Descripcion"].ToString();
                    string fecha = row["Fecha"].ToString();
                    string hora = row["Hora"].ToString();
                    string estatus = row["Estatus"].ToString();
                    string perfilB = row["PerfilB"].ToString();

                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT177SPER SET \n");

                    sql.AppendFormat("PERPER = " + "'" + "{0}" + "'" + "," + "\n", perfil.PadRight(35, ' '));
                    sql.AppendFormat("PERDES = " + "'" + "{0}" + "'" + "," + "\n", descripcion.PadRight(50, ' '));
                    sql.AppendFormat("PERFCH = " + "'" + "{0}" + "'" + "," + "\n", fecha.PadLeft(6, '0'));
                    sql.AppendFormat("PERHOR = " + "'" + "{0}" + "'" + "," + "\n", hora.PadLeft(6, '0'));
                    sql.AppendFormat("PERSTS = " + "'" + "{0}" + "'" + "," + "\n", estatus.PadRight(1, ' '));
                    sql.AppendFormat("PERPERB = " + "'" + "{0}" + "'" + "\n", perfil.PadRight(35, ' '));
                    sql.Append("WHERE \n");
                    sql.AppendFormat("PERPERB = " + "'" + "{0}" + "'" + "\n", perfilB.PadRight(35, ' '));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();
                }
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtUsuario;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void EliminaPerfil(string perfilB)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("DELETE FROM " + LibSatObj + ".SAT177SPER WHERE\n");
                sql.Append(" PERPERB = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", perfilB);

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch
            {      }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
