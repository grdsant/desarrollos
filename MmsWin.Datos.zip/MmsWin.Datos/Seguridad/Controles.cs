﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Seguridad
{
    public class Controles
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static DataTable ObtenControles(string control, string descripcion, string aplicacion, string modulo, string tipo)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtControles = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT * FROM " + LibSatObj + ".SAT177SCLS\n");

                if (control != "" | descripcion != "" | aplicacion != "" | modulo != "" | tipo != "") {sql.AppendFormat(" WHERE "); }

                if (control != "")
                {
                    sql.AppendFormat(" CLSCTL LIKE " + "'%" + "{0}" + "%'" + "\n", control);
                }

                if (control != "" && descripcion != "") { sql.AppendFormat(" AND "); }

                if (descripcion != "")
                {
                    sql.AppendFormat(" CLSDES LIKE " + "'%" + "{0}" + "%'" + "\n", descripcion);
                }

                if ((control != "" | descripcion != "") &&  aplicacion != "") { sql.AppendFormat(" AND "); }

                if (aplicacion != "")
                {
                    sql.AppendFormat(" CLSAPL LIKE " + "'%" + "{0}" + "%'" + "\n", aplicacion);
                }

                if ((control != "" | descripcion != "" | aplicacion != "") && modulo != "" ) { sql.AppendFormat(" AND "); }

                if (modulo != "")
                {
                    sql.AppendFormat(" CLSMOD LIKE " + "'%" + "{0}" + "%'" + "\n", modulo);
                }

                if ((control != "" | descripcion != "" | aplicacion != "" | modulo != "") && tipo != "") { sql.AppendFormat(" AND "); }

                if (tipo != "")
                {
                    sql.AppendFormat(" CLSTIP LIKE " + "'%" + "{0}" + "%'" + "\n", tipo);
                }
                sql.Append(" ORDER BY CLSAPL, CLSMOD, CLSCTL ASC\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtControles = new DataTable("controles");
                dtControles.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtControles;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable GrabaControles(DataTable dtControles)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();

                foreach (DataRow row in dtControles.Rows)
                {
                    string ParAplicacion = row["Aplicacion"].ToString();
                    string ParModulo = row["Modulo"].ToString();
                    string ParControl = row["Control"].ToString();
                    string ParTipo = row["Tipo"].ToString();
                    string ParUsuario = row["Usuario"].ToString();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R31 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParAplicacion.PadRight(35, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParModulo.PadRight(35, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParControl.PadRight(50, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParTipo.PadRight(20, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParUsuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();
                }

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
                return dtControles;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
