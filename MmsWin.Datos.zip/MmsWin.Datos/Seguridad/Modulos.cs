﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Seguridad
{
   public class Modulos
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

       public static DataTable ObtenModulos()
       {
           string cadenaConexionDb2 = Db2_Prod;

           OleDbConnection db2Conn = null;

           StringBuilder sql = new StringBuilder();
           DataTable dtModulos = null;

           try
           {
               db2Conn = new OleDbConnection(cadenaConexionDb2);
               db2Conn.Open();
               OleDbCommand db2Comm = db2Conn.CreateCommand();

               sql.Append("SELECT * FROM " + LibSatObj + ".SAT177SMOD\n");
               sql.Append(" ORDER BY MODMOD, MODAPL ASC\n");

               db2Comm.CommandText = sql.ToString();
               OleDbDataReader db2Reader = db2Comm.ExecuteReader();

               dtModulos = new DataTable("Aplicaciones");
               dtModulos.Load(db2Reader);
               db2Reader.Close();

               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();

               return dtModulos;
           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();
           }
       }
    }
}
