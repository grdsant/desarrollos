﻿using Data.Common.SQL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace MmsWin.Datos.CambioPrecio
{
    public class CambioPrecio
    {
        #region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseriesAll"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
        #endregion

        #region " Regresa la consulta del cambio de precio sin Folio asignado "
        public static DataTable CambioPrecioSinFolio(string idComprador)
        {
            OleDbConnection db2Conn = null;
            DataTable dtCambioPrecio = new DataTable();
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                //sql.Clear();
                //sql.Append(" SELECT \n");
                //sql.Append("       CAST(SASNUM AS VARCHAR(100)) AS IDPROV, \n");                 // # del Proveedor  
                //sql.Append("       ASNAME AS PROVEEDOR, \n");              // Nombre del Proveedor   
                //sql.Append("       CAST(SSTYLQ  AS VARCHAR(100)) AS IDESTILO, \n");               // # del Estilo                        
                //sql.Append("       SSTYLE AS ESTILO, \n");                 // Nombre del Estilo  
                //sql.Append("       IFNULL(ONHAND, 0) AS ONHAND, \n");        // Inventario
                //sql.Append("       IFNULL(COSTOOR, 0) AS CSTOR, \n");        // Costo del Estilo Original
                //sql.Append("       IFNULL(PRECIOOR, 0) AS PRCOR,\n");        // Precio del Estilo Original
                //sql.Append("       IFNULL(MARGENOR, 0) AS MAROR, \n");       // Margen del Estilo Original
                //sql.Append("       IFNULL(COSTOACT, 0) AS CSTAC, \n");        // Costo del Estilo Actual
                //sql.Append("       IFNULL(PRECIOACT, 0) AS PRCAC,\n");        // Precio del Estilo Actual
                //sql.Append("       IFNULL(MARGENACT, 0) AS MARAC, \n");        // Margen del Estilo Actual
                //sql.Append("       IFNULL(IDMARCA, 0) AS IDMARCA, \n");        // El # de la Marca
                //sql.Append("       IFNULL(MARCA, '') AS MARCA, \n");            // la Marca
                //sql.Append("       IFNULL(TEMP, '') AS TEMP \n");              // la Temporada
                //sql.Append("   FROM MMNETLIB.SAT177RPC \n");
                //sql.Append(" ORDER BY ASNAME, SSTYLE  ASC\n");
                sql.Clear();
                sql.Append(" SELECT \n");
                sql.Append("       CAST(ASNUM AS VARCHAR(100)) AS IDPROV,\n");
                sql.Append("       ASNAME AS PROVEEDOR, \n");
                sql.Append("       CAST(SSTYLQ  AS VARCHAR(100)) AS IDESTILO, \n");
                sql.Append("       SSTYLE AS ESTILO, \n");
                sql.Append("       CAST(ASBUYR  AS VARCHAR(100)) AS IDCOMPRADOR,\n");
                sql.Append("       BYRNAM  AS COMPRADOR,	\n");
                sql.Append("       IFNULL(ONHAND, 0) AS ONHAND, \n");        // Inventario
                sql.Append("       IFNULL(COSTOOR, 0) AS CSTOR, \n");        // Costo del Estilo Original
                sql.Append("       IFNULL(PRECIOOR, 0) AS PRCOR,\n");        // Precio del Estilo Original
                sql.Append("       IFNULL(MARGENOR, 0) AS MAROR, \n");       // Margen del Estilo Original
                sql.Append("       IFNULL(COSTOACT, 0) AS CSTAC, \n");       // Costo del Estilo Actual
                sql.Append("       IFNULL(PRECIOACT, 0) AS PRCAC,\n");       // Precio del Estilo Actual
                sql.Append("       IFNULL(MARGENACT, 0) AS MARAC, \n");      // Margen del Estilo Actual
                sql.Append("       IFNULL(IDMARCA, 0) AS IDMARCA, \n");      // El # de la Marca
                sql.Append("       IFNULL(MARCA, '') AS MARCA, \n");         // la Marca
                sql.Append("       IFNULL(TEMP, '') AS TEMP \n");            // la Temporada
                sql.Append("   FROM MMNETLIB.SAT1CP1\n");
                if(idComprador != "999")
                    sql.AppendFormat(" WHERE ASBUYR = {0}\n" , idComprador);

                sql.Append(" ORDER BY ASNUM, SSTYLE, BYRNAM ASC\n");

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;
                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);
                daDb2.Fill(dtCambioPrecio);

                return dtCambioPrecio;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Obtener el número de folio para Estilos Preautorizados "
        public static string ObtieneFolio()
        {
            StringBuilder sql = new StringBuilder();
            string dato = "";

            try
            {
                sql.Clear();
                sql.Append(" SELECT IFNULL(MAX(SASFOLIO), 0) + 1  FROM MMNETLIB.SAT702F ");  // # maximo del folio a insertar

                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();

                    OleDbDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        dato = reader[0].ToString();
                    }

                    reader.Close();
                }

                return dato;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Carga los Folio que ya estan dados de alta "
        public static DataTable CargaListaFolios(string idComprador,string Folio = "P")
        {
            OleDbConnection db2Conn = null;
            DataTable dtFolios = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Clear();
                sql.Append(" SELECT DISTINCT SASFOLIO AS FOLIO, \n");
                sql.Append("       CAST(CASE SASESTA WHEN 'P' THEN 'Pendientes'   \n");
                sql.Append("                    WHEN 'A' THEN 'Autorizados'   \n");
                sql.Append("                    WHEN 'C' THEN 'Vencido' END AS VARCHAR(20)) AS ESTATUS,\n");
                sql.Append("       CAST(SASESTA AS VARCHAR(10)) AS IDESTATUS\n");
                sql.Append("  FROM MMNETLIB.SAT702F \n");
                // sql.AppendFormat(" 	WHERE SASFOLIO LIKE '{0}%'\n ", Folio);
                sql.AppendFormat(" 	WHERE SASESTA ='{0}'\n ", Folio);

                if(idComprador != "999")
                    sql.AppendFormat(" 	AND BYRNUM ='{0}'\n ", idComprador); 

                sql.Append(" ORDER BY SASFOLIO ASC\n");

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtFolios);

                return dtFolios;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " modifica el folio proveedor y Estilos cambiandolñe el precio "
        public static int modificaFolioCP(string folioMod, string costoMod, string precioMod, string margenMod, string proveeMod, string estiloMod, string marcaDes, string tempo, string idComprador)
        {
            StringBuilder sql = new StringBuilder();
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("es-MX");
            string[] Fechas;

            try
            {
                int idApp = 0, Fecha400 = 0;
                Fechas = DateTime.Now.GetDateTimeFormats();
                Fecha400 = Convert.ToInt32(Fechas[6].Replace("-", "").Substring(2, 6));

                using (OleDbConnection DB = new OleDbConnection(Db2_Prod))
                {
                    DB.Open();
                    OleDbCommand command = new OleDbCommand();
                    command.Connection = DB;
                    command.CommandType = CommandType.Text;

                    sql.Clear();
                    sql.Append("UPDATE MMNETLIB.SAT702F \n");
                    sql.AppendFormat(" SET CSTNU = {0}, \n", costoMod);
                    sql.AppendFormat(" PRCNU = {0},\n", precioMod);
                    sql.AppendFormat(" MARNU = {0},\n", margenMod);
                    sql.AppendFormat(" SASFECH = {0} \n", Fecha400);
                    sql.AppendFormat(" WHERE SASFOLIO = '{0}' AND SASNUM= '{1}' AND SSTYLQ = '{2}' AND SASMARC= '{3}' AND SASTEMP= '{4}' AND BYRNUM= '{5}' \n",
                                                         folioMod, proveeMod, estiloMod, marcaDes, tempo, idComprador);

                    command.CommandText = sql.ToString();
                    idApp = command.ExecuteNonQuery();
                }
                return idApp;
            }
            catch (Exception ex)
            {
                throw new Exception(ex + " No se pudo completar el proceso del cambio de precio. !Comuniquese con el administrador¡");
            }
        }
        #endregion

        #region " inserta el número de folio para Estilos Preautorizados "
        public static int nuevoFolioCP(DataTable dtIngresaFolio, string Usuario)
        {
            int idApp = 0, Fecha400 = 0, cont = 0;
            StringBuilder sql = new StringBuilder();
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("es-MX");
            string[] Fechas;

            try
            {
                Fechas = DateTime.Now.GetDateTimeFormats();
                Fecha400 = Convert.ToInt32(Fechas[6].Replace("-", "").Substring(2, 6));

                using (OleDbConnection DB = new OleDbConnection(Db2_Prod))
                {
                    DB.Open();
                    OleDbCommand command = new OleDbCommand();
                    command.Connection = DB;

                    sql.Clear();
                    sql.Append("INSERT INTO MMNETLIB.SAT702F (SASFOLIO, SASNUM, SSTYLQ, BYRNUM, SASMARC, SASMARDESC, SASFECHCAP, SASUSER, SASTEMP, SASESTA) \n");

                    foreach (DataRow insert in dtIngresaFolio.Rows)
                    {
                        string folio = string.Empty, idProv = string.Empty, idStilo = string.Empty, idmarca = string.Empty, marcades = string.Empty;
                        string temp = string.Empty, idComp = string.Empty, values = "VALUES";
                        cont++;

                        folio = insert["FOLIO"].ToString();
                        idProv = insert["IDPROV"].ToString();
                        idStilo = insert["IDESTILO"].ToString();
                        idmarca = insert["IDMARCA"].ToString();
                        marcades = insert["MARCA"].ToString();
                        temp = insert["TEMP"].ToString();
                        idComp = insert["IDCOMPRADOR"].ToString();

                        if (cont > 1)
                            values = values.Replace("VALUES", "");

                        sql.AppendFormat(values + "('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}','P'),\n", folio, idProv, idStilo, idComp, idmarca, marcades, Fecha400, Usuario, temp);

                    }
                    sql.Remove(sql.Length - 2, 2);
                    command.CommandText = sql.ToString();
                    idApp = command.ExecuteNonQuery();
                }
                return idApp;
            }
            catch (Exception ex)
            {
                throw new Exception(ex + " No se pudo completar el proceso del Folio. !Comuniquese con el administrador¡");
            }
        }
        #endregion

        #region " Carga el detalle de los estilos que ya tienen folio proveedor y estilo "
        public static DataTable cargaDetallePorFolio(string Folio, string proveedor, string estilo, string marca, string temp)
        {
            OleDbConnection db2Conn = null;
            DataTable dtFolios = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Clear();
                sql.Append(" SELECT FECHACAM, CSTCAM, PRCCAM, MARCAM \n");
                sql.Append("  FROM  MMNETLIB.SAT177DTCP    \n");
                sql.AppendFormat("    WHERE SASFOLIO = '{0}' \n", Folio);
                sql.AppendFormat("      AND SASNUM = '{0}'\n", proveedor);
                sql.AppendFormat("      AND SSTYLQ = '{0}'\n", estilo);
                sql.AppendFormat("      AND SASMARC = '{0}'\n", marca);
                sql.AppendFormat("      AND SASTEMP = '{0}'\n", temp);
               // sql.Append("      ORDER BY FECHACAM DESC \n");
                sql.Append(" GROUP BY  FECHACAM, CSTCAM, PRCCAM, MARCAM  \n"); // No Eventos en cambios a Precios y costos

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtFolios);

                return dtFolios;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " Autoriza los Flios cambia el estatus "
        public static bool AutorizaFolio(string folio, string estatus, string usuario)
        {
            StringBuilder sql = new StringBuilder();
            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("es-MX");
            try
            {
                string[] Fechas = DateTime.Now.GetDateTimeFormats();

                int Fecha400 = Convert.ToInt32(Fechas[6].Replace("-", "").Substring(2, 6));

                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    connection.Open();

                    sql.Clear();
                    sql.AppendFormat(" UPDATE MMNETLIB.SAT702F SET SASESTA = '{0}' WHERE SASFOLIO = '{1}' ", estatus, folio);

                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);
                    command.ExecuteNonQuery();

                    sql.Clear();
                    sql.AppendFormat(" DELETE FROM MMNETLIB.SAT177RPCCP WHERE FOLIO = '{0}' ", folio);

                    command = new OleDbCommand(sql.ToString(), connection);
                    command.ExecuteNonQuery();

                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Elimina los registros que no autorizaron "
        public static bool EliminaNoAutorizados(string folio, string estilo, string proveedor, string marca, string temporada, string idcomprador)
        {
            StringBuilder sql = new StringBuilder();
            try
            {
                sql.Clear();
                sql.AppendFormat(" DELETE FROM MMNETLIB.SAT702F \n WHERE SASFOLIO = '{0}' AND SASNUM = '{1}' AND SSTYLQ = '{2}' AND SASMARC = '{3}' AND SASTEMP = '{4}' AND BYRNUM = '{5}' ",
                                    folio, proveedor, estilo, marca, temporada, idcomprador);

                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();

                    command.ExecuteNonQuery();

                    return true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Carga el detalle de los estilos que ya tienen folio "
        public static DataTable CargaDetalleFolio(string Folio)
        {
            OleDbConnection db2Conn = null;
            DataTable dtFolios = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Clear();
                sql.Append(" SELECT \n");
                sql.Append("		FOLIO,\n");
                sql.Append("		IDPROV,	\n");
                sql.Append("		PROVEEDOR,\n");
                sql.Append("		IDESTILO,	\n");
                sql.Append("		ESTILO,\n");
                sql.Append("		IDCOMPRADOR,\n");
                sql.Append("		COMPRADOR,\n");
                sql.Append("		ONHAND,\n");
                sql.Append("		CSTOR,\n");
                sql.Append("		PRCOR,\n");
                sql.Append("		MAROR,\n");
                sql.Append("		CSTAC,\n");
                sql.Append("		PRCAC,\n");
                sql.Append("		MARAC,\n");
                sql.Append("		CSTNU,\n");
                sql.Append("		PRCNU,\n");
                sql.Append("		MARNU,\n");
                sql.Append("		INCRULT AS PORCINCL,\n");
                sql.Append("		INCRORI AS PORCINOR,\n");
                sql.Append("		FECHAUC,\n");
                sql.Append("		NOEVENTOSCST,\n");
                sql.Append("		NOEVENTOSPRC,\n");
                sql.Append("		NOEVENTOS,\n");
                sql.Append("		ESTATUS,\n");
                sql.Append("		IDMARCA,\n");
                sql.Append("		MARCA,\n");
                sql.Append("		TEMP\n");
                sql.Append(" FROM MMNETLIB.SAT177CBCP\n");
                sql.AppendFormat(" WHERE FOLIO = '{0}' \n", Folio);
                sql.Append("ORDER BY PROVEEDOR, ESTILO ASC \n");

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtFolios);

                return dtFolios;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " obtiene el Margen de Precio limite"
        public static decimal obtenMargenPrecio(string marca)
        {
            decimal resultado = 0;
            StringBuilder sql = new StringBuilder();
            string noEvento = "";
            OleDbConnection db2Conn = null;

            try
            {
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.AppendFormat("SELECT IFNULL(MARPRE, 0) FROM MMSATOBJ.SAT177SMAR WHERE MARMID  = '{0}' \n", marca);
                db2Comm.CommandText = sql.ToString();

                OleDbDataReader reader = db2Comm.ExecuteReader();

                while (reader.Read())
                {
                    noEvento = reader[0].ToString();
                }

                resultado = Convert.ToDecimal(noEvento == "" ? "0" : noEvento);

                reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " obtiene el redondeo permitido "
        public static DataTable obtenRedondeoPre(string marca)
        {
            OleDbConnection db2Conn = null;
            DataTable dtFolios = new DataTable();
            StringBuilder sql = new StringBuilder();

            try
            {
                sql.Clear();
                sql.AppendFormat("SELECT FIRDES AS PINI, FIRHAS AS PFIN, FIRPPOR AS PORCE, FIRPEN AS REDONDEO FROM MMNETLIB.SAT177CFR WHERE FIRAMARCA = '{0}' AND  FIRGRU = '{0}' \n", marca);

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand cmdDb2 = new OleDbCommand(sql.ToString(), db2Conn);
                cmdDb2.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(cmdDb2);

                daDb2.Fill(dtFolios);

                return dtFolios;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
        #endregion

        #region " llena la tabla con los movimientos para el reporte de cambio de precio "
        public static void ObtenEstilosPrepedidos(string folio)
        {
            StringBuilder sql = new StringBuilder();
            OleDbConnection db2Conn = null;
            DataTable dtFolios = new DataTable();
            DataTable dtDetalle = new DataTable();
            try
            {
                existeFolio(folio);

                sql.Clear();

                sql.Append(" SELECT \n");
                sql.Append("       FOLIO,  \n");        // Campo de # de folio
                sql.Append("       IDPROV,	 \n");      // Campo de # de preveedor
                sql.Append("       PROVEEDOR,\n");      // Campo de nombre de preveedor
                sql.Append("       IDESTILO,\n");       // Campo de # de estilo
                sql.Append("       ESTILO,	\n");       // Campo de nombre de estilo
                sql.Append("       IDCOMPRADOR, \n");   // Campo de # de comprador
                sql.Append("       COMPRADOR, \n");     // Campo de nombre de comprador
                sql.Append("	   ONHAND, \n");        // Inventario
                sql.Append("	   CSTOR, \n");         // Campo de costo original
                sql.Append("	   PRCOR, \n");         // Campo de precio original
                sql.Append("	   MAROR,\n");          // Campo de margen original
                sql.Append("	   CSTAC, \n");         // Campo de costo actual
                sql.Append("	   PRCAC,\n");          // Campo de precio actual
                sql.Append("	   MARAC, \n");         // Campo de margen actual
                sql.Append("	   CSTNU,  \n");        // Campo de costo nuevo
                sql.Append("	   PRCNU,  \n");        // Campo de precio nuevo, 
                sql.Append("	   MARNU, \n");         // Campo de margen nuevo   
                sql.Append("       INCRULT, \n");       // Campo de ultimo incremento  (costoNu-CostoAct)/CostoAct % DE INCREMENTO VS ÚLTIMO
                sql.Append("       INCRORI, \n");       // Campo de inctremento original (costoNu-CostoOri)/CostoOri % DE INCREMENTO VS ORIGINAL  
                sql.Append("       FECHAUC, \n");       // Campo del ultimo cambio de precio
                sql.Append("       ESTATUS, \n");       // Estatus que contiene el cambio de precio
                sql.Append("       TEMP, \n");          // Temporada 
                sql.Append("       MARCA \n");          // Marca
                sql.Append("FROM MMNETLIB.SAT177CBCP  \n");
                sql.AppendFormat("	WHERE FOLIO = {0} \n", folio);

                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand db2Comm = new OleDbCommand(sql.ToString(), db2Conn);
                db2Comm.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(db2Comm);

                daDb2.Fill(dtFolios);

                int ordena = 0;
                foreach (DataRow insert in dtFolios.Rows)
                {
                    string idProv = string.Empty, idStilo = string.Empty, provee = string.Empty, estilo = string.Empty, onhand = string.Empty, ctoOr = string.Empty;
                    string preOr = string.Empty, marOr = string.Empty, temp = string.Empty, idcomprador = string.Empty, comprador = string.Empty, marca = string.Empty;
                    string ctoAct = string.Empty, preAct = string.Empty, marAct = string.Empty, ctoNue = string.Empty, preNue = string.Empty, marNue = string.Empty, IncUlt = string.Empty;
                    string IncOr = string.Empty, fecUlt = string.Empty, eveCosto = string.Empty, evePre = string.Empty, events = string.Empty, estatus = string.Empty;

                    if (ordena != 1)
                        ordena++;

                    idProv = insert["IDPROV"].ToString();
                    idStilo = insert["IDESTILO"].ToString();
                    provee = insert["PROVEEDOR"].ToString();
                    idcomprador = insert["IDCOMPRADOR"].ToString();
                    comprador = insert["COMPRADOR"].ToString();
                    estilo = insert["ESTILO"].ToString();
                    onhand = insert["ONHAND"].ToString();
                    ctoOr = insert["CSTOR"].ToString();
                    preOr = insert["PRCOR"].ToString();
                    marOr = insert["MAROR"].ToString();
                    ctoAct = insert["CSTAC"].ToString();
                    preAct = insert["PRCAC"].ToString();
                    marAct = insert["MARAC"].ToString();
                    ctoNue = insert["CSTNU"].ToString();
                    preNue = insert["PRCNU"].ToString();
                    marNue = insert["MARNU"].ToString();
                    IncUlt = insert["INCRULT"].ToString();
                    IncOr = insert["INCRORI"].ToString();
                    fecUlt = insert["FECHAUC"].ToString();
                    estatus = insert["ESTATUS"].ToString();
                    temp = insert["TEMP"].ToString();
                    marca = insert["MARCA"].ToString();

                    sql.Clear();
                    sql.Append("SELECT SUM(T3.EVENCST) as NOEVENTOSCST,  SUM(T3.EVENPRE) AS  NOEVENTOSPRC, SUM(T3.EVENCST) + SUM(T3.EVENPRE) AS NOEVENTOS \n");
                    sql.Append(" FROM (\n");
                    sql.Append("       SELECT CSTCDT AS FECHACAM, CSTVND AS PROCAM, CSTSTY AS ESTCAM, CSTAMT AS COSTOCAM, 0 PRECAM, COUNT(CSTCDT) EVENCST, 0 EVENPRE\n");
                    sql.AppendFormat("   FROM MM610LIB.CSTPLN WHERE CSTSTR = 0 AND CSTITM = 0 AND CSTVND = '{0}'  AND CSTSTY = '{1}'   \n", idProv, idStilo);
                    sql.Append("       GROUP BY CSTVND, CSTSTY, CSTAMT, CSTCDT\n");
                    sql.Append("UNION ALL\n");
                    sql.Append("SELECT PLNCDT AS FECHACAM, PLNVND AS PROCAM, PLNSTY AS ESTCAM, 0 AS COSTOCAM, PLNAMT AS PRECAM, 0 EVENCST, COUNT(PLNCDT) EVENPRE \n");
                    sql.AppendFormat(" FROM MM610LIB.PRCPLN WHERE PLNSTR = 0 AND PLNITM = 0 AND PLNVND = '{0}' AND PLNSTY = '{1}' \n", idProv, idStilo);
                    sql.Append("  GROUP BY PLNVND, PLNSTY, PLNAMT, PLNCDT\n");
                    sql.Append("  )T3\n");

                    db2Comm.CommandText = sql.ToString();
                    OleDbDataReader reader = db2Comm.ExecuteReader();

                    while (reader.Read())
                    {
                        eveCosto = Convert.ToString(reader.GetInt32(0));
                        evePre = Convert.ToString(reader.GetInt32(1));
                        events = Convert.ToString(reader.GetInt32(2));
                    }

                    reader.Close();

                    sql.Clear();
                    sql.Append("INSERT INTO MMNETLIB.SAT177RPCCP\n");
                    sql.Append("  (ORDENA,FOLIO,IDPROV,PROVEEDOR,IDESTILO,ESTILO,IDCOMPRADOR,COMPRADOR,ONHAND,CSTOR,PRCOR,MAROR,CSTAC,PRCAC,MARAC,CSTNU,PRCNU,MARNU,INCRULT,INCRORI,FECHAUC,NOEVENTOSCST,NOEVENTOSPRC,NOEVENTOS,ESTATUS,TEMP, MARCA)\n");
                    sql.AppendFormat("VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', '{15}', '{16}', '{17}', '{18}', '{19}', '{20}', '{21}', '{22}', '{23}', '{24}', '{25}', '{26}')"
                                            , ordena, folio, idProv, provee, idStilo, estilo, idcomprador, comprador, onhand, ctoOr, preOr, marOr, ctoAct, preAct, marAct, ctoNue, preNue, marNue, IncUlt, IncOr, fecUlt, eveCosto, evePre, events, estatus, temp, marca);
                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    dtDetalle = union(folio, idProv, idStilo, fecUlt);

                    if (dtDetalle.Rows.Count > 0)
                    {
                        foreach (DataRow detalle in dtDetalle.Rows)
                        {
                            string orden = detalle["ORDENA"].ToString();
                            idProv = detalle["IDPROV"].ToString();
                            idStilo = detalle["IDESTILO"].ToString();
                            provee = detalle["PROVEEDOR"].ToString();
                            estilo = detalle["ESTILO"].ToString();
                            onhand = detalle["ONHAND"].ToString();
                            ctoOr = detalle["CSTOR"].ToString();
                            preOr = detalle["PRCOR"].ToString();
                            marOr = detalle["MAROR"].ToString();
                            ctoAct = detalle["CSTAC"].ToString();
                            preAct = detalle["PRCAC"].ToString();
                            marAct = detalle["MARAC"].ToString();
                            ctoNue = detalle["CSTNU"].ToString();
                            preNue = detalle["PRCNU"].ToString();
                            marNue = detalle["MARNU"].ToString();
                            IncUlt = detalle["INCRULT"].ToString();
                            IncOr = detalle["INCRORI"].ToString();
                            eveCosto = detalle["NOEVENTOSCST"].ToString();
                            evePre = detalle["NOEVENTOSPRC"].ToString();
                            events = detalle["NOEVENTOS"].ToString();
                            fecUlt = detalle["FECHAUC"].ToString();
                            estatus = detalle["ESTATUS"].ToString();
                            temp = detalle["TEMP"].ToString();

                            sql.Clear();
                            sql.Append("INSERT INTO MMNETLIB.SAT177RPCCP\n");
                            sql.Append("  (ORDENA,FOLIO,IDPROV,PROVEEDOR,IDESTILO,ESTILO,ONHAND,CSTOR,PRCOR,MAROR,CSTAC,PRCAC,MARAC,CSTNU,PRCNU,MARNU,INCRULT,INCRORI,FECHAUC,NOEVENTOSCST,NOEVENTOSPRC,NOEVENTOS,ESTATUS,TEMP)\n");
                            sql.AppendFormat("VALUES ('{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}', '{13}', '{14}', '{15}', '{16}', '{17}', '{18}', '{19}', '{20}', '{21}', '{22}', '{23}')"
                                          , orden, folio, idProv, provee, idStilo, estilo, onhand, ctoOr, preOr, marOr, ctoAct, preAct, marAct, ctoNue, preNue, marNue, IncUlt, IncOr, fecUlt, eveCosto, evePre, events, estatus, temp);
                            db2Comm.CommandText = sql.ToString();
                            db2Comm.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " union de las tablas del detalle con otros estilos ya nombrados diferentes  "
        private static DataTable union(string folio, string idProv, string idStilo, string fecUlt)
        {
            StringBuilder sql = new StringBuilder();
            OleDbConnection db2Conn = null;
            DataTable dtPrepedidos = new DataTable();
            DataTable dtDetalleFolios = new DataTable();
            DateTime fecha = Convert.ToDateTime(fecUlt);

            try
            {
                string provNue = string.Empty, estilNue = string.Empty;
                //sql.Clear();
                //sql.Append(" SELECT fclaprov prove, fclaest estiloNue  \n");
                //sql.Append(" FROM  tpremae  where fclaestold is not null and fstatus = 'L'\n");
                //sql.AppendFormat("and fclaprov in ('{0}') and fclaestold in ('{1}') \n", idProv, idStilo);
                sql.Clear();
                sql.Append("select t1.fclaprov prove,\n");
                sql.Append("stuff((select ', ' + t2.fclaest \n");
                sql.Append("from tpremae  t2\n");
                sql.Append("where t1.fclaestold = t2.fclaestold\n");
                sql.Append("for xml path('')),1,2,'') 'estiloNue'\n");
                sql.Append("from tpremae t1\n");
                sql.Append("where fclaestold is not null and fstatus = 'L'\n"); ;
                sql.AppendFormat("and fclaprov = '{0}' and fclaestold = '{1}' \n", idProv, idStilo);
                sql.Append("group by fclaprov, fclaest, fclaestold\n");

                using (DBHelperSQL DB = new DBHelperSQL("cnnPrePedido"))
                {
                    using (var dr = DB.EjecutaReader(sql.ToString(), null))
                    {
                        while (dr.Read())
                        {
                            provNue = dr.GetInt32(0).ToString();
                            estilNue = dr.GetString(1);
                        }
                        dr.Close();
                    }
                }

                if (estilNue.Contains(','))
                {
                    String[] arreglo = estilNue.Split(',');
                    for (int i = 0; i <= (arreglo.Length -1); i++)
                    {

                        estilNue = "'" + arreglo[i] + "'" + ",";
                    }
                    estilNue = estilNue.TrimEnd(',');
                }
                else
                {
                    estilNue = "'" + estilNue + "'";
                }

                sql.Clear();
                sql.Append("  SELECT ROWNUMBER() OVER (ORDER BY FECHAUC DESC ) + 1 as ORDENA, D.* FROM (\n");
                sql.Append("  SELECT\n");
                sql.Append("		      T1.SASFOLIO AS FOLIO, \n");                // Campo de # de folio
                sql.Append("			  T1.SASNUM AS IDPROV, \n");                 // Campo de # de preveedor
                sql.Append("			  '' AS PROVEEDOR,      \n");                // Campo de nombre de preveedor
                sql.Append("			  T1.SSTYLQ AS IDESTILO, \n");               // Campo de # de estilo
                sql.Append("			  '' AS ESTILO,        \n");                 // Campo de nombre de estilo
                sql.Append("		      0 ONHAND, 0 CSTOR ,0 PRCOR, 0 MAROR,\n");
                sql.Append("		      IFNULL(COALESCE(T3.COSTOCAM, 0),0) AS CSTAC, \n");        // Campo de costo CAMBIO PARA UNIOS CONVERTIDO A actual
                sql.Append("		      IFNULL(COALESCE(T3.PRECAM, 0),0) AS PRCAC,  \n");         // Campo de precio CAMBIO PARA UNIOS CONVERTIDO A actual
                sql.Append("		      CAST((1-(IFNULL(T3.COSTOCAM, 0) * 1.16) / IFNULL(T3.PRECAM, 0)) * 100 AS DECIMAL(18,2)) AS MARAC,\n");  // Campo de margen CAMBIO PARA UNIOS CONVERTIDO A actual
                sql.Append("		      0 CSTNU, 0 PRCNU, 0 MARNU, 0 INCRULT, 0 INCRORI,\n");
                
                //sql.Append("		      IFNULL(SUBSTRING(CHAR(T3.FECHACAM), 5, 2) || '/'|| SUBSTRING(CHAR(T3.FECHACAM),3, 2) || '/' || '20' || SUBSTRING(CHAR(T3.FECHACAM),1, 2),'S/C') AS FECHAUC,\n"); // FECHACAM Campo de la que cambio de precio - costo
                //Remplaza a la línea de arriba, OCG
                sql.Append("   IFNULL(MMNETLIB.FORMATFECH(T3.FECHACAM),'S/C') FECHAUC, ");

                sql.Append("		      0 NOEVENTOSCST, 0 NOEVENTOSPRC, 0 NOEVENTOS, '' ESTATUS, '' TEMP\n");
                sql.Append("		  FROM MMNETLIB.SAT702F T1 INNER JOIN \n");
                sql.Append("			         (\n");
                sql.Append("				        SELECT DISTINCT FECHACAM, PROCAM, ESTCAM,\n");
                sql.Append("			                    CASE WHEN COSTOCAM > 0 THEN COSTOCAM ELSE (SELECT DISTINCT CSTAMT FROM MM610LIB.CSTPLN WHERE CSTCDT IN \n");
                sql.Append("			                                   (SELECT MAX(CSTCDT) FROM MM610LIB.CSTPLN WHERE CSTCDT <= T3.FECHACAM AND CSTVND = T3.PROCAM AND CSTSTY = T3.ESTCAM AND CSTSTR = 0 AND CSTITM = 0)\n");
                sql.Append("			                                           AND CSTVND = T3.PROCAM AND CSTSTY = T3.ESTCAM  AND CSTSTR = 0 AND CSTITM = 0) END AS COSTOCAM,\n");
                sql.Append("			                    CASE WHEN PRECAM > 0 THEN PRECAM ELSE (SELECT DISTINCT PLNAMT FROM MM610LIB.PRCPLN WHERE PLNCDT IN \n");
                sql.Append("			                                   (SELECT MAX(PLNCDT) FROM MM610LIB.PRCPLN WHERE PLNCDT <= T3.FECHACAM AND PLNVND = T3.PROCAM AND PLNSTY = T3.ESTCAM AND PLNSTR = 0 AND PLNITM = 0) \n");
                sql.Append("			                                   AND PLNVND = T3.PROCAM AND PLNSTY = T3.ESTCAM AND PLNSTR = 0 AND PLNITM = 0) END AS PRECAM\n");
                sql.Append("			                FROM\n");
                sql.Append("					            (\n");
                sql.Append("							      SELECT CSTCDT AS FECHACAM, CSTVND AS PROCAM, CSTSTY AS ESTCAM, CSTAMT AS COSTOCAM, 0 PRECAM\n");
                sql.AppendFormat("							          FROM MM610LIB.CSTPLN WHERE CSTSTR = 0 AND CSTITM = 0 AND CSTVND = '{0}' AND CSTSTY = '{1}' \n", idProv, idStilo);
                sql.Append("							        UNION ALL\n");
                sql.Append("							        SELECT PLNCDT AS FECHACAM, PLNVND AS PROCAM, PLNSTY AS ESTCAM, 0 AS COSTOCAM, PLNAMT AS PRECAM\n");
                sql.AppendFormat("							          FROM MM610LIB.PRCPLN WHERE PLNSTR = 0 AND PLNITM = 0 AND PLNVND = '{0}' AND PLNSTY = '{1}' \n", idProv, idStilo);
                sql.Append("							     )T3 \n");
                sql.Append("			            	GROUP BY FECHACAM , PROCAM, ESTCAM, COSTOCAM, PRECAM  \n");
                sql.Append("				     )T3 ON T1.SASNUM = T3.PROCAM AND T1.SSTYLQ = T3.ESTCAM \n"); // No Eventos en cambios a Precios y costos
                sql.AppendFormat("		 WHERE T3.FECHACAM > 99999  AND T1.SASFOLIO = {0} \n", folio);
                if (provNue != string.Empty && estilNue != string.Empty)
                {
                    sql.Append("UNION ALL \n");   //// Tabla de Historicos con otros estilos
                    sql.Append("  SELECT\n");
                    sql.AppendFormat("		  '{0}' AS FOLIO, \n", folio);               // Campo de # de folio
                    sql.Append("			  T1.SASNUM AS IDPROV, \n");                 // Campo de # de preveedor
                    sql.Append("			  '' AS PROVEEDOR,      \n");                // Campo de nombre de preveedor
                    sql.Append("			  T1.SSTYLQ AS IDESTILO, \n");               // Campo de # de estilo
                    sql.Append("			  '' AS ESTILO,        \n");                 // Campo de nombre de estilo
                    sql.Append("		      0 ONHAND, 0 CSTOR ,0 PRCOR, 0 MAROR,\n");
                    sql.Append("		      IFNULL(COALESCE(T3.COSTOCAM, 0),0) AS CSTAC, \n");        // Campo de costo CAMBIO PARA UNIOS CONVERTIDO A actual
                    sql.Append("		      IFNULL(COALESCE(T3.PRECAM, 0),0) AS PRCAC,  \n");         // Campo de precio CAMBIO PARA UNIOS CONVERTIDO A actual
                    sql.Append("		      CAST((1-(IFNULL(T3.COSTOCAM, 0) * 1.16) / IFNULL(T3.PRECAM, 0)) * 100 AS DECIMAL(18,2)) AS MARAC,\n");  // Campo de margen CAMBIO PARA UNIOS CONVERTIDO A actual
                    sql.Append("		      0 CSTNU, 0 PRCNU, 0 MARNU, 0 INCRULT, 0 INCRORI,\n");
                    sql.Append("		      IFNULL(SUBSTRING(CHAR(T3.FECHACAM), 5, 2) || '/'|| SUBSTRING(CHAR(T3.FECHACAM),3, 2) || '/' || '20' || SUBSTRING(CHAR(T3.FECHACAM),1, 2),'S/C') AS FECHAUC,\n"); // FECHACAM Campo de la que cambio de precio - costo
                    sql.Append("		      0 NOEVENTOSCST, 0 NOEVENTOSPRC, 0 NOEVENTOS, '' ESTATUS, '' TEMP\n");
                    sql.Append("		  FROM MMNETLIB.SAT702F T1 INNER JOIN \n");
                    sql.Append("			         (\n");
                    sql.Append("				        SELECT DISTINCT FECHACAM, PROCAM, ESTCAM,\n");
                    sql.Append("			                    CASE WHEN COSTOCAM > 0 THEN COSTOCAM ELSE (SELECT DISTINCT CSTAMT FROM MM610LIB.CSTPLN WHERE CSTCDT IN \n");
                    sql.Append("			                                   (SELECT MAX(CSTCDT) FROM MM610LIB.CSTPLN WHERE CSTCDT <= T3.FECHACAM AND CSTVND = T3.PROCAM AND CSTSTY = T3.ESTCAM AND CSTSTR = 0 AND CSTITM = 0)\n");
                    sql.Append("			                                           AND CSTVND = T3.PROCAM AND CSTSTY = T3.ESTCAM  AND CSTSTR = 0 AND CSTITM = 0) END AS COSTOCAM,\n");
                    sql.Append("			                    CASE WHEN PRECAM > 0 THEN PRECAM ELSE (SELECT DISTINCT PLNAMT FROM MM610LIB.PRCPLN WHERE PLNCDT IN \n");
                    sql.Append("			                                   (SELECT MAX(PLNCDT) FROM MM610LIB.PRCPLN WHERE PLNCDT <= T3.FECHACAM AND PLNVND = T3.PROCAM AND PLNSTY = T3.ESTCAM AND PLNSTR = 0 AND PLNITM = 0) \n");
                    sql.Append("			                                   AND PLNVND = T3.PROCAM AND PLNSTY = T3.ESTCAM AND PLNSTR = 0 AND PLNITM = 0) END AS PRECAM\n");
                    sql.Append("			                FROM\n");
                    sql.Append("					            (\n");
                    sql.Append("							      SELECT CSTCDT AS FECHACAM, CSTVND AS PROCAM, CSTSTY AS ESTCAM, CSTAMT AS COSTOCAM, 0 PRECAM\n");
                    sql.AppendFormat("							          FROM MM610LIB.CSTPLN WHERE CSTSTR = 0 AND CSTITM = 0 AND CSTVND = '{0}' AND CSTSTY IN ({1})   \n", provNue, estilNue);
                    sql.Append("							        UNION ALL\n");
                    sql.Append("							        SELECT PLNCDT AS FECHACAM, PLNVND AS PROCAM, PLNSTY AS ESTCAM, 0 AS COSTOCAM, PLNAMT AS PRECAM\n");
                    sql.AppendFormat("							          FROM MM610LIB.PRCPLN WHERE PLNSTR = 0 AND PLNITM = 0 AND PLNVND = '{0}' AND PLNSTY IN ({1}) \n", provNue, estilNue);
                    sql.Append("							     )T3 \n");
                    sql.Append("			            	GROUP BY FECHACAM , PROCAM, ESTCAM, COSTOCAM, PRECAM  \n");
                    sql.Append("				     )T3 ON T1.SASNUM = T3.PROCAM AND T1.SSTYLQ = T3.ESTCAM \n"); // No Eventos en cambios a Precios y costos
                    
                    
                     
                    sql.AppendFormat("		 WHERE T1.SASNUM = {0} AND T1.SSTYLQ IN ({1})\n", provNue, estilNue);
                    
                }
                sql.Append("	) D \n");
                sql.AppendFormat("	WHERE YEAR(DATE(TIMESTAMP_FORMAT(FECHAUC, 'DD-MM-YYYY'))) BETWEEN {0} AND {1} \n", fecha.Year - 2, fecha.Year);
                sql.Append(" 	ORDER BY DATE(TIMESTAMP_FORMAT(FECHAUC, 'DD-MM-YYYY')) DESC ");
                db2Conn = new OleDbConnection(Db2_Prod);
                db2Conn.Open();

                OleDbCommand db2Comm = new OleDbCommand(sql.ToString(), db2Conn);
                db2Comm.CommandType = CommandType.Text;

                OleDbDataAdapter daDb2 = new OleDbDataAdapter(db2Comm);

                daDb2.Fill(dtDetalleFolios);

                return dtDetalleFolios;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region " Verifica si existe el folio en reporte "
        public static void existeFolio(string folio)
        {
            StringBuilder sql = new StringBuilder();
            try
            {
                sql.Clear();
                sql.AppendFormat("DELETE FROM MMNETLIB.SAT177RPCCP WHERE FOLIO = '{0}' ", folio);

                using (OleDbConnection connection = new OleDbConnection(Db2_Prod))
                {
                    OleDbCommand command = new OleDbCommand(sql.ToString(), connection);

                    connection.Open();

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion
    }
}