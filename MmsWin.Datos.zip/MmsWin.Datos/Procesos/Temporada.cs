﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;
using Data.Common.SQL;
using System.Data.Common;
using System.Data.SqlClient;
using Data.Common.Ole;


namespace MmsWin.Datos.Procesos
{
    public class Temporada
    {

        #region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
        #endregion

        public static void GuardaTemporada(MmsWin.Entidades.Temporada temp, string usuario)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("INSERT INTO  PASO.SAT177f40 \n");
                sql.AppendFormat("(MTEANO, MTEMAR, MTEPRV, MTEPRN, MTESTY, MTEDES, MTEDP, MTESD, MTECS, MTESC, MTETMP, MTEDCP,  MTEFCHA, MTEHORA, MTEUSR,MTEORI) \n");
                sql.Append("VALUES\n");
                sql.AppendFormat("({0},{1},{2}, \n", DateTime.Now.ToString("yy"), temp.Marca, temp.Id_Proveedor);
                sql.AppendFormat("'{0}','{1}','{2}', \n", temp.Proveedor, temp.Id_Estilo, temp.Estilo);
                sql.AppendFormat("{0},{1},{2},{3}, \n", temp.Id_Departamento, temp.Id_Subdepartamento, temp.Id_Clase, temp.Id_SubClase);
                sql.AppendFormat("'{0}','{1}',\n", temp.CodTemporada.ToUpper(), temp.Comprador);
                sql.AppendFormat("{0},121212, '{1}','{2}' )\n", DateTime.Now.ToString("yyMMdd"), usuario, temp.Origen.ToUpper());

                try
                {
                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    if (!e.Message.Contains("clave duplicada")) { throw new Exception(e.Message); }
                }
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void GuardaTemporadas(MmsWin.Entidades.Temporada temp, string usuario)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                //sql.Append("DELETE FROM   " + LibSatObj + ".SAT177f40 \n");

                //db2Comm.CommandText = sql.ToString();
                //db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("INSERT INTO PASO.SAT177f40 \n");
                sql.Append("(MTEANO, MTEMAR, MTEPRV, MTEPRN,\n");
                sql.Append("MTESTY, MTEDES, \n");
                sql.Append("MTEDP, MTESD, MTECS, MTESC, \n");
                sql.Append("MTETMP, MTEDCP, \n");
                sql.Append("MTEFIT,MTEFFT, MTEFCA, \n");
                sql.Append("MTEFCHA, MTEHORA, MTEUSR,MTEORI)\n");
                sql.Append("SELECT 16,CASE WHEN  SCORGP = '' THEN 0 ELSE COALESCE(SCORGP, 0) END marca,\n");
                sql.Append("COALESCE(SASNUM, '0') prov ,SUBSTRING ( COALESCE(ASNAME,'SIN ASIGNAR') ,0 , 30 ) proveedor  ,\n");
                sql.Append("COALESCE(SSTYLQ,'') SSTYLQ, COALESCE(SSTYLE,'')SSTYLE,\n");
                sql.Append("SDEPT, SSDEPT, SCLAS, SSCLAS, \n");
                sql.Append("SSEASN,COALESCE(SBUYER, '0') comprador,\n");
                sql.Append("'160601','160801','161225',\n");
                sql.Append("'161207','121212','" + usuario + "','NAC'\n");
                sql.Append("FROM " + LibSatObj + ".INSMST M\n");
                sql.Append("LEFT JOIN MM610LIB.APSUPP  P ON M.SASNUM = P.ASNUM\n");
                sql.Append("WHERE SSEASN IN ('INV','NAV')\n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }


        public static DataTable ObtenTemporada(int marca, string comprador, string temporada, string origen,
            int id_prov = 0, string prov = "", string id_estilo = "", string estilo = "", int depto = 0, int subdepto = 0, int clase = 0, int subclase = 0)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConvenio = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT MTEMAR MARCA, MTEPRV ID_PROV, MTEPRN PROVEEDOR, MTESTY ID_ESTILO, MTEDES ESTILO, MTEDP DEPTO,\n");
                sql.Append("MTESD SUBDEPTO, MTECS CLASE, MTESC SUBCLASE, MTETMP TEMPORADA, MTEORI ORIGEN, MTEDCP COMPRADOR  \n");
                sql.Append("  FROM  mmsatobj.SAT177f40 \n");
                sql.AppendFormat("WHERE  MTEANO= {0} \n", DateTime.Now.ToString("yy"));

                if (marca != 0)
                    sql.AppendFormat("AND MTEMAR= {0} \n", marca);

                if (!comprador.Contains("999"))
                    sql.AppendFormat("AND MTEDCP= {0} \n", comprador);

                if (!string.IsNullOrEmpty(temporada))
                    sql.AppendFormat("AND MTETMP= {0} \n", temporada);

                if (!string.IsNullOrEmpty(origen))
                    sql.AppendFormat("AND MTEORI= {0} \n", origen);

                if (id_prov != 0)
                    sql.AppendFormat("AND MTEPRV= {0} \n", id_prov);

                if (prov != string.Empty)
                    sql.AppendFormat("AND MTEPRN like '%{0}%' \n", prov);

                if (id_estilo != string.Empty)
                    sql.AppendFormat("AND MTESTY like '%{0}%' \n", id_estilo);

                if (estilo != string.Empty)
                    sql.AppendFormat("AND MTEDES like '%{0}%' \n", estilo);

                if (depto != 0)
                    sql.AppendFormat("AND MTEDP= {0} \n", depto);

                if (subdepto != 0)
                    sql.AppendFormat("AND MTESD= {0} \n", subdepto);

                if (clase != 0)
                    sql.AppendFormat("AND MTECS= {0} \n", clase);

                if (subclase != 0)
                    sql.AppendFormat("AND MTESC= {0} \n", subclase);

                db2Comm.CommandText = sql.ToString();

                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtConvenio = new DataTable("Convenio");
                dtConvenio.Load(db2Reader);
                db2Reader.Close();


                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtConvenio;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenEstilos(string marca, int depto, int subdepto, int clase, int subclase, int proveedor, string estilo, string temporada, string origen)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConvenio = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT  '" + origen + "' ORIGEN,'" + temporada + "' TEMPORADA , COALESCE(scorgp,'') marca, SSTYLQ ID_ESTILO, SSTYLE ESTILO, COALESCE(SASNUM,0) PROVEEDOR,P.NOMBRE PROV,COALESCE(SDEPT,0) ID_DEPTO , DEPTO.NOMBRE DEPTO, \n");
                sql.Append("COALESCE(SSDEPT,0) ID_SUBDEPTO,SUBDEPTO.NOMBRE SUBDEPTO, COALESCE(SCLAS,0) ID_CLASE ,CLASE.NOMBRE CLASE , COALESCE(SSCLAS,0) ID_SUBCLASE, SUBCLASE.NOMBRE SUBCLASE ,COALESCE(p.id_comprador,0) id_comprador\n");
                sql.Append("FROM MM610LIB.INSMST M \n");
                sql.Append("LEFT JOIN \n");
                sql.Append("(\n");
                sql.Append("SELECT IDEPT DEPTO,ISDEPT SUBDEPTO, ICLAS CLASE, ISCLAS SUBCLASE,  DPTNAM NOMBRE\n");
                sql.Append("FROM MM610LIB.INVDPT\n");
                sql.Append("WHERE IDEPT > 0 \n");
                sql.Append("AND ISDEPT = 0\n");
                sql.Append("AND ICLAS = 0\n");
                sql.Append("AND ISCLAS = 0\n");
                sql.Append(")DEPTO ON M.SDEPT = DEPTO.DEPTO \n");
                sql.Append("LEFT JOIN \n");
                sql.Append("(\n");
                sql.Append("SELECT IDEPT DEPTO,ISDEPT SUBDEPTO, ICLAS CLASE, ISCLAS SUBCLASE,  DPTNAM NOMBRE\n");
                sql.Append("FROM MM610LIB.INVDPT\n");
                sql.Append("WHERE IDEPT > 0 \n");
                sql.Append("AND ISDEPT > 0\n");
                sql.Append("AND ICLAS = 0\n");
                sql.Append("AND ISCLAS = 0\n");
                sql.Append(")SUBDEPTO ON M.SDEPT = SUBDEPTO.DEPTO \n");
                sql.Append("AND M.SSDEPT = SUBDEPTO.SUBDEPTO\n");
                sql.Append("LEFT JOIN \n");
                sql.Append("(\n");
                sql.Append("SELECT IDEPT DEPTO,ISDEPT SUBDEPTO, ICLAS CLASE, ISCLAS SUBCLASE,  DPTNAM NOMBRE\n");
                sql.Append("FROM MM610LIB.INVDPT\n");
                sql.Append("WHERE IDEPT > 0 \n");
                sql.Append("AND ISDEPT > 0\n");
                sql.Append("AND ICLAS > 0\n");
                sql.Append("AND ISCLAS = 0\n");
                sql.Append(")CLASE ON M.SDEPT = CLASE.DEPTO \n");
                sql.Append("AND M.SSDEPT = CLASE.SUBDEPTO\n");
                sql.Append("AND M.SCLAS = CLASE.CLASE\n");
                sql.Append("LEFT JOIN \n");
                sql.Append("(\n");
                sql.Append("SELECT IDEPT DEPTO,ISDEPT SUBDEPTO, ICLAS CLASE, ISCLAS SUBCLASE,  DPTNAM NOMBRE\n");
                sql.Append("FROM MM610LIB.INVDPT\n");
                sql.Append("WHERE IDEPT > 0 \n");
                sql.Append("AND ISDEPT > 0\n");
                sql.Append("AND ICLAS > 0\n");
                sql.Append("AND ISCLAS > 0\n");
                sql.Append(")SUBCLASE ON M.SDEPT = SUBCLASE.DEPTO \n");
                sql.Append("AND M.SSDEPT = SUBCLASE.SUBDEPTO\n");
                sql.Append("AND M.SCLAS = SUBCLASE.CLASE\n");
                sql.Append("AND M.SSCLAS = SUBCLASE.SUBCLASE\n");
                sql.Append("LEFT JOIN (SELECT ASNUM , ASNAME NOMBRE,asbuyr id_comprador\n");
                sql.Append("FROM MM610LIB.APSUPP )P	ON M.SASNUM =P.ASNUM 	  \n");

                sql.AppendFormat("WHERE  SSTYLQ <> '' \n");

                if (marca != "999")
                    sql.AppendFormat("AND  scorgp= '{0}' \n", marca);

                if (depto != 0)
                    sql.AppendFormat("AND SDEPT= {0} \n", depto);

                if (subdepto != 0)
                    sql.AppendFormat("AND SSDEPT= {0} \n", subdepto);

                if (clase != 0)
                    sql.AppendFormat("AND SCLAS= {0} \n", clase);

                if (subclase != 0)
                    sql.AppendFormat("AND SSCLAS= {0} \n", subclase);

                if (proveedor != 0)
                    sql.AppendFormat("AND SASNUM= {0} \n", proveedor);

                if (estilo != string.Empty)
                    sql.AppendFormat("AND SSTYLQ= '{0}' \n", estilo);

                db2Comm.CommandText = sql.ToString();

                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtConvenio = new DataTable("Convenio");
                dtConvenio.Load(db2Reader);
                db2Reader.Close();


                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtConvenio;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void EliminaTemporada(int marca, int id_prov, string id_estilo)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("DELETE  FROM PASO.SAT177f40 \n");
                sql.AppendFormat("WHERE MTEMAR= {0} \n", marca);
                sql.AppendFormat("AND MTEPRV= {0} \n", id_prov);
                sql.AppendFormat("AND MTESTY like '%{0}%' \n", id_estilo);

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        //Base de datos Prepedidos
        public static DataTable ObtenHeaderTemporadas(short cadena)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConvenio = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT JERANIO ANIO, JERMAR MARCA, JERIDT ID, JERSEA TEMPORADA,\n");
                sql.Append("JERFAL BLACK_OUT_DATE,JERFAL FECHA_FIN, JERFAL FECHA_CALIFICACION, JERFAL FECHA_RECIBO , JERFAL FECHA_RECIBO_FIN\n");
                sql.Append(" FROM mmsatobj.SAT177F46\n");

                db2Comm.CommandText = sql.ToString();

                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtConvenio = new DataTable("Convenio");
                dtConvenio.Load(db2Reader);
                db2Reader.Close();


                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtConvenio;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }



        public static void AgregaHeaderTemporadas(int anio, int marca, int id, string temp, string fec_black, string fec_black_fin, string fecha_cal, string fec_rec, string fec_rec_fin)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.AppendFormat("  INSERT INTO [tblackoutdate] WHERE ANIO = {0} \n", anio);

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }


        public static DataTable ObtenDetalleTemporadas(short cadena, int temp, int anio)
        {
            string cadenaConexionDb2 = Db2_Prod;
            StringBuilder sql = new StringBuilder();
            DataTable dtConvenio = new DataTable("Prepedido");
            OleDbConnection db2Conn = null;
            try
            {
                sql.Append("SELECT jeranio anio, jermar marca,jeridt id, \n");
                sql.Append("jerdp departamento,jersd subdepartamento, jercl clase, jersc subclase\n");
                sql.Append(" FROM mmsatobj.SAT177F45\n");
                sql.AppendFormat("WHERE jeridt = {0} AND jermar = {1} AND jeranio = {2} \n", temp, cadena, anio);

                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                db2Comm.CommandText = sql.ToString();

                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtConvenio = new DataTable("Convenio");
                dtConvenio.Load(db2Reader);
                db2Reader.Close();


                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtConvenio;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static void EliminaJerarquia_Black(int marca, int depto, int subdepto, int clase, int subclase, int temporada, int anio)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.AppendFormat("  DELETE FROM mmsatobj.SAT177F45  WHERE jeranio = {0} \n", anio);
                sql.AppendFormat("   AND jermar = {0} \n", marca);
                sql.AppendFormat("   AND jeridt = {0} \n", temporada);
                sql.AppendFormat("   and jerdp = {0} \n", depto);
                sql.AppendFormat("   and jersd = {0}\n", subdepto);
                sql.AppendFormat("   and jercl = {0}\n", clase);
                sql.AppendFormat("   and jersc = {0}\n", subclase);

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static bool ValidaJerarquia(int marca, int depto, int subdepto, int clase, int subclase)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            bool existe = false;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append(" SELECT count(*) existe\n");
                sql.Append(" FROM mm610lib.insmst\n");
                sql.AppendFormat("  WHERE SDEPT = {0} AND SSDEPT = {1} AND SCLAS= {2} AND SSCLAS = {3} AND SCORGP = {4}\n", depto, subdepto, clase, subclase, marca);

                db2Comm.CommandText = sql.ToString();

                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                while (db2Reader.Read())
                {
                    if (db2Reader.GetInt32(0) > 0)
                    {
                        existe = true;
                    }
                }

                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return existe;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void InsertaJerarquia_Black(int marca, int depto, int subdepto, int clase, int subclase, int temporada, int anio)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("INSERT INTO mmsatobj.SAT177F45\n");
                sql.Append("(jeranio, jermar, JERIDT, JERDP,JERSD,JERCL,JERSC,JERSTS)\n");
                sql.Append(" VALUES\n");
                sql.AppendFormat("  ({0}\n", DateTime.Now.ToString("yy"));
                sql.AppendFormat("  ,{0}\n", marca);
                sql.AppendFormat("  ,{0}\n", temporada);
                sql.AppendFormat("  ,{0}\n", depto);
                sql.AppendFormat("  ,{0}\n", subdepto);
                sql.AppendFormat("  ,{0}\n", clase);
                sql.AppendFormat("  ,{0}\n", subclase);
                sql.AppendFormat("  ,'A')\n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable CalificaTemporada(int marca, string temporada, string fecha_inial, string fecha_final, int tabla)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtConvenio = new DataTable();
            string querySQL = string.Empty;
            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                if (tabla == 3)
                    sql.AppendFormat(" SELECT  * FROM  TABLE(MMNETLIB.fnCalifica_rentabilidad_tt(30,161226,170101,170206,170212,1) )X order by prov, estilo", marca, temporada, fecha_inial, fecha_final, tabla);
                else if (tabla == 30)
                    sql.AppendFormat(" SELECT  * FROM  TABLE(MMNETLIB.fnCalifica({0},'{1}',{2},{3},{4}) )X", marca, temporada, fecha_inial, fecha_final, tabla);

                //sql.AppendFormat("SELECT  * FROM  TABLE(MMNETLIB.fnCalifica(30,'INV',160101,161225,30) )X");
                using (DBHelperOleDB DB = new DBHelperOleDB("cnnIseries", true))
                // using (DBHelperPSQL DB = new DBHelperPSQL("cnnCGI"))
                {
                    using (System.Data.IDataReader dr = DB.EjecutaReader(sql.ToString(), null))
                    {
                        dtConvenio.Load(dr);
                        dr.Close();
                    }
                }

                return dtConvenio;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

    }
}
