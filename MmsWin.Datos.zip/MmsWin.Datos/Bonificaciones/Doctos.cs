﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Bonificaciones
{
    public class Doctos
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static DataTable ObtenDoctos(string marca, string comprador, string FchDe, string FchHas, string ParProveedor, string PartbNombre, string PartbEstilo, string ParDescripcion)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtDoctos = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                if (marca == "[999, Todas]")
                {
                    marca = "999";
                }

                sql.Append("SELECT * FROM\n");
                sql.Append(" " + LibSatObj + ".SAT177F30\n");

                if (FchDe != "")
                {
                    sql.AppendFormat(" WHERE NOTBON BETWEEN " + "'" + "{0}" + "'" + "\n", FchDe);
                    sql.AppendFormat(" AND " + "'" + "{0}" + "'" + "\n", FchHas);

                    if (marca     != "999") { sql.AppendFormat(" and NOTNMR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0')); }
                    if (comprador != "999") { sql.AppendFormat(" and NOTCOM IN " + "(" + "{0}" + ")" + "\n", comprador); }

                    if (ParProveedor   != "") { sql.AppendFormat(" and NOTPRV = "    + "'"  + "{0}" + "'"  + "\n", ParProveedor); }
                    if (PartbNombre    != "") { sql.AppendFormat(" and NOTPRN LIKE " + "'%" + "{0}" + "%'" + "\n", PartbNombre); }
                    if (PartbEstilo    != "") { sql.AppendFormat(" and NOTSTY = "    + "'"  + "{0}" + "'"  + "\n", PartbEstilo); }
                    if (ParDescripcion != "") { sql.AppendFormat(" and NOTDES LIKE " + "'%" + "{0}" + "%'" + "\n", ParDescripcion); }
                }

                sql.Append(" ORDER BY NOTCAL, NOTPRV, NOTSTY  ASC\n"); 

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtDoctos = new DataTable("Doctos");
                dtDoctos.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtDoctos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void EliminaDocumento(string ParFchBon, string ParFchRev, string ParProveedor, string ParEstilo, string ParNota)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("DELETE FROM " + LibSatObj + ".SAT177F30 WHERE\n");
                sql.Append(" NOTBON = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParFchBon.PadLeft(6, '0'));
                sql.Append(" AND NOTFRE = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParFchRev.PadLeft(6, '0'));
                sql.Append(" AND NOTPRV = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParProveedor.PadLeft(6, '0'));
                sql.Append(" AND NOTSTY = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParEstilo.PadRight(15, ' '));
                sql.Append(" AND NOTNOT = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParNota.PadRight(10, ' '));

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch
            {  }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void EjecutaCargaPDF(string ParFchBon, string ParFchCal, string ParNota, string ParPrv, string ParSty, string ParDest, string ParTpo, string ParUser  )
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R35 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchBon.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParFchCal.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParNota.PadRight(20, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParPrv.PadLeft(6, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParSty.PadRight(15, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParDest.PadRight(100, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParTpo.PadLeft(1, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParUser.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

    }
}
