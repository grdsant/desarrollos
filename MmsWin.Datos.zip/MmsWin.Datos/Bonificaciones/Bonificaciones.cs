﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Bonificaciones
{
    public class Bonificaciones
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
        public static string ambiente  = ConfigurationManager.AppSettings["AMBIENTE"].ToString();
#endregion

        public static DataTable ObtenBonifica(string marca, string comprador, String FchDe, String FchHas, string ParProveedor, string PartbNombre, string PartbEstilo, string ParDescripcion)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtBonifica = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT  \n");

                sql.Append("BONFBO, \n");   //00 Fecha Bonifica
                sql.Append("BONPRV,  \n");  //01 Proveedor
                sql.Append("BONPRN,  \n");  //02 Nombre
                sql.Append("BONSTY,  \n");  //03 Estilo
                sql.Append("BONDES,  \n");  //04 Descripcion
                sql.Append("BONDCP,  \n");  //05 Comprador
                sql.Append("BONFCM,  \n");  //06 Fecha Compra
                sql.Append("BONFRE,  \n");  //07 Fecha Revision
                sql.Append("BONPZA,  \n");  //08 Piezas
                sql.Append("BONVTA,  \n");  //09 Venta
                sql.Append("BONONH,  \n");  //10 OnHand
                sql.Append("BONPVT,  \n");  //11 % Ventas
                sql.Append("BONCAL,  \n");  //12 Calificacion
                sql.Append("BONTAB,  \n");  //13 Tabla de Accion
                sql.Append("BONNOT,  \n");  //14 Nota Credito
                sql.Append("BONSUB,  \n");  //15 Sub_Tot
                sql.Append("BONIVA,  \n");  //16 Iva 
                sql.Append("BONTOT,  \n");  //17 Total
                sql.Append("BONPBO,  \n");  //18 % Bonificacion
                sql.Append("BONCST,  \n");  //19 Costo Actual
                sql.Append("BONPRC,  \n");  //20 Precio Actual
                sql.Append("BONMRG,  \n");  //21 Margen Actual
                sql.Append("BONCST1, \n");  //22 Costo Nuevo
                sql.Append("BONPRC1, \n");  //23 Precio Nuevo
                sql.Append("BONMRG1, \n");  //24 Margen Nuevo
                sql.Append("BONCST2, \n");  //25 Costo Final
                sql.Append("BONPRC2, \n");  //26 Precio Final
                sql.Append("BONMRG2, \n");  //27 Margen Final 
                sql.Append("BONCMP,  \n");  //28 Compras Obs 
                sql.Append("BONTAB2, \n");  //29 Tabla de Accion 2 
                sql.Append("BONCSTD, \n");  //30 Diferecia Consto  
                sql.Append("BONPZA1, \n");  //31 Piezas On Hand
                sql.Append("BONIMP1, \n");  //32 Importe'On Hand 
                sql.Append("BONPRO,  \n");  //33 Promocion

                sql.Append("BONDCF2, \n");  //34//30 Dif Cst Final  
                sql.Append("BONIDC2, \n");  //35//31 Imp OH Dif Cst
                sql.Append("BONIMF2, \n");  //36//32 Imp Mrg Final

                sql.Append("BONTABF, \n");  //37//34 Tabla de Accion Final  
                sql.Append("BONMAR,  \n");  //38//35 Marca
                sql.Append("BONCID,  \n");  //39//36 Comprador
                sql.Append("BONBDG,  \n");  //40//37 Bodega
                sql.Append("BONCK1,  \n");  //41//38 Compras
                sql.Append("BONCK2,  \n");  //42//39 Contraloria
                sql.Append("BONNMR,  \n");  //43//40 Marca
                sql.Append("BONFCHA, \n");  //44//41 Fecha 
                sql.Append("BONHORA, \n");  //45//42 Hora
                sql.Append("BONUSR,  \n");  //46//43 Usuario
                sql.Append("BONERR,  \n");  //47//44 Error
                sql.Append("BONCLF,  \n");  //48//45 Correo Electronico
                sql.Append("BONCXO,  \n");  //49//46 Cal x Omision
                sql.Append("BONIDE,  \n");  //50//47 Ident. Estilos
                sql.Append("BONRCS,  \n");  //51//48 Rebaja Costos 
                sql.Append("BONRPR,  \n");  //52//49 Rebaja Precios
                sql.Append("BONDEV,  \n");  //53//50 Devoluciones
                sql.Append("BONCFA,  \n");  //54//51 Carga Facturas
                sql.Append("BONPOL,  \n");  //55//52 Poliza Contable
                sql.Append("BONCK3,  \n");  //56//53 Sts Correo
                sql.Append("BONCK4,  \n");  //57//54 Sts Cal x Omi
                sql.Append("BONCK5,  \n");  //58//55 Sts Ident
                sql.Append("BONCK6,  \n");  //59//56 Sts  Costos
                sql.Append("BONCK7,  \n");  //60//57 Sts Precios
                sql.Append("BONCK8,  \n");  //61//58 Sts Dev
                sql.Append("BONCK9,  \n");  //62//59 Sts Facturas
                sql.Append("BONCK10, \n");  //63//60 Sts Poliza
                sql.Append("BONNCS   \n");  //64//61 Nc PDF 
                sql.Append(" FROM    \n");  //

                sql.Append(" " + LibSatObj + ".SAT177F20 \n");

                if (FchDe != "")
                {
                    sql.AppendFormat(" WHERE BONFBO BETWEEN " + "'" + "{0}" + "'" + "\n", FchDe);
                    sql.AppendFormat(" AND " + "'" + "{0}" + "'" + "\n", FchHas);

                    if (marca     != "999") { sql.AppendFormat(" and BONNMR = " + "'" + "{0}" + "'" + "\n", marca.PadLeft(3, '0')); }
                    if (comprador != "999") { sql.AppendFormat(" and BONCID IN " + "(" + "{0}" + ")" + "\n", comprador.PadRight (3, ' ')); }

                    if (ParProveedor   != "") { sql.AppendFormat(" and BONPRV = " + "'" + "{0}" + "'" + "\n", ParProveedor); }
                    if (PartbNombre    != "") { sql.AppendFormat(" and BONPRN LIKE " + "'%" + "{0}" + "%'" + "\n", PartbNombre); }
                    if (PartbEstilo    != "") { sql.AppendFormat(" and BONSTY = " + "'" + "{0}" + "'" + "\n", PartbEstilo); }
                    if (ParDescripcion != "") { sql.AppendFormat(" and BONDES LIKE " + "'%" + "{0}" + "%'" + "\n", ParDescripcion); }
                }

                sql.Append(" ORDER BY BONCAL, BONPRV, BONSTY  ASC\n"); // Ordenado por Proveedor

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtBonifica = new DataTable("Bonificaciones");
                dtBonifica.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            return dtBonifica;
        }

        public static DataTable UpdateBonificaciones(DataTable dtBonificaciones)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                foreach (DataRow row in dtBonificaciones.Rows)
                {
                    string FechaBon  = row["FechaBon"].ToString();
                    string FechaRev  = row["FechaRev"].ToString();
                    string Proveedor = row["Proveedor"].ToString();
                    string Estilo    = row["Estilo"].ToString();

                    string NotaCred      = row["NotaCred"].ToString();
                    string SubTotal      = row["SubTotal"].ToString();
                    string Iva           = row["Iva"].ToString();
                    string Total         = row["Total"].ToString();
                    string PorcBon       = row["PorcBon"].ToString();
                    string CostoAct      = row["CostoAct"].ToString();
                    string PrecioAct     = row["PrecioAct"].ToString();
                    string MargenAct     = row["MargenAct"].ToString();
                    string CostoNuev     = row["CostoNuev"].ToString();
                    string PrecioNuev    = row["PrecioNuev"].ToString();
                    string MargenNuev    = row["MargenNuev"].ToString();
                    string CostiFinal    = row["CostiFinal"].ToString();
                    string PrecioFinal   = row["PrecioFinal"].ToString();
                    string MargenFinal   = row["MargenFinal"].ToString();
                    string Observaciones = row["Observaciones"].ToString();
                    string TablaAccion2  = row["TablaAccion2"].ToString();
                    string TablaAccion   = row["TablaAccion"].ToString();
                    string Compras       = row["Compras"].ToString();
                    string Contraloria   = row["Contraloria"].ToString();
                    string DifCostoFinal = row["DifCostoFinal"].ToString();
                    string ImporteOnHand = row["ImporteOnHand"].ToString();
                    string ImporteMargen = row["ImporteMargen"].ToString();

                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT177F20 SET \n");
                    sql.AppendFormat("BONNOT  = " + "'" + "{0}" + "'" + "," + "\n", NotaCred.PadRight(20, ' '));
                    sql.AppendFormat("BONSUB  = " + "'" + "{0}" + "'" + "," + "\n", SubTotal.PadLeft(13, ' '));
                    sql.AppendFormat("BONIVA  = " + "'" + "{0}" + "'" + "," + "\n", Iva.PadLeft(11, ' '));
                    sql.AppendFormat("BONTOT  = " + "'" + "{0}" + "'" + "," + "\n", Total.PadLeft(13, ' '));
                    sql.AppendFormat("BONPBO  = " + "'" + "{0}" + "'" + "," + "\n", PorcBon.PadLeft(9, ' '));
                    sql.AppendFormat("BONCST  = " + "'" + "{0}" + "'" + "," + "\n", CostoAct.PadLeft(13, ' '));
                    sql.AppendFormat("BONPRC  = " + "'" + "{0}" + "'" + "," + "\n", PrecioAct.PadLeft(13, ' '));
                    sql.AppendFormat("BONMRG  = " + "'" + "{0}" + "'" + "," + "\n", MargenAct.PadLeft(13, ' '));
                    sql.AppendFormat("BONCST1 = " + "'" + "{0}" + "'" + "," + "\n", CostoNuev.PadLeft(13, ' '));
                    sql.AppendFormat("BONPRC1 = " + "'" + "{0}" + "'" + "," + "\n", PrecioNuev.PadLeft(13, ' '));
                    sql.AppendFormat("BONMRG1 = " + "'" + "{0}" + "'" + "," + "\n", MargenNuev.PadLeft(13, ' '));

                    sql.AppendFormat("BONCST2 = " + "'" + "{0}" + "'" + "," + "\n", CostiFinal.PadLeft(13, ' '));
                    sql.AppendFormat("BONPRC2 = " + "'" + "{0}" + "'" + "," + "\n", PrecioFinal.PadRight(13, ' '));

                    try
                    {
                        double margen, costo, precio;
                        margen = 0; costo = 0; precio = 0;
                        costo = Convert.ToDouble(CostiFinal);
                        precio = Convert.ToDouble(PrecioFinal);
                        if (costo != 0 && precio != 0)
                        {
                            margen = (1 - (costo / (precio / 1.16))) * 100;
                            MargenFinal = Convert.ToString(margen);
                        }
                    }
                    catch { }

                    sql.AppendFormat("BONMRG2 = " + "'" + "{0}" + "'" + "," + "\n", MargenFinal.PadRight(13, ' '));

                    sql.AppendFormat("BONCMP  = " + "'" + "{0}" + "'" + "," + "\n", Observaciones.PadRight(150, ' '));
                    sql.AppendFormat("BONTAB2 = " + "'" + "{0}" + "'" + "," + "\n", TablaAccion2.PadRight(2, ' '));
                    sql.AppendFormat("BONTABF = " + "'" + "{0}" + "'" + "," + "\n", TablaAccion.PadRight(2, ' '));
                    sql.AppendFormat("BONCK1  = " + "'" + "{0}" + "'" + "," + "\n", Compras.PadLeft(1, '0'));
                    sql.AppendFormat("BONCK2  = " + "'" + "{0}" + "'" + "," + "\n", Contraloria.PadLeft(1, '0'));

                    sql.AppendFormat("BONDCF2 = " + "'" + "{0}" + "'" + "," + "\n", DifCostoFinal.PadLeft(13, ' '));
                    sql.AppendFormat("BONIDC2 = " + "'" + "{0}" + "'" + "," + "\n", ImporteOnHand.PadLeft(13, ' '));
                    sql.AppendFormat("BONIMF2 = " + "'" + "{0}" + "'" + "\n", ImporteMargen.PadLeft(13, ' '));



                    sql.Append("WHERE \n");
                    sql.AppendFormat("BONFBO = " + "'" + "{0}" + "'" + "\n", FechaBon.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("BONFRE = " + "'" + "{0}" + "'" + "\n", FechaRev.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("BONPRV = " + "'" + "{0}" + "'" + "\n", Proveedor.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("BONSTY = " + "'" + "{0}" + "'" + "\n", Estilo.PadRight(15, ' '));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();
                }
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtBonificaciones;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable UpdateCheckBox(DataTable dtCheckBox)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                foreach (DataRow row in dtCheckBox.Rows)
                {
                    string FechaBon = row["FechaBon"].ToString();
                    string FechaRev = row["FechaRev"].ToString();
                    string Proveedor = row["Proveedor"].ToString();
                    string Estilo = row["Estilo"].ToString();

                    string Correo = row["Correo"].ToString();
                    string Cor1 = row["Cor1"].ToString();
                    string CalxOmi = row["CalxOmi"].ToString();
                    string Cal1 = row["Cal1"].ToString();
                    string Identif = row["Identif"].ToString();
                    string Ide1 = row["Ide1"].ToString();
                    string Costo = row["Costo"].ToString();
                    string Cos1 = row["Cos1"].ToString();
                    string Precio = row["Precio"].ToString();
                    string Pre1 = row["Pre1"].ToString();
                    string Devolucion = row["Devolucion"].ToString();
                    string Dev1 = row["Dev1"].ToString();
                    string FactEmit = row["FactEmit"].ToString();
                    string Fac1 = row["Fac1"].ToString();
                    string Poliza1 = row["Poliza1"].ToString();
                    string Pol1 = row["Pol1"].ToString();

                    string stCorreo = row["stCorreo"].ToString();
                    string stCor1 = row["stCor1"].ToString();
                    string stCalxOmi = row["stCalxOmi"].ToString();
                    string stCal1 = row["stCal1"].ToString();
                    string stIdentif = row["stIdentif"].ToString();
                    string stIde1 = row["stIde1"].ToString();
                    string stCosto = row["stCosto"].ToString();
                    string stCos1 = row["stCos1"].ToString();
                    string stPrecio = row["stPrecio"].ToString();
                    string stPre1 = row["stPre1"].ToString();
                    string stDevolucion = row["stDevolucion"].ToString();
                    string stDev1 = row["stDev1"].ToString();
                    string stFactEmit = row["stFactEmit"].ToString();
                    string stFac1 = row["stFac1"].ToString();
                    string stPoliza1 = row["stPoliza1"].ToString();
                    string stPol1 = row["stPol1"].ToString();

                    string Compras = row["Compras"].ToString();
                    string Com1 = row["Com1"].ToString();
                    string Contraloria = row["Contraloria"].ToString();
                    string Con1 = row["Con1"].ToString();

                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT177F20 SET \n");

                    Int32 segundo = 0;
                    if (Cor1 == "1") { sql.AppendFormat("BONCLF = " + "'" + "{0}" + "'" + "\n", Correo.PadLeft(1, '0')); }
                    if (Cor1 == "1") { segundo++; } if (Cal1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Cal1 == "1") { sql.AppendFormat("BONCXO = " + "'" + "{0}" + "'" + "\n", CalxOmi.PadLeft(1, '0')); }
                    if (Cal1 == "1") { segundo++; } if (Ide1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Ide1 == "1") { sql.AppendFormat("BONIDE = " + "'" + "{0}" + "'" + "\n", Identif.PadLeft(1, '0')); }
                    if (Ide1 == "1") { segundo++; } if (Cos1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Cos1 == "1") { sql.AppendFormat("BONRCS = " + "'" + "{0}" + "'" + "\n", Costo.PadLeft(1, '0')); }
                    if (Cos1 == "1") { segundo++; } if (Pre1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Pre1 == "1") { sql.AppendFormat("BONRPR = " + "'" + "{0}" + "'" + "\n", Precio.PadLeft(1, '0')); }
                    if (Pre1 == "1") { segundo++; } if (Dev1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Dev1 == "1") { sql.AppendFormat("BONDEV = " + "'" + "{0}" + "'" + "\n", Devolucion.PadLeft(1, '0')); }
                    if (Dev1 == "1") { segundo++; } if (Fac1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Fac1 == "1") { sql.AppendFormat("BONCFA = " + "'" + "{0}" + "'" + "\n", FactEmit.PadLeft(1, '0')); }
                    if (Fac1 == "1") { segundo++; } if (Pol1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Pol1 == "1") { sql.AppendFormat("BONPOL = " + "'" + "{0}" + "'" + "\n", Poliza1.PadLeft(1, '0')); }
                    if (Pol1 == "1") { segundo++; } if (stCor1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
                    if (stCor1 == "1") { sql.AppendFormat("BONCK3 = " + "'" + "{0}" + "'" + "\n", stCorreo.PadLeft(1, '0')); }
                    if (stCor1 == "1") { segundo++; } if (stCal1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (stCal1 == "1") { sql.AppendFormat("BONCK4 = " + "'" + "{0}" + "'" + "\n", stCalxOmi.PadLeft(1, '0')); }
                    if (stCal1 == "1") { segundo++; } if (stIde1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (stIde1 == "1") { sql.AppendFormat("BONCK5 = " + "'" + "{0}" + "'" + "\n", stIdentif.PadLeft(1, '0')); }
                    if (stIde1 == "1") { segundo++; } if (stCos1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (stCos1 == "1") { sql.AppendFormat("BONCK6 = " + "'" + "{0}" + "'" + "\n", stCosto.PadLeft(1, '0')); }
                    if (stCos1 == "1") { segundo++; } if (stPre1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (stPre1 == "1") { sql.AppendFormat("BONCK7 = " + "'" + "{0}" + "'" + "\n", stPrecio.PadLeft(1, '0')); }
                    if (stPre1 == "1") { segundo++; } if (stDev1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (stDev1 == "1") { sql.AppendFormat("BONCK8 = " + "'" + "{0}" + "'" + "\n", stDevolucion.PadLeft(1, '0')); }
                    if (stDev1 == "1") { segundo++; } if (stFac1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (stFac1 == "1") { sql.AppendFormat("BONCK9 = " + "'" + "{0}" + "'" + "\n", stFactEmit.PadLeft(1, '0')); }
                    if (stFac1 == "1") { segundo++; } if (stPol1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (stPol1 == "1") { sql.AppendFormat("BONCK10 = " + "'" + "{0}" + "'" + "\n", stPoliza1.PadLeft(1, '0')); }
                    if (stPol1 == "1") { segundo++; } if (Com1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }

                    if (Com1 == "1") { sql.AppendFormat("BONCK1 = " + "'" + "{0}" + "'" + "\n", Compras.PadLeft(1, '0')); }
                    if (Com1 == "1") { segundo++; } if (Con1 == "1" && segundo > 0) { sql.AppendFormat("," + "\n"); }
                    if (Con1 == "1") { sql.AppendFormat("BONCK2 = " + "'" + "{0}" + "'" + "\n", Contraloria.PadLeft(1, '0')); }

                    sql.Append("WHERE \n");
                    sql.AppendFormat("BONFBO = " + "'" + "{0}" + "'" + "\n", FechaBon.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("BONFRE = " + "'" + "{0}" + "'" + "\n", FechaRev.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("BONPRV = " + "'" + "{0}" + "'" + "\n", Proveedor.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("BONSTY = " + "'" + "{0}" + "'" + "\n", Estilo.PadRight(15, ' '));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();
                }
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtCheckBox;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static void EliminaBonificaciones(string ParFchBon, string ParFchRev, string ParProveedor, string ParEstilo)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();
            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("DELETE FROM " + LibSatObj + ".SAT177F20 WHERE\n");
                sql.Append(" BONFBO = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParFchBon.PadLeft(6, '0'));
                sql.Append(" AND BONFRE = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParFchRev.PadLeft(6, '0'));
                sql.Append(" AND BONPRV = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParProveedor.PadLeft(6, '0'));
                sql.Append(" AND BONSTY = \n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParEstilo.PadRight(15, ' '));

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

            }
            catch
            { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenRutaPDF(String ParFchBon, String ParFchCal, String ParPrv, String ParSty, String ParNota)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtRutaPDF = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Append("SELECT NOTRUT FROM  " + LibSatObj + ".SAT177F30 \n");

                sql.AppendFormat(" WHERE NOTBON = " + "'" + "{0}" + "'" + "\n", ParFchBon.PadLeft(6, '0'));
                sql.AppendFormat(" and NOTFRE = " + "'" + "{0}" + "'" + "\n", ParFchCal.PadLeft(6, '0'));
                sql.AppendFormat(" and NOTPRV = " + "'" + "{0}" + "'" + "\n", ParPrv.PadLeft(6, '0'));
                sql.AppendFormat(" and NOTSTY = " + "'" + "{0}" + "'" + "\n", ParSty.PadRight(15, ' ')); ;
                if (ParNota != "Mas de 1")
                {
                    sql.AppendFormat(" and NOTNOT = " + "'" + "{0}" + "'" + "\n", ParNota.PadRight(20, ' '));
                }
                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtRutaPDF = new DataTable("Bonificaciones");
                dtRutaPDF.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            return dtRutaPDF;
        }

        public static void EjecutaRecalculo(string ParFchBon)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                
                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177R50 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParFchBon.PadLeft(6, '0'));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable UpdateFechaAmover(DataTable dtMoverFecha, string FchAmover)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                foreach (DataRow row in dtMoverFecha.Rows)
                {
                    string FechaBon    = row["FechaBon"].ToString();
                    string FechaRev    = row["FechaRev"].ToString();
                    string Proveedor   = row["Proveedor"].ToString();
                    string Estilo      = row["Estilo"].ToString();

                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT177F20 SET \n");
                    sql.AppendFormat("BONFBO = " + "'" + "{0}" + "'" + "\n", FchAmover.PadLeft(6, '0'));
                    sql.Append("WHERE \n");
                    sql.AppendFormat("BONFBO = " + "'" + "{0}" + "'" + "\n", FechaBon.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("BONFRE = " + "'" + "{0}" + "'" + "\n", FechaRev.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("BONPRV = " + "'" + "{0}" + "'" + "\n", Proveedor.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("BONSTY = " + "'" + "{0}" + "'" + "\n", Estilo.PadRight(15, ' '));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();

                    sql.Clear();
                    sql.Append("UPDATE " + LibSatObj + ".SAT177F30 SET \n");
                    sql.AppendFormat("NOTBON = " + "'" + "{0}" + "'" + "\n", FchAmover.PadLeft(6, '0'));
                    sql.Append("WHERE \n");
                    sql.AppendFormat("NOTBON = " + "'" + "{0}" + "'" + "\n", FechaBon.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("NOTFRE = " + "'" + "{0}" + "'" + "\n", FechaRev.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("NOTPRV = " + "'" + "{0}" + "'" + "\n", Proveedor.PadLeft(6, '0'));
                    sql.Append("AND \n");
                    sql.AppendFormat("NOTSTY = " + "'" + "{0}" + "'" + "\n", Estilo.PadRight(15, ' '));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();
                }
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtMoverFecha;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

    }
}
