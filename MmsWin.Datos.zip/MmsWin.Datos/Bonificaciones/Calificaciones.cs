﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;

namespace MmsWin.Datos.Bonificaciones
{
    public class Calificaciones
    {

#region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
#endregion

        public static DataTable ObtenCalificaciones(String marca, String comprador, String FchDe, String FchHas, String ParPendiente, string ParProveedor, string PartbNombre, string PartbEstilo, string ParDescripcion, String User)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtBonifica = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                if (marca == "[999, Todas]")
                {
                    marca = "999";
                }
                sql.Append("CALL " + LibSatPgm + ".SAT177R21 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", marca.PadLeft(3, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", comprador.PadRight(3,' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", FchDe);
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", FchHas);
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParPendiente);
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParProveedor.PadLeft(6,'0'));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", PartbNombre.PadRight(30,' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", PartbEstilo.PadRight(15,' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", ParDescripcion.PadRight(30, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", User.PadRight(10, ' '));
                sql.Append(")");
                
                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT * FROM\n");
                sql.Append("" + LibSatObj + ".SAT177F21\n");
                sql.Append(" ORDER BY CSTFRV, CSTPRV, CSTSTY  ASC\n"); // Ordenado por Proveedor

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtBonifica = new DataTable("Calificaciones");
                dtBonifica.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtBonifica;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
