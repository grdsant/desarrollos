﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MmsWin.Front.Convenio;
using MmsWin.Front.Procesos;
using MmsWin.Front.Bonificaciones;
using MmsWin.Front.Seguridad;
using MmsWin.Front.Configuracion;
using MmsWin.Front.ConvenioMelody;
using MmsWin.Front.CalificacionAllocation;



namespace MmsWin.Admin
{
    public partial class WinAero : Form
    {
        Point mousedownpoint = Point.Empty;

        string ParUser;

        private PictureBox ptbConvenio;
        private PictureBox pbDoctos;
        private PictureBox pbSeguridad;
        private PictureBox ptbProcesos;
        private Label      lblConvenio;
        private Label      lblProcesos;
        private Label      lblDoctos;
        private PictureBox pbBonificaciones;
        private Label      lblBonificaciones;
        private Label      lblTablasdeRentabilidad;
        private PictureBox pbConfiguracion;
        private Label      lblConfiguracion;
        private Label lblSeguridad;
        private PictureBox pbConvenioMelody;
        private Label      lbConvenioMelody;
        private PictureBox pbxFormatos;
        private Label      lblFormatos;
        private ContextMenuStrip     cmsFormatos;
        private ToolStripMenuItem    smiAmpliacion;
        private ToolStripMenuItem    smiFillRate;
        private IContainer           components;
        private ToolStripMenuItem    mnuCambioPrecio;
        private PictureBox           pgbMasivoTemporadas;
        private Label                lblMasivoTemporadas;
        private ContextMenuStrip     cmsCatalogos;
        private ToolStripMenuItem    smiProveedores;
        private ToolStripMenuItem smiConfiguracion;
        private Label lbAmbiente;
        private Panel panel1;
        private PictureBox pbSalir;
        private Label lbTitulo;
        private Label lbFooter;
        private Label lblCargaMasiva;
        private PictureBox pbCargaMasiva;
        private PictureBox pbCxP;
        private Label lbCxP;
        private PictureBox           pbTblRentabilidad;

        public WinAero()
        {
            InitializeComponent();
        }
        [StructLayout(LayoutKind.Sequential)]
        public struct Margins
        {
            public int derecha;
            public int izquierda;
            public int superior;
            public int inferior;
        }

        [DllImport("dwmapi.dll")]
        public static extern int DwmExtendFrameIntoClientArea(IntPtr hWnd, ref Margins margs);

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WinAero));
            this.lblConvenio = new System.Windows.Forms.Label();
            this.lblProcesos = new System.Windows.Forms.Label();
            this.lblDoctos = new System.Windows.Forms.Label();
            this.lblBonificaciones = new System.Windows.Forms.Label();
            this.lblTablasdeRentabilidad = new System.Windows.Forms.Label();
            this.lblConfiguracion = new System.Windows.Forms.Label();
            this.lblSeguridad = new System.Windows.Forms.Label();
            this.lbConvenioMelody = new System.Windows.Forms.Label();
            this.lblFormatos = new System.Windows.Forms.Label();
            this.cmsFormatos = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.smiAmpliacion = new System.Windows.Forms.ToolStripMenuItem();
            this.smiFillRate = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCambioPrecio = new System.Windows.Forms.ToolStripMenuItem();
            this.lblMasivoTemporadas = new System.Windows.Forms.Label();
            this.cmsCatalogos = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.smiProveedores = new System.Windows.Forms.ToolStripMenuItem();
            this.smiConfiguracion = new System.Windows.Forms.ToolStripMenuItem();
            this.pgbMasivoTemporadas = new System.Windows.Forms.PictureBox();
            this.pbxFormatos = new System.Windows.Forms.PictureBox();
            this.pbConvenioMelody = new System.Windows.Forms.PictureBox();
            this.pbConfiguracion = new System.Windows.Forms.PictureBox();
            this.pbTblRentabilidad = new System.Windows.Forms.PictureBox();
            this.pbBonificaciones = new System.Windows.Forms.PictureBox();
            this.ptbProcesos = new System.Windows.Forms.PictureBox();
            this.pbSeguridad = new System.Windows.Forms.PictureBox();
            this.pbDoctos = new System.Windows.Forms.PictureBox();
            this.ptbConvenio = new System.Windows.Forms.PictureBox();
            this.lbAmbiente = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbCxP = new System.Windows.Forms.Label();
            this.pbCxP = new System.Windows.Forms.PictureBox();
            this.lblCargaMasiva = new System.Windows.Forms.Label();
            this.pbCargaMasiva = new System.Windows.Forms.PictureBox();
            this.pbSalir = new System.Windows.Forms.PictureBox();
            this.lbTitulo = new System.Windows.Forms.Label();
            this.lbFooter = new System.Windows.Forms.Label();
            this.cmsFormatos.SuspendLayout();
            this.cmsCatalogos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pgbMasivoTemporadas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxFormatos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbConvenioMelody)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbConfiguracion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTblRentabilidad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBonificaciones)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbProcesos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSeguridad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDoctos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbConvenio)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCxP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCargaMasiva)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).BeginInit();
            this.SuspendLayout();
            // 
            // lblConvenio
            // 
            this.lblConvenio.AutoSize = true;
            this.lblConvenio.BackColor = System.Drawing.Color.Silver;
            this.lblConvenio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConvenio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblConvenio.Location = new System.Drawing.Point(27, 189);
            this.lblConvenio.Name = "lblConvenio";
            this.lblConvenio.Size = new System.Drawing.Size(86, 13);
            this.lblConvenio.TabIndex = 7;
            this.lblConvenio.Text = "Calificaciones";
            // 
            // lblProcesos
            // 
            this.lblProcesos.AutoSize = true;
            this.lblProcesos.BackColor = System.Drawing.Color.Silver;
            this.lblProcesos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProcesos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblProcesos.Location = new System.Drawing.Point(778, 188);
            this.lblProcesos.Name = "lblProcesos";
            this.lblProcesos.Size = new System.Drawing.Size(59, 13);
            this.lblProcesos.TabIndex = 8;
            this.lblProcesos.Text = "Procesos";
            // 
            // lblDoctos
            // 
            this.lblDoctos.AutoSize = true;
            this.lblDoctos.BackColor = System.Drawing.Color.Silver;
            this.lblDoctos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDoctos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblDoctos.Location = new System.Drawing.Point(315, 189);
            this.lblDoctos.Name = "lblDoctos";
            this.lblDoctos.Size = new System.Drawing.Size(98, 13);
            this.lblDoctos.TabIndex = 10;
            this.lblDoctos.Text = "Documentos NC";
            // 
            // lblBonificaciones
            // 
            this.lblBonificaciones.AutoSize = true;
            this.lblBonificaciones.BackColor = System.Drawing.Color.Silver;
            this.lblBonificaciones.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBonificaciones.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblBonificaciones.Location = new System.Drawing.Point(170, 189);
            this.lblBonificaciones.Name = "lblBonificaciones";
            this.lblBonificaciones.Size = new System.Drawing.Size(90, 13);
            this.lblBonificaciones.TabIndex = 14;
            this.lblBonificaciones.Text = "Bonificaciones";
            // 
            // lblTablasdeRentabilidad
            // 
            this.lblTablasdeRentabilidad.AutoSize = true;
            this.lblTablasdeRentabilidad.BackColor = System.Drawing.Color.Silver;
            this.lblTablasdeRentabilidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTablasdeRentabilidad.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblTablasdeRentabilidad.Location = new System.Drawing.Point(439, 189);
            this.lblTablasdeRentabilidad.Name = "lblTablasdeRentabilidad";
            this.lblTablasdeRentabilidad.Size = new System.Drawing.Size(138, 13);
            this.lblTablasdeRentabilidad.TabIndex = 15;
            this.lblTablasdeRentabilidad.Text = "Tablas de Rentabilidad";
            // 
            // lblConfiguracion
            // 
            this.lblConfiguracion.AutoSize = true;
            this.lblConfiguracion.BackColor = System.Drawing.Color.Silver;
            this.lblConfiguracion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfiguracion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblConfiguracion.Location = new System.Drawing.Point(619, 189);
            this.lblConfiguracion.Name = "lblConfiguracion";
            this.lblConfiguracion.Size = new System.Drawing.Size(85, 13);
            this.lblConfiguracion.TabIndex = 18;
            this.lblConfiguracion.Text = "Configuración";
            // 
            // lblSeguridad
            // 
            this.lblSeguridad.AutoSize = true;
            this.lblSeguridad.BackColor = System.Drawing.Color.Silver;
            this.lblSeguridad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSeguridad.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblSeguridad.Location = new System.Drawing.Point(923, 188);
            this.lblSeguridad.Name = "lblSeguridad";
            this.lblSeguridad.Size = new System.Drawing.Size(64, 13);
            this.lblSeguridad.TabIndex = 19;
            this.lblSeguridad.Text = "Seguridad";
            // 
            // lbConvenioMelody
            // 
            this.lbConvenioMelody.AutoSize = true;
            this.lbConvenioMelody.BackColor = System.Drawing.Color.Silver;
            this.lbConvenioMelody.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbConvenioMelody.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbConvenioMelody.Location = new System.Drawing.Point(0, 356);
            this.lbConvenioMelody.Name = "lbConvenioMelody";
            this.lbConvenioMelody.Size = new System.Drawing.Size(136, 13);
            this.lbConvenioMelody.TabIndex = 23;
            this.lbConvenioMelody.Text = "Convenio Diferenciado";
            // 
            // lblFormatos
            // 
            this.lblFormatos.AutoSize = true;
            this.lblFormatos.BackColor = System.Drawing.Color.Silver;
            this.lblFormatos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFormatos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblFormatos.Location = new System.Drawing.Point(181, 356);
            this.lblFormatos.Name = "lblFormatos";
            this.lblFormatos.Size = new System.Drawing.Size(62, 13);
            this.lblFormatos.TabIndex = 25;
            this.lblFormatos.Text = "Formatos ";
            // 
            // cmsFormatos
            // 
            this.cmsFormatos.BackColor = System.Drawing.Color.LightSteelBlue;
            this.cmsFormatos.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smiAmpliacion,
            this.smiFillRate,
            this.mnuCambioPrecio});
            this.cmsFormatos.Name = "cmsFormatos";
            this.cmsFormatos.Size = new System.Drawing.Size(339, 70);
            // 
            // smiAmpliacion
            // 
            this.smiAmpliacion.Name = "smiAmpliacion";
            this.smiAmpliacion.Size = new System.Drawing.Size(338, 22);
            this.smiAmpliacion.Text = "Formato de ampliación entrega Orden de Compra";
            this.smiAmpliacion.Click += new System.EventHandler(this.MenuItems_Click);
            // 
            // smiFillRate
            // 
            this.smiFillRate.Name = "smiFillRate";
            this.smiFillRate.Size = new System.Drawing.Size(338, 22);
            this.smiFillRate.Text = "Formato de excepción de cobro Fill-Rate";
            this.smiFillRate.Visible = false;
            this.smiFillRate.Click += new System.EventHandler(this.MenuItems_Click);
            // 
            // mnuCambioPrecio
            // 
            this.mnuCambioPrecio.Name = "mnuCambioPrecio";
            this.mnuCambioPrecio.Size = new System.Drawing.Size(338, 22);
            this.mnuCambioPrecio.Text = "Formato de cambio de precio y costo";
            this.mnuCambioPrecio.Click += new System.EventHandler(this.mnuCambioPrecio_Click);
            // 
            // lblMasivoTemporadas
            // 
            this.lblMasivoTemporadas.AutoSize = true;
            this.lblMasivoTemporadas.BackColor = System.Drawing.Color.Silver;
            this.lblMasivoTemporadas.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMasivoTemporadas.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblMasivoTemporadas.Location = new System.Drawing.Point(299, 356);
            this.lblMasivoTemporadas.Name = "lblMasivoTemporadas";
            this.lblMasivoTemporadas.Size = new System.Drawing.Size(120, 13);
            this.lblMasivoTemporadas.TabIndex = 27;
            this.lblMasivoTemporadas.Text = "Masivo Temporadas";
            // 
            // cmsCatalogos
            // 
            this.cmsCatalogos.BackColor = System.Drawing.Color.LightSteelBlue;
            this.cmsCatalogos.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.smiProveedores,
            this.smiConfiguracion});
            this.cmsCatalogos.Name = "cmsFormatos";
            this.cmsCatalogos.Size = new System.Drawing.Size(196, 48);
            this.cmsCatalogos.Click += new System.EventHandler(this.MenuItems_Click);
            // 
            // smiProveedores
            // 
            this.smiProveedores.Name = "smiProveedores";
            this.smiProveedores.Size = new System.Drawing.Size(195, 22);
            this.smiProveedores.Text = "Tipo de proveedores";
            this.smiProveedores.Click += new System.EventHandler(this.MenuItems_Click);
            // 
            // smiConfiguracion
            // 
            this.smiConfiguracion.Name = "smiConfiguracion";
            this.smiConfiguracion.Size = new System.Drawing.Size(195, 22);
            this.smiConfiguracion.Text = "Configuración maestra";
            // 
            // pgbMasivoTemporadas
            // 
            this.pgbMasivoTemporadas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pgbMasivoTemporadas.ContextMenuStrip = this.cmsFormatos;
            this.pgbMasivoTemporadas.Enabled = false;
            this.pgbMasivoTemporadas.ErrorImage = ((System.Drawing.Image)(resources.GetObject("pgbMasivoTemporadas.ErrorImage")));
            this.pgbMasivoTemporadas.Image = ((System.Drawing.Image)(resources.GetObject("pgbMasivoTemporadas.Image")));
            this.pgbMasivoTemporadas.InitialImage = null;
            this.pgbMasivoTemporadas.Location = new System.Drawing.Point(294, 221);
            this.pgbMasivoTemporadas.Name = "pgbMasivoTemporadas";
            this.pgbMasivoTemporadas.Size = new System.Drawing.Size(138, 132);
            this.pgbMasivoTemporadas.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pgbMasivoTemporadas.TabIndex = 26;
            this.pgbMasivoTemporadas.TabStop = false;
            this.pgbMasivoTemporadas.Click += new System.EventHandler(this.pgbMasivoTemporadas_Click);
            // 
            // pbxFormatos
            // 
            this.pbxFormatos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxFormatos.ContextMenuStrip = this.cmsFormatos;
            this.pbxFormatos.Enabled = false;
            this.pbxFormatos.Image = ((System.Drawing.Image)(resources.GetObject("pbxFormatos.Image")));
            this.pbxFormatos.InitialImage = null;
            this.pbxFormatos.Location = new System.Drawing.Point(146, 221);
            this.pbxFormatos.Name = "pbxFormatos";
            this.pbxFormatos.Size = new System.Drawing.Size(138, 132);
            this.pbxFormatos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxFormatos.TabIndex = 24;
            this.pbxFormatos.TabStop = false;
            // 
            // pbConvenioMelody
            // 
            this.pbConvenioMelody.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbConvenioMelody.Image = ((System.Drawing.Image)(resources.GetObject("pbConvenioMelody.Image")));
            this.pbConvenioMelody.InitialImage = null;
            this.pbConvenioMelody.Location = new System.Drawing.Point(2, 221);
            this.pbConvenioMelody.Name = "pbConvenioMelody";
            this.pbConvenioMelody.Size = new System.Drawing.Size(138, 132);
            this.pbConvenioMelody.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbConvenioMelody.TabIndex = 22;
            this.pbConvenioMelody.TabStop = false;
            this.pbConvenioMelody.Click += new System.EventHandler(this.pbConvenioMelody_Click);
            // 
            // pbConfiguracion
            // 
            this.pbConfiguracion.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbConfiguracion.ContextMenuStrip = this.cmsCatalogos;
            this.pbConfiguracion.Enabled = false;
            this.pbConfiguracion.Image = ((System.Drawing.Image)(resources.GetObject("pbConfiguracion.Image")));
            this.pbConfiguracion.InitialImage = null;
            this.pbConfiguracion.Location = new System.Drawing.Point(586, 54);
            this.pbConfiguracion.Name = "pbConfiguracion";
            this.pbConfiguracion.Size = new System.Drawing.Size(138, 132);
            this.pbConfiguracion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbConfiguracion.TabIndex = 17;
            this.pbConfiguracion.TabStop = false;
            this.pbConfiguracion.Click += new System.EventHandler(this.pbConfiguracion_Click);
            // 
            // pbTblRentabilidad
            // 
            this.pbTblRentabilidad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbTblRentabilidad.Enabled = false;
            this.pbTblRentabilidad.Image = ((System.Drawing.Image)(resources.GetObject("pbTblRentabilidad.Image")));
            this.pbTblRentabilidad.InitialImage = null;
            this.pbTblRentabilidad.Location = new System.Drawing.Point(440, 54);
            this.pbTblRentabilidad.Name = "pbTblRentabilidad";
            this.pbTblRentabilidad.Size = new System.Drawing.Size(138, 132);
            this.pbTblRentabilidad.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbTblRentabilidad.TabIndex = 16;
            this.pbTblRentabilidad.TabStop = false;
            this.pbTblRentabilidad.Click += new System.EventHandler(this.pbTblRentabilidad_Click);
            // 
            // pbBonificaciones
            // 
            this.pbBonificaciones.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbBonificaciones.Enabled = false;
            this.pbBonificaciones.Image = ((System.Drawing.Image)(resources.GetObject("pbBonificaciones.Image")));
            this.pbBonificaciones.InitialImage = null;
            this.pbBonificaciones.Location = new System.Drawing.Point(148, 54);
            this.pbBonificaciones.Name = "pbBonificaciones";
            this.pbBonificaciones.Size = new System.Drawing.Size(138, 132);
            this.pbBonificaciones.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbBonificaciones.TabIndex = 13;
            this.pbBonificaciones.TabStop = false;
            this.pbBonificaciones.Click += new System.EventHandler(this.pbBonificaciones_Click);
            // 
            // ptbProcesos
            // 
            this.ptbProcesos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ptbProcesos.Enabled = false;
            this.ptbProcesos.Image = ((System.Drawing.Image)(resources.GetObject("ptbProcesos.Image")));
            this.ptbProcesos.InitialImage = null;
            this.ptbProcesos.Location = new System.Drawing.Point(732, 54);
            this.ptbProcesos.Name = "ptbProcesos";
            this.ptbProcesos.Size = new System.Drawing.Size(138, 132);
            this.ptbProcesos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptbProcesos.TabIndex = 6;
            this.ptbProcesos.TabStop = false;
            this.ptbProcesos.Click += new System.EventHandler(this.ptbProcesos_Click);
            // 
            // pbSeguridad
            // 
            this.pbSeguridad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbSeguridad.Enabled = false;
            this.pbSeguridad.Image = ((System.Drawing.Image)(resources.GetObject("pbSeguridad.Image")));
            this.pbSeguridad.InitialImage = null;
            this.pbSeguridad.Location = new System.Drawing.Point(878, 54);
            this.pbSeguridad.Name = "pbSeguridad";
            this.pbSeguridad.Size = new System.Drawing.Size(138, 132);
            this.pbSeguridad.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSeguridad.TabIndex = 4;
            this.pbSeguridad.TabStop = false;
            this.pbSeguridad.Click += new System.EventHandler(this.pbSeguridad_Click);
            // 
            // pbDoctos
            // 
            this.pbDoctos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbDoctos.Enabled = false;
            this.pbDoctos.Image = ((System.Drawing.Image)(resources.GetObject("pbDoctos.Image")));
            this.pbDoctos.InitialImage = null;
            this.pbDoctos.Location = new System.Drawing.Point(294, 54);
            this.pbDoctos.Name = "pbDoctos";
            this.pbDoctos.Size = new System.Drawing.Size(138, 132);
            this.pbDoctos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbDoctos.TabIndex = 2;
            this.pbDoctos.TabStop = false;
            this.pbDoctos.Click += new System.EventHandler(this.pbDoctos_Click);
            // 
            // ptbConvenio
            // 
            this.ptbConvenio.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ptbConvenio.Enabled = false;
            this.ptbConvenio.Image = ((System.Drawing.Image)(resources.GetObject("ptbConvenio.Image")));
            this.ptbConvenio.InitialImage = null;
            this.ptbConvenio.Location = new System.Drawing.Point(2, 54);
            this.ptbConvenio.Name = "ptbConvenio";
            this.ptbConvenio.Size = new System.Drawing.Size(138, 132);
            this.ptbConvenio.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.ptbConvenio.TabIndex = 1;
            this.ptbConvenio.TabStop = false;
            this.ptbConvenio.Click += new System.EventHandler(this.ptbConvenio_Click);
            // 
            // lbAmbiente
            // 
            this.lbAmbiente.AutoSize = true;
            this.lbAmbiente.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbAmbiente.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAmbiente.ForeColor = System.Drawing.Color.LimeGreen;
            this.lbAmbiente.Location = new System.Drawing.Point(903, 389);
            this.lbAmbiente.Name = "lbAmbiente";
            this.lbAmbiente.Size = new System.Drawing.Size(85, 20);
            this.lbAmbiente.TabIndex = 29;
            this.lbAmbiente.Text = "Ambiente";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.Controls.Add(this.lbCxP);
            this.panel1.Controls.Add(this.lblCargaMasiva);
            this.panel1.Location = new System.Drawing.Point(0, 44);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1018, 342);
            this.panel1.TabIndex = 30;
            // 
            // lbCxP
            // 
            this.lbCxP.AutoSize = true;
            this.lbCxP.BackColor = System.Drawing.Color.Silver;
            this.lbCxP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbCxP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbCxP.Location = new System.Drawing.Point(604, 312);
            this.lbCxP.Name = "lbCxP";
            this.lbCxP.Size = new System.Drawing.Size(100, 13);
            this.lbCxP.TabIndex = 30;
            this.lbCxP.Text = "Cuentas x Pagar";
            // 
            // pbCxP
            // 
            this.pbCxP.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbCxP.Image = ((System.Drawing.Image)(resources.GetObject("pbCxP.Image")));
            this.pbCxP.InitialImage = null;
            this.pbCxP.Location = new System.Drawing.Point(586, 221);
            this.pbCxP.Name = "pbCxP";
            this.pbCxP.Size = new System.Drawing.Size(138, 132);
            this.pbCxP.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCxP.TabIndex = 29;
            this.pbCxP.TabStop = false;
            this.pbCxP.Click += new System.EventHandler(this.pbCxP_Click);
            // 
            // lblCargaMasiva
            // 
            this.lblCargaMasiva.AutoSize = true;
            this.lblCargaMasiva.BackColor = System.Drawing.Color.Silver;
            this.lblCargaMasiva.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCargaMasiva.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblCargaMasiva.Location = new System.Drawing.Point(465, 312);
            this.lblCargaMasiva.Name = "lblCargaMasiva";
            this.lblCargaMasiva.Size = new System.Drawing.Size(84, 13);
            this.lblCargaMasiva.TabIndex = 28;
            this.lblCargaMasiva.Text = "Carga Masiva";
            // 
            // pbCargaMasiva
            // 
            this.pbCargaMasiva.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbCargaMasiva.Image = ((System.Drawing.Image)(resources.GetObject("pbCargaMasiva.Image")));
            this.pbCargaMasiva.InitialImage = null;
            this.pbCargaMasiva.Location = new System.Drawing.Point(440, 221);
            this.pbCargaMasiva.Name = "pbCargaMasiva";
            this.pbCargaMasiva.Size = new System.Drawing.Size(138, 132);
            this.pbCargaMasiva.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbCargaMasiva.TabIndex = 23;
            this.pbCargaMasiva.TabStop = false;
            this.pbCargaMasiva.Click += new System.EventHandler(this.pbCargaMasiva_Click);
            // 
            // pbSalir
            // 
            this.pbSalir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.pbSalir.Image = ((System.Drawing.Image)(resources.GetObject("pbSalir.Image")));
            this.pbSalir.Location = new System.Drawing.Point(984, 9);
            this.pbSalir.Name = "pbSalir";
            this.pbSalir.Size = new System.Drawing.Size(28, 23);
            this.pbSalir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbSalir.TabIndex = 70;
            this.pbSalir.TabStop = false;
            this.pbSalir.Click += new System.EventHandler(this.pbSalir_Click);
            // 
            // lbTitulo
            // 
            this.lbTitulo.AutoSize = true;
            this.lbTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTitulo.ForeColor = System.Drawing.Color.Silver;
            this.lbTitulo.Location = new System.Drawing.Point(11, 12);
            this.lbTitulo.Name = "lbTitulo";
            this.lbTitulo.Size = new System.Drawing.Size(29, 16);
            this.lbTitulo.TabIndex = 71;
            this.lbTitulo.Text = "xxx";
            // 
            // lbFooter
            // 
            this.lbFooter.AutoSize = true;
            this.lbFooter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFooter.ForeColor = System.Drawing.Color.Silver;
            this.lbFooter.Location = new System.Drawing.Point(4, 389);
            this.lbFooter.Name = "lbFooter";
            this.lbFooter.Size = new System.Drawing.Size(425, 20);
            this.lbFooter.TabIndex = 72;
            this.lbFooter.Text = "Versión 10/07/2019 - 09:01:01  Rebaja Diferenciada";
            // 
            // WinAero
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(1020, 414);
            this.Controls.Add(this.pbCxP);
            this.Controls.Add(this.pgbMasivoTemporadas);
            this.Controls.Add(this.lbFooter);
            this.Controls.Add(this.lbTitulo);
            this.Controls.Add(this.pbCargaMasiva);
            this.Controls.Add(this.pbSalir);
            this.Controls.Add(this.lbAmbiente);
            this.Controls.Add(this.lblMasivoTemporadas);
            this.Controls.Add(this.lblFormatos);
            this.Controls.Add(this.pbxFormatos);
            this.Controls.Add(this.lbConvenioMelody);
            this.Controls.Add(this.pbConvenioMelody);
            this.Controls.Add(this.lblSeguridad);
            this.Controls.Add(this.lblConfiguracion);
            this.Controls.Add(this.pbConfiguracion);
            this.Controls.Add(this.pbTblRentabilidad);
            this.Controls.Add(this.lblTablasdeRentabilidad);
            this.Controls.Add(this.lblBonificaciones);
            this.Controls.Add(this.pbBonificaciones);
            this.Controls.Add(this.lblDoctos);
            this.Controls.Add(this.lblProcesos);
            this.Controls.Add(this.lblConvenio);
            this.Controls.Add(this.ptbProcesos);
            this.Controls.Add(this.pbSeguridad);
            this.Controls.Add(this.pbDoctos);
            this.Controls.Add(this.ptbConvenio);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "WinAero";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Convenio / Bonificaciones  Versión 1.0";
            this.TransparencyKey = System.Drawing.Color.Gray;
            this.HelpButtonClicked += new System.ComponentModel.CancelEventHandler(this.WinAero_HelpButtonClicked);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.WinAero_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.WinAero_FormClosed);
            this.Load += new System.EventHandler(this.WinAero_Load);
            this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.WinAero_HelpRequested);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.WinAero_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.WinAero_MouseMove);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.WinAero_MouseUp);
            this.cmsFormatos.ResumeLayout(false);
            this.cmsCatalogos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pgbMasivoTemporadas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxFormatos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbConvenioMelody)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbConfiguracion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbTblRentabilidad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBonificaciones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbProcesos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSeguridad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbDoctos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptbConvenio)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbCxP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCargaMasiva)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSalir)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void WinAero_Load(object sender, EventArgs e)
        {
            Point mousedownpoint = Point.Empty;

            lbAmbiente.Text = MmsWin.Admin.Login.ambiente;
            if (lbAmbiente.Text == "Producción")
            {
                lbAmbiente.ForeColor = Color.LimeGreen;
            }
            else
            {
                lbAmbiente.ForeColor = Color.Red;
            }


            // Seguridad();

            //BackColor = System.Drawing.Color.Black;
            Margins margenes = new Margins();
            margenes.derecha = -1;
            margenes.izquierda = -1;
            margenes.superior = -1;
            margenes.inferior = -1;
            IntPtr hwnd = this.Handle;
            int result = DwmExtendFrameIntoClientArea(hwnd, ref margenes);

            this.Text = "Convenio / Bonificaciones  Versión 1.0  /  " + MmsWin.Front.Utilerias.VarTem.tmpUSRNOM;
            lbTitulo.Text = "Convenio / Bonificaciones  Versión 1.0  /  " + MmsWin.Front.Utilerias.VarTem.tmpUSRNOM;
            // Seguridad...
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            Seguridad("Inicio", "Aplicaciones", ParUser);

            //this.pgbMasivoTemporadas.Enabled = true;

            
        }
        // Seguridad                                                                                
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable tbSeguridad = null;
            tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
            foreach (DataRow row in tbSeguridad.Rows)
            {
                string Controles = row["SEGCLS"].ToString();
                string ValHab = row["SEGHAC"].ToString();
                string ValVis = row["SEGVIC"].ToString();
                string tipo = row["SEGTIP"].ToString();

                AplicaSeguridad(Controles, ValHab, ValVis, tipo);
            }
        }
        // Aplica eguridad                                                                          
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }

            this.lblFormatos.Visible = true;
            this.pbxFormatos.Enabled = true;
        }

        private void ptbConvenio_Click(object sender, EventArgs e)
        {
            Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                          "Convenio").SingleOrDefault<Form>();
            {
                if (existe != null)
                {
                    MessageBox.Show("El Convenio esta abierto");
                }
                else
                {
                    MmsWin.Front.Convenio.Convenio i = new MmsWin.Front.Convenio.Convenio();
                    i.Show();
                }
            }
        }

        private void ptbProcesos_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Procesos").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana de Procesos esta abierta");
                    }
                    else
                    {
                        Procesos i = new Procesos();
                        i.Show();

                    }
                }
            }
            catch { }
            finally { }
        }

        private void lblUsuarios_Click(object sender, EventArgs e)
        {

        }

        private void pbDoctos_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Documentos").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de Docuentos esta abierta");
                    }
                    else
                    {
                        Doctos i = new Doctos();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbBonificaciones_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Bonificaciones").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de Bonificaciones esta abierta");
                    }
                    else
                    {
                        Bonificaciones i = new Bonificaciones();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbTblRentabilidad_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "TblHdrRent").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de Tablas de Rentabilidad esta abierta");
                    }
                    else
                    {
                        TblHdrRent i = new TblHdrRent();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void WinAero_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void WinAero_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Carga Seguridad    
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("Inicio", "Aplicaciones", ParUser);
            }

            Application.Exit();
        }

        private void ptbPerfiles_Click(object sender, EventArgs e)
        {
        }

        private void pbUsuarios_Click(object sender, EventArgs e)
        {

        }

        private void pbSeguridad_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "SegMain").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("La ventana de seguridad ya esta abierta");
                    }
                    else
                    {
                        SegMain i = new SegMain();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void pbConfiguracion_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Configuracion").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de configuracion esta abierta");
                    }
                    else
                    {
                        Configuracion i = new Configuracion();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }

        }

        private void WinAero_HelpButtonClicked(object sender, CancelEventArgs e)
        {
            MessageBox.Show("Ayuda");
        }

        private void WinAero_HelpRequested(object sender, HelpEventArgs hlpevent)
        {
            MessageBox.Show("Ayuda");
        }

        private void MenuItems_Click(object sender, EventArgs e)
        {
            #region smiAmpliacion

            if (sender == this.smiAmpliacion)
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "AmpliacionOrdenCompra").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de configuracion esta abierta");
                    }
                    else
                    {
                        Cursor.Current = Cursors.WaitCursor;

                        AmpliacionOC i = new AmpliacionOC();
                        i.ShowDialog(this);

                        Cursor.Current = Cursors.Default;
                    }
                }
            }

            #endregion

            #region smiFillRate

            if (sender == this.smiFillRate)
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "FillRate").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de configuracion esta abierta");
                    }
                    else
                    {
                        Cursor.Current = Cursors.WaitCursor;

                        FillRate i = new FillRate();
                        i.ShowDialog(this);

                        Cursor.Current = Cursors.Default;
                    }
                }
            }

            #endregion

            #region smiProveedores

            if (sender == this.smiProveedores)
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "ProveedoresTipo").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("El catálogo de tipode de proveedores ya esta abierto.");
                    }
                    else
                    {
                        Cursor.Current = Cursors.WaitCursor;

                        ProveedoresTipo i = new ProveedoresTipo();
                        i.ShowDialog(this);

                        Cursor.Current = Cursors.Default;
                    }
                }
            }

            #endregion

        }

        private void pgbMasivoTemporadas_Click(object sender, EventArgs e)
        {
            Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "AmpliacionOrdenCompra").SingleOrDefault<Form>();
            {
                if (existe != null)
                {
                    MessageBox.Show("Las ventana de configuracion esta abierta");
                }
                else
                {
                    MmsWin.Front.Procesos.CargaTemporada i = new MmsWin.Front.Procesos.CargaTemporada();
                    i.ShowDialog(this);
                }
            }
        }

        private void mnuCambioPrecio_Click(object sender, EventArgs e)
        {
            Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "CambioPrecio").SingleOrDefault<Form>();
            {
                if (existe != null)
                {
                    MessageBox.Show("Las ventana de configuracion esta abierta");
                }
                else
                {
                    Cursor.Current = Cursors.WaitCursor;

                    CambioPrecio i = new CambioPrecio();
                    i.ShowDialog(this);

                    Cursor.Current = Cursors.Default;
                }
            }
        }

        private void pbConvenioMelody_Click(object sender, EventArgs e)
        {
            Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "ConvenioMelodyMDI").SingleOrDefault<Form>();
            {
                if (existe != null)
                {
                    MessageBox.Show("Las ventana del Convenio Melody ya esta abierta");
                }
                else
                {
                    ConvenioMelodyMDI i = new ConvenioMelodyMDI();
                    //i.ShowDialog(this);
                    i.Show();
                }
            }
        }

        private void pbCalificaAllocation_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "CalAlloc").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana de Bonificaciones esta abierta");
                    }
                    else
                    {
                        CalAlloc i = new CalAlloc();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }

        private void pbSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void WinAero_MouseDown(object sender, MouseEventArgs e)
        {
            mousedownpoint = new Point(e.X, e.Y);
        }

        private void WinAero_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedownpoint.IsEmpty)
                return;
            Form f = sender as Form;
            f.Location = new Point(f.Location.X + (e.X - mousedownpoint.X), f.Location.Y + (e.Y - mousedownpoint.Y));
        }

        private void WinAero_MouseUp(object sender, MouseEventArgs e)
        {
            mousedownpoint = Point.Empty;
        }

        private void statusStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void pbCargaMasiva_Click(object sender, EventArgs e)
        {
            Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "ConvenioMelodyMDI").SingleOrDefault<Form>();
            {
                if (existe != null)
                {
                    MessageBox.Show("Las ventana del Convenio Melody ya esta abierta");
                }
                else
                {
                    //WpfCargaMasiva objeto = new WpfCargaMasiva();
                 

                }
            }
        }

        private void pbCxP_Click(object sender, EventArgs e)
        {
            try
            {
                Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "CxP").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("Las ventana Cuentas x Pagar esta abierta");
                    }
                    else
                    {
                        CxP i = new CxP();
                        i.Show();
                    }
                }
            }
            catch { }
            finally { }
        }


    }
}
