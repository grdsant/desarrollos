﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MmsWin.Admin
{
    public partial class Login : Form
    {
        #region Conexion
        public static string srv_Doctos = ConfigurationManager.ConnectionStrings["srvDoctos"].ToString();
        public static string Servidor = ConfigurationManager.ConnectionStrings["IPservidor"].ToString();
        #endregion

        public static string ParUser  { get; set; }
        public static string ParPass  { get; set; }
        public static string ambiente { get; set; }
        public static bool   noexiste { get; set; }

        public Login()
        {
            InitializeComponent();
        }

        private void tbUsuario_KeyPress(object sender, KeyPressEventArgs e)
        {

                if (e.KeyChar == (char)Keys.Enter)
                {
                    MmsWin.Front.Utilerias.VarTem.tmpUser = tbUsuario.Text;
                    if (tbUsuario.Text.Trim() != "")
                    {

                        // Seguridad... x las Columnas nuevas
                        ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
                        Seguridad("Login", "Login", ParUser);

                        if (tbUsuario.Text.Trim() == "")
                        {
                            MessageBox.Show("Digite el nombre de usuario.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }

                        if (this.tbPass.Text.Trim() == "")
                        {
                            if (MmsWin.Admin.Login.noexiste == true)
                            {
                                MessageBox.Show("Digite la contraseña.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                                tbPass.Focus();
                                return;
                            }
                        }

                        if (tbUsuario.Text != "")
                        {
                            GuardaVariables();
                            WinAeroWin();
                        }
                        else
                        {
                            MessageBox.Show("Digite el Nombre del usuario");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Digite el nombre de usuario.", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
        }

        private void tbPass_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (MmsWin.Negocio.Login.Login.GetInstance().ValidaVersion() == false)
                {
                    MessageBox.Show("La versión del 'Convenio' que esta ejecutando, no corresponde con la versión liberada actual", "CONVENIO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                if (tbUsuario.Text != "")
                {
                    GuardaVariables();
                    WinAeroWin();
                }
            }
        }

        private void GuardaVariables()
        {
            MmsWin.Front.Utilerias.VarTem.tmpUsrConv = "CALIFICA";
            MmsWin.Front.Utilerias.VarTem.simulador  = false;
            MmsWin.Front.Utilerias.VarTem.tmpUser = tbUsuario.Text;
            MmsWin.Front.Utilerias.VarTem.tmpPass = tbPass.Text;

            if (tbPass.Text == "")
            {
                MmsWin.Front.Utilerias.VarTem.tmpPass = tbUsuario.Text;         
            }
        }

        private void WinAeroWin()
        {
            string ParUsuario = MmsWin.Front.Utilerias.VarTem.tmpUser;
            string ParPassword = MmsWin.Front.Utilerias.VarTem.tmpPass;
            System.Data.DataTable tbLogin = null;

            try
            {
                Servidor = ConfigurationManager.ConnectionStrings["IPservidor"].ToString();
                tbLogin = MmsWin.Negocio.Login.Login.GetInstance().ObtenLogin1(ParUsuario, ParPassword);

            if (tbLogin != null)
            {
                foreach (DataRow row in tbLogin.Rows)
                {
                    string USRNOM;
                    string USRVIL;
                    string USRMAR;
                    string USRCOM;
                    string USRDIR;

                    USRNOM = row["USRNOM"].ToString();
                    USRVIL = row["USRVIL"].ToString();
                    USRMAR = row["USRMID"].ToString();
                    USRCOM = row["USRCOM"].ToString();
                    USRDIR = row["USRDIR"].ToString();
                    MmsWin.Front.Utilerias.VarTem.tmpUSRNOM = USRNOM;
                    MmsWin.Front.Utilerias.VarTem.tmpUSRVIL = USRVIL;
                    MmsWin.Front.Utilerias.VarTem.tmpUSRMAR = USRMAR;
                    MmsWin.Front.Utilerias.VarTem.tmpUSRCOM = USRCOM;
                    MmsWin.Front.Utilerias.VarTem.tmpDESC   = USRDIR;
                    MmsWin.Front.Utilerias.VarTem.tmpMarca  = USRMAR;
                    MmsWin.Front.Utilerias.VarTem.tmpComprador = USRCOM;

                    FechaInicial();
                }

                if (tbLogin.Rows.Count > 0)
                {
                    WinAero i = new WinAero();
                    i.Show();
                    this.Visible = false;
                    CargaConfiguracion();
                }
              }

            }
            catch (Exception ex)
            {
                string Msg = ex.Message.ToString();
                MessageBox.Show(Msg);
                //MessageBox.Show("Nombre de usuario o contraseña incorrectos.\nRecuerde que al tercer intento, su contraseña será bloqueada.",this.Text,MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
        }

        private void FechaInicial()
        {
            try
            {
                System.Data.DataTable tbFechaInicial = null;
                tbFechaInicial = MmsWin.Negocio.Utilerias.Utilerias.GetInstance().ObtenFechaInial1();

                foreach (DataRow row in tbFechaInicial.Rows)
                {
                    MmsWin.Front.Utilerias.VarTem.tmpFchInicial = row["DSPFCH"].ToString();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void CargaConfiguracion()
        { 
            System.Data.DataTable ActualConfiguracion = null;
            try
            {
                ActualConfiguracion = MmsWin.Negocio.Configuracion.Configuracion.GetInstance().ObtenConfiguracion1();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            if (ActualConfiguracion.Rows.Count > 0)
            {
               MmsWin.Front.Utilerias.VarTem.BkConfiguracion = ActualConfiguracion;
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {
            chkbDesarrollo.Checked = false;
            chkbProduccion.Checked = true;
            MmsWin.Admin.Login.ambiente = "Producción";

            Configuration configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            configuration.AppSettings.Settings["AMBIENTE"].Value = "Producción";
            configuration.ConnectionStrings.ConnectionStrings["cnnIseries"].ConnectionString = configuration.ConnectionStrings.ConnectionStrings["cnnIseriesAll"].ConnectionString;
            configuration.ConnectionStrings.ConnectionStrings["IPservidor"].ConnectionString = configuration.ConnectionStrings.ConnectionStrings["IPservidorAll"].ConnectionString;
            configuration.Save();

            ConfigurationManager.RefreshSection("appSettings");
            ConfigurationManager.RefreshSection("connectionStrings");
        }

        // Seguridad                                                                                
        //
        public void Seguridad(string Aplicacion, string Modulo, string Usuario)
        {
            try
            {
                System.Data.DataTable tbSeguridad = null;
                tbSeguridad = MmsWin.Negocio.Seguridad.Seguridad.GetInstance().ObtenSeguridad1(Aplicacion, Modulo, Usuario);
                foreach (DataRow row in tbSeguridad.Rows)
                {
                    string Controles = row["SEGCLS"].ToString();
                    string ValHab    = row["SEGHAC"].ToString();
                    string ValVis    = row["SEGVIC"].ToString();
                    string tipo      = row["SEGTIP"].ToString();

                    AplicaSeguridad(Controles, ValHab, ValVis, tipo);
                }
            }
            catch (Exception ex)
            {
                //string Msg = ex.Message.ToString();
                //MessageBox.Show(Msg);
                //MessageBox.Show("El usuario no existe...");
                MmsWin.Admin.Login.noexiste = false;
            }
        }
        // Aplica eguridad                                                                          
        //
        public void AplicaSeguridad(string Controles, string ValHab, string ValVis, string tipo)
        {
            // Aplica a Controles
            if (tipo == "Control")
            {
                try
                {
                    bool valorHab = false;
                    if (ValHab == "1") { valorHab = true; }

                    this.Controls[Controles].Enabled = valorHab;
                }
                catch { }

                try
                {
                    bool valorVis = false;
                    if (ValVis == "1") { valorVis = true; }
                    this.Controls[Controles].Visible = valorVis;
                }
                catch { }
            }

            //this.lblFormatos.Visible = true;
            //this.pbxFormatos.Enabled = true;
        }

        private void Login_HelpButtonClicked(object sender, CancelEventArgs e)
        {
            string notaPDF = @"\\" + srv_Doctos + @"\Notas_Credito_Proveedor\Manual_Convenio.PDF"; 

            //string notaPDF = @"\\172.16.50.25\Notas_Credito_Proveedor\Manual_Convenio.PDF";

            Process.Start(notaPDF);
        }

        private void label1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Llamar a la Ext. 1119");
        }

        private void pbSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void chkbProduccion_Click(object sender, EventArgs e)
        {
            chkbDesarrollo.Checked = false;
            chkbProduccion.Checked = true;
            MmsWin.Admin.Login.ambiente = "Producción";

            Configuration configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            configuration.ConnectionStrings.ConnectionStrings["cnnIseries"].ConnectionString = configuration.ConnectionStrings.ConnectionStrings["cnnIseriesAll"].ConnectionString;
            configuration.ConnectionStrings.ConnectionStrings["IPservidor"].ConnectionString = configuration.ConnectionStrings.ConnectionStrings["IPservidorAll"].ConnectionString;
            configuration.AppSettings.Settings["AMBIENTE"].Value = MmsWin.Admin.Login.ambiente;
            configuration.Save();
            ConfigurationManager.RefreshSection("connectionStrings");
            ConfigurationManager.RefreshSection("appSettings");
        }

        private void chkbDesarrollo_Click(object sender, EventArgs e)
        {
            chkbProduccion.Checked = false;
            chkbDesarrollo.Checked = true;
            MmsWin.Admin.Login.ambiente = "Desarrollo";

            Configuration configuration = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            configuration.ConnectionStrings.ConnectionStrings["cnnIseries"].ConnectionString = configuration.ConnectionStrings.ConnectionStrings["cnnIseriesDesarrollo"].ConnectionString;
            configuration.ConnectionStrings.ConnectionStrings["IPservidor"].ConnectionString = configuration.ConnectionStrings.ConnectionStrings["IPservidorDesarrollo"].ConnectionString;
            configuration.AppSettings.Settings["AMBIENTE"].Value = MmsWin.Admin.Login.ambiente;


            configuration.Save();
            ConfigurationManager.RefreshSection("connectionStrings");
            ConfigurationManager.RefreshSection("appSettings");
        }

        private void chkbDesarrollo_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkbProduccion_CheckedChanged(object sender, EventArgs e)
        {

        }

        // Carga Seguridad                                                                        
        //
        private void CargaSeguridad(string Aplicacion, string Modulo, string Usuario)
        {
            System.Data.DataTable dtControles = new System.Data.DataTable("Controles");
            dtControles.Columns.Add("Aplicacion", typeof(String));
            dtControles.Columns.Add("Modulo", typeof(String));
            dtControles.Columns.Add("Control", typeof(String));
            dtControles.Columns.Add("Tipo", typeof(String));
            dtControles.Columns.Add("Usuario", typeof(String));

            foreach (Control X in this.Controls)
            {
                DataRow workRow = dtControles.NewRow();
                workRow["Aplicacion"] = Aplicacion;
                workRow["Modulo"] = Modulo;
                workRow["Control"] = X.Name;
                workRow["Tipo"] = "Control";
                workRow["Usuario"] = Usuario;
                dtControles.Rows.Add(workRow);
            }
            MmsWin.Negocio.Seguridad.Controles.GetInstance().GrabaControles(dtControles);
        }

        private void Login_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Carga Seguridad    
            string Nivel = MmsWin.Front.Utilerias.VarTem.tmpUSRVIL;
            ParUser = MmsWin.Front.Utilerias.VarTem.tmpUser;
            if (Nivel == "ADMINISTRADOR")
            {
                CargaSeguridad("Login", "Login", ParUser);
            }

            Application.Exit();
        }

    }
}
