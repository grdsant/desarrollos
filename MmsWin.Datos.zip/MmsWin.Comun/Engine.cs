﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MmsWin.Comun
{
    /// <summary>
    /// Clase de los métodos generales para todas las capas de negocio
    /// </summary>
    public class Engine
    {
        /// <summary>
        /// Listado de nombre de parametros registrados en la tabla de MMSATOBJ.SAT177SMAR
        /// </summary>
        public enum Paremetrizacion : int
        {
            Reprogramaciones = 1,
            Semanas = 4
        }

        /// <summary>
        /// Listado de las marcas de la compañia
        /// </summary>
        public enum Marca : int
        {
            Milano = 30,
            Melody = 10,
            HomeFashion = 60,
            Todas = 999
        }
    }
}
