﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsXtda.Negocio.Consulta
{
    public class Consulta
    {
        internal static Consulta Consultas;

        public static Consulta GetInstance()
        {
            if (Consultas == null)
                Consultas = new Consulta();
            return Consultas;
        }

        public DataTable EjecutaConsulta1(string parTda, string parUsuario)
        {
            DataTable dtConsXtda = null;
            try
            {
                dtConsXtda = ConsXtda.Datos.Consulta.Consulta.EjecutaConsXtda(parTda, parUsuario);
                DataView dv = dtConsXtda.DefaultView;
                dtConsXtda = dv.ToTable();

                return dtConsXtda;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
