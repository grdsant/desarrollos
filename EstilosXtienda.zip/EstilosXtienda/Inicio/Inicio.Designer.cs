﻿namespace Inicio
{
    partial class Inicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbConsultaTienda = new System.Windows.Forms.Label();
            this.tbConsXtienda = new System.Windows.Forms.TextBox();
            this.dgvGridView = new System.Windows.Forms.DataGridView();
            this.tbUser = new System.Windows.Forms.TextBox();
            this.lblUsuario = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // lbConsultaTienda
            // 
            this.lbConsultaTienda.AutoSize = true;
            this.lbConsultaTienda.Location = new System.Drawing.Point(102, 80);
            this.lbConsultaTienda.Name = "lbConsultaTienda";
            this.lbConsultaTienda.Size = new System.Drawing.Size(40, 13);
            this.lbConsultaTienda.TabIndex = 1;
            this.lbConsultaTienda.Text = "Tienda";
            // 
            // tbConsXtienda
            // 
            this.tbConsXtienda.Location = new System.Drawing.Point(151, 77);
            this.tbConsXtienda.Name = "tbConsXtienda";
            this.tbConsXtienda.Size = new System.Drawing.Size(100, 20);
            this.tbConsXtienda.TabIndex = 0;
            this.tbConsXtienda.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbConsXtienda.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbConsXtienda_KeyPress);
            // 
            // dgvGridView
            // 
            this.dgvGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGridView.Location = new System.Drawing.Point(53, 33);
            this.dgvGridView.Name = "dgvGridView";
            this.dgvGridView.Size = new System.Drawing.Size(252, 171);
            this.dgvGridView.TabIndex = 4;
            this.dgvGridView.Visible = false;
            // 
            // tbUser
            // 
            this.tbUser.Location = new System.Drawing.Point(151, 124);
            this.tbUser.Name = "tbUser";
            this.tbUser.Size = new System.Drawing.Size(100, 20);
            this.tbUser.TabIndex = 5;
            this.tbUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbUser.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbUser_KeyPress);
            // 
            // lblUsuario
            // 
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.Location = new System.Drawing.Point(102, 127);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(43, 13);
            this.lblUsuario.TabIndex = 6;
            this.lblUsuario.Text = "Usuario";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(151, 169);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Reporte";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(368, 227);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblUsuario);
            this.Controls.Add(this.tbUser);
            this.Controls.Add(this.tbConsXtienda);
            this.Controls.Add(this.lbConsultaTienda);
            this.Controls.Add(this.dgvGridView);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Inicio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Consulta de estilos por tienda";
            this.Load += new System.EventHandler(this.Inicio_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbConsultaTienda;
        private System.Windows.Forms.TextBox tbConsXtienda;
        private System.Windows.Forms.DataGridView dgvGridView;
        private System.Windows.Forms.TextBox tbUser;
        private System.Windows.Forms.Label lblUsuario;
        private System.Windows.Forms.Button button1;
    }
}