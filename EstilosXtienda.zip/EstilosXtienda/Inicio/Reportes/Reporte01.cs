﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Inicio.Reportes
{
    public partial class Reporte01 : Form
    {
        public Reporte01()
        {
            InitializeComponent();
        }

        private void Reporte01_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'dsReporte01.SAT177F962' Puede moverla o quitarla según sea necesario.
            this.SAT177F962TableAdapter.Fill(this.dsReporte01.SAT177F962);

            this.reportViewer1.RefreshReport();
            this.reportViewer1.RefreshReport();
        }

        private void dsReporte01BindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void SAT177F962BindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }
    }
}
