﻿namespace Inicio.Reportes
{
    partial class Reporte01
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.SAT177F962BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dsReporte01 = new Reportes.dsReporte01();
            this.sAT177F962BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dsReporte01BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.SAT177F962TableAdapter = new Reportes.dsReporte01TableAdapters.SAT177F962TableAdapter();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            ((System.ComponentModel.ISupportInitialize)(this.SAT177F962BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsReporte01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAT177F962BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsReporte01BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // SAT177F962BindingSource
            // 
            this.SAT177F962BindingSource.DataMember = "SAT177F962";
            this.SAT177F962BindingSource.DataSource = this.dsReporte01;
            this.SAT177F962BindingSource.CurrentChanged += new System.EventHandler(this.SAT177F962BindingSource_CurrentChanged);
            // 
            // dsReporte01
            // 
            this.dsReporte01.DataSetName = "dsReporte01";
            this.dsReporte01.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sAT177F962BindingSource1
            // 
            this.sAT177F962BindingSource1.DataMember = "SAT177F962";
            this.sAT177F962BindingSource1.DataSource = this.dsReporte01BindingSource;
            // 
            // dsReporte01BindingSource
            // 
            this.dsReporte01BindingSource.DataSource = this.dsReporte01;
            this.dsReporte01BindingSource.Position = 0;
            this.dsReporte01BindingSource.CurrentChanged += new System.EventHandler(this.dsReporte01BindingSource_CurrentChanged);
            // 
            // SAT177F962TableAdapter
            // 
            this.SAT177F962TableAdapter.ClearBeforeFill = true;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.SAT177F962BindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Inicio.Reportes.InfReporte01.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(687, 298);
            this.reportViewer1.TabIndex = 0;
            // 
            // Reporte01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 298);
            this.Controls.Add(this.reportViewer1);
            this.Name = "Reporte01";
            this.Text = "Reporte01";
            this.Load += new System.EventHandler(this.Reporte01_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SAT177F962BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsReporte01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sAT177F962BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dsReporte01BindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.BindingSource SAT177F962BindingSource;
        private dsReporte01 dsReporte01;
        private dsReporte01TableAdapters.SAT177F962TableAdapter SAT177F962TableAdapter;
        private System.Windows.Forms.BindingSource dsReporte01BindingSource;
        private System.Windows.Forms.BindingSource sAT177F962BindingSource1;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
    }
}