﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Threading.Tasks;
using System.Reflection;
using Inicio.Reportes;


namespace Inicio
{
    public partial class Inicio : Form
    {
        int nr;
        public Inicio()
        {
            InitializeComponent();
        }

        private void btConsultaTienda_Click(object sender, EventArgs e)
        {

        }

        private void Inicio_Load(object sender, EventArgs e)
        {
            tbConsXtienda.Focus();
            tbUser.MaxLength = 10;
        }

        private void CargaConsulta()
        {
            try
            {
                Form existe = System.Windows.Forms.Application.OpenForms.OfType<Form>().Where(pre => pre.Name ==
                              "Consulta").SingleOrDefault<Form>();
                {
                    if (existe != null)
                    {
                        MessageBox.Show("El Convenio esta abierto");
                    }
                    else
                    {
                        ConsXtda.Front.ConsXtda.Consulta  i = new ConsXtda.Front.ConsXtda.Consulta();
                        i.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally { }
        }

        private void CargaExcel()
        {
            System.Data.DataTable dtDowns = (System.Data.DataTable)(dgvGridView.DataSource);
            Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
            if (xlApp == null)
            {
                MessageBox.Show("Excel is not properly installed!!");
                return;
            }
            Excel.Workbook xlWorkBook;
            Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlWorkBook = xlApp.Workbooks.Add(misValue);
            xlWorkSheet = (Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            int nc = dgvGridView.Columns.Count;


            for (int ii = 1; ii <= nc; ii++)
            {
                xlWorkSheet.Cells[1, ii] = dgvGridView.Columns[ii - 1].HeaderText;
            }

            System.Data.DataTable dtCalificaciones = (System.Data.DataTable)(dgvGridView.DataSource);
            int nr = dgvGridView.RowCount;

            int r = 0;
            int rt = 3;
            foreach (DataRow row in dtCalificaciones.Rows)
            {
                var gsArray = new[]       {
                                                    row["EXTTDA"],
                                                    row["EXTDES"],
                                                    row["EXTCYT"],
                                                    row["EXTPRV"],
                                                    row["EXTNOM"],
                                                    row["EXTYLQ"],
                                                    row["EXTYLE"],
                                                    row["EXTDEP"],
                                                    row["EXTSDP"],
                                                    row["EXTCLS"],
                                                    row["EXTSCL"],
                                                    row["EXTDEPD"],
                                                    row["EXTSDPD"],
                                                    row["EXTCLSD"],
                                                    row["EXTSCLD"],
                                                    row["EXTONH"],
                                                    row["EXTTRS"],
                                                    row["EXTORD"],
                                                    row["EXTSM0"],
                                                    row["EXTSM1"],
                                                    row["EXTSM2"],
                                                    row["EXTSM3"],
                                                    row["EXTSM4"],
                                                    row["EXTSM5"],
                                                    row["EXTSM6"],
                                                    row["EXTSM7"],
                                                    row["EXTSM8"],
                                                    row["EXTULF"],
                                                    row["EXTDAT"],
                                                    row["EXTLOC"],
                                                    row["EXTRCB"],
                                                    row["EXTNUM"],
                                                    row["EXTPZA"],
                                                    row["EXTCSTI"],
                                                    row["EXTPRCI"],
                                                    row["EXTCST"],
                                                    row["EXTPRC"],                                                    
                                                    row["EXTAPR"],
                                                    row["EXTNEV"],
                                                    row["EXTFEV"],
                                                    row["EXTSTR"],
                                                    row["EXTSKU"],
                                                    row["EXTFRT"],
                                                    row["EXTPZ0"],
                                                    row["EXTFCH"],
                                                    row["EXTHOR"],
                                                    row["EXTUSR"],
                                                    row["EXTEVE"]

                };

                Range rng = xlWorkSheet.get_Range("A" + rt, "AV" + rt);
                rng.Value = gsArray;

                this.Text = "Estilos por tienda / " + " " + (r += 1).ToString() + " Registro(s) de " + nr;

                // Pagar
             //   if (row["CSTCAL"].ToString() == " P a g a r") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.LightGreen; }
                // 15%
             //   if (row["CSTCAL"].ToString() == " 15%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Yellow; }
                // 20%
             //   if (row["CSTCAL"].ToString() == " 20%") { xlWorkSheet.Cells[rt, 15].Cells.Interior.Color = Color.Yellow; }


                rt++;
            }
            xlWorkSheet.Columns[1].ColumnWidth = 1;
            xlWorkSheet.Columns[2].ColumnWidth = 15;
            xlWorkSheet.Columns[3].ColumnWidth = 10;
            xlWorkSheet.Columns[4].ColumnWidth = 1;
            xlWorkSheet.Columns[5].ColumnWidth = 30;
            xlWorkSheet.Columns[6].ColumnWidth = 5;
            xlWorkSheet.Columns[7].ColumnWidth = 35;
            xlWorkSheet.Columns[8].ColumnWidth = 1;
            xlWorkSheet.Columns[9].ColumnWidth = 1;
            xlWorkSheet.Columns[10].ColumnWidth = 2;
            xlWorkSheet.Columns[11].ColumnWidth = 2;
            xlWorkSheet.Columns[12].ColumnWidth = 25;
            xlWorkSheet.Columns[13].ColumnWidth = 25;
            xlWorkSheet.Columns[14].ColumnWidth = 25;
            xlWorkSheet.Columns[15].ColumnWidth = 25;
            xlWorkSheet.Columns[16].ColumnWidth = 4;
            xlWorkSheet.Columns[17].ColumnWidth = 4;
            xlWorkSheet.Columns[18].ColumnWidth = 4;
            xlWorkSheet.Columns[19].ColumnWidth = 4;
            xlWorkSheet.Columns[20].ColumnWidth = 4;
            xlWorkSheet.Columns[21].ColumnWidth = 4;
            xlWorkSheet.Columns[22].ColumnWidth = 4;
            xlWorkSheet.Columns[23].ColumnWidth = 4;
            xlWorkSheet.Columns[24].ColumnWidth = 4;
            xlWorkSheet.Columns[25].ColumnWidth = 4;
            xlWorkSheet.Columns[26].ColumnWidth = 4;
            xlWorkSheet.Columns[27].ColumnWidth = 4;
            xlWorkSheet.Columns[28].ColumnWidth = 4;
            xlWorkSheet.Columns[29].ColumnWidth = 4;
            xlWorkSheet.Columns[30].ColumnWidth = 4;
            xlWorkSheet.Columns[31].ColumnWidth = 4;
            xlWorkSheet.Columns[32].ColumnWidth = 4;
            xlWorkSheet.Columns[33].ColumnWidth = 4;
            xlWorkSheet.Columns[34].ColumnWidth = 4;
            xlWorkSheet.Columns[35].ColumnWidth = 4;
            xlWorkSheet.Columns[36].ColumnWidth = 4;
            xlWorkSheet.Columns[37].ColumnWidth = 4;
            xlWorkSheet.Columns[38].ColumnWidth = 4;
            xlWorkSheet.Columns[39].ColumnWidth = 4;
            xlWorkSheet.Columns[40].ColumnWidth = 4;
            xlWorkSheet.Columns[41].ColumnWidth = 4;
            xlWorkSheet.Columns[42].ColumnWidth = 4;
            xlWorkSheet.Columns[43].ColumnWidth = 4;
            xlWorkSheet.Columns[44].ColumnWidth = 4;
            xlWorkSheet.Columns[45].ColumnWidth = 4;
            xlWorkSheet.Columns[46].ColumnWidth = 4;
            xlWorkSheet.Columns[47].ColumnWidth = 4;
            xlWorkSheet.Columns[48].ColumnWidth = 6;
            xlWorkSheet.Columns[49].ColumnWidth = 6;

            var Rang1 = xlWorkSheet.get_Range("A1", "C1");
            Rang1.Interior.Color = Color.LightGreen;

            xlWorkSheet.Cells[1, 4].Cells.Interior.Color = Color.LightSkyBlue;
            xlWorkSheet.Cells[1, 5].Cells.Interior.Color = Color.LightSkyBlue;

            xlWorkSheet.Cells[1, 6].Cells.Interior.Color = Color.LightSalmon;
            xlWorkSheet.Cells[1, 7].Cells.Interior.Color = Color.LightSalmon;

            var Rang2 = xlWorkSheet.get_Range("H1", "K1");
            Rang2.Interior.Color = Color.LightGreen;

            var Rang3 = xlWorkSheet.get_Range("L1", "O1");
            Rang3.Interior.Color = Color.LightSkyBlue;

            var Rang4 = xlWorkSheet.get_Range("P1", "R1");
            Rang4.Interior.Color = Color.LightSalmon;

            var Rang5 = xlWorkSheet.get_Range("S1", "AA1");
            Rang5.Interior.Color = Color.LightSkyBlue;

            var Rang6 = xlWorkSheet.get_Range("AB1", "AG1");
            Rang6.Interior.Color = Color.LightGreen;

            var Rang7 = xlWorkSheet.get_Range("AH1", "AI1");
            Rang7.Interior.Color = Color.LightSalmon;

            var Rang9 = xlWorkSheet.get_Range("AJ1", "AK1");
            Rang9.Interior.Color = Color.LightGray;

            var Rang10 = xlWorkSheet.get_Range("AL1", "AP1");
            Rang10.Interior.Color = Color.Blue;

            var Rang11 = xlWorkSheet.get_Range("AQ1", "AR1");
            Rang11.Interior.Color = Color.Green;

            //var Rang12 = xlWorkSheet.get_Range("AL1", "AM1");
            //Rang12.Interior.Color = Color.LightGreen;

            var Rang13 = xlWorkSheet.get_Range("AS1", "AV1");
            Rang13.Interior.Color = Color.LightGray;

            var Rang8 = xlWorkSheet.get_Range("A1", "AV1");
            Rang8.WrapText = true;
            Rang8.Font.Bold = true;
            Rang8.Font.Color = Color.White;
            Rang8.Borders.LineStyle = BorderStyle.FixedSingle;
            Rang8.Font.Underline = true;
            Rang8.HorizontalAlignment = HorizontalAlignment.Center;

            String Rango = "A2" + ":" + "AV" + rt;
            Excel.Range SourceRange = (Excel.Range)xlWorkSheet.get_Range("A2", "AV" + rt); // or whatever range you want here
            FormatAsTable(SourceRange, "Table1", "TableStyleMedium2");

            xlWorkSheet.Rows[2].Hidden = true;

            xlWorkSheet.Columns["A"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["D"].HorizontalAlignment     = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["F"].HorizontalAlignment     = XlHAlign.xlHAlignLeft;
            xlWorkSheet.Columns["H:K"].HorizontalAlignment   = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["P:AC"].HorizontalAlignment  = XlHAlign.xlHAlignRight;
            xlWorkSheet.Columns["AB:AG"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AH:AJ"].HorizontalAlignment = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["S:AA"].HorizontalAlignment  = XlHAlign.xlHAlignCenter;
            xlWorkSheet.Columns["AM:AV"].HorizontalAlignment = XlHAlign.xlHAlignCenter;

            xlWorkSheet.Columns["A"].NumberFormat     = "#####";
            xlWorkSheet.Columns["D"].NumberFormat     = "#####";
            xlWorkSheet.Columns["H:K"].NumberFormat   = "#####";
            xlWorkSheet.Columns["P:AA"].NumberFormat  = "###,###";
            xlWorkSheet.Columns["AB"].NumberFormat    = "2000-00-00";
            xlWorkSheet.Columns["AC"].NumberFormat    = "2000-00-00";
            xlWorkSheet.Columns["AH:AJ"].NumberFormat = "###,###.00";
            xlWorkSheet.Columns["AG"].NumberFormat    = "###,###";

            xlWorkSheet.Columns["AM"].NumberFormat    = "#####";
            xlWorkSheet.Columns["AN"].NumberFormat    = "2000-00-00";
            xlWorkSheet.Columns["AO"].NumberFormat    = "#####";
            xlWorkSheet.Columns["AP"].NumberFormat    = "#####";
            xlWorkSheet.Columns["AQ"].NumberFormat    = "2000-00-00";
            xlWorkSheet.Columns["AR"].NumberFormat    = "###,###";
            xlWorkSheet.Columns["AS"].NumberFormat    = "2000-00-00";
            xlWorkSheet.Columns["AT"].NumberFormat    = "00-00-00";
            xlWorkSheet.Columns["AV"].NumberFormat    = "#####";

            var range = xlWorkSheet.get_Range("A3", "A3");
            range.Select();

            string Hoy = DateTime.Now.ToString("yyyyMMddHHmmss");
            xlApp.ActiveWindow.Zoom = 80;
            xlWorkBook.SaveAs("C:\\Reportes\\EstilosXtienda" + Hoy + ".xlsx", Excel.XlFileFormat.xlWorkbookDefault, misValue, misValue, misValue, misValue, Excel.XlSaveAsAccessMode.xlExclusive, misValue, misValue, misValue, misValue, misValue);
            xlWorkBook.Close(true, misValue, misValue);
            xlApp.Quit();
            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);

            string comando = @"C:\\Reportes\\EstilosXtienda" + Hoy + ".xlsx";
            ExecuteCommand(comando);
        }

        static void ExecuteCommand(string _Command)
        {
            //Indicamos que deseamos inicializar el proceso cmd.exe junto a un comando de arranque. 
            //(/C, le indicamos al proceso cmd que deseamos que cuando termine la tarea asignada se cierre el proceso).
            //Para mas informacion consulte la ayuda de la consola con cmd.exe /? 
            System.Diagnostics.ProcessStartInfo procStartInfo = new System.Diagnostics.ProcessStartInfo("cmd", "/c " + _Command);
            // Indicamos que la salida del proceso se redireccione en un Stream
            procStartInfo.RedirectStandardOutput = true;
            procStartInfo.UseShellExecute = false;
            //Indica que el proceso no despliegue una pantalla negra (El proceso se ejecuta en background)
            procStartInfo.CreateNoWindow = true;
            //Inicializa el proceso
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo = procStartInfo;
            proc.Start();
            //Consigue la salida de la Consola(Stream) y devuelve una cadena de texto
            string result = proc.StandardOutput.ReadToEnd();
        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Exception Occured while releasing object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

        public void FormatAsTable(Excel.Range SourceRange, string TableName, string TableStyleName)
        {
            SourceRange.Worksheet.ListObjects.Add(XlListObjectSourceType.xlSrcRange,
            SourceRange, System.Type.Missing, XlYesNoGuess.xlYes, System.Type.Missing).Name =
                TableName;
            SourceRange.Select();
            SourceRange.Worksheet.ListObjects[TableName].TableStyle = TableStyleName;
            SourceRange.Worksheet.ListObjects[TableName].ShowAutoFilter = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowHeaders = false;
            SourceRange.Worksheet.ListObjects[TableName].ShowTotals = false;
        }

        private void tbConsXtienda_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                if (tbConsXtienda.Text != "" && tbUser.Text != "")
                {
                    string parTda = tbConsXtienda.Text;
                    string parUsuario = tbUser.Text;
                    if (tbConsXtienda.Text != "")
                    {
                        nr = 0;
                        System.Data.DataTable dtConsXtda = null;
                        this.Cursor = Cursors.WaitCursor;
                        dtConsXtda = ConsXtda.Negocio.Consulta.Consulta.GetInstance().EjecutaConsulta1(parTda, parUsuario);

                        if (dtConsXtda.Rows.Count > 0)
                        {
                            dgvGridView.DataSource = dtConsXtda;
                            SetFontAndColors();

                            nr = dgvGridView.RowCount;
                            this.Text = "Historico de Calificaciones / " + " " + (nr).ToString() + " Registro(s)";

                            CargaExcel();

                        }
                        this.Cursor = Cursors.Default;
                     //   MessageBox.Show("Proceso Terminado...");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("No debe quedar en blanco la tienda");
                    }
                }
            }
        }

        private void tbUser_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                string parTda = tbConsXtienda.Text;
                string parUsuario = tbUser.Text;
                if (tbConsXtienda.Text != "" && tbUser.Text != "")
                {
                    nr = 0;
                    System.Data.DataTable dtConsXtda = null;
                    this.Cursor = Cursors.WaitCursor;
                    dtConsXtda = ConsXtda.Negocio.Consulta.Consulta.GetInstance().EjecutaConsulta1(parTda, parUsuario);

                    if (dtConsXtda.Rows.Count > 0)
                    {
                        dgvGridView.DataSource = dtConsXtda;
                        SetFontAndColors();

                        nr = dgvGridView.RowCount;
                        this.Text = "Historico de Calificaciones / " + " " + (nr).ToString() + " Registro(s)";

                        CargaExcel();

                    }
                    this.Cursor = Cursors.Default;
                 //   MessageBox.Show("Proceso Terminado...");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("No debe quedar en blanco la tienda");
                }

            }
        }

        private void SetFontAndColors()
        {
            this.dgvGridView.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            this.dgvGridView.ColumnHeadersDefaultCellStyle.Font = new System.Drawing.Font("Bold", 9);
            this.dgvGridView.EnableHeadersVisualStyles = false;
            this.dgvGridView.DefaultCellStyle.Font = new System.Drawing.Font("Verdana", 8);
            this.dgvGridView.DefaultCellStyle.SelectionForeColor = Color.Black;
            this.dgvGridView.DefaultCellStyle.SelectionBackColor = Color.LightGray;
            this.dgvGridView.CellBorderStyle = DataGridViewCellBorderStyle.Single;
            this.dgvGridView.RowsDefaultCellStyle.ForeColor = Color.Black;
            this.dgvGridView.Columns[3].Frozen = true;

            dgvGridView.Columns[0].HeaderText = "Tienda";
            dgvGridView.Columns[1].HeaderText = "Descripción";
            dgvGridView.Columns[2].HeaderText = "Ciudad";
            dgvGridView.Columns[3].HeaderText = "Proveedor";
            dgvGridView.Columns[4].HeaderText = "Nombre";
            dgvGridView.Columns[5].HeaderText = "Estilo";
            dgvGridView.Columns[6].HeaderText = "Descripción";
            dgvGridView.Columns[7].HeaderText = "Depto";
            dgvGridView.Columns[8].HeaderText = "Sub Depto";
            dgvGridView.Columns[9].HeaderText = "Clase";
            dgvGridView.Columns[10].HeaderText = "Sub Clase";
            dgvGridView.Columns[11].HeaderText = "Depto";
            dgvGridView.Columns[12].HeaderText = "Sub  Depto";
            dgvGridView.Columns[13].HeaderText = "Clase";
            dgvGridView.Columns[14].HeaderText = "Sub  Clase";
            dgvGridView.Columns[15].HeaderText = "On  Hand";
            dgvGridView.Columns[16].HeaderText = "Transito";
            dgvGridView.Columns[17].HeaderText = "Ondenes Confirmadas";
            dgvGridView.Columns[18].HeaderText = "Semana  Actual";
            dgvGridView.Columns[19].HeaderText = "Semana  1";
            dgvGridView.Columns[20].HeaderText = "Semana  2";
            dgvGridView.Columns[21].HeaderText = "Semana  3";
            dgvGridView.Columns[22].HeaderText = "Semana  4";
            dgvGridView.Columns[23].HeaderText = "Semana  5";
            dgvGridView.Columns[24].HeaderText = "Semana  6";
            dgvGridView.Columns[25].HeaderText = "Semana  7";
            dgvGridView.Columns[26].HeaderText = "Semana  8";
            dgvGridView.Columns[27].HeaderText = "Ultima Venta";
            dgvGridView.Columns[28].HeaderText = "Fecha Recibo";
            dgvGridView.Columns[29].HeaderText = "Bodega";
            dgvGridView.Columns[30].HeaderText = "Recibo";
            dgvGridView.Columns[31].HeaderText = "Orden";
            dgvGridView.Columns[32].HeaderText = "Piezas";
            dgvGridView.Columns[33].HeaderText = "Costo Inicial";
            dgvGridView.Columns[34].HeaderText = "Precio Inicial";
            dgvGridView.Columns[35].HeaderText = "Costo";
            dgvGridView.Columns[36].HeaderText = "Precio";

            dgvGridView.Columns[37].HeaderText = "Precio";
            dgvGridView.Columns[38].HeaderText = "Evento";
            dgvGridView.Columns[39].HeaderText = "Fecha";
            dgvGridView.Columns[40].HeaderText = "Tienda";
            dgvGridView.Columns[41].HeaderText = "Sku";
            dgvGridView.Columns[42].HeaderText = "Recibo Tienda";
            dgvGridView.Columns[43].HeaderText = "Piezas";

            dgvGridView.Columns[44].HeaderText = "Fecha  Proceso";
            dgvGridView.Columns[45].HeaderText = "Hora  Proceso";
            dgvGridView.Columns[46].HeaderText = "Usuario  Proceso";
            dgvGridView.Columns[47].HeaderText = "Evento  Etiqueta";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Reporte01 i = new Reporte01();
            i.ShowDialog(this);
        }

    }
}
