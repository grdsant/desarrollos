﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Odbc;

namespace ConsXtda.Datos.Consulta
{
   public  class Consulta
    {
       public static DataTable EjecutaConsXtda(string parTda, string parUsuario)
       {
           string Db2_Prod = "Provider=IBMDA400;Data Source=192.168.2.83;User Id=SRVCONV;Password=SRVCONV";

           string Db2_odbc = "Provider=IBMDA400;Data Source=192.168.2.83;User Id=SRVCONV;Password=SRVCONV";
           System.Data.Odbc.OdbcConnection odbcVar = null;

           string cadenaConexionDb2 = Db2_Prod;
           OleDbConnection db2Conn = null;
           StringBuilder sql = new StringBuilder();
           DataTable dtConsXtda = null;

           try
           {
               db2Conn = new OleDbConnection(cadenaConexionDb2);
               db2Conn.Open();
               OleDbCommand db2Comm = db2Conn.CreateCommand();

               sql.Append("CALL MMSATPGM.SAT406R1 (\n");
               sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", parTda.PadLeft(5, '0'));
               sql.AppendFormat("'" + "{0}" + "'" + "\n", parUsuario.PadRight(10, ' '));
               sql.Append(")");

               db2Comm.CommandText = sql.ToString();
               db2Comm.ExecuteNonQuery();

               sql.Clear();
               sql.Append("SELECT * FROM MMSATOBJ.SAT406PF \n");

               db2Comm.CommandText = sql.ToString();
               OleDbDataReader db2Reader = db2Comm.ExecuteReader();

               dtConsXtda = new DataTable("ConsultaXtda");
               dtConsXtda.Load(db2Reader);
               db2Reader.Close();

               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();

               return dtConsXtda;
           }
           catch (Exception ex)
           {
               throw ex;
           }
           finally
           {
               if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                   db2Conn.Close();
           }
       }
       
    }
}
