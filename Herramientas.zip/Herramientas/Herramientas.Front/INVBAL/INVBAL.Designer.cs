﻿namespace Herramientas.Front.INVBAL
{
    partial class INVBAL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(INVBAL));
            this.tbInvbalLib = new System.Windows.Forms.TextBox();
            this.tbInvbal = new System.Windows.Forms.TextBox();
            this.lbLibreria = new System.Windows.Forms.Label();
            this.lbArchivo = new System.Windows.Forms.Label();
            this.lbProcesos = new System.Windows.Forms.Label();
            this.btProcesar = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbInvmst = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbGat027f = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbGat092f = new System.Windows.Forms.TextBox();
            this.btNoProc = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.btSAT704PFonhand = new System.Windows.Forms.Button();
            this.btDIFonhand = new System.Windows.Forms.Button();
            this.btINVBALonhand = new System.Windows.Forms.Button();
            this.lbSAT704PF = new System.Windows.Forms.Label();
            this.lbDIF = new System.Windows.Forms.Label();
            this.lbINVBAL = new System.Windows.Forms.Label();
            this.btSAT704PFtransito = new System.Windows.Forms.Button();
            this.btSAT704PFonorder = new System.Windows.Forms.Button();
            this.btDIFtransito = new System.Windows.Forms.Button();
            this.btDIFonorder = new System.Windows.Forms.Button();
            this.btINVBALtransito = new System.Windows.Forms.Button();
            this.btINVBALonorder = new System.Windows.Forms.Button();
            this.lbOnHand = new System.Windows.Forms.Label();
            this.lbTransito = new System.Windows.Forms.Label();
            this.lbOnOrder = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btValidacion = new System.Windows.Forms.Button();
            this.lbFecha = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tbInvmstLib = new System.Windows.Forms.TextBox();
            this.tbGat027fLib = new System.Windows.Forms.TextBox();
            this.tbGat092fLib = new System.Windows.Forms.TextBox();
            this.gbProceso = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbSemana = new System.Windows.Forms.Label();
            this.Anio = new System.Windows.Forms.Label();
            this.tbSemana = new System.Windows.Forms.TextBox();
            this.tbAnio = new System.Windows.Forms.TextBox();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbInvbalLib
            // 
            this.tbInvbalLib.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbInvbalLib.Location = new System.Drawing.Point(372, 32);
            this.tbInvbalLib.Name = "tbInvbalLib";
            this.tbInvbalLib.Size = new System.Drawing.Size(94, 20);
            this.tbInvbalLib.TabIndex = 0;
            this.tbInvbalLib.Text = "PASO";
            // 
            // tbInvbal
            // 
            this.tbInvbal.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbInvbal.Location = new System.Drawing.Point(272, 32);
            this.tbInvbal.Name = "tbInvbal";
            this.tbInvbal.Size = new System.Drawing.Size(93, 20);
            this.tbInvbal.TabIndex = 4;
            this.tbInvbal.Text = "INVBALLF";
            // 
            // lbLibreria
            // 
            this.lbLibreria.AutoSize = true;
            this.lbLibreria.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLibreria.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbLibreria.Location = new System.Drawing.Point(369, 17);
            this.lbLibreria.Name = "lbLibreria";
            this.lbLibreria.Size = new System.Drawing.Size(55, 13);
            this.lbLibreria.TabIndex = 5;
            this.lbLibreria.Text = "Librerias";
            // 
            // lbArchivo
            // 
            this.lbArchivo.AutoSize = true;
            this.lbArchivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbArchivo.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbArchivo.Location = new System.Drawing.Point(215, 36);
            this.lbArchivo.Name = "lbArchivo";
            this.lbArchivo.Size = new System.Drawing.Size(51, 13);
            this.lbArchivo.TabIndex = 6;
            this.lbArchivo.Text = "INVBAL";
            // 
            // lbProcesos
            // 
            this.lbProcesos.AutoSize = true;
            this.lbProcesos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbProcesos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbProcesos.Location = new System.Drawing.Point(12, 278);
            this.lbProcesos.Name = "lbProcesos";
            this.lbProcesos.Size = new System.Drawing.Size(59, 13);
            this.lbProcesos.TabIndex = 9;
            this.lbProcesos.Text = "Procesos";
            // 
            // btProcesar
            // 
            this.btProcesar.BackColor = System.Drawing.Color.Green;
            this.btProcesar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btProcesar.ForeColor = System.Drawing.Color.White;
            this.btProcesar.Location = new System.Drawing.Point(27, 97);
            this.btProcesar.Name = "btProcesar";
            this.btProcesar.Size = new System.Drawing.Size(76, 46);
            this.btProcesar.TabIndex = 10;
            this.btProcesar.Text = "Procesar";
            this.btProcesar.UseVisualStyleBackColor = false;
            this.btProcesar.Click += new System.EventHandler(this.btProcesar_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(269, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Archivos";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(215, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "INVMST";
            // 
            // tbInvmst
            // 
            this.tbInvmst.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbInvmst.Location = new System.Drawing.Point(272, 58);
            this.tbInvmst.Name = "tbInvmst";
            this.tbInvmst.Size = new System.Drawing.Size(93, 20);
            this.tbInvmst.TabIndex = 5;
            this.tbInvmst.Text = "INVMST";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(215, 87);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 15;
            this.label3.Text = "GAT027F";
            // 
            // tbGat027f
            // 
            this.tbGat027f.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbGat027f.Location = new System.Drawing.Point(272, 84);
            this.tbGat027f.Name = "tbGat027f";
            this.tbGat027f.Size = new System.Drawing.Size(93, 20);
            this.tbGat027f.TabIndex = 6;
            this.tbGat027f.Text = "GAT027F";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(215, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 17;
            this.label4.Text = "GAT092F";
            // 
            // tbGat092f
            // 
            this.tbGat092f.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbGat092f.Location = new System.Drawing.Point(272, 110);
            this.tbGat092f.Name = "tbGat092f";
            this.tbGat092f.Size = new System.Drawing.Size(93, 20);
            this.tbGat092f.TabIndex = 7;
            this.tbGat092f.Text = "GAT092F";
            // 
            // btNoProc
            // 
            this.btNoProc.Enabled = false;
            this.btNoProc.Font = new System.Drawing.Font("Microsoft Sans Serif", 72F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNoProc.Location = new System.Drawing.Point(12, 292);
            this.btNoProc.Name = "btNoProc";
            this.btNoProc.Size = new System.Drawing.Size(461, 111);
            this.btNoProc.TabIndex = 18;
            this.btNoProc.Text = "0";
            this.btNoProc.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label5.Location = new System.Drawing.Point(427, 276);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "Tiempo      ";
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // btSAT704PFonhand
            // 
            this.btSAT704PFonhand.Enabled = false;
            this.btSAT704PFonhand.Location = new System.Drawing.Point(111, 177);
            this.btSAT704PFonhand.Name = "btSAT704PFonhand";
            this.btSAT704PFonhand.Size = new System.Drawing.Size(101, 23);
            this.btSAT704PFonhand.TabIndex = 20;
            this.btSAT704PFonhand.Text = "SAT704PF";
            this.btSAT704PFonhand.UseVisualStyleBackColor = true;
            // 
            // btDIFonhand
            // 
            this.btDIFonhand.Enabled = false;
            this.btDIFonhand.Location = new System.Drawing.Point(218, 177);
            this.btDIFonhand.Name = "btDIFonhand";
            this.btDIFonhand.Size = new System.Drawing.Size(101, 23);
            this.btDIFonhand.TabIndex = 21;
            this.btDIFonhand.Text = "Difernecia";
            this.btDIFonhand.UseVisualStyleBackColor = true;
            // 
            // btINVBALonhand
            // 
            this.btINVBALonhand.Enabled = false;
            this.btINVBALonhand.Location = new System.Drawing.Point(324, 177);
            this.btINVBALonhand.Name = "btINVBALonhand";
            this.btINVBALonhand.Size = new System.Drawing.Size(101, 23);
            this.btINVBALonhand.TabIndex = 22;
            this.btINVBALonhand.Text = "INVBAL";
            this.btINVBALonhand.UseVisualStyleBackColor = true;
            // 
            // lbSAT704PF
            // 
            this.lbSAT704PF.AutoSize = true;
            this.lbSAT704PF.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSAT704PF.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lbSAT704PF.Location = new System.Drawing.Point(133, 161);
            this.lbSAT704PF.Name = "lbSAT704PF";
            this.lbSAT704PF.Size = new System.Drawing.Size(67, 13);
            this.lbSAT704PF.TabIndex = 23;
            this.lbSAT704PF.Text = "SAT704PF";
            // 
            // lbDIF
            // 
            this.lbDIF.AutoSize = true;
            this.lbDIF.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDIF.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbDIF.Location = new System.Drawing.Point(242, 161);
            this.lbDIF.Name = "lbDIF";
            this.lbDIF.Size = new System.Drawing.Size(65, 13);
            this.lbDIF.TabIndex = 24;
            this.lbDIF.Text = "Diferencia";
            // 
            // lbINVBAL
            // 
            this.lbINVBAL.AutoSize = true;
            this.lbINVBAL.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbINVBAL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbINVBAL.Location = new System.Drawing.Point(351, 161);
            this.lbINVBAL.Name = "lbINVBAL";
            this.lbINVBAL.Size = new System.Drawing.Size(51, 13);
            this.lbINVBAL.TabIndex = 25;
            this.lbINVBAL.Text = "INVBAL";
            // 
            // btSAT704PFtransito
            // 
            this.btSAT704PFtransito.Enabled = false;
            this.btSAT704PFtransito.Location = new System.Drawing.Point(111, 206);
            this.btSAT704PFtransito.Name = "btSAT704PFtransito";
            this.btSAT704PFtransito.Size = new System.Drawing.Size(101, 23);
            this.btSAT704PFtransito.TabIndex = 26;
            this.btSAT704PFtransito.Text = "SAT704PF";
            this.btSAT704PFtransito.UseVisualStyleBackColor = true;
            // 
            // btSAT704PFonorder
            // 
            this.btSAT704PFonorder.Enabled = false;
            this.btSAT704PFonorder.Location = new System.Drawing.Point(111, 235);
            this.btSAT704PFonorder.Name = "btSAT704PFonorder";
            this.btSAT704PFonorder.Size = new System.Drawing.Size(101, 23);
            this.btSAT704PFonorder.TabIndex = 27;
            this.btSAT704PFonorder.Text = "SAT704PF";
            this.btSAT704PFonorder.UseVisualStyleBackColor = true;
            // 
            // btDIFtransito
            // 
            this.btDIFtransito.Enabled = false;
            this.btDIFtransito.Location = new System.Drawing.Point(218, 206);
            this.btDIFtransito.Name = "btDIFtransito";
            this.btDIFtransito.Size = new System.Drawing.Size(101, 23);
            this.btDIFtransito.TabIndex = 28;
            this.btDIFtransito.Text = "Difernecia";
            this.btDIFtransito.UseVisualStyleBackColor = true;
            // 
            // btDIFonorder
            // 
            this.btDIFonorder.Enabled = false;
            this.btDIFonorder.Location = new System.Drawing.Point(218, 235);
            this.btDIFonorder.Name = "btDIFonorder";
            this.btDIFonorder.Size = new System.Drawing.Size(101, 23);
            this.btDIFonorder.TabIndex = 29;
            this.btDIFonorder.Text = "Difernecia";
            this.btDIFonorder.UseVisualStyleBackColor = true;
            // 
            // btINVBALtransito
            // 
            this.btINVBALtransito.Enabled = false;
            this.btINVBALtransito.Location = new System.Drawing.Point(324, 206);
            this.btINVBALtransito.Name = "btINVBALtransito";
            this.btINVBALtransito.Size = new System.Drawing.Size(101, 23);
            this.btINVBALtransito.TabIndex = 30;
            this.btINVBALtransito.Text = "INVBAL";
            this.btINVBALtransito.UseVisualStyleBackColor = true;
            // 
            // btINVBALonorder
            // 
            this.btINVBALonorder.Enabled = false;
            this.btINVBALonorder.Location = new System.Drawing.Point(324, 235);
            this.btINVBALonorder.Name = "btINVBALonorder";
            this.btINVBALonorder.Size = new System.Drawing.Size(101, 23);
            this.btINVBALonorder.TabIndex = 31;
            this.btINVBALonorder.Text = "INVBAL";
            this.btINVBALonorder.UseVisualStyleBackColor = true;
            // 
            // lbOnHand
            // 
            this.lbOnHand.AutoSize = true;
            this.lbOnHand.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOnHand.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbOnHand.Location = new System.Drawing.Point(54, 183);
            this.lbOnHand.Name = "lbOnHand";
            this.lbOnHand.Size = new System.Drawing.Size(57, 13);
            this.lbOnHand.TabIndex = 32;
            this.lbOnHand.Text = "On Hand";
            // 
            // lbTransito
            // 
            this.lbTransito.AutoSize = true;
            this.lbTransito.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTransito.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbTransito.Location = new System.Drawing.Point(54, 211);
            this.lbTransito.Name = "lbTransito";
            this.lbTransito.Size = new System.Drawing.Size(53, 13);
            this.lbTransito.TabIndex = 33;
            this.lbTransito.Text = "Transito";
            // 
            // lbOnOrder
            // 
            this.lbOnOrder.AutoSize = true;
            this.lbOnOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOnOrder.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbOnOrder.Location = new System.Drawing.Point(54, 240);
            this.lbOnOrder.Name = "lbOnOrder";
            this.lbOnOrder.Size = new System.Drawing.Size(58, 13);
            this.lbOnOrder.TabIndex = 34;
            this.lbOnOrder.Text = "On Order";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(43, 151);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(402, 123);
            this.panel1.TabIndex = 35;
            // 
            // btValidacion
            // 
            this.btValidacion.Location = new System.Drawing.Point(27, 31);
            this.btValidacion.Name = "btValidacion";
            this.btValidacion.Size = new System.Drawing.Size(76, 23);
            this.btValidacion.TabIndex = 36;
            this.btValidacion.Text = "Validacion";
            this.btValidacion.UseVisualStyleBackColor = true;
            this.btValidacion.Click += new System.EventHandler(this.btValidacion_Click);
            // 
            // lbFecha
            // 
            this.lbFecha.AutoSize = true;
            this.lbFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFecha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lbFecha.Location = new System.Drawing.Point(4, 6);
            this.lbFecha.Name = "lbFecha";
            this.lbFecha.Size = new System.Drawing.Size(42, 13);
            this.lbFecha.TabIndex = 37;
            this.lbFecha.Text = "Fecha";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbFecha);
            this.panel2.Enabled = false;
            this.panel2.Location = new System.Drawing.Point(27, 67);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(76, 25);
            this.panel2.TabIndex = 38;
            // 
            // tbInvmstLib
            // 
            this.tbInvmstLib.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbInvmstLib.Location = new System.Drawing.Point(371, 58);
            this.tbInvmstLib.Name = "tbInvmstLib";
            this.tbInvmstLib.Size = new System.Drawing.Size(94, 20);
            this.tbInvmstLib.TabIndex = 1;
            this.tbInvmstLib.Text = "MM610LIB";
            // 
            // tbGat027fLib
            // 
            this.tbGat027fLib.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbGat027fLib.Location = new System.Drawing.Point(371, 83);
            this.tbGat027fLib.Name = "tbGat027fLib";
            this.tbGat027fLib.Size = new System.Drawing.Size(94, 20);
            this.tbGat027fLib.TabIndex = 2;
            this.tbGat027fLib.Text = "MMSATOBJ";
            // 
            // tbGat092fLib
            // 
            this.tbGat092fLib.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbGat092fLib.Location = new System.Drawing.Point(371, 110);
            this.tbGat092fLib.Name = "tbGat092fLib";
            this.tbGat092fLib.Size = new System.Drawing.Size(94, 20);
            this.tbGat092fLib.TabIndex = 3;
            this.tbGat092fLib.Text = "MMSATOBJ";
            // 
            // gbProceso
            // 
            this.gbProceso.BackColor = System.Drawing.Color.Gray;
            this.gbProceso.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbProceso.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbProceso.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.gbProceso.Location = new System.Drawing.Point(19, 16);
            this.gbProceso.Name = "gbProceso";
            this.gbProceso.Size = new System.Drawing.Size(91, 130);
            this.gbProceso.TabIndex = 42;
            this.gbProceso.TabStop = false;
            this.gbProceso.Text = "Procesar";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Location = new System.Drawing.Point(12, 7);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(461, 141);
            this.panel3.TabIndex = 36;
            // 
            // lbSemana
            // 
            this.lbSemana.AutoSize = true;
            this.lbSemana.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbSemana.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lbSemana.Location = new System.Drawing.Point(114, 79);
            this.lbSemana.Name = "lbSemana";
            this.lbSemana.Size = new System.Drawing.Size(81, 13);
            this.lbSemana.TabIndex = 50;
            this.lbSemana.Text = "Semana (NS)";
            // 
            // Anio
            // 
            this.Anio.AutoSize = true;
            this.Anio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Anio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Anio.Location = new System.Drawing.Point(114, 39);
            this.Anio.Name = "Anio";
            this.Anio.Size = new System.Drawing.Size(57, 13);
            this.Anio.TabIndex = 48;
            this.Anio.Text = "Año (AA)";
            // 
            // tbSemana
            // 
            this.tbSemana.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbSemana.Location = new System.Drawing.Point(114, 94);
            this.tbSemana.Name = "tbSemana";
            this.tbSemana.Size = new System.Drawing.Size(100, 20);
            this.tbSemana.TabIndex = 9;
            this.tbSemana.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbAnio
            // 
            this.tbAnio.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.tbAnio.Location = new System.Drawing.Point(114, 55);
            this.tbAnio.Name = "tbAnio";
            this.tbAnio.Size = new System.Drawing.Size(100, 20);
            this.tbAnio.TabIndex = 8;
            this.tbAnio.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // INVBAL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(485, 411);
            this.Controls.Add(this.tbGat092f);
            this.Controls.Add(this.tbGat027f);
            this.Controls.Add(this.lbSemana);
            this.Controls.Add(this.Anio);
            this.Controls.Add(this.tbSemana);
            this.Controls.Add(this.tbAnio);
            this.Controls.Add(this.tbGat092fLib);
            this.Controls.Add(this.tbGat027fLib);
            this.Controls.Add(this.tbInvmstLib);
            this.Controls.Add(this.btValidacion);
            this.Controls.Add(this.lbOnOrder);
            this.Controls.Add(this.lbTransito);
            this.Controls.Add(this.lbOnHand);
            this.Controls.Add(this.btINVBALonorder);
            this.Controls.Add(this.btINVBALtransito);
            this.Controls.Add(this.btDIFonorder);
            this.Controls.Add(this.btDIFtransito);
            this.Controls.Add(this.btSAT704PFonorder);
            this.Controls.Add(this.btSAT704PFtransito);
            this.Controls.Add(this.lbINVBAL);
            this.Controls.Add(this.lbDIF);
            this.Controls.Add(this.lbSAT704PF);
            this.Controls.Add(this.btINVBALonhand);
            this.Controls.Add(this.btDIFonhand);
            this.Controls.Add(this.btSAT704PFonhand);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btNoProc);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbInvmst);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btProcesar);
            this.Controls.Add(this.lbProcesos);
            this.Controls.Add(this.lbArchivo);
            this.Controls.Add(this.lbLibreria);
            this.Controls.Add(this.tbInvbal);
            this.Controls.Add(this.tbInvbalLib);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.gbProceso);
            this.Controls.Add(this.panel3);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "INVBAL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Carga Inventario";
            this.Load += new System.EventHandler(this.INVBAL_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbInvbalLib;
        private System.Windows.Forms.TextBox tbInvbal;
        private System.Windows.Forms.Label lbLibreria;
        private System.Windows.Forms.Label lbArchivo;
        private System.Windows.Forms.Label lbProcesos;
        private System.Windows.Forms.Button btProcesar;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbInvmst;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbGat027f;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbGat092f;
        private System.Windows.Forms.Button btNoProc;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Button btSAT704PFonhand;
        private System.Windows.Forms.Button btDIFonhand;
        private System.Windows.Forms.Button btINVBALonhand;
        private System.Windows.Forms.Label lbSAT704PF;
        private System.Windows.Forms.Label lbDIF;
        private System.Windows.Forms.Label lbINVBAL;
        private System.Windows.Forms.Button btSAT704PFtransito;
        private System.Windows.Forms.Button btSAT704PFonorder;
        private System.Windows.Forms.Button btDIFtransito;
        private System.Windows.Forms.Button btDIFonorder;
        private System.Windows.Forms.Button btINVBALtransito;
        private System.Windows.Forms.Button btINVBALonorder;
        private System.Windows.Forms.Label lbOnHand;
        private System.Windows.Forms.Label lbTransito;
        private System.Windows.Forms.Label lbOnOrder;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btValidacion;
        private System.Windows.Forms.Label lbFecha;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox tbInvmstLib;
        private System.Windows.Forms.TextBox tbGat027fLib;
        private System.Windows.Forms.TextBox tbGat092fLib;
        private System.Windows.Forms.GroupBox gbProceso;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lbSemana;
        private System.Windows.Forms.Label Anio;
        private System.Windows.Forms.TextBox tbSemana;
        private System.Windows.Forms.TextBox tbAnio;
    }
}