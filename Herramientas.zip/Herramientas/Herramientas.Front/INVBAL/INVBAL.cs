﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Herramientas.Front.INVBAL
{
    public partial class INVBAL : Form
    {
        public static string procesado { get; set; }

        CultureInfo ci = CultureInfo.InvariantCulture;
        int nr;
        int milliseconds = 1000;
        int milliseconds2 = 6000;
        DateTime tiempoInicio;
        string stbkOnHand   = string.Empty;
        string stbkTransito = string.Empty;
        string stbkOnOrder  = string.Empty;

        public INVBAL()
        {
            InitializeComponent();
        }

        private void INVBAL_Load(object sender, EventArgs e)
        {
            btNoProc.Text = "Cargando...";
            timer1.Start();
            Herramientas.Front.INVBAL.INVBAL.procesado = "1";
        }

        private void btProcesar_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            string invbalLib = tbInvbalLib.Text;
            string invbal    = tbInvbal.Text;
            string stFecha   = string.Empty;
            string stMensaje = string.Empty;
            string anio      = tbAnio.Text;
            string semana    = tbSemana.Text;

            stMensaje = Herramientas.Negocio.INVBAL.INVBAL.GetInstance().ObtenAnioSemana1(anio, semana, invbalLib, invbal, out stFecha);
            lbFecha.Text = "20" + stFecha.Substring(0, 2) + "-" + stFecha.Substring(2, 2) + "-" + stFecha.Substring(4, 2);

            DateTime dt = DateTime.Parse("20"+stFecha.Substring(0, 2) + "-" + stFecha.Substring(2, 2) + "-" + stFecha.Substring(4, 2));

            //DateTime dt = DateTime.Parse("2016-03-20");
            int x = System.Globalization.CultureInfo.CurrentUICulture.Calendar.GetWeekOfYear(dt, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
            
            //Semana MMs 
            string fechaMms  = stFecha;
            string SemanaMms = string.Empty;
            string Mensaje   = Herramientas.Negocio.INVBAL.INVBAL.GetInstance().ObtenSemanaMmsNegocio(fechaMms, out SemanaMms);
            
            tbAnio.Text = stFecha.Substring(0, 2);
            //tbSemana.Text = Convert.ToString(x);
            tbSemana.Text = SemanaMms;

            this.Cursor = Cursors.Default;
            
            string message = "Esta seguro de procesar esta Semana?";
            string caption = "Confirmación";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
            {
                bIniciar();
                btNoProc.Text = "Cargando...";
                if (nr > 0 || tbAnio.Text == "" || tbSemana.Text == "")
                {
                    MessageBox.Show("Esta activo o no es valido el año y/o Semana");
                    timer1.Stop();
                    timer2.Stop();
                    btNoProc.Text = "Fin...";
                }
                else
                {
                    this.Cursor   = Cursors.WaitCursor;
                    btNoProc.Text = "Cargando...";

                    timer1.Start();

                    btSAT704PFonhand.Text   = string.Empty;
                    btSAT704PFtransito.Text = string.Empty;
                    btSAT704PFonorder.Text  = string.Empty;
                    btINVBALonhand.Text     = string.Empty;
                    btINVBALtransito.Text   = string.Empty;
                    btINVBALonorder.Text    = string.Empty;

                    invbalLib = tbInvbalLib.Text;
                    invbal    = tbInvbal.Text;

                    string stInvmstLib = tbInvmstLib.Text;
                    string stInvmst    = tbInvmst.Text;

                    string stGat027fLib = tbGat027fLib.Text;
                    string stGat027f    = tbGat027f.Text;

                    string stGat092fLib = tbGat092fLib.Text;
                    string stGat092f    = tbGat092f.Text;

                    anio     = tbAnio.Text;
                    semana   = tbSemana.Text;
                    Herramientas.Front.INVBAL.INVBAL.procesado = "0";
                    Herramientas.Negocio.INVBAL.INVBAL.GetInstance().EjecutaCarga(invbalLib, invbal, stInvmstLib, stInvmst, stGat027fLib, stGat027f, stGat092fLib, stGat092f, anio, semana);
                    Thread.Sleep(milliseconds2);
                    this.Cursor = Cursors.Default;
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            Thread.Sleep(milliseconds);

            DataTable dtProceos0 = null;
            DataTable dtProceos = null;
            dtProceos0 = Herramientas.Negocio.INVBAL.INVBAL.GetInstance().ObtenpProcesos0INVBAL();
            dtProceos = Herramientas.Negocio.INVBAL.INVBAL.GetInstance().ObtenpProcesosINVBAL();

            if (dtProceos != null)
            {
                if (dtProceos.Rows.Count > 0)
                {
                    //dgvGridView.DataSource = dtProceos;

                    nr = dtProceos.Rows.Count - 1;
                    btNoProc.Text = Convert.ToString(nr);
                    this.Text = "Procesos / " + " " + (nr).ToString() + " Registro(s)";
                }
                else
                {
                    if (dtProceos0 != null)
                    {
                        if (dtProceos0.Rows.Count == 0)
                        {
                            // Validacion de cifras de control
                            timer1.Stop();
                            timer2.Stop();
                            btNoProc.Text = "Fin...";
                            validacionCifras();
                            if (Herramientas.Front.INVBAL.INVBAL.procesado == "0")
                            {
                                string stMensaje = string.Empty;
                                stMensaje = Herramientas.Negocio.INVBAL.INVBAL.GetInstance().UpdateFin();
                                MessageBox.Show(stMensaje);
                            }
                        }
                    }
                
                }
            }

        }

        private void bIniciar()
        {
               tiempoInicio = DateTime.Now;
               timer2.Start();
        }

        private void validacionCifras()
        {
            btSAT704PFonhand.Text   = "Calculando...";
            btSAT704PFtransito.Text = "Calculando...";
            btSAT704PFonorder.Text  = "Calculando...";

            btINVBALonhand.Text   = "Calculando...";
            btINVBALtransito.Text = "Calculando...";
            btINVBALonorder.Text  = "Calculando...";

            if (tbAnio.Text == "" || tbSemana.Text == "")
            {
            }
            else
            {
                // Totales SAT704PF
                string parAnio = tbAnio.Text;
                string parSemana = tbSemana.Text;
                string parLibreria = tbInvbalLib.Text;
                string parArchivo = tbInvbal.Text;
                string stOnHand = string.Empty;
                string stTransito = string.Empty;
                string stOnOrder = string.Empty;
                string stMensaje = string.Empty;

                stMensaje = Herramientas.Negocio.INVBAL.INVBAL.GetInstance().ObtenCifraSAT704PF1(parAnio, parSemana, parLibreria, parArchivo, out stOnHand, out stTransito, out stOnOrder);
                if (stMensaje != "")
                {
                    MessageBox.Show(stMensaje);
                }
                try
                {
                    btSAT704PFonhand.Text = string.Format("{0:n0}", double.Parse(stOnHand));
                    btSAT704PFtransito.Text = string.Format("{0:n0}", double.Parse(stTransito));
                    btSAT704PFonorder.Text = string.Format("{0:n0}", double.Parse(stOnOrder));

                    stbkOnHand = stOnHand;
                    stbkTransito = stTransito;
                    stbkOnOrder = stOnOrder;
                }
                catch { }
                // Totales INVBAL
                stMensaje = Herramientas.Negocio.INVBAL.INVBAL.GetInstance().ObtenCifraINVBAL1(parAnio, parSemana, parLibreria, parArchivo, out stOnHand, out stTransito, out stOnOrder);
                if (stMensaje != "")
                {
                    MessageBox.Show(stMensaje);
                }
                try
                {
                    btINVBALonhand.Text = string.Format("{0:n0}", double.Parse(stOnHand));
                    btINVBALtransito.Text = string.Format("{0:n0}", double.Parse(stTransito));
                    btINVBALonorder.Text = string.Format("{0:n0}", double.Parse(stOnOrder));
                }
                catch { }
                // Deferencia
                try
                {
                    string stDIFonhand = Convert.ToString((Convert.ToInt64(stbkOnHand)) - (Convert.ToInt64(stOnHand)));
                    btDIFonhand.Text = string.Format("{0:n0}", double.Parse(stDIFonhand));
                }
                catch { }
                try
                {
                    string stDIFtransito = Convert.ToString((Convert.ToInt64(stbkTransito)) - (Convert.ToInt64(stTransito)));
                    btDIFtransito.Text = string.Format("{0:n0}", double.Parse(stDIFtransito));
                }
                catch { }
                try
                {
                    string stDIFonorder = Convert.ToString((Convert.ToInt64(stbkOnOrder)) - (Convert.ToInt64(stOnOrder)));
                    btDIFonorder.Text = string.Format("{0:n0}", double.Parse(stDIFonorder));
                }
                catch { }
            }

        }

        private void timer2_Tick(object sender, EventArgs e)
         {
             if (tiempoInicio != DateTime.MinValue)
             {
                 TimeSpan tiempo01 = (DateTime.Now - tiempoInicio);
                 label5.Text = Convert.ToString(tiempo01);
             }
         }

        private void btValidacion_Click(object sender, EventArgs e)
        {
            this.Cursor = Cursors.WaitCursor;

            if (tbAnio.Text == "" || tbSemana.Text == "")
            {
                MessageBox.Show("Debe indicar el año y la semana que se desea comparar...");
            }
            validacionCifras();
            this.Cursor = Cursors.Default;
        }
    }
}
