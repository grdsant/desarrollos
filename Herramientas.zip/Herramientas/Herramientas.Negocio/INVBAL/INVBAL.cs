﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Herramientas.Negocio.INVBAL
{
   public class INVBAL
    {
        internal static INVBAL invbals;

        public static INVBAL GetInstance()
        {
            if (invbals == null)
                invbals = new INVBAL();
            return invbals;
        }

        public void EjecutaCarga(string invbalLib, string invbal, string stInvmstLib, string stInvmst, string stGat027fLib, string stGat027f, string stGat092fLib, string stGat092f, string anio, string semana)
        {
            try
            {
                Herramientas.Datos.INVBAL.INVBAL.EjecutaCarga(invbalLib, invbal, stInvmstLib, stInvmst, stGat027fLib, stGat027f, stGat092fLib, stGat092f, anio, semana);
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string UpdateFin()
        {
            string stMensaje = string.Empty;
            try
            {
               stMensaje = Herramientas.Datos.INVBAL.INVBAL.UpdateFin();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return stMensaje;
        }

        public DataTable ObtenpProcesos0INVBAL()
        {
            DataTable dtProceos = null;
            try
            {
                dtProceos = Herramientas.Datos.INVBAL.INVBAL.ObtenProcesos0INVBAL();

                DataView dv = dtProceos.DefaultView;
                dtProceos = dv.ToTable();

                return dtProceos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObtenpProcesosINVBAL()
        {
            DataTable dtProceos = null;
            try
            {
                dtProceos = Herramientas.Datos.INVBAL.INVBAL.ObtenProcesosINVBAL();

                DataView dv = dtProceos.DefaultView;
                dtProceos = dv.ToTable();

                return dtProceos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string ObtenCifraSAT704PF1(string parAnio, string parSemana, string parLibreria, string parArchivo, out string stOnHand, out string stTransito, out string stOnOrder)
        {
            string stMensaje = string.Empty;
                   stOnHand  = string.Empty;
                   stTransito = string.Empty;
                   stOnOrder = string.Empty;
            try
            {
                stMensaje = Herramientas.Datos.INVBAL.INVBAL.ObtenCifraSAT704PF(parAnio,  parSemana,  parLibreria,  parArchivo, out stOnHand, out stTransito, out stOnOrder);
                return stMensaje;
            }
            catch { }
            finally { }
            return stMensaje;
        }

        public string ObtenCifraINVBAL1(string parAnio, string parSemana, string parLibreria, string parArchivo, out string stOnHand, out string stTransito, out string stOnOrder)
        {
            string stMensaje = string.Empty;
                   stOnHand = string.Empty;
                   stTransito = string.Empty;
                   stOnOrder = string.Empty;
            try
            {
                stMensaje = Herramientas.Datos.INVBAL.INVBAL.ObtenCifraINVBAL(parAnio, parSemana, parLibreria, parArchivo, out stOnHand, out stTransito, out stOnOrder);
                return stMensaje;
            }
            catch { }
            finally { }
            return stMensaje;
        }

        public string ObtenAnioSemana1(string parAnio, string parSemana, string parinvbalLib, string parinvbal, out string stFecha)
        {
            string stMensaje = string.Empty;
            stFecha = string.Empty;
            try
            {
                stMensaje = Herramientas.Datos.INVBAL.INVBAL.ObtenAnioSemana(parAnio, parSemana, parinvbalLib, parinvbal, out stFecha);
                return stMensaje;
            }
            catch { }
            finally { }
            return stMensaje;
        }

        public string ObtenSemanaMmsNegocio(string fecha, out string semanaMms)
        {
            string stMensaje = string.Empty;
            semanaMms = string.Empty;
            try
            {
                stMensaje = Herramientas.Datos.INVBAL.INVBAL.ObtenSemanaMms(fecha, out semanaMms);
                return stMensaje;
            }
            catch { }
            finally { }
            return stMensaje;
        }
    }
}
