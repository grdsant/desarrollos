﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Data;
using System.Collections;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace Herramientas.Datos.INVBAL
{
    public class INVBAL
    {
        #region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        // Ambiente
        public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        public static string Lib610Lib = ConfigurationManager.AppSettings["LIBMM610LIB"].ToString();
        // Ambiente CGI
        public static string Db_CGI = ConfigurationManager.ConnectionStrings["cnnCGISQL"].ToString();
        #endregion
        public static void EjecutaCarga(string invbalLib, string invbal, string stInvmstLib, string stInvmst, string stGat027fLib, string stGat027f, string stGat092fLib, string stGat092f, string anio, string semana)
        {
            string cadenaConexionDb2 = Db2_Prod;
            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT704C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL " + LibSatPgm + ".SAT704CL (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", invbalLib.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", invbal.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", stInvmstLib.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", stInvmst.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", stGat027fLib.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", stGat027f.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", stGat092fLib.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", stGat092f.PadRight(10, ' '));
                sql.AppendFormat("'" + "{0}" + "'" + "," + "\n", anio.PadLeft(2, '0'));
                sql.AppendFormat("'" + "{0}" + "'" + "\n", semana.PadLeft(2, '0'));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string UpdateFin()
        {
            // Actualiza Bandera CGI
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
            SqlConnection cn;
            SqlCommand cmd;
            SqlDataReader dr;

            StringBuilder sqlCgi = new StringBuilder();
            string stMensaje = string.Empty;

            try
            {
                stMensaje = "Error al actualizar la bandera CGI";
                cn = new SqlConnection(Db_CGI);
                cn.Open();

                sqlCgi.Clear();
                sqlCgi.Append("update T_AppConfig set numValue = 1, dateValue = getdate() where id = 15  \n");

                cmd = new SqlCommand(sqlCgi.ToString(), cn);
                dr = cmd.ExecuteReader();
                dr.Close();
                stMensaje = "Se actualizo la bandera de CGI Correctamente";
            }
            catch (Exception ex)
            {
                return stMensaje;
                throw ex;
            }
            return stMensaje;
            // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        }

        public static DataTable ObtenProcesos0INVBAL()
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtProcesos = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT * FROM " + "MMSATOBJ" + ".SAT704CTL0\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtProcesos = new DataTable("Procesos");
                dtProcesos.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtProcesos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static DataTable ObtenProcesosINVBAL()
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtProcesos = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT * FROM " + "MMSATOBJ" + ".SAT704CTL\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtProcesos = new DataTable("Procesos");
                dtProcesos.Load(db2Reader);
                db2Reader.Close();

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return dtProcesos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string ObtenCifraSAT704PF(string parAnio, string parSemana, string parLibreria, string parArchivo, out string stOnHand, out string stTransito, out string stOnOrder)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtOnhandTransitoOnOrder = null;
            string stMensaje = string.Empty;
            stOnHand   = "On Hand";
            stTransito = "Transito";
            stOnOrder  = "On Order";

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT sum(ONHAND), sum(TRANSI), sum(ONORDER) FROM  MMSATOBJ" + "." + "SAT704PF" + " \n"); //" + LibSatObj + "." + "SAT704PF" + " \n");
                sql.AppendFormat(" WHERE ANOI  = " + "'" + "{0}" + "'" + "\n", parAnio.PadLeft(2, '0'));
                sql.AppendFormat(" and   SEM   = " + "'" + "{0}" + "'" + "\n", parSemana.PadLeft(2, '0'));

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtOnhandTransitoOnOrder = new DataTable("OnHandTransito");
                dtOnhandTransitoOnOrder.Load(db2Reader);
                db2Reader.Close();

                if (dtOnhandTransitoOnOrder.Rows.Count > 0)
                {
                    foreach (DataRow row in dtOnhandTransitoOnOrder.Rows)
                    {
                        stOnHand   = string.Format("{0}", double.Parse(row[0].ToString()));
                        stTransito = string.Format("{0}", double.Parse(row[1].ToString()));
                        stOnOrder  = string.Format("{0}", double.Parse(row[2].ToString()));
                    }
                }

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return stMensaje;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return stMensaje;
        }

        public static string ObtenCifraINVBAL(string parAnio, string parSemana, string parLibreria, string parArchivo, out string stOnHand, out string stTransito, out string stOnOrder)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtOnhandTransitoOnOrder = null;
            string stMensaje = string.Empty;
            stOnHand = "On Hand";
            stTransito = "Transito";
            stOnOrder = "On Order";

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();
                
                sql.Clear();
                sql.Append("SELECT SUM( IBHAND ) , SUM( IBINTQ ), SUM( IBPOOQ ) FROM  " + parLibreria + "." + parArchivo + " \n");
                sql.AppendFormat(" WHERE IBDEPT not in(101, 102, 103, 104)" + " \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtOnhandTransitoOnOrder = new DataTable("OnHandTransito");
                dtOnhandTransitoOnOrder.Load(db2Reader);
                db2Reader.Close();

                if (dtOnhandTransitoOnOrder.Rows.Count > 0)
                {
                    foreach (DataRow row in dtOnhandTransitoOnOrder.Rows)
                    {
                        stOnHand = string.Format("{0}", double.Parse(row[0].ToString()));
                        stTransito = string.Format("{0}", double.Parse(row[1].ToString()));
                        stOnOrder = string.Format("{0}", double.Parse(row[2].ToString()));
                    }
                }

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return stMensaje;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return stMensaje;
        }

        public static string ObtenAnioSemana(string parAnio, string parSemana, string parinvbalLib, string parinvbal, out string stFecha)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtOnhandTransitoOnOrder = null;
            string stMensaje = string.Empty;
            stFecha = "";

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT max(IBALD4) FROM  " + parinvbalLib + "." + parinvbal + " \n");
                sql.AppendFormat(" WHERE IBCEN4 = 1" + " \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtOnhandTransitoOnOrder = new DataTable("OnHandTransito");
                dtOnhandTransitoOnOrder.Load(db2Reader);
                db2Reader.Close();

                if (dtOnhandTransitoOnOrder.Rows.Count > 0)
                {
                    foreach (DataRow row in dtOnhandTransitoOnOrder.Rows)
                    {
                        stFecha = string.Format("{0}", double.Parse(row[0].ToString()));
                    }
                }

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return stMensaje;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return stMensaje;
        }

        public static string ObtenSemanaMms(string fecha, out string semanaMms)
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtOnhandTransitoOnOrder = null;
            string stMensaje = string.Empty;
            semanaMms = "";

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("SELECT DATWKY FROM MM610LIB.INVCAL" + " \n");
                sql.AppendFormat(" WHERE DATBAK =" +  fecha + " \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtOnhandTransitoOnOrder = new DataTable("OnHandTransito");
                dtOnhandTransitoOnOrder.Load(db2Reader);
                db2Reader.Close();

                if (dtOnhandTransitoOnOrder.Rows.Count > 0)
                {
                    foreach (DataRow row in dtOnhandTransitoOnOrder.Rows)
                    {
                        semanaMms = string.Format("{0}", double.Parse(row[0].ToString()));
                    }
                }

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return stMensaje;
            }
            catch { }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return stMensaje;
        }

    }
}
