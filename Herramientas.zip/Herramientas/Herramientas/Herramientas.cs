﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Herramientas.Front.INVBAL;

namespace Herramientas
{
    public partial class Herramientas : Form
    {
        public Herramientas()
        {
            InitializeComponent();
        }

        private void btINVBAL_Click(object sender, EventArgs e)
        {
            Form existe = Application.OpenForms.OfType<Form>().Where(pre => pre.Name == "Convenio Melody").SingleOrDefault<Form>();
            {
                if (existe != null)
                {
                    MessageBox.Show("Las ventana del Convenio Melody ya esta abierta");
                }
                else
                {
                     INVBAL i = new INVBAL();
                    i.ShowDialog(this);
                }
            }
        }
    }
}
