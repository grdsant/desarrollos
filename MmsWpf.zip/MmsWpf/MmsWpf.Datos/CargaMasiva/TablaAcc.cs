﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
using System.Data.OleDb;
using System.Configuration;
using System.Data;

namespace MmsWpf.Datos.TablaAcc
{
    public class TablaAcc
    {
        #region Conexion
        // Equipo
        public static string Db2_Prod  = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        public static string Servidor  = ConfigurationManager.ConnectionStrings["IPservidor"].ToString();
        //public static string LibSatObj = ConfigurationManager.AppSettings["LIBMMSATOBJ"].ToString();
        //public static string LibSatPgm = ConfigurationManager.AppSettings["LIBMMSATPGM"].ToString();
        // Ambiente
        #endregion

        public static string ValidaTablaAcc(DataTable dtDatos, string usuario)
        {
            string msgMensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + "MMSATPGM" + ".SAT193R01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();



                foreach (DataRow row in dtDatos.Rows)
                {
                    string proveedor = row["PROVEEDOR"].ToString();
                    string estilo    = row["ESTILO"].ToString();
                    string tabla     = row["NUEVA"].ToString();
                    string user      = usuario;
                    string fecha     = "190605";   // row["RGLFAL"].ToString();
                    string hora      = "101010";   // row["RGLHAL"].ToString();

                    sql.Clear();
                    sql.Append("INSERT INTO " + "MMSATOBJ" + ".SAT193F01 VALUES ( \n");

                    sql.AppendFormat("'" + "{0}" + "'" + "\n", proveedor.PadLeft(6, '0'));
                    sql.Append(", \n");
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", estilo.PadRight(15, ' '));
                    sql.Append(", \n");
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", tabla.PadLeft(2, '0'));
                    sql.Append(", \n");
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", user.PadRight(10, ' '));
                    sql.Append(", \n");
                    sql.AppendFormat("'" + "{0}" + "'" + "\n", fecha.PadLeft(6, '0'));
                    sql.Append(", \n");
                    sql.AppendFormat("'" + "{0}" + "')" + "\n", hora.PadLeft(6, '0'));

                    db2Comm.CommandText = sql.ToString();
                    db2Comm.ExecuteNonQuery();
                }

                msgMensaje = "Proceso Terminado...";

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return msgMensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }


        public static DataTable CargaValidacion()
        {
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtDatos = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL MMSATPGM.SAT193R02 (\n");
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();




                sql.Clear();
                sql.Append("SELECT  VALPRV Proveedor, VALPRVD Nombre, VALSTY Estilo, VALSTYD Descripcion, VALTAC T_Actual, VALTDID T_Nueva, VALVAL Valid, VALAPL Aplicacion \n");

                sql.Append("FROM MMSATOBJ.SAT193F02 \n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtDatos = new DataTable("Validación");
                dtDatos.Load(db2Reader);
                db2Reader.Close();

                return dtDatos;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }

        public static string AplicarTablaAcc(string usuario)
        {
            string msgMensaje = string.Empty;
            string cadenaConexionDb2 = Db2_Prod;

            OleDbConnection db2Conn = null;
            StringBuilder sql = new StringBuilder();

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL " + "MMSATPGM" + ".SAT193R03 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", usuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                msgMensaje = "Proceso Terminado...";

                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();

                return msgMensaje;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }
        }
    }
}
