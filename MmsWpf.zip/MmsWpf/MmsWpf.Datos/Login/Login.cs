﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MmsWpf.Datos.Login
{
    public class Login
    {
        #region Conexion
        // Equipo
        public static string Db2_Prod = ConfigurationManager.ConnectionStrings["cnnIseries"].ToString();
        public static string Servidor = ConfigurationManager.ConnectionStrings["IPservidor"].ToString();

        // Ambiente
        #endregion


        public static DataTable ObtenLogin(string ParUsuario, string ParPassword)
        {
            Servidor = ConfigurationManager.ConnectionStrings["IPservidor"].ToString();
            string cadenaConexionDb2 = "Provider=IBMDA400;Data Source=" + Servidor + ";User Id=" + ParUsuario + " ;Password=" + ParPassword;

            OleDbConnection db2Conn = null;

            StringBuilder sql = new StringBuilder();
            DataTable dtLogin = null;

            try
            {
                db2Conn = new OleDbConnection(cadenaConexionDb2);
                db2Conn.Open();
                OleDbCommand db2Comm = db2Conn.CreateCommand();

                sql.Clear();
                sql.Append("CALL MMSATPGM.SAT177C01 \n");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("CALL MMSATPGM.SAT177R3 (\n");
                sql.AppendFormat("'" + "{0}" + "'" + "\n", ParUsuario.PadRight(10, ' '));
                sql.Append(")");

                db2Comm.CommandText = sql.ToString();
                db2Comm.ExecuteNonQuery();

                sql.Clear();
                sql.Append("SELECT * FROM MMSATOBJ.SAT177F3\n");
                sql.Append(" ORDER BY USRUSR ASC\n");

                db2Comm.CommandText = sql.ToString();
                OleDbDataReader db2Reader = db2Comm.ExecuteReader();

                dtLogin = new DataTable("Login");
                dtLogin.Load(db2Reader);
                db2Reader.Close();
            }

            catch (OleDbException ex)
            {
                throw ex;
            }

            finally
            {
                if (db2Conn != null && db2Conn.State == ConnectionState.Open)
                    db2Conn.Close();
            }

            return dtLogin;
        }

    }
}
