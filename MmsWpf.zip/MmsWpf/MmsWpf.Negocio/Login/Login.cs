﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MmsWpf.Negocio.Login
{
   public class Login
    {
        internal static Login Logins;
        public static Login GetInstance()
        {
            if (Logins == null)
                Logins = new Login();
            return Logins;
        }

        public DataTable ObtenLogin(string ParUsuario, string ParPassword)
        {
            DataTable dtLogin1 = null;
            try
            {
                dtLogin1 = MmsWpf.Datos.Login.Login.ObtenLogin(ParUsuario, ParPassword);

                if (dtLogin1 != null)
                {
                    DataView dv = dtLogin1.DefaultView;
                    dtLogin1 = dv.ToTable();
                }
                return dtLogin1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
