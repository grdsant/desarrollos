﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MmsWpf.Negocio.TablaAcc
{
    public class TablaAcc
    {
        internal static TablaAcc TablaAccs;

        public static TablaAcc GetInstance()
        {
            if (TablaAccs == null)
                TablaAccs = new TablaAcc();
            return TablaAccs;
        }

        public string ValidaTablaAcc(DataTable dtDatos, string usuario)
        {
            try
            {
                return MmsWpf.Datos.TablaAcc.TablaAcc.ValidaTablaAcc(dtDatos, usuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable CargaValidacion()
        {
            try
            {
                return MmsWpf.Datos.TablaAcc.TablaAcc.CargaValidacion();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string AplicarTablaAcc(string usuario)
        {
            try
            {
                return MmsWpf.Datos.TablaAcc.TablaAcc.AplicarTablaAcc(usuario);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
