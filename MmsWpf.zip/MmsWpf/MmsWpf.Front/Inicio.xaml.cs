﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MmsWpf.Front
{
    /// <summary>
    /// Lógica de interacción para Inicio.xaml
    /// </summary>
    public partial class Inicio : Window
    {
        public Inicio()
        {
            InitializeComponent();

            double widthPrimary  = System.Windows.SystemParameters.PrimaryScreenWidth;
            double heightPrimary = System.Windows.SystemParameters.PrimaryScreenHeight;

            double widthArea  = System.Windows.SystemParameters.WorkArea.Height;
            double heightArea = System.Windows.SystemParameters.WorkArea.Width;



            double widthThis = this.Width;
            double heihgtThis = this.Height;

            MmsWpf.Front.CargaMasiva.TablaAcc.varWidth = widthThis;
            MmsWpf.Front.CargaMasiva.TablaAcc.varHeight = heihgtThis;

        }

        private void ButtonPopUpLogout_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        private void ButtonOpenMenu_Click(object sender, RoutedEventArgs e)
        {
            ButtonCloseMenu.Visibility = Visibility.Visible;
            ButtonOpenMenu.Visibility = Visibility.Collapsed;
        }

        private void ButtonCloseMenu_Click(object sender, RoutedEventArgs e)
        {
            ButtonCloseMenu.Visibility = Visibility.Collapsed;
            ButtonOpenMenu.Visibility = Visibility.Visible;
        }


        private void ListViewMenu_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UserControl usc = null;
            GridMain.Children.Clear();

            switch (((ListViewItem)((ListView)sender).SelectedItem).Name)
            {
                case "ItemTablaAcc":
                    usc = new MmsWpf.Front.CargaMasiva.TablaAcc();
                    GridMain.Children.Add(usc);
                    break;
                case "ItemDevoluciones":
                    usc = new MmsWpf.Front.Devoluciones.Devoluciones();
                    GridMain.Children.Add(usc);
                    break;
                default:
                    break;
            }
        }



        private void btMinimizar_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void btMaximizar_Click(object sender, RoutedEventArgs e)
        {
            if (WindowState == WindowState.Maximized)
            {
                WindowState = WindowState.Normal;
            }
            else
            {
                WindowState = WindowState.Maximized;
            }
        }

        private void btCerrar_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void Window_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            double widthThis = this.Width;
            double heihgtThis = this.Height;

            try
            {
                MmsWpf.Front.CargaMasiva.TablaAcc.varWidth = widthThis - 40;
                MmsWpf.Front.CargaMasiva.TablaAcc.varHeight = heihgtThis - 110;
            }
            catch { }
        }
    }
}
