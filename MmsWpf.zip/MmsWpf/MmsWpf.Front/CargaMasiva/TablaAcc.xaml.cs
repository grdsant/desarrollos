﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Drawing;
using System.Collections;
using System.ComponentModel;

using System.Data;
using System.Data.OleDb;

namespace MmsWpf.Front.CargaMasiva
{
    /// <summary>
    /// Lógica de interacción para TablaAcc.xaml
    /// </summary>
    public partial class TablaAcc : UserControl
    {
        string msgMensaje = string.Empty;

        public static double varWidth;
        public static double varHeight;

        public static DataTable dtTablaAcc;

        public System.Data.DataTable dtDatos = null;

        public TablaAcc()
        {
            InitializeComponent();
            double widthPrimary = System.Windows.SystemParameters.PrimaryScreenWidth;
            double heightPrimary = System.Windows.SystemParameters.PrimaryScreenHeight;

            double widthArea = System.Windows.SystemParameters.WorkArea.Height;
            double heightArea = System.Windows.SystemParameters.WorkArea.Width;

            double widthThis  = this.Width;
            double heihgtThis = this.Height;

            dgDatos.Width = varWidth - 30;
            dgDatos.Height = varHeight - 80;

            //dgDatos.Visibility = Visibility.Hidden;
        }

        private void BtPath_Click(object sender, RoutedEventArgs e)
        {
            

        }

        private void BrowseButton_Click(object sender, RoutedEventArgs e)
        {
            ProgressEstatus.IsIndeterminate = true;
            ProgressEstatus.Visibility = Visibility.Visible;

            // Create OpenFileDialog
            Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();

            // Launch OpenFileDialog by calling ShowDialog method
            Nullable<bool> result = openFileDlg.ShowDialog();
            // Get the selected file name and display in a TextBox.
            // Load content of file in a TextBlock
            if (result == true)
            {
                FileNameTextBox.Text = openFileDlg.FileName;
                //TextBlock1.Text = System.IO.File.ReadAllText(openFileDlg.FileName);
              
                string PathConn = "Provider=Microsoft.jet.OLEDB.4.0;Data Source=" + FileNameTextBox.Text + ";Extended Properties=\"Excel 8.0;HDR=Yes;\";";
                OleDbConnection conn = new OleDbConnection(PathConn);

                OleDbDataAdapter myDataAdapter = new OleDbDataAdapter("Select * from [" + "Hoja1" + "$]", conn);
                DataTable dt = new DataTable();

                myDataAdapter.Fill(dt);

                dgDatos.ItemsSource = dt.DefaultView;
                CountingBadge.Badge = dt.Rows.Count;

                MmsWpf.Front.CargaMasiva.TablaAcc.dtTablaAcc = dt;

                ValidationButton.Background = Brushes.Red;
                ValidationButton.Content = "Sin Validar";

            }
            ProgressEstatus.IsIndeterminate = false;
            ProgressEstatus.Visibility = Visibility.Hidden;
        }

        private void btValidar_Click(object sender, RoutedEventArgs e)
        {
            if (ValidationButton.Content.ToString() == "Aprobado")
            {
                MessageBox.Show("Los datos ya se validaron");
            }
            else
            {
                if (ValidationButton.Content.ToString() == "Aplicado")
                {
                    MessageBox.Show("Los datos ya se aplicaron");
                }
                else
                {

                    if (ValidationButton.Content.ToString() == "Error en validación")
                    {
                        MessageBox.Show("Corregir y Vuelva a cargar...");
                    }
                    else
                    {
                        ProgressEstatus.IsIndeterminate = true;
                        ProgressEstatus.Visibility = Visibility.Visible;

                        ValidationButton.Background = Brushes.BlueViolet;
                        ValidationButton.Content = "Procesando...";

                        MessageBoxResult result = System.Windows.MessageBox.Show("Se va a validar los datos que se muestran en la pantalla", "Confirmación", MessageBoxButton.YesNo);
                        switch (result)
                        {
                            case MessageBoxResult.Yes:
                                //System.Windows.MessageBox.Show("Click para procesar", "ok");

                                dtDatos = null;

                                ValidationButton.Background = Brushes.Green;
                                ValidationButton.Content = "Aprobado";

                                dtDatos = MmsWpf.Front.CargaMasiva.TablaAcc.dtTablaAcc;
                                string usuario = MmsWpf.Front.Inicio.VarUsuario;
                                msgMensaje = string.Empty;
                                msgMensaje = MmsWpf.Negocio.TablaAcc.TablaAcc.GetInstance().ValidaTablaAcc(dtDatos, usuario);

                                ValidationButton.Background = Brushes.Green;
                                ValidationButton.Content = "Aprobado";

                                ProgressEstatus.IsIndeterminate = false;
                                ProgressEstatus.Visibility = Visibility.Hidden;

                                CargaValidacion();

                                int rt = 1;
                                string aplicacion = string.Empty;
                                string pasa_nopasa = "0";
                                foreach (DataRow row in dtDatos.Rows)
                                {
                                    aplicacion = row["APLICACION"].ToString();
                                    {
                                        if (aplicacion == "1" )
                                        {
                                            if (pasa_nopasa == "0")
                                            {
                                                pasa_nopasa = "1";
                                                ValidationButton.Background = Brushes.Red;
                                                ValidationButton.Content = "Error en validación";
                                            }
                                        }
                                    };
                                    rt++;
                                }
                                if (pasa_nopasa == "0")
                                {
                                    MessageBox.Show(msgMensaje);
                                }
                                break;
                            case MessageBoxResult.No:

                                ProgressEstatus.IsIndeterminate = false;
                                ProgressEstatus.Visibility = Visibility.Hidden;
                                ValidationButton.Background = Brushes.Red;
                                ValidationButton.Content = "Sin Validar";

                                System.Windows.MessageBox.Show("Cancelado por el usuario", "Confirmación");
                                break;
                        }
                    }
                }
            }
        }

        private void CargaValidacion()
        {
            dtDatos = MmsWpf.Negocio.TablaAcc.TablaAcc.GetInstance().CargaValidacion();

            if (dtDatos.Rows.Count > 0)
            {
                dgDatos.Visibility = Visibility.Visible;
                dgDatos.ItemsSource = dtDatos.DefaultView;
                CountingBadge.Badge = dtDatos.Rows.Count;

                MmsWpf.Front.CargaMasiva.TablaAcc.dtTablaAcc = dtDatos;


            }
            else
            {
                dgDatos.Visibility = Visibility.Hidden;
            }


        }

        private void btAplicar_Click(object sender, RoutedEventArgs e)
        {
            if (ValidationButton.Content.ToString() == "Aprobado")
            {
                if (ValidationButton.Content.ToString() == "Aplicado")
                {
                    MessageBox.Show("Los datos ya se aplicaron");
                }
                else
                {
                    string usuario = MmsWpf.Front.Inicio.VarUsuario;
                    msgMensaje = string.Empty;
                    msgMensaje = MmsWpf.Negocio.TablaAcc.TablaAcc.GetInstance().AplicarTablaAcc(usuario);
                    var bc = new BrushConverter();
                    ValidationButton.Background = (Brush)bc.ConvertFrom("#2D2D30");
                    ValidationButton.Content = "Aplicado";
                    MessageBox.Show(msgMensaje);
                }
            }
            else
            {
                if (ValidationButton.Content.ToString() == "Aplicado")
                {
                    MessageBox.Show("Los datos ya estan aplicados");
                }

                if (ValidationButton.Content.ToString() == "Error en validación")
                {
                    MessageBox.Show("hay errores en la validación");
                }
            }
        }

        private void Row_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void dgDatos_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {

        }

        private void dgDatos_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {

        }

        private void dgDatos_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void dgDatos_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {

        }

        private void dgDatos_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {

        }

        private void Row_DoubleClick(object sender, MouseButtonEventArgs e)
        {
           
        }

        private void BotonValidacion_Click(object sender, RoutedEventArgs e)
        {
            ValidationButton.Background = Brushes.Red;
            ValidationButton.Content = "Sin Validación";
        }

        private void TablaAcc_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            double widthThis = this.Width;
            double heihgtThis = this.Height;

            try
            {

                dgDatos.Width = varWidth - 30;
                dgDatos.Height = varHeight - 80;
            }
            catch { }
        }

        private void btRecargar_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                dgDatos.Width = varWidth - 30;
                dgDatos.Height = varHeight - 80;
            }
            catch { }
        }
    }
}
