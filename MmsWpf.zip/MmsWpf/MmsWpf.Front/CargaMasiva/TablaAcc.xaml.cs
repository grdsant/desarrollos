﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using System.Drawing;
using System.Collections;
using System.ComponentModel;

using System.Data;
using System.Data.OleDb;

namespace MmsWpf.Front.CargaMasiva
{
    /// <summary>
    /// Lógica de interacción para TablaAcc.xaml
    /// </summary>
    public partial class TablaAcc : UserControl
    {
        public static double varWidth;
        public static double varHeight;


        public System.Data.DataTable dtDatos = null;

        public TablaAcc()
        {
            InitializeComponent();
            double widthPrimary = System.Windows.SystemParameters.PrimaryScreenWidth;
            double heightPrimary = System.Windows.SystemParameters.PrimaryScreenHeight;

            double widthArea = System.Windows.SystemParameters.WorkArea.Height;
            double heightArea = System.Windows.SystemParameters.WorkArea.Width;

            double widthThis  = this.Width;
            double heihgtThis = this.Height;

            dgDatos.Width = varWidth - 40;
            dgDatos.Height = varHeight - 110;

            //dgDatos.Visibility = Visibility.Hidden;
        }

        private void BtPath_Click(object sender, RoutedEventArgs e)
        {
            

        }

        private void BrowseButton_Click(object sender, RoutedEventArgs e)
        {
            ProgressEstatus.IsIndeterminate = true;
            ProgressEstatus.Visibility = Visibility.Visible;

            // Create OpenFileDialog
            Microsoft.Win32.OpenFileDialog openFileDlg = new Microsoft.Win32.OpenFileDialog();

            // Launch OpenFileDialog by calling ShowDialog method
            Nullable<bool> result = openFileDlg.ShowDialog();
            // Get the selected file name and display in a TextBox.
            // Load content of file in a TextBlock
            if (result == true)
            {

                dtDatos = null;
                dgDatos.ItemsSource = null;
          
                FileNameTextBox.Text = openFileDlg.FileName;
                //TextBlock1.Text = System.IO.File.ReadAllText(openFileDlg.FileName);
              
                string PathConn = "Provider=Microsoft.jet.OLEDB.4.0;Data Source=" + FileNameTextBox.Text + ";Extended Properties=\"Excel 8.0;HDR=Yes;\";";
                OleDbConnection conn = new OleDbConnection(PathConn);

                OleDbDataAdapter myDataAdapter = new OleDbDataAdapter("Select * from [" + "Hoja1" + "$]", conn);
                DataTable dt = new DataTable();

                myDataAdapter.Fill(dt);

                dgDatos.ItemsSource = dt.DefaultView;
                CountingBadge.Badge = dt.Rows.Count;

            }
            ProgressEstatus.IsIndeterminate = false;
            ProgressEstatus.Visibility = Visibility.Hidden;
        }

        private void btValidar_Click(object sender, RoutedEventArgs e)
        {
            ValidationButton.Background = Brushes.Green;
            ValidationButton.Content = "Aprovado";
        
        }

        private void btAplicar_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Row_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void dgDatos_SelectedCellsChanged(object sender, SelectedCellsChangedEventArgs e)
        {

        }

        private void dgDatos_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {

        }

        private void dgDatos_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void dgDatos_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {

        }

        private void dgDatos_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {

        }

        private void Row_DoubleClick(object sender, MouseButtonEventArgs e)
        {
           
        }

        private void BotonValidacion_Click(object sender, RoutedEventArgs e)
        {
            ValidationButton.Background = Brushes.Red;
            ValidationButton.Content = "Sin Validación";
        }

        private void TablaAcc_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            double widthThis = this.Width;
            double heihgtThis = this.Height;

            try
            {

                dgDatos.Width = varWidth - 40;
                dgDatos.Height = varHeight - 110;
            }
            catch { }
        }

        private void btRecargar_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                dgDatos.Width = varWidth - 40;
                dgDatos.Height = varHeight - 110;
            }
            catch { }
        }
    }
}
