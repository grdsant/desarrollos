﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace MmsWpf.Front
{
    /// <summary>
    /// Lógica de interacción para Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        string usuario = string.Empty;
        string password = string.Empty;
        System.Data.DataTable tbLogin = null;

        public Login()
        {
            InitializeComponent();
        }

        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            DragMove();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            App.Current.Shutdown();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (txt_usuario.Text != "")
            {
                try
                {
                    tbLogin = null;

                    usuario = txt_usuario.Text;
                    SecureString myPass = txt_contraseña.SecurePassword;
                    var pass = (PasswordBox)txt_contraseña;
                    password = pass.Password;

                    tbLogin = MmsWpf.Negocio.Login.Login.GetInstance().ObtenLogin(usuario, password);

                    if (tbLogin != null)
                    {
                        foreach (DataRow row in tbLogin.Rows)
                        {
                            string USRNOM;
                            string USRVIL;
                            string USRMAR;
                            string USRCOM;

                            USRNOM = row["USRNOM"].ToString();
                            USRVIL = row["USRVIL"].ToString();
                            USRMAR = row["USRMID"].ToString();
                            USRCOM = row["USRCOM"].ToString();

                            MmsWpf.Front.Inicio.VarNombre = USRNOM;
                            MmsWpf.Front.Inicio.VarUsuario = usuario;
                            MmsWpf.Front.Inicio.VarPassword = password;

                        }

                        if (tbLogin.Rows.Count > 0)
                        {
                            Inicio objeto = new Inicio();
                            objeto.Show();
                            this.Visibility = Visibility.Hidden;
                        }
                    }
                }
                catch (Exception ex)
                {
                    string Msg = ex.Message.ToString();
                    MessageBox.Show(Msg);
                }
            }
        }

        private void txt_contraseña_KeyUp(object sender, KeyEventArgs e)
        {
            if (txt_usuario.Text != "")
            {
                if (e.Key == Key.Enter)
                {
                    // Carga de Datos
                    try
                    {

                        try
                        {
                            tbLogin = null;

                            usuario = txt_usuario.Text;
                            SecureString myPass = txt_contraseña.SecurePassword;
                            var pass = (PasswordBox)txt_contraseña;
                            password = pass.Password;

                            tbLogin = MmsWpf.Negocio.Login.Login.GetInstance().ObtenLogin(usuario, password);

                            if (tbLogin != null)
                            {
                                foreach (DataRow row in tbLogin.Rows)
                                {
                                    string USRNOM;
                                    string USRVIL;
                                    string USRMAR;
                                    string USRCOM;

                                    USRNOM = row["USRNOM"].ToString();
                                    USRVIL = row["USRVIL"].ToString();
                                    USRMAR = row["USRMID"].ToString();
                                    USRCOM = row["USRCOM"].ToString();

                                    MmsWpf.Front.Inicio.VarNombre = USRNOM;
                                    MmsWpf.Front.Inicio.VarUsuario = usuario;
                                    MmsWpf.Front.Inicio.VarPassword = password;

                                }

                                if (tbLogin.Rows.Count > 0)
                                {
                                    Inicio objeto = new Inicio();
                                    objeto.Show();
                                    this.Visibility = Visibility.Hidden;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            string Msg = ex.Message.ToString();
                            MessageBox.Show(Msg);
                        }
                    }
                    catch { }
                }
            }
        }
    }
}
